# infra/migracao.py
"""
🧱 MIGRAÇÃO GENÉRICA — o CREATE TABLE é a única fonte de verdade.

POR QUE EXISTE
--------------
`CREATE TABLE IF NOT EXISTS` não conserta tabela que já existe (armadilha
nº 14). Produção estourou com `no such column: equip_poder` na tela do clã:
o banco nasceu antes da coluna entrar no CREATE, e lendo o código o schema
parecia certo — no disco estava errado. O clã ganhou `TABELAS` como fonte
única em 17/09; 16 outras tabelas continuavam com o mesmo risco, cada uma
com seu CREATE solto e nenhuma migração.

Aqui a solução é a mesma, sem reescrever o schema de ninguém: depois de cada
CREATE, `garantir_colunas` LÊ o próprio texto do CREATE, compara com a
tabela no disco (`PRAGMA table_info`) e acrescenta o que falta. Coluna nova
num CREATE passa a chegar sozinha em banco velho — não tem como existir num
lugar e faltar no outro, porque o lugar é um só.

O QUE O ALTER DO SQLITE NÃO ACEITA
----------------------------------
`ALTER TABLE ADD COLUMN` recusa PRIMARY KEY, UNIQUE e NOT NULL sem DEFAULT.
Essas restrições são tiradas da definição NA HORA DE ACRESCENTAR (a tabela
nova, criada do zero, continua com elas). Coluna que precisa ser chave não
é o tipo de coluna que se acrescenta depois — se aparecer uma, o log avisa.
"""
from __future__ import annotations

import re

_RE_CREATE = re.compile(
    r"CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+([A-Za-z_][A-Za-z0-9_]*)\s*\((.*?)\)\s*(?:;|$)",
    re.IGNORECASE | re.DOTALL)
_RESTRICOES_DE_TABELA = ("PRIMARY KEY", "UNIQUE", "FOREIGN KEY", "CHECK", "CONSTRAINT")


def _separar_topo(corpo: str) -> list[str]:
    """Separa por vírgula só no nível de fora — `DEFAULT (x, y)` ou
    `CHECK (a IN (1, 2))` têm vírgula dentro e não são coluna nova."""
    partes, nivel, atual = [], 0, []
    for ch in corpo:
        if ch == "(":
            nivel += 1
        elif ch == ")":
            nivel -= 1
        if ch == "," and nivel == 0:
            partes.append("".join(atual).strip())
            atual = []
        else:
            atual.append(ch)
    if "".join(atual).strip():
        partes.append("".join(atual).strip())
    return partes


def tabelas_do_sql(sql: str) -> dict[str, list[tuple[str, str]]]:
    """{tabela: [(coluna, definição)]} de todo CREATE TABLE IF NOT EXISTS do
    texto (serve pra `execute` de um CREATE só ou `executescript` de vários).
    Comentário `--` é removido antes, pra não virar pedaço de coluna."""
    limpo = re.sub(r"--[^\n]*", "", sql or "")
    saida: dict[str, list[tuple[str, str]]] = {}
    for m in _RE_CREATE.finditer(limpo):
        cols = []
        for parte in _separar_topo(m.group(2)):
            if not parte or parte.upper().startswith(_RESTRICOES_DE_TABELA):
                continue
            nome, _, definicao = parte.partition(" ")
            cols.append((nome.strip().strip('"`[]'), definicao.strip()))
        saida[m.group(1)] = cols
    return saida


def definicao_para_alter(definicao: str) -> str:
    """Tira o que o ALTER do SQLite recusa. NOT NULL sem DEFAULT também sai:
    as linhas que já existem não teriam valor pra cumprir a regra."""
    d = re.sub(r"\bPRIMARY\s+KEY\b(\s+AUTOINCREMENT)?", "", definicao, flags=re.IGNORECASE)
    d = re.sub(r"\bUNIQUE\b", "", d, flags=re.IGNORECASE)
    if re.search(r"\bNOT\s+NULL\b", d, re.IGNORECASE) and not re.search(r"\bDEFAULT\b", d, re.IGNORECASE):
        d = re.sub(r"\bNOT\s+NULL\b", "", d, flags=re.IGNORECASE)
    return re.sub(r"\s+", " ", d).strip()


def _plano(sql: str, existentes_por_tabela: dict[str, set]) -> list[tuple[str, str, str]]:
    plano = []
    for tabela, cols in tabelas_do_sql(sql).items():
        existentes = existentes_por_tabela.get(tabela)
        if existentes is None:          # tabela não existe: o CREATE cuida
            continue
        for nome, definicao in cols:
            if nome not in existentes:
                plano.append((tabela, nome, definicao_para_alter(definicao)))
    return plano


def garantir_colunas(conn, sql: str) -> list[str]:
    """Acrescenta, nas tabelas do `sql` que já existem, as colunas que o
    CREATE tem e o disco não. `conn` pode ser conexão ou cursor sqlite3.
    Devolve a lista "tabela.coluna" do que foi acrescentado."""
    existentes = {}
    for tabela in tabelas_do_sql(sql):
        linhas = conn.execute(f"PRAGMA table_info({tabela})").fetchall()
        if linhas:
            existentes[tabela] = {l[1] for l in linhas}
    feitos = []
    for tabela, nome, definicao in _plano(sql, existentes):
        conn.execute(f"ALTER TABLE {tabela} ADD COLUMN {nome} {definicao}")
        feitos.append(f"{tabela}.{nome}")
    if feitos:
        print(f"[migração] colunas acrescentadas: {', '.join(feitos)}")
    return feitos


async def garantir_colunas_async(db, sql: str) -> list[str]:
    """A mesma coisa pra conexão aiosqlite (o `init_db` do sql_repo)."""
    existentes = {}
    for tabela in tabelas_do_sql(sql):
        cur = await db.execute(f"PRAGMA table_info({tabela})")
        linhas = await cur.fetchall()
        if linhas:
            existentes[tabela] = {l[1] for l in linhas}
    feitos = []
    for tabela, nome, definicao in _plano(sql, existentes):
        await db.execute(f"ALTER TABLE {tabela} ADD COLUMN {nome} {definicao}")
        feitos.append(f"{tabela}.{nome}")
    if feitos:
        print(f"[migração] colunas acrescentadas: {', '.join(feitos)}")
    return feitos
