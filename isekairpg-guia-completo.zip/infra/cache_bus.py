# infra/cache_bus.py
"""
Ponte simples entre a lógica do jogo (game/logic.py) e o cache em memória
do processo do bot (main.py).

PROBLEMA QUE ISSO RESOLVE:
main.py mantém um cache em memória (`_player_cache`) pra não bater no SQLite
a cada clique. Só que em vários pontos da raid (loot, morte de jogador),
o `game/logic.py` escreve DIRETO no banco os dados de OUTRO jogador que não
é quem clicou no botão agora. Se esse outro jogador já está em cache, a
próxima vez que ELE clicar em algo, o main.py salva de volta no banco a
versão antiga que estava em memória — apagando a mudança (loot sumia,
estado de morte sumia, etc.).

Este módulo guarda um conjunto de user_ids "sujos". `cache_load()` no
main.py checa esse conjunto: se o usuário está lá, força um reload do
banco (ignora o cache) antes de continuar, e depois limpa a marca.
"""

_dirty_users: set[int] = set()


def mark_dirty(user_id: int) -> None:
    """Chame isso sempre que escrever no banco os dados de um jogador
    que não é o autor da ação atual (ex: dar loot pro time, matar
    alguém em raid, etc.)."""
    try:
        _dirty_users.add(int(user_id))
    except (TypeError, ValueError):
        pass


def is_dirty(user_id: int) -> bool:
    try:
        return int(user_id) in _dirty_users
    except (TypeError, ValueError):
        return False


def clear_dirty(user_id: int) -> None:
    try:
        _dirty_users.discard(int(user_id))
    except (TypeError, ValueError):
        pass
