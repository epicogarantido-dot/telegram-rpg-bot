// ===========================================================
// 🚨 REDE DE SEGURANÇA — TEM QUE SER A PRIMEIRA COISA DO ARQUIVO
// -----------------------------------------------------------
// No WebView do Telegram o jogador não tem console. Sem isto, um
// erro de JS deixa a tela parada, sem nada na cara dele, e ele
// acha que o jogo travou. Fica no TOPO de propósito: se estivesse
// no fim, um erro de carregamento aconteceria ANTES do registro e
// justamente o caso que ele existe pra cobrir ficaria descoberto.
// ===========================================================
(function () {
  var jaMostrou = false;

  function avisar(titulo, detalhe) {
    try { console.error(titulo, detalhe); } catch (e) {}
    if (jaMostrou) return;          // um aviso só; erro em loop não vira spam
    jaMostrou = true;
    try {
      var caixa = document.createElement("div");
      caixa.setAttribute("role", "alert");
      caixa.style.cssText =
        "position:fixed;left:12px;right:12px;bottom:12px;z-index:99999;" +
        "background:#2a0d12;border:1px solid #7c2b3a;border-radius:12px;" +
        "padding:12px 14px;color:#ffd9df;font:13px/1.45 system-ui,sans-serif;" +
        "box-shadow:0 8px 24px rgba(0,0,0,.5)";
      caixa.innerHTML =
        '<b>Algo quebrou nesta tela.</b><br>' +
        'Feche e abra o app de novo. Se continuar, mande print desta mensagem.' +
        '<br><span style="opacity:.7;font-size:var(--t-mini);word-break:break-word">' +
        String(titulo + " — " + detalhe).slice(0, 300) + "</span>" +
        '<br><button style="margin-top:8px;background:#7c2b3a;color:#fff;border:0;' +
        'border-radius:8px;padding:6px 12px;font:12px system-ui">Fechar</button>';
      caixa.querySelector("button").onclick = function () {
        caixa.remove();
        jaMostrou = false;
      };
      (document.body || document.documentElement).appendChild(caixa);
    } catch (e) {
      // se nem isso deu, o alert nativo é o último recurso
      try { alert("Algo quebrou nesta tela. Feche e abra o app de novo."); } catch (e2) {}
    }
  }

  window.addEventListener("error", function (ev) {
    avisar(
      (ev && ev.message) || "Erro",
      ((ev && ev.filename) || "") + ":" + ((ev && ev.lineno) || "?")
    );
  });

  window.addEventListener("unhandledrejection", function (ev) {
    var r = ev && ev.reason;
    avisar("Promessa rejeitada", (r && (r.message || r)) || "sem detalhe");
  });
})();

// ===========================================================
// ISEKAIRPG — Mini App
// Fala com a API do bot (mesmo processo Python, mesmo banco).
// Estrutura de shell (gaveta, roteador, bottom sheet, som,
// confete, número flutuante, ripple) adaptada de um projeto
// irmão que já validou esses padrões em produção — só a Ficha
// de Personagem está de verdade ligada na API por enquanto
// (Fase 1); o resto mostra "em construção" e continua no bot.
// ===========================================================

// ===========================================================
// 📱 VIBRAÇÃO (20/09/2026 — o Mini App do Telegram saiu com o bot)
// ===========================================================
// Antes a vibração e os alertas iam pelo cliente do Telegram. O jogo agora
// é só site: a vibração usa a API do navegador (celular Android; no iOS o
// Safari não vibra e a chamada simplesmente não faz nada), e os alertas são
// sempre o toast do próprio jogo.
function vibrar(tipo) {
  try { if (navigator.vibrate) navigator.vibrate(tipo === "erro" ? [40, 30, 40] : 15); }
  catch (e) { /* aparelho sem vibração: nada a fazer */ }
}

// ===========================================================
// 🔐 SESSÃO DO SITE (migração pra fora do Telegram)
// -----------------------------------------------------------
// O token fica em localStorage, não em cookie. É a outra ponta da
// decisão do servidor: com CORS liberado, cookie seria buraco de
// CSRF, porque o navegador anexa cookie sozinho. Header não.
//
// Enquanto a migração não termina, os dois caminhos convivem:
//   token salvo  -> Authorization: Bearer <token>   (site)
//   initData     -> Authorization: tma <initData>   (Telegram)
// Quem abre pelo Telegram continua entrando sem fazer nada.
// ===========================================================
const CHAVE_TOKEN = "iso_token";

function pegarToken() {
  try { return localStorage.getItem(CHAVE_TOKEN) || ""; } catch (e) { return ""; }
}
function salvarToken(token) {
  try { localStorage.setItem(CHAVE_TOKEN, token); } catch (e) {}
}
function limparToken() {
  try { localStorage.removeItem(CHAVE_TOKEN); } catch (e) {}
}
function cabecalhoAuth() {
  const token = pegarToken();
  if (token) return `Bearer ${token}`;
  return "";
}


// ---------- som (sintetizado, sem precisar hospedar arquivo de áudio) ----------
let AUDIO_CTX = null;
function pegarAudioCtx() {
  if (!AUDIO_CTX) {
    try { AUDIO_CTX = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return null; }
  }
  if (AUDIO_CTX.state === "suspended") AUDIO_CTX.resume();
  return AUDIO_CTX;
}
function somLigado() { return localStorage.getItem("iso_som") !== "off"; }
function alternarSom() {
  localStorage.setItem("iso_som", somLigado() ? "off" : "on");
  return somLigado();
}
function tocarTom(freq, duracao, tipo = "sine", volume = 0.12, atraso = 0) {
  if (!somLigado()) return;
  const ctx = pegarAudioCtx();
  if (!ctx) return;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = tipo;
  osc.frequency.value = freq;
  const inicio = ctx.currentTime + atraso;
  gain.gain.setValueAtTime(0, inicio);
  gain.gain.linearRampToValueAtTime(volume, inicio + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.001, inicio + duracao);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(inicio);
  osc.stop(inicio + duracao + 0.05);
}
const som = {
  // 🖼️ (09/07/2026): cada som agora também dispara a vibração háptica
  // nativa do Telegram — a documentação oficial recomenda isso pra dar
  // uma sensação "premium" e confirmar ações sem precisar olhar pra tela.
  // Como já chamamos som.vitoria()/erro() em toda vitória/derrota do
  // jogo (torre, arena, raid...), isso se propaga automaticamente sem
  // precisar mexer em cada tela uma por uma.
  clique: () => { tocarTom(600, 0.06, "square", 0.04); vibrar("leve"); },
  vitoria: () => {
    tocarTom(523, 0.15, "triangle"); tocarTom(659, 0.15, "triangle", 0.12, 0.12); tocarTom(784, 0.3, "triangle", 0.12, 0.24);
    vibrar("sucesso");
  },
  erro: () => { tocarTom(180, 0.15, "sawtooth", 0.08); vibrar("erro"); },
  moeda: () => { tocarTom(880, 0.08, "square", 0.06); tocarTom(1100, 0.1, "square", 0.06, 0.06); vibrar("leve"); },
  raro: () => {
    [523, 659, 784, 1047].forEach((f, i) => tocarTom(f, 0.35, "triangle", 0.11, i * 0.09));
    vibrar("sucesso");
  },
};

// ---------- trilha sonora (ambiente, sintetizada — sem precisar hospedar
// arquivo de música, mesmo motor de áudio do resto do app) ----------
let MUSICA_TIMER = null;
let TRILHA_INDICE = 0;
function musicaLigada() { return localStorage.getItem("iso_musica") === "on"; }
function alternarMusica() {
  const ligar = !musicaLigada();
  localStorage.setItem("iso_musica", ligar ? "on" : "off");
  if (ligar) iniciarTrilha(); else pararTrilha();
  return ligar;
}
function atualizarBotaoMusica() {
  const btn = document.getElementById("btn-musica");
  if (btn) btn.style.opacity = musicaLigada() ? "1" : "0.4";
}

// acorde sustentado, várias notas juntas, volume bem baixo — é fundo, não protagonista
function tocarAcorde(freqs, duracao, volume = 0.022) {
  if (!somLigado()) return; // respeita o mesmo mudo geral do som
  const ctx = pegarAudioCtx();
  if (!ctx) return;
  const inicio = ctx.currentTime + 0.05;
  freqs.forEach((f) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = f;
    gain.gain.setValueAtTime(0, inicio);
    gain.gain.linearRampToValueAtTime(volume, inicio + duracao * 0.3);
    gain.gain.linearRampToValueAtTime(0, inicio + duracao);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(inicio);
    osc.stop(inicio + duracao + 0.1);
  });
}

// progressão mística (Ré menor → Sib → Fá → Dó), clima de fantasia sem letra —
// só notas sustentadas em loop lento, pensado pra não cansar em sessões longas
const TRILHA_PROGRESSAO = [
  [146.83, 174.61, 220.00], // Dm
  [116.54, 146.83, 174.61], // Bb
  [174.61, 220.00, 261.63], // F
  [130.81, 164.81, 196.00], // Am (encaixa melhor que C puro na progressão menor)
];

function iniciarTrilha() {
  if (MUSICA_TIMER || !musicaLigada()) return;
  const DURACAO_ACORDE = 4.5;
  const passo = () => {
    if (!musicaLigada()) { MUSICA_TIMER = null; return; }
    tocarAcorde(TRILHA_PROGRESSAO[TRILHA_INDICE % TRILHA_PROGRESSAO.length], DURACAO_ACORDE);
    TRILHA_INDICE++;
    MUSICA_TIMER = setTimeout(passo, DURACAO_ACORDE * 1000 * 0.92); // leve sobreposição, sem silêncio entre acordes
  };
  passo();
}
function pararTrilha() {
  if (MUSICA_TIMER) { clearTimeout(MUSICA_TIMER); MUSICA_TIMER = null; }
}
function atualizarBotaoSom() {
  const btn = document.getElementById("btn-som");
  if (btn) btn.textContent = somLigado() ? "🔊" : "🔇";
}

// ---------- ripple global (qualquer botão) ----------
document.addEventListener("click", (ev) => {
  const btn = ev.target.closest("button");
  if (!btn) return;
  const rect = btn.getBoundingClientRect();
  if (rect.width === 0 || rect.height === 0) return;
  const ripple = document.createElement("span");
  ripple.className = "ripple";
  const tamanho = Math.max(rect.width, rect.height) * 1.4;
  ripple.style.width = ripple.style.height = `${tamanho}px`;
  ripple.style.left = `${ev.clientX - rect.left - tamanho / 2}px`;
  ripple.style.top = `${ev.clientY - rect.top - tamanho / 2}px`;
  btn.classList.add("tem-ripple");
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 600);
});

// ---------- helpers seguros (nunca innerHTML com texto do jogador) ----------
function el(tag, className, texto) {
  const e = document.createElement(tag === undefined ? "div" : tag);
  if (className) e.className = className;
  if (texto !== undefined) e.textContent = texto;
  return e;
}
function escaparHtml(texto) {
  const div = document.createElement("div");
  div.textContent = texto;
  return div.innerHTML;
}

// ---------- chamada de API autenticada ----------
async function api(caminho, opcoes = {}) {
  let resp;
  if (opcoes.headers) {
    for (const k of Object.keys(opcoes.headers)) {
      if (opcoes.headers[k] === undefined) delete opcoes.headers[k];
    }
  }
  try {
    const { semToast, ...opcoesFetch } = opcoes;
    resp = await fetch(caminho, {
      ...opcoesFetch,
      headers: {
        ...(opcoes.semAuth ? {} : { "Authorization": cabecalhoAuth() }),
        // FormData tem que ir SEM Content-Type: quem monta o boundary do
        // multipart é o navegador. Fixar "application/json" aqui quebraria
        // todo upload de arquivo.
        ...(opcoes.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
        ...(opcoes.headers || {}),
      },
    });
  } catch (e) {
    const msg = "Sem conexão com o servidor — confere sua internet e tenta de novo.";
    if (!opcoes.semToast) toast(msg, true);   // semToast: quem chama mostra a própria tela
    const err = new Error(msg); err.jaAlertado = true; throw err;
  }
  if (!resp.ok) {
    const erro = await resp.json().catch(() => ({ detail: `Erro no servidor (${resp.status}).` }));
    const msg = erro.detail || "Erro na requisição.";
    // 🔐 Sessão morta: em vez de alerta sem saída, devolve pra tela de
    // login. Sem isto o jogador com token vencido via só um "sessão
    // expirada" e ficava preso numa tela morta, sem nada pra tocar.
    // 🔒 Conta bloqueada: o servidor devolve 403 com os detalhes. Vira tela
    // própria, com a saída visível — alerta solto deixaria a pessoa presa
    // sem entender nem o motivo nem o que fazer.
    if (resp.status === 409 && erro?.detail?.fora_da_cidade) {
      mostrarPortaoCidade(erro.detail);
      const err = new Error(erro.detail.msg || msg); err.jaAlertado = true; throw err;
    }
    if (resp.status === 403 && erro?.detail?.bloqueada) {
      mostrarContaBloqueada(erro.detail);
      const err = new Error("conta bloqueada"); err.jaAlertado = true; throw err;
    }
    if (resp.status === 401 && pegarToken() && !opcoes.semAuth) {
      limparToken();
      mostrarLogin("Sua sessão expirou. Entre de novo.");
      const err = new Error(msg); err.jaAlertado = true; throw err;
    }
    if (resp.status === 401 || resp.status >= 500) {
      if (!opcoes.semToast) toast(msg, true);
      const err = new Error(msg); err.jaAlertado = true; throw err;
    }
    throw new Error(msg);
  }
  try { return await resp.json(); } catch (e) {
    throw new Error("O servidor respondeu de um jeito inesperado — tenta de novo.");
  }
}

// ===========================================================
// 🔐 TELA DE ENTRADA DO SITE
// Fora do Telegram não existe identidade de graça. Esta é a
// primeira coisa que um visitante vê quando não tem sessão.
// ===========================================================
let MODO_ENTRADA = "entrar";   // "entrar" | "criar"
let CONVIDADO = false;          // 🎮 (28/09) conta sem usuário e senha: o token é a única chave

function mostrarLogin(aviso = "") {
  document.getElementById("app")?.classList.add("oculto");
  document.getElementById("barra-abas")?.classList.add("oculto");
  const tela = document.getElementById("tela-carregando");
  tela.classList.remove("oculto");
  tela.innerHTML = "";

  const caixa = el("div", "portao");
  caixa.appendChild(el("div", "portao-marca", "⛩️"));
  caixa.appendChild(el("h1", "portao-titulo", "Isekai RPG"));
  caixa.appendChild(el("p", "portao-lore",
    MODO_ENTRADA === "entrar"
      ? "A torre continua exatamente onde você parou."
      : "Escolha um nome. Ele não muda depois."));

  if (aviso) caixa.appendChild(el("div", "portao-aviso", aviso));

  const campoUsuario = document.createElement("input");
  campoUsuario.className = "sheet-input";
  campoUsuario.type = "text";
  campoUsuario.autocapitalize = "off";
  campoUsuario.autocomplete = "username";
  campoUsuario.spellcheck = false;
  campoUsuario.placeholder = "Usuário";
  caixa.appendChild(campoUsuario);

  const campoSenha = document.createElement("input");
  campoSenha.className = "sheet-input";
  campoSenha.type = "password";
  campoSenha.autocomplete = MODO_ENTRADA === "entrar" ? "current-password" : "new-password";
  campoSenha.placeholder = "Senha";
  caixa.appendChild(campoSenha);

  // 20/09/2026: o campo "código do bot" saiu com o bot. O servidor ainda
  // aceita `codigo` (vincular um save antigo), mas não existe mais de onde
  // tirar um código — mostrar o campo seria pedir algo impossível.
  const campoCodigo = null;
  if (MODO_ENTRADA === "criar") {
    caixa.appendChild(el("p", "portao-dica portao-atencao",
      "⚠️ Anote a senha. Não existe recuperação por e-mail."));
  }

  const botao = document.createElement("button");
  botao.className = "botao-holofote";
  botao.style.marginTop = "14px";
  botao.textContent = MODO_ENTRADA === "entrar" ? "Entrar" : "Criar conta";
  caixa.appendChild(botao);

  const alternar = document.createElement("button");
  alternar.className = "botao-secundario";
  alternar.style.marginTop = "10px";
  alternar.style.width = "100%";
  alternar.textContent = MODO_ENTRADA === "entrar"
    ? "Não tenho conta ainda" : "Já tenho conta";
  alternar.onclick = () => {
    MODO_ENTRADA = MODO_ENTRADA === "entrar" ? "criar" : "entrar";
    mostrarLogin();
  };
  caixa.appendChild(alternar);

  // 🎮 (28/09, dev) começar como convidado: um toque, sem cadastro
  const convidado = document.createElement("button");
  convidado.className = "botao-secundario";
  convidado.style.marginTop = "10px";
  convidado.style.width = "100%";
  convidado.textContent = "🎮 Jogar como convidado";
  caixa.appendChild(convidado);
  caixa.appendChild(el("p", "portao-dica",
    "Sem cadastro. Dá pra criar usuário e senha depois, em Mais → Conta, sem perder nada."));

  const erro = el("div", "portao-erro");
  caixa.appendChild(erro);
  convidado.onclick = async () => {
    erro.textContent = "";
    convidado.disabled = true;
    convidado.textContent = "Abrindo a Torre...";
    try {
      const r = await api("/api/auth/convidado", { method: "POST", semAuth: true });
      salvarToken(r.token);
      CONVIDADO = true;
      await entrarNoJogo();
    } catch (e) {
      erro.textContent = e.message || "Não consegui entrar. Tente de novo.";
      convidado.disabled = false;
      convidado.textContent = "🎮 Jogar como convidado";
    }
  };

  async function enviar() {
    erro.textContent = "";
    const usuario = campoUsuario.value.trim();
    const senha = campoSenha.value;
    // Guarda com aviso, não guarda mudo: um botão que não faz nada faz o
    // jogador achar que o app travou.
    if (!usuario || !senha) {
      erro.textContent = "Preencha usuário e senha.";
      return;
    }
    botao.disabled = true;
    botao.textContent = "Um instante...";
    try {
      const rota = MODO_ENTRADA === "entrar" ? "/api/auth/entrar" : "/api/auth/registrar";
      const corpo = { usuario, senha };
      if (campoCodigo && campoCodigo.value.trim()) corpo.codigo = campoCodigo.value.trim();
      const r = await api(rota, {
        method: "POST",
        body: JSON.stringify(corpo),
        semAuth: true,
      });
      salvarToken(r.token);
      if (r.vinculado) toast("Personagem recuperado. Bem-vindo de volta.");
      await entrarNoJogo();
    } catch (e) {
      erro.textContent = e.message || "Não consegui entrar. Tente de novo.";
      botao.disabled = false;
      botao.textContent = MODO_ENTRADA === "entrar" ? "Entrar" : "Criar conta";
    }
  }

  botao.onclick = enviar;
  // Enter no teclado do celular envia — sem isso a pessoa fecha o teclado
  // só pra achar o botão.
  campoSenha.onkeydown = (ev) => { if (ev.key === "Enter") enviar(); };
  if (campoCodigo) campoCodigo.onkeydown = (ev) => { if (ev.key === "Enter") enviar(); };

  tela.appendChild(caixa);
  campoUsuario.focus();
}

async function sairDaConta() {
  // 🎮 convidado não tem senha: o token é a única chave da conta
  if (CONVIDADO && !confirm(
    "Você está jogando como CONVIDADO, sem usuário e senha.\n\n"
    + "Se sair agora, não tem como voltar pra este personagem — ele se perde pra sempre.\n\n"
    + "Pra guardar, cancele e use \"Salvar progresso\" em Mais → Conta.\n\nSair mesmo assim?")) return;
  try { await api("/api/auth/sair", { method: "POST" }); } catch (e) { /* sair é local de qualquer jeito */ }
  CONVIDADO = false;
  limparToken();
  MODO_ENTRADA = "entrar";
  mostrarLogin("Você saiu.");
}


// ===========================================================
// 🔔 CAIXA DE AVISOS
// O bot mandava mensagem no chat. Fora do Telegram não existe
// chat — então o aviso mora aqui dentro.
// ===========================================================
let AVISOS_NAO_LIDOS = 0;

function atualizarBadgeAvisos(n) {
  AVISOS_NAO_LIDOS = Number(n) || 0;
  const badge = document.getElementById("badge-avisos");
  if (!badge) return;
  badge.textContent = AVISOS_NAO_LIDOS > 9 ? "9+" : String(AVISOS_NAO_LIDOS);
  badge.classList.toggle("oculto", AVISOS_NAO_LIDOS === 0);
}

async function checarAvisos() {
  try {
    const r = await api("/api/avisos");
    atualizarBadgeAvisos(r.nao_lidos);
    return r.avisos || [];
  } catch (e) { return []; }   // aviso é acessório: nunca atrapalha o jogo
}

function quandoTexto(ts) {
  if (!ts) return "";
  const min = Math.floor(Date.now() / 1000 - ts) / 60;
  if (min < 1) return "agora";
  if (min < 60) return `há ${Math.floor(min)} min`;
  const h = min / 60;
  if (h < 24) return `há ${Math.floor(h)}h`;
  return `há ${Math.floor(h / 24)} dias`;
}

async function abrirAvisos() {
  som.clique();
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", "🔔 Avisos"));
  const lista = el("div");
  lista.appendChild(el("p", "texto-fraco", "Carregando..."));
  corpo.appendChild(lista);
  abrirSheet(corpo);

  const avisos = await checarAvisos();
  lista.innerHTML = "";
  if (!avisos.length) {
    // Estado vazio que explica o que vai aparecer aqui, em vez de só
    // dizer que está vazio.
    lista.appendChild(estadoVazio("🔔",
      "Nada por enquanto. Aqui chegam as confirmações de Pix e o aviso "
      + "de quando alguém compra um item seu no Mercado."));
    return;
  }
  for (const a of avisos) {
    const item = el("div", "aviso-item" + (a.lido_em ? "" : " novo"));
    item.appendChild(el("div", "aviso-titulo", a.titulo));
    item.appendChild(el("div", "aviso-texto", a.texto));
    item.appendChild(el("div", "aviso-quando", quandoTexto(a.criado_em)));
    lista.appendChild(item);
  }
  // Marca como lido só DEPOIS de desenhar: assim a borda dourada do que
  // era novo ainda aparece nesta abertura, e some na próxima.
  try {
    await api("/api/avisos/lidos", { method: "POST" });
    atualizarBadgeAvisos(0);
  } catch (e) { /* acessório */ }
}

document.getElementById("btn-avisos")?.addEventListener("click", abrirAvisos);


// ===========================================================
// 🎭 CRIAÇÃO DE PERSONAGEM — classe e raça
// Só existia no bot. Quem criava conta pelo site ficava sem as
// duas pra sempre, e como a escolha é DEFINITIVA não havia
// conserto depois.
//
// Desenho: as duas escolhas são irreversíveis, então a tela
// mostra o preço junto com o ganho. Esconder o lado ruim numa
// decisão sem volta é o tipo de coisa que o jogador só descobre
// tarde demais.
// ===========================================================
const NOME_STAT = {
  atk: "Ataque", def: "Defesa", spd: "Velocidade", acc: "Precisão",
  eva: "Evasão", crit: "Crítico", reg: "Regeneração", hp_max: "Vida",
};
const NOME_ATRIBUTO = { str: "Força", vit: "Vitalidade", agi: "Agilidade", dex: "Destreza" };

// 🐛 (28/09) Antes: QUALQUER erro aqui (servidor ocupado, internet
// oscilando, um 500) virava "não falta criar nada" — e o jogo entrava com o
// personagem pela metade: sem sexo/raça/profissão/habilidade e com o menu
// de baixo aceso ("deu erro e saiu da rota"). Agora tenta de novo uma vez e,
// se ainda falhar, devolve { erro } — quem chama mostra "Tentar de novo" e
// NUNCA abre o jogo no escuro. Medido em testes/testar_criacao_fluxo.js.
async function precisaCriarPersonagem() {
  let ultimoErro = null;
  for (let tentativa = 0; tentativa < 2; tentativa++) {
    try {
      const r = await api("/api/character/opcoes", { semToast: true });
      // 26/09/2026 (dev): a ordem é SEXO → RAÇA → PROFISSÃO. O sexo vem
      // primeiro porque, com a raça, escolhe a arte — e o carrossel de raças
      // já mostra a imagem certa pra quem escolheu.
      // ✨ (28/09) + o 4º passo: a habilidade comum da profissão
      return (!r.classe_atual || !r.raca_atual || !r.sexo_atual || r.skill_pendente) ? r : null;
    } catch (e) {
      if (e.jaAlertado && !pegarToken()) return { erro: true, sessao: true };   // 401: já foi pro login
      ultimoErro = e;
      await new Promise((ok) => setTimeout(ok, 700));
    }
  }
  return { erro: true, mensagem: (ultimoErro && ultimoErro.message) || "" };
}

/** Falha ao confirmar o estado da criação: tela de "Tentar de novo", com o
 *  menu de baixo apagado — nunca abre o jogo com o personagem pela metade. */
function mostrarFalhaNaCriacao(info) {
  if (info && info.sessao) return;            // o api() já mostrou o login
  document.getElementById("barra-abas")?.classList.add("oculto");
  const tela = document.getElementById("tela-carregando");
  tela.classList.remove("oculto");
  tela.innerHTML = "";
  const box = el("div", "em-construcao");
  box.appendChild(el("div", "em-construcao-icone", "⚠️"));
  box.appendChild(el("p", "", "Não consegui falar com o servidor agora. A sua criação está salva até aqui."));
  const btn = document.createElement("button");
  btn.className = "botao-holofote";
  btn.textContent = "Tentar de novo";
  btn.onclick = () => location.reload();
  box.appendChild(btn);
  tela.appendChild(box);
}

// Carrossel de escolha. Um card por vez, do tamanho da tela.
//
// Troca em relação à grade de dois por linha: cabe MUITO mais dentro de cada
// card — o símbolo grande, a descrição inteira, o atributo principal, e ganhos
// e perdas lado a lado sem apertar. O que se perde é ver duas opções ao mesmo
// tempo; por isso os efeitos ficam sempre na MESMA altura do card, e a
// comparação vira deslizar, como virar carta. Sem isso, o carrossel seria
// bonito e pior de decidir.
//
// Rola com scroll-snap nativo: acompanha o dedo, tem inércia do sistema e
// obedece "menos movimento" sem código extra. Carrossel com timer em JS não
// faz nada disso, e ainda anda sozinho na cara de quem está lendo.
function montarCarrossel(lista, ehClasse, aoEscolher) {
  const bloco = el("div", "carrossel-bloco");
  const trilho = el("div", "carrossel");
  const pontos = el("div", "carrossel-pontos");

  lista.forEach((opcao, indice) => {
    const slide = el("div", "carrossel-slide");
    const cartao = el("div", "escolha-cartao");

    const selo = el("div", "escolha-selo", ehClasse ? (CLASSE_SIMBOLO[opcao.id] || "❔") : "🧬");
    if (ehClasse) selo.style.setProperty("--cor-aura", CLASSE_COR[opcao.id] || "");
    if (opcao.arte) {
      // ✨ (28/09) a carta de habilidade traz a arte dela (o emblema da skill)
      const moldura = el("div", "escolha-selo escolha-selo-skill");
      moldura.appendChild(opcao.arte());
      cartao.appendChild(moldura);
    } else if (!ehClasse && opcao.img_key) {
      // 🖼️ (26/09) a raça com a arte dela (e do sexo escolhido); se a
      // imagem falhar, volta o selo
      const retrato = el("div", "escolha-retrato");
      retrato.appendChild(imagemDoJogo(opcao.img_key, 480, () => retrato.replaceWith(selo)));
      cartao.appendChild(retrato);
    } else {
      cartao.appendChild(selo);
    }

    cartao.appendChild(el("div", "escolha-nome", opcao.nome));
    if (opcao.atributo) {
      cartao.appendChild(el("div", "escolha-atributo",
        "Atributo principal: " + (NOME_ATRIBUTO[opcao.atributo] || opcao.atributo)));
    }
    cartao.appendChild(el("div", "escolha-lore", opcao.descricao || ""));

    const efeitos = el("div", "escolha-efeitos");
    // ✨ carta de habilidade: o que ela faz, uma linha por efeito
    for (const linha of opcao.efeitos || []) {
      efeitos.appendChild(el("span", "escolha-neutro", linha));
    }
    for (const g of opcao.ganhos || []) {
      efeitos.appendChild(el("span", "escolha-ganho", `+${g.pct}% ${NOME_STAT[g.stat] || g.stat}`));
    }
    // Mesmo tamanho e mesmo peso do ganho. Numa escolha sem volta, o custo
    // não pode ser letra miúda.
    for (const pd of opcao.perdas || []) {
      efeitos.appendChild(el("span", "escolha-perda", `${pd.pct}% ${NOME_STAT[pd.stat] || pd.stat}`));
    }
    if (!(opcao.efeitos || []).length && !(opcao.ganhos || []).length && !(opcao.perdas || []).length) {
      efeitos.appendChild(el("span", "escolha-neutro", "Sem modificador de status"));
    }
    cartao.appendChild(efeitos);

    const botao = document.createElement("button");
    botao.className = "botao-holofote escolha-botao";
    botao.textContent = `Escolher ${opcao.nome}`;
    botao.onclick = () => aoEscolher(opcao, botao);
    cartao.appendChild(botao);

    slide.appendChild(cartao);
    trilho.appendChild(slide);

    const ponto = document.createElement("button");
    ponto.className = "carrossel-ponto" + (indice === 0 ? " ativo" : "");
    ponto.setAttribute("aria-label", `Ir para ${opcao.nome}`);
    ponto.onclick = () => irParaSlide(trilho, indice);
    pontos.appendChild(ponto);
  });

  const anterior = document.createElement("button");
  anterior.className = "carrossel-seta anterior";
  anterior.setAttribute("aria-label", "Opção anterior");
  anterior.textContent = "‹";
  const proxima = document.createElement("button");
  proxima.className = "carrossel-seta proxima";
  proxima.setAttribute("aria-label", "Próxima opção");
  proxima.textContent = "›";

  const atual = () => Math.round(trilho.scrollLeft / Math.max(1, trilho.clientWidth));
  anterior.onclick = () => irParaSlide(trilho, atual() - 1);
  proxima.onclick = () => irParaSlide(trilho, atual() + 1);

  const contador = el("div", "carrossel-contador", `1 de ${lista.length}`);

  // Atualiza ponto, contador e setas conforme o dedo arrasta. Sem isto o
  // jogador não sabe quantas opções faltam nem que ainda há mais pro lado.
  let agendado = false;
  trilho.addEventListener("scroll", () => {
    if (agendado) return;
    agendado = true;
    requestAnimationFrame(() => {
      agendado = false;
      const i = atual();
      contador.textContent = `${i + 1} de ${lista.length}`;
      [...pontos.children].forEach((p, n) => p.classList.toggle("ativo", n === i));
      anterior.disabled = i <= 0;
      proxima.disabled = i >= lista.length - 1;
    });
  });
  anterior.disabled = true;
  if (lista.length <= 1) proxima.disabled = true;

  const barra = el("div", "carrossel-barra");
  barra.append(anterior, contador, proxima);

  bloco.append(trilho, pontos, barra);
  return bloco;
}

function irParaSlide(trilho, indice) {
  const total = trilho.children.length;
  const alvo = Math.max(0, Math.min(total - 1, indice));
  trilho.scrollTo({ left: alvo * trilho.clientWidth, behavior: "smooth" });
}

async function telaCriacao(dados) {
  const c = document.getElementById("conteudo");
  // 🐛 (28/09) a criação é tela cheia: o menu de baixo nunca aparece aqui —
  // tocar nele largava a criação no meio
  document.getElementById("barra-abas")?.classList.add("oculto");
  // 26/09/2026: SEXO (1) → RAÇA (2, com as imagens) → PROFISSÃO (3)
  // ✨ 28/09/2026 (dev): → HABILIDADE (4), uma ativa comum da profissão
  const etapaSexo = !dados.sexo_atual;
  const etapaRaca = !etapaSexo && !dados.raca_atual;
  const etapaClasse = !etapaSexo && !etapaRaca && !dados.classe_atual;
  const etapaSkill = !etapaSexo && !etapaRaca && !etapaClasse;
  const lista = etapaSkill
    ? (dados.skills_iniciais || []).map((sk) => ({ ...sk, arte: () => emblemaSkill(sk.skill_id, 1, "active", 96) }))
    : etapaClasse ? dados.classes : dados.racas;

  c.innerHTML = "";
  const topo = el("div", "criacao-topo");
  const passo = etapaSexo ? 1 : etapaRaca ? 2 : etapaClasse ? 3 : 4;
  // 🌱 nascido na Torre: raça e profissão vêm sorteadas — só 2 passos
  const nascido = !!dados.nascido_na_torre;
  topo.appendChild(el("div", "criacao-passo", nascido ? `Passo ${etapaSexo ? 1 : 2} de 2` : `Passo ${passo} de 4`));
  topo.appendChild(el("h2", "criacao-titulo",
    etapaSexo ? "Escolha o sexo" : etapaRaca ? "Escolha sua raça"
      : etapaClasse ? "Escolha sua profissão" : "Escolha sua primeira habilidade"));
  topo.appendChild(el("p", "criacao-lore",
    etapaSexo
      ? "Junto com a raça, é o que decide a sua arte — o retrato que aparece na ficha, no topo e na batalha."
      : etapaRaca
      ? "A raça define de onde você vem — e a sua aparência. É definitiva."
      : etapaClasse
      ? "A profissão define como você luta. Cada uma troca alguma coisa por outra — e a escolha é para sempre."
      : "Sua primeira habilidade de combate: entra no slot 1 e já vale na primeira luta. As outras você conquista na Torre, e dá pra evoluir esta depois."));
  if (nascido) {
    const raca = (dados.racas || []).find((x) => x.id === dados.raca_atual);
    const classe = (dados.classes || []).find((x) => x.id === dados.classe_atual);
    topo.appendChild(el("p", "criacao-lore",
      `🌱 Nascido na Torre: a raça (${raca ? raca.nome : dados.raca_atual}) e a profissão `
      + `(${classe ? classe.nome : dados.classe_atual}) vieram do sangue, sorteadas. Em troca, +10% em todos os status.`));
  }
  c.appendChild(topo);

  // ---- passo 1: sexo. Duas opções, sem carrossel.
  if (etapaSexo) {
    const grade = el("div", "combate-acoes");
    for (const [sigla, rotulo, emoji] of [["m", "Masculino", "♂️"], ["f", "Feminino", "♀️"]]) {
      const b = document.createElement("button");
      b.className = "botao-holofote";
      b.textContent = `${emoji} ${rotulo}`;
      b.onclick = async () => {
        if (!confirm(`Escolher ${rotulo}? Essa decisão não pode ser trocada depois.`)) return;
        b.disabled = true;
        try {
          await api("/api/character/sexo", { method: "POST", body: JSON.stringify({ sexo: sigla }) });
          som.moeda();
          const proximo = await precisaCriarPersonagem();
          if (proximo && proximo.erro) mostrarFalhaNaCriacao(proximo);
          else if (proximo) await telaCriacao(proximo);
          else await entrarNoJogo();
        } catch (e) {
          som.erro(); if (!e.jaAlertado) toast(e.message, true); b.disabled = false;
        }
      };
      grade.appendChild(b);
    }
    c.appendChild(grade);
    return;
  }

  const aoEscolher = (async (op, botao) => {
      // Confirmação explícita: é irreversível, e um deslize no carrossel
      // pode parar em cima de um botão sem querer.
      if (!confirm(`Escolher ${op.nome}? Essa decisão não pode ser trocada depois.`)) return;
      botao.disabled = true;
      botao.textContent = "Confirmando...";
      try {
        const rota = etapaSkill ? "/api/character/skill_inicial"
          : etapaClasse ? "/api/character/classe" : "/api/character/raca";
        const r = await api(rota, { method: "POST", body: JSON.stringify({ id: op.id }) });
        if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true);
                     botao.disabled = false; botao.textContent = `Escolher ${op.nome}`; return; }
        som.moeda();
        notificacaoGrande(etapaSkill ? "✨" : "🎭", op.nome,
          etapaSkill ? "Habilidade aprendida — está no slot 1"
            : etapaClasse ? "Profissão definida" : "Raça definida");
        const proximo = await precisaCriarPersonagem();
        if (proximo && proximo.erro) { mostrarFalhaNaCriacao(proximo); return; }
        if (proximo) await telaCriacao(proximo);
        // (28/09) era irPara("personagem"): pulava o resto da entrada — o
        // pedido de nome, o guia inicial e a barra de abas (que continuava
        // escondida). Tudo só aparecia depois de atualizar a página.
        else await entrarNoJogo();
      } catch (e) {
        som.erro();
        if (!e.jaAlertado) toast(e.message, true);
        botao.disabled = false; botao.textContent = `Escolher ${op.nome}`;
      }
  });
  if (etapaSkill && !lista.length) {
    // profissão sem ativa comum no catálogo: não trava a entrada
    await entrarNoJogo();
    return;
  }
  c.appendChild(montarCarrossel(lista, etapaClasse, aoEscolher));
}


// ---------- 🏥 hospital ----------
// Existia só no bot (hospital:heal). Cura tudo de uma vez por ouro; o
// preço sobe com o nível (10g + nível/5).
async function renderHospital() {
  const c = document.getElementById("conteudo");
  mostrarEsqueleto();
  let ficha;
  try { ficha = await api("/api/character"); }
  catch (e) { c.innerHTML = ""; if (!e.jaAlertado) toast(e.message, true); return; }

  const hp = Number(ficha.hp ?? 0), hpMax = Number(ficha.hp_max ?? 1);
  const nivel = Number(ficha.level ?? 1);
  const custo = 10 + Math.floor(nivel / 5);
  const cheio = hp >= hpMax;

  c.innerHTML = "";
  inserirBanner(c, "hospital", "hospital");

  const painel = el("div", "gold-panel");
  painel.appendChild(el("div", "arena-semana-titulo", "🏥 Tratamento"));
  painel.appendChild(barraDeProgresso("Vida", `${hp} / ${hpMax}`,
                                      Math.max(0, Math.min(100, (hp / hpMax) * 100)), "barra-hp"));
  painel.appendChild(el("p", "texto-fraco",
    cheio ? "Sua vida já está cheia. Volte quando se machucar."
          : `Recupera toda a vida de uma vez. Custa ${custo}💰 — o preço sobe conforme você sobe de nível.`));

  const botao = document.createElement("button");
  botao.className = "botao-holofote";
  botao.style.marginTop = "12px";
  // Botão desabilitado COM motivo visível logo acima, em vez de um botão
  // que parece clicável e não faz nada.
  botao.disabled = cheio || Number(ficha.gold ?? 0) < custo;
  botao.textContent = cheio ? "Vida cheia"
    : (Number(ficha.gold ?? 0) < custo ? `Faltam ${custo - Number(ficha.gold ?? 0)}💰` : `Curar por ${custo}💰`);
  botao.onclick = async () => {
    botao.disabled = true;
    try {
      const r = await api("/api/hospital/heal", { method: "POST" });
      if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); botao.disabled = false; return; }
      som.moeda();
      toast(r.msg.replace(/<[^>]+>/g, ""));
      atualizarTopo({ gold: r.gold });
      await renderHospital();
    } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); botao.disabled = false; }
  };
  painel.appendChild(botao);
  c.appendChild(painel);
}


// ---------- 💎 engaste de gemas ----------
// Existia só no bot. Sem esta tela as cores que caem no jogo não têm onde
// ser usadas — viram peso morto no inventário.
//
// Regra dura do motor, e por isso ela aparece DUAS vezes na tela: engastar
// em slot ocupado DESTRÓI a gema que estava lá. É irreversível e o jogador
// precisa saber antes de tocar, não depois.
let SOCKET_ALVO = null;   // item escolhido
let SOCKET_SLOT = null;   // número do slot escolhido

async function renderEngaste() {
  const c = document.getElementById("conteudo");
  mostrarEsqueleto();
  let d;
  try { d = await api("/api/socket/itens"); }
  catch (e) { c.innerHTML = ""; if (!e.jaAlertado) toast(e.message, true); return; }

  c.innerHTML = "";
  inserirBanner(c, "forja", "engaste");
  c.appendChild(el("h3", "secao-titulo", "💎 Engaste"));

  if (!d.itens.length) {
    c.appendChild(estadoVazio("💎",
      "Nenhum item seu tem encaixe de gema. Encaixes vêm do item — "
      + "os forjados em raridade mais alta nascem com mais."));
    return;
  }
  if (!d.cores.length) {
    c.appendChild(estadoVazio("💎",
      "Você tem itens com encaixe, mas nenhuma gema. Elas caem dos monstros "
      + "da Torre e da Exploração."));
    return;
  }

  c.appendChild(el("p", "texto-fraco",
    "Toque num encaixe pra escolher a gema. Encaixe já ocupado: a gema antiga é destruída."));

  for (const item of d.itens) {
    const cartao = el("div", `cartao-item engaste-peca ${classeRar(item.raridade)}`);
    // 🖼️ 20/09/2026: a arte da peça vem primeiro, e os encaixes ficam numa
    // linha embaixo dela. A API já mandava `img_key` e a tela só escrevia o
    // nome — nesta tela, em especial, escolher errado DESTRÓI a gema que
    // estava no encaixe, então ver em que peça se está mexendo não é enfeite.
    const cab = el("div", "engaste-cabeca");
    const arteItem = el("div", "engaste-arte");
    if (item.img_key) porFundo(arteItem, urlImagem(item.img_key, 96));
    const cabTxt = el("div", "engaste-cabeca-txt");
    cabTxt.appendChild(el("div", `cartao-item-nome ${classeRar(item.raridade)}`,
      item.nome + (item.equipado ? "  ·  equipado" : "")));
    cabTxt.appendChild(el("div", "texto-fraco",
      `${item.livres} encaixe(s) livre(s) de ${item.slots.length}`
      + (textoBonusRaridade(item.bonus_raridade)[0] ? `  ·  ${textoBonusRaridade(item.bonus_raridade)[0]}` : "")));
    cab.append(arteItem, cabTxt);
    cartao.appendChild(cab);

    const fila = el("div", "engaste-slots");
    for (const slot of item.slots) {
      const pino = el("button", "engaste-slot" + (slot.core ? " ocupado" : ""));
      pino.textContent = slot.core ? "💎" : "○";
      pino.title = slot.nome || `Encaixe ${slot.indice + 1} — vazio`;
      pino.onclick = () => escolherGema(item, slot, d.cores);
      fila.appendChild(pino);
      if (slot.core) {
        fila.appendChild(el("span", "engaste-etiqueta", slot.nome));
      }
    }
    cartao.appendChild(fila);
    c.appendChild(cartao);
  }
}

function escolherGema(item, slot, cores) {
  som.clique();
  SOCKET_ALVO = item.alvo; SOCKET_SLOT = slot.indice;
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", `Encaixe ${slot.indice + 1} — ${item.nome}`));

  if (slot.core) {
    // O aviso vem antes da lista, não depois: quem lê de cima pra baixo
    // precisa saber do custo antes de ver as opções.
    const alerta = el("div", "engaste-alerta");
    alerta.textContent = `Aqui já tem ${slot.nome}. Engastar outra DESTRÓI essa — não tem como tirar de volta.`;
    corpo.appendChild(alerta);
  }

  for (const core of cores) {
    const linha = document.createElement("button");
    linha.className = "engaste-opcao";
    const bonus = Object.entries(core.bonus || {})
      .map(([k, v]) => `+${v} ${NOME_STAT[k] || k}`).join("  ");
    linha.append(
      el("span", "engaste-opcao-nome", `${core.nome}  ×${core.qtd}`),
      el("span", "engaste-opcao-bonus", bonus || "—"));
    linha.onclick = () => aplicarGema(core, slot);
    corpo.appendChild(linha);
  }
  abrirSheet(corpo);
}

async function aplicarGema(core, slot) {
  if (slot.core && !confirm(`Engastar ${core.nome} aqui destrói ${slot.nome}. Continuar?`)) return;
  try {
    const r = await api("/api/socket/aplicar", {
      method: "POST",
      body: JSON.stringify({ alvo: SOCKET_ALVO, slot: SOCKET_SLOT, core: core.id }),
    });
    if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
    som.forja ? som.forja() : som.moeda();
    fecharSheet();
    toast(r.msg.replace(/<[^>]+>/g, ""));
    await renderEngaste();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}


// ---------- 🔒 conta bloqueada ----------
// O bot barrava conta bloqueada desde sempre (core/router.py:251). O Mini
// App nunca barrou — dava pra continuar jogando normalmente. E o bloqueio
// nem era gravado no banco, então sumia no primeiro reinício.
function mostrarContaBloqueada(info) {
  document.getElementById("app")?.classList.add("oculto");
  document.getElementById("barra-abas")?.classList.add("oculto");
  const tela = document.getElementById("tela-carregando");
  tela.classList.remove("oculto");
  tela.innerHTML = "";

  const caixa = el("div", "portao");
  caixa.appendChild(el("div", "portao-marca", "🔒"));
  caixa.appendChild(el("h1", "portao-titulo", "Conta bloqueada"));
  caixa.appendChild(el("p", "portao-lore", info.motivo || "Pagamento não confirmado."));
  if (info.pedido) caixa.appendChild(el("p", "portao-dica", `Pedido: ${info.pedido}`));

  caixa.appendChild(el("p", "portao-dica",
    "Se você pagou de verdade, fale com o administrador com o comprovante em mãos — "
    + "o pedido continua registrado e o desbloqueio é na hora."));
  caixa.appendChild(el("p", "portao-dica portao-atencao",
    "A outra saída é resetar o personagem e começar do zero. Isso apaga nível, "
    + "itens, ouro e ⭐, e não tem volta."));

  const campo = document.createElement("input");
  campo.className = "sheet-input";
  campo.placeholder = "Digite RESETAR para confirmar";
  campo.autocapitalize = "characters";
  campo.oninput = () => { campo.value = campo.value.toUpperCase(); };
  caixa.appendChild(campo);

  const botao = document.createElement("button");
  botao.className = "botao-secundario";
  botao.style.width = "100%";
  botao.textContent = "Resetar personagem";
  const erro = el("div", "portao-erro");

  botao.onclick = async () => {
    if (campo.value.trim() !== "RESETAR") {
      erro.textContent = "Digite RESETAR exatamente assim para confirmar.";
      return;
    }
    botao.disabled = true; botao.textContent = "Resetando...";
    try {
      await api("/api/conta/reset", {
        method: "POST", body: JSON.stringify({ confirmacao: "RESETAR" }) });
      location.reload();
    } catch (e) {
      erro.textContent = e.message || "Não consegui resetar. Tente de novo.";
      botao.disabled = false; botao.textContent = "Resetar personagem";
    }
  };
  caixa.appendChild(botao);
  caixa.appendChild(erro);

  if (pegarToken()) {
    const sair = document.createElement("button");
    sair.className = "botao-secundario";
    sair.style.width = "100%"; sair.style.marginTop = "8px";
    sair.textContent = "Sair da conta";
    sair.onclick = sairDaConta;
    caixa.appendChild(sair);
  }
  tela.appendChild(caixa);
}


// ---------- 📖 tutorial de primeira vez ----------
// O bot mostrava um tutorial na primeira visita a cada tela — 13 no total.
// O site nunca mostrou nenhum. Aqui eles voltam, com uma diferença: dá pra
// reler. No bot apareceu, fechou, acabou.
const TUTORIAL_DA_TELA = {
  torre: "tower", explorar: "explore", onda: "wave", boss_global: "global_boss",
  raid: "raid", party: "raid_rooms", forja: "craft", engaste: "socket",
  loja: "shop", skills: "skills", especialidade: "trails",
  // (28/09) "clan" saiu daqui: o Resumo abre o GUIA_CLAN 600 ms depois, e a
  // folha abria por baixo dele — o guia bloqueava o "Entendi" da folha e a
  // folha cobria o botão que o guia mandava tocar. O texto segue na Ajuda.
  // situacoes também saiu (28/09): o Clã abre no Resumo, e é lá que o guia
  // do clã explica tudo. A folha "O seu clã" fica só na Ajuda.
};
const TUTORIAIS_JA_TENTADOS = new Set();

// =============================================================================
// 👆 GUIA DE CLIQUE (26/09/2026, pedido do dev)
// -----------------------------------------------------------------------------
// "Um tutorial inicial que conduz o jogador pelas páginas, de clique
// controlado, explicando o básico — e o básico do clã quando ele libera."
// A tela escurece, só o alvo fica aceso, e o balão explica. Passo "toque":
// só o alvo recebe o toque (o resto é bloqueado) e o toque avança. Passo
// "ok": o botão Entendi avança. Cada roteiro aparece UMA vez (salvo no
// servidor como tutorial visto: guia_inicio / guia_clan) e dá pra pular.
// Alvo que não aparece em 6 s é pulado — o guia nunca trava o jogo.
// =============================================================================
let GUIA_ATIVO = null;
let GUIA_DEPOIS_DO_NOME = false;
let _guiaRolagem = 0;
window.addEventListener("scroll", () => {
  if (!GUIA_ATIVO) return;
  cancelAnimationFrame(_guiaRolagem);
  _guiaRolagem = requestAnimationFrame(desenharPassoDoGuia);
}, { passive: true });

const GUIA_INICIO = [
  { id: "inicio", cap: "O básico", ok: true, titulo: "Bem-vindo à Torre", texto: "Você acordou dentro de uma Torre de 100 andares. Vou te mostrar o básico: a ficha, uma luta, a forja e o equipamento. Toque em Entendi pra seguir." },
  { alvo: ".placa-andar", ok: true, titulo: "Seu andar", texto: "Aqui fica o andar da Torre em que você está. Cada andar é mais difícil — e dá mais ouro, XP e itens." },
  { alvo: ".topo-recursos", ok: true, titulo: "Ouro e estrelas", texto: "💰 Ouro compra quase tudo. ⭐ Estrelas são a moeda rara, da conta: valem pra todos os seus personagens." },
  { alvo: '.aba-item[data-grupo="personagem"]', titulo: "Seu personagem", texto: "Toque em Você pra ver sua ficha." },
  { alvo: ".poder-de-combate", ok: true, titulo: "Poder de combate", texto: "O ⚡ poder resume sua força. Na Torre, cada inimigo mostra o poder dele comparado ao seu." },
  { alvo: ".stats-grid, .grade-stats", ok: true, titulo: "Status", texto: "Ataque, defesa, velocidade... Subindo de nível você ganha pontos pra gastar nas Trilhas." },
  { alvo: '.aba-item[data-grupo="cidade"]', ok: true, titulo: "A Cidade", texto: "Na Cidade ficam a Loja, o Hospital e a Forja — onde você cria equipamento com os cores que os monstros deixam." },
  { alvo: '.aba-item[data-grupo="mais"]', ok: true, titulo: "Missões e mais", texto: "Em Mais ficam as Missões diárias (o reino paga ouro todo dia), o Ranking e a sua Conta." },
  { id: "luta", cap: "Primeira luta", alvo: '.aba-item[data-grupo="mundo"]', titulo: "A Torre", texto: "Agora vamos lutar. Toque em Mundo." },
  // ⚔️ (26/09, dev) estendido: luta guiada → fuga → forja das 4 peças → mochila
  { alvo: "#btn-explorar-torre", titulo: "Explorar", texto: "Explore pra encontrar monstros. Toque em Explorar.",
    aoTocar: async () => { desenharCombate(await api("/api/guia/luta", { method: "POST" })); } },
  { id: "atacar", alvo: "#btn-atacar", vezes: 2, titulo: "Atacar", texto: "A luta é por turnos: quando sua barra enche, é sua vez. Toque em Atacar — duas vezes." },
  // ✨ (28/09) a habilidade escolhida na criação, usada na primeira luta
  { alvo: ".btn-skill-combate", titulo: "Sua habilidade", texto: "Essa é a habilidade que você escolheu. Bate mais forte que o Atacar, mas depois recarrega por alguns turnos. Toque nela!" },
  { alvo: ".combate-vs", ok: true, titulo: "Vida e turnos", texto: "Em cima fica a sua vida e a do inimigo; embaixo, a ordem dos próximos turnos. Skills e poções também gastam o turno." },
  { alvo: "#btn-fugir", titulo: "Hora de recuar", texto: "Esse monstro aguenta mais do que parece — e você está sem equipamento. Toque em Fugir.",
    aoTocar: async () => {
      const r = await api("/api/guia/fugir", { method: "POST" });
      if (r && r.log) toast(String(r.log).replace(/<[^>]+>/g, ""));
      await renderTorre();
    } },
  // 🛠️ (28/09, dev) "Ensina só a primeira arma e depois já faz automático":
  // a Espada é guiada toque a toque; Armadura, Elmo e Anel saem pela forja
  // de verdade num toque (mesmo ouro, ferro e cores). Na Mochila, idem: o
  // guia ensina a vestir a arma e veste o resto. Eram 42 passos, agora 26.
  { id: "forja", cap: "Forja", alvo: '.aba-item[data-grupo="cidade"]', titulo: "Pra Cidade", texto: "Sem equipamento não dá. Toque em Cidade." },
  { alvo: '.caminho[data-tela="forja"]', titulo: "A Forja", texto: "Toque em Forja: você começou com cores pra forjar as primeiras peças." },
  { alvo: '[data-forja="weapon:sword"]', ok: true, titulo: "Uma Espada", texto: "Primeiro, uma Espada — ela já está escolhida. Cada peça pede cores do tipo dela (aqui, Core de Arma)." },
  { alvo: '.core-linha[data-core="wa_atk"] .core-mais', vezes: 4, titulo: "Coloque os cores", texto: "Uma peça comum leva 4 cores. Toque 4 vezes no + do Core de Arma ATK." },
  { alvo: "#btn-forjar", titulo: "Forjar", texto: "Toque em Forjar!" },
  { alvo: ".sheet-opcao", titulo: "Peça pronta!", texto: "Sua primeira peça. Toque em Continuar." },
  { id: "forja_resto", ok: true, rotuloOk: "Forjar as 3", titulo: "O resto é comigo",
    texto: "Agora você sabe forjar. Pra não repetir tudo, eu forjo a Armadura, o Elmo e o Anel — com o seu ouro e os seus cores, igual à Forja normal.",
    aoOk: async () => {
      const r = await api("/api/guia/forjar_resto", { method: "POST" });
      atualizarTopo({ gold: r.gold });
      if (r.feitas && r.feitas.length) {
        som.raro();
        notificacaoGrande("🛠️", `${r.feitas.length} peças forjadas`, r.feitas.map((x) => x && x.nome).filter(Boolean).join(" · "));
      }
      for (const f of r.falhas || []) toast(f, true);
      if (TELA_ATUAL === "forja") await renderForja();
    } },
  { id: "equipar", cap: "Equipar", alvo: '.aba-item[data-grupo="personagem"]', titulo: "Vestir tudo", texto: "Peças forjadas vão pra Mochila. Toque em Você." },
  { alvo: '.caminho[data-tela="inventario"]', titulo: "Mochila", texto: "Toque em Mochila." },
  { alvo: '[data-inv-slot="weapon"]', titulo: "Arma", texto: "Toque em Arma." },
  { alvo: ".btn-equipar", titulo: "Equipar", texto: "Toque em Equipar." },
  { id: "equipar_resto", ok: true, rotuloOk: "Vestir o resto", titulo: "E o resto",
    texto: "É assim com qualquer peça: escolhe o tipo em cima e toca em Equipar. A Armadura, o Elmo e o Anel eu visto pra você.",
    aoOk: async () => {
      await api("/api/guia/equipar_resto", { method: "POST" });
      som.moeda();
      if (TELA_ATUAL === "inventario") await renderInventario();
      atualizarEstadoSilenciosoTopo();
    } },
  { id: "fim", ok: true, titulo: "Pronto pra Torre!", texto: "Tudo equipado — seu ⚡ poder subiu. Volte pra Torre e explore. Quando achar o portal pro 2º andar, você funda o seu clã antes de subir. Boa sorte, aventureiro!" },
];

const GUIA_CLAN = [
  { ok: true, titulo: "Seu clã", texto: "O clã é a sua aldeia na Torre — e ele trabalha enquanto você não está. Vou mostrar o essencial." },
  { alvo: ".clan-recursos", ok: true, titulo: "Recursos", texto: "Comida, madeira, couro e ferro. Todo aldeão come e queima lenha; se faltar, as equipes rendem só metade. Cada vez que você volta, o clã conta até 6 h do que passou." },
  { alvo: ".membros", ok: true, titulo: "Membros e equipes", texto: "Seus aldeões, com os talentos ao lado. Os botões filtram quem está em cada equipe. Aldeão parado não produz." },
  { alvo: ".cultivo", ok: true, titulo: "XP parado", texto: "Depois de 20 min sem jogar, seu personagem ganha XP sozinho, sem risco — pelo seu poder, +10% por guarda (até +100%). Aqui você pode deixar personagens LUTANDO o tempo todo: rende sempre, mas eles podem morrer." },
  { alvo: '.caminho[data-tela="clan_postos"]', titulo: "Explorar o andar", texto: "Toque em Explorar andar: é lá que você monta as equipes que coletam." },
  { alvo: ".caixa-exploracao, .andar-cabecalho", ok: true, titulo: "Equipes", texto: "Uma equipe precisa de coletores e pelo menos 1 guarda. Ela fica 12 h num posto e volta. No posto do tipo certo, rende mais." },
  { ok: true, titulo: "Crônicas", texto: "De vez em quando, a aldeia vive uma história que espera sua decisão — procure o 🔴 em Crônicas. Se você demorar, a aldeia decide sozinha. O resumo completo do clã fica em Mais → Ajuda. Bom jogo!" },
];

// 📍 (28/09) O contador era "30/42": no meio da forja parecia que o guia não
// acabava nunca. Agora ele diz em que etapa você está e quanto falta DELA —
// "Etapa 3 de 4 · Forja · peça 2 de 4". Roteiro sem `cap` (o do clã, curto)
// segue no "3/7" de antes.
function rotuloDoGuia(passos, i) {
  if (!passos.some((x) => x.cap)) return `${i + 1}/${passos.length}`;
  const caps = [];
  passos.forEach((x, k) => { if (x.cap) caps.push(k); });
  let n = 0;
  while (n + 1 < caps.length && caps[n + 1] <= i) n++;
  const ini = caps[n], fim = n + 1 < caps.length ? caps[n + 1] : passos.length;
  const trecho = passos.slice(ini, fim);
  let texto = `Etapa ${n + 1} de ${caps.length} · ${passos[ini].cap}`;
  const pecas = trecho.filter((x) => x.peca).length;
  if (pecas) {
    const atual = passos.slice(ini, i + 1).filter((x) => x.peca).length;
    texto += ` · peça ${Math.max(1, atual)} de ${pecas}`;
  } else {
    texto += ` · ${i - ini + 1}/${fim - ini}`;
  }
  return texto;
}

function esperarAlvo(seletor, ms = 6000) {
  return new Promise((resolve) => {
    const ini = Date.now();
    const tick = () => {
      const alvo = seletor ? document.querySelector(seletor) : null;
      if (!seletor || (alvo && alvo.getBoundingClientRect().width > 0)) return resolve(alvo);
      if (Date.now() - ini > ms) return resolve(undefined);
      setTimeout(tick, 150);
    };
    tick();
  });
}

// 🔁 (28/09) O alvo guardado pode ter sido TROCADO pela tela: Atacar, Equipar
// e as abas da Mochila só redesenham quando o servidor responde. Com resposta
// acima de ~250 ms o guia agarrava o botão velho e bloqueava o toque no novo
// (igualzinho, no mesmo lugar) — o jogador ficava preso, só com "Pular".
// Medido em testes/testar_guia.js: travava a partir de 300 ms.
function alvoVivoDoGuia() {
  const g = GUIA_ATIVO;
  if (!g || !g.passo || !g.passo.alvo) return null;
  if (g.alvoEl && g.alvoEl.isConnected) return g.alvoEl;
  const novo = document.querySelector(g.passo.alvo);
  if (novo) g.alvoEl = novo;
  return novo;
}

function _bloqueioDoGuia(ev) {
  if (!GUIA_ATIVO) return;
  const dentroDoBalao = ev.target.closest && ev.target.closest(".guia-balao");
  if (dentroDoBalao) return;
  const vivo = GUIA_ATIVO.alvoEl ? alvoVivoDoGuia() : null;
  const dentroDoAlvo = vivo && vivo.contains(ev.target) && !GUIA_ATIVO.fechado;
  // botão de fechar folha (Continuar/Entendi) FORA do alvo passa: folha
  // aberta fora de hora cobria o destaque e o guia bloqueava o único jeito
  // de fechá-la.
  // 🐛 (28/09) Esta liberação vinha ANTES de conferir o alvo — e no passo
  // "Peça pronta!" o alvo É um .sheet-opcao (o Continuar da peça forjada). O
  // toque passava direto, a folha fechava, o guia nunca contava o toque e
  // ficava esperando um botão que não existia mais, bloqueando todo o resto:
  // a Forja do tutorial travava. Medido em testes/testar_guia_real.js.
  if (!dentroDoAlvo && ev.target.closest && ev.target.closest(".sheet-opcao")) return;
  if (dentroDoAlvo && !GUIA_ATIVO.passo.ok) {
    const g = GUIA_ATIVO, passo = g.passo;
    if (passo.aoTocar) {
      // o guia troca a ação do botão pela dele (a luta/fuga preparada)
      ev.preventDefault(); ev.stopPropagation();
      g.alvoEl = null;
      Promise.resolve(passo.aoTocar()).catch((e) => { if (!e.jaAlertado) toast(e.message, true); })
        .finally(() => setTimeout(() => avancarGuia(), 250));
      return;
    }
    if (passo.vezes && (g.toques = (g.toques || 0) + 1) < passo.vezes) {
      // ainda faltam toques: deixa este passar e redesenha no alvo novo
      setTimeout(async () => {
        const novo = await esperarAlvo(passo.alvo);
        // o passo pode ter fechado nesse meio-tempo (último toque veio rápido):
        // aí não pode reabrir o alvo, senão os toques extras passam
        if (novo && GUIA_ATIVO === g && g.passo === passo && !g.fechado) { g.alvoEl = novo; desenharPassoDoGuia(); }
      }, 250);
      return;
    }
    g.toques = 0;
    // o toque certo: deixa passar e avança logo depois.
    // 🔒 (28/09) e solta o alvo NA HORA: antes ele continuava valendo nesses
    // 250 ms, e um toque duplo (dedo nervoso) passava de novo — a ação rodava
    // duas vezes (Forjar duas vezes) e o guia avançava dois passos, pulando
    // o seguinte. Medido em testes/testar_guia.js ("toque duplo").
    g.alvoEl = null; g.fechado = true;
    setTimeout(() => avancarGuia(), 250);
    return;
  }
  ev.preventDefault(); ev.stopPropagation();
}

async function iniciarGuia(topico, passos, emCombate = false) {
  if (GUIA_ATIVO) return;
  let inicio = -1;
  try {
    const t = await api(`/api/tutorial/${topico}`);
    if (t.visto) return;
    // 🔁 (28/09) atualizou a página no meio: retoma no último marco (o
    // servidor junta o que foi gravado com o que o estado do jogo prova)
    const k = t.retomar ? passos.findIndex((x) => x.id === t.retomar) : -1;
    if (k > 0) inicio = k - 1;
    // em luta, só a luta DO GUIA retoma o guia (no passo do Atacar)
    if (emCombate && t.retomar !== "atacar") return;
  } catch (e) { return; }
  GUIA_ATIVO = { topico, passos, i: inicio, alvoEl: null, passo: null };
  document.addEventListener("click", _bloqueioDoGuia, true);
  // o destaque acompanha a tela quando ela redesenha sozinha (resposta do
  // servidor): sem isto a luz ficava no canto, sobre um botão que já saiu
  GUIA_ATIVO.relogio = setInterval(() => {
    const g = GUIA_ATIVO;
    if (!g || !g.alvoEl || g.alvoEl.isConnected) return;
    if (alvoVivoDoGuia()) desenharPassoDoGuia();
  }, 250);
  const camada = el("div", "guia-camada");
  camada.id = "guia-camada";
  document.body.appendChild(camada);
  await avancarGuia();
}

async function avancarGuia() {
  const g = GUIA_ATIVO;
  if (!g) return;
  g.i += 1;
  g.fechado = false;
  if (g.i >= g.passos.length) return encerrarGuia(true);
  const passo = g.passos[g.i];
  g.passo = passo;
  // marco gravado ao ENTRAR no trecho: atualizar a página a partir daqui
  // volta aqui. "atacar" não grava — só vale com a luta aberta, e isso o
  // servidor já sabe sozinho.
  if (g.topico === "guia_inicio" && passo.id && passo.id !== "atacar" && passo.id !== "inicio") {
    api("/api/guia/marco", { method: "POST", body: JSON.stringify({ marco: passo.id }) }).catch(() => {});
  }
  // enquanto o próximo destaque não aparece, só o fundo escuro (o balão
  // velho na tela parecia que o toque não tinha funcionado)
  const camada = document.getElementById("guia-camada");
  if (camada) { camada.innerHTML = ""; camada.appendChild(el("div", "guia-fundo")); }
  g.alvoEl = null;
  const alvo = await esperarAlvo(passo.alvo);
  if (passo.alvo && !alvo) return avancarGuia();          // alvo não apareceu: pula
  g.alvoEl = alvo || null;
  if (alvo) alvo.scrollIntoView({ block: "center", behavior: "smooth" });
  await sleep(alvo ? 320 : 0);
  desenharPassoDoGuia();
}

function desenharPassoDoGuia() {
  const g = GUIA_ATIVO;
  const camada = document.getElementById("guia-camada");
  if (!g || !camada) return;
  camada.innerHTML = "";
  const passo = g.passo;
  if (g.alvoEl) {
    const r = g.alvoEl.getBoundingClientRect();
    const luz = el("div", "guia-luz");
    Object.assign(luz.style, { left: `${r.left - 6}px`, top: `${r.top - 6}px`,
      width: `${r.width + 12}px`, height: `${r.height + 12}px` });
    camada.appendChild(luz);
  } else {
    camada.appendChild(el("div", "guia-fundo"));
  }
  const balao = el("div", "guia-balao");
  balao.appendChild(el("div", "guia-contador", rotuloDoGuia(g.passos, g.i)
    + (passo.vezes ? ` · toque ${(g.toques || 0) + 1} de ${passo.vezes}` : "")));
  balao.appendChild(el("div", "guia-titulo", passo.titulo));
  balao.appendChild(el("div", "guia-texto", passo.texto));
  const botoes = el("div", "guia-botoes");
  const pular = document.createElement("button");
  pular.className = "guia-pular"; pular.textContent = "Pular tutorial";
  // (28/09) um toque sem querer encerrava o guia pra sempre
  pular.onclick = () => {
    const extra = g.topico === "guia_inicio" ? " O material da forja continua com você." : "";
    if (confirm(`Pular o tutorial? Ele não aparece de novo — dá pra reler o básico em Mais → Ajuda.${extra}`)) encerrarGuia(true);
  };
  botoes.appendChild(pular);
  if (passo.ok || !g.alvoEl) {
    const ok = document.createElement("button");
    ok.className = "botao-holofote guia-ok";
    ok.textContent = passo.rotuloOk || (g.i === g.passos.length - 1 ? "Começar!" : "Entendi");
    ok.onclick = async () => {
      if (passo.aoOk) {
        // a ação do servidor roda ANTES de avançar: se falhar, o passo fica
        // na tela e dá pra tocar de novo (as duas rotas do guia não dobram nada)
        ok.disabled = true; ok.textContent = "Um instante...";
        try { await passo.aoOk(); }
        catch (e) { if (!e.jaAlertado) toast(e.message, true); ok.disabled = false; ok.textContent = passo.rotuloOk || "Tentar de novo"; return; }
      }
      avancarGuia();
    };
    botoes.appendChild(ok);
  } else {
    botoes.appendChild(el("div", "guia-dica", "👆 toque no destaque"));
  }
  balao.appendChild(botoes);
  // balão embaixo do alvo, ou em cima se o alvo está na metade de baixo
  if (g.alvoEl) {
    const r = g.alvoEl.getBoundingClientRect();
    if (r.top > window.innerHeight * 0.55) balao.style.bottom = `${window.innerHeight - r.top + 14}px`;
    else balao.style.top = `${r.bottom + 14}px`;
  }
  camada.appendChild(balao);
}

async function encerrarGuia(marcar) {
  const g = GUIA_ATIVO;
  GUIA_ATIVO = null;
  if (g && g.relogio) clearInterval(g.relogio);
  document.removeEventListener("click", _bloqueioDoGuia, true);
  const camada = document.getElementById("guia-camada");
  if (camada) camada.remove();
  if (g && marcar) {
    try { await api(`/api/tutorial/${g.topico}/visto`, { method: "POST" }); } catch (e) { /* sem rede: aparece de novo */ }
  }
}
window.addEventListener("resize", () => { if (GUIA_ATIVO) desenharPassoDoGuia(); });

async function talvezMostrarTutorial(tela) {
  const topico = TUTORIAL_DA_TELA[tela];
  if (GUIA_ATIVO) return;               // (26/09) o guia de clique tem a vez
  if (!topico || TUTORIAIS_JA_TENTADOS.has(topico)) return;
  // Marca a tentativa na hora: sem isto, trocar de tela rápido dispara a
  // mesma consulta várias vezes e o tutorial pisca duas vezes.
  TUTORIAIS_JA_TENTADOS.add(topico);
  try {
    const t = await api(`/api/tutorial/${topico}`);
    if (!t.visto) mostrarTutorial(t, true);
  } catch (e) { /* tutorial é acessório: nunca atrapalha entrar na tela */ }
}

function mostrarTutorial(t, marcarVisto) {
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", "📖 Como funciona"));
  const texto = el("div", "tutorial-texto");
  // Texto puro vindo da API; o \n vira quebra de linha aqui e nada mais é
  // interpretado — conteúdo do servidor não deve virar HTML no navegador.
  for (const linha of (t.texto || "").split("\n")) {
    if (linha.trim()) texto.appendChild(el("p", "tutorial-linha", linha.trim()));
  }
  corpo.appendChild(texto);

  const botao = document.createElement("button");
  botao.className = "botao-holofote sheet-opcao";
  botao.textContent = "Entendi";
  botao.onclick = async () => {
    fecharSheet();
    if (marcarVisto) {
      // Só marca depois do "Entendi". Marcar na abertura perderia o
      // tutorial de quem teve a conexão cair no meio — e ele só aparece
      // uma vez na vida.
      try { await api(`/api/tutorial/${t.topico}/visto`, { method: "POST" }); } catch (e) {}
    }
  };
  corpo.appendChild(botao);
  abrirSheet(corpo);
}

async function renderAjuda() {
  const c = document.getElementById("conteudo");
  mostrarEsqueleto();
  let d;
  try { d = await api("/api/tutoriais"); }
  catch (e) { c.innerHTML = ""; if (!e.jaAlertado) toast(e.message, true); return; }
  c.innerHTML = "";
  c.appendChild(el("h3", "secao-titulo", "📖 Ajuda"));
  c.appendChild(el("p", "texto-fraco", "Todos os guias do jogo. Pode reler quantas vezes quiser."));
  for (const t of d.tutoriais) {
    const linha = document.createElement("button");
    linha.className = "engaste-opcao";
    const titulo = (t.texto || "").split("\n")[0].trim() || t.topico;
    linha.append(el("span", "engaste-opcao-nome", titulo),
                 el("span", "engaste-opcao-bonus", t.visto ? "lido" : "novo"));
    linha.onclick = () => { som.clique(); mostrarTutorial(t, false); };
    c.appendChild(linha);
  }
}

// ---------- 📜 histórico de combate ----------
// O app só mostra o último lance. Quem tocava rápido demais perdia o que
// aconteceu, sem jeito de recuperar.
async function abrirHistoricoCombate() {
  som.clique();
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", "📜 Histórico da batalha"));
  const lista = el("div", "historico-combate");
  lista.appendChild(el("p", "texto-fraco", "Carregando..."));
  corpo.appendChild(lista);
  abrirSheet(corpo);

  try {
    const d = await api("/api/tower/historico");
    lista.innerHTML = "";
    if (!d.linhas.length) {
      lista.appendChild(el("p", "texto-fraco", "Nada aconteceu ainda nesta batalha."));
      return;
    }
    // Mais recente no topo: numa lista longa, o que interessa é o que
    // acabou de acontecer, não o começo da luta.
    for (const linha of [...d.linhas].reverse()) {
      lista.appendChild(el("p", "historico-linha", linha));
    }
    if (d.total > d.linhas.length) {
      lista.appendChild(el("p", "texto-fraco",
        `Mostrando os últimos ${d.linhas.length} de ${d.total} lances.`));
    }
  } catch (e) {
    lista.innerHTML = "";
    lista.appendChild(el("p", "texto-fraco", e.message || "Não consegui carregar."));
  }
}


// ---------- barra de abas ----------
// O Mestre do Futebol foi de 35 itens de menu pra 5 abas + gaveta de 11, e
// foi a mudança que mais mudou a sensação de usar. Aqui são 21 telas: as 5
// do laço principal viram aba, as outras 16 continuam na gaveta.
// Cinco é teto, não meta — acima disso o rótulo quebra em tela estreita.


function montarBarraAbas() {
  const barra = document.getElementById("barra-abas");
  if (!barra) return;
  for (const botao of barra.querySelectorAll(".aba-item")) {
    botao.onclick = () => {
      // O botão LEVA, não abre menu. Antes eram dois toques e uma leitura
      // pra chegar em qualquer lugar; agora o primeiro toque já põe você na
      // tela principal da seção, e os irmãos dela ficam no rodapé da página.
      const grupo = GRUPOS_MENU.find((g) => g.id === botao.dataset.grupo);
      if (!grupo || !grupo.telas.length) return;
      som.clique();
      irPara(grupo.telas[0].tela);
    };
  }
}

function atualizarBarraAbas() {
  const barra = document.getElementById("barra-abas");
  if (!barra) return;
  // Acende o GRUPO da tela atual. Assim a barra sempre diz em que parte do
  // jogo você está, mesmo em telas que não têm botão próprio.
  const grupoAtual = GRUPO_DA_TELA[TELA_ATUAL] || "mais";
  // 🎨 A seção também vai pro <body>: o CSS tinge a aba, a borda do topo,
  // a placa do andar e os títulos com a cor dela (--cor-secao).
  document.body.dataset.secao = grupoAtual;
  for (const botao of barra.querySelectorAll(".aba-item")) {
    botao.classList.toggle("ativa", botao.dataset.grupo === grupoAtual);
  }
}

// pulsar() foi removido em 11/09/2026, um dia depois de eu adicionar. O
// projeto já tinha animarNumero(), que faz melhor: conta até o valor novo,
// só anima quando MUDOU, e ainda mostra o delta flutuando (+250). Manter as
// duas seria o mesmo código morto que a varredura deste projeto vive achando.


// ---------- instalar como app (PWA) ----------
// Registra o service worker. Ele só guarda a casca — nunca resposta de API;
// ver o comentário no sw.js sobre por que dado de jogo em cache é pior que
// não abrir.
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch((e) => {
      // Falhar aqui não pode atrapalhar nada: sem service worker o jogo
      // funciona igual, só não instala na tela inicial.
      console.warn("service worker não registrou:", e);
    });
  });
}


// ===========================================================
// 🖼️ RETRATO DO JOGADOR E QUADROS DE DESTINO
// A tela de batalha já usava retrato redondo com a arte real. O resto do
// jogo usava emoji. Agora é a mesma linguagem em todo lugar, e o jogador é
// sempre representado pela arte de STATUS — a mesma da Ficha dele.
// ===========================================================
// 🧍 A arte do jogador. Começa no STATUS genérico e é trocada pela chave
// que o servidor resolve por raça e sexo assim que a ficha chega — a queda
// pra arte da raça e daí pro STATUS acontece lá, num lugar só.
let IMG_JOGADOR = "STATUS";

/** Retrato redondo com arte real. `chave` é a chave do asset; sem ela,
 *  cai no emoji — a arte pode não ter terminado de espelhar ainda, e uma
 *  bolinha vazia é pior que um símbolo. */
function retratoImagem(chave, emojiReserva, tamanho) {
  const bola = el("div", "retrato-img");
  if (tamanho) { bola.style.width = tamanho + "px"; bola.style.height = tamanho + "px"; }
  if (!chave) { bola.textContent = emojiReserva || "❓"; return bola; }
  // O retrato é pequeno: pedir 64 ou 128 em vez da arte cheia é a maior
  // economia de banda do jogo inteiro, porque retrato aparece em toda tela.
  const img = imagemDoJogo(chave, tamanho || 42,
    () => { img.remove(); bola.textContent = emojiReserva || "❓"; });
  bola.appendChild(img);
  return bola;
}

/** Põe uma imagem de fundo com as aspas que o CSS precisa.
 *  As aspas não são estilo: sem elas, qualquer URL com parêntese ou espaço
 *  fecha o url() antes da hora e a regra inteira vira lixo — sem erro no
 *  console, só o retrato vazio. */
function porFundo(elemento, url) {
  elemento.style.backgroundImage = `url("${String(url).replace(/"/g, '%22')}")`;
  elemento.textContent = "";
}

// 25/09/2026: a Praça (tela "cidade") saiu a pedido do dev. Ela era uma
// grade de atalhos pra telas que a barra de baixo já alcança, mais o botão
// da Recompensa diária — que foi morar na tela de Missões, junto das
// diárias do reino.

// ===========================================================
// 🧭 MENU EM 4 GRUPOS — o sanduíche saiu
// -----------------------------------------------------------
// Antes: uma gaveta com 21 itens de texto atrás de um ☰. Dois toques e uma
// leitura pra chegar em qualquer lugar, e nenhuma pista de onde as coisas
// moram.
//
// Agora os grupos são o próprio mapa do jogo, na ordem da barra:
//   1 MUNDO      tudo que acontece FORA da cidade, mais a Torre
//   2 CIDADE     os serviços do centro — e é o grupo que exige estar lá
//   3 PERSONAGEM você mesmo: ficha, mochila, trilhas
//   4 MAIS       o que não é nenhum dos três
//
// Cada botão abre uma folha com os quadros de arte, a mesma caixa da praça
// e da batalha. O agrupamento não é arrumação: é ele que torna o bloqueio
// da cidade legível, porque o grupo 2 é exatamente o que fica trancado.
// ===========================================================
const GRUPOS_MENU = [
  { id: "mundo", icone: "🗺️", rotulo: "Mundo", titulo: "Fora da cidade", telas: [
    { tela: "torre",       rotulo: "Torre",        sub: "100 andares" },
    { tela: "explorar",    rotulo: "Explorar",     sub: "Expedição de 7 dias" },
    { tela: "onda",        rotulo: "Onda",         sub: "5 chefes, sem fim" },
    { tela: "boss_global", rotulo: "Boss Global",  sub: "Todos contra um" },
    { tela: "raid",        rotulo: "Raid",         sub: "Grupo e traição" },
    { tela: "party",       rotulo: "Salas",        sub: "Entrar num grupo" },
    { tela: "arena",       rotulo: "Arena",        sub: "PvP semanal" },
    { tela: "arena_pets",  rotulo: "Arena Pets",   sub: "Espíritos em PvP" },
  ]},
  { id: "cidade", icone: "🏙️", rotulo: "Cidade", titulo: "Centro da cidade", telas: [
    { tela: "loja",          rotulo: "Loja",          sub: "Comprar e vender" },
    { tela: "loja_premium",  rotulo: "Loja Premium",  sub: "VIP, Autobatalha e ⭐" },
    { tela: "forja",    rotulo: "Forja",     sub: "Forjar equipamento" },
    { tela: "fusao",    rotulo: "Fusão Mítica", sub: "5 Lendários viram 1 Mítico" },
    { tela: "engaste",  rotulo: "Engaste",   sub: "Gemas nos itens" },
    { tela: "mercado",  rotulo: "Mercado",   sub: "Entre jogadores" },
    { tela: "gacha",    rotulo: "Templo",    sub: "Invocar espíritos" },
    { tela: "estabulo", rotulo: "Estábulo",  sub: "Invocar montarias" },
    { tela: "hospital", rotulo: "Hospital",  sub: "Curar a vida" },
  ]},
  { id: "personagem", icone: "🧙", rotulo: "Você", titulo: "Seu personagem", telas: [
    { tela: "personagem",    rotulo: "Ficha",     sub: "Status e equipamento" },
    { tela: "personagens",   rotulo: "Personagens", sub: "Trocar de personagem" },
    { tela: "inventario",    rotulo: "Mochila",   sub: "Itens e cores" },
    { tela: "skills",        rotulo: "Skills",    sub: "Aprender e equipar" },
    { tela: "pets",          rotulo: "Espíritos", sub: "Seu deck" },
    { tela: "trilhas",       rotulo: "Trilhas",       sub: "Distribuir pontos" },
    { tela: "especialidade", rotulo: "Especialidade", sub: "Equipar habilidades" },
  ]},
  // 🏰 O clã ganhou botão próprio. É o terceiro pilar: o que acontece
  // enquanto você não está, e as decisões que esperam você voltar. Enfiar
  // isso dentro de "Você" ou "Mais" enterraria justamente o conteúdo que
  // precisa ser a primeira coisa que o jogador vê ao abrir o jogo.
  { id: "clan", icone: "🏰", rotulo: "Clã", titulo: "Seu clã", telas: [
    { tela: "clan",           rotulo: "Resumo",     sub: "O que rolou e como o clã está" },
    { tela: "clan_postos",    rotulo: "Explorar andar", sub: "Buscar postos, pontos e rivais" },
    { tela: "clan_ferreiro",  rotulo: "Ferreiro",   sub: "Ferramentas e equipamento dos NPCs, em lote" },
    { tela: "clan_reliquias", rotulo: "Relíquias",  sub: "O que as equipes desenterram — 3 ativas" },
    { tela: "clan_historico", rotulo: "Histórico",  sub: "Sessões passadas e quem tombou" },
    { tela: "jornada",    rotulo: "Travessia",   sub: "Leve o clã pro próximo andar, lutando" },
    { tela: "situacoes",  rotulo: "Crônicas",    sub: "Histórias que esperam sua decisão" },
  ]},
  { id: "mais", icone: "⚙️", rotulo: "Mais", titulo: "Outros", telas: [
    { tela: "missoes", rotulo: "Missões", sub: "Recompensas do dia" },
    { tela: "ranking", rotulo: "Ranking", sub: "Quem está na frente" },
    { tela: "mercado_personagens", rotulo: "Mercado de personagens", sub: "Comprar e vender" },
    { tela: "ajuda",   rotulo: "Ajuda",   sub: "Todos os guias" },
    { tela: "conta",   rotulo: "Conta",   sub: "Senha e sair" },
  ]},
];

// De qual grupo é cada tela — usado pra acender o botão certo na barra.
const GRUPO_DA_TELA = Object.fromEntries(
  GRUPOS_MENU.flatMap((g) => g.telas.map((t) => [t.tela, g.id]))
);
GRUPO_DA_TELA.perfil_jogador = GRUPO_DA_TELA.ranking;   // o perfil "mora" junto do ranking
const TELAS_DA_CIDADE = new Set(GRUPOS_MENU.find((g) => g.id === "cidade").telas.map((t) => t.tela));

// A rota /api/auth/trocar-senha existia desde a migração e NENHUMA tela
// chegava nela. Sem e-mail de recuperação, não poder trocar a própria senha
// é beco sem saída: se ela vazar, só o admin resolve.
// ---------- 👥 personagens da conta ----------
// Última coisa grande que só existia no bot. É a base do clã: cada
// personagem num slot vai ser um membro, e o slot ativo é só quem você
// está pilotando na Torre.
async function renderPersonagens() {
  const c = document.getElementById("conteudo");
  mostrarEsqueleto();
  let d;
  try { d = await api("/api/personagens"); }
  catch (e) { c.innerHTML = ""; if (!e.jaAlertado) toast(e.message, true); return; }

  c.innerHTML = "";
  c.appendChild(el("h3", "secao-titulo", "👥 Personagens"));
  c.appendChild(el("p", "texto-fraco",
    `Você pilota um por vez. Os outros ficam no armário — e é deles que o clã vai ser feito. `
    + `${d.personagens.length} de ${d.max_extras + 1} slots usados.`));

  for (const pe of d.personagens) {
    const linha = document.createElement("button");
    linha.className = "linha-lista";
    const texto = el("div", "linha-lista-texto");
    texto.appendChild(el("div", "linha-lista-titulo", pe.nome));
    texto.appendChild(el("div", "linha-lista-sub",
      `Nível ${pe.level}` + (pe.ativo ? "  ·  pilotando agora" : "  ·  no armário")));
    // ✨ (28/09) quem nasceu de um aldeão desperto
    if (pe.origem) {
      texto.appendChild(el("div", "linha-lista-sub",
        `✨ Despertou na aldeia${pe.origem.profissao ? ` (era ${pe.origem.profissao})` : ""} · aura ${"★".repeat(pe.origem.aura || 0)}`));
    }
    linha.appendChild(texto);
    linha.appendChild(el("span", "linha-lista-seta", pe.ativo ? "◆" : "›"));
    if (pe.ativo) {
      linha.classList.add("trancado");
      linha.onclick = () => toast("Este é o personagem que você está pilotando.");
      c.appendChild(linha);
    } else {
      linha.onclick = () => trocarPersonagem(pe);
      // 🧍 25/09/2026: o Mercado de personagens tinha comprar e cancelar,
      // mas NENHUMA tela chamava /api/personagens/anunciar — o mercado nunca
      // recebia anúncio. Vender é daqui, porque é aqui que o armário aparece.
      // (o servidor recusa o que está ao vivo, então só os do armário.)
      const fila = el("div", "linha-personagem");
      const vender = document.createElement("button");
      vender.className = "botao-secundario linha-personagem-vender";
      vender.textContent = "Vender";
      vender.onclick = () => anunciarPersonagem(pe);
      // ⚔️ (28/09, dev) treino de cavaleiro: o motivo aparece quando não dá
      const cav = document.createElement("button");
      cav.className = "botao-secundario linha-personagem-vender" + (pe.cavaleiro?.pode ? "" : " trancado");
      cav.textContent = "⚔️ Cavaleiro";
      cav.onclick = () => pe.cavaleiro?.pode ? treinarCavaleiro(pe, d.regras_cavaleiro)
                                              : toast(pe.cavaleiro?.motivo || "Não dá agora.", true);
      fila.append(linha, cav, vender);
      c.appendChild(fila);
    }
  }

  if (d.livres.length) {
    const criar = document.createElement("button");
    criar.className = "botao-holofote";
    criar.style.cssText = "width:100%;margin-top:14px";
    criar.textContent = `Criar personagem (${d.livres.length} slot(s) livre(s))`;
    criar.onclick = async () => {
      criar.disabled = true;
      try {
        const r = await api("/api/personagens/criar", { method: "POST" });
        (r.ok ? som.moeda : som.erro)();
        toast(r.msg.replace(/<[^>]+>/g, ""), !r.ok);
        await renderPersonagens();
      } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); criar.disabled = false; }
    };
    c.appendChild(criar);
  }
}

async function treinarCavaleiro(pe, regras) {
  const r = regras || {};
  const custo = r.custo || {};
  if (!confirm(
    `Treinar ${pe.nome} (nível ${pe.level}) como cavaleiro do clã?\n\n`
    + `Ele larga a Torre PARA SEMPRE: sai dos seus personagens, com o equipamento e as skills dele, `
    + `e vira cavaleiro do clã: rende 10× o melhor guarda (5★) do mesmo nível `
    + `e vale 10 guardas na defesa da aldeia.\n\n`
    + `Como usa aura, mora na cidade do reino — não ocupa casa nem come da aldeia — e recebe soldo em ouro: `
    + `${r.soldo_dia || 500} por dia, pago adiantado. Sem soldo ele não luta.\n\n`
    + `O treino custa ${custo.ferro || 0} de ferro e ${custo.couro || 0} de couro do clã, `
    + `mais ${r.ouro || 0} de ouro (a 1ª semana de soldo), e leva ${r.horas || 12}h.`
  )) return;
  try {
    const resp = await api("/api/personagens/cavaleiro", { method: "POST", body: JSON.stringify({ slot: pe.slot }) });
    som.moeda();
    if (resp.gold != null) atualizarTopo({ gold: resp.gold });
    notificacaoGrande("⚔️", pe.nome, "Em treino de cavaleiro — depois vai pra guarnição da cidade");
    toast(String(resp.texto || "").replace(/<[^>]+>/g, ""));
    await renderPersonagens();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function anunciarPersonagem(pe) {
  const resposta = prompt(
    `Vender ${pe.nome} (nível ${pe.level}) no Mercado de personagens.\n\n`
    + "Preço em ⭐ estrelas (quem comprar paga direto pra você). "
    + "Enquanto estiver anunciado, ele sai do seu armário — cancelar traz de volta.");
  if (resposta === null) return;
  const preco = parseInt(String(resposta).replace(/\D/g, ""), 10);
  if (!preco || preco < 1) { som.erro(); toast("Preço inválido — use um número de estrelas.", true); return; }
  try {
    const r = await api("/api/personagens/anunciar", {
      method: "POST", body: JSON.stringify({ slot: pe.slot, preco }) });
    (r.ok ? som.moeda : som.erro)();
    toast(r.msg.replace(/<[^>]+>/g, ""), !r.ok);
    if (r.ok) await renderPersonagens();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function trocarPersonagem(pe) {
  // A troca move o save vivo pro armário e traz outro. É a operação mais
  // destrutiva do jogo, então confirma nomeando quem sai e quem entra —
  // "tem certeza?" sozinho não diz o que se perde de vista.
  if (!confirm(
    `Guardar o personagem atual e pilotar ${pe.nome} (nível ${pe.level})?\n\n`
    + "O atual vai para o armário com tudo que tem. Nada é perdido, mas você "
    + "deixa de jogar com ele até trocar de volta."
  )) return;
  try {
    const r = await api("/api/personagens/trocar", {
      method: "POST", body: JSON.stringify({ slot: pe.slot }) });
    if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
    som.moeda();
    toast(r.msg.replace(/<[^>]+>/g, ""));
    // Recarrega inteiro: mudou o personagem, mudou tudo — topo, ficha,
    // mochila. Redesenhar só esta tela deixaria o resto mentindo.
    location.reload();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function renderMercadoPersonagens() {
  const c = document.getElementById("conteudo");
  mostrarEsqueleto();
  let d;
  try { d = await api("/api/personagens/mercado"); }
  catch (e) { c.innerHTML = ""; if (!e.jaAlertado) toast(e.message, true); return; }

  c.innerHTML = "";
  c.appendChild(el("h3", "secao-titulo", "🧍 Mercado de personagens"));

  // Os seus aparecem em "Seus anúncios"; na lista de compra só
  // davam erro ("não pode comprar seu próprio personagem").
  const meus = new Set((d.minhas || []).map((x) => x.id));
  const aVenda = d.mercado.filter((it) => !meus.has(it.id));
  if (!aVenda.length) {
    c.appendChild(estadoVazio("🧍",
      "Ninguém mais vendendo personagem agora. Pra vender um seu, vá em "
      + "Personagens e toque em Vender num que esteja no armário."));
  }
  for (const it of aVenda) {
    const linha = document.createElement("button");
    linha.className = "linha-lista";
    const texto = el("div", "linha-lista-texto");
    texto.appendChild(el("div", "linha-lista-titulo", `${it.nome || "Personagem"} — ${it.price}⭐`));
    texto.appendChild(el("div", "linha-lista-sub", `Nível ${it.nivel ?? "?"}`));
    linha.appendChild(texto);
    linha.appendChild(el("span", "linha-lista-seta", "›"));
    linha.onclick = async () => {
      if (!confirm(`Comprar ${it.nome || "este personagem"} por ${it.price}⭐?`)) return;
      try {
        const r = await api("/api/personagens/comprar", {
          method: "POST", body: JSON.stringify({ id: it.id }) });
        (r.ok ? som.moeda : som.erro)();
        toast(r.msg.replace(/<[^>]+>/g, ""), !r.ok);
        await renderMercadoPersonagens();
      } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    };
    c.appendChild(linha);
  }

  if (d.minhas.length) {
    c.appendChild(el("h3", "secao-titulo", "Seus anúncios"));
    for (const it of d.minhas) {
      const linha = document.createElement("button");
      linha.className = "linha-lista";
      const texto = el("div", "linha-lista-texto");
      texto.appendChild(el("div", "linha-lista-titulo", `${it.nome || "Personagem"} — ${it.price}⭐`));
      texto.appendChild(el("div", "linha-lista-sub", "toque para cancelar o anúncio"));
      linha.appendChild(texto);
      linha.appendChild(el("span", "linha-lista-seta", "✕"));
      linha.onclick = async () => {
        try {
          const r = await api("/api/personagens/cancelar", {
            method: "POST", body: JSON.stringify({ id: it.id }) });
          (r.ok ? som.clique : som.erro)();
          toast(r.msg.replace(/<[^>]+>/g, ""), !r.ok);
          await renderMercadoPersonagens();
        } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
      };
      c.appendChild(linha);
    }
  }
}


// ---------- 🔑 trocar a senha ----------
// ---------- 🏰 clã ----------
// O pilar idle. O mapa é a própria Torre: cada andar é uma área, e você só
// manda gente pros andares que já ficaram atrás de você.
const COR_RANK = { comum:"#9a94ab", incomum:"#7fd67f", raro:"#4fc3c8",
                   epico:"#b18cf0", lendario:"#e8b64a" };

// ---------- 🏘️ aldeia ----------
// 🥇 20/09/2026: a aldeia tinha moeda própria (bronze e prata) pra não virar
// outro bolso do personagem. O dev decidiu por uma economia só: tudo aqui
// custa o OURO do personagem, o mesmo da Torre. Ver `abrirAldeia`.
// ---------- 📜 decisões (o storylet do clã) ----------
// Copiado do Six Ages: o conselho opina ANTES, com viés, e a perícia de
// quem executa é o que rola no teste. Seguir o conselho de alguém é apostar
// em duas coisas — que ele está certo, e que ele dá conta.
let DECISAO_EXECUTOR = null;

// 📖 26/09/2026: CRÔNICAS — o sistema novo de storylets (game/cronicas.py).
// A tela "Decisões" virou a fila das Crônicas: cada uma com o que custa, a
// chance de dar certo, e quantas sessões faltam pra aldeia decidir sozinha.
async function renderSituacoes() {
  const c = document.getElementById("conteudo");
  mostrarEsqueleto();
  let d;
  try { d = await api("/api/clan/cronicas"); }
  catch (e) { c.innerHTML = ""; if (!e.jaAlertado) toast(e.message, true); return; }
  c.innerHTML = "";
  c.appendChild(el("h3", "secao-titulo", "📖 Crônicas"));
  for (const g of d.guerras || []) {
    c.appendChild(el("div", "cronica-guerra",
      `⚔️ Em guerra com ${g.cla} — a cidade é atacada com mais frequência (mais ${textoDeHoras(g.restam_horas)})`));
  }
  if (!d.fila.length) {
    c.appendChild(estadoVazio("📖",
      "Nenhuma história esperando. As crônicas nascem do que acontece: equipes que voltam, "
      + "ataques, a Torre, gente que chega. Volte depois de uma sessão."));
  }
  for (const cr of d.fila) c.appendChild(cartaoDaCronica(cr));
  if ((d.historico || []).length) {
    c.appendChild(el("h3", "secao-titulo", "O que já aconteceu"));
    for (const h of d.historico) {
      const linha = el("div", "cronica-historico");
      linha.appendChild(el("div", "", h.texto));
      for (const det of h.detalhes || []) linha.appendChild(el("div", "texto-fraco", det));
      c.appendChild(linha);
    }
  }
}

/** 🖼️ (26/09) arte da crônica (CRONICA_<ID>), se já foi enviada pelo
 *  /admin; sem arte, a imagem some e o cartão fica só com o texto. */
function arteDaCronica(chave) {
  const moldura = el("div", "cronica-arte");
  const img = imagemDoJogo(chave, 480, () => moldura.remove());
  moldura.appendChild(img);
  return moldura;
}

/** "~5 h" / "~1 dia e 6 h" — prazos das Crônicas (6 h de relógio por sessão). */
function textoDeHoras(h) {
  const horas = Math.max(0, Number(h) || 0);
  if (horas < 1) return "menos de 1 h";
  if (horas < 24) return `~${horas} h`;
  const d = Math.floor(horas / 24), r = horas % 24;
  return `~${d} dia${d > 1 ? "s" : ""}${r ? ` e ${r} h` : ""}`;
}

function cartaoDaCronica(cr) {
  const card = el("div", "cronica" + (cr.fundacao ? " fundacao" : ""));
  if (cr.img_key) card.appendChild(arteDaCronica(cr.img_key));
  card.appendChild(el("div", "cronica-titulo", `${cr.icone} ${cr.titulo}`));
  card.appendChild(el("p", "cronica-texto", cr.texto));
  if (!cr.fundacao) {
    card.appendChild(el("div", "cronica-prazo",
      `⏳ ${textoDeHoras(cr.restam_horas)} pra decidir — senão a aldeia escolhe: “${cr.padrao}”`));
  }
  for (const op of cr.opcoes) {
    const b = document.createElement("button");
    b.className = "botao-secundario cronica-opcao";
    b.disabled = !op.disponivel;
    b.appendChild(el("div", "cronica-opcao-texto", op.texto));
    const extras = [];
    if (op.custos && op.custos.length) extras.push(op.custos.join(" · "));
    if (op.chance != null) extras.push(`🎲 ${op.chance}% de dar certo`);
    if (!op.disponivel && op.motivo) extras.push(`🔒 ${op.motivo}`);
    if (extras.length) b.appendChild(el("div", "cronica-opcao-extra", extras.join("  ·  ")));
    b.onclick = () => decidirCronica(cr.uid, op.indice, b);
    card.appendChild(b);
  }
  return card;
}

async function decidirCronica(uid, opcao, botao) {
  botao.disabled = true;
  try {
    const r = await api("/api/clan/cronicas", { method: "POST", body: JSON.stringify({ uid, opcao }) });
    if (r.sucesso === false) som.erro(); else som.moeda();
    const corpo = el("div");
    corpo.appendChild(el("h3", "secao-titulo", r.titulo));
    corpo.appendChild(el("p", "", `${r.escolha}${r.sucesso === true ? " — deu certo!" : r.sucesso === false ? " — deu errado." : ""}`));
    for (const l of r.linhas || []) corpo.appendChild(el("div", "cronica-resultado", l));
    abrirSheet(corpo);
    await renderSituacoes();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); botao.disabled = false; }
}

// 🧹 26/09/2026: decidir() e a página da Saga saíram com o sistema antigo
// de decisões. O que aconteceu fica no fim da página das Crônicas.


// 🥇 20/09/2026: a Aldeia usava bronze/prata, moeda própria do clã. Saiu —
// agora tudo aqui custa o OURO do personagem (`d.gold`, o mesmo que a
// Torre já dá), e "vender material" saiu junto: material virou ingrediente
// da Forja (ver Forja) e do equipamento do clã, não sobra mais o que vender.
// 25/09/2026: era uma folha aberta pelo botão "Aldeia"; agora desenha
// DENTRO do Resumo (`destino`). Sem destino, ainda abre como folha.
async function abrirAldeia(destino) {
  const inline = destino instanceof Element;
  if (!inline) som.clique();
  const corpo = inline ? destino : el("div");
  corpo.appendChild(el("h3", "secao-titulo", "🏘️ Comércio da aldeia"));
  const carregando = el("p", "texto-fraco", "Carregando...");
  corpo.appendChild(carregando);
  if (!inline) abrirSheet(corpo);

  let d;
  try { d = await api("/api/clan/aldeia"); }
  catch (e) { carregando.textContent = e.message || "Não consegui carregar."; return; }
  carregando.remove();

  if (!inline) {   // no Resumo o ouro já está nos recursos, logo acima
    const saldo = el("div", "clan-recursos");
    saldo.appendChild(fichaRecurso("💰", "Ouro", d.gold.toLocaleString("pt-BR"), "var(--ouro)"));
    corpo.appendChild(saldo);
  }

  for (const [chave, s] of Object.entries(d.servicos)) {
    const preco = `${s.ouro}g`;
    const jaContratada = chave === "mao_de_obra" && d.mao_de_obra_pendente > 0;
    const pode = d.gold >= s.ouro && !jaContratada;
    const linha = document.createElement("button");
    linha.className = "linha-lista" + (pode ? "" : " trancado");
    const texto = el("div", "linha-lista-texto");
    texto.appendChild(el("div", "linha-lista-titulo", `${s.nome} — ${preco}`));
    // A razão vai na tela. Serviço sem motivo claro é moeda parada.
    texto.appendChild(el("div", "linha-lista-sub",
      jaContratada ? "✅ Contratada — vale na próxima construção." : s.porque));
    linha.appendChild(texto);
    linha.appendChild(el("span", "linha-lista-seta", pode ? "›" : (jaContratada ? "✅" : "🔒")));
    linha.onclick = async () => {
      if (jaContratada) { toast("Já contratada: vale na próxima construção."); return; }
      if (!pode) { toast(`Falta ouro: custa ${preco}.`, true); return; }
      try {
        const r = await api("/api/clan/aldeia/servico", {
          method: "POST", body: JSON.stringify({ servico: chave }) });
        som.moeda(); toast(r.msg); fecharSheet(); await recarregarClan();
      } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    };
    corpo.appendChild(linha);
  }

  // 🌾 Comprar comida com ouro. Preços fixos de propósito — 4 botões batem
  // de primeira, um campo de texto pediria teclado no celular pra uma
  // decisão que é só "quanto dessa vez".
  corpo.appendChild(el("h3", "secao-titulo", "🌾 Comprar comida"));
  corpo.appendChild(el("p", "texto-fraco",
    `${d.comida}/${d.teto_comida} no celeiro · ${d.custo_comida_unidade}g por unidade. `
    + "Farmar continua de graça — isto é pra socorrer uma sessão ruim."));
  const opcoesComida = el("div", "habitante-acoes");
  for (const qtd of [50, 150, 300]) {
    const b = document.createElement("button");
    b.className = "botao-secundario";
    const custo = qtd * d.custo_comida_unidade;
    b.textContent = `+${qtd} (${custo}g)`;
    b.disabled = d.gold < custo || d.comida >= d.teto_comida;
    b.onclick = async () => {
      try {
        const r = await api("/api/clan/aldeia/comprar_comida", {
          method: "POST", body: JSON.stringify({ quantidade: qtd }) });
        som.moeda(); toast(r.msg); fecharSheet(); await recarregarClan();
      } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    };
    opcoesComida.appendChild(b);
  }
  corpo.appendChild(opcoesComida);

  // 🛒 Outras aldeias vendem o resto da manutenção — é a saída da greve.
  if (d.precos_outras_aldeias) {
    corpo.appendChild(el("h3", "secao-titulo", "🛒 Comprar de outras aldeias"));
    for (const recurso of ["madeira", "couro", "ferro"]) {
      const preco = d.precos_outras_aldeias[recurso];
      const tem = (d.estoque || {})[recurso] ?? 0;
      corpo.appendChild(el("div", "habitante-sub",
        `${ICONE_RECURSO_EQUIPE[recurso]} ${recurso}: você tem ${tem} · ${preco}g cada`));
      const linha = el("div", "habitante-acoes");
      for (const qtd of [10, 50]) {
        const b = document.createElement("button");
        b.className = "botao-secundario";
        b.textContent = `+${qtd} (${qtd * preco}g)`;
        b.disabled = d.gold < qtd * preco;
        b.onclick = async () => {
          try {
            const r = await api("/api/clan/aldeia/comprar", { method: "POST",
              body: JSON.stringify({ recurso, quantidade: qtd }) });
            som.moeda(); toast(r.msg); fecharSheet(); await recarregarClan();
          } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
        };
        linha.appendChild(b);
      }
      corpo.appendChild(linha);
    }
  }

  // 🔁 Compra automática: mesma automação do descanso, agora pra comida.
  // Só dispara quando a sessão de AFK termina com gente faminta, e nunca
  // gasta mais que o limite numa sessão — a regra em si já existia pro
  // descanso, aqui é a mesma ideia com um teto de ouro.
  const bAuto = document.createElement("button");
  const ligado = !!d.regras_comida_auto;
  bAuto.className = ligado ? "botao-holofote" : "botao-secundario";
  bAuto.style.cssText = "width:100%;margin-top:8px";
  bAuto.textContent = ligado
    ? `🔁 Compra automática LIGADA (até ${d.regras_limite_comida}g por sessão)`
    : "🔁 Ligar compra automática de comida";
  bAuto.onclick = async () => {
    try {
      await api("/api/clan/regras", {
        method: "POST", body: JSON.stringify({ compra_comida_auto: !ligado }) });
      som.clique(); fecharSheet(); await recarregarClan();
    } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
  };
  corpo.appendChild(bAuto);

  // 🛒 (26/09) a mesma coisa pros materiais: madeira, couro e ferro
  const bMat = document.createElement("button");
  const ligadoMat = !!d.regras_materiais_auto;
  bMat.className = ligadoMat ? "botao-holofote" : "botao-secundario";
  bMat.style.cssText = "width:100%;margin-top:8px";
  bMat.textContent = ligadoMat
    ? `🔁 Compra automática de materiais LIGADA (até ${d.regras_limite_materiais}g por sessão)`
    : "🔁 Ligar compra automática de madeira, couro e ferro";
  bMat.onclick = async () => {
    try {
      await api("/api/clan/regras", {
        method: "POST", body: JSON.stringify({ compra_materiais_auto: !ligadoMat }) });
      som.clique(); fecharSheet(); await recarregarClan();
    } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
  };
  corpo.appendChild(bMat);
  corpo.appendChild(el("p", "texto-fraco",
    "Compra no fim de cada sessão o que não cobre a manutenção da próxima (até duas sessões)."));

  // Material: só informativo agora — não vende mais. A Forja é pra onde
  // ele serve.
  if (d.materiais.some((m) => m.qtd > 0)) {
    corpo.appendChild(el("h3", "secao-titulo", "⛏️ Material do clã"));
    corpo.appendChild(el("p", "texto-fraco",
      "Usado na Forja (peças pessoais) e no equipamento do clã. Não se vende mais."));
    for (const m of d.materiais.filter((x) => x.qtd > 0)) {
      corpo.appendChild(el("div", "habitante-sub", `${m.nome} (rank ${m.rank}): ${m.qtd}`));
    }
  }
}


function faixaHumor(v) {
  if (v < 20) return "motim";
  if (v < 40) return "inquieto";
  if (v < 60) return "resignado";
  if (v < 80) return "confiante";
  return "festa";
}

// 25/09/2026: a página da Fundação saiu (pedido do dev). O clã que nunca
// fundou recebe o que ela dava automaticamente, na rota /api/clan.

async function renderJornada() {
  const c = document.getElementById("conteudo");
  mostrarEsqueleto();
  let d;
  try { d = await api("/api/clan/jornada"); }
  catch (e) { c.innerHTML = ""; if (!e.jaAlertado) toast(e.message, true); return; }
  desenharJornada(d);
}

function barraDeVida(atual, max, classe) {
  const tr = el("div", "barra-trilho mini");
  const pr = el("div", `barra-preenchimento ${classe || "barra-hp"}`);
  pr.style.width = `${Math.max(0, Math.min(100, (atual / Math.max(1, max)) * 100))}%`;
  tr.appendChild(pr);
  return tr;
}

async function acaoDaTravessia(corpo) {
  try {
    const r = await api("/api/clan/jornada/acao", { method: "POST", body: JSON.stringify(corpo) });
    if (r.final) desenharJornada({ jornada: r.jornada }, r.final);
    else desenharJornada(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

function desenharJornada(d, final) {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  const t = d.jornada;

  if (final) {
    const titulo = { sucesso: `🏁 O clã chegou ao Andar ${final.destino}!`,
      recuou: "↩️ O clã voltou", fracasso: "💀 Todos caíram" }[final.fim] || "Fim";
    const caixa = el("div", "aldeia-box");
    caixa.appendChild(el("div", "aldeia-estagio", titulo));
    caixa.appendChild(el("p", "texto-fraco",
      `${final.batalhas} batalha(s) vencida(s) · ${final.abatidos} abatido(s) · ${final.reforcos} reforço(s) inimigo(s).`));
    const mat = Object.entries(final.material || {}).map(([r, q]) => `${q} de rank ${r}`);
    const partes = [...mat];
    if (final.couro) partes.push(`${final.couro} de couro`);
    if (final.comida_volta) partes.push(`${final.comida_volta} de comida de volta`);
    caixa.appendChild(el("p", "texto-fraco", partes.length ? `Trouxeram ${partes.join(", ")}.` : "Não trouxeram nada."));
    const feridas = Object.values(final.ferimentos || {}).reduce((a, b) => a + b, 0);
    if (feridas) caixa.appendChild(el("p", "texto-fraco", `🩸 ${feridas} ponto(s) de ferimento no grupo.`));
    if (final.posto_revelado) {
      caixa.appendChild(el("p", "texto-fraco", `🔎 Ao chegar, acharam um posto: ${final.posto_revelado.nome}.`));
    }
    if (final.fim === "sucesso") { som.vitoria(); }
    if (final.gold !== undefined) atualizarTopo({ gold: final.gold });
    c.appendChild(caixa);
    const b = document.createElement("button");
    b.className = "botao-holofote"; b.textContent = "Voltar";
    b.onclick = () => renderJornada();
    c.appendChild(b);
    return;
  }

  if (!t) {
    c.appendChild(tituloDaLuta("Travessia", `o clã está no Andar ${d.andar_do_cla}`));
    if (!d.destino) {
      c.appendChild(el("p", "texto-fraco",
        `A travessia é sempre pro andar seguinte, e só pra onde você já chegou na Torre. ` +
        `Chegue ao Andar ${d.andar_do_cla + 1} (você está no ${d.andar_max}) pra levar o clã até lá.`));
      return;
    }
    const cartao = el("div", "ponto-mapa");
    cartao.appendChild(el("div", "habitante-nome",
      `🧭 Andar ${d.andar_do_cla} → Andar ${d.destino}${d.chefe ? " 👹" : ""}`));
    cartao.appendChild(el("div", "habitante-sub",
      `${d.tempo} turnos de travessia · cada batalha: vença em ${d.limite} turnos ou chega reforço` +
      (d.chefe ? " · o chefe do andar entra no fim" : "")));
    cartao.appendChild(el("div", "habitante-sub",
      `${d.lutadores.length} lutador(es) · no ponto pra este andar: nível ${d.nivel_referencia}`));
    c.appendChild(cartao);
    if (d.em_posto) {
      c.appendChild(el("p", "texto-fraco", `⚠️ ${d.em_posto} lutador(es) em posto — recolha antes de partir.`));
    }
    const levar = Math.min(d.comida_max, d.comida);
    const b = document.createElement("button");
    b.className = "botao-holofote";
    b.style.cssText = "width:100%;margin-top:8px";
    b.textContent = `🧭 Partir levando ${levar} de comida`;
    b.disabled = levar < d.comida_min || d.em_posto > 0;
    b.onclick = async () => {
      if (!confirm(`Atravessar até o Andar ${d.destino} com ${levar} de comida?`)) return;
      try {
        const r = await api("/api/clan/jornada/partir", { method: "POST", body: JSON.stringify({ comida: levar }) });
        som.clique(); desenharJornada(r);
      } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    };
    c.appendChild(b);
    c.appendChild(el("p", "texto-fraco",
      `Rações: ${d.comida_min} · o resto vai de reserva pra comer no meio da luta (até ${d.comida_max}).`));
    return;
  }

  c.appendChild(tituloDaLuta(`Andar ${t.origem} → ${t.destino}`, `turno ${t.turno}/${t.tempo}`));
  c.appendChild(barraDeVida(t.turno, t.tempo, "barra-atb"));

  const estado = el("div", "clan-recursos");
  estado.appendChild(fichaRecurso("🍖", "Comida", t.comida));
  estado.appendChild(fichaRecurso("✅", "Vencidas", t.batalhas_vencidas));
  estado.appendChild(fichaRecurso("📯", "Reforços", t.reforcos));
  estado.appendChild(fichaRecurso("🐂", "Couro", t.espolio_couro ?? 0));
  c.appendChild(estado);

  // a batalha da vez
  const batalha = el("div", "decisao-cena");
  if (t.inimigos.length) {
    const resta = Math.max(0, t.limite - t.turno_da_batalha);
    batalha.appendChild(el("div", "aldeia-estagio",
      `⚔️ Batalha ${t.batalhas_vencidas + 1} — vença em ${resta} turno(s) ou chega reforço`));
    for (const e of t.inimigos) {
      const linha = el("div", "habitante-sub", `${e.tipo === "boss" ? "👹" : e.tipo === "normal" ? "👾" : "💀"} ${e.nome}`);
      batalha.appendChild(linha);
      batalha.appendChild(barraDeVida(e.hp, e.hp_max, "barra-hp inimigo"));
    }
  } else {
    batalha.appendChild(el("div", "aldeia-estagio", "🌫️ Um respiro no caminho..."));
  }
  c.appendChild(batalha);

  const grupo = el("div", "fileira-inimigos banco-pets");
  for (const m of t.grupo) {
    const f = el("div", `banco-pet${m.hp <= 0 ? " morto" : ""}`);
    f.appendChild(el("div", "banco-pet-arte", m.hp <= 0 ? "🩸" : "🧍"));
    f.appendChild(barraDeVida(m.hp, m.hp_max));
    f.title = `${m.nome} — ${m.hp}/${m.hp_max}`;
    grupo.appendChild(f);
  }
  c.appendChild(grupo);

  // tática: muda na hora, vale do próximo turno em diante
  const chips = el("div", "habitante-acoes");
  for (const [id, nome] of Object.entries(t.taticas)) {
    const b = document.createElement("button");
    b.className = t.tatica === id ? "botao-holofote" : "botao-secundario";
    b.textContent = nome;
    b.onclick = () => acaoDaTravessia({ acao: "tatica", tatica: id });
    chips.appendChild(b);
  }
  c.appendChild(chips);

  const acoes = el("div", "combate-acoes acoes-pet");
  const botoes = [
    ["▶️ 1 turno", { acao: "avancar" }, "botao-secundario"],
    ["⏩ Seguir", { acao: "seguir" }, "botao-holofote"],
    [`🍖 Comer (−${t.custo_comer})`, { acao: "comer" }, "botao-secundario"],
  ];
  for (const [rotulo, corpo, classe] of botoes) {
    const b = document.createElement("button");
    b.className = `${classe} acao-pet`;
    b.textContent = rotulo;
    if (corpo.acao === "comer") b.disabled = t.comida < t.custo_comer;
    b.onclick = () => acaoDaTravessia(corpo);
    acoes.appendChild(b);
  }
  c.appendChild(acoes);

  const volta = document.createElement("button");
  volta.className = "botao-secundario";
  volta.style.cssText = "width:100%;margin-top:10px";
  volta.textContent = "↩️ Recuar (metade do espólio)";
  volta.onclick = () => { if (confirm("Voltar pro andar de onde saíram? Traz metade do espólio.")) acaoDaTravessia({ acao: "recuar" }); };
  c.appendChild(volta);

  const diario = el("div", "clan-diario");
  for (const linha of (t.log || []).slice().reverse()) diario.appendChild(el("div", "clan-diario-linha", linha));
  c.appendChild(diario);
}

// 25/09/2026: a página do Território saiu (pedido do dev). Os pontos do
// mapa continuam aparecendo nos achados de "Explorar andar", que é por onde
// o clã marcha até eles; as rotas /api/clan/territorio* seguem no servidor.

// 📑 Páginas do clã. 25/09/2026 (dev): as abas de CIMA saíram — o clã usa
// a mesma navegação de todo o jogo, a grade de caminhos no fim da página.

async function carregarPaginaDoClan(tela) {
  const c = document.getElementById("conteudo");
  mostrarEsqueleto();
  let d;
  try { d = await api("/api/clan"); }
  catch (e) { c.innerHTML = ""; if (!e.jaAlertado) toast(e.message, true); return null; }
  CLAN_CACHE = d;
  if (d.bloqueado) {
    // 🔒 (26/09) o clã só existe depois da fundação, ao subir pro 2º andar
    c.innerHTML = "";
    const box = el("div", "aldeia-box clan-bloqueado");
    box.appendChild(el("div", "em-construcao-icone", "🔒"));
    box.appendChild(el("div", "aldeia-estagio", "O clã ainda não existe"));
    box.appendChild(el("p", "texto-fraco",
      "Ele nasce quando você achar o portal do 1º andar e tentar subir pro 2º. "
      + "Explore a Torre até o portal aparecer."));
    const ir = document.createElement("button");
    ir.className = "botao-holofote"; ir.style.cssText = "width:100%;margin-top:10px";
    ir.textContent = "🗼 Ir pra Torre";
    ir.onclick = () => irPara("torre");
    box.appendChild(ir);
    c.appendChild(box);
    return null;
  }
  // Sem passado, o clã nem abre. A fundação é a primeira coisa — depois
  // dela não dá pra voltar, então ela não pode ser pulável.
  c.innerHTML = "";
  // 🎁 (28/09) sessão AFK segurada: o banner de receber abre a página
  if (d.recompensa_pendente) c.appendChild(bannerDeRecompensaDoCla(d.recompensa_pendente));
  // aviso de quem voltou do posto: vale em qualquer página
  if (d.recolhidos && d.recolhidos.length) {
    toast(`${d.recolhidos.join(", ")} voltou do posto: o clã ainda não chegou àquele andar.`);
  }
  return { c, d };
}

// Depois de uma ação (explorar, pôr no posto, construir, serviço da aldeia)
// a tela volta pra MESMA página do clã — não pro Resumo.
async function recarregarClan() {
  const pagina = { clan_postos: renderClanPostos,
                   clan_historico: renderClanHistorico, clan_ferreiro: renderClanFerreiro,
                   clan_equipe: renderClanEquipe, clan_reliquias: renderClanReliquias }[TELA_ATUAL];
  return pagina ? pagina() : renderClan();
}

// 🏰 Resumo (25/09/2026, upgrade pedido pelo dev). Ordem: os RECURSOS,
// quantos membros, o botão pra ver os membros e os botões das equipes
// (lista paginada, com os talentos ao lado — 0★ quando não tem). Depois a
// batalha dos personagens (o XP offline), o diário e o comércio da aldeia,
// que morava no botão "Aldeia" da página que saiu.
let RESUMO_LISTA = null;      // null = fechada | "todos" | um filtro de equipe
let RESUMO_PAGINA = 0;
const RESUMO_POR_PAGINA = 8;
const RESUMO_ABERTOS = new Set();   // habitantes com as ações abertas

async function renderClan() {
  const pg = await carregarPaginaDoClan("clan");
  if (!pg) return;
  const { c, d } = pg;

  // ⏳ quem saiu por causa das 12h
  const est = d.estadias_encerradas || {};
  if ((est.equipes || []).length) toast(`⏳ ${est.equipes.length} equipe(s) completaram 12h no posto e voltaram pra aldeia.`);
  if (est.refugio) toast(`🏕️ As 12h no ${est.refugio} acabaram — o clã saiu do refúgio.`);

  // 📖 (26/09) Crônicas esperando e guerras: primeira coisa da página
  if ((d.cronicas_pendentes || 0) > 0 || (d.guerras || []).length) {
    const aviso = document.createElement("button");
    aviso.className = "botao-holofote";
    aviso.style.cssText = "width:100%;margin-bottom:12px";
    aviso.textContent = (d.guerras || []).length
      ? `⚔️ Em guerra · 📖 ${d.cronicas_pendentes || 0} crônica(s) esperando`
      : `📖 ${d.cronicas_pendentes} crônica(s) esperando sua decisão`;
    aviso.onclick = () => irPara("situacoes");
    c.appendChild(aviso);
  }
  // 1) recursos
  c.appendChild(recursosDoCla(d));
  // 2) quantos membros (+ recrutar, descanso, identidade)
  if (d.aldeia_viva) c.appendChild(cabecalhoDaAldeia(d.aldeia_viva, d.comida));
  // 3) ver membros + 4) equipes
  if (d.aldeia_viva) c.appendChild(listaDeMembros(d));
  // ⚔️ a batalha dos personagens (XP offline)
  if ((d.cultivo || []).length) c.appendChild(painelDoCultivo(d));

  // o diário da última sessão
  if (d.afk && d.afk.ticks > 0) {
    c.appendChild(diarioDoAfk(d.afk));
  } else if (d.diario && d.diario.length) {
    c.appendChild(diarioDoAfk(d.diario[0], `Última jornada do clã — ${haQuantoTempo(d.diario[0].quando)}`));
  }
  if (d.humor) {
    const h = el("div", "clan-humor humor-" + faixaHumor(d.humor.valor));
    h.appendChild(el("div", "clan-humor-nome", `O clã está ${d.humor.nome}`));
    h.appendChild(el("div", "clan-humor-texto", d.humor.texto));
    const barra = el("div", "clan-humor-barra");
    const dentro = el("div", "clan-humor-preenche");
    dentro.style.width = Math.max(2, Math.min(100, d.humor.valor)) + "%";
    barra.appendChild(dentro);
    h.appendChild(barra);
    c.appendChild(h);
  }
  if (d.situacao) {
    c.appendChild(painelDaSituacao(d.situacao));
    const alertas = alertasDoCla(d.situacao, d);
    if (alertas) c.appendChild(alertas);
  }
  if (d.greve && d.greve.length) {
    const g = el("div", "aldeia-box");
    g.appendChild(el("div", "aldeia-estagio", "📉 A aldeia trabalhou pela metade"));
    g.appendChild(el("p", "texto-fraco",
      `Faltou ${d.greve.join(", ")} pra manter a aldeia: as equipes renderam 50%. ` +
      "Compre de outras aldeias (aqui embaixo), mande uma equipe coletar o que falta, ou traga guardas pra casa — guarda custa caro."));
    c.appendChild(g);
  }
  if (d.manutencao) {
    const m = d.manutencao.custo;
    c.appendChild(el("p", "texto-fraco",
      `🏚️ Manter a aldeia por sessão: ${m.comida}🌾 (além da ração) · ${m.madeira}🪵 · ${m.couro}🐂 · ${m.ferro}⛏️`));
  }

  // 🏘️ o que era o botão "Aldeia": serviços, comida, outras aldeias
  const comercio = el("div", "aldeia-comercio");
  c.appendChild(comercio);
  abrirAldeia(comercio);
  // 👆 (26/09) o guia do clã, na primeira vez que ele abre fundado
  setTimeout(() => iniciarGuia("guia_clan", GUIA_CLAN), 600);
}

function recursosDoCla(d) {
  const recursos = el("div", "clan-recursos");
  const comidaCheia = d.teto_comida && d.comida >= d.teto_comida;
  recursos.appendChild(fichaRecurso("🌾", "Comida",
    d.teto_comida ? `${d.comida}/${d.teto_comida}` : d.comida, comidaCheia ? "#e07a5f" : ""));
  recursos.appendChild(fichaRecurso("🪵", "Madeira", d.madeira ?? 0, "#a9793f"));
  recursos.appendChild(fichaRecurso("🐂", "Couro", d.couro ?? 0, "#b08a6a"));
  recursos.appendChild(fichaRecurso("💰", "Ouro", (d.gold ?? 0).toLocaleString("pt-BR"), "var(--ouro)"));
  for (const m of (d.materiais || [])) {
    if (m.qtd > 0 || m.rank <= 2) recursos.appendChild(fichaRecurso("⛏️", m.nome, m.qtd, COR_RANK[m.cor]));
  }
  return recursos;
}

/** O topo da aldeia: estágio, quantos membros, recrutar, regra de descanso
 *  e identidade. (Era a primeira metade do antigo painel da Aldeia.) */
function cabecalhoDaAldeia(av, comida) {
  const box = el("div", "aldeia-box");
  const est = av.estagio || {};
  const vivos = (av.habitantes || []).length;
  const topo = el("div", "aldeia-topo");
  topo.appendChild(el("div", "aldeia-estagio", `👥 ${vivos} membro(s)`));
  topo.appendChild(el("div", "texto-fraco", `${est.nome || "Acampamento"} · cabem ${est.capacidade} · defesa ${av.defesa}`));
  box.appendChild(topo);
  if (est.proximo) {
    const faltaGente = Math.max(0, est.proximo.habitantes - vivos);
    box.appendChild(el("div", "aldeia-proximo",
      `Próximo: ${est.proximo.nome} — ` +
      (faltaGente ? `${faltaGente} membro(s) a mais` : "gente suficiente") +
      (est.proximo.comodidades ? `, ${est.proximo.comodidades} construção(ões)` : "")));
  }
  // 🚶 (26/09) recrutar é só por ouro (o "acolher" por comida saiu): o
  // mesmo serviço "recrutar" da aldeia, que agora traz um aldeão de verdade.
  const recrutar = document.createElement("button");
  recrutar.className = "botao-secundario";
  recrutar.style.cssText = "width:100%;margin:8px 0";
  const cheia = vivos >= (est.capacidade || 0);
  recrutar.textContent = cheia ? "🏘️ Aldeia cheia — construa Moradias"
    : `🚶 Recrutar um aldeão (${av.custo_recrutar || 450} de ouro)`;
  recrutar.disabled = cheia;
  recrutar.onclick = async () => {
    recrutar.disabled = true;
    try {
      const r = await api("/api/clan/aldeia/servico", { method: "POST", body: JSON.stringify({ servico: "recrutar" }) });
      som.moeda(); toast(r.msg);
      atualizarTopo({ gold: r.gold });
      await recarregarClan();
    } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); recrutar.disabled = false; }
  };
  box.appendChild(recrutar);
  const reg = av.regras || {};
  const bRegra = document.createElement("button");
  bRegra.className = reg.descanso_auto ? "botao-holofote" : "botao-secundario";
  bRegra.style.cssText = "width:100%;margin:0";
  bRegra.textContent = reg.descanso_auto
    ? `🔁 Descanso automático LIGADO (para em ${reg.limite}, volta em ${reg.volta})`
    : "🔁 Ligar descanso automático";
  bRegra.onclick = () => acaoAldeia("/api/clan/regras", { descanso_auto: !reg.descanso_auto });
  box.appendChild(bRegra);
  const esp = av.especializacoes || {};
  if (esp.vagas > 0) {
    const escolhidas = esp.escolhidas || [];
    const cat = esp.catalogo || {};
    box.appendChild(el("div", "aldeia-proximo", escolhidas.length
      ? `Identidade: ${escolhidas.map((k) => `${cat[k]?.icone || ""} ${cat[k]?.nome || k}`).join(" + ")}`
      : "A aldeia pode escolher uma identidade."));
    if (escolhidas.length < esp.vagas) {
      const grade = el("div", "habitante-acoes");
      for (const [k, v] of Object.entries(cat)) {
        if (escolhidas.includes(k)) continue;
        const b = document.createElement("button");
        b.className = "botao-secundario";
        b.textContent = `${v.icone} ${v.nome}`;
        b.onclick = () => {
          if (!confirm(`${v.nome}: ${v.efeito}. Trocar depois custa ${esp.custo_troca}g de ouro.`)) return;
          acaoAldeia("/api/clan/especializacao", { especializacao: k });
        };
        grade.appendChild(b);
      }
      box.appendChild(grade);
    }
  }
  return box;
}

// As equipes do Resumo: filtros sobre os membros. O recurso de cada posto
// vem de d.equipes (posto_id → recurso); guarda e "na aldeia" vêm da função.
const FILTROS_DE_EQUIPE = [
  { id: "ferro",   rotulo: "⛏️ Mineração" },
  { id: "comida",  rotulo: "🌾 Comida" },
  { id: "madeira", rotulo: "🪵 Madeira" },
  { id: "couro",   rotulo: "🐂 Couro" },
  { id: "guarda",  rotulo: "🛡️ Guardas" },
  { id: "aldeia",  rotulo: "🏘️ Na aldeia" },
];

function membrosDoFiltro(habitantes, filtro, equipes) {
  const recursoDe = {};
  for (const e of equipes || []) recursoDe[e.posto_id] = e.recurso;
  return habitantes.filter((h) => {
    if (filtro === "todos") return true;
    if (filtro === "guarda") return h.funcao === "guarda";
    if (filtro === "aldeia") return !h.funcao;
    return h.funcao === "coletor" && recursoDe[h.equipe] === filtro;
  });
}

function listaDeMembros(d) {
  const av = d.aldeia_viva;
  const habs = av.habitantes || [];
  const box = el("div", "membros");
  const ver = document.createElement("button");
  ver.className = RESUMO_LISTA === "todos" ? "botao-holofote" : "botao-secundario";
  ver.style.cssText = "width:100%;margin:0 0 8px";
  ver.textContent = RESUMO_LISTA === "todos" ? `👥 Esconder membros` : `👥 Ver membros (${habs.length})`;
  ver.onclick = () => { som.clique(); RESUMO_LISTA = RESUMO_LISTA === "todos" ? null : "todos"; RESUMO_PAGINA = 0; renderClan(); };
  box.appendChild(ver);

  const chips = el("div", "membros-equipes");
  for (const f of FILTROS_DE_EQUIPE) {
    const n = membrosDoFiltro(habs, f.id, d.equipes).length;
    const b = document.createElement("button");
    b.className = "filtro-chip" + (RESUMO_LISTA === f.id ? " ativo" : "");
    b.textContent = `${f.rotulo} ${n}`;
    b.onclick = () => { som.clique(); RESUMO_LISTA = RESUMO_LISTA === f.id ? null : f.id; RESUMO_PAGINA = 0; renderClan(); };
    chips.appendChild(b);
  }
  box.appendChild(chips);

  if (!RESUMO_LISTA) return box;
  const lista = membrosDoFiltro(habs, RESUMO_LISTA, d.equipes);
  if (!lista.length) {
    box.appendChild(estadoVazio("👥", RESUMO_LISTA === "todos"
      ? "Ninguém mora aqui ainda — acolha alguém."
      : "Ninguém nessa equipe agora. Monte equipes em Explorar andar."));
    return box;
  }
  const paginas = Math.ceil(lista.length / RESUMO_POR_PAGINA);
  RESUMO_PAGINA = Math.max(0, Math.min(RESUMO_PAGINA, paginas - 1));
  const fatia = lista.slice(RESUMO_PAGINA * RESUMO_POR_PAGINA, (RESUMO_PAGINA + 1) * RESUMO_POR_PAGINA);
  for (const h of fatia) box.appendChild(linhaDoMembro(h, av));
  if (paginas > 1) {
    const nav = el("div", "membros-paginas");
    const ant = document.createElement("button");
    ant.className = "botao-secundario"; ant.textContent = "‹";
    ant.disabled = RESUMO_PAGINA === 0;
    ant.onclick = () => { RESUMO_PAGINA--; renderClan(); };
    const prox = document.createElement("button");
    prox.className = "botao-secundario"; prox.textContent = "›";
    prox.disabled = RESUMO_PAGINA >= paginas - 1;
    prox.onclick = () => { RESUMO_PAGINA++; renderClan(); };
    nav.append(ant, el("span", "", `Página ${RESUMO_PAGINA + 1} de ${paginas}`), prox);
    box.appendChild(nav);
  }
  return box;
}

/** Uma linha por membro, com os talentos AO LADO (todos, 0★ quando não
 *  tem). Tocar abre o detalhe e as ações que moravam na página da Aldeia. */
function linhaDoMembro(h, av) {
  const prof = (av.profissoes || {})[h.profissao] || {};
  const aberto = RESUMO_ABERTOS.has(h.id);
  const linha = el("div", `membro${h.descansando ? " descansando" : ""}${aberto ? " aberto" : ""}`);
  const topo = document.createElement("button");
  topo.className = "membro-topo";
  const txt = el("div", "membro-txt");
  txt.appendChild(el("div", "membro-nome", `${h.cavaleiro ? "⚔️" : (prof.icone || "👤")} ${h.nome}`));
  // 💰 (28/09) cavaleiro mora na cidade e recebe soldo: sem soldo, parado
  const soldo = !h.cavaleiro ? "" : h.soldo_horas > 0
    ? ` · 💰 ${h.soldo_horas >= 48 ? Math.floor(h.soldo_horas / 24) + "d" : h.soldo_horas + "h"}`
    : " · 💰 sem soldo (parado)";
  const papel = h.cavaleiro ? (h.treino_horas > 0 ? `⚔️ Cavaleiro em treino (~${h.treino_horas}h)${soldo}` : `⚔️ Cavaleiro${soldo}`)
    : h.funcao === "guarda" ? "🛡️ Guarda" : h.funcao === "coletor" ? "🧺 Coletor" : "🏠 Na aldeia";
  txt.appendChild(el("div", "membro-sub", `${papel} · Nv.${h.nivel}/${h.nivel_max}${h.descansando ? " · 😴" : ""}`));
  topo.appendChild(txt);
  const tal = el("div", "membro-talentos");
  for (const [k, icone] of Object.entries(ICONE_TALENTO)) {
    const e = Number((h.talentos || {})[k] || 0);
    tal.appendChild(el("span", "membro-talento" + (e ? "" : " zero"), `${icone}${e}★`));
  }
  topo.appendChild(tal);
  topo.onclick = () => { aberto ? RESUMO_ABERTOS.delete(h.id) : RESUMO_ABERTOS.add(h.id); renderClan(); };
  linha.appendChild(topo);
  if (!aberto) return linha;

  const det = el("div", "membro-detalhe");
  if (h.xp_proximo) det.appendChild(el("div", "habitante-sub", `${h.xp}/${h.xp_proximo} XP`));
  if (h.aura) det.appendChild(el("div", "habitante-sub", `✨ Aura ${"★".repeat(h.aura)}`));
  if (h.cargo) det.appendChild(el("div", "habitante-cargo", `👑 ${h.cargo}`));
  if (h.familia) det.appendChild(el("div", "habitante-sub", `👪 ${h.familia}`));
  const trilho = el("div", "barra-trilho mini");
  const fill = el("div", `barra-preenchimento ${h.fadiga >= 80 ? "barra-inimigo" : "barra-atb"}`);
  fill.style.width = `${h.fadiga}%`;
  trilho.appendChild(fill);
  det.appendChild(trilho);
  // (25/09) desde 20/09 só produz quem está numa EQUIPE, num posto — o
  // "rende ~X/sessão" aparecia até pra quem estava parado na aldeia.
  const rende = h.funcao === "coletor"
    ? (h.produz ? `coletando · rende ~${h.rende} de ${h.produz}/sessão` : "coletando")
    : h.funcao === "guarda" ? "de guarda numa equipe"
    : "parado na aldeia — só produz numa equipe (Explorar andar)";
  det.appendChild(el("div", "habitante-sub", `${h.descansando ? "😴 descansando" : h.faixa} · ${rende}`));
  const acoes = el("div", "habitante-acoes");
  const bDesc = document.createElement("button");
  bDesc.className = "botao-secundario";
  bDesc.textContent = h.descansando ? "⛏️ Voltar ao trabalho" : "😴 Descansar";
  bDesc.onclick = () => mudarHabitante({ id: h.id, descansar: !h.descansando });
  const bProf = document.createElement("button");
  bProf.className = "botao-secundario";
  bProf.textContent = "🔄 Profissão";
  bProf.onclick = () => escolherProfissao(h, av.profissoes);
  // ⚔️ cavaleiro não troca de ofício (trocar zeraria o nível dele)
  if (h.cavaleiro) acoes.append(bDesc); else acoes.append(bDesc, bProf);
  // 💰 (28/09, dev) soldo do cavaleiro, pago em ouro do personagem que você pilota
  if (h.cavaleiro) {
    for (const dias of [7, 1]) {
      const b = document.createElement("button");
      b.className = dias === 7 ? "botao-holofote" : "botao-secundario";
      const preco = dias * (h.soldo_dia || 500);
      b.textContent = `💰 Soldo ${dias} dia${dias > 1 ? "s" : ""} (${preco.toLocaleString("pt-BR")})`;
      b.onclick = async () => {
        try {
          const r = await api("/api/clan/cavaleiro/soldo", { method: "POST", body: JSON.stringify({ id: h.id, dias }) });
          som.moeda();
          if (r.gold != null) atualizarTopo({ gold: r.gold });
          toast(`💰 Soldo de ${h.nome} pago por mais ${dias} dia${dias > 1 ? "s" : ""}.`);
          await recarregarClan();
        } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
      };
      acoes.appendChild(b);
    }
  }
  // ✨ (28/09, dev) quem despertou pode deixar a aldeia e virar personagem
  if (h.pode_virar_personagem) {
    const bSubir = document.createElement("button");
    bSubir.className = "botao-holofote";
    bSubir.style.gridColumn = "1 / -1";
    bSubir.textContent = "✨ Virar personagem (subir a Torre)";
    bSubir.onclick = async () => {
      if (!confirm(
        `${h.nome} despertou a aura (${"★".repeat(h.aura)}). Deixar ele sair da aldeia e virar um dos seus personagens?\n\n`
        + `A aldeia perde o trabalho dele e o bônus de aura${h.cargo ? ` — e o cargo de ${h.cargo}` : ""}. `
        + `Ele ocupa um slot de personagem e começa no nível 1 com ${4 * h.aura} pontos de trilha `
        + `(4 por estrela de aura). Nascido na Torre: +10% em todos os status, mas a raça e a `
        + `profissão vêm sorteadas quando você pilotar ele pela primeira vez.`)) return;
      try {
        const r = await api("/api/clan/habitante/promover", { method: "POST", body: JSON.stringify({ id: h.id }) });
        som.moeda();
        notificacaoGrande("✨", h.nome, "Agora é um dos seus personagens — veja em Você → Personagens");
        toast(String(r.texto || "").replace(/<[^>]+>/g, ""));
        await recarregarClan();
      } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    };
    acoes.appendChild(bSubir);
  }
  const cargoPossivel = h.aura ? "aura" : ((av.cargos || {})[h.profissao] ? h.profissao : null);
  if (cargoPossivel && !h.cargo) {
    const bChefe = document.createElement("button");
    bChefe.className = "botao-secundario";
    bChefe.style.gridColumn = "1 / -1";
    bChefe.textContent = `👑 Tornar ${av.cargos[cargoPossivel].nome}`;
    bChefe.onclick = () => acaoAldeia("/api/clan/chefe", { cargo: cargoPossivel, id: h.id });
    acoes.appendChild(bChefe);
  }
  det.appendChild(acoes);
  linha.appendChild(det);
  return linha;
}

/** ⚔️ Batalha no andar: o XP offline dos personagens da conta. A chance de
 *  morrer aparece ANTES de mandar — é medida duelando a ficha de verdade. */
function painelDoCultivo(d) {
  const box = el("div", "aldeia-box cultivo");
  const andar = d.andar_de_trabalho || d.andar_do_cla || 1;
  box.appendChild(el("div", "aldeia-estagio", `⚔️ Batalha no Andar ${andar}`));
  box.appendChild(el("p", "texto-fraco",
    "O XP rende a cada 5 minutos conforme o ⚡ poder de combate, +10% por guarda do clã em serviço. "
    + "Depois de 20 min sem jogar, o personagem que você pilota entra sozinho no idle (sem risco). "
    + "Ligado aqui (⚔️ Lutando), ele batalha o tempo todo — mas pode morrer e ir pra morte da Torre."));
  for (const x of d.cultivo) {
    const linha = el("div", "cultivo-linha" + (x.batalhando ? " ligado" : "") + (x.morto ? " morto" : ""));
    const txt = el("div", "cultivo-txt");
    txt.appendChild(el("div", "cultivo-nome", `${x.nome}${x.ativo ? " · você" : ""} — Nv.${x.nivel}`));
    let sub;
    if (!x.existe) sub = "ainda não nasceu — troque pra ele uma vez";
    else if (x.morto) sub = "💀 morto — reviva na Torre" + (x.ativo ? "" : " (troque pra ele em Personagens)");
    else sub = `⚡${(x.poder || 0).toLocaleString("pt-BR")} · ~${x.xp_por_hora} XP/h`
      + (x.idle_auto ? " · 💤 no idle automático" : "")
      + ` · se lutar: morre em ${x.chance_morte}% das lutas`;
    txt.appendChild(el("div", "cultivo-sub", sub));
    if (x.resumo && x.existe && !x.morto) txt.appendChild(el("div", "cultivo-sub", x.resumo));
    if (x.ultimo) {
      const u = x.ultimo;
      txt.appendChild(el("div", "cultivo-ultimo",
        `Última: +${u.xp} XP em ${u.lutas} luta(s)${u.morreu ? " · 💀 caiu" : ""}${u.travado ? " · no teto de nível do andar" : ""} — ${haQuantoTempo(u.quando)}`));
    }
    linha.appendChild(txt);
    const b = document.createElement("button");
    b.className = x.batalhando ? "botao-holofote cultivo-acao" : "botao-secundario cultivo-acao";
    b.textContent = x.batalhando ? "⚔️ Lutando" : "🏠 Em casa";
    b.disabled = !x.existe || (x.morto && !x.batalhando);
    b.onclick = async () => {
      if (!x.batalhando && x.risco_sessao >= 50 &&
          !confirm(`${x.nome} morre em ${x.risco_sessao}% de uma sessão cheia neste andar. Mandar mesmo assim?`)) return;
      b.disabled = true;
      try {
        await api("/api/clan/cultivo", { method: "POST", body: JSON.stringify({ slot: x.slot, batalhar: !x.batalhando }) });
        som.clique(); await renderClan();
      } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); b.disabled = false; }
    };
    linha.appendChild(b);
    box.appendChild(linha);
  }
  return box;
}

// ⚔️ Postos: quem trabalha onde, e a busca por postos novos no andar.
async function renderClanPostos() {
  const pg = await carregarPaginaDoClan("clan_postos");
  if (!pg) return;
  const { c, d } = pg;
  // 🧭 25/09/2026 (dev): "Postos" virou "Explorar andar" — é aqui que o clã
  // explora o andar onde está e escolhe pra onde vai. Depois disso segue o
  // de sempre: batalha pelo ponto, equipe no posto, AFK.
  c.appendChild(cabecalhoDoAndar(d));
  // 🔎 Explorar (construtor fora do render, pra o executar_appjs cobrir)
  const exploracao = caixaDeExploracao(d);
  if (exploracao) c.appendChild(exploracao);
  // 🏕️ o refúgio do andar: opção fixa (a página do Território saiu)
  const refugio = cartaoDoRefugio(d);
  if (refugio) c.appendChild(refugio);

  // 👥 As equipes: coletar é fora, num posto, com guarda junto.
  c.appendChild(el("h3", "secao-titulo", "👥 Equipes neste andar"));
  if (!(d.equipes || []).length) {
    c.appendChild(estadoVazio("🔎", "Nenhum posto achado neste andar ainda — explore acima."));
  }
  // agrupadas pelo que FAZEM (pedido do dev): o ponto, e cada recurso
  const grupos = [["cidade", "🏰 Cidade (o que a aldeia guarda)"], ["ponto", "🚩 Ponto do mapa"],
                  ["comida", "🌾 Equipes de comida"], ["madeira", "🪵 Equipes de madeira"],
                  ["couro", "🦌 Equipes de couro"], ["ferro", "⛏️ Equipes de ferro"]];
  for (const [chave, titulo] of grupos) {
    const doGrupo = (d.equipes || []).filter((e) => (e.especial || e.recurso) === chave);
    if (!doGrupo.length) continue;
    c.appendChild(el("div", "aldeia-estagio", titulo));
    for (const eq of doGrupo) c.appendChild(cartaoDaEquipe(eq, d));
  }

  // Os lutadores (personagens) não vão mais pros postos: são quem faz a
  // Travessia. Ficam listados aqui pra ver estado (fome, ferimento).
  c.appendChild(el("h3", "secao-titulo",
    d.situacao ? `Lutadores (${d.situacao.vivos}) — vão na Travessia` : "Lutadores — vão na Travessia"));
  if (!d.membros.length) {
    c.appendChild(estadoVazio("🏰",
      "Nenhum membro ainda. Cada personagem da conta vira um membro do clã — "
      + "crie um na tela de Personagens."));
  }
  for (const m of d.membros) {
    const linha = document.createElement("button");
    linha.className = "linha-lista";
    const texto = el("div", "linha-lista-texto");
    texto.appendChild(el("div", "linha-lista-titulo", `${m.nome} — nível ${m.nivel}`));
    const area = d.areas.find((a) => a.id === m.area_id);
    // O equipamento aparece no membro porque a distribuição é automática:
    // sem mostrar quem ficou com o quê, forjar pareceria não fazer nada.
    const eq = m.equip_poder ? `  ·  equipado +${m.equip_poder}` : "  ·  sem equipamento";
    texto.appendChild(el("div", "linha-lista-sub",
      (area ? `${area.nome} · ${m.perfil || "perfil ainda não calculado"}`
            : "na cidade, sem posto") + eq));
    // Fome e ferimento derrubam atributo no perfil de combate — ou seja,
    // encolhem a fronteira dele. Escondê-los faria o jogador mandar um
    // cavaleiro enfraquecido achando que manda o de ontem.
    const estado = [];
    if (m.fome > 0) estado.push(`🌾 com fome (−${m.fome})`);
    if (m.ferimento > 0) estado.push(`🩸 ferido (−${m.ferimento})`);
    if (estado.length) {
      const aviso = el("div", "linha-lista-sub", estado.join("  ·  "));
      aviso.style.color = "#e07a5f";
      texto.appendChild(aviso);
    }
    linha.appendChild(texto);
    linha.appendChild(el("span", "linha-lista-seta", area ? "⚔️" : "·"));
    c.appendChild(linha);
  }

  // As sessões anteriores. Uma só na tela seria "o que aconteceu"; várias
  // são "como o clã chegou até aqui", que é a saga contada em números.
}

// 25/09/2026: a página Aldeia saiu (pedido do dev). Os membros e as equipes
// estão no Resumo; o comércio também; a Forja foi pro Ferreiro.

// 🏺 Relíquias: o achado raro das equipes (~1% por equipe por sessão). O
// acervo cresce; os slots não — escolher o que fica de fora é o sistema.
async function renderClanReliquias() {
  const pg = await carregarPaginaDoClan("clan_reliquias");
  if (!pg) return;
  const { c, d } = pg;
  const r = d.reliquias || { acervo: [], slots: 3, total: 8, chance: 0.01 };
  const ativas = r.acervo.filter((x) => x.ativa).length;
  c.appendChild(el("p", "texto-fraco",
    `${r.acervo.length}/${r.total} no acervo · ${ativas}/${r.slots} ativas · `
    + `cada equipe tem ${Math.round(r.chance * 100)}% por sessão de desenterrar uma.`));
  if (!r.acervo.length) {
    c.appendChild(estadoVazio("🏺", "Nenhuma ainda. Mande equipes trabalhar nos postos — é cavando que aparece."));
    return;
  }
  for (const x of r.acervo) c.appendChild(cartaoDaReliquia(x, ativas >= r.slots));
}

function cartaoDaReliquia(x, slotsCheios) {
  const card = el("div", `aldeia-box${x.ativa ? " meu" : ""}`);
  card.appendChild(el("div", "aldeia-estagio", `${x.icone} ${x.nome}${x.ativa ? " · ativa" : ""}`));
  card.appendChild(el("p", "texto-fraco", x.historia));
  card.appendChild(el("div", "habitante-sub", `✨ ${x.texto}`));
  const b = document.createElement("button");
  b.className = x.ativa ? "botao-secundario" : "botao-holofote";
  b.style.cssText = "width:100%;margin-top:6px";
  b.textContent = x.ativa ? "📦 Guardar no acervo" : "✨ Ativar";
  b.disabled = !x.ativa && slotsCheios;
  b.onclick = async () => {
    try {
      await api("/api/clan/reliquia", { method: "POST", body: JSON.stringify({ reliquia: x.id, ativa: !x.ativa }) });
      som.clique(); await recarregarClan();
    } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
  };
  card.appendChild(b);
  return card;
}

// ⚒️ Ferreiro: ferramentas dos coletores e equipamento dos guardas, em lote.
async function renderClanFerreiro() {
  const pg = await carregarPaginaDoClan("clan_ferreiro");
  if (!pg) return;
  const { c, d } = pg;
  c.appendChild(el("p", "texto-fraco",
    "Uma bancada por função: a ferramenta do lenhador não serve pro minerador. O ferreiro trabalha em "
    + "LOTE com quem está fazendo aquilo agora; quem mudou de função (ou chegou) é nivelado primeiro, "
    + "com custo 50% maior. Usa o material do clã."));
  for (const trilha of ["agricultor", "lenhador", "cacador", "minerador", "guarda"]) {
    const f = (d.ferreiro || {})[trilha];
    if (f) c.appendChild(cartaoDoFerreiro(trilha, f));
  }
  // 🔨 Forja e construções (era o botão da página Aldeia, que saiu)
  const oficina = el("div", "ferreiro-oficina");
  c.appendChild(oficina);
  abrirOficina(d, oficina);
}

function cartaoDoFerreiro(trilha, f) {
  const card = el("div", "aldeia-box");
  card.appendChild(el("div", "aldeia-estagio", `${f.nome} — Tier ${f.tier_lote}`));
  const efeito = trilha === "guarda" ? "poder" : "produção";
  card.appendChild(el("p", "texto-fraco",
    `${f.total} na trilha · ${efeito} ×${f.bonus.toFixed(2)}` +
    (f.bonus_proximo && f.alvo && f.acao === "evoluir" ? ` → ×${f.bonus_proximo.toFixed(2)} no Tier ${f.alvo}` : "")));
  if (f.acao === "nada") { card.appendChild(el("p", "texto-fraco", "Ninguém fazendo isso agora — monte uma equipe em Postos.")); return card; }
  if (f.acao === "maximo") { card.appendChild(el("p", "texto-fraco", "✅ Todos no tier máximo.")); return card; }
  const custo = Object.entries(f.custo).map(([r, q]) => `${q} de rank ${r} (tem ${f.tem[r] ?? 0})`).join(" + ");
  const falta = Object.entries(f.custo).some(([r, q]) => (f.tem[r] ?? 0) < q);
  card.appendChild(el("p", "texto-fraco", f.acao === "nivelar"
    ? `🆕 ${f.quem} chegaram depois: nivelar até o Tier ${f.alvo} custa ${custo}.`
    : `⬆️ Evoluir os ${f.quem} pro Tier ${f.alvo} custa ${custo}.`));
  const b = document.createElement("button");
  b.className = falta ? "botao-secundario" : "botao-holofote";
  b.style.cssText = "width:100%";
  b.textContent = f.acao === "nivelar" ? "🆕 Nivelar os novos" : `⬆️ Evoluir pro Tier ${f.alvo}`;
  b.disabled = falta;
  b.onclick = async () => {
    try {
      await api("/api/clan/ferreiro", { method: "POST", body: JSON.stringify({ trilha }) });
      som.moeda(); toast("O ferreiro terminou o lote."); await recarregarClan();
    } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
  };
  card.appendChild(b);
  return card;
}

// 📜 Histórico: as sessões passadas e quem tombou.
async function renderClanHistorico() {
  const pg = await carregarPaginaDoClan("clan_historico");
  if (!pg) return;
  const { c, d } = pg;
  let vazio = true;
  if (d.diario && d.diario.length > 1) {
    vazio = false;
    c.appendChild(el("h3", "secao-titulo", "Jornadas anteriores"));
    for (const pagina of d.diario.slice(1)) {
      const linha = el("div", "clan-jornada");
      const ganhos = [];
      if (pagina.comida) ganhos.push(`${pagina.comida}🌾`);
      if (pagina.ouro) ganhos.push(`${pagina.ouro}💰`);
      for (const [rank, qtd] of Object.entries(pagina.materiais || {})) {
        ganhos.push(`${qtd}⛏️r${rank}`);
      }
      linha.appendChild(el("span", "clan-jornada-quando", haQuantoTempo(pagina.quando)));
      linha.appendChild(el("span", "clan-jornada-ganhos",
        ganhos.length ? ganhos.join("  ") : "nada trouxe"));
      if (pagina.mortos && pagina.mortos.length) {
        linha.appendChild(el("span", "clan-jornada-morte",
          `⚰️ ${pagina.mortos.map((m) => m.nome).join(", ")}`));
      }
      c.appendChild(linha);
    }
  }

  // 📖 Memórias e memorial da aldeia (vieram da página Aldeia, que saiu)
  if (d.aldeia_viva && ((d.aldeia_viva.memorias || []).length || (d.aldeia_viva.memorial || []).length)) {
    vazio = false;
    c.appendChild(memoriasDaAldeia(d.aldeia_viva));
  }

  if (d.mortos.length) {
    vazio = false;
    // Os mortos ficam listados de propósito. Permadeath sem memorial é só
    // um número que sumiu da lista.
    c.appendChild(el("h3", "secao-titulo", "Tombados"));
    for (const m of d.mortos) {
      const box = el("div", "clan-morto");
      box.appendChild(el("div", "clan-morto-nome", m.nome));
      box.appendChild(el("div", "clan-morto-causa", m.causa || "causa não registrada"));
      c.appendChild(box);
    }
  }

  if (vazio) c.appendChild(estadoVazio("📜", "Ainda não há histórico: as sessões do clã aparecem aqui."));
}

let CLAN_CACHE = null;

// 🔎 Explorar: os postos não vêm prontos — o clã procura, gastando comida,
// e nem sempre acha o que queria. Cada andar mostra O QUE PODE existir lá
// (a lista do andar), não o que vai sair. Fica FORA do renderClan de
// propósito: construtor puro é o que o executar_appjs.js consegue rodar.
let EQUIPE_EXPLORANDO = null;

function cabecalhoDoAndar(d) {
  const andar = d.andar_de_trabalho || d.andar_do_cla || 1;
  const postos = (d.equipes || []).filter((e) => !e.especial).length;
  const ocupadas = (d.equipes || []).filter((e) => (e.guardas || []).length || (e.coletores || []).length).length;
  const box = el("div", "andar-cabecalho");
  const placa = el("div", "andar-cabecalho-placa");
  placa.append(el("span", "", "Andar"), el("b", "", String(andar)));
  const txt = el("div", "andar-cabecalho-txt");
  txt.appendChild(el("div", "andar-cabecalho-titulo", "Onde o clã está"));
  txt.appendChild(el("div", "andar-cabecalho-sub",
    `${postos} posto(s) achado(s) · ${ocupadas} equipe(s) em campo`));
  box.append(placa, txt);
  return box;
}

/** "12h" / "3h 20min" / "15 min". */
function formatarEstadia(seg) {
  const min = Math.max(0, Math.round(Number(seg || 0) / 60));
  const h = Math.floor(min / 60), m = min % 60;
  return h ? (m ? `${h}h ${m}min` : `${h}h`) : `${m} min`;
}

/** 🏕️ Refúgio: ninguém ataca, fica 12h e o clã sai sozinho. */
function cartaoDoRefugio(d) {
  const r = d.refugio;
  if (!r) return null;
  const card = el("div", "achado achado-refugio" + (r.ativo ? " ativo" : ""));
  card.appendChild(el("div", "achado-icone", "🏕️"));
  const txt = el("div", "achado-txt");
  txt.appendChild(el("div", "achado-titulo", r.nome));
  txt.appendChild(el("div", "achado-detalhe", r.ativo
    ? `O clã está abrigado · sai em ${formatarEstadia(r.restante_seg)}`
    : `Refúgio seguro: ninguém ataca · fica ${formatarEstadia(r.restante_seg)}`
      + (r.tem_outro_ponto ? " · larga o ponto atual" : "")));
  card.appendChild(txt);
  const b = document.createElement("button");
  b.className = r.ativo ? "botao-secundario achado-acao" : "botao-holofote achado-acao";
  b.textContent = r.ativo ? "Sair" : "🏕️ Abrigar";
  b.onclick = async () => {
    if (!r.ativo && r.tem_outro_ponto && !confirm(`Abrigar o clã em ${r.nome}? Um ponto por vez: o clã larga o ponto atual.`)) return;
    b.disabled = true;
    try {
      const resp = r.ativo
        ? await api("/api/clan/territorio/abandonar", { method: "POST" })
        : await api("/api/clan/territorio/conquistar", { method: "POST", body: JSON.stringify({ id: r.id }) });
      som.clique(); toast(resp.texto || (r.ativo ? "O clã saiu do refúgio." : "Feito."));
      await recarregarClan();
    } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); b.disabled = false; }
  };
  card.appendChild(b);
  return card;
}

function caixaDeExploracao(d) {
  // 🔎 (dev, 20/09) uma EQUIPE com guarda explora o andar: pode ser atacada
  // no caminho e volta com 5 achados — postos, pontos do mapa, cidades de
  // outros clãs. Escolher leva a equipe pra lá; explorar de novo refaz a lista.
  const comGuarda = (d.equipes || []).filter((e) => e.guardas && e.guardas.length);
  const caixa = el("div", "aldeia-box caixa-exploracao");
  caixa.appendChild(el("div", "aldeia-estagio", "🔎 Explorar o andar"));
  if (!comGuarda.length) {
    caixa.appendChild(el("p", "texto-fraco", "Monte uma equipe com guarda — só ela aguenta o caminho."));
    return caixa;
  }
  if (!EQUIPE_EXPLORANDO || !comGuarda.some((e) => e.posto_id === EQUIPE_EXPLORANDO)) {
    EQUIPE_EXPLORANDO = (d.achados && d.achados.equipe) || comGuarda[0].posto_id;
  }
  const escolha = el("div", "habitante-acoes");
  for (const e of comGuarda) {
    const b = document.createElement("button");
    b.className = e.posto_id === EQUIPE_EXPLORANDO ? "botao-holofote" : "botao-secundario";
    b.textContent = e.nome;
    b.onclick = () => { EQUIPE_EXPLORANDO = e.posto_id; recarregarClan(); };
    escolha.appendChild(b);
  }
  caixa.appendChild(escolha);
  const ir = document.createElement("button");
  ir.className = "botao-holofote";
  ir.style.cssText = "width:100%;margin-top:6px";
  const lista = (d.achados && d.achados.lista) || [];
  ir.textContent = `${lista.length ? "🔄 Explorar de novo" : "🔎 Explorar"} `
    + `(−${d.custo_busca}🌾 −${d.madeira_busca ?? 0}🪵 · 25% de emboscada)`;
  ir.disabled = d.comida < d.custo_busca || (d.madeira ?? 0) < (d.madeira_busca ?? 0);
  ir.onclick = async () => {
    try {
      const r = await api("/api/clan/explorar", { method: "POST", body: JSON.stringify({ equipe: EQUIPE_EXPLORANDO }) });
      if (r.emboscada) toast(r.emboscada.ferido ? "⚠️ Emboscada! A escolta não deu conta — a equipe voltou cansada."
                                                : "⚔️ Emboscada — a escolta segurou.", !!r.emboscada.ferido);
      som.clique(); await recarregarClan();
    } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
  };
  caixa.appendChild(ir);
  const icone = { posto: "📍", ponto: "🚩", cidade: "🏰" };
  if (lista.length) caixa.appendChild(el("div", "achados-titulo", `O que a equipe achou (${lista.length})`));
  lista.forEach((a, i) => {
    const card = el("div", `achado achado-${a.tipo}`);
    // O título de posto e de cidade já vem com o emoji dele do servidor;
    // o ícone só entra quando o título começa por letra (ponto do mapa).
    const temEmoji = !/^[\p{L}\p{N}]/u.test(a.titulo || "");
    card.appendChild(el("div", "achado-icone", temEmoji ? (a.titulo.match(/^\S+/) || [""])[0] : (icone[a.tipo] || "·")));
    const txt = el("div", "achado-txt");
    txt.appendChild(el("div", "achado-titulo", temEmoji ? a.titulo.replace(/^\S+\s*/, "") : a.titulo));
    txt.appendChild(el("div", "achado-detalhe", a.detalhe || ""));
    card.appendChild(txt);
    const b = document.createElement("button");
    b.className = a.tipo === "posto" ? "botao-holofote achado-acao" : "botao-secundario achado-acao";
    b.textContent = a.tipo === "cidade" ? "⚔️ Atacar" : a.tipo === "ponto" ? "🚩 Marchar" : "📍 Ficar";
    b.onclick = async () => {
      if (a.tipo !== "posto" && !confirm("Pode virar batalha: quem perde tem os guardas mortos e os coletores levados. Seguir?")) return;
      try {
        const r = await api("/api/clan/achado", { method: "POST", body: JSON.stringify({ indice: i }) });
        toast(r.texto || "Feito.", r.venceu === false);
        if (r.venceu === false) som.erro(); else som.moeda();
        await recarregarClan();
      } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    };
    card.appendChild(b);
    caixa.appendChild(card);
  });
  return caixa;
}

function fichaRecurso(icone, nome, qtd, cor) {
  const box = el("div", "clan-recurso");
  box.appendChild(el("div", "clan-recurso-icone", icone));
  const v = el("div", "clan-recurso-valor", String(qtd));
  if (cor) v.style.color = cor;
  box.appendChild(v);
  box.appendChild(el("div", "clan-recurso-nome", nome));
  return box;
}

// =============================================================================
// 🏰 A SITUAÇÃO DO CLÃ — sempre na tela
// =============================================================================
// A tela mostrava recursos e uma lista de membros, e mais nada: não dizia
// quantos aldeões existiam, quantos estavam trabalhando, quantos passavam
// fome, nem quanto tempo a comida ainda durava. E o diário do AFK só
// aparecia quando havia tick novo — reabrir a tela apagava tudo, e o
// jogador ficava com uma lista de nomes sem contexto nenhum.
//
// Os números vêm prontos do servidor (CR.situacao_do_cla). É a MESMA conta
// que decide o jogo — quem come, quanto dura a comida —, e duas
// implementações da mesma regra divergem: a que o jogador lê vira a que ele
// usa pra decidir, e aí ele decide com o número errado.

function fichaSituacao(icone, rotulo, valor, tom) {
  const f = el("div", "sit-ficha" + (tom ? ` ${tom}` : ""));
  f.appendChild(el("div", "sit-ficha-icone", icone));
  f.appendChild(el("div", "sit-ficha-valor", String(valor)));
  f.appendChild(el("div", "sit-ficha-rotulo", rotulo));
  return f;
}

function painelDaSituacao(sit) {
  const caixa = el("div", "sit-painel");

  const grade = el("div", "sit-grade");
  grade.appendChild(fichaSituacao("👥", "aldeões", sit.vivos));
  grade.appendChild(fichaSituacao("⛏️", "em posto", sit.em_posto));
  grade.appendChild(fichaSituacao("🏕️", "na aldeia", sit.na_aldeia));
  if (sit.com_fome > 0) grade.appendChild(fichaSituacao("🌾", "com fome", sit.com_fome, "ruim"));
  if (sit.feridos > 0) grade.appendChild(fichaSituacao("🩸", "feridos", sit.feridos, "ruim"));
  if (sit.mortos > 0) grade.appendChild(fichaSituacao("⚰️", "mortos", sit.mortos, "morto"));
  caixa.appendChild(grade);

  // Autonomia: quantas sessões a comida aguenta no ritmo de hoje. É o
  // número que decide entre postar mais gente e mandar alguém colher, e
  // era o que nenhuma tela mostrava.
  if (sit.autonomia_sessoes !== null && sit.autonomia_sessoes !== undefined) {
    const a = sit.autonomia_sessoes;
    const tom = a < 1 ? "ruim" : a < 3 ? "atencao" : "";
    const linha = el("div", `sit-autonomia ${tom}`);
    linha.appendChild(el("span", "sit-autonomia-num", a < 1 ? "<1" : String(a)));
    linha.appendChild(el("span", "sit-autonomia-txt",
      `sessõe${a === 1 ? "" : "s"} de comida no ritmo de agora `
      + `(${sit.racao_por_sessao} por sessão)`));
    caixa.appendChild(linha);
  }
  return caixa;
}

/** O que está errado, em ordem de urgência. Alerta que o jogador não
 *  consegue agir é ruído — cada um destes tem uma ação óbvia. */
function alertasDoCla(sit, d) {
  const lista = [];
  const a = sit.autonomia_sessoes;

  if (sit.em_posto === 0 && sit.vivos > 0) {
    lista.push({ t: "info", txt: "Ninguém está em posto. O clã não produz nada assim." });
  }
  if (a !== null && a < 1) {
    lista.push({ t: "grave", txt: "A comida acaba nesta sessão. Recolha gente, mande "
      + "alguém colher num andar raso ou compre mantimentos na aldeia." });
  } else if (sit.colhendo_comida === 0 && sit.em_posto > 0 && a !== null && a < 4) {
    lista.push({ t: "grave", txt: "Ninguém está colhendo comida e o estoque está curto." });
  } else if (a !== null && a < 3) {
    lista.push({ t: "atencao", txt: "A comida está acabando." });
  }
  if (sit.com_fome > 0) {
    lista.push({ t: "atencao", txt: `${sit.com_fome} com fome — cada ponto de fome `
      + "é um atributo a menos no combate deles." });
  }
  if (sit.feridos > 0) {
    lista.push({ t: "atencao", txt: `${sit.feridos} ferido(s). O curandeiro da aldeia cura.` });
  }
  if (d.teto_comida && d.comida >= d.teto_comida) {
    lista.push({ t: "atencao", txt: "O depósito encheu — o que for colhido agora apodrece. "
      + "O Celeiro dobra o que cabe." });
  }
  if (sit.situacoes_pendentes > 0) {
    lista.push({ t: "info", txt: `${sit.situacoes_pendentes} situação(ões) esperando decisão.` });
  }
  if (!lista.length) return null;

  const caixa = el("div", "sit-alertas");
  for (const al of lista) {
    const linha = el("div", `sit-alerta ${al.t}`);
    linha.appendChild(el("span", "sit-alerta-marca",
      al.t === "grave" ? "⛔" : al.t === "atencao" ? "⚠️" : "•"));
    linha.appendChild(el("span", "sit-alerta-txt", al.txt));
    caixa.appendChild(linha);
  }
  return caixa;
}

function haQuantoTempo(quando) {
  if (!quando) return "";
  const seg = Math.max(0, Math.floor(Date.now() / 1000) - Number(quando));
  if (seg < 90) return "agora há pouco";
  const min = Math.floor(seg / 60);
  if (min < 60) return `há ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `há ${h}h`;
  return `há ${Math.floor(h / 24)}d`;
}

/** 🏘️ A aldeia: estágio, gente e o livro de Memórias.
 *
 *  Cada habitante é uma linha com o que DECIDE o que fazer com ele: quanto
 *  rende agora, quão cansado está e até onde o potencial deixa ele ir. O
 *  resto (xp exato, id) não entra — dado que não vira decisão é ruído na
 *  tela do celular. */
// 👥 AS EQUIPES (fase 1 do redesenho da aldeia, 20/09/2026)
// Coletar é fora da aldeia, num posto do andar, e a equipe só sai com guarda.
const ICONE_TALENTO = { agricultor: "🌾", lenhador: "🪵", cacador: "🦌", minerador: "⛏️",
                        guarda: "🛡️", curandeiro: "🩹" };
const ICONE_RECURSO_EQUIPE = { comida: "🌾", madeira: "🪵", couro: "🐂", ferro: "⛏️" };
const COLETA_DO_RECURSO = { comida: "agricultor", madeira: "lenhador", couro: "cacador", ferro: "minerador" };

function textoDosTalentos(t) {
  const partes = Object.entries(t || {}).filter(([, e]) => e > 0)
    .map(([p, e]) => `${ICONE_TALENTO[p] || p}${e}★`);
  return partes.length ? `Talentos: ${partes.join(" ")}` : "Sem talento nenhum";
}

function cartaoDaEquipe(eq, d) {
  const card = el("div", "ponto-mapa");
  card.appendChild(el("div", "habitante-nome", eq.recurso ? `${eq.nome} · ${ICONE_RECURSO_EQUIPE[eq.recurso] || ""} ${eq.recurso}` : eq.nome));
  const tem = eq.coletores.length && eq.guardas.length;
  card.appendChild(el("div", "habitante-sub", eq.especial === "cidade"
    ? `🛡️ ${eq.guardas.length} guarda(s) · poder ${eq.poder} — defendem o que a aldeia guarda. Sem eles, um ataque leva 20% do estoque.`
    : eq.ameaca === null
    ? `🧺 ${eq.coletores.length} coletor(es) · 🛡️ ${eq.guardas.length} guarda(s) · poder ${eq.poder} — é ela que marcha e defende o ponto`
    : tem
      ? `🧺 ${eq.coletores.length} coletor(es) · 🛡️ ${eq.guardas.length} guarda(s) · escolta ${eq.poder}/${eq.ameaca} · ~${eq.producao}/sessão`
      : `Sem equipe. Ameaça do andar: ${eq.ameaca} — mande guardas que somem isso.`));
  // ⏳ 12h por posto (25/09/2026): depois disso a equipe volta pra aldeia
  if (eq.restante_seg != null) {
    card.appendChild(el("div", "habitante-sub equipe-prazo", `⏳ volta pra aldeia em ${formatarEstadia(eq.restante_seg)}`));
  }
  if (tem && eq.ameaca !== null && eq.poder < eq.ameaca) {
    card.appendChild(el("div", "habitante-sub", "⚠️ Escolta fraca: rende menos e os coletores voltam cansados."));
  }
  const acoes = el("div", "habitante-acoes");
  const b = document.createElement("button");
  b.className = "botao-secundario";
  b.textContent = "👥 Abrir a equipe";
  b.onclick = () => { EQUIPE_ABERTA = eq.posto_id; EQUIPE_ADICIONANDO = null; irPara("clan_equipe"); };
  acoes.appendChild(b);
  if (tem) {
    const x = document.createElement("button");
    x.className = "botao-secundario";
    x.textContent = "🏠 Trazer de volta";
    x.onclick = async () => {
      try { await api("/api/clan/equipe", { method: "POST", body: JSON.stringify({ posto_id: eq.posto_id, desfazer: true }) });
        som.clique(); await recarregarClan(); }
      catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    };
    acoes.appendChild(x);
  }
  card.appendChild(acoes);
  return card;
}

// 👥 PÁGINA DE CADA EQUIPE (20/09, pedido do dev): escolher quem entra, com
// os de MAIS talento pra função primeiro, e mostrando quem já está em outra
// equipe (e um filtro pra esconder esses). O rascunho sobrevive ao filtro.
let EQUIPE_ABERTA = null;
let EQUIPE_SO_LIVRES = false;

async function renderClanEquipe() {
  const pg = await carregarPaginaDoClan("clan_equipe");
  if (!pg) return;
  const { c, d } = pg;
  const eq = (d.equipes || []).find((e) => e.posto_id === EQUIPE_ABERTA);
  const voltar = document.createElement("button");
  voltar.className = "botao-secundario";
  voltar.textContent = "← Postos";
  voltar.onclick = () => irPara("clan_postos");
  c.appendChild(voltar);
  if (!eq) { c.appendChild(estadoVazio("🔎", "Esse posto não está mais no andar do clã.")); return; }
  desenharEquipe(c, eq, d);
}

// A página da equipe (2ª versão, pedido do dev): primeiro QUEM ESTÁ nela,
// cada um com um botão de tirar; embaixo, "➕ Adicionar" abre a lista de
// candidatos (mais talento primeiro, filtro de livres). Cada toque já salva
// — no celular, marcar vários e depois lembrar de salvar é onde se perde.
let EQUIPE_ADICIONANDO = null;       // null | "coletores" | "guardas"

function melhorColeta(h) {
  return Math.max(...["agricultor", "lenhador", "cacador", "minerador"].map((p) => (h.talentos || {})[p] || 0));
}

async function salvarEquipe(eq, coletores, guardas, recurso = eq.recurso) {
  try {
    await api("/api/clan/equipe", { method: "POST", body: JSON.stringify({ posto_id: eq.posto_id,
      coletores: [...coletores], guardas: [...guardas], recurso }) });
    som.clique(); await recarregarClan();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

function desenharEquipe(c, eq, d) {
  const habs = (d.aldeia_viva && d.aldeia_viva.habitantes) || [];
  const porId = Object.fromEntries(habs.map((h) => [h.id, h]));
  const nomeDaEquipe = Object.fromEntries((d.equipes || []).map((e) => [e.posto_id, e.nome]));
  const doPonto = eq.especial === "ponto";
  const daCidade = eq.especial === "cidade";
  const prof = eq.recurso ? COLETA_DO_RECURSO[eq.recurso] : null;
  const estrelaColeta = (h) => (prof ? (h.talentos || {})[prof] || 0 : melhorColeta(h));

  c.appendChild(el("h3", "secao-titulo", eq.nome));
  c.appendChild(el("p", "texto-fraco", daCidade
    ? `Poder da guarnição: ${eq.poder}. Ela fica em casa e defende o estoque da aldeia: se um ataque `
      + "passar por ela, levam 20% de comida, madeira, couro e ferro."
    : doPonto
    ? `Poder dos guardas: ${eq.poder}${d.guarda_pessoal ? ` + ${d.guarda_pessoal} do seu personagem` : ""}. `
      + "Quem perde uma batalha pelo ponto tem os guardas mortos e os coletores levados."
      + (eq.so_guardas ? " 🔮 Este ponto só aceita guardas." : "")
    : `Escolta ${eq.poder}/${eq.ameaca} · ~${eq.producao}/sessão. Sem guarda ou sem coletor, a equipe não sai.`));

  // 🧺 25/09/2026 (dev): a equipe coleta QUALQUER recurso. No do posto ela
  // ganha o bônus das estrelas; fora dele, coleta sem bônus (0,7×).
  if (!doPonto && !daCidade && eq.recurso_do_posto) {
    c.appendChild(el("div", "habitante-sub", "O que coletar:"));
    const escolha = el("div", "membros-equipes");
    for (const r of ["comida", "madeira", "couro", "ferro"]) {
      const b = document.createElement("button");
      b.className = "filtro-chip" + (eq.recurso === r ? " ativo" : "");
      b.textContent = `${ICONE_RECURSO_EQUIPE[r]} ${r}${r === eq.recurso_do_posto ? " ★ posto" : ""}`;
      b.onclick = () => {
        if (r === eq.recurso) return;
        // quem não tem talento pro recurso novo sai da coleta; os guardas ficam
        const talento = COLETA_DO_RECURSO[r];
        const ficam = new Set((eq.coletores || []).filter((id) => ((porId[id] || {}).talentos || {})[talento] > 0));
        salvarEquipe(eq, ficam, new Set(eq.guardas || []), r);
      };
      escolha.appendChild(b);
    }
    c.appendChild(escolha);
    if (!eq.bonus_do_posto) {
      c.appendChild(el("p", "texto-fraco",
        `Coletando fora do tipo do posto: sem o bônus dele. Um posto de ${eq.recurso} rende mais.`));
    }
  }

  if (doPonto) {
    const conf = el("div", "habitante-acoes");
    for (const [id, rotulo] of [["lutar", "⚔️ Lutar quando atacado"], ["fugir", "🏃 Fugir (ninguém morre)"]]) {
      const b = document.createElement("button");
      b.className = d.defesa === id ? "botao-holofote" : "botao-secundario";
      b.textContent = rotulo;
      b.onclick = async () => {
        try { await api("/api/clan/defesa", { method: "POST", body: JSON.stringify({ defesa: id }) }); await recarregarClan(); }
        catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
      };
      conf.appendChild(b);
    }
    c.appendChild(conf);
    const g = document.createElement("button");
    g.className = d.de_guarda ? "botao-holofote" : "botao-secundario";
    g.style.cssText = "width:100%;margin-top:6px";
    g.textContent = d.de_guarda ? "🧍 Seu personagem está de guarda (sem Torre) — tirar" : "🧍 Pôr meu personagem de guarda";
    g.onclick = async () => {
      if (!d.de_guarda && !confirm("De guarda, seu personagem defende o ponto e NÃO entra na Torre até você tirá-lo. Seguir?")) return;
      try { await api("/api/clan/guarda_pessoal", { method: "POST", body: JSON.stringify({ ativo: !d.de_guarda }) }); await recarregarClan(); }
      catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    };
    c.appendChild(g);
  }

  // quem ESTÁ na equipe, por papel, com o botão de tirar
  const membros = (papel, titulo, estrela) => {
    const ids = eq[papel];
    c.appendChild(el("h3", "secao-titulo", `${titulo} (${ids.length})`));
    if (!ids.length) c.appendChild(el("p", "texto-fraco", "Ninguém ainda."));
    for (const id of ids) {
      const h = porId[id];
      if (!h) continue;
      const linha = el("div", "habitante-acoes");
      linha.appendChild(el("span", "habitante-sub", `${"★".repeat(estrela(h))} ${h.nome} · Nv.${h.nivel}/${h.nivel_max}`
        + (h.xp_proximo ? ` · ${h.xp}/${h.xp_proximo} XP` : " · no teto")));
      const x = document.createElement("button");
      x.className = "botao-secundario";
      x.textContent = "✖ Tirar";
      x.onclick = () => {
        const col = new Set(eq.coletores), gua = new Set(eq.guardas);
        (papel === "coletores" ? col : gua).delete(id);
        salvarEquipe(eq, col, gua);
      };
      linha.appendChild(x);
      c.appendChild(linha);
    }
    const add = document.createElement("button");
    add.className = EQUIPE_ADICIONANDO === papel ? "botao-holofote" : "botao-secundario";
    add.style.cssText = "width:100%;margin-top:4px";
    add.textContent = EQUIPE_ADICIONANDO === papel ? "Fechar a lista" : `➕ Adicionar ${papel}`;
    add.onclick = () => { EQUIPE_ADICIONANDO = EQUIPE_ADICIONANDO === papel ? null : papel; renderClanEquipeLocal(c, eq, d); };
    c.appendChild(add);
    if (EQUIPE_ADICIONANDO === papel) listaParaAdicionar(c, eq, d, papel, habs, nomeDaEquipe, estrela);
  };
  // guarnição da cidade e ponto de cores: só guardas
  if (!eq.so_guardas) membros("coletores", prof ? `🧺 Coletores (${ICONE_TALENTO[prof]})` : "🧺 Coletores", estrelaColeta);
  membros("guardas", "🛡️ Guardas", (h) => (h.talentos || {}).guarda || 0);
}

// Quem pode entrar: com talento (≥1★) pro papel, fora desta equipe, os de
// MAIS talento primeiro (depois nível); `soLivres` esconde quem já tem equipe.
function candidatosParaAdicionar(habs, eq, estrela, soLivres) {
  const ja = new Set([...eq.coletores, ...eq.guardas]);
  return habs
    .filter((h) => estrela(h) > 0 && !ja.has(h.id))
    .filter((h) => !soLivres || !h.equipe)
    .sort((a, b) => (estrela(b) - estrela(a)) || (b.nivel - a.nivel));
}

function listaParaAdicionar(c, eq, d, papel, habs, nomeDaEquipe, estrela) {
  const filtro = el("div", "habitante-acoes");
  for (const [so, rotulo] of [[false, "Todos"], [true, "Só quem está livre"]]) {
    const b = document.createElement("button");
    b.className = EQUIPE_SO_LIVRES === so ? "botao-holofote" : "botao-secundario";
    b.textContent = rotulo;
    b.onclick = () => { EQUIPE_SO_LIVRES = so; renderClanEquipeLocal(c, eq, d); };
    filtro.appendChild(b);
  }
  c.appendChild(filtro);
  const lista = candidatosParaAdicionar(habs, eq, estrela, EQUIPE_SO_LIVRES);
  if (!lista.length) c.appendChild(el("p", "texto-fraco", "Ninguém com talento pra isso" + (EQUIPE_SO_LIVRES ? " livre." : ".")));
  for (const h of lista) {
    const b = document.createElement("button");
    b.className = "botao-secundario";
    b.style.cssText = "width:100%;margin-top:4px;text-align:left";
    const onde = h.equipe ? ` · em: ${nomeDaEquipe[h.equipe] || "outra equipe"}` : " · livre";
    b.textContent = `➕ ${"★".repeat(estrela(h))} ${h.nome} · Nv.${h.nivel}${onde}`;
    b.onclick = () => {
      const col = new Set(eq.coletores), gua = new Set(eq.guardas);
      (papel === "coletores" ? col : gua).add(h.id);
      salvarEquipe(eq, col, gua);
    };
    c.appendChild(b);
  }
}

// Abrir/fechar a lista e trocar o filtro redesenham só a página, sem ir ao servidor.
function renderClanEquipeLocal(c, eq, d) {
  c.innerHTML = "";
  const voltar = document.createElement("button");
  voltar.className = "botao-secundario";
  voltar.textContent = "← Explorar andar";
  voltar.onclick = () => irPara("clan_postos");
  c.appendChild(voltar);
  desenharEquipe(c, eq, d);
}

/** 📖 Memórias e memorial da aldeia — foram pra página Histórico junto do
 *  resto do que já passou (a página Aldeia saiu em 25/09/2026). */
function memoriasDaAldeia(av) {
  const box = el("div");
  // Memórias do Clã: o livro. Diferente do diário (que guarda 5 sessões e
  // esquece), aqui fica o que marcou — com hora, pra virar história.
  if ((av.memorias || []).length) {
    box.appendChild(el("h3", "secao-titulo", "📖 Memórias do Clã"));
    for (const m of av.memorias.slice(0, 12)) {
      const l = el("div", "memoria");
      l.appendChild(el("div", "memoria-texto", m.texto));
      if (m.quando) l.appendChild(el("div", "texto-fraco", haQuantoTempo(m.quando)));
      box.appendChild(l);
    }
  }
  if ((av.memorial || []).length) {
    box.appendChild(el("h3", "secao-titulo", "🕯️ Memorial"));
    for (const m of av.memorial) {
      box.appendChild(el("div", "memoria", `Aqui repousa ${m.nome}, que ${m.causa || "partiu"}.`));
    }
  }
  return box;
}

async function acaoAldeia(rota, corpo) {
  try {
    await api(rota, { method: "POST", body: JSON.stringify(corpo) });
    som.clique();
    await recarregarClan();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function mudarHabitante(corpo) {
  try {
    await api("/api/clan/habitante/mudar", { method: "POST", body: JSON.stringify(corpo) });
    som.clique();
    await recarregarClan();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

function escolherProfissao(h, catalogo) {
  // Trocar ZERA o nível, e o aviso vem antes da escolha: um Geólogo Nv.12
  // que vira agricultor volta ao Nv.1, e ninguém deveria descobrir isso
  // depois de apertar.
  const opcoes = Object.entries(catalogo || {}).filter(([k]) => k !== h.profissao);
  const lista = opcoes.map(([k, v], i) => `${i + 1}. ${v.icone} ${v.nome}`).join("\n");
  const resp = prompt(`${h.nome} é ${h.titulo} Nv.${h.nivel}. Trocar de profissão ` +
                      `VOLTA pro Nv.1.\n\n${lista}\n\nNúmero da nova profissão:`);
  const idx = parseInt(resp, 10) - 1;
  if (!(idx >= 0 && idx < opcoes.length)) return;
  mudarHabitante({ id: h.id, profissao: opcoes[idx][0] });
}

function diarioDoAfk(afk, titulo) {
  const box = el("div", "clan-diario");
  box.appendChild(el("div", "clan-diario-titulo", titulo || "Enquanto você não estava"));
  // 🏘️ O que marcou a aldeia vem antes dos números: um despertar de Aura
  // ou uma morte num ataque é história, e história não pode ficar
  // embaixo de "48 de comida".
  const aldeia = afk.aldeia;
  if (aldeia && aldeia.frases && aldeia.frases.length) {
    const marcas = aldeia.frases.filter((f) => /✨|⚰️|🚶|🛡️|🩸|⭐/.test(f));
    for (const f of marcas.slice(0, 5)) box.appendChild(el("div", "clan-diario-marca", f));
  }
  if (afk.mortos.length) {
    for (const m of afk.mortos) {
      const morte = el("div", "clan-diario-morte");
      morte.appendChild(el("div", "clan-morto-nome", `${m.nome} não voltou`));
      // A conta inteira na tela. Com morte permanente, "ele morreu" sem o
      // porquê é arbitrário; com os números, é a aposta que você fez.
      morte.appendChild(el("div", "clan-morto-causa", m.causa || ""));
      box.appendChild(morte);
    }
  }
  const ganhos = [];
  if (afk.comida) ganhos.push(`${afk.comida} de comida`);
  if (afk.madeira) ganhos.push(`${afk.madeira} de madeira`);
  if (afk.couro) ganhos.push(`${afk.couro} de couro`);
  if (afk.ouro) ganhos.push(`${afk.ouro} de ouro`);
  for (const [rank, qtd] of Object.entries(afk.materiais || {})) {
    ganhos.push(`${qtd} de material rank ${rank}`);
  }
  box.appendChild(el("div", "clan-diario-linha",
    ganhos.length ? `O clã trouxe ${ganhos.join(" e ")}.` : "O clã não trouxe nada desta vez."));
  if (afk.saque && Object.keys(afk.saque).length) {
    box.appendChild(el("div", "clan-diario-linha", "🏚️ Atacaram a cidade e levaram " +
      Object.entries(afk.saque).map(([r, q]) => `${q} de ${r}`).join(", ") + " — faltou guarda em casa."));
  }
  if (afk.reliquia) {
    box.appendChild(el("div", "clan-diario-linha",
      `🏺 Desenterraram ${afk.reliquia.icone} ${afk.reliquia.nome}: ${afk.reliquia.texto}`));
  }
  if (afk.cores && afk.cores.length) {
    box.appendChild(el("div", "clan-diario-linha", `🔮 O Veio de Cores rendeu ${afk.cores.length} core(s) pro seu inventário.`));
  }
  // 🌾 A compra automática aparece no diário: ouro que sai sozinho da
  // carteira sem ninguém ver é o tipo de número que parece bug.
  if (afk.compra_auto) {
    box.appendChild(el("div", "clan-diario-linha",
      `🔁 Faltou comida: a compra automática trouxe ${afk.compra_auto.comprado} `
      + `por ${afk.compra_auto.custo_ouro} de ouro.`));
  }
  // A ração é a outra metade da conta. Sem ela, a comida era um número que
  // só subia e o Celeiro não tinha razão de existir.
  if (afk.racao > 0) {
    box.appendChild(el("div", "clan-diario-linha",
      `Quem estava em posto comeu ${afk.consumido} de ${afk.racao}.`));
  }
  if (afk.famintos && afk.famintos.length) {
    const nomes = afk.famintos.map((f) => f.nome).join(", ");
    const linha = el("div", "clan-diario-linha",
      `Não deu pra todo mundo: ${nomes} ${afk.famintos.length > 1 ? "ficaram" : "ficou"} `
      + "com fome e vai render menos na próxima. Colha em andar raso ou compre "
      + "mantimentos na aldeia.");
    linha.style.color = "#e07a5f";
    box.appendChild(linha);
  }
  if (afk.perdido > 0) {
    box.appendChild(el("div", "clan-diario-nota",
      `${afk.perdido} de comida estragou — o depósito encheu. O Celeiro aumenta o que cabe.`));
  }
  if (afk.descartados > 0) {
    // Dizer que o tempo extra não rendeu é mais honesto que deixar o
    // jogador achar que ficar fora mais tempo rende mais.
    box.appendChild(el("div", "clan-diario-nota",
      `Você ficou fora bastante tempo — o clã trabalhou ${afk.ticks} turnos e descansou o resto.`));
  }
  return box;
}

async function escolherArea(membro, areas) {
  som.clique();
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", `Onde ${membro.nome} fica?`));
  corpo.appendChild(el("p", "texto-fraco",
    "Ele trabalha aí enquanto você não está. Se morrer, morre de vez — "
    + "toque numa área para ver a chance antes de confirmar."));

  const semPosto = document.createElement("button");
  semPosto.className = "botao-secundario sheet-opcao";
  semPosto.textContent = "Deixar na cidade (não sai)";
  semPosto.onclick = async () => { await definirPosto(membro.slot, null); };
  corpo.appendChild(semPosto);

  for (const a of areas) {
    const linha = document.createElement("button");
    linha.className = "linha-lista";
    const texto = el("div", "linha-lista-texto");
    texto.appendChild(el("div", "linha-lista-titulo",
      `${a.nome} — ${a.rank_nome}`));
    texto.appendChild(el("div", "linha-lista-sub",
      `rende ${a.rende} de ${ICONE_RECURSO[a.recurso] || ""} ${a.recurso === "metal" ? "metal rank " + a.rank : a.recurso}`));
    linha.appendChild(texto);
    linha.appendChild(el("span", "linha-lista-seta", "›"));
    linha.onclick = () => verPrevisao(membro, a);
    corpo.appendChild(linha);
  }
  abrirSheet(corpo);
}

async function verPrevisao(membro, area) {
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", `${membro.nome} no ${area.nome}`));
  const carregando = el("p", "texto-fraco", "Calculando o risco...");
  corpo.appendChild(carregando);
  abrirSheet(corpo);

  let r;
  try {
    r = await api(`/api/clan/previsao?slot=${membro.slot}&area_id=${encodeURIComponent(area.id)}`);
  } catch (e) { carregando.textContent = e.message || "Não consegui calcular."; return; }

  carregando.remove();
  const perfil = r.perfil;
  const destaque = el("div", perfil.chance_morte > 30 ? "engaste-alerta" : "clan-previsao");
  // A frase antes do número: "morre se esbarrar no chefe" se entende, "3,2%"
  // não diz nada sobre o que acontece lá fora.
  destaque.appendChild(el("div", "clan-previsao-frase", perfil.resumo));
  destaque.appendChild(el("div", "clan-previsao-num",
    `${perfil.chance_morte}% de morrer a cada encontro`));
  corpo.appendChild(destaque);

  for (const e of perfil.encontros) {
    const l = el("div", "clan-encontro");
    l.appendChild(el("span", "clan-encontro-nome",
      (e.chefe ? "Chefe do andar " : "Monstro do andar ") + e.andar));
    const res = { vence: "vence", recua: "recua ferido", morre: "MORRE" }[e.resultado];
    const tag = el("span", "clan-encontro-res clan-res-" + e.resultado, res);
    l.appendChild(tag);
    corpo.appendChild(l);
  }

  const confirmar = document.createElement("button");
  confirmar.className = perfil.chance_morte > 30 ? "botao-secundario" : "botao-holofote";
  confirmar.style.cssText = "width:100%;margin-top:14px";
  confirmar.textContent = perfil.chance_morte > 0
    ? `Mandar mesmo assim (${perfil.chance_morte}%)` : "Mandar";
  confirmar.onclick = async () => {
    if (perfil.chance_morte > 30 &&
        !confirm(`${membro.nome} tem ${perfil.chance_morte}% de morrer a cada encontro aí. `
                 + "Morte é permanente. Confirmar?")) return;
    await definirPosto(membro.slot, area.id);
  };
  corpo.appendChild(confirmar);
}

async function definirPosto(slot, areaId) {
  try {
    await api("/api/clan/posto", {
      method: "POST", body: JSON.stringify({ slot, area_id: areaId }) });
    som.clique();
    fecharSheet();
    await recarregarClan();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

// 25/09/2026: a Forja e as construções moram na página do Ferreiro
// (desenha dentro de `destino`); sem destino, ainda abre como folha.
function abrirOficina(d, destino) {
  const inline = destino instanceof Element;
  if (!inline) som.clique();
  const corpo = inline ? destino : el("div");
  corpo.appendChild(el("h3", "secao-titulo", "🔨 Forja"));
  corpo.appendChild(el("p", "texto-fraco",
    "Equipamento sobe o poder do membro — e poder é o que decide até onde "
    + "ele consegue ir sem morrer. A peça vai pro arsenal do clã e é "
    + "distribuída sozinha: a melhor fica com o melhor guerreiro, e isso é "
    + "refeito toda sessão."));
  for (const m of d.materiais) {
    const linha = document.createElement("button");
    linha.className = "linha-lista";
    const texto = el("div", "linha-lista-texto");
    texto.appendChild(el("div", "linha-lista-titulo", `Equipamento ${m.nome}`));
    texto.appendChild(el("div", "linha-lista-sub", `você tem ${m.qtd} de rank ${m.rank}`));
    linha.appendChild(texto);
    linha.appendChild(el("span", "linha-lista-seta", "🔨"));
    linha.onclick = async () => {
      try {
        const r = await api("/api/clan/forjar", {
          method: "POST", body: JSON.stringify({ rank: m.rank }) });
        som.moeda(); toast(r.msg); fecharSheet(); await recarregarClan();
      } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    };
    corpo.appendChild(linha);
  }

  corpo.appendChild(el("h3", "secao-titulo", "🏗️ Construções"));
  for (const [chave, com] of Object.entries(d.catalogo_comodidades)) {
    // 🏠 (25/09) por níveis (Moradias): mostra o nível, o que já dá e o
    // preço do PRÓXIMO; só "fecha" no nível máximo.
    const bruto = d.comodidades[chave];
    const nivel = bruto === true ? 1 : Number(bruto || 0);
    const feita = com.niveis ? nivel >= (com.nivel_max || 20) : !!bruto;
    const madeira = com.niveis ? com.madeira_por_nivel * (nivel + 1) : com.madeira;
    const metal = com.niveis ? com.custo_por_nivel * (nivel + 1) : com.custo;
    const linha = document.createElement("button");
    linha.className = "linha-lista" + (feita ? " trancado" : "");
    const texto = el("div", "linha-lista-texto");
    const custoTexto = madeira
      ? `${madeira} 🪵  +  ${metal} ⛏️ rank ${com.rank}`
      : `${metal} ⛏️ rank ${com.rank}`;
    const titulo = com.niveis
      ? `${com.nome} Nv.${nivel}/${com.nivel_max}` + (feita ? "  ·  máximo" : `  —  ${custoTexto} → +${com.valor}`)
      : com.nome + (feita ? "  ·  construída" : `  —  ${custoTexto}`);
    texto.appendChild(el("div", "linha-lista-titulo", titulo));
    if (com.niveis && nivel > 0) {
      texto.appendChild(el("div", "linha-lista-sub", `Já dá +${com.valor * nivel} no limite de aldeões.`));
    }
    // A razão de existir vai na tela, não só no código. Construção sem
    // motivo claro é material parado.
    texto.appendChild(el("div", "linha-lista-sub", com.porque));
    linha.appendChild(texto);
    linha.appendChild(el("span", "linha-lista-seta", feita ? "✓" : "›"));
    if (!feita) {
      linha.onclick = async () => {
        try {
          const r = await api("/api/clan/construir", {
            method: "POST", body: JSON.stringify({ comodidade: chave }) });
          som.moeda(); toast(r.msg); fecharSheet(); await recarregarClan();
        } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
      };
    }
    corpo.appendChild(linha);
  }
  if (!inline) abrirSheet(corpo);
}


// ---------- 🔑 conta ----------
// Trocar senha e sair moravam na folha que o botão da barra abria. Com o
// botão levando direto pra tela, eles ficariam sem casa — e some justo o
// caminho de quem precisa resolver um problema de acesso.
async function renderConta() {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  c.appendChild(el("h3", "secao-titulo", "🔑 Conta"));

  if (!pegarToken()) {
    c.appendChild(estadoVazio("🔑", "Entre com a sua conta pra ver as opções dela."));
    return;
  }

  let info = null;
  try { info = await api("/api/auth/eu"); } catch (e) { /* segue sem */ }
  if (info && info.convidado) {
    // 🎮 (28/09, dev) convidado: salvar = dar usuário e senha à MESMA conta
    CONVIDADO = true;
    const caixa = el("div", "aldeia-box");
    caixa.appendChild(el("div", "aldeia-estagio", "🎮 Você está jogando como convidado"));
    caixa.appendChild(el("p", "texto-fraco",
      "O seu progresso está preso a este navegador. Se limpar os dados, trocar de aparelho ou sair da conta, "
      + "o personagem se perde. Crie um usuário e uma senha pra guardar tudo — nada muda de lugar."));
    const u = document.createElement("input");
    u.className = "sheet-input"; u.type = "text"; u.autocapitalize = "off"; u.spellcheck = false;
    u.autocomplete = "username"; u.placeholder = "Usuário";
    const sn = document.createElement("input");
    sn.className = "sheet-input"; sn.type = "password"; sn.autocomplete = "new-password"; sn.placeholder = "Senha";
    const erro = el("div", "portao-erro");
    const salvar = document.createElement("button");
    salvar.className = "botao-holofote"; salvar.style.cssText = "width:100%;margin-top:8px";
    salvar.textContent = "💾 Salvar progresso";
    salvar.onclick = async () => {
      erro.textContent = "";
      if (!u.value.trim() || !sn.value) { erro.textContent = "Preencha usuário e senha."; return; }
      salvar.disabled = true; salvar.textContent = "Salvando...";
      try {
        const r = await api("/api/auth/converter", {
          method: "POST", body: JSON.stringify({ usuario: u.value.trim(), senha: sn.value }) });
        CONVIDADO = false;
        som.moeda();
        notificacaoGrande("💾", r.usuario, "Progresso salvo — entre com esse usuário em qualquer aparelho");
        await renderConta();
      } catch (e) {
        erro.textContent = e.message || "Não deu. Tente de novo.";
        salvar.disabled = false; salvar.textContent = "💾 Salvar progresso";
      }
    };
    caixa.append(u, sn, el("p", "portao-dica portao-atencao", "⚠️ Anote a senha. Não existe recuperação por e-mail."),
                 salvar, erro);
    c.appendChild(caixa);
  } else if (info) {
    c.appendChild(el("p", "texto-fraco",
      "Conta do site."));
  }

  const trocar = document.createElement("button");
  trocar.className = "botao-holofote";
  trocar.style.cssText = "width:100%;margin-bottom:8px";
  trocar.textContent = "🔑 Trocar senha";
  trocar.onclick = abrirTrocarSenha;
  if (!(info && info.convidado)) c.appendChild(trocar);   // convidado não tem senha pra trocar

  const sair = document.createElement("button");
  sair.className = "botao-secundario";
  sair.style.cssText = "width:100%";
  sair.textContent = "🚪 Sair da conta";
  sair.onclick = sairDaConta;
  c.appendChild(sair);
}


function abrirTrocarSenha() {
  som.clique();
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", "🔑 Trocar senha"));
  corpo.appendChild(el("p", "texto-fraco",
    "Trocar a senha encerra suas outras sessões — é o único jeito de expulsar "
    + "quem já esteja dentro com a senha antiga."));

  const atual = document.createElement("input");
  atual.className = "sheet-input"; atual.type = "password";
  atual.autocomplete = "current-password"; atual.placeholder = "Senha atual";
  const nova = document.createElement("input");
  nova.className = "sheet-input"; nova.type = "password";
  nova.autocomplete = "new-password"; nova.placeholder = "Senha nova";
  const repete = document.createElement("input");
  repete.className = "sheet-input"; repete.type = "password";
  repete.autocomplete = "new-password"; repete.placeholder = "Repita a senha nova";
  corpo.append(atual, nova, repete);
  corpo.appendChild(el("p", "portao-dica portao-atencao",
    "⚠️ Anote a senha nova. Não existe recuperação por e-mail."));

  const erro = el("div", "portao-erro");
  const botao = document.createElement("button");
  botao.className = "botao-holofote sheet-opcao";
  botao.textContent = "Trocar senha";
  botao.onclick = async () => {
    erro.textContent = "";
    // A repetição existe por causa do teclado de celular: sem recuperação
    // por e-mail, um erro de digitação trancaria a conta pra sempre.
    if (!atual.value || !nova.value) { erro.textContent = "Preencha os dois campos de senha."; return; }
    if (nova.value !== repete.value) { erro.textContent = "As duas senhas novas não batem."; return; }
    botao.disabled = true; botao.textContent = "Trocando...";
    try {
      const r = await api("/api/auth/trocar-senha", {
        method: "POST",
        body: JSON.stringify({ senha_atual: atual.value, senha_nova: nova.value }),
      });
      som.moeda(); fecharSheet(); toast(r.aviso || "Senha trocada.");
    } catch (e) {
      erro.textContent = e.message || "Não consegui trocar a senha.";
      botao.disabled = false; botao.textContent = "Trocar senha";
    }
  };
  corpo.append(botao, erro);
  abrirSheet(corpo);
}


/** Os caminhos irmãos da tela atual, em grade, no fim da página.
 *
 *  Substituiu a folha que abria pelo botão da barra. Duas razões:
 *  o menu em folha custava um toque a mais e tapava a tela que você
 *  acabou de abrir; e como grade, os destinos ficam visíveis enquanto
 *  você lê a página — a navegação para de ser um lugar aonde se vai e
 *  passa a ser parte da própria tela.
 *
 *  A atual aparece marcada e não é clicável: botão que leva pra onde
 *  você já está é ruído.
 */
function gradeDeCaminhos(tela) {
  const grupoId = GRUPO_DA_TELA[tela];
  const grupo = GRUPOS_MENU.find((g) => g.id === grupoId);
  if (!grupo || grupo.telas.length < 2) return null;

  const bloco = el("div", "caminhos");
  bloco.appendChild(el("div", "caminhos-titulo", grupo.icone + "  " + grupo.titulo));
  const grade = el("div", "caminhos-grade");

  for (const t of grupo.telas) {
    const atual = t.tela === tela;
    const trancada = TELAS_DA_CIDADE.has(t.tela) && FORA_DA_CIDADE;
    const item = document.createElement("button");
    item.className = "caminho" + (atual ? " atual" : "") + (trancada ? " trancado" : "")
      + (telaTemPendencia(t.tela) ? " tem-pendencia" : "");
    item.dataset.tela = t.tela;
    item.appendChild(el("span", "caminho-nome", t.rotulo));
    if (t.sub) item.appendChild(el("span", "caminho-sub", t.sub));
    if (trancada) item.appendChild(el("span", "caminho-cadeado", "🔒"));
    if (atual) {
      item.disabled = true;
    } else {
      item.onclick = () => { som.clique(); irPara(t.tela); };
    }
    grade.appendChild(item);
  }
  bloco.appendChild(grade);
  return bloco;
}


// 🐛 25/09/2026: "os botões do fim da página somem de vez em quando". A
// grade só era posta pelo irPara, depois da tela montar — e 46 lugares
// REDESENHAM a tela chamando a render direto (página da lista de membros,
// resgatar missão, vender personagem, trocar aba do ranking...): limpavam
// o #conteudo e montavam de novo SEM a grade. Agora um vigia no #conteudo
// garante a grade da tela atual, sempre por último, depois de qualquer
// redesenho — inclusive de pedaço que chega atrasado (await) depois dela.
let _gradeAgendada = 0;
function garantirGradeDeCaminhos() {
  const c = document.getElementById("conteudo");
  if (!c || !TELA_ATUAL || !c.children.length) return;
  if (c.querySelector(":scope > .esqueleto-bloco")) return;   // ainda carregando
  let bloco = c.querySelector(":scope > .caminhos");
  if (bloco && bloco.dataset.tela !== TELA_ATUAL) { bloco.remove(); bloco = null; }
  if (!bloco) {
    bloco = gradeDeCaminhos(TELA_ATUAL);
    if (!bloco) return;
    bloco.dataset.tela = TELA_ATUAL;
    c.appendChild(bloco);
    return;
  }
  if (c.lastElementChild !== bloco) c.appendChild(bloco);  // volta pro fim
}
function vigiarGradeDeCaminhos() {
  const c = document.getElementById("conteudo");
  if (!c || c._vigiaGrade || typeof MutationObserver === "undefined") return;
  c._vigiaGrade = new MutationObserver(() => {
    cancelAnimationFrame(_gradeAgendada);
    _gradeAgendada = requestAnimationFrame(garantirGradeDeCaminhos);
  });
  c._vigiaGrade.observe(c, { childList: true });
}
if (typeof document !== "undefined" && document.addEventListener) {
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", vigiarGradeDeCaminhos);
  else vigiarGradeDeCaminhos();
}

// abrirGrupo() foi removida em 11/09/2026. Ela abria uma folha com a lista
// do grupo; agora o botão da barra leva direto pra tela e os caminhos
// irmãos ficam em grade no fim da página. Deixar a função aqui sem ninguém
// chamar seria exatamente o código morto que a varredura deste projeto vive
// achando.

// ---------- estado cidade / fora da cidade ----------
let FORA_DA_CIDADE = false;
let EM_COMBATE = false;
let CUSTO_VOLTA = 0;

async function checarEstadoCidade() {
  try {
    const r = await api("/api/cidade/estado");
    FORA_DA_CIDADE = !r.na_cidade;
    EM_COMBATE = !!r.em_combate;
    CUSTO_VOLTA = r.custo_volta || 0;
    const barra = document.getElementById("barra-abas");
    barra?.classList.toggle("fora-da-cidade", FORA_DA_CIDADE);
  } catch (e) { /* não impede jogar */ }
}

function botaoVoltarCidade() {
  const botao = document.createElement("button");
  botao.className = "botao-holofote";
  botao.style.cssText = "width:100%;margin-bottom:12px";
  botao.textContent = `Voltar para a cidade — ${CUSTO_VOLTA}💰`;
  botao.onclick = async () => {
    botao.disabled = true;
    botao.textContent = "Teleportando...";
    try {
      const r = await api("/api/cidade/voltar", { method: "POST" });
      som.moeda();
      fecharSheet();
      toast(r.msg.replace(/<[^>]+>/g, ""));
      atualizarTopo({ gold: r.gold });
      await checarEstadoCidade();
      await irPara("loja");   // a Praça saiu; a Loja é a 1ª porta da Cidade
    } catch (e) {
      som.erro();
      if (!e.jaAlertado) toast(e.message, true);
      botao.disabled = false;
      botao.textContent = `Voltar para a cidade — ${CUSTO_VOLTA}💰`;
    }
  };
  return botao;
}

/** Chamado quando o servidor devolve 409 de fora-da-cidade. Vira folha com o
 *  preço e o botão, em vez de um toast que some e não resolve nada. */
function mostrarPortaoCidade(info) {
  FORA_DA_CIDADE = true;
  EM_COMBATE = !!info.em_combate;
  CUSTO_VOLTA = info.custo || CUSTO_VOLTA;
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", "🏙️ Você não está na cidade"));
  corpo.appendChild(el("p", "", info.msg || ""));
  if (info.em_combate) {
    corpo.appendChild(el("p", "texto-fraco",
      "Vença, fuja ou morra — enquanto a luta existir, não há teleporte."));
  } else if (info.pode_pagar === false) {
    corpo.appendChild(el("p", "texto-fraco",
      `Você tem ${info.gold ?? 0}💰 e o teleporte custa ${info.custo}💰. `
      + "Dá pra juntar subindo a Torre ou vendendo cores."));
  } else {
    corpo.appendChild(botaoVoltarCidade());
  }
  abrirSheet(corpo);
}


// ---------- 🌿 trilhas: distribuir pontos ----------
// `spend_trail_point` sempre esteve no motor, mas não tinha rota nem tela.
// Os pontos acumulavam sem lugar pra gastar.
//
// A barreira do passo 5 é o que essa tela precisa deixar claro: ali é
// obrigatório escolher um secundário, e é escolha DEFINITIVA pra aquela
// trilha. Gastar em lote freia na barreira e devolve o resto dos pontos —
// nada é queimado numa escolha que ninguém fez.
async function renderTrilhas() {
  const c = document.getElementById("conteudo");
  mostrarEsqueleto();
  let d;
  try { d = await api("/api/trilhas"); }
  catch (e) { c.innerHTML = ""; if (!e.jaAlertado) toast(e.message, true); return; }
  desenharTrilhas(d);
}

function desenharTrilhas(d) {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  c.appendChild(el("h3", "secao-titulo", "🌿 Trilhas"));

  const saldo = el("div", "trilha-saldo");
  saldo.appendChild(el("div", "trilha-saldo-valor", String(d.pontos)));
  saldo.appendChild(el("div", "trilha-saldo-rotulo",
    d.pontos === 1 ? "ponto para distribuir" : "pontos para distribuir"));
  c.appendChild(saldo);

  if (!d.pontos) {
    c.appendChild(el("p", "texto-fraco",
      "Pontos de trilha vêm de subir de nível. Suba a Torre e volte aqui."));
  }

  for (const t of d.trilhas) {
    const cartao = el("div", "trilha-cartao");

    const topo = el("div", "trilha-topo");
    topo.appendChild(el("div", "trilha-nome", t.nome));
    topo.appendChild(el("div", "trilha-ciclo", `Ciclo ${t.ciclos} · passo ${t.passo}/10`));
    cartao.appendChild(topo);

    // Dez marcas em vez de barra contínua: o que importa aqui é contar
    // passos, e passo é coisa discreta. A do meio é a barreira.
    const passos = el("div", "trilha-passos");
    for (let i = 1; i <= 10; i++) {
      const marca = el("span", "trilha-passo"
        + (i <= t.passo ? " feito" : "")
        + (i === 5 ? " barreira" : ""));
      passos.appendChild(marca);
    }
    cartao.appendChild(passos);

    cartao.appendChild(el("div", "trilha-sec",
      t.sec_nome ? `Secundário: ${t.sec_nome}` : "Secundário ainda não escolhido"));

    if (t.precisa_escolher) {
      const aviso = el("div", "engaste-alerta");
      aviso.textContent = "Passo 5: escolha o secundário para seguir. A escolha vale para sempre nesta trilha.";
      cartao.appendChild(aviso);
      const opcoes = el("div", "trilha-opcoes");
      for (const o of t.opcoes_sec) {
        const b = document.createElement("button");
        b.className = "botao-secundario";
        b.textContent = o.nome;
        b.onclick = () => escolherSecundario(t, o);
        opcoes.appendChild(b);
      }
      cartao.appendChild(opcoes);
    } else {
      const acoes = el("div", "trilha-acoes");
      for (const qtd of [1, 5, d.pontos]) {
        if (qtd < 1 || (qtd === 5 && d.pontos < 5) || (qtd === d.pontos && d.pontos <= 5)) continue;
        const b = document.createElement("button");
        b.className = qtd === 1 ? "botao-holofote" : "botao-secundario";
        b.textContent = qtd === d.pontos ? `Gastar tudo (${qtd})` : `+${qtd}`;
        b.disabled = d.pontos < qtd;
        b.onclick = () => gastarTrilha(t, qtd);
        acoes.appendChild(b);
      }
      if (!acoes.children.length) {
        const b = document.createElement("button");
        b.className = "botao-holofote";
        b.textContent = "+1";
        b.disabled = true;
        acoes.appendChild(b);
      }
      cartao.appendChild(acoes);
    }
    c.appendChild(cartao);
  }
}

async function gastarTrilha(t, quantidade, sec) {
  try {
    const r = await api("/api/trilhas/gastar", {
      method: "POST",
      body: JSON.stringify({ trilha: t.id, quantidade, ...(sec ? { sec } : {}) }),
    });
    if (!r.ok && !r.precisa_escolher) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
    som.moeda();
    if (r.msg) toast(r.msg.replace(/<[^>]+>/g, ""));
    desenharTrilhas(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

function escolherSecundario(t, opcao) {
  // Confirmação explícita: esta é definitiva por trilha, igual classe e raça.
  if (!confirm(`Escolher ${opcao.nome} como secundário de ${t.nome}? Não dá pra trocar depois.`)) return;
  gastarTrilha(t, 1, opcao.id);
}


// ---------- 🧪 poção e 🤖 autobatalha ----------
// Os dois eram VENDIDOS na Loja do site e não tinham como ser usados. A
// poção ficava guardada; a Autobatalha custava 500⭐ de dinheiro real e não
// ligava nada. Aqui eles ganham botão.
let AUTOBATALHA_ATIVA = false;

async function checarAutobatalha() {
  try {
    const r = await api("/api/combate/auto/status");
    AUTOBATALHA_ATIVA = !!r.ativa;
  } catch (e) { AUTOBATALHA_ATIVA = false; }
}

async function usarPocao(aoTerminar) {
  try {
    const r = await api("/api/combate/pocao", { method: "POST" });
    if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
    som.moeda();
    toast(`${r.msg.replace(/<[^>]+>/g, "")} (${r.potions} restantes)`);
    if (aoTerminar) await aoTerminar();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

/** Botões de ação que valem em qualquer luta. Recebem o callback que
 *  redesenha a tela — cada modo de combate redesenha de um jeito. */
function botoesDeApoio(aoTerminar, pocoes) {
  const linha = el("div", "combate-apoio");

  const pocao = document.createElement("button");
  pocao.className = "botao-secundario";
  // Quantidade no próprio rótulo: sem isso o jogador toca pra descobrir que
  // não tem nenhuma, e descobrir por erro é o pior jeito de saber.
  pocao.textContent = `🧪 Poção (${pocoes ?? 0})`;
  pocao.disabled = !pocoes;
  pocao.onclick = () => usarPocao(aoTerminar);
  linha.appendChild(pocao);

  if (AUTOBATALHA_ATIVA) {
    const auto = document.createElement("button");
    auto.className = "botao-secundario";
    auto.textContent = "🤖 Autobatalha";
    auto.onclick = async () => {
      auto.disabled = true;
      auto.textContent = "Resolvendo...";
      try {
        // A resposta é o MESMO snapshot que o ataque devolve (inclusive
        // explorar/onda). Passa ela adiante: pedir o combate de novo
        // depois da vitória dá 400, e era isso que prendia a tela no
        // começo da luta.
        const r = await api("/api/combate/auto", { method: "POST" });
        som.clique();
        if (r.log_auto) toast(r.log_auto.replace(/<[^>]+>/g, "").slice(0, 160));
        if (aoTerminar) await aoTerminar(r);
      } catch (e) {
        som.erro();
        if (!e.jaAlertado) toast(e.message, true);
        auto.disabled = false; auto.textContent = "🤖 Autobatalha";
      }
    };
    linha.appendChild(auto);
  }
  return linha;
}


// ---------- 📚 aprender e re-rolar skills ----------
// As duas existiam só no bot. Sem elas, as cores de skill que caem no jogo
// não tinham onde ser trocadas por habilidade.
async function aprenderSkill(coreId, nome, aoTerminar) {
  try {
    const r = await api("/api/skills/aprender", {
      method: "POST", body: JSON.stringify({ core: coreId }) });
    (r.ok ? som.moeda : som.erro)();
    toast(r.msg.replace(/<[^>]+>/g, ""), !r.ok);
    if (r.ok && aoTerminar) await aoTerminar();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function rerolarSkill(skillId, nome, aoTerminar) {
  // Aposta explícita: o motor diz que pode sair PIOR, então a tela diz
  // também. Esconder isso faria o jogador gastar 500g achando que é upgrade.
  if (!confirm(
    `Re-rolar os bônus de ${nome}?\n\n`
    + "Custa 500💰 e 1 core dela. O resultado pode sair MELHOR ou PIOR — "
    + "é aposta, e não tem como voltar atrás."
  )) return;
  try {
    const r = await api("/api/skills/rerolar", {
      method: "POST", body: JSON.stringify({ skill: skillId }) });
    (r.ok ? som.forja || som.moeda : som.erro)();
    toast(r.msg.replace(/<[^>]+>/g, ""), !r.ok);
    if (r.ok) {
      atualizarTopo({ gold: r.gold });
      if (aoTerminar) await aoTerminar();
    }
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

// ---------- 🐴 fundir montarias ----------
async function fundirMontaria(mountId, nome, aoTerminar) {
  if (!confirm(`Fundir ${nome}? As montarias usadas na fusão somem.`)) return;
  try {
    const r = await api("/api/estabulo/fundir", {
      method: "POST", body: JSON.stringify({ montaria: mountId }) });
    (r.ok ? som.moeda : som.erro)();
    toast(r.msg.replace(/<[^>]+>/g, ""), !r.ok);
    if (r.ok && aoTerminar) await aoTerminar();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

// ---------- 🚪 fugir da raid ----------
// Quem entrasse numa sala pelo site ficava preso até a raid acabar.
async function fugirDaRaid(aoTerminar) {
  if (!confirm(
    "Sair da raid agora?\n\n"
    + "Você perde a parte que teria nas recompensas desta sala."
  )) return;
  try {
    const r = await api("/api/raid/fugir", { method: "POST" });
    (r.ok ? som.clique : som.erro)();
    toast(r.msg.replace(/<[^>]+>/g, ""), !r.ok);
    if (r.ok) { if (aoTerminar) await aoTerminar(); else await irPara("raid"); }
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}


// ---------- toast ----------
function toast(msg, ehErro = false) {
  const t = el("div", "toast" + (ehErro ? " erro" : ""), msg);
  document.body.appendChild(t);
  requestAnimationFrame(() => t.classList.add("mostrar"));
  setTimeout(() => { t.classList.remove("mostrar"); setTimeout(() => t.remove(), 300); }, 2600);
}

// ---------- número animado + flutuante ----------
function animarNumero(elemento, valorNovo, formatarFn, duracaoMs = 700) {
  const valorAntigo = elemento._valorAtual ?? valorNovo;
  if (valorAntigo === valorNovo) { elemento.textContent = formatarFn(valorNovo); elemento._valorAtual = valorNovo; return; }
  if (valorNovo !== valorAntigo) mostrarNumeroFlutuante(elemento, valorNovo - valorAntigo);
  const inicio = performance.now();
  function passo(agora) {
    const progresso = Math.min((agora - inicio) / duracaoMs, 1);
    const facilitado = 1 - Math.pow(1 - progresso, 3);
    const valorAtual = Math.round(valorAntigo + (valorNovo - valorAntigo) * facilitado);
    elemento.textContent = formatarFn(valorAtual);
    if (progresso < 1) requestAnimationFrame(passo); else elemento._valorAtual = valorNovo;
  }
  requestAnimationFrame(passo);
}
function mostrarNumeroFlutuante(elemento, delta) {
  if (Math.abs(delta) < 1) return;
  const rect = elemento.getBoundingClientRect();
  const f = el("span", "numero-flutuante" + (delta > 0 ? " positivo" : " negativo"),
               (delta > 0 ? "+" : "") + Math.round(delta).toLocaleString("pt-BR"));
  f.style.left = `${rect.left + rect.width / 2}px`;
  f.style.top = `${rect.top}px`;
  document.body.appendChild(f);
  setTimeout(() => f.remove(), 1100);
}

// ---------- confete + flash dourado ----------
// (26/09/2026) o efeito de confete saiu, a pedido do dev.
function flashDourado() {
  const f = el("div", "flash-dourado");
  document.body.appendChild(f);
  setTimeout(() => f.remove(), 700);
}

// ---------- notificação grande — pra momentos que merecem mais destaque que
// um toast comum: subir de nível, forjar, evoluir pet, invocar algo raro.
// Some sozinha depois de ~2s (a animação de saída já está no CSS).
let NOTIFICACAO_GRANDE_ATIVA = null;
function notificacaoGrande(icone, titulo, subtitulo = "") {
  if (NOTIFICACAO_GRANDE_ATIVA) NOTIFICACAO_GRANDE_ATIVA.remove();
  const overlay = el("div", "notificacao-grande-overlay");
  const card = el("div", "notificacao-grande");
  card.appendChild(el("div", "notificacao-grande-icone", icone));
  card.appendChild(el("div", "notificacao-grande-titulo", titulo));
  if (subtitulo) card.appendChild(el("div", "notificacao-grande-sub", subtitulo));
  overlay.appendChild(card);
  document.body.appendChild(overlay);
  NOTIFICACAO_GRANDE_ATIVA = overlay;
  vibrar("sucesso");
  setTimeout(() => { overlay.remove(); if (NOTIFICACAO_GRANDE_ATIVA === overlay) NOTIFICACAO_GRANDE_ATIVA = null; }, 2000);
}


// ===========================================================
// 🎁 JANELA DE RECOMPENSA (28/09, dev): "uma janela de notificação bem
// bonita pra quando dropa XP e cores depois da batalha, e pro clã quando
// fico AFK — um botão de receber recompensa e aí a janela com o que se
// conseguiu". Duas formas:
//   - leve (fim da luta): no topo, some sozinha em 1,5s; enquanto está na
//     tela BLOQUEIA o fundo (pedido do dev) — um toque só fecha ela antes;
//   - cheia (clã): no centro, fundo escuro, botão pra fechar.
let JANELA_RECOMPENSA = null;
let ULTIMA_RECOMPENSA_ID = null;

function fecharJanelaRecompensa() {
  const j = JANELA_RECOMPENSA;
  if (!j) return;
  JANELA_RECOMPENSA = null;
  clearTimeout(j._timer);
  j.classList.add("saindo");
  setTimeout(() => { j.remove(); if (j._aoFechar) j._aoFechar(); }, 220);
}

function janelaRecompensa({ icone = "🎁", titulo, sub = "", itens = [], gastos = [], dica = "",
                            nivel = null, botao = "Fechar", leve = false, autoFechar = 0, aoFechar = null }) {
  if (JANELA_RECOMPENSA) { JANELA_RECOMPENSA._aoFechar = null; JANELA_RECOMPENSA.remove(); JANELA_RECOMPENSA = null; }
  const overlay = el("div", "recomp-overlay" + (leve ? " leve" : ""));
  const card = el("div", "recomp-card");
  const caixa = el("div", "recomp-icone-caixa");
  caixa.append(el("div", "recomp-raios"), el("div", "recomp-icone", icone));
  card.appendChild(caixa);
  card.appendChild(el("div", "recomp-titulo", titulo));
  if (sub) card.appendChild(el("div", "recomp-sub", sub));
  if (nivel) card.appendChild(el("div", "recomp-nivel", `⬆️ Nível ${nivel}!`));
  if (itens.length) {
    const lista = el("div", "recomp-lista");
    itens.forEach((it, i) => {
      const linha = el("div", "recomp-item" + (it.raro ? " raro" : "") + (it.ruim ? " ruim" : ""));
      linha.style.setProperty("--i", i);
      linha.append(el("span", "recomp-item-icone", it.icone || "•"), el("span", "recomp-item-texto", it.texto || ""));
      if (it.valor) linha.appendChild(el("span", "recomp-item-valor", it.valor));
      lista.appendChild(linha);
    });
    card.appendChild(lista);
  }
  if (gastos.length) {
    card.appendChild(el("div", "recomp-secao", "Gastos da aldeia"));
    for (const g of gastos) {
      const linha = el("div", "recomp-gasto");
      linha.append(el("span", "", g.icone), el("span", "", g.texto), el("span", "", g.valor));
      card.appendChild(linha);
    }
  }
  if (dica) card.appendChild(el("p", "recomp-dica", "💡 " + dica));
  if (leve && autoFechar) {
    const tempo = el("div", "recomp-tempo");
    const barra = el("div");
    barra.style.animationDuration = autoFechar + "ms";
    tempo.appendChild(barra);
    card.appendChild(tempo);
  }
  if (!leve) {
    const b = document.createElement("button");
    b.className = "botao-holofote recomp-botao";
    b.textContent = botao;
    b.onclick = fecharJanelaRecompensa;
    card.appendChild(b);
    overlay.onclick = (ev) => { if (ev.target === overlay) fecharJanelaRecompensa(); };
  } else {
    // a leve cobre o jogo inteiro: qualquer toque (no card ou no fundo) só
    // fecha a janela antes do tempo — não passa pro que está atrás
    overlay.onclick = (ev) => { ev.preventDefault(); ev.stopPropagation(); fecharJanelaRecompensa(); };
  }
  overlay.appendChild(card);
  document.body.appendChild(overlay);
  overlay._aoFechar = aoFechar;
  JANELA_RECOMPENSA = overlay;
  if (autoFechar) overlay._timer = setTimeout(fecharJanelaRecompensa, autoFechar);
  vibrar("sucesso");
}

// O pacote da vitória vem na resposta da luta (sai do servidor uma vez só);
// o id segura a janela se a mesma resposta for desenhada duas vezes.
function talvezMostrarRecompensaDaLuta(dados) {
  const r = dados && dados.recompensa;
  if (!r || r.id === ULTIMA_RECOMPENSA_ID) return;
  ULTIMA_RECOMPENSA_ID = r.id;
  const itens = [];
  if (r.xp) itens.push({ icone: "⭐", texto: "Experiência", valor: `+${r.xp} XP` });
  if (r.xp_travado) itens.push({ icone: "🔒", texto: "XP travado: nível máximo deste andar", valor: "" });
  let raro = false;
  for (const c of Object.values(r.cores || {})) {
    const eRaro = !!c.skill || Number(c.tier || 1) > 1;
    raro = raro || eRaro;
    itens.push({ icone: c.skill ? "✨" : "💎", texto: c.nome + (Number(c.tier || 1) > 1 ? ` (T${c.tier})` : ""),
                 valor: `x${c.qtd}`, raro: eRaro });
  }
  for (const [nome, q] of Object.entries(r.material || {})) {
    itens.push({ icone: "⛏️", texto: nome, valor: `+${q}` });
  }
  if (!itens.length && !r.nivel) return;
  if (raro) som.raro(); else som.moeda();
  janelaRecompensa({
    icone: r.nivel ? "🌟" : "⚔️", titulo: "Vitória!", nivel: r.nivel || null, itens,
    // (28/09, dev) "muda pra 1,5s": a janela da luta some rápido em todos os
    // casos — a próxima luta começa logo, e nível/raro já têm brilho e som
    leve: true, autoFechar: 1500,
  });
}

// 🎁 banner do clã: a sessão AFK espera o toque em "Receber"
function bannerDeRecompensaDoCla(pendente) {
  const box = el("div", "recomp-banner");
  const texto = el("div", "recomp-banner-texto");
  const t = el("div");
  t.append(el("b", "", "Seu clã trabalhou enquanto você estava fora"),
           el("span", "", `${String(pendente.horas).replace(".", ",")}h de aldeia, equipes e batalha te esperando`));
  texto.append(el("div", "recomp-banner-icone", "🎁"), t);
  const b = document.createElement("button");
  b.className = "botao-holofote";
  b.textContent = "🎁 Receber recompensa";
  b.onclick = async () => {
    b.disabled = true; b.textContent = "Abrindo...";
    try {
      const d = await api("/api/clan/receber", { method: "POST" });
      if (d.gold != null) atualizarTopo({ gold: d.gold });
      const rec = d.recompensa || { itens: [] };
      const boas = (rec.itens || []).filter((x) => !x.ruim).length;
      if ((rec.itens || []).some((x) => x.raro)) som.raro(); else som.moeda();
      janelaRecompensa({
        icone: boas ? "🎁" : "🏚️",
        titulo: boas ? "Recompensa do clã" : "O clã não produziu",
        sub: `${String(rec.horas || 0).replace(".", ",")}h enquanto você estava fora`,
        itens: rec.itens || [], gastos: rec.gastos || [], dica: rec.dica || "",
        botao: boas ? "Pegar tudo" : "Entendi",
        aoFechar: () => recarregarClan(),
      });
    } catch (e) {
      som.erro(); if (!e.jaAlertado) toast(e.message, true);
      b.disabled = false; b.textContent = "🎁 Receber recompensa";
    }
  };
  box.append(texto, b);
  return box;
}

// ---------- quadradinho de combatente (grade de inimigos/aliados) ----------
/** Título da tela de luta: onde você está, em ouro, no topo.
 *
 *  Fica no começo da página e não no meio do painel porque é TÍTULO — diz
 *  em que tela você está, como o de qualquer outra. No meio ele disputava
 *  largura com os dois retratos, que são o que a tela quer mostrar.
 *
 *  Montado com nós de texto e não com innerHTML: o rótulo carrega número
 *  vindo da API, e innerHTML com dado de fora é atalho que só dá problema
 *  meses depois. */
function tituloDaLuta(onde, detalhe) {
  const caixa = el("div", "titulo-luta");
  caixa.appendChild(el("span", "titulo-luta-onde", onde));
  if (detalhe) caixa.appendChild(el("span", "titulo-luta-detalhe", detalhe));
  return caixa;
}

/** Ficha de inimigo na fileira de combate: arte grande, nome e barra de
 *  vida embaixo. Substituiu o quadradinho com a barra dentro — na tela do
 *  celular aquele quadrado tinha 30px de retrato, e a arte não cabia nele. */
function fichaInimigo(op) {
  const f = document.createElement("button");
  f.className = "inimigo-ficha" + (op.selecionado ? " selecionado" : "") +
    (op.atingido ? " flash-dano" : "") + (op.morto ? " morto" : "");
  const arte = el("div", "inimigo-ficha-arte");
  if (op.imagemUrl) porFundo(arte, op.imagemUrl);
  else arte.textContent = op.icone || "👹";
  f.appendChild(arte);
  if (op.selecionado) f.appendChild(el("div", "inimigo-ficha-alvo", "🎯"));
  // A mesma letra que aparece na fila de turnos. Sem ela, "o B ataca daqui
  // a dois turnos" não aponta pra ninguém na tela.
  if (op.tag) f.appendChild(el("div", "inimigo-ficha-tag", op.tag));
  f.appendChild(el("div", "inimigo-ficha-nome", op.nome));
  const pct = op.hpMax > 0 ? Math.max(0, Math.min(100, (op.hp / op.hpMax) * 100)) : 0;
  const trilho = el("div", "inimigo-ficha-barra");
  const fill = el("div", "inimigo-ficha-barra-fill");
  fill.style.width = `${pct}%`;
  trilho.appendChild(fill);
  f.appendChild(trilho);
  f.appendChild(el("div", "inimigo-ficha-hp", `${Math.max(0, op.hp)}/${op.hpMax}`));
  // ⚡ (26/09) o PODER DE COMBATE do bot antigo, de volta: o número e a
  // comparação com o seu (🟢 fraco … 🔴 muito mais forte)
  if (op.poder != null) {
    const pw = el("div", "inimigo-ficha-poder", `⚡${op.poder.toLocaleString("pt-BR")} ${op.poderEmoji || ""}`);
    if (op.poderDesc) f.title = op.poderDesc;
    f.appendChild(pw);
  }
  if (op.onClick) f.onclick = op.onClick;
  return f;
}

// { tipo: 'jogador'|'inimigo', icone, imagemUrl, nome, hp, hpMax, selecionado, atingido, morto, onClick }
function quadradoCombatente(op) {
  const q = el("div", `quadrado-combatente ${op.tipo}` +
    (op.selecionado ? " selecionado" : "") + (op.atingido ? " flash-dano" : "") + (op.morto ? " morto" : ""));
  if (op.onClick) { q.onclick = op.onClick; q.style.cursor = "pointer"; }
  const retrato = el("div", "quadrado-combatente-retrato");
  if (op.imagemUrl) retrato.style.backgroundImage = `url(${op.imagemUrl})`;
  else retrato.textContent = op.icone || "❓";
  q.appendChild(retrato);
  if (op.selecionado) q.appendChild(el("div", "quadrado-combatente-alvo", "🎯"));
  q.appendChild(el("div", "quadrado-combatente-nome", op.nome));
  const pct = op.hpMax > 0 ? Math.max(0, Math.min(100, (op.hp / op.hpMax) * 100)) : 0;
  const barraWrap = el("div", "quadrado-combatente-barra");
  const fill = el("div", `quadrado-combatente-barra-fill ${op.tipo === "inimigo" ? "barra-inimigo" : "barra-hp"}`);
  fill.style.width = `${pct}%`;
  barraWrap.appendChild(fill);
  q.appendChild(barraWrap);
  return q;
}

// ---------- formata segundos em "3d 14h" / "5h 20min" / "8min" ----------
function formatarContagem(segundos) {
  if (!segundos || segundos <= 0) return "a qualquer momento";
  const dias = Math.floor(segundos / 86400);
  const horas = Math.floor((segundos % 86400) / 3600);
  const min = Math.floor((segundos % 3600) / 60);
  if (dias > 0) return `${dias}d ${horas}h`;
  if (horas > 0) return `${horas}h ${min}min`;
  return `${min}min`;
}

// ---------- estado vazio (mais convidativo que um texto cinza solto) ----------
function estadoVazio(icone, texto) {
  const box = el("div", "estado-vazio");
  box.appendChild(el("div", "estado-vazio-icone", icone));
  box.appendChild(el("p", "estado-vazio-texto", texto));
  return box;
}

// ---------- fila de iniciativa: os próximos turnos ----------
//
// Antes esta barra só ordenava quem está mais pronto AGORA — o que responde
// "quem age a seguir" e mais nada. Com o ATB do jogo dá pra responder a
// pergunta que realmente importa: "dá tempo de usar a skill antes daquele
// chefe bater duas vezes?".
//
// A regra do motor é simples e determinística: a barra de cada um enche a
// `spd` por unidade de tempo, quem chega em ATB_MAX age e desconta ATB_MAX.
// Então a ordem futura é calculável — não é estimativa, é a mesma conta.
//
// ⚠️ É uma PREVISÃO: vale enquanto ninguém morrer, for lentificado ou
// receber buff de velocidade. Como a tela se redesenha a cada turno, ela se
// corrige sozinha — mas por isso o rótulo diz "próximos", não "será".
const ATB_MAX = 100;
const TURNOS_PREVISTOS = 10;

function preverTurnos(combatentes, quantos = TURNOS_PREVISTOS) {
  // Cópia com barra e velocidade próprias: prever não pode mexer no estado
  // que a tela está desenhando.
  const estado = combatentes
    .filter((c) => !c.morto && (c.spd || 0) > 0)
    .map((c) => ({ ref: c, bar: Number(c.bar) || 0, spd: Number(c.spd) || 1 }));
  if (!estado.length) return [];

  const ordem = [];
  for (let i = 0; i < quantos; i++) {
    // Quem precisa de menos tempo pra encher. Empate: o de maior barra.
    let melhor = null, menorT = Infinity;
    for (const e of estado) {
      const t = (ATB_MAX - e.bar) / e.spd;
      if (t < menorT - 1e-9 || (Math.abs(t - menorT) < 1e-9 && melhor && e.bar > melhor.bar)) {
        menorT = t; melhor = e;
      }
    }
    if (!melhor || !isFinite(menorT)) break;
    for (const e of estado) e.bar = Math.min(ATB_MAX, e.bar + e.spd * menorT);
    ordem.push(melhor.ref);
    melhor.bar -= ATB_MAX;
  }
  return ordem;
}

// combatentes: [{ tipo, icone, imagemUrl, rotulo, bar, spd, morto }]
function filaIniciativa(combatentes) {
  const ordem = preverTurnos(combatentes);
  const caixa = el("div", "fila-caixa");
  caixa.appendChild(el("div", "fila-titulo", "Próximos turnos"));
  const fila = el("div", "fila-iniciativa");
  if (!ordem.length) {
    // Sem spd não dá pra prever. Cai no comportamento antigo — ordenar por
    // quem está mais pronto — em vez de mostrar uma fila vazia.
    [...combatentes].sort((a, b) => b.bar - a.bar).forEach((cmb, pos) => {
      const chip = el("div", `fila-chip ${cmb.tipo}${pos === 0 ? " proximo" : ""}`);
      chip.appendChild(el("div", "", cmb.icone));
      fila.appendChild(chip);
    });
    caixa.appendChild(fila);
    return caixa;
  }
  ordem.forEach((cmb, pos) => {
    const chip = el("div", `fila-chip ${cmb.tipo}${pos === 0 ? " proximo" : ""}`);
    if (cmb.imagemUrl) porFundo(chip, cmb.imagemUrl);
    else chip.appendChild(el("div", "", cmb.icone));
    // Com vários inimigos, dez carinhas iguais não dizem nada. O rótulo
    // curto (V, A, B…) é o que liga o chip à ficha lá embaixo.
    if (cmb.rotulo) chip.appendChild(el("span", "fila-chip-tag", cmb.rotulo));
    chip.title = cmb.nome || "";
    fila.appendChild(chip);
  });
  caixa.appendChild(fila);
  return caixa;
}

// ---------- bottom sheet ----------
// 🔒 (28/09) Folha travada não fecha com toque fora. Existe pro nome
// obrigatório do jogador novo: no celular, tocar fora é o jeito natural de
// baixar o teclado — a folha sumia, o nome ficava vazio e o guia inicial
// (que espera o nome) nunca começava. Só aparecia de novo ao atualizar.
let SHEET_TRAVADA = false;
function abrirSheet(nodeCorpo, travada = false) {
  SHEET_TRAVADA = !!travada;
  const corpo = document.getElementById("sheet-corpo");
  corpo.innerHTML = "";
  corpo.appendChild(nodeCorpo);
  document.getElementById("sheet-overlay").classList.remove("oculto");
}
function fecharSheet() { SHEET_TRAVADA = false; document.getElementById("sheet-overlay").classList.add("oculto"); }
document.getElementById("sheet-overlay")?.addEventListener("click", (ev) => {
  if (ev.target.id === "sheet-overlay" && !SHEET_TRAVADA) fecharSheet();
});

// ---------- esqueleto de carregamento ----------
function mostrarEsqueleto() {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  for (let i = 0; i < 4; i++) {
    const bloco = el("div", "esqueleto-bloco");
    bloco.style.marginBottom = "10px";
    c.appendChild(bloco);
  }
}

// ---------- puxar pra atualizar ----------
let PUXAR_ATIVO = false;
function ativarPuxarAtualizar() {
  // a entrada agora roda de novo depois da criação: sem esta trava o gesto
  // ganhava listeners em dobro e o indicador aparecia duas vezes
  if (PUXAR_ATIVO) return;
  PUXAR_ATIVO = true;
  const conteudo = document.getElementById("conteudo");
  let inicioY = null, puxando = false;
  const indicador = el("div", "puxar-indicador", "↓");
  conteudo.parentNode.insertBefore(indicador, conteudo);

  conteudo.addEventListener("touchstart", (ev) => {
    // (28/09) durante o guia, puxar pra atualizar não vale: é toque fora do
    // que o guia pediu (e recarregava a página no meio do tutorial)
    if (GUIA_ATIVO) { puxando = false; inicioY = null; return; }
    if (conteudo.scrollTop === 0 && window.scrollY === 0) { inicioY = ev.touches[0].clientY; puxando = true; }
  }, { passive: true });
  conteudo.addEventListener("touchmove", (ev) => {
    if (!puxando || inicioY === null) return;
    const distancia = ev.touches[0].clientY - inicioY;
    if (distancia > 0 && distancia < 100) {
      indicador.style.opacity = Math.min(distancia / 60, 1);
      indicador.style.transform = `translateY(${Math.min(distancia, 60)}px) rotate(${Math.min(distancia * 3, 180)}deg)`;
    }
  }, { passive: true });
  conteudo.addEventListener("touchend", (ev) => {
    if (!puxando) return;
    const distanciaFinal = (ev.changedTouches[0]?.clientY || 0) - (inicioY || 0);
    indicador.style.opacity = 0;
    indicador.style.transform = "translateY(0) rotate(0deg)";
    if (distanciaFinal > 55) {
      som.clique();
      vibrar("leve");
      irPara(TELA_ATUAL);
    }
    puxando = false; inicioY = null;
  });
}

// ---------- badge de missões prontas (botão hambúrguer + item do menu) ----------
let QTD_MISSOES_PRONTAS = 0;
function aplicarBadgeMissoes(qtd) {
  QTD_MISSOES_PRONTAS = qtd;
  const badgeBotao = document.getElementById("badge-menu");
  if (badgeBotao) {
    if (qtd > 0) { badgeBotao.textContent = qtd > 9 ? "9+" : String(qtd); badgeBotao.classList.remove("oculto"); }
    else badgeBotao.classList.add("oculto");
  }
}
async function atualizarBadgeMissoes() {
  // (26/09) o badge antigo ficava no botão da gaveta, que não existe mais:
  // agora é o ponto vermelho das pendências (missões, trilha, aldeia...)
  await atualizarPendencias(true);
}

// 🔴 26/09/2026 (dev): "pontos vermelhos nas páginas que têm algo pra
// receber" — missões/diárias prontas, pontos de trilha, aldeões livres e
// crônicas esperando. O ponto aparece na ABA de baixo (se alguma página do
// grupo tem pendência) e no ATALHO da página na grade.
let PENDENCIAS = {};
let _pendenciasEm = 0;
const PENDENCIA_DA_TELA = { missoes: "missoes", trilhas: "trilhas", clan: "aldeia", situacoes: "cronicas" };

async function atualizarPendencias(forcar = false) {
  if (!forcar && Date.now() - _pendenciasEm < 15000) { aplicarPontos(); return; }
  _pendenciasEm = Date.now();
  try { PENDENCIAS = await api("/api/pendencias"); } catch (e) { return; }
  aplicarPontos();
}

function telaTemPendencia(tela) {
  const chave = PENDENCIA_DA_TELA[tela];
  return !!(chave && Number(PENDENCIAS[chave] || 0) > 0);
}

function aplicarPontos() {
  const grupos = {};
  for (const [tela, grupo] of Object.entries(GRUPO_DA_TELA)) {
    if (telaTemPendencia(tela)) grupos[grupo] = true;
  }
  document.querySelectorAll(".aba-item[data-grupo]").forEach((b) => {
    b.classList.toggle("tem-pendencia", !!grupos[b.dataset.grupo]);
    // 🔒 (26/09) a aba do Clã fica apagada até a fundação
    if (b.dataset.grupo === "clan") b.classList.toggle("bloqueada", !!PENDENCIAS.clan_bloqueado);
  });
  document.querySelectorAll(".caminho[data-tela]").forEach((c) => {
    c.classList.toggle("tem-pendencia", telaTemPendencia(c.dataset.tela));
  });
}

// ---------- gaveta lateral (menu real do jogo) ----------
const ITENS_DRAWER = [
  { secao: "Cidade", itens: [
  ]},
  { secao: "Personagem", itens: [
    { icone: "📊", texto: "Ficha / Status", tela: "personagem" },
    { icone: "⚔️", texto: "Gerenciar Skills", tela: "skills" },
    { icone: "🐉", texto: "Meus Espíritos", tela: "pets" },
    { icone: "🎒", texto: "Inventário", tela: "inventario" },
    { icone: "🛡️", texto: "Especialidade", tela: "especialidade" },
  ]},
  { secao: "Aventura", itens: [
    { icone: "🗼", texto: "Torre", tela: "torre" },
    { icone: "🌍", texto: "Explorar Mundo", tela: "explorar" },
    { icone: "🌊", texto: "Onda de Bosses", tela: "onda" },
    { icone: "📜", texto: "Missões", tela: "missoes" },
  ]},
  { secao: "Grupo", itens: [
    { icone: "⚔️", texto: "Raid", tela: "raid" },
    { icone: "👥", texto: "Entrar em Party", tela: "party" },
    { icone: "🐲", texto: "Boss Global", tela: "boss_global" },
  ]},
  { secao: "Arenas", itens: [
    { icone: "🏆", texto: "Arena PvP", tela: "arena" },
    { icone: "🐾", texto: "Arena dos Pets", tela: "arena_pets" },
  ]},
  { secao: "Cidade", itens: [
    { icone: "🏥", texto: "Hospital", tela: "hospital" },
    { icone: "🏪", texto: "Loja", tela: "loja" },
    { icone: "🛠️", texto: "Forjar Itens", tela: "forja" },
    { icone: "💎", texto: "Engaste de Gemas", tela: "engaste" },
    { icone: "🔮", texto: "Templo de Evocação", tela: "gacha" },
    { icone: "🐴", texto: "Estábulo", tela: "estabulo" },
    { icone: "🔄", texto: "Mercado", tela: "mercado" },
    { icone: "🏆", texto: "Ranking", tela: "ranking" },
    { icone: "📖", texto: "Ajuda", tela: "ajuda" },
  ]},
];

// título legível por tela — pego direto da lista do menu, pra usar no overlay do banner
const TELA_TITULO = Object.fromEntries(
  ITENS_DRAWER.flatMap((grupo) => grupo.itens.map((item) => [item.tela, item.texto]))
);

// 25/09/2026: a gaveta (montarDrawer/abrirMenu/fecharMenu) e a barra
// ‹ anterior / próxima › saíram de vez. A barra estava escondida por CSS
// desde que as abas chegaram, e o toque no meio dela chamava abrirMenu(),
// que procurava um #drawer-overlay que o index.html já não tinha — só não
// quebrava porque ninguém conseguia tocar. TELA_TITULO (acima) continua:
// é ele que dá nome ao banner de cada tela.

// ---------- roteador ----------
let TELA_ATUAL = "personagem";
let DADOS_PERSONAGEM = null;

// 🖼️ (09/07/2026): banner de cena por tela — as mesmas imagens que o bot
// já usa no chat (CITY, TOWER, LOJA...), servidas via /api/imagem/{chave}.
const BANNER_POR_TELA = {
  personagem: "STATUS", inventario: "INVENTARIO", pets: "CLASSE", skills: "SKILL",
  especialidade: "CLASSE", torre: "TOWER", explorar: "TOWER", onda: "TOWER",
  missoes: "CITY", raid: "RAID", party: "RAID", arena: "RANKING", arena_pets: "RANKING",
  loja: "LOJA", forja: "CRAFT", gacha: "APRENDER", estabulo: "APRENDER",
  mercado: "TROCAS", ranking: "RANKING",
  // 11/09/2026 — hospital e engaste eram telas novas e ficaram sem chave de
  // arte: apareciam sem banner e, na praça, sem retrato. As duas imagens já
  // estavam no assets.py desde sempre.
  hospital: "HOSPITAL", engaste: "SOCKETS", ajuda: "APRENDER",
  trilhas: "TRILHAS", personagens: "CLASSE", clan: "RAID",
  clan_postos: "RAID", clan_historico: "RAID", clan_ferreiro: "CRAFT", clan_equipe: "RAID", clan_reliquias: "CRAFT",
  situacoes: "APRENDER", jornada: "TOWER", conta: "VIP", mercado_personagens: "TROCAS",
};
// 🐛 (28/09) A Ficha/Status mostrava no TOPO a arte padrão ("STATUS", a mesma
// pra todo mundo) em vez da arte do personagem — o banner vinha desta tabela
// fixa, enquanto o retrato redondo logo abaixo já usava a arte certa (raça +
// sexo, IMG_JOGADOR). Na Ficha o banner agora é a arte do próprio jogador;
// sem arte própria, o servidor já devolve "STATUS" e nada muda.
function chaveDoBanner(tela) {
  if (tela === "personagem") return IMG_JOGADOR || BANNER_POR_TELA.personagem;
  if (tela === "perfil_jogador") return PERFIL_ARTE || BANNER_POR_TELA.personagem;
  return BANNER_POR_TELA[tela];
}

function urlImagem(chave, largura) {
  if (!chave) return null;
  const base = `/api/imagem/${encodeURIComponent(chave)}`;
  // Pede a arte no tamanho em que ela vai ser DESENHADA. A original vem do
  // Telegram com ~1280px; um retrato de 42px usando a original é ~95% de
  // bytes jogados fora, e no WebView de celular isso aparece como tela que
  // demora pra montar.
  //
  // Dobro do CSS por causa de tela retina: 42px de layout = 84 de pixel
  // real, e pedir 42 deixaria borrado no aparelho de todo mundo.
  // 📤 Arte TROCADA pelo admin ganha versão na URL: sem isso, o cache de 24h
  // mostraria a imagem velha e a troca pareceria não ter funcionado.
  const v = IMG_VERSOES[chave];
  const versao = v ? `v=${v}` : "";
  if (!largura) return versao ? `${base}?${versao}` : base;
  const real = Math.min(512, Math.ceil(largura * 2 / 64) * 64);
  return `${base}?w=${real}${versao ? "&" + versao : ""}`;
}

// Versões das artes trocadas pelo admin. Começa vazio (URL sem versão, que é
// o normal) e é preenchido uma vez no boot; se falhar, nada quebra — só a
// arte trocada pode demorar a aparecer.
// `var` e não `let`: urlImagem pode ser chamada antes desta linha rodar, e
// `let` daria ReferenceError (zona morta) em vez de só "sem versão".
var IMG_VERSOES = {};
if (typeof fetch === "function") {
  fetch("/api/imagens/versoes").then((r) => (r.ok ? r.json() : {}))
    .then((v) => { if (v && typeof v === "object") IMG_VERSOES = v; })
    .catch(() => {});
}

/** Todo <img> do jogo passa por aqui. Centraliza o que é fácil esquecer em
 *  um lugar: carregamento preguiçoso, decodificação fora da thread
 *  principal, texto alternativo e a reserva quando a arte falha. */
function imagemDoJogo(chave, largura, reserva) {
  const img = document.createElement("img");
  img.src = urlImagem(chave, largura);
  img.alt = "";
  img.loading = "lazy";
  img.decoding = "async";
  if (reserva) img.onerror = reserva;
  return img;
}
/** A tela que acabou de ser montada é uma batalha? (o painel da luta, a
 *  linha de inimigos, a Raid em curso, ou o Boss Global) */
function ehTelaDeBatalha(tela) {
  if (tela === "boss_global") return true;
  return !!document.querySelector("#conteudo .combate-vs, #conteudo .fileira-inimigos, #conteudo .titulo-luta");
}

function inserirBanner(container, chave, tela) {
  if (!chave) return;
  const wrap = el("div", "banner-wrap");
  const img = document.createElement("img");
  img.className = "banner-tela";
  img.src = urlImagem(chave);
  img.loading = "lazy";
  img.decoding = "async";
  img.alt = "";
  img.onerror = () => wrap.remove(); // se a imagem falhar, some sem quebrar o layout
  // a arte do personagem é um retrato em pé: o banner baixo cortava pelo
  // meio (peito) — aqui o corte mira o rosto
  if (tela === "personagem" || tela === "perfil_jogador") img.style.objectPosition = "center 18%";
  wrap.appendChild(img);
  const titulo = tela ? TELA_TITULO[tela] : null;
  if (titulo) {
    const legenda = el("div", "banner-legenda");
    legenda.appendChild(el("div", "banner-titulo", titulo));
    wrap.appendChild(legenda);
  }
  container.insertBefore(wrap, container.firstChild);
}

// 🛡️ Protege o progresso durante combate: fechar a aba sem querer no meio
// de uma raid é uma péssima experiência. Era a confirmação nativa do
// Telegram; no site é o aviso do próprio navegador ("sair da página?").
function protegerProgresso(ativo) {
  window.onbeforeunload = ativo ? (e) => { e.preventDefault(); e.returnValue = ""; return ""; } : null;
}

const CLASSE_SIMBOLO = {
  guardiao: "🛡️", mago: "🔮", arqueiro: "🏹", guerreiro: "⚔️",
  bezerk: "🪓", assassino: "🗡️", curandeiro: "✨",
};

// cor de identidade por classe — usada na aura do retrato, selo de nível e chips de stat.
// Categorias, não sequência: cada classe tem uma cor fixa que não muda com nada além dela mesma.
const CLASSE_COR = {
  guardiao: "#e8b64a", mago: "#8a6fe8", arqueiro: "#4fd17a",
  guerreiro: "#d8623a", bezerk: "#e8543f", assassino: "#4a9eff", curandeiro: "#4fc3c8",
};
const SLOT_INFO = {
  weapon: { rotulo: "Arma", icone: "⚔️" }, armor: { rotulo: "Peitoral", icone: "🛡️" },
  helmet: { rotulo: "Elmo", icone: "⛑️" }, gloves: { rotulo: "Luvas", icone: "🧤" },
  boots: { rotulo: "Botas", icone: "🥾" }, shield: { rotulo: "Escudo", icone: "🛡️" },
  belt: { rotulo: "Cinto", icone: "🎗️" }, necklace: { rotulo: "Colar", icone: "📿" }, ring: { rotulo: "Anel", icone: "💍" },
};
const STAT_INFO = {
  atk: { rotulo: "Ataque", icone: "⚔️" }, def: { rotulo: "Defesa", icone: "🛡️" },
  spd: { rotulo: "Velocidade", icone: "💨" }, acc: { rotulo: "Precisão", icone: "🎯" },
  eva: { rotulo: "Esquiva", icone: "🌀" }, crit: { rotulo: "Crítico", icone: "💥" },
  reg: { rotulo: "Regeneração", icone: "🩸" },
};

const ATTR_INFO = {
  str: { rotulo: "Força", icone: "💪" }, vit: { rotulo: "Vitalidade", icone: "❤️" },
  agi: { rotulo: "Agilidade", icone: "🏃" }, dex: { rotulo: "Destreza", icone: "🎯" },
};

let NIVEL_CONHECIDO = null;

/** ✏️ (25/09/2026) Escolher o nome do personagem que você pilota.
 *  `obrigatorio` = quem ainda não tem nome (a folha não oferece "depois"). */
function abrirEscolherNome(atual, obrigatorio = false) {
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", obrigatorio ? "Como seu personagem se chama?" : "Trocar o nome"));
  corpo.appendChild(el("p", "texto-fraco", "De 3 a 20 letras. Não pode repetir o nome de outro jogador."));
  const campo = document.createElement("input");
  campo.className = "sheet-input";
  campo.maxLength = 20;
  campo.value = atual || "";
  campo.placeholder = "Nome do personagem";
  campo.autocomplete = "off";
  corpo.appendChild(campo);
  const erro = el("p", "texto-fraco erro-nome", "");
  const salvar = document.createElement("button");
  salvar.className = "botao-holofote";
  salvar.style.cssText = "width:100%;margin-top:10px";
  salvar.textContent = "Salvar nome";
  salvar.onclick = async () => {
    salvar.disabled = true; erro.textContent = "";
    try {
      const r = await api("/api/character/nome", { method: "POST", body: JSON.stringify({ nome: campo.value }) });
      som.moeda();
      document.getElementById("nome-topo").textContent = r.nome;
      fecharSheet();
      toast(`Agora você é ${r.nome}.`);
      if (GUIA_DEPOIS_DO_NOME) { GUIA_DEPOIS_DO_NOME = false; setTimeout(() => iniciarGuia("guia_inicio", GUIA_INICIO), 500); }
      if (TELA_ATUAL === "personagem") renderPersonagem();
    } catch (e) {
      som.erro(); erro.textContent = e.message || "Não deu pra salvar esse nome.";
      salvar.disabled = false;
    }
  };
  campo.onkeydown = (ev) => { if (ev.key === "Enter") salvar.click(); };
  corpo.append(erro, salvar);
  abrirSheet(corpo, obrigatorio);
  setTimeout(() => campo.focus(), 60);
}

async function renderPersonagem() {
  const d = await api("/api/character");
  DADOS_PERSONAGEM = d;
  // O retrato da ficha é montado logo abaixo e `atualizarTopo(d)` só roda
  // no fim: sem isto, a primeira pintura usaria a arte da sessão anterior.
  if (d.img_jogador) IMG_JOGADOR = d.img_jogador;
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  if (NIVEL_CONHECIDO !== null && d.level > NIVEL_CONHECIDO) {
    notificacaoGrande("✨", `Nível ${d.level}!`, "Sua Aura ficou mais forte");
  }
  NIVEL_CONHECIDO = d.level;
  desenharFicha(c, d, false);
  atualizarTopo(d);
}

/** 👤 (28/09, dev) A ficha desenhada UMA vez pros dois casos: a sua
 *  (`publica` = false) e a de outro jogador aberta pelo ranking (`publica`
 *  = true: só leitura — sem trocar nome, sem barras de vida/XP, sem pontos
 *  parados, montaria sem atalho pro Estábulo). As duas telas nunca
 *  divergem porque são a mesma função. */
function desenharFicha(c, d, publica) {
  const arteDoJogador = publica ? (d.img_jogador || "STATUS") : IMG_JOGADOR;
  const cabecalho = el("div", "cabecalho-personagem");
  const retratoWrap = el("div", "retrato-wrap");
  retratoWrap.style.setProperty("--cor-aura", CLASSE_COR[d.class_id] || "");
  retratoWrap.appendChild(el("div", "retrato-aura"));
  // A aura continua sendo o elemento vivo do lore — ela só passou a
  // envolver a ARTE em vez de um emoji.
  const simbolo = el("div", "retrato-simbolo");
  simbolo.appendChild(retratoImagem(arteDoJogador, CLASSE_SIMBOLO[d.class_id] || "🧙", 84));
  retratoWrap.appendChild(simbolo);
  const identidade = el("div", "identidade");
  const linhaNome = el("div", "linha-nome");
  linhaNome.appendChild(el("h2", "nome-jogador", d.username || "Aventureiro"));
  if (!publica) {
    const editarNome = document.createElement("button");
    editarNome.className = "btn-editar-nome";
    editarNome.title = "Trocar o nome";
    editarNome.textContent = "✏️";
    editarNome.onclick = () => abrirEscolherNome(d.username || "");
    linhaNome.appendChild(editarNome);
  }
  identidade.appendChild(linhaNome);
  if (d.poder != null) {
    identidade.appendChild(el("div", "poder-de-combate", `⚡ Poder de combate: ${Number(d.poder).toLocaleString("pt-BR")}`));
  }
  identidade.appendChild(el("p", "classe-raca", [d.class_id, d.race_id].filter(Boolean).join(" · ") || "Sem classe/raça"));
  if (d.chakra) identidade.appendChild(el("p", "chakra-linha", `🔮 ${d.chakra}`));
  if (d.nascido_na_torre) identidade.appendChild(el("p", "chakra-linha", "🌱 Nascido na Torre: +10% em todos os status"));
  if (publica && d.tower_floor) identidade.appendChild(el("p", "chakra-linha", `🗼 Andar ${d.tower_floor}`));
  const selo = el("div", "nivel-selo");
  selo.style.setProperty("--cor-aura", CLASSE_COR[d.class_id] || "");
  const seloValor = el("span", "", String(d.level)); seloValor.id = "nivel-valor";
  selo.append(seloValor, el("span", "nivel-rotulo", "NÍVEL"));
  identidade.appendChild(selo);
  cabecalho.append(retratoWrap, identidade);
  c.appendChild(cabecalho);

  if (!publica) {
    const barras = el("div", "barras");
    const hpPct = d.hp_max > 0 ? Math.max(0, Math.min(100, (d.hp / d.hp_max) * 100)) : 0;
    const xpPct = d.xp_next > 0 ? Math.max(0, Math.min(100, (d.xp / d.xp_next) * 100)) : 0;
    barras.appendChild(barraDeProgresso("❤️ Vida", `${d.hp}/${d.hp_max}`, hpPct, "barra-hp"));
    barras.appendChild(barraDeProgresso("✨ Experiência", `${d.xp}/${d.xp_next}`, xpPct, "barra-xp"));
    c.appendChild(barras);
  }

  const statsGrid = el("div", "stats-grid");
  statsGrid.style.setProperty("--cor-aura", CLASSE_COR[d.class_id] || "");
  let i = 0;
  for (const [chave, info] of Object.entries(STAT_INFO)) {
    const linha = el("div", "stat-linha");
    linha.style.animationDelay = `${i * 0.04}s`;
    const corpo = el("div", "stat-linha-corpo");
    corpo.append(el("span", "stat-nome", info.rotulo), el("span", "stat-valor", String(d.stats?.[chave] ?? 0)));
    linha.append(el("div", "stat-icone-chip", info.icone), corpo);
    statsGrid.appendChild(linha);
    i++;
  }
  c.appendChild(el("h3", "secao-titulo", "Status"));   // era um 2º "Atributos"
  c.appendChild(statsGrid);

  if (d.attrs) {
    // 📊 O número aqui agora é o TOTAL que o jogo usa, com a conta aberta
    // embaixo. Antes mostrava só a base: quem tinha 32 pontos de trilha em
    // agilidade lia "1" e não tinha como saber onde o investimento foi
    // parar — o dado existia, só nunca saía de dentro do `recalc`.
    const tituloAttrs = el("h3", "secao-titulo", "Atributos");
    c.appendChild(tituloAttrs);
    if (!publica && d.trail_points > 0) {
      c.appendChild(el("p", "texto-fraco",
        `Você tem ${d.trail_points} ponto(s) de trilha pra gastar.`));
    }
    const attrsGrid = el("div", "stats-grid");
    attrsGrid.style.setProperty("--cor-aura", CLASSE_COR[d.class_id] || "");
    let j = 0;
    for (const [chave, info] of Object.entries(ATTR_INFO)) {
      const linha = el("div", "stat-linha");
      linha.style.animationDelay = `${j * 0.04}s`;
      const corpo = el("div", "stat-linha-corpo");
      const nome = el("div", "stat-nome-bloco");
      nome.appendChild(el("span", "stat-nome", info.rotulo));
      const daTrilha = (d.attrs_trilha || {})[chave] || 0;
      const base = (d.attrs_base || {})[chave] ?? 0;
      if (daTrilha) nome.appendChild(el("span", "stat-fonte", `${base} base + ${daTrilha} trilha`));
      corpo.append(nome, el("span", "stat-valor", String(d.attrs[chave] ?? 0)));
      linha.append(el("div", "stat-icone-chip", info.icone), corpo);
      attrsGrid.appendChild(linha);
      j++;
    }
    c.appendChild(attrsGrid);
  }

  c.appendChild(el("h3", "secao-titulo", "Equipamentos"));
  const equipGrid = el("div", "equip-grid");
  for (const [slot, info] of Object.entries(SLOT_INFO)) {
    const item = d.equip?.[slot];
    const card = el("div", `equip-slot${item ? " " + classeRar(item.raridade) : " vazio"}`);
    // A arte do item já vinha na API (img_key) e não era usada: o slot
    // mostrava o ícone do TIPO, então espada comum e espada lendária eram
    // o mesmo desenho.
    const icone = el("div", "equip-slot-icone");
    if (item && item.img_key) porFundo(icone, urlImagem(item.img_key, 44));
    else icone.textContent = info.icone;
    card.append(icone, el("div", "equip-slot-nome", info.rotulo));
    if (item) card.appendChild(el("div", "equip-slot-item", item.nome));
    // 📈 (28/09) bônus de raridade também na Ficha (só a Mochila mostrava)
    if (item && item.bonus_raridade) {
      const br = item.bonus_raridade;
      card.appendChild(el("div", "equip-slot-bonus", `+${br.pct}% ${ROTULO_STAT[br.stat] || String(br.stat).toUpperCase()}`));
    }
    equipGrid.appendChild(card);
  }
  c.appendChild(equipGrid);

  // 👤 (28/09, dev) habilidades e especialidades equipadas — é o que
  // explica a força de um personagem (e o que um jogador quer copiar)
  desenharHabilidadesDaFicha(c, d.skills || []);
  desenharEspecialidadesDaFicha(c, d.especialidades || []);

  c.appendChild(el("h3", "secao-titulo", "Esquadrão de Espíritos"));
  const petsGrid = el("div", "pets-grid");
  petsGrid.style.setProperty("--cor-aura", CLASSE_COR[d.class_id] || "");
  (d.pets || []).forEach((pet) => {
    const card = el("div", `pet-slot${pet ? " " + classeRar(pet.raridade) : " vazio"}`);
    if (pet) {
      // A API já mandava `img_key` e a tela desenhava um 🐾 pra todos: o
      // esquadrão inteiro era cinco patinhas iguais.
      const arte = el("div", "pet-slot-arte");
      if (pet.img_key) porFundo(arte, urlImagem(pet.img_key, 128));
      else arte.textContent = "🐾";
      // Só a ARTE aqui. Os atributos de combate moraram neste slot por uma
      // versão e saíram: esta tela é a ficha do personagem, e quem compara
      // pet com pet está na tela dos Espíritos — que é onde eles estão
      // agora, no cartão, com espaço pra caber inteiros.
      // 25/09/2026 (dev): SÓ a imagem — com nome e nível embaixo a arte
      // ficava pequena demais pra ver. Nome e nível vão no toque longo
      // (title) e seguem inteiros na tela dos Espíritos.
      card.classList.add("so-arte");
      card.append(arte);
      card.title = `${pet.nome || ""} · Nv.${pet.nivel} · E${pet.evolucao || 1}`;
    } else {
      card.appendChild(el("div", "", "—"));
    }
    petsGrid.appendChild(card);
  });
  c.appendChild(petsGrid);

  // 🐎 MONTARIA — o bônus dela vale na Torre e ela não aparecia em canto
  // nenhum da ficha. Slot único, sempre visível: vazio também é informação
  // (diz que dá pra ter uma).
  c.appendChild(el("h3", "secao-titulo", "Montaria"));
  const m = d.mount;
  const mCard = el("div", `montaria-slot${m ? " " + classeRar(m.raridade) : " vazio"}`);
  const mArte = el("div", "montaria-arte");
  if (m && m.img_key) porFundo(mArte, urlImagem(m.img_key, 128));
  else mArte.textContent = "🐎";
  const mTxt = el("div", "montaria-txt");
  mTxt.appendChild(el("div", "montaria-nome", m ? m.nome : "Sem montaria"));
  mTxt.appendChild(el("div", "montaria-sub",
    m ? (m.efeito || m.raridade || "") : "Montarias vêm da Exploração — no Estábulo você equipa."));
  mCard.append(mArte, mTxt);
  if (!publica) mCard.onclick = () => irPara("estabulo");
  else if (!m) mTxt.lastChild.textContent = "—";
  c.appendChild(mCard);
}

function desenharHabilidadesDaFicha(c, skills) {
  c.appendChild(el("h3", "secao-titulo", "Habilidades"));
  const lista = el("div", "ficha-lista");
  if (!skills.some(Boolean)) lista.appendChild(el("p", "texto-fraco", "Nenhuma habilidade equipada."));
  for (const sk of skills) {
    if (!sk) continue;
    // habilidade guarda a raridade em número (1 a 5)
    const rar = ["comum", "incomum", "raro", "epico", "lendario"][Math.max(1, Math.min(5, Number(sk.raridade) || 1)) - 1];
    const linha = el("div", `ficha-linha ${classeRar(rar)}`);
    const icone = el("div", "ficha-linha-icone");
    icone.appendChild(emblemaSkill(sk.skill_id, sk.raridade, sk.tipo, 40));
    const txt = el("div", "ficha-linha-txt");
    txt.appendChild(el("div", "ficha-linha-nome",
      `${sk.nome}  ·  ${sk.tipo === "passive" ? "passiva" : "ativa"}${sk.nivel > 1 ? `  ·  Nv.${sk.nivel}` : ""}`));
    if ((sk.efeitos || []).length) txt.appendChild(el("div", "ficha-linha-sub", sk.efeitos.join(" · ")));
    linha.append(icone, txt);
    lista.appendChild(linha);
  }
  c.appendChild(lista);
}

function desenharEspecialidadesDaFicha(c, specs) {
  c.appendChild(el("h3", "secao-titulo", "Especialidades"));
  const lista = el("div", "ficha-lista");
  if (!specs.some(Boolean)) lista.appendChild(el("p", "texto-fraco", "Nenhuma especialidade equipada."));
  for (const e of specs) {
    if (!e) continue;
    const linha = el("div", "ficha-linha");
    const txt = el("div", "ficha-linha-txt");
    txt.appendChild(el("div", "ficha-linha-nome", e.nome));
    const sub = [(e.passivas || []).join(" · "), e.desc].filter(Boolean).join("  —  ");
    if (sub) txt.appendChild(el("div", "ficha-linha-sub", sub));
    linha.append(el("div", "ficha-linha-icone", "🛡️"), txt);
    lista.appendChild(linha);
  }
  c.appendChild(lista);
}

// ---------- 👤 perfil de outro jogador (aberto pelo ranking) ----------
let PERFIL_ALVO = null;
let PERFIL_ARTE = null;

function abrirPerfilJogador(id) {
  if (id == null) return;
  if (MEU_ID != null && String(id) === String(MEU_ID)) { irPara("personagem"); return; }
  PERFIL_ALVO = id;
  irPara("perfil_jogador");
}

async function renderPerfilJogador() {
  const c = document.getElementById("conteudo");
  if (PERFIL_ALVO == null) { await renderRanking(); return; }
  const d = await api(`/api/jogador/${encodeURIComponent(PERFIL_ALVO)}/ficha`);
  PERFIL_ARTE = d.img_jogador || null;
  c.innerHTML = "";
  const voltar = document.createElement("button");
  voltar.className = "botao-secundario perfil-voltar";
  voltar.textContent = "‹ Ranking";
  voltar.onclick = () => irPara("ranking");
  c.appendChild(voltar);
  desenharFicha(c, d, true);
}

function barraDeProgresso(rotulo, textoNumero, pct, classeCor) {
  const linha = el("div", "barra-linha");
  const rotuloDiv = el("div", "barra-rotulo");
  rotuloDiv.append(el("span", "", rotulo), el("span", "barra-numero", textoNumero));
  const trilho = el("div", "barra-trilho");
  const preenchimento = el("div", `barra-preenchimento ${classeCor}`);
  trilho.appendChild(preenchimento);
  linha.append(rotuloDiv, trilho);
  requestAnimationFrame(() => { preenchimento.style.width = `${pct}%`; });
  return linha;
}

function atualizarTopo(d) {
  // 🔥 (09/07/2026): agora aceita atualização PARCIAL — várias ações (forja,
  // gacha, mercado, combate) só têm ouro/premium novos em mãos, não o
  // personagem inteiro. Antes, chamar isso com um objeto parcial resetava
  // nome e símbolo pra valores padrão ("Aventureiro"/"❓") por engano.
  if (d.img_jogador) IMG_JOGADOR = d.img_jogador;
  if (d.username !== undefined) document.getElementById("nome-topo").textContent = d.username || "Aventureiro";
  // 🖼️ O retrato do topo era o emoji da classe. Agora é a arte de STATUS —
  // a mesma que o jogador vê na Ficha. Representar a pessoa com a arte dela
  // e não com um símbolo genérico é o que amarra as telas umas nas outras.
  if (d.class_id !== undefined) {
    const mini = document.getElementById("retrato-mini");
    if (mini) {
      mini.innerHTML = "";
      mini.appendChild(retratoImagem(IMG_JOGADOR, CLASSE_SIMBOLO[d.class_id] || "🧙"));
    }
  }
  if (d.gold !== undefined) animarNumero(document.getElementById("topo-ouro"), d.gold || 0, (v) => v.toLocaleString("pt-BR"));
  if (d.premium !== undefined) animarNumero(document.getElementById("topo-premium"), d.premium || 0, (v) => v.toLocaleString("pt-BR"));
  if (d.tower_floor !== undefined) document.getElementById("topo-andar").textContent = d.tower_floor ?? 1;
}

// =============================================================================
// 🎒 INVENTÁRIO
// =============================================================================
const SLOT_LISTA = ["weapon","armor","helmet","gloves","boots","shield","belt","necklace","ring"];
let INVENTARIO_SLOT_ATUAL = "weapon";

async function renderInventario() {
  const dados = await api("/api/inventory");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  const filtro = el("div", "filtro-carrossel");
  for (const slot of SLOT_LISTA) {
    const info = SLOT_INFO[slot];
    const chip = document.createElement("button");
    chip.className = "filtro-chip" + (slot === INVENTARIO_SLOT_ATUAL ? " ativo" : "");
    chip.dataset.invSlot = slot;
    chip.textContent = `${info.icone} ${info.rotulo}`;
    chip.onclick = () => { INVENTARIO_SLOT_ATUAL = slot; renderInventario(); };
    filtro.appendChild(chip);
  }
  c.appendChild(filtro);

  const dadosSlot = dados.slots[INVENTARIO_SLOT_ATUAL];

  // Item da mochila no mesmo cartão grande dos espíritos: os atributos viram
  // pílulas e os sockets deixam de ser uma linha de texto perdida. Antes o
  // cartão fino não mostrava o que o item FAZ, e comparar dois exigia abrir
  // os dois.
  const cartaoDeItem = (item, rotulo, aoTocar, extra, equipado) => marcarEquipar(rotulo, cartaoGrande({
    nome: item.nome, raridade: item.raridade, img_key: item.img_key, emoji: "⚔️",
    bonus_stats: item.bonus,
    // 📈 (26/09) o bônus de RARIDADE (+4% a +20%) — no atributo principal da
    // peça, ou no SORTEADO na forja (acessórios). O jogo sempre aplicou, mas
    // o cartão nunca mostrava.
    extras: [`💎 ${item.sockets_usados}/${item.sockets_max} sockets`].concat(textoBonusRaridade(item.bonus_raridade)),
    destacado: !!equipado, selo: equipado ? "equipado" : null,
    acoes: [{ rotulo, principal: true, aoTocar }].concat(extra ? [extra] : []),
  }));

  c.appendChild(el("h3", "secao-titulo", "Equipado"));
  if (dadosSlot.equipado) {
    c.appendChild(carrossel([cartaoDeItem(dadosSlot.equipado, "Desequipar", async () => {
      await acaoInventario("/api/inventory/unequip", { slot: INVENTARIO_SLOT_ATUAL });
    }, null, true)], estadoVazio("⚔️", "")));
  } else {
    const vazio = el("div", "equip-slot vazio");
    vazio.style.width = "100%";
    vazio.appendChild(el("div", "", "Nenhum item equipado neste slot."));
    c.appendChild(vazio);
  }

  c.appendChild(el("h3", "secao-titulo", `Mochila (${dadosSlot.mochila.length})`));
  const cartoesMochila = dadosSlot.mochila.map((item) => cartaoDeItem(
    item, "Equipar",
    async () => { await acaoInventario("/api/inventory/equip", { slot: INVENTARIO_SLOT_ATUAL, idx: item.idx }); },
    { rotulo: "💰 Vender", aoTocar: async () => {
        const r = await api("/api/shop/sell_item", { method: "POST",
          body: JSON.stringify({ slot: INVENTARIO_SLOT_ATUAL, idx: item.idx }) });
        som.moeda(); toast(r.msg.replace(/<[^>]+>/g, "")); atualizarTopo({ gold: r.gold });
        await renderInventario();
      } }));
  c.appendChild(carrossel(cartoesMochila, estadoVazio("🎒",
    "Mochila vazia neste slot. Forje ou ganhe itens explorando a Torre.")));
}

async function acaoInventario(caminho, corpo) {
  try {
    const r = await api(caminho, { method: "POST", body: JSON.stringify(corpo) });
    som.clique();
    toast(r.msg);
    await renderInventario();
  } catch (e) {
    som.erro();
    if (!e.jaAlertado) toast(e.message, true);
  }
}

// =============================================================================
// 🐾 ESQUADRÃO DE ESPÍRITOS
// =============================================================================
/** 🔮 (26/09/2026) Fusão: 5 cópias extras de uma raridade → 15% de chance
 *  de um espírito da raridade de cima. Sempre fica 1 de cada espírito. */
const NOME_RARIDADE_PET = { comum: "comum", incomum: "incomum", raro: "raro", epico: "épico", lendario: "lendário" };
function painelDeFusao(f) {
  const box = el("div", "aldeia-box fusao");
  box.appendChild(el("div", "aldeia-estagio", "🔮 Fusão de espíritos"));
  box.appendChild(el("p", "texto-fraco",
    `${f.qtd} espíritos da mesma raridade → ${f.chance}% de chance de um da raridade de cima. ` +
    "Dando certo ou não, os 5 são consumidos. Só usa cópias extras: sempre fica 1 de cada espírito."));
  const ordem = ["comum", "incomum", "raro", "epico"];
  for (let i = 0; i < ordem.length; i++) {
    const r = ordem[i], acima = ["incomum", "raro", "epico", "lendario"][i];
    const tem = (f.extras || {})[r] || 0;
    const b = document.createElement("button");
    b.className = "botao-secundario fusao-opcao";
    b.disabled = tem < f.qtd;
    b.appendChild(el("div", "cronica-opcao-texto", `5 ${NOME_RARIDADE_PET[r]} → ${NOME_RARIDADE_PET[acima]}`));
    b.appendChild(el("div", "cronica-opcao-extra",
      `você tem ${tem} extra(s)${tem >= f.qtd ? ` · dá pra tentar ${Math.floor(tem / f.qtd)}x` : ""} · 🎲 ${f.chance}%`));
    b.onclick = () => fundirEspiritos(r, acima, b);
    box.appendChild(b);
  }
  return box;
}

async function fundirEspiritos(raridade, acima, botao) {
  if (!confirm(`Usar 5 espíritos ${NOME_RARIDADE_PET[raridade]} (cópias extras) pra tentar um ${NOME_RARIDADE_PET[acima]}? ` +
               "Se não der certo, os 5 somem.")) return;
  botao.disabled = true;
  try {
    const r = await api("/api/pets/fundir", { method: "POST", body: JSON.stringify({ raridade }) });
    const gastos = r.gastos.map((g) => `${g.nome}${g.qtd > 1 ? ` ×${g.qtd}` : ""}`).join(", ");
    if (r.sucesso) {
      som.raro(); flashDourado();
      notificacaoGrande("🔮", "A fusão deu certo!", `${r.ganho.nome} (${NOME_RARIDADE_PET[r.ganho.raridade]})`);
    } else {
      som.erro();
      toast(`A fusão falhou. Foram consumidos: ${gastos}.`);
    }
    await renderPets();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); botao.disabled = false; }
}

async function renderPets() {
  const dados = await api("/api/pets");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  c.appendChild(el("h3", "secao-titulo", "Esquadrão (toque pra trocar)"));
  const deckGrid = el("div", "pets-grid");
  dados.deck.forEach((pet, idx) => {
    const card = el("div", `pet-slot${pet ? "" : " vazio"}`);
    if (pet) card.append(el("div", "", "🐾"), el("div", "pet-slot-nivel", `Nv.${pet.nivel}`));
    else card.appendChild(el("div", "", "vazio"));
    card.style.cursor = "pointer";
    card.onclick = () => abrirEscolherPetSheet(idx, dados.owned);
    deckGrid.appendChild(card);
  });
  c.appendChild(deckGrid);

  if (dados.fusao) c.appendChild(painelDeFusao(dados.fusao));
  c.appendChild(el("h3", "secao-titulo", `Espíritos (${dados.owned.length})`));
  const noDeck = new Set(dados.deck.filter(Boolean).map((d) => d.pet_id));
  const cards = dados.owned.map((pet) => cartaoGrande({
    nome: pet.nome, raridade: pet.raridade, quantidade: pet.quantidade,
    evolucao: pet.evolucao, nivel: pet.nivel, img_key: pet.img_key, emoji: "🐾",
    arquetipo: pet.arquetipo, bonus_stats: pet.bonus_stats,
    mecanica: pet.mecanica, economia: pet.economia,
    destacado: noDeck.has(pet.pet_id),
    selo: noDeck.has(pet.pet_id) ? "no esquadrão" : null,
    // O verso: o que o bicho FAZ em combate. A skill automática estava no
    // PETS_DB desde sempre e nunca chegava na tela — montava-se o esquadrão
    // sem saber o que cada um dispara.
    // ⚔️ Os atributos de combate, na frente do cartão. É a informação que
    // decide o esquadrão, e ela vivia só no motor da Arena.
    stats_combate: pet.stats,
    verso: (v) => {
      v.appendChild(el("div", "peca-verso-titulo", pet.nome));
      if (pet.arquetipo && ROTULO_ARQUETIPO[pet.arquetipo]) {
        v.appendChild(el("div", "peca-verso-texto", ROTULO_ARQUETIPO[pet.arquetipo]));
      }
      // As 4 opções que este pet leva pra Arena. Antes a tela mostrava
      // uma "skill automática" que não existe mais: quem escolhe é o
      // jogador, e são quatro.
      for (const acao of (pet.acoes || [])) {
        const l = el("div", "peca-verso-linha");
        l.append(el("span", "", `${acao.icone} ${acao.nome}`),
                 el("span", "", acao.recarga ? `${acao.recarga}t` : "—"));
        v.appendChild(l);
      }
      if (pet.auto_skill) {
        v.appendChild(el("div", "peca-verso-texto",
          `Dispara sozinho: ${pet.auto_skill.nome}`));
        const l = el("div", "peca-verso-linha");
        l.append(el("span", "", "Recarga"), el("span", "", `${pet.auto_skill.cooldown} turnos`));
        v.appendChild(l);
        if (pet.auto_skill.forca) {
          const f = el("div", "peca-verso-linha");
          f.append(el("span", "", "Força"),
                   el("span", "", `${Math.round(pet.auto_skill.forca * 100)}%`));
          v.appendChild(f);
        }
      } else {
        v.appendChild(el("div", "peca-verso-texto", "Não dispara skill sozinho."));
      }
      const mec = descreverMecanica(pet.mecanica);
      if (mec) v.appendChild(el("div", "peca-verso-texto", mec));
      const eco = descreverEconomia(pet.economia);
      if (eco) v.appendChild(el("div", "peca-verso-texto", eco));
      const nv = el("div", "peca-verso-linha");
      nv.append(el("span", "", "Nível"), el("span", "", `${pet.nivel}/100`));
      v.appendChild(nv);
    },
    acoes: [
      { rotulo: "⭐ Evoluir", principal: true,
        aoTocar: () => acaoPet("/api/pets/evolve", { pet_id: pet.pet_id }, () => {
          notificacaoGrande("⭐", "Evoluiu!", pet.nome);
        }) },
      { rotulo: "📈 Nível", aoTocar: () => abrirNivelSheet(pet) },
    ],
  }));
  c.appendChild(carrossel(cards, estadoVazio("🐾",
    "Você ainda não tem espíritos. Ganhe alguns explorando ou no Templo de Evocação.")));
}

// =============================================================================
// 🎠 CARTÃO GRANDE + CARROSSEL — espíritos, montarias, itens e cores
// =============================================================================
// Antes os dois eram uma pilha vertical de cartões finos com miniatura de
// lado. Com 50 espíritos possíveis isso vira rolagem infinita, e o cartão
// não dizia o que a criatura FAZ — escolher entre duas era escolher pelo
// nome.
//
// Agora é um card por vez, grande, com o que decide a escolha: arte, raridade,
// evolução, bônus de atributo e a mecânica em português. Rola de lado com
// encaixe (scroll-snap), que no celular é gesto mais barato que rolar uma
// lista longa procurando.

// Ícone de cada recurso do clã. Um lugar só: a tela do clã, a lista de
// áreas e o diário mostram os mesmos quatro.
const ICONE_RECURSO = { comida: "🌾", madeira: "🪵", couro: "🐂", metal: "⛏️" };

const ROTULO_STAT = {
  atk: "Ataque", def: "Defesa", hp: "Vida", hp_max: "Vida máx.",
  spd: "Velocidade", crit: "Crítico", eva: "Esquiva", reg: "Regeneração",
};

const ROTULO_MECANICA = {
  // montarias
  tp_discount: (v) => `Teleporte ${Math.round(v * 100)}% mais barato`,
  explore_gold_pct: (v) => `+${Math.round(v * 100)}% de ouro explorando`,
  explore_xp_pct: (v) => `+${Math.round(v * 100)}% de XP explorando`,
  // espíritos
  dmg_amp: (v) => `+${Math.round(v * 100)}% de dano`,
  dmg_red: (v) => `−${Math.round(v * 100)}% de dano recebido`,
  cooldown_red: (v) => `−${Math.round(v * 100)}% de recarga de skill`,
  eva_amp: (v) => `+${Math.round(v * 100)}% de esquiva`,
  lifesteal: (v) => `${Math.round(v * 100)}% do dano vira vida`,
};

const ROTULO_ECONOMIA = {
  xp: "XP", gold: "Ouro", drop: "Chance de drop", fusion_chance: "Chance de fusão",
  craft_comum: "Forja comum", craft_incomum: "Forja incomum", craft_raro: "Forja rara",
  craft_epico: "Forja épica", craft_lendario: "Forja lendária",
};

const ROTULO_ARQUETIPO = {
  dps: "⚔️ Dano", tank: "🛡️ Tanque", healer: "💚 Cura",
  buffer: "✨ Suporte", utility: "🔧 Utilidade",
};

function descreverMecanica(mec) {
  if (!mec || !mec.type) return null;
  const f = ROTULO_MECANICA[mec.type];
  return f ? f(Number(mec.value) || 0) : null;
}

function descreverEconomia(eco) {
  if (!eco || !eco.type) return null;
  const nome = ROTULO_ECONOMIA[eco.type];
  if (!nome) return null;
  return `+${Math.round((Number(eco.value) || 0) * 100)}% ${nome}`;
}

/** Cartão grande, usado por espírito, montaria, item da mochila e core da
 *  forja. `op` traz o que mostrar e os botões de ação.
 *
 *  A regra que mantém isto coeso: o cartão mostra o que a peça FAZ, não só
 *  o nome dela. Foi por isso que ele nasceu — escolher entre dois espíritos
 *  era escolher pelo nome, e na mochila e na forja era o mesmo problema. */
/** O botão "Equipar" do cartão ganha a classe que o guia inicial procura. */
function marcarEquipar(rotulo, cartao) {
  if (rotulo === "Equipar") {
    const b = [...cartao.querySelectorAll("button")].find((x) => x.textContent.includes("Equipar"));
    if (b) b.classList.add("btn-equipar");
  }
  return cartao;
}

function textoBonusRaridade(br) {
  if (!br) return [];
  const nome = ROTULO_STAT[br.stat] || String(br.stat).toUpperCase();
  return [br.sorteado ? `🎲 +${br.pct}% ${nome} (sorteado)` : `📈 +${br.pct}% ${nome} (raridade)`];
}

function cartaoGrande(op) {
  const card = el("div", `peca-card ${classeRar(op.raridade)}` +
    (op.destacado ? " destacado" : ""));

  const arte = el("div", "peca-arte");
  if (op.img_key) porFundo(arte, urlImagem(op.img_key, 200));
  else if (op.arteEl) arte.appendChild(op.arteEl);   // (25/09) emblema de skill
  else arte.textContent = op.emoji || "🐾";
  if (op.selo) arte.appendChild(el("div", "peca-selo", op.selo));

  // 🃏 CARTA QUE VIRA.
  //
  // Quando há `verso`, tocar a arte gira o cartão e mostra os detalhes
  // atrás. Isso existe porque o detalhe é MUITO — descrição da skill, o que
  // o pet dispara, o gatilho da especialidade — e enfiar tudo na frente
  // faria o cartão virar parágrafo, perdendo o que o carrossel tem de bom:
  // dá pra passar o olho.
  //
  // A frente continua completa por si: quem nunca virar a carta ainda vê
  // nome, raridade e bônus. Virar acrescenta, não desbloqueia.
  if (op.verso) {
    const giro = el("div", "peca-giro");
    const frente = el("div", "peca-face peca-frente");
    frente.appendChild(arte);
    frente.appendChild(el("div", "peca-virar", "toque para ver"));
    const verso = el("div", "peca-face peca-verso");
    op.verso(verso);
    giro.append(frente, verso);

    const palco = document.createElement("button");
    palco.className = "peca-palco";
    palco.setAttribute("aria-label", `Ver detalhes de ${op.nome}`);
    palco.appendChild(giro);
    palco.onclick = () => {
      const virada = palco.classList.toggle("virada");
      palco.setAttribute("aria-label",
        virada ? `Ver a arte de ${op.nome}` : `Ver detalhes de ${op.nome}`);
      som.clique();
    };
    card.appendChild(palco);
  } else {
    card.appendChild(arte);
  }

  const corpo = el("div", "peca-corpo");
  corpo.appendChild(el("div", "peca-nome", op.nome));

  const meta = el("div", "peca-meta");
  meta.appendChild(el("span", `peca-raridade rar-texto-${op.raridade || "comum"}`,
    (op.raridade || "comum").toUpperCase()));
  if (op.arquetipo && ROTULO_ARQUETIPO[op.arquetipo]) {
    meta.appendChild(el("span", "peca-arquetipo", ROTULO_ARQUETIPO[op.arquetipo]));
  }
  if (op.quantidade > 1) meta.appendChild(el("span", "peca-qtd", `${op.quantidade}x`));
  corpo.appendChild(meta);

  if (op.evolucao) {
    const linha = el("div", "peca-evo");
    linha.appendChild(estrelasEvolucao(op.evolucao));
    if (op.nivel) linha.appendChild(el("span", "peca-nivel", `Nv.${op.nivel}/100`));
    corpo.appendChild(linha);
  }

  // ⚔️ Atributos de combate, quando quem chamou mandou. São o que decide
  // o esquadrão da Arena, e ficavam só dentro do motor.
  if (op.stats_combate) {
    const st = op.stats_combate;
    const grade = el("div", "peca-stats");
    for (const [icone, rotulo, valor] of [
      ["❤️", "Vida", st.hp_max], ["⚔️", "Ataque", st.atk],
      ["🛡️", "Defesa", st.def], ["💨", "Velocidade", st.spd],
      ["🎯", "Precisão", st.acc], ["💥", "Crítico", st.crit],
    ]) {
      if (valor === undefined) continue;
      const celula = el("div", "peca-stat");
      celula.append(el("span", "peca-stat-icone", icone),
                    el("span", "peca-stat-rotulo", rotulo),
                    el("span", "peca-stat-valor", String(valor)));
      grade.appendChild(celula);
    }
    corpo.appendChild(grade);
  }

  // O que a criatura FAZ — é isto que decide a escolha.
  const efeitos = el("div", "peca-efeitos");
  for (const [chave, valor] of Object.entries(op.bonus_stats || {})) {
    const pill = el("div", "peca-pill");
    pill.append(el("span", "peca-pill-nome", ROTULO_STAT[chave] || chave),
                el("span", "peca-pill-valor", `+${valor}`));
    efeitos.appendChild(pill);
  }
  // Bônus percentuais. ⚠️ Vêm como FRAÇÃO da API (0.03 = 3%), não como
  // número já em porcento — conferido no core_bonus_pct.
  for (const [chave, valor] of Object.entries(op.bonus_pct || {})) {
    const pill = el("div", "peca-pill");
    pill.append(el("span", "peca-pill-nome", ROTULO_STAT[chave] || chave),
                el("span", "peca-pill-valor", `+${Math.round(Number(valor) * 100)}%`));
    efeitos.appendChild(pill);
  }
  const mec = descreverMecanica(op.mecanica);
  if (mec) efeitos.appendChild(el("div", "peca-pill destaque", mec));
  const eco = descreverEconomia(op.economia);
  if (eco) efeitos.appendChild(el("div", "peca-pill destaque", eco));
  // Pílulas livres: sockets do item, quantidade de core, o que a tela quiser.
  for (const extra of op.extras || []) {
    if (extra) efeitos.appendChild(el("div", "peca-pill", extra));
  }
  if (efeitos.childNodes.length) corpo.appendChild(efeitos);

  if (op.acoes && op.acoes.length) {
    const acoes = el("div", "peca-acoes");
    for (const a of op.acoes) {
      const btn = document.createElement("button");
      btn.className = a.principal ? "botao-holofote" : "botao-secundario";
      btn.textContent = a.rotulo;
      if (a.desabilitado) { btn.disabled = true; btn.style.opacity = "0.45"; }
      else btn.onclick = a.aoTocar;
      acoes.appendChild(btn);
    }
    corpo.appendChild(acoes);
  }

  card.appendChild(corpo);
  return card;
}

/** Trilho horizontal com encaixe. Vazio vira estado vazio, não uma faixa oca. */
function carrossel(cards, vazio) {
  if (!cards.length) return vazio;
  const trilho = el("div", "peca-carrossel");
  cards.forEach((c) => trilho.appendChild(c));
  return trilho;
}

function estrelasEvolucao(atual, max = 5) {
  const span = el("span", "estrelas-evo");
  for (let i = 1; i <= max; i++) {
    span.appendChild(el("span", `estrela-pip${i <= atual ? " cheia" : ""}`, "★"));
  }
  return span;
}

function abrirEscolherPetSheet(slotIdx, owned) {
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", "Escolher espírito"));
  const btnLimpar = document.createElement("button");
  btnLimpar.className = "botao-secundario sheet-opcao";
  btnLimpar.textContent = "🗑️ Deixar vazio";
  btnLimpar.onclick = () => { fecharSheet(); acaoPet("/api/pets/equip", { pet_id: null, slot_idx: slotIdx }); };
  corpo.appendChild(btnLimpar);
  for (const pet of owned) {
    const btn = document.createElement("button");
    btn.className = "botao-secundario sheet-opcao";
    btn.textContent = `${pet.nome} (⭐${pet.evolucao} Nv.${pet.nivel})`;
    btn.onclick = () => { fecharSheet(); acaoPet("/api/pets/equip", { pet_id: pet.pet_id, slot_idx: slotIdx }); };
    corpo.appendChild(btn);
  }
  abrirSheet(corpo);
}

function abrirNivelSheet(pet) {
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", `Subir nível — ${pet.nome}`));
  corpo.appendChild(el("p", "texto-fraco", "Escolha a raridade e quantos espíritos sacrificar como material."));

  const selectRaridade = document.createElement("select");
  selectRaridade.className = "sheet-select";
  for (const r of ["comum", "incomum", "raro", "epico", "lendario"]) {
    const opt = document.createElement("option");
    opt.value = r; opt.textContent = r.toUpperCase();
    selectRaridade.appendChild(opt);
  }
  const inputQtd = document.createElement("input");
  inputQtd.type = "number"; inputQtd.min = "1"; inputQtd.value = "1";
  inputQtd.className = "sheet-input";

  corpo.append(selectRaridade, inputQtd);

  const btnConfirmar = document.createElement("button");
  btnConfirmar.className = "botao-holofote sheet-opcao";
  btnConfirmar.textContent = "✅ Sacrificar e subir nível";
  btnConfirmar.onclick = () => {
    fecharSheet();
    acaoPet("/api/pets/level", { pet_id: pet.pet_id, raridade: selectRaridade.value, quantidade: parseInt(inputQtd.value, 10) || 1 });
  };
  corpo.appendChild(btnConfirmar);
  abrirSheet(corpo);
}

async function acaoPet(caminho, corpo, aoSucesso) {
  try {
    const r = await api(caminho, { method: "POST", body: JSON.stringify(corpo) });
    if (r.ok === false) { som.erro(); toast(r.msg, true); return; }
    som.moeda();
    toast(r.msg.replace(/<[^>]+>/g, "")); // tira as tags HTML da mensagem do bot pro toast
    if (aoSucesso) aoSucesso();
    await renderPets();
  } catch (e) {
    som.erro();
    if (!e.jaAlertado) toast(e.message, true);
  }
}

// =============================================================================
// ⚔️ SKILLS
// =============================================================================
// =============================================================================
// 🔷 EMBLEMA DE SKILL (25/09/2026, dev: "cria imagem pra cada skill")
// -----------------------------------------------------------------------------
// 211 skills, 22 famílias (a 2ª parte do id: a_FIRE_3, p_VENOM_2...). Cada
// família tem um SÍMBOLO desenhado em SVG; a RARIDADE dá a cor e o brilho
// da moldura (e os pontinhos embaixo); ATIVA é redonda, PASSIVA é hexágono.
// Família × raridade × tipo = um emblema próprio pra cada skill, sem baixar
// imagem nenhuma e nítido em qualquer tamanho.
// =============================================================================
const GLIFO_SKILL = {
  fire: "M12 3c1 3 4 5 4 9a4 4 0 0 1-8 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 0-8z",
  ice: "M12 3v18M4.2 7.5l15.6 9M19.8 7.5l-15.6 9M9.5 4.5 12 6l2.5-1.5M9.5 19.5 12 18l2.5 1.5",
  thunder: "M13 2 5 14h6l-1 8 8-12h-6l1-8z",
  sword: "M14.5 3.5 20 3l-.5 5.5L9 19l-4-4L14.5 3.5zM5 15l-2 2 4 4 2-2M7 17l-3 3",
  glove: "M7 11V7a2 2 0 0 1 4 0v4M11 10V6a2 2 0 0 1 4 0v5M15 10a2 2 0 0 1 4 0v4a6 6 0 0 1-6 6h-2a6 6 0 0 1-6-6v-3a2 2 0 0 1 2-2",
  spear: "M4 20 17 7M17 7l3-4-4 1 1 3zM13 7l4 4M6 18l-2 2",
  shadow: "M19 14.5A7.5 7.5 0 1 1 9.5 5a6 6 0 0 0 9.5 9.5z",
  fatal: "M12 5a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM12 2v5M12 17v5M2 12h5M17 12h5M12 10.5v3M10.5 12h3",
  venom: "M12 3s6 7 6 11a6 6 0 0 1-12 0c0-4 6-11 6-11zM10 13.5h.01M14 13.5h.01M10 17c1.3.8 2.7.8 4 0",
  heal: "M10 4h4v6h6v4h-6v6h-4v-6H4v-4h6z",
  balance: "M5 19c0-8 6-14 14-14 0 8-6 14-14 14zM5 19l8-8",
  support: "M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2zM19 3v4M17 5h4",
  thorns: "M12 2l1.8 5L19 5l-2 5.2L22 12l-5 1.8L19 19l-5.2-2L12 22l-1.8-5L5 19l2-5.2L2 12l5-1.8L5 5l5.2 2z",
  stone: "M4 16l3-8 6-3 6 5 1 7-8 3zM10 9l2 4-2 3",
  shield: "M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6zM12 7v10M8 11h8",
  fury: "M6 4c2 5 2 11 0 16M12 3c2 6 2 12 0 18M18 4c2 5 2 11 0 16",
  vitality: "M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10zM8 11h2l1-2 2 4 1-2h2",
  blood: "M12 3s5 6 5 10a5 5 0 0 1-10 0c0-4 5-10 5-10zM9 9l1.5 3M15 9l-1.5 3",
  hunter: "M6 3c8 3 8 15 0 18M6 3v18M4 12h15M16 9l3 3-3 3",
  arrow: "M4 20 19 5M13 4h7v7M4 20l1-4 3 3z",
  wind: "M3 8h11a3 3 0 1 0-3-3M3 12h15a3 3 0 1 1-3 3M3 16h8",
  starter: "M12 3l2.5 6H21l-5 4 2 7-6-4-6 4 2-7-5-4h6.5z",
};
const COR_RARIDADE_SKILL = ["var(--rar-comum)", "var(--rar-incomum)", "var(--rar-raro)", "var(--rar-epico)", "var(--rar-lendario)"];

function emblemaSkill(skillId, raridade, tipo, tamanho = 40) {
  const partes = String(skillId || "").split("_");
  const familia = partes.length > 2 ? partes[1] : (partes[0] || "starter");
  const rar = Math.max(1, Math.min(5, Number(raridade) || Number(partes[partes.length - 1]) || 1));
  const passiva = tipo ? tipo === "passive" : partes[0] === "p";
  const cor = COR_RARIDADE_SKILL[rar - 1];
  const glifo = GLIFO_SKILL[familia] || GLIFO_SKILL.starter;
  const forma = passiva
    ? '<path d="M20 2.5 35.2 11.25v17.5L20 37.5 4.8 28.75v-17.5z"/>'
    : '<circle cx="20" cy="20" r="17.5"/>';
  const pontos = tamanho >= 30 ? Array.from({ length: rar }, (_, i) =>
    `<circle cx="${20 - (rar - 1) * 2.4 + i * 4.8}" cy="34.3" r="1.25" fill="${cor}" stroke="none"/>`).join("") : "";
  const brilho = rar >= 4 ? ` style="filter:drop-shadow(0 0 ${rar === 5 ? 5 : 3}px ${cor})"` : "";
  const caixa = el("span", "emblema-skill");
  caixa.style.width = caixa.style.height = `${tamanho}px`;
  caixa.innerHTML = `<svg viewBox="0 0 40 40" width="${tamanho}" height="${tamanho}" aria-hidden="true"${brilho}>`
    + `<g fill="var(--vazio-alto)" stroke="${cor}" stroke-width="2">${forma}</g>`
    + `<g transform="translate(9 8.5) scale(0.92)" fill="none" stroke="${cor}" stroke-width="1.8"`
    + ` stroke-linecap="round" stroke-linejoin="round"><path d="${glifo}"/></g>${pontos}</svg>`;
  return caixa;
}

/** Botão de skill com o emblema na frente do nome. */
function botaoComEmblema(btn, skillId, texto, raridade, tipo) {
  btn.textContent = "";
  btn.classList.add("botao-com-emblema");
  btn.append(emblemaSkill(skillId, raridade, tipo, 26), el("span", "", texto));
  return btn;
}

async function renderSkills() {
  const dados = await api("/api/skills");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  c.appendChild(el("h3", "secao-titulo", "Slots Equipados"));
  const slotsGrid = el("div", "pets-grid");
  dados.equipadas.forEach((skId, idx) => {
    const skill = dados.aprendidas.find((s) => s.skill_id === skId);
    const card = el("div", `pet-slot${skill ? "" : " vazio"}`);
    if (skill) card.append(emblemaSkill(skill.skill_id, skill.raridade, skill.tipo, 34), el("div", "pet-slot-nivel", skill.nome.slice(0, 8)));
    else card.appendChild(el("div", "", "vazio"));
    card.style.cursor = "pointer";
    card.onclick = () => abrirEscolherSkillSheet(idx, dados.aprendidas);
    slotsGrid.appendChild(card);
  });
  c.appendChild(slotsGrid);

  c.appendChild(el("h3", "secao-titulo", `Skills Aprendidas (${dados.aprendidas.length})`));
  const RAR_NUM = ["comum", "incomum", "raro", "epico", "lendario"];
  const cartoesSkill = dados.aprendidas.map((sk) => cartaoGrande({
    nome: sk.nome,
    raridade: RAR_NUM[sk.raridade - 1] || "comum",
    arteEl: emblemaSkill(sk.skill_id, sk.raridade, sk.tipo, 96),
    bonus_stats: sk.bonuses,
    bonus_pct: sk.bonus_pct,
    extras: [`Nv.${sk.nivel}/${sk.nivel_max}`]
      .concat(sk.tipo === "passive" ? ["passiva"] : [])
      .concat(sk.cooldown ? [`recarga ${sk.cooldown}t`] : []),
    destacado: sk.equipado_em !== null,
    selo: sk.equipado_em !== null ? `slot ${sk.equipado_em + 1}` : null,
    // O verso: o que a skill faz e como evoluir. A evolução JÁ EXISTIA no
    // motor (usar o core de novo sobe o nível), mas nenhuma tela dizia isso
    // nem qual core usar — a mecânica estava lá e ninguém alcançava.
    verso: (v) => {
      v.appendChild(el("div", "peca-verso-titulo", sk.nome));
      if (sk.bonus_texto) {
        v.appendChild(el("div", "peca-verso-texto",
          sk.bonus_texto.replace(/<[^>]+>/g, "")));
      }
      if (sk.mult) {
        const l = el("div", "peca-verso-linha");
        l.append(el("span", "", "Dano"), el("span", "", `${Math.round(sk.mult * 100)}%`));
        v.appendChild(l);
      }
      if (sk.alvo) {
        const l = el("div", "peca-verso-linha");
        l.append(el("span", "", "Alvo"), el("span", "", sk.alvo));
        v.appendChild(l);
      }
      const nl = el("div", "peca-verso-linha");
      nl.append(el("span", "", "Nível"), el("span", "", `${sk.nivel} de ${sk.nivel_max}`));
      v.appendChild(nl);
      if (sk.evolucao) {
        const ev = el("div", "peca-verso-texto");
        ev.style.color = sk.evolucao.tem >= sk.evolucao.custo ? "var(--rar-incomum)" : "var(--tinta-fraca)";
        ev.textContent = `Evoluir: ${sk.evolucao.custo}x ${sk.evolucao.core_nome} `
          + `(você tem ${sk.evolucao.tem}) · ${sk.evolucao.ganho}`;
        v.appendChild(ev);
      } else {
        v.appendChild(el("div", "peca-verso-texto", "Nível máximo."));
      }
    },
    acoes: [
      // Evoluir só aparece quando dá pra fazer: botão que existe pra
      // recusar é pior que botão ausente.
      ...(sk.evolucao && sk.evolucao.tem >= sk.evolucao.custo
        ? [{ rotulo: `⬆️ Nv.${sk.nivel + 1}`, principal: true,
             aoTocar: () => aprenderSkill(sk.evolucao.core_id, sk.nome, renderSkills) }]
        : []),
      ...(sk.raridade > 1
        ? [{ rotulo: "🎲 Re-rolar",
             aoTocar: () => rerolarSkill(sk.skill_id, sk.nome, renderSkills) }]
        : []),
    ],
  }));
  c.appendChild(carrossel(cartoesSkill, estadoVazio("📜",
    "Você ainda não aprendeu nenhuma skill. Derrote monstros pra dropar cores e aprenda aqui embaixo.")));

  // Cores de skill guardadas: é aqui que elas viram habilidade. Antes não
  // havia lugar nenhum no site pra trocar core por skill.
  if ((dados.cores_skill || []).length) {
    c.appendChild(el("h3", "secao-titulo", "Cores de skill"));
    for (const core of dados.cores_skill) {
      const linha = document.createElement("button");
      linha.className = "linha-lista";
      const texto = el("div", "linha-lista-texto");
      texto.appendChild(el("div", "linha-lista-titulo", `${core.nome} ×${core.qtd}`));
      texto.appendChild(el("div", "linha-lista-sub",
        core.ja_aprendida ? "Você já tem — usar evolui a skill" : "Ainda não aprendida"));
      linha.appendChild(texto);
      linha.appendChild(el("span", "linha-lista-seta", "›"));
      linha.onclick = () => aprenderSkill(core.id, core.nome, renderSkills);
      c.appendChild(linha);
    }
  }
}

function abrirEscolherSkillSheet(slotIdx, aprendidas) {
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", "Escolher skill"));
  const btnLimpar = document.createElement("button");
  btnLimpar.className = "botao-secundario sheet-opcao";
  btnLimpar.textContent = "🗑️ Deixar vazio";
  btnLimpar.onclick = () => { fecharSheet(); acaoSkill("/api/skills/unequip", { slot_idx: slotIdx }); };
  corpo.appendChild(btnLimpar);
  for (const sk of aprendidas) {
    const btn = document.createElement("button");
    btn.className = "botao-secundario sheet-opcao";
    botaoComEmblema(btn, sk.skill_id, `${sk.nome} (Nv.${sk.nivel})`, sk.raridade, sk.tipo);
    btn.onclick = () => { fecharSheet(); acaoSkill("/api/skills/equip", { skill_id: sk.skill_id, slot_idx: slotIdx }); };
    corpo.appendChild(btn);
  }
  abrirSheet(corpo);
}

async function acaoSkill(caminho, corpo) {
  try {
    const r = await api(caminho, { method: "POST", body: JSON.stringify(corpo) });
    som.clique();
    toast(r.msg.replace(/<[^>]+>/g, ""));
    await renderSkills();
  } catch (e) {
    som.erro();
    if (!e.jaAlertado) toast(e.message, true);
  }
}

// =============================================================================
// 📜 MISSÕES
// =============================================================================
async function renderMissoes() {
  // 📅 25/09/2026: as DIÁRIAS existiam no servidor desde 20/09 (/api/diarias,
  // game/diarias.py — o ouro do reino, ~4.000 por dia) e nenhuma tela as
  // chamava: o jogador nunca via nem resgatava. Agora são o topo desta tela.
  // As missões antigas (game/missions.py) são de uma vez só e ficam embaixo,
  // como "Primeiros passos". A Recompensa diária de login veio da Praça.
  const c = document.getElementById("conteudo");
  mostrarEsqueleto();
  let diarias = null, dados;
  try {
    [diarias, dados] = await Promise.all([
      api("/api/diarias").catch(() => null),
      api("/api/missions"),
    ]);
  } catch (e) { c.innerHTML = ""; if (!e.jaAlertado) toast(e.message, true); return; }
  c.innerHTML = "";

  const botaoLogin = document.createElement("button");
  botaoLogin.className = "botao-secundario";
  botaoLogin.style.cssText = "width:100%;margin-bottom:16px";
  botaoLogin.textContent = "🎁 Recompensa de login";
  botaoLogin.onclick = async () => {
    botaoLogin.disabled = true;
    try {
      const r = await api("/api/diario/resgatar", { method: "POST" });
      (r.ok ? som.moeda : som.erro)();
      toast(r.msg.replace(/<[^>]+>/g, ""), !r.ok);
      atualizarTopo({ gold: r.gold, premium: r.premium });
    } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    botaoLogin.disabled = false;
  };
  c.appendChild(botaoLogin);

  if (diarias) c.appendChild(painelDiarias(diarias));

  c.appendChild(el("h3", "secao-titulo", "Primeiros passos"));
  c.appendChild(el("p", "texto-fraco", "Missões de uma vez só: cada uma paga quando você cumpre."));
  // (o antigo "Resgatar todas" daqui nunca aparecia: contava m.pronta, campo
  // que /api/missions não manda, e chamava o Cultivo de Aura, não missões.
  // Se aparecesse, quebrava a tela — usava `c` antes de declarar.)
  for (const m of dados.missoes) {
    const card = el("div", "cartao-missao" + (m.resgatada ? " resgatada" : m.concluida ? " concluida" : ""));
    const info = el("div", "cartao-item-info");
    info.appendChild(el("div", "cartao-item-nome", m.nome));
    const desc = el("div", "missao-desc");
    desc.innerHTML = escaparHtml(m.desc).replace(/&lt;b&gt;/g, "<b>").replace(/&lt;\/b&gt;/g, "</b>");
    info.appendChild(desc);
    info.appendChild(el("div", "cartao-item-bonus", `💰 ${m.ouro}g${m.xp ? ` · ✨ ${m.xp}XP` : ""}`));
    card.appendChild(info);

    if (m.resgatada) {
      card.appendChild(el("div", "missao-selo", "✅ Resgatada"));
    } else if (m.concluida) {
      const btn = document.createElement("button");
      btn.className = "botao-holofote"; btn.style.width = "auto"; btn.textContent = "Resgatar";
      btn.onclick = () => acaoMissao(m.id);
      card.appendChild(btn);
    } else {
      card.appendChild(el("div", "missao-selo pendente", "⏳ Pendente"));
    }
    c.appendChild(card);
  }
  aplicarBadgeMissoes(contarMissoesProntas(diarias, dados));
}

/** Quantas coisas estão esperando resgate — diárias + bônus + missões. */
function contarMissoesProntas(diarias, dados) {
  let n = (dados?.missoes || []).filter((m) => m.concluida && !m.resgatada).length;
  if (diarias) {
    n += (diarias.diarias || []).filter((d) => d.pronta && !d.resgatada).length;
    if (diarias.bonus_pronto) n += 1;
  }
  return n;
}

/** As quatro diárias do reino, com barra de progresso e o bônus de fechar
 *  o dia. Fica fora da render pra o executar_appjs poder chamá-la. */
function painelDiarias(st) {
  const box = el("div", "diarias");
  const lista = st.diarias || [];
  const pago = lista.filter((d) => d.resgatada).reduce((s, d) => s + d.ouro, 0)
             + (st.bonus_resgatado ? st.bonus : 0);
  const topo = el("div", "diarias-topo");
  topo.appendChild(el("h3", "secao-titulo", "Diárias do reino"));
  topo.appendChild(el("div", "diarias-pago",
    `💰 ${pago.toLocaleString("pt-BR")} de ${(st.total || 0).toLocaleString("pt-BR")}`));
  box.appendChild(topo);
  box.appendChild(el("p", "texto-fraco", "O Império paga o trabalho do dia. Zeram à meia-noite."));

  const prontas = lista.filter((d) => d.pronta && !d.resgatada);
  if (prontas.length > 1) {
    const tudo = document.createElement("button");
    tudo.className = "botao-holofote";
    tudo.style.cssText = "width:100%;margin-bottom:10px";
    tudo.textContent = `Resgatar as ${prontas.length} prontas`;
    tudo.onclick = async () => {
      tudo.disabled = true;
      let ultimo = null;
      for (const d of prontas) {
        try { ultimo = await api("/api/diarias/resgatar", { method: "POST", body: JSON.stringify({ id: d.id }) }); }
        catch (e) { if (!e.jaAlertado) toast(e.message, true); break; }
      }
      if (ultimo) { som.moeda(); atualizarTopo({ gold: ultimo.gold }); toast("Diárias resgatadas."); }
      await renderMissoes();
    };
    box.appendChild(tudo);
  }

  for (const d of lista) {
    const card = el("div", "diaria" + (d.resgatada ? " resgatada" : d.pronta ? " pronta" : ""));
    const info = el("div", "diaria-info");
    const linha = el("div", "diaria-linha");
    linha.append(el("div", "diaria-nome", d.nome), el("div", "diaria-ouro", `💰 ${d.ouro.toLocaleString("pt-BR")}`));
    info.appendChild(linha);
    info.appendChild(el("div", "missao-desc", d.desc));
    const trilho = el("div", "diaria-trilho");
    const cheio = el("div", "diaria-cheio");
    cheio.style.width = `${Math.min(100, (d.progresso / Math.max(1, d.meta)) * 100)}%`;
    trilho.appendChild(cheio);
    info.appendChild(trilho);
    info.appendChild(el("div", "diaria-conta", `${d.progresso}/${d.meta}`));
    card.appendChild(info);
    if (d.resgatada) card.appendChild(el("div", "missao-selo", "✅"));
    else if (d.pronta) {
      const btn = document.createElement("button");
      btn.className = "botao-holofote"; btn.style.width = "auto"; btn.textContent = "Resgatar";
      btn.onclick = () => resgatarDiaria(d.id, btn);
      card.appendChild(btn);
    }
    box.appendChild(card);
  }

  const bonus = el("div", "diaria diaria-bonus" + (st.bonus_resgatado ? " resgatada" : st.bonus_pronto ? " pronta" : ""));
  const bInfo = el("div", "diaria-info");
  const bLinha = el("div", "diaria-linha");
  bLinha.append(el("div", "diaria-nome", "Dia completo"), el("div", "diaria-ouro", `💰 ${(st.bonus || 0).toLocaleString("pt-BR")}`));
  bInfo.appendChild(bLinha);
  bInfo.appendChild(el("div", "missao-desc", "Resgate as quatro diárias pra ganhar o bônus."));
  bonus.appendChild(bInfo);
  if (st.bonus_resgatado) bonus.appendChild(el("div", "missao-selo", "✅"));
  else if (st.bonus_pronto) {
    const btn = document.createElement("button");
    btn.className = "botao-holofote"; btn.style.width = "auto"; btn.textContent = "Resgatar";
    btn.onclick = () => resgatarDiaria("bonus", btn);
    bonus.appendChild(btn);
  }
  box.appendChild(bonus);
  return box;
}

async function resgatarDiaria(id, botao) {
  if (botao) botao.disabled = true;
  try {
    const r = await api("/api/diarias/resgatar", { method: "POST", body: JSON.stringify({ id }) });
    som.moeda();
    toast(r.msg);
    atualizarTopo({ gold: r.gold });
    await renderMissoes();
  } catch (e) {
    som.erro();
    if (!e.jaAlertado) toast(e.message, true);
    if (botao) botao.disabled = false;
  }
}

async function acaoMissao(missaoId) {
  try {
    const r = await api("/api/missions/claim", { method: "POST", body: JSON.stringify({ missao_id: missaoId }) });
    if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
    som.moeda();
    toast(r.msg.replace(/<[^>]+>/g, ""));
    await renderMissoes();
    await atualizarEstadoSilenciosoTopo();
  } catch (e) {
    som.erro();
    if (!e.jaAlertado) toast(e.message, true);
  }
}

async function atualizarEstadoSilenciosoTopo() {
  try {
    const d = await api("/api/character");
    atualizarTopo(d);
  } catch (e) { /* falha silenciosa — não atrapalha o que já deu certo */ }
}

// =============================================================================
// 🏆 RANKING
// =============================================================================
let RANKING_TIPO_ATUAL = "floors";
let MEU_ID = null;

const RANKING_ABAS = [
  { tipo: "floors", rotulo: "🗼 Andar" },
  { tipo: "gold", rotulo: "💰 Ouro" },
  { tipo: "level", rotulo: "✨ Nível" },
  { tipo: "arena", rotulo: "⚔️ Arena" },
];

async function renderRanking() {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  const filtro = el("div", "filtro-carrossel");
  for (const aba of RANKING_ABAS) {
    const chip = document.createElement("button");
    chip.className = "filtro-chip" + (aba.tipo === RANKING_TIPO_ATUAL ? " ativo" : "");
    chip.textContent = aba.rotulo;
    chip.onclick = () => { RANKING_TIPO_ATUAL = aba.tipo; renderRanking(); };
    filtro.appendChild(chip);
  }
  c.appendChild(filtro);

  const dados = await api(`/api/ranking?tipo=${RANKING_TIPO_ATUAL}`);

  // 🟢 Quantos estão jogando agora — igual ao Mestre do Futebol. Num jogo
  // pequeno "0 online" às 3 da manhã não significa abandono, então as faixas
  // de 24h e semana vão junto: sozinho, o número instantâneo mente.
  const com = dados.comunidade;
  if (com && com.total !== undefined) {
    const faixa = el("div", "comunidade");
    const item = (valor, rotulo, classe) => {
      const box = el("div", "comunidade-item");
      box.appendChild(el("div", "comunidade-valor" + (classe ? " " + classe : ""), String(valor)));
      box.appendChild(el("div", "comunidade-rotulo", rotulo));
      return box;
    };
    faixa.append(
      item("🟢 " + com.online_agora, "online agora", "online"),
      item(com.ativos_24h, "nas últimas 24h"),
      item(com.ativos_7d, "na semana"),
      item(com.total, "no total"),
    );
    c.appendChild(faixa);
  }

  // 🏆 25/09/2026: pódio pros três primeiros (2º · 1º · 3º, o 1º mais
  // alto) em metal de troféu, e lista numerada do 4º em diante. A sua
  // linha acende — num top 10 o que o jogador procura primeiro é ele mesmo.
  if (dados.ranking.length === 0) {
    c.appendChild(estadoVazio("🏆", "Ninguém no ranking ainda. Ele se enche conforme as pessoas sobem a Torre — suba um andar e você já entra."));
    return;
  }
  const podio = montarPodio(dados);
  if (podio) c.appendChild(podio);
  const lista = el("div", "ranking-lista");
  dados.ranking.slice(3).forEach((jogador, i) => lista.appendChild(linhaDoRanking(jogador, i + 4, dados)));
  if (lista.children.length) c.appendChild(lista);
}

const RANKING_UNIDADE = { floor: "andar", gold: "ouro", level: "nível", arena_points: "pontos" };

function valorDoRanking(jogador, dados) {
  const v = jogador[dados.campo];
  return typeof v === "number" ? v.toLocaleString("pt-BR") : String(v ?? "—");
}

function ehVoce(jogador) {
  return MEU_ID != null && jogador.telegram_id != null && String(jogador.telegram_id) === String(MEU_ID);
}

/** Os três primeiros. Fora da render pra o executar_appjs poder chamar. */
function montarPodio(dados) {
  const top = dados.ranking.slice(0, 3);
  if (!top.length) return null;
  const podio = el("div", "podio");
  // ordem visual 2º, 1º, 3º; posição que falta vira coluna vazia
  for (const lugar of [2, 1, 3]) {
    const j = top[lugar - 1];
    const col = el("div", `podio-col lugar-${lugar}` + (j && ehVoce(j) ? " voce" : ""));
    if (j) {
      tornarAbrivelPerfil(col, j);
      col.appendChild(el("div", "podio-medalha", String(lugar)));
      col.appendChild(el("div", "podio-nome", j.username || "—"));
      const valor = el("div", "podio-valor");
      valor.append(el("span", "podio-icone", dados.icone || ""), el("b", "", valorDoRanking(j, dados)));
      col.appendChild(valor);
      if (ehVoce(j)) col.appendChild(el("div", "ranking-voce", "você"));
    }
    col.appendChild(el("div", "podio-base"));
    podio.appendChild(col);
  }
  return podio;
}

/** 👤 (28/09) tocar no jogador do ranking abre a ficha dele */
function tornarAbrivelPerfil(elemento, jogador) {
  if (jogador.telegram_id == null) return;
  elemento.classList.add("abre-perfil");
  elemento.setAttribute("role", "button");
  elemento.tabIndex = 0;
  elemento.title = `Ver a ficha de ${jogador.username || "jogador"}`;
  elemento.onclick = () => abrirPerfilJogador(jogador.telegram_id);
  elemento.onkeydown = (ev) => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); abrirPerfilJogador(jogador.telegram_id); } };
}

function linhaDoRanking(jogador, posicao, dados) {
  const linha = el("div", "ranking-linha" + (ehVoce(jogador) ? " voce" : ""));
  tornarAbrivelPerfil(linha, jogador);
  linha.appendChild(el("div", "ranking-posicao", String(posicao)));
  const nome = el("div", "ranking-nome");
  nome.appendChild(el("span", "", jogador.username || "—"));
  if (ehVoce(jogador)) nome.appendChild(el("span", "ranking-voce", "você"));
  if (dados.campo === "arena_points" && jogador.wins != null) {
    nome.appendChild(el("div", "ranking-sub", `${jogador.wins}V · ${jogador.losses ?? 0}D`));
  }
  const valor = el("div", "ranking-valor");
  valor.append(el("b", "", valorDoRanking(jogador, dados)),
               el("span", "ranking-unidade", RANKING_UNIDADE[dados.campo] || ""));
  linha.append(nome, valor, el("span", "ranking-seta", "›"));
  return linha;
}


// =============================================================================
// 🛡️ ESPECIALIDADE
// =============================================================================
async function renderEspecialidade() {
  const dados = await api("/api/specialties");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  c.appendChild(el("h3", "secao-titulo", "Slots (toque pra trocar)"));
  const grid = el("div", "pets-grid");
  dados.equipadas.forEach((specId, idx) => {
    const spec = dados.todas.find((s) => s.spec_id === specId);
    const card = el("div", `pet-slot${spec ? "" : " vazio"}`);
    if (spec) card.append(el("div", "", "🛡️"), el("div", "pet-slot-nivel", spec.nome.slice(0, 10)));
    else card.appendChild(el("div", "", "vazio"));
    card.style.cursor = "pointer";
    card.onclick = () => abrirEscolherEspecialidadeSheet(idx, dados.todas, dados.equipadas);
    grid.appendChild(card);
  });
  c.appendChild(grid);

  c.appendChild(el("h3", "secao-titulo", `Todas as Especialidades (${dados.todas.length})`));
  // Eram 21 cartões finos empilhados, com a descrição em prosa e nada que
  // permitisse comparar duas. Agora o verso traz os números.
  const ROTULO_GATILHO = {
    double_damage_chance: "Chance de dano duplo",
    crit_chance: "Chance de crítico", dodge_chance: "Chance de esquiva",
    lifesteal_chance: "Chance de roubo de vida",
    stun_chance: "Chance de atordoar", burn_chance: "Chance de queimar",
    freeze_chance: "Chance de congelar", reflect_chance: "Chance de refletir",
  };
  const cartoesSpec = dados.todas.map((spec) => {
    const equipada = dados.equipadas.includes(spec.spec_id);
    const livre = dados.equipadas.findIndex((x) => !x);
    return cartaoGrande({
      nome: spec.nome,
      raridade: equipada ? "epico" : "comum",
      emoji: "🛡️",
      bonus_pct: spec.passivas,
      destacado: equipada,
      selo: equipada ? "equipada" : null,
      verso: (v) => {
        v.appendChild(el("div", "peca-verso-titulo", spec.nome));
        v.appendChild(el("div", "peca-verso-texto", spec.desc));
        for (const [chave, valor] of Object.entries(spec.passivas || {})) {
          const l = el("div", "peca-verso-linha");
          l.append(el("span", "", ROTULO_STAT[chave] || chave.toUpperCase()),
                   el("span", "", `+${Math.round(valor * 100)}%`));
          v.appendChild(l);
        }
        for (const [chave, valor] of Object.entries(spec.gatilhos || {})) {
          const l = el("div", "peca-verso-linha");
          l.append(el("span", "", ROTULO_GATILHO[chave] || chave.replace(/_/g, " ")),
                   el("span", "", `${valor}%`));
          v.appendChild(l);
        }
      },
      acoes: equipada ? [] : [{
        rotulo: livre >= 0 ? "Equipar" : "Trocar por…",
        principal: true,
        aoTocar: () => {
          if (livre >= 0) {
            acaoEspecialidade("/api/specialties/equip",
              { spec_id: spec.spec_id, slot_idx: livre });
          } else {
            // Slots cheios: em vez de recusar, pergunta qual trocar. Botão
            // que só sabe dizer não é botão que não devia estar ali.
            abrirTrocarEspecialidadeSheet(spec, dados.equipadas, dados.todas);
          }
        },
      }],
    });
  });
  c.appendChild(carrossel(cartoesSpec, estadoVazio("🛡️", "Nenhuma especialidade.")));
}

/** Slots cheios: escolher qual sai pra esta entrar. */
function abrirTrocarEspecialidadeSheet(nova, equipadas, todas) {
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", `Trocar por ${nova.nome}`));
  corpo.appendChild(el("p", "texto-fraco", "Qual especialidade sai?"));
  equipadas.forEach((specId, idx) => {
    const atual = todas.find((s) => s.spec_id === specId);
    const btn = document.createElement("button");
    btn.className = "botao-secundario sheet-opcao";
    btn.textContent = `Slot ${idx + 1}: ${atual ? atual.nome : "vazio"}`;
    btn.onclick = () => {
      fecharSheet();
      acaoEspecialidade("/api/specialties/equip",
        { spec_id: nova.spec_id, slot_idx: idx });
    };
    corpo.appendChild(btn);
  });
  abrirSheet(corpo);
}

function abrirEscolherEspecialidadeSheet(slotIdx, todas, equipadas) {
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", "Escolher especialidade"));
  const btnLimpar = document.createElement("button");
  btnLimpar.className = "botao-secundario sheet-opcao";
  btnLimpar.textContent = "🗑️ Deixar vazio";
  btnLimpar.onclick = () => { fecharSheet(); acaoEspecialidade("/api/specialties/unequip", { slot_idx: slotIdx }); };
  corpo.appendChild(btnLimpar);
  for (const spec of todas) {
    if (equipadas.includes(spec.spec_id)) continue; // já equipada noutro slot
    const btn = document.createElement("button");
    btn.className = "botao-secundario sheet-opcao";
    btn.textContent = spec.nome;
    btn.onclick = () => { fecharSheet(); acaoEspecialidade("/api/specialties/equip", { spec_id: spec.spec_id, slot_idx: slotIdx }); };
    corpo.appendChild(btn);
  }
  abrirSheet(corpo);
}

async function acaoEspecialidade(caminho, corpo) {
  try {
    const r = await api(caminho, { method: "POST", body: JSON.stringify(corpo) });
    som.clique();
    toast(r.msg.replace(/<[^>]+>/g, ""));
    await renderEspecialidade();
  } catch (e) {
    som.erro();
    if (!e.jaAlertado) toast(e.message, true);
  }
}

// =============================================================================
// 🔮 TEMPLO DE EVOCAÇÃO (gacha de pets) + 🐴 ESTÁBULO (gacha de montarias)
// =============================================================================
async function renderGacha() {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  c.appendChild(el("p", "texto-fraco", "💰 1.000g por 1 evocação, ou 10.000g por 11 de uma vez."));

  const botoes = el("div", "gacha-botoes");
  const btn1 = document.createElement("button");
  btn1.className = "botao-secundario"; btn1.textContent = "🔮 Evocar 1x";
  btn1.onclick = () => acaoGacha("/api/gacha/roll", 1, renderGacha);
  const btn11 = document.createElement("button");
  btn11.className = "botao-holofote"; btn11.textContent = "✨ Evocar 11x";
  btn11.onclick = () => acaoGacha("/api/gacha/roll", 11, renderGacha);
  botoes.append(btn1, btn11);
  c.appendChild(botoes);
}

async function renderEstabulo() {
  const dados = await api("/api/stable");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  // O bloqueio é dito ANTES dos botões e com o motivo junto. Botão que não
  // explica por que está apagado é pior que botão que dá erro ao tocar.
  if (!dados.liberado) {
    const trava = el("div", "aviso-trava");
    trava.appendChild(el("div", "aviso-trava-icone", "🔒"));
    trava.appendChild(el("div", "aviso-trava-texto",
      `Montarias abrem no andar ${dados.andar_minimo}. Você está no ${dados.andar}.`));
    c.appendChild(trava);
  }
  c.appendChild(el("p", "texto-fraco", "💰 800g por 1 invocação, ou 8.000g por 11 de uma vez."));

  const botoes = el("div", "gacha-botoes");
  const btn1 = document.createElement("button");
  btn1.className = "botao-secundario";
  btn1.textContent = dados.liberado ? "🐴 Invocar 1x" : `🔒 Andar ${dados.andar_minimo}`;
  btn1.disabled = !dados.liberado;
  if (dados.liberado) btn1.onclick = () => acaoGacha("/api/stable/roll", 1, renderEstabulo);
  else btn1.style.opacity = "0.45";
  const btn11 = document.createElement("button");
  btn11.className = "botao-holofote";
  btn11.textContent = dados.liberado ? "✨ Invocar 11x" : `🔒 Andar ${dados.andar_minimo}`;
  btn11.disabled = !dados.liberado;
  if (dados.liberado) btn11.onclick = () => acaoGacha("/api/stable/roll", 11, renderEstabulo);
  else btn11.style.opacity = "0.45";
  botoes.append(btn1, btn11);
  c.appendChild(botoes);

  c.appendChild(el("h3", "secao-titulo", "Montarias"));
  const cards = dados.owned.map((m) => {
    const equipada = m.mount_id === dados.equipado;
    return cartaoGrande({
      nome: m.nome, raridade: m.raridade, quantidade: m.quantidade,
      img_key: m.img_key, emoji: "🐴",
      bonus_stats: m.bonus_stats, mecanica: m.mecanica,
      destacado: equipada, selo: equipada ? "equipada" : null,
      acoes: equipada ? [] : [{
        rotulo: dados.liberado ? "🐴 Equipar" : `🔒 Andar ${dados.andar_minimo}`,
        principal: true,
        desabilitado: !dados.liberado,
        aoTocar: async () => {
          try {
            await api("/api/stable/equip", { method: "POST",
              body: JSON.stringify({ mount_id: m.mount_id }) });
            som.clique(); await renderEstabulo();
          } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
        },
      }],
    });
  });
  c.appendChild(carrossel(cards, estadoVazio("🐴",
    "Nenhuma montaria ainda. Invoque uma aqui em cima.")));
}

async function acaoGacha(caminho, amount, aoTerminarRender) {
  try {
    const r = await api(caminho, { method: "POST", body: JSON.stringify({ amount }) });
    atualizarTopo({ gold: r.gold_restante });
    if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
    mostrarResultadoGacha(r.rolados, aoTerminarRender);
  } catch (e) {
    som.erro();
    if (!e.jaAlertado) toast(e.message, true);
  }
}

function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

async function mostrarResultadoGacha(rolados, aoTerminarRender) {
  // 🎠 26/09/2026 (dev): o resultado virou CARROSSEL — um cartão grande por
  // invocação, revelados um de cada vez (o mais raro no fim), com o
  // carrossel andando sozinho até o que acabou de aparecer. Depois dá pra
  // arrastar pra rever tudo.
  const ordem = { comum: 0, incomum: 1, raro: 2, epico: 3, lendario: 4 };
  const ordenados = [...rolados].sort((a, b) => (ordem[a.raridade] ?? 0) - (ordem[b.raridade] ?? 0));

  const corpo = el("div");
  const topo = el("div", "resultado-topo");
  topo.appendChild(el("h3", "secao-titulo", `Resultado (${rolados.length})`));
  const contador = el("div", "resultado-contador", `0/${ordenados.length}`);
  topo.appendChild(contador);
  corpo.appendChild(topo);
  const trilho = el("div", "resultado-carrossel");
  corpo.appendChild(trilho);

  const btnFechar = document.createElement("button");
  btnFechar.className = "botao-holofote sheet-opcao"; btnFechar.textContent = "Fechar";
  btnFechar.style.opacity = "0"; btnFechar.style.pointerEvents = "none";
  btnFechar.onclick = async () => { fecharSheet(); if (aoTerminarRender) await aoTerminarRender(); };
  corpo.appendChild(btnFechar);
  abrirSheet(corpo);

  // o próprio tempo de espera é pista: comum é quase instantâneo, lendário demora
  const tempoCarregando = { comum: 160, incomum: 220, raro: 360, epico: 520, lendario: 760 };

  for (let i = 0; i < ordenados.length; i++) {
    const r = ordenados[i];
    const cartao = el("div", `resultado-cartao ${classeRar(r.raridade)} carregando`);
    cartao.appendChild(el("div", "resultado-interrogacao", "?"));
    trilho.appendChild(cartao);
    trilho.scrollTo({ left: cartao.offsetLeft - (trilho.clientWidth - cartao.clientWidth) / 2, behavior: "smooth" });

    await sleep(tempoCarregando[r.raridade] ?? 160);

    cartao.classList.remove("carregando");
    cartao.innerHTML = "";
    const arte = el("div", "resultado-arte");
    arte.appendChild(el("div", "resultado-emoji", r.emoji || "🐾"));
    if (r.img_key) {
      const img = imagemDoJogo(r.img_key, 360, () => img.remove());
      arte.appendChild(img);
    }
    cartao.appendChild(arte);
    cartao.appendChild(el("div", "resultado-nome", r.nome));
    cartao.appendChild(el("div", `resultado-raridade ${classeRar(r.raridade)}`, (NOME_RARIDADE_PET[r.raridade] || r.raridade).toUpperCase()));
    contador.textContent = `${i + 1}/${ordenados.length}`;

    if (r.raridade === "lendario") { som.raro(); flashDourado(); notificacaoGrande("🔮", "Lendário!", r.nome); }
    else if (r.raridade === "epico") { som.raro(); }
    else if (r.raridade === "raro") { som.moeda(); }
    else { som.clique(); }

    await sleep(140);
  }

  btnFechar.style.transition = "opacity 0.25s ease";
  btnFechar.style.opacity = "1"; btnFechar.style.pointerEvents = "auto";
}

// =============================================================================
// 🛠️ FORJA
// =============================================================================
// 🔥 (09/07/2026): a seleção de cores fica em memória no navegador — o
// jogador marca/desmarca os cores livremente, sem gastar uma requisição
// por toque. Só manda pro servidor quando aperta "Forjar".
let FORJA_DADOS = null;
let FORJA_ESTADO = { slot: "weapon", rar: "common", sub: "sword", selecionados: [] };
// =============================================================================
// 💎 RARIDADE — um vocabulário só
// =============================================================================
// ⚠️ Os ITENS carregam a raridade em inglês (common/uncommon/rare/epic/
// legendary, que é o que game/items.py usa), e o CSS só define as classes em
// português (.rar-comum/.rar-incomum/.rar-raro/.rar-epico/.rar-lendario).
// Resultado: `class="cartao-item rar-legendary"` não casava com NADA, e o
// efeito de raridade — cantos ornamentados, glow, o pulso do lendário —
// nunca apareceu em item nenhum, em tela nenhuma. Pets e montarias
// funcionavam porque os bancos deles já guardam em português.
//
// Traduzir aqui, num lugar só, conserta todas as telas de uma vez e não
// quebra as que já falavam português.
const RARIDADE_CLASSE = {
  common: "comum", uncommon: "incomum", rare: "raro",
  epic: "epico", legendary: "lendario", mythic: "mythic",
  comum: "comum", incomum: "incomum", raro: "raro",
  epico: "epico", "épico": "epico", lendario: "lendario", "lendário": "lendario",
  mitico: "mythic", "mítico": "mythic",
};

/** Classe CSS da raridade, aceitando os dois vocabulários. */
function classeRar(raridade) {
  const chave = String(raridade || "comum").toLowerCase();
  return "rar-" + (RARIDADE_CLASSE[chave] || "comum");
}

const RAR_PT = { common: "Comum", uncommon: "Incomum", rare: "Raro", epic: "Épico", legendary: "Lendário" };

async function renderForja() {
  FORJA_DADOS = await api("/api/craft/cores");
  desenharForja();
}

function desenharForja() {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  const d = FORJA_DADOS;
  const est = FORJA_ESTADO;

  // raridade primeiro: é o preço e a chance, e ela filtra o carrossel
  c.appendChild(el("h3", "secao-titulo", "1. Raridade"));
  const filtroRar = el("div", "filtro-carrossel");
  for (const [rarId, info] of Object.entries(d.raridades)) {
    const chip = document.createElement("button");
    chip.className = "filtro-chip" + (rarId === est.rar ? " ativo" : "");
    chip.textContent = `${RAR_PT[rarId]} (${info.cores} cores)`;
    chip.onclick = () => { est.rar = rarId; est.selecionados = []; desenharForja(); };
    filtroRar.appendChild(chip);
  }
  c.appendChild(filtroRar);

  const need = d.raridades[est.rar].cores;
  const custo = d.custos[est.rar];
  const chance = Math.round(d.raridades[est.rar].chance * 100);
  const req = d.requisitos[est.slot] || {};
  // 🐛 20/09/2026: aqui saía o ID cru do core — "wa_atk x2" — que não quer
  // dizer nada pra quem joga. O nome bonito já existia em `items.core_name`
  // e a API já mandava; só não estava sendo usado.
  const reqTexto = Object.entries(req)
    .map(([k, v]) => `${(d.nomes_cores && d.nomes_cores[k]) || k} x${v}`)
    .join(", ");

  // ⛏️ 20/09/2026: a forja pede MATERIAL da Torre, pelo rank da raridade.
  // Vai logo abaixo da escolha de raridade porque é a raridade que decide
  // o rank — e faltar material é o motivo novo de a forja recusar, que o
  // jogador precisa ver ANTES de montar os cores, não depois.
  const mat = (d.material || {})[est.rar];
  if (mat) {
    // Piso da raridade + 1 por tier acima do 1 em cada core escolhido — a
    // mesma conta de `craft.custo_material`. Muda na hora em que o jogador
    // troca um core, que é quando ele precisa saber.
    const tierDe = (cid) => { const m = /_t(\d+)$/.exec(cid || ""); return m ? Number(m[1]) : 1; };
    const extra = (est.selecionados || []).reduce((s, cid) => s + Math.max(0, tierDe(cid) - 1), 0)
      * (mat.por_tier || 0);
    const total = mat.qtd + extra;
    const falta = mat.tem < total;
    const caixa = el("div", `forja-material${falta ? " faltando" : ""}`);
    caixa.appendChild(el("div", "forja-material-titulo",
      `⛏️ ${total} de material ${mat.nome} (rank ${mat.rank})`
      + (extra ? ` — ${mat.qtd} + ${extra} pelos tiers dos cores` : "")));
    caixa.appendChild(el("div", "texto-fraco",
      `Você tem ${mat.tem}: ${mat.mochila} na mochila + ${mat.cla} no clã. `
      + (falta ? `Sai nos ${mat.onde} — na Torre, num posto do clã ou no mapa.`
               : "A mochila é gasta primeiro.")));
    c.appendChild(caixa);
  }

  // ---------- 2. O QUE FORJAR: carrossel dos ITENS ----------
  //
  // Antes eram três fileiras de chips (slot, tipo de arma, raridade) e uma
  // prévia só, no fim. O jogador escolhia às cegas: nada mostrava a arte nem
  // o custo de cada peça até ele já ter escolhido. Agora ele desliza o que
  // dá pra fazer, com arte, custo e requisito no cartão.
  //
  // A raridade fica fora do carrossel de propósito: ela é o preço e a
  // chance, e multiplicá-la pelos slots daria 45 cartões pra rolar.
  const RAR_ASSET = { common: "COMMON", uncommon: "UNCOMMON", rare: "RARE", epic: "EPIC", legendary: "LEGENDARY" };
  const sufixoRar = RAR_ASSET[est.rar] || est.rar.toUpperCase();
  const chaveDe = (slot, sub) => (slot === "weapon" && sub
    ? `${slot.toUpperCase()}_${String(sub).toUpperCase()}_${sufixoRar}`
    : `${slot.toUpperCase()}_${sufixoRar}`);

  // Uma peça por slot; o slot de arma abre em um cartão por tipo de arma,
  // porque lá o tipo muda a arte e o jogo.
  const forjaveis = [];
  for (const slot of SLOT_LISTA) {
    if (slot === "weapon") {
      for (const tipo of d.tipos_arma) forjaveis.push({ slot, sub: tipo });
    } else {
      forjaveis.push({ slot, sub: null });
    }
  }

  c.appendChild(el("h3", "secao-titulo", "2. O que forjar"));
  const cartoesItem = forjaveis.map(({ slot, sub }) => {
    const escolhido = slot === est.slot && (slot !== "weapon" || sub === est.sub);
    const reqSlot = d.requisitos[slot] || {};
    const cartao = cartaoGrande({
      nome: sub ? ((d.nomes_armas && d.nomes_armas[sub]) || sub) : SLOT_INFO[slot]?.rotulo || slot,
      raridade: est.rar,
      img_key: chaveDe(slot, sub),
      emoji: SLOT_INFO[slot]?.icone || "⚔️",
      extras: [
        `${custo.toLocaleString("pt-BR")}g`,
        `${d.raridades[est.rar].cores} cores`,
        `${chance}% de dar certo`,
      // 🔤 (26/09) era `${k} x${v}` — "wa_atk x2", o ID cru do core
      ].concat(Object.entries(reqSlot).map(([k, v]) => `${(d.nomes_cores && d.nomes_cores[k]) || k} x${v}`)),
      destacado: escolhido,
      selo: escolhido ? "escolhido" : null,
      acoes: escolhido ? [] : [{
        rotulo: "Escolher", principal: true,
        aoTocar: () => {
          est.slot = slot;
          est.sub = sub;
          est.selecionados = [];
          som.clique();
          desenharForja();
        },
      }],
    });
    cartao.dataset.forja = `${slot}:${sub || ""}`;     // o guia aponta aqui (26/09)
    return cartao;
  });
  c.appendChild(carrossel(cartoesItem, estadoVazio("⚔️", "Nada forjável nesta raridade. Escolha outra raridade aqui em cima.")));

  // seleção de cores
  c.appendChild(el("h3", "secao-titulo", "3. Escolha os Cores"));
  // Contador grande e separado do título: com o carrossel, o "2/5" perdido
  // no fim do título some do olho de quem está deslizando os cartões.
  const contador = el("div", "forja-contador" + (est.selecionados.length === need ? " pronto" : ""));
  contador.appendChild(el("span", "forja-contador-num", `${est.selecionados.length}`));
  contador.appendChild(el("span", "forja-contador-de", `de ${need} marcados`));
  if (est.selecionados.length === need) contador.appendChild(el("span", "forja-contador-ok", "✓"));
  c.appendChild(contador);
  // Os cores voltaram a ser lista compacta: o carrossel agora é dos ITENS, e
  // dois carrosséis empilhados fariam o jogador deslizar duas vezes pra uma
  // decisão só. Core é ingrediente — o que importa dele é o bônus e quantos
  // sobram, que cabem numa linha.
  if (!d.cores.length) {
    c.appendChild(estadoVazio("💎", "Você não tem cores. Derrote monstros na Torre pra dropar."));
  } else {
    const lista = el("div", "core-lista");
    for (const core of d.cores) {
      const marcados = est.selecionados.filter((c2) => c2 === core.core_id).length;
      const cheio = est.selecionados.length >= need;
      const semSobra = marcados >= core.quantidade;
      // ➖➕ (26/09/2026, dev): um botão de menos e um de mais em cada core
      // — pra tirar 7 é tocar 7 vezes no menos, sem adivinhar se o toque
      // na linha ia marcar ou desmarcar.
      const linha = el("div", `core-linha ${classeRar(core.raridade)}${marcados ? " marcado" : ""}`);
      linha.dataset.core = core.core_id;
      const txt = el("div", "core-txt");
      txt.appendChild(el("div", "core-nome", core.nome));
      const bonus = Object.entries(core.bonus || {})
        .map(([k, v]) => `${ROTULO_STAT[k] || k.toUpperCase()} +${v}`)
        .concat(Object.entries(core.bonus_pct || {})
          .map(([k, v]) => `${ROTULO_STAT[k] || k.toUpperCase()} +${Math.round(v * 100)}%`));
      txt.appendChild(el("div", "core-bonus",
        `${bonus.join(" · ") || "sem bônus"} · tem ${core.quantidade}`));
      linha.appendChild(txt);
      const controle = el("div", "core-controle");
      const menos = document.createElement("button");
      menos.className = "core-botao"; menos.textContent = "−";
      menos.setAttribute("aria-label", `Tirar um ${core.nome}`);
      menos.disabled = !marcados;
      menos.onclick = () => {
        est.selecionados.splice(est.selecionados.indexOf(core.core_id), 1);
        som.clique(); desenharForja();
      };
      const qtd = el("span", "core-qtd", String(marcados));
      const mais = document.createElement("button");
      mais.className = "core-botao core-mais"; mais.textContent = "+";
      mais.setAttribute("aria-label", `Pôr um ${core.nome}`);
      mais.disabled = cheio || semSobra;
      mais.onclick = () => {
        est.selecionados.push(core.core_id);
        som.clique(); desenharForja();
      };
      controle.append(menos, qtd, mais);
      linha.appendChild(controle);
      lista.appendChild(linha);
    }
    c.appendChild(lista);
  }

  const btnForjar = document.createElement("button");
  btnForjar.className = "botao-holofote";
  btnForjar.id = "btn-forjar";
  btnForjar.style.marginTop = "12px";
  btnForjar.textContent = est.selecionados.length === need ? "🛠️ Forjar!" : `Selecione ${need} cores`;
  btnForjar.disabled = est.selecionados.length !== need;
  btnForjar.onclick = acaoForjar;
  c.appendChild(btnForjar);

  // A Fusão Mítica saiu daqui pra tela própria: no fim da Forja, depois de
  // raridade, itens e cores, ela era um bloco que ninguém rolava até.
  const irFusao = document.createElement("button");
  irFusao.className = "botao-secundario";
  irFusao.style.cssText = "width:100%;margin-top:18px";
  irFusao.textContent = "✨ Fusão Mítica";
  irFusao.onclick = () => irPara("fusao");
  c.appendChild(irFusao);
}

async function acaoFundirMitico(slot) {
  try {
    const r = await api("/api/craft/mythic_fuse", { method: "POST", body: JSON.stringify({ slot }) });
    if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); await renderForja(); return; }
    som.raro(); flashDourado();
    notificacaoGrande("💠", "Item Mítico!", SLOT_INFO[slot]?.rotulo || slot);
    await renderForja();
  } catch (e) {
    som.erro();
    if (!e.jaAlertado) toast(e.message, true);
  }
}

/** A janela do item recém-forjado: arte grande, atributos atrás e o efeito
 *  de raridade em volta.
 *
 *  ⚠️ A arte vai num elemento INTERNO, nunca na mesma caixa que leva a
 *  classe de raridade: os cantos ornamentados são background-image, e pôr
 *  outra imagem de fundo ali apagaria eles (armadilha nº 2 do projeto). */
function mostrarItemForjado(item, est) {
  if (!item) {
    notificacaoGrande("🛠️", "Item forjado!",
      `${RAR_PT[est.rar]} · ${SLOT_INFO[est.slot].rotulo}`);
    return;
  }
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", "🛠️ Item forjado!"));

  const caixa = el("div", `forjado-caixa ${classeRar(item.raridade)}`);
  const arte = el("div", "forjado-arte");
  if (item.img_key) porFundo(arte, urlImagem(item.img_key, 150));
  else arte.textContent = SLOT_INFO[est.slot]?.icone || "⚔️";
  caixa.appendChild(arte);

  caixa.appendChild(el("div", "forjado-nome", item.nome));
  caixa.appendChild(el("div", `forjado-raridade ${"rar-texto-" + classeRar(item.raridade).slice(4)}`,
    (RAR_PT[item.raridade] || item.raridade || "").toUpperCase()));

  const stats = el("div", "forjado-stats");
  for (const [chave, valor] of Object.entries(item.bonus || {})) {
    const l = el("div", "forjado-stat");
    l.append(el("span", "forjado-stat-nome", ROTULO_STAT[chave] || chave.toUpperCase()),
             el("span", "forjado-stat-valor", `+${valor}`));
    stats.appendChild(l);
  }
  if (item.sockets_max) {
    const l = el("div", "forjado-stat");
    l.append(el("span", "forjado-stat-nome", "Sockets"),
             el("span", "forjado-stat-valor", `${item.sockets_usados}/${item.sockets_max}`));
    stats.appendChild(l);
  }
  // 📈 (28/09) o bônus de raridade (o servidor já mandava; a janela não mostrava)
  if (item.bonus_raridade) {
    const br = item.bonus_raridade;
    const l = el("div", "forjado-stat");
    l.append(el("span", "forjado-stat-nome", br.sorteado ? `${ROTULO_STAT[br.stat] || br.stat} (sorteado)` : `${ROTULO_STAT[br.stat] || br.stat} (raridade)`),
             el("span", "forjado-stat-valor", `+${br.pct}%`));
    stats.appendChild(l);
  }
  if (stats.childNodes.length) caixa.appendChild(stats);
  corpo.appendChild(caixa);

  const btn = document.createElement("button");
  btn.className = "botao-holofote sheet-opcao";
  btn.textContent = "Continuar";
  btn.onclick = () => fecharSheet();
  corpo.appendChild(btn);
  abrirSheet(corpo);
}

async function acaoForjar() {
  const est = FORJA_ESTADO;
  try {
    const r = await api("/api/craft/confirm", {
      method: "POST",
      body: JSON.stringify({ slot: est.slot, rar: est.rar, sub: est.sub, cores: est.selecionados }),
    });
    atualizarTopo({ gold: r.gold }); // 🔥 o ouro é cobrado mesmo se o craft falhar no sorteio de sucesso
    if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
    som.raro();
    est.selecionados = [];
    mostrarItemForjado(r.item, est);
    await renderForja();
  } catch (e) {
    som.erro();
    if (!e.jaAlertado) toast(e.message, true);
  }
}

// =============================================================================
// ✨ FUSÃO MÍTICA — tela própria
// =============================================================================
// Aceita 5 Lendários QUAISQUER; a composição decide o tipo do mítico. Antes
// exigia 5 da mesma categoria, e quem tinha 4 armas e 1 bota não fundia
// nada — o lendário avulso não servia pra coisa alguma.
let FUSAO_ESCOLHIDOS = [];

async function renderFusao() {
  const d = await api("/api/fusao");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  // Só mantém escolhas que ainda existem (o inventário pode ter mudado).
  const validos = new Set(d.lendarios.map((it) => `${it.slot}:${it.idx}`));
  FUSAO_ESCOLHIDOS = FUSAO_ESCOLHIDOS.filter((k) => validos.has(k));

  const pct = (x) => `${Math.round(x * 100)}%`;
  c.appendChild(el("p", "texto-fraco",
    `Funde ${d.custo} Lendários quaisquer. Os itens são consumidos dê certo ou não. `
    + `Chance de sair um Mítico: ${pct(d.chance_sucesso)}.`));

  // 📖 (28/09, dev) "um carrossel só mostrando os itens míticos, as imagens e
  // os status deles" — o que pode sair, antes de gastar 5 Lendários.
  if ((d.catalogo || []).length) {
    c.appendChild(el("h3", "secao-titulo", `📖 Os ${d.catalogo.length} Míticos`));
    const filtro = el("div", "filtro-carrossel");
    const tipos = [["", "Todos"], ...[...new Set(d.catalogo.map((x) => x.slot))]
      .map((sl) => [sl, `${SLOT_INFO[sl]?.icone || ""} ${SLOT_INFO[sl]?.rotulo || sl}`])];
    for (const [sl, rotulo] of tipos) {
      const chip = document.createElement("button");
      chip.className = "filtro-chip" + (sl === FUSAO_CATALOGO_SLOT ? " ativo" : "");
      chip.textContent = rotulo;
      chip.onclick = () => { FUSAO_CATALOGO_SLOT = sl; som.clique(); renderFusao(); };
      filtro.appendChild(chip);
    }
    c.appendChild(filtro);
    const visiveis = d.catalogo.filter((x) => !FUSAO_CATALOGO_SLOT || x.slot === FUSAO_CATALOGO_SLOT);
    c.appendChild(carrossel(visiveis.map(cartaoDoMitico), estadoVazio("✨", "Nenhum mítico nesse tipo.")));
  }

  // A composição atual e o que ela faz com o tipo — a conta aberta, antes
  // de confirmar. É a mesma regra do projeto: a agência vem antes.
  const contagem = {};
  for (const k of FUSAO_ESCOLHIDOS) {
    const slot = k.split(":")[0];
    contagem[slot] = (contagem[slot] || 0) + 1;
  }
  const maior = Object.entries(contagem).sort((a, b) => b[1] - a[1])[0];
  const linhaTabela = d.tabela_tipo.find((t) => t.iguais === (maior ? maior[1] : 0));

  const painel = el("div", "fusao-painel" + (FUSAO_ESCOLHIDOS.length === d.custo ? " pronto" : ""));
  painel.appendChild(el("div", "fusao-contador",
    `${FUSAO_ESCOLHIDOS.length} de ${d.custo}`));
  if (maior) {
    painel.appendChild(el("div", "fusao-previsao",
      `${maior[1]}x ${SLOT_INFO[maior[0]]?.rotulo || maior[0]} → `
      + `${pct(linhaTabela ? linhaTabela.chance : 0)} de o Mítico sair desse tipo`));
    // A multiplicação escrita. Esconder que são duas rolagens é o que faz o
    // jogador achar que foi roubado quando sai outro tipo.
    painel.appendChild(el("div", "fusao-nota",
      `${pct(d.chance_sucesso)} de sair Mítico × `
      + `${pct(linhaTabela ? linhaTabela.chance : 0)} de ser esse tipo = `
      + `${pct(d.chance_sucesso * (linhaTabela ? linhaTabela.chance : 0))} de sair `
      + `exatamente o que você quer.`));
  } else {
    painel.appendChild(el("div", "fusao-nota",
      "Escolha 5 abaixo. Quanto mais peças do mesmo tipo, maior a chance de o "
      + "Mítico sair desse tipo — 5 iguais dão 50%."));
  }
  c.appendChild(painel);

  const btn = document.createElement("button");
  btn.className = "botao-holofote";
  btn.style.cssText = "width:100%;margin-bottom:14px";
  btn.textContent = FUSAO_ESCOLHIDOS.length === d.custo
    ? "✨ Fundir" : `Escolha mais ${d.custo - FUSAO_ESCOLHIDOS.length}`;
  btn.disabled = FUSAO_ESCOLHIDOS.length !== d.custo;
  if (btn.disabled) btn.style.opacity = "0.45";
  else btn.onclick = acaoFundir;
  c.appendChild(btn);

  c.appendChild(el("h3", "secao-titulo", `Seus Lendários (${d.lendarios.length})`));
  if (!d.lendarios.length) {
    c.appendChild(estadoVazio("💠",
      "Você não tem Lendários. Eles vêm da Forja na raridade lendária e dos baús fundos da Torre."));
    return;
  }
  const lista = el("div", "core-lista");
  for (const it of d.lendarios) {
    const chave = `${it.slot}:${it.idx}`;
    const marcado = FUSAO_ESCOLHIDOS.includes(chave);
    const cheio = FUSAO_ESCOLHIDOS.length >= d.custo;
    const linha = document.createElement("button");
    linha.className = `core-linha rar-lendario${marcado ? " marcado" : ""}`;
    const txt = el("div", "core-txt");
    txt.appendChild(el("div", "core-nome", it.nome));
    const bonus = Object.entries(it.bonus || {})
      .map(([k, v]) => `${ROTULO_STAT[k] || k.toUpperCase()} +${v}`).join(" · ");
    const rarTxt = textoBonusRaridade(it.bonus_raridade)[0];   // 📈 (28/09)
    txt.appendChild(el("div", "core-bonus",
      `${SLOT_INFO[it.slot]?.rotulo || it.slot}${bonus ? " · " + bonus : ""}${rarTxt ? " · " + rarTxt : ""}`));
    linha.appendChild(txt);
    linha.appendChild(el("span", "core-marca", marcado ? "✓" : (cheio ? "" : "+")));
    if (!marcado && cheio) { linha.disabled = true; linha.style.opacity = "0.4"; }
    else linha.onclick = () => {
      if (marcado) FUSAO_ESCOLHIDOS.splice(FUSAO_ESCOLHIDOS.indexOf(chave), 1);
      else FUSAO_ESCOLHIDOS.push(chave);
      som.clique();
      renderFusao();
    };
    lista.appendChild(linha);
  }
  c.appendChild(lista);
}

let FUSAO_CATALOGO_SLOT = "";

/** Carta de um mítico do catálogo: arte, a habilidade própria, o gatilho,
 *  os 16 sockets e o bônus de raridade. Atrás, o que a habilidade faz. */
function cartaoDoMitico(x) {
  const br = x.bonus_raridade;
  return cartaoGrande({
    nome: x.nome, raridade: "mythic", img_key: x.img_key,
    emoji: SLOT_INFO[x.slot]?.icone || "✨",
    selo: SLOT_INFO[x.slot]?.rotulo || x.slot,
    extras: [
      `✨ ${x.skill.nome}`,
      `⚡ ${x.gatilho}`,
      `💎 ${x.sockets} sockets`,
    ].concat(br ? textoBonusRaridade({ stat: br.stat, pct: br.pct }) : []),
    verso: (v) => {
      v.appendChild(el("div", "peca-verso-titulo", x.nome));
      v.appendChild(el("div", "peca-verso-texto",
        `Habilidade própria: ${x.skill.nome}. Dispara sozinha a cada ${x.skill_recarga} turnos, `
        + `com ${x.skill_poder}% da força, sem ocupar slot de habilidade.`));
      for (const ef of x.skill.efeitos || []) v.appendChild(el("div", "peca-verso-linha", `• ${ef}`));
      v.appendChild(el("div", "peca-verso-texto", `Gatilho: ${x.gatilho}.`));
      v.appendChild(el("div", "peca-verso-texto",
        `Sem atributo base: a força vem dos ${x.sockets} sockets` + (br ? ` e do +${br.pct}% de raridade.` : ".")));
    },
  });
}

async function acaoFundir() {
  const itens = FUSAO_ESCOLHIDOS.map((k) => {
    const [slot, idx] = k.split(":");
    return { slot, idx: Number(idx) };
  });
  try {
    const r = await api("/api/fusao/fundir", {
      method: "POST", body: JSON.stringify({ itens }) });
    FUSAO_ESCOLHIDOS = [];
    if (!r.ok) {
      som.erro();
      toast(r.msg.replace(/<[^>]+>/g, ""), true);
      await renderFusao();
      return;
    }
    som.raro();
    mostrarItemForjado(r.item, { rar: "mythic", slot: itens[0].slot });
    await renderFusao();
  } catch (e) {
    som.erro();
    if (!e.jaAlertado) toast(e.message, true);
    await renderFusao();
  }
}

// =============================================================================
// 🔄 MERCADO
// =============================================================================
let MERCADO_ABA = "navegar";
let MERCADO_FILTRO = { slot: "", rarity: "", ordem: "recentes", page: 0 };

async function renderMercado() {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  const filtro = el("div", "filtro-carrossel");
  for (const [aba, rotulo] of [["navegar", "🔍 Navegar"], ["meus", "📦 Meus Anúncios"]]) {
    const chip = document.createElement("button");
    chip.className = "filtro-chip" + (aba === MERCADO_ABA ? " ativo" : "");
    chip.textContent = rotulo;
    chip.onclick = () => { MERCADO_ABA = aba; renderMercado(); };
    filtro.appendChild(chip);
  }
  c.appendChild(filtro);

  if (MERCADO_ABA === "navegar") {
    // Filtros. Sem eles o mercado é uma pilha por data de anúncio, e achar
    // "a melhor arma" exigia abrir tudo de dez em dez.
    //
    // ⚠️ A ordenação é do SERVIDOR, não do navegador: a lista vem paginada
    // de 10 em 10, e ordenar no cliente ordenaria só a página aberta — o que
    // parece funcionar e está errado.
    const linhaFiltro = (rotulo, opcoes, atual, aoEscolher) => {
      const caixa = el("div", "mercado-filtro");
      caixa.appendChild(el("span", "mercado-filtro-rotulo", rotulo));
      const chips = el("div", "filtro-carrossel");
      for (const [valor, texto] of opcoes) {
        const chip = document.createElement("button");
        chip.className = "filtro-chip" + (valor === atual ? " ativo" : "");
        chip.textContent = texto;
        chip.onclick = () => { aoEscolher(valor); som.clique(); renderMercado(); };
        chips.appendChild(chip);
      }
      caixa.appendChild(chips);
      return caixa;
    };

    c.appendChild(linhaFiltro("Tipo",
      [["", "Todos"]].concat(SLOT_LISTA.map((sl) => [sl, SLOT_INFO[sl]?.rotulo || sl])),
      MERCADO_FILTRO.slot, (v) => { MERCADO_FILTRO.slot = v; MERCADO_FILTRO.page = 0; }));
    c.appendChild(linhaFiltro("Raridade",
      [["", "Todas"], ["rare", "Raro"], ["epic", "Épico"], ["legendary", "Lendário"]],
      MERCADO_FILTRO.rarity, (v) => { MERCADO_FILTRO.rarity = v; MERCADO_FILTRO.page = 0; }));
    c.appendChild(linhaFiltro("Ordenar",
      [["recentes", "Recentes"], ["atk", "Maior ATK"], ["def", "Maior DEF"],
       ["preco_asc", "Mais barato"], ["preco_desc", "Mais caro"]],
      MERCADO_FILTRO.ordem, (v) => { MERCADO_FILTRO.ordem = v; MERCADO_FILTRO.page = 0; }));

    const qs = new URLSearchParams();
    if (MERCADO_FILTRO.slot) qs.set("slot", MERCADO_FILTRO.slot);
    if (MERCADO_FILTRO.rarity) qs.set("rarity", MERCADO_FILTRO.rarity);
    if (MERCADO_FILTRO.ordem) qs.set("ordem", MERCADO_FILTRO.ordem);
    qs.set("page", String(MERCADO_FILTRO.page));
    const dados = await api(`/api/market?${qs.toString()}`);

    const filtrando = MERCADO_FILTRO.slot || MERCADO_FILTRO.rarity;
    if (dados.itens.length === 0) {
      c.appendChild(estadoVazio("🏪", filtrando
        ? "Nenhum anúncio com esse filtro. Escolha Todos aqui em cima pra ver o mercado inteiro."
        : "Ninguém está vendendo nada agora. Quem abastece o Mercado são os outros jogadores — e você também pode: toque em 📦 Meus Anúncios aqui em cima pra colocar um item à venda."));
    } else {
      c.appendChild(el("p", "texto-fraco",
        `${dados.total} anúncio(s) · mostrando ${dados.itens.length}`));
    }

    for (const it of dados.itens) {
      const card = el("div", `cartao-item ${classeRar(it.raridade)}`);
      if (it.img_key) {
        const thumb = document.createElement("img");
        thumb.className = "cartao-thumb";
        thumb.src = urlImagem(it.img_key, 56);
        thumb.loading = "lazy";
        thumb.decoding = "async";
        thumb.alt = "";
        thumb.onerror = () => thumb.remove();
        card.appendChild(thumb);
      }
      const info = el("div", "cartao-item-info");
      info.appendChild(el("div", "cartao-item-nome", it.nome));
      // Os atributos na linha: comparar dois anúncios exigia abrir os dois.
      const atributos = Object.entries(it.bonus || {})
        .map(([k, v]) => `${ROTULO_STAT[k] || k.toUpperCase()} +${v}`).join(" · ");
      if (atributos) info.appendChild(el("div", "cartao-item-bonus", atributos));
      // 📈 (28/09) a API já mandava o bônus de raridade e a tela não mostrava
      for (const t of textoBonusRaridade(it.bonus_raridade)) info.appendChild(el("div", "cartao-item-bonus", t));
      info.appendChild(el("div", "cartao-item-bonus",
        `⭐ ${it.preco} · ${SLOT_INFO[it.slot]?.rotulo || it.slot} · por ${it.vendedor || "?"}`));
      const btn = document.createElement("button");
      btn.className = "botao-secundario"; btn.textContent = "Comprar";
      btn.onclick = () => acaoComprar(it.item_id);
      card.append(info, btn);
      c.appendChild(card);
    }

    // Paginação: com filtro, a lista útil passa a ter mais de 10 com
    // frequência, e sem isto o jogador só via os 10 primeiros.
    const paginas = Math.ceil((dados.total || 0) / 10);
    if (paginas > 1) {
      const nav = el("div", "combate-acoes");
      const anterior = document.createElement("button");
      anterior.className = "botao-secundario";
      anterior.textContent = "‹ Anterior";
      anterior.disabled = MERCADO_FILTRO.page <= 0;
      if (anterior.disabled) anterior.style.opacity = "0.45";
      else anterior.onclick = () => { MERCADO_FILTRO.page--; renderMercado(); };
      const proxima = document.createElement("button");
      proxima.className = "botao-secundario";
      proxima.textContent = `Página ${MERCADO_FILTRO.page + 1}/${paginas} ›`;
      proxima.disabled = MERCADO_FILTRO.page >= paginas - 1;
      if (proxima.disabled) proxima.style.opacity = "0.45";
      else proxima.onclick = () => { MERCADO_FILTRO.page++; renderMercado(); };
      nav.append(anterior, proxima);
      c.appendChild(nav);
    }
  } else {
    const btnAnunciar = document.createElement("button");
    btnAnunciar.className = "botao-holofote";
    btnAnunciar.style.marginBottom = "14px";
    btnAnunciar.textContent = "➕ Anunciar Item";
    btnAnunciar.onclick = abrirAnunciarSheet;
    c.appendChild(btnAnunciar);

    const dados = await api("/api/market/mine");
    c.appendChild(el("p", "texto-fraco", `💎 Seu saldo: ${dados.premium}⭐`));
    if (dados.itens.length === 0) c.appendChild(estadoVazio("📦", "Você não tem anúncios ativos. Anuncie um item acima."));
    for (const it of dados.itens) {
      const card = el("div", `cartao-item ${classeRar(it.raridade)}`);
      if (it.img_key) {
        const thumb = document.createElement("img");
        thumb.className = "cartao-thumb";
        thumb.src = urlImagem(it.img_key, 56);
        thumb.loading = "lazy";
        thumb.decoding = "async";
        thumb.alt = "";
        thumb.onerror = () => thumb.remove();
        card.appendChild(thumb);
      }
      const info = el("div", "cartao-item-info");
      info.appendChild(el("div", "cartao-item-nome", it.nome));
      for (const t of textoBonusRaridade(it.bonus_raridade)) info.appendChild(el("div", "cartao-item-bonus", t));
      info.appendChild(el("div", "cartao-item-bonus", `⭐ ${it.preco}`));
      const btn = document.createElement("button");
      btn.className = "botao-secundario"; btn.textContent = "Cancelar";
      btn.onclick = () => acaoCancelarAnuncio(it.item_id);
      card.append(info, btn);
      c.appendChild(card);
    }
  }
}

async function acaoComprar(itemId) {
  try {
    const r = await api("/api/market/buy", { method: "POST", body: JSON.stringify({ item_id: itemId }) });
    atualizarTopo({ premium: r.premium });
    if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
    som.moeda();
    toast(r.msg.replace(/<[^>]+>/g, ""));
    await renderMercado();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function acaoCancelarAnuncio(itemId) {
  try {
    const r = await api("/api/market/cancel", { method: "POST", body: JSON.stringify({ item_id: itemId }) });
    som.clique();
    toast(r.msg);
    await renderMercado();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function abrirAnunciarSheet() {
  const inv = await api("/api/inventory");
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", "Escolha um item da mochila"));

  let algumItem = false;
  for (const slot of SLOT_LISTA) {
    for (const item of inv.slots[slot].mochila) {
      algumItem = true;
      const btn = document.createElement("button");
      btn.className = "botao-secundario sheet-opcao";
      btn.textContent = `${item.nome} [${item.raridade}]`;
      btn.onclick = () => abrirPrecoSheet(slot, item);
      corpo.appendChild(btn);
    }
  }
  if (!algumItem) corpo.appendChild(estadoVazio("🎒", "Sua mochila está vazia — equipe menos ou forje mais itens."));
  abrirSheet(corpo);
}

function abrirPrecoSheet(slot, item) {
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", `Anunciar: ${item.nome}`));
  corpo.appendChild(el("p", "texto-fraco", "Taxa fixa de listagem: 50⭐. Defina o preço de venda:"));
  const inputPreco = document.createElement("input");
  inputPreco.type = "number"; inputPreco.min = "1"; inputPreco.value = "100";
  inputPreco.className = "sheet-input";
  corpo.appendChild(inputPreco);

  const btnConfirmar = document.createElement("button");
  btnConfirmar.className = "botao-holofote sheet-opcao";
  btnConfirmar.textContent = "✅ Anunciar";
  btnConfirmar.onclick = async () => {
    fecharSheet();
    try {
      const r = await api("/api/market/list", {
        method: "POST",
        body: JSON.stringify({ slot, idx: item.idx, preco: parseInt(inputPreco.value, 10) || 1 }),
      });
      atualizarTopo({ premium: r.premium }); // 🔥 taxa fixa de listagem já é cobrada aqui
      som.moeda();
      toast(r.msg.replace(/<[^>]+>/g, ""));
      await renderMercado();
    } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
  };
  corpo.appendChild(btnConfirmar);
  abrirSheet(corpo);
}


// =============================================================================
// 🗼 TORRE / COMBATE
// =============================================================================
async function renderTorre() {
  const dados = await api("/api/tower/status");
  ESTADO_COMBATE_ANTERIOR = null; // reset ao entrar na tela — evita flash falso na primeira renderização
  desenharTorre(dados);
}

let ESTADO_COMBATE_ANTERIOR = null;
let EXPLORANDO_ATIVO = false; // true quando o combate na tela veio de /api/explore/go, não da Torre normal
// 🔒 Raid em combate. Mesma ideia de EXPLORANDO_ATIVO/ONDA_ATIVA: sair da
// tela não pausa nada — o combate da raid segue rodando no servidor pro
// grupo inteiro. Quem navega embora some da luta sem morrer nem fugir, e os
// outros quatro ficam esperando um alvo que não age mais.
let RAID_EM_COMBATE = false;
let ONDA_ATIVA = false; // true quando o combate na tela veio da Onda de Bosses
let ONDA_NUMERO_ATUAL = 1;
let COMBATE_INICIO = null;
let COMBATE_TIMER_INTERVAL = null;
function iniciarCronometroCombate() {
  if (COMBATE_TIMER_INTERVAL) return; // já rodando, não duplica
  COMBATE_TIMER_INTERVAL = setInterval(atualizarCronometroCombate, 1000);
}
function pararCronometroCombate() {
  if (COMBATE_TIMER_INTERVAL) { clearInterval(COMBATE_TIMER_INTERVAL); COMBATE_TIMER_INTERVAL = null; }
  COMBATE_INICIO = null;
}
function atualizarCronometroCombate() {
  const alvo = document.getElementById("combate-cronometro");
  if (!alvo || !COMBATE_INICIO) return;
  const seg = Math.floor((Date.now() - COMBATE_INICIO) / 1000);
  const m = Math.floor(seg / 60), s = seg % 60;
  alvo.textContent = m > 0 ? `${m}m${String(s).padStart(2, "0")}s` : `${s}s`;
}

function desenharTorre(dados) {
  talvezMostrarRecompensaDaLuta(dados);     // 🎁 (28/09) fim da luta
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  protegerProgresso(!!dados.em_combate);

  if (dados.morreu) {
    pararCronometroCombate();
    const box = el("div", "em-construcao resultado-combate resultado-derrota");
    box.appendChild(el("div", "em-construcao-icone", "💀"));
    box.appendChild(el("p", "", "Você caiu em combate"));
    if (dados.log) box.appendChild(el("p", "texto-fraco", dados.log.replace(/<[^>]+>/g, "")));

    // 🔎 (28/09) quem te derrubou, lado a lado, e o que fazer — antes era só
    // "Você caiu em combate", e no chefe do 5º andar ninguém sabia o porquê
    const d = dados.derrota;
    if (d) {
      box.appendChild(el("p", "", `${d.chefe ? "👑 " : ""}${d.nome} te derrubou.`));
      const tab = el("div", "derrota-lado-a-lado");
      const linha = (rot, x) => el("div", "texto-fraco",
        `${rot}  ⚔️ ${x.atk}  🛡️ ${x.def}  ⚡ ${x.spd}  ❤️ ${x.hp_max}`);
      tab.append(linha("Ele", d.ele), linha("Você", d.voce));
      box.appendChild(tab);
      if (d.chefe) box.appendChild(el("p", "texto-fraco", "É o chefe do andar: o portal só abre vencendo ele."));
      for (const dica of d.dicas || []) box.appendChild(el("p", "texto-fraco", "💡 " + dica));
    }

    // 🛡️ Até o andar 10 a morte não cobra nada: o portal está sempre aberto,
    // não perde andar e não espera. É o privilégio do novato.
    if (dados.novato) {
      box.appendChild(el("p", "texto-fraco",
        `🛡️ Proteção do novato: até o andar ${dados.andar_novato} você volta de graça, `
        + "sem esperar e sem perder o andar."));
    }
    const btnRevive = document.createElement("button");
    btnRevive.className = "botao-holofote";
    if (dados.revive_cooldown_seg > 0) {
      btnRevive.textContent = `⏳ Portal fecha por ${formatarContagem(dados.revive_cooldown_seg)}`;
      btnRevive.disabled = true; btnRevive.style.opacity = "0.5";
    } else {
      btnRevive.textContent = "👼 Reviver (metade do HP)";
      btnRevive.onclick = acaoRevive;
    }
    box.appendChild(btnRevive);

    // 💰 Com o portal fechado, dá pra voltar na hora pagando ouro. Não existe
    // "começar de novo" aqui: perder a conta não pode ser um botão.
    if (dados.revive_cooldown_seg > 0 && dados.custo_reviver) {
      const btnOuro = document.createElement("button");
      const tem = (dados.gold ?? 0) >= dados.custo_reviver;
      btnOuro.className = tem ? "botao-secundario" : "botao-secundario trancado";
      btnOuro.textContent = `💰 Reviver agora (${dados.custo_reviver.toLocaleString("pt-BR")}g)`;
      btnOuro.disabled = !tem;
      btnOuro.onclick = async () => {
        if (!confirm(`Pagar ${dados.custo_reviver.toLocaleString("pt-BR")} de ouro pra voltar agora?`)) return;
        try {
          const r = await api("/api/tower/revive_pago", { method: "POST" });
          som.moeda(); toast(r.msg.replace(/<[^>]+>/g, ""));
          atualizarTopo({ gold: r.gold }); desenharTorre(r);
        } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
      };
      box.appendChild(btnOuro);
    }
    c.appendChild(box);
    return;
  }

  // 👣 Encontro na Torre: gente presa lá dentro. Vem antes do portal porque
  // é o que acabou de acontecer — mandar o jogador escolher andar com uma
  // pessoa parada na frente dele seria perder a cena.
  if (dados.torre_encontro) {
    pararCronometroCombate();
    // Sem await: quem chama esta função é síncrona. O erro é tratado aqui
    // mesmo — encontro que falha ao carregar volta pra Torre em vez de
    // deixar a tela em branco.
    desenharEncontroTorre().catch(() => { renderTorre(); });
    return;
  }

  if (dados.tower_choice) {
    const box = el("div", "em-construcao");
    box.appendChild(el("div", "em-construcao-icone", dados.portal_do_chefe ? "👑" : "🌀"));
    box.appendChild(el("p", "", dados.portal_do_chefe
      ? `O chefe caiu! O portal pro ${Number(dados.andar) + 1}º andar se abriu. Avançar agora ou continuar aqui?`
      : "Portal encontrado! Avançar de andar ou continuar no mesmo?"));
    const linha = el("div", "gacha-botoes");
    const btnAvancar = document.createElement("button");
    btnAvancar.className = "botao-holofote"; btnAvancar.textContent = "⬆️ Avançar";
    btnAvancar.onclick = () => acaoAvancarAndar();
    const btnFicar = document.createElement("button");
    btnFicar.className = "botao-secundario"; btnFicar.textContent = "🔁 Ficar";
    btnFicar.onclick = () => acaoTorreSimples("/api/tower/stay");
    linha.append(btnAvancar, btnFicar);
    box.appendChild(linha);
    c.appendChild(box);
    pararCronometroCombate();
    return;
  }

  if (dados.em_combate) {
    desenharCombate(dados);
    return;
  }

  pararCronometroCombate();
  // fora de combate: tela de exploração
  c.appendChild(el("h3", "secao-titulo", `Andar ${dados.andar}`));
  const hpPct = dados.hp_max > 0 ? Math.max(0, Math.min(100, (dados.hp / dados.hp_max) * 100)) : 0;
  c.appendChild(barraDeProgresso("❤️ Vida", `${dados.hp}/${dados.hp_max}`, hpPct, "barra-hp"));
  // 👑 (28/09) no andar de chefe do novato o portal só abre vencendo o chefe
  if (dados.portal_preso) {
    c.appendChild(el("p", "texto-fraco", "👑 Andar de chefe: o portal pro próximo andar só abre quando você vencer o chefe. Metade das lutas é com os capangas dele — bom pra subir de nível antes."));
  }

  const btnExplorar = document.createElement("button");
  btnExplorar.className = "botao-holofote";
  btnExplorar.style.marginTop = "16px";
  btnExplorar.textContent = "🗺️ Explorar";
  btnExplorar.id = "btn-explorar-torre";           // o guia inicial aponta aqui
  btnExplorar.onclick = acaoExplorar;
  c.appendChild(btnExplorar);
}

function desenharCombate(dados) {
  talvezMostrarRecompensaDaLuta(dados);     // 🎁 (28/09) exploração/ondas também
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  if (COMBATE_INICIO === null) COMBATE_INICIO = Date.now();
  iniciarCronometroCombate();

  const ondeEstou = EXPLORANDO_ATIVO ? ["Mundo Exterior", ""]
    : ONDA_ATIVA ? ["Onda", String(ONDA_NUMERO_ATUAL)]
    : ["Torre", `Andar ${dados.andar}`];
  c.appendChild(tituloDaLuta(ondeEstou[0], ondeEstou[1]));

  const alvoAtual = dados.inimigos?.[dados.alvo];
  const jogadorAtingido = ESTADO_COMBATE_ANTERIOR && dados.hp < ESTADO_COMBATE_ANTERIOR.hp;
  const alvoAtingido = ESTADO_COMBATE_ANTERIOR && alvoAtual &&
    ESTADO_COMBATE_ANTERIOR.inimigos?.[dados.alvo] !== undefined && alvoAtual.hp < ESTADO_COMBATE_ANTERIOR.inimigos[dados.alvo];

  const hpPct = dados.hp_max > 0 ? Math.max(0, Math.min(100, (dados.hp / dados.hp_max) * 100)) : 0;
  const atbPct = Math.min(100, dados.p_bar);
  const alvoPct = alvoAtual && alvoAtual.hp_max > 0 ? Math.max(0, Math.min(100, (alvoAtual.hp / alvoAtual.hp_max) * 100)) : 0;

  const painel = el("div", "combate-vs");

  // lado do jogador
  const ladoJogador = el("div", "combate-vs-lado jogador");
  // O jogador é representado pela arte de STATUS, como no resto do jogo —
  // era o único lugar que ainda mostrava um emoji de espadas.
  const retratoJogador = el("div", "combate-vs-retrato");
  // 130 é o teto do CSS; urlImagem dobra sozinha pra retina.
  if (IMG_JOGADOR) porFundo(retratoJogador, urlImagem(IMG_JOGADOR, 130));
  else retratoJogador.textContent = "⚔️";
  ladoJogador.appendChild(retratoJogador);
  ladoJogador.appendChild(el("div", "combate-vs-nome", "Você"));
  const hpWrapJ = el("div", "combate-vs-barra-wrap");
  const hpTrilhoJ = el("div", "barra-trilho mini" + (jogadorAtingido ? " flash-dano" : ""));
  hpTrilhoJ.appendChild(el("div", "barra-preenchimento barra-hp", "")); hpTrilhoJ.firstChild.style.width = `${hpPct}%`;
  hpWrapJ.append(hpTrilhoJ, el("div", "barra-numero-mini", `${dados.hp}/${dados.hp_max}`));
  const atbWrapJ = el("div", "combate-vs-barra-wrap");
  const atbTrilhoJ = el("div", "barra-trilho mini");
  atbTrilhoJ.appendChild(el("div", "barra-preenchimento barra-atb", "")); atbTrilhoJ.firstChild.style.width = `${atbPct}%`;
  atbWrapJ.append(atbTrilhoJ, el("div", "barra-numero-mini", `${Math.round(atbPct)}%`));
  ladoJogador.append(hpWrapJ, atbWrapJ);

  // meio — ícone de combate + cronômetro
  // O meio guarda só o cronômetro. O ícone de espadas repetia o que os dois
  // retratos já dizem, e o lugar da luta virou título no topo — os dois
  // roubavam a largura que os retratos precisam.
  const meio = el("div", "combate-vs-meio");
  const cronometro = el("div", "combate-vs-timer");
  cronometro.id = "combate-cronometro";
  cronometro.textContent = "0s";
  meio.appendChild(cronometro);

  // lado do inimigo (alvo atual)
  const ladoInimigo = el("div", "combate-vs-lado inimigo" + (alvoAtingido ? " atingido" : ""));
  const retratoInimigo = el("div", "combate-vs-retrato");
  // 130 é o teto do CSS; urlImagem dobra sozinha pra retina.
  if (dados.img_key) porFundo(retratoInimigo, urlImagem(dados.img_key, 130));
  else retratoInimigo.textContent = "👹";
  ladoInimigo.appendChild(retratoInimigo);
  ladoInimigo.appendChild(el("div", "combate-vs-nome", alvoAtual ? alvoAtual.nome : "—"));
  const hpWrapI = el("div", "combate-vs-barra-wrap");
  const hpTrilhoI = el("div", "barra-trilho mini" + (alvoAtingido ? " flash-dano" : ""));
  hpTrilhoI.appendChild(el("div", "barra-preenchimento barra-inimigo", "")); hpTrilhoI.firstChild.style.width = `${alvoPct}%`;
  hpWrapI.append(hpTrilhoI, el("div", "barra-numero-mini", alvoAtual ? `${alvoAtual.hp}/${alvoAtual.hp_max}` : "—"));
  ladoInimigo.appendChild(hpWrapI);

  painel.append(ladoJogador, meio, ladoInimigo);
  c.appendChild(painel);

  // fila de iniciativa — quem age a seguir, usando o mesmo campo de
  // prontidão que já alimenta as barras acima (só não era usado ainda)
  const LETRAS = "ABCDEFGH";
  const combatentesVivos = [
    { tipo: "jogador", icone: "⚔️", nome: "Você", rotulo: "V",
      imagemUrl: IMG_JOGADOR ? urlImagem(IMG_JOGADOR, 34) : null,
      bar: dados.p_bar, spd: dados.p_spd, morto: false },
    ...dados.inimigos
      .map((ini, idx) => ({ ini, idx }))
      .filter(({ ini }) => ini.hp > 0)
      .map(({ ini, idx }) => ({
        tipo: "inimigo", icone: "👹", nome: ini.nome,
        rotulo: dados.inimigos.length > 1 ? LETRAS[idx] || String(idx + 1) : "",
        imagemUrl: ini.img_key ? urlImagem(ini.img_key, 34) : null,
        bar: ini.bar || 0, spd: ini.spd, morto: false,
      })),
  ];
  c.appendChild(filaIniciativa(combatentesVivos));


  // ---- botões de batalha em DUAS COLUNAS: atacar, poção e autobatalha na
  // mesma grade, porque na hora da luta são a mesma decisão — e empilhados
  // em largura cheia eles comiam meia tela de rolagem.
  const acoesGrid = el("div", "combate-acoes");
  const btnAtacar = document.createElement("button");
  btnAtacar.className = "botao-holofote"; btnAtacar.textContent = "⚔️ Atacar"; btnAtacar.id = "btn-atacar";
  btnAtacar.onclick = acaoAtacar;
  acoesGrid.appendChild(btnAtacar);
  const apoio = botoesDeApoio(async (snapshot) => {
    // Com snapshot (autobatalha) usa o caminho normal de pós-combate, que
    // sabe tratar vitória, morte, próximo andar, Onda e Exploração.
    if (snapshot) { processarResultadoCombate(snapshot); return; }
    const r = await api("/api/tower/combat");
    desenharCombate(r);
  }, dados.potions ?? dados.pocoes);
  while (apoio.firstChild) acoesGrid.appendChild(apoio.firstChild);
  c.appendChild(acoesGrid);

  if (dados.skills.length > 0) {
    c.appendChild(el("h3", "secao-titulo", "Skills"));
    const skillsGrid = el("div", "combate-acoes");
    for (const sk of dados.skills) {
      const btn = document.createElement("button");
      const pronta = sk.cooldown_restante <= 0;
      btn.className = "botao-secundario btn-skill-combate";   // o guia inicial aponta aqui
      botaoComEmblema(btn, sk.skill_id, pronta ? sk.nome : `${sk.nome} (${sk.cooldown_restante}t)`);
      btn.disabled = !pronta;
      if (!pronta) btn.style.opacity = "0.4";
      btn.onclick = () => acaoSkillCombate(sk.skill_id);
      skillsGrid.appendChild(btn);
    }
    c.appendChild(skillsGrid);
  }

  // 👹 26/09/2026 (dev): a linha dos inimigos fica ABAIXO dos botões de
  // batalha, em todos os modos (Torre, Explorar, Onda, Raid, Arena de Pets)
  // inimigos — uma fileira com a arte grande e a vida embaixo de cada um
  c.appendChild(el("h3", "secao-titulo", "Inimigos"));
  const fileira = el("div", "fileira-inimigos");
  dados.inimigos.forEach((ini, idx) => {
    const anteriorIni = ESTADO_COMBATE_ANTERIOR?.inimigos?.[idx];
    const atingido = anteriorIni !== undefined && ini.hp < anteriorIni;
    fileira.appendChild(fichaInimigo({
      icone: "👹",
      tag: dados.inimigos.length > 1 ? (LETRAS[idx] || String(idx + 1)) : "",
      // Antes isto era urlImagem(chave) sem largura: a arte vinha em ~1280px
      // pra um retrato de 30px. A ficha nova tem 78, e agora pede 78.
      imagemUrl: ini.img_key ? urlImagem(ini.img_key, 64) : null,
      nome: ini.nome, hp: ini.hp, hpMax: ini.hp_max,
      selecionado: idx === dados.alvo, atingido, morto: ini.hp <= 0,
      poder: ini.poder, poderEmoji: ini.poder_emoji, poderDesc: ini.poder_desc,
      onClick: () => acaoAlvo(idx),
    }));
  });
  c.appendChild(fileira);

  ESTADO_COMBATE_ANTERIOR = { hp: dados.hp, inimigos: dados.inimigos.map((i) => i.hp) };

  // ---- saída e leitura, no fim, também lado a lado
  const rodape = el("div", "combate-acoes");
  const btnFugir = document.createElement("button");
  if (EXPLORANDO_ATIVO) {
    btnFugir.className = "botao-secundario"; btnFugir.textContent = "🚫 Sem fuga aqui fora";
    btnFugir.disabled = true; btnFugir.style.opacity = "0.4";
  } else {
    btnFugir.className = "botao-secundario"; btnFugir.textContent = "🏃 Fugir"; btnFugir.id = "btn-fugir";
    btnFugir.onclick = acaoFugir;
  }
  rodape.appendChild(btnFugir);

  if (dados.log) {
    const verTudo = document.createElement("button");
    verTudo.className = "botao-secundario";
    verTudo.style.fontSize = "12px";
    verTudo.textContent = "📜 Ver a batalha";
    verTudo.onclick = abrirHistoricoCombate;
    rodape.appendChild(verTudo);
  }
  c.appendChild(rodape);

  if (dados.log) {

    const logBox = el("div", "log-combate");
    logBox.innerHTML = escaparHtml(dados.log).replace(/&lt;b&gt;/g, "<b>").replace(/&lt;\/b&gt;/g, "</b>").replace(/\n/g, "<br>");
    c.appendChild(logBox);
  }
}

async function acaoExplorar() {
  try {
    const r = await api("/api/tower/explore", { method: "POST" });
    som.clique();
    // andar junto com o ouro: subir de andar é o efeito principal desta
    // ação, e a barra de cima ficava no andar velho até trocar de tela.
    atualizarTopo({ gold: r.gold, tower_floor: r.andar });
    desenharTorre(r);
    if (r.em_combate) som.erro(); // sinaliza início de perigo
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

// =============================================================================
// 📜 O QUE A SUA ESCOLHA CAUSOU
// =============================================================================
// O motor de storylets devolve o que aconteceu — a rolagem aberta e os
// efeitos aplicados —, mas isso não chegava na tela: o clã mostrava só o
// dado num toast, e o encontro da Torre não mostrava nada (o código procurava
// um campo `texto` que `escolher()` nunca devolve).
//
// Consequência é o pagamento do sistema inteiro. Escolher e não ver o que
// mudou faz o storylet parecer enfeite — e faz o jogador escolher no escuro
// da próxima vez, porque não aprendeu nada com esta.
//
// Painel e não toast de propósito: toast some, e a conta do dado é
// justamente o que a pessoa quer reler quando falha.

const ROTULO_QUALIDADE = {
  comida: "Comida", madeira: "Madeira", couro: "Couro", metal: "Metal",
  ouro: "Ouro",
  moral: "Moral", humor: "Humor do clã", lealdade: "Lealdade", medo: "Medo",
  membros: "Aldeões", territorios: "Territórios", informacao: "Informação",
  autoridade: "Autoridade", reputacao: "Reputação", atrito: "Atrito",
  aura_recrutado: "Usuário de aura",
};

function rotuloDeQualidade(chave) {
  if (ROTULO_QUALIDADE[chave]) return ROTULO_QUALIDADE[chave];
  // Qualidade nova que ainda não tem rótulo: mostra o nome cru em vez de
  // esconder. Efeito invisível é pior que efeito feio.
  return String(chave).replace(/_/g, " ");
}

/** Painel com o que a escolha causou. `aoContinuar` fecha e segue. */

// ---------- 👣 encontro na Torre ----------
async function desenharEncontroTorre() {
  const c = document.getElementById("conteudo");
  const dados = await api("/api/tower/encontro");
  c.innerHTML = "";
  if (!dados.evento) { await renderTorre(); return; }
  const ev = dados.evento;
  c.appendChild(tituloDaLuta("Encontro"));
  // 👣 (26/09) encontro = Crônica: custo e chance aparecem ANTES de escolher
  // (a agência vem antes — opção com rolagem escondida é armadilha)
  const card = el("div", "cronica");
  if (ev.img_key) card.appendChild(arteDaCronica(ev.img_key));
  card.appendChild(el("div", "cronica-titulo", `${ev.icone} ${ev.titulo}`));
  card.appendChild(el("p", "cronica-texto", ev.texto));
  for (const op of ev.opcoes) {
    const b = document.createElement("button");
    b.className = "botao-secundario cronica-opcao";
    b.disabled = !op.disponivel;
    b.appendChild(el("div", "cronica-opcao-texto", op.texto));
    const extras = [];
    if (op.custos && op.custos.length) extras.push(op.custos.join(" · "));
    if (op.chance != null) extras.push(`🎲 ${op.chance}% de dar certo`);
    if (!op.disponivel && op.motivo) extras.push(`🔒 ${op.motivo}`);
    if (extras.length) b.appendChild(el("div", "cronica-opcao-extra", extras.join("  ·  ")));
    b.onclick = () => decidirEncontro(op.indice, b);
    card.appendChild(b);
  }
  c.appendChild(card);
}

async function decidirEncontro(idx, botao) {
  if (botao) botao.disabled = true;
  try {
    const r = await api("/api/tower/encontro/decidir", {
      method: "POST", body: JSON.stringify({ opcao: idx }) });
    const res = r.resultado || {};
    (res.sucesso === false ? som.erro : som.moeda)();
    atualizarTopo({ gold: r.gold });
    const c = document.getElementById("conteudo");
    c.innerHTML = "";
    c.appendChild(tituloDaLuta("Encontro"));
    const box = el("div", "cronica");
    box.appendChild(el("div", "cronica-titulo", res.titulo || "Encontro"));
    box.appendChild(el("p", "", `${res.escolha}${res.sucesso === true ? " — deu certo!" : res.sucesso === false ? " — deu errado." : ""}`));
    for (const l of res.linhas || []) box.appendChild(el("div", "cronica-resultado", l));
    const seguir = document.createElement("button");
    seguir.className = "botao-holofote";
    seguir.style.cssText = "width:100%;margin-top:12px";
    seguir.textContent = "Seguir pela Torre";
    seguir.onclick = () => renderTorre();
    box.appendChild(seguir);
    c.appendChild(box);
  } catch (e) {
    som.erro();
    if (botao) botao.disabled = false;
    if (!e.jaAlertado) toast(e.message, true);
  }
}

// 🔥 26/09/2026 (dev): no 1º andar, "Avançar" sem clã fundado abre a
// FUNDAÇÃO na hora (as 3 crônicas), depois o tutorial do idle — e aí sobe.
async function acaoAvancarAndar() {
  await atualizarPendencias(true);
  if (PENDENCIAS.clan_bloqueado) { await desenharFundacaoNaTorre(); return; }
  await acaoTorreSimples("/api/tower/advance");
}

async function desenharFundacaoNaTorre() {
  const c = document.getElementById("conteudo");
  let d;
  try { d = await api("/api/clan/cronicas"); }
  catch (e) { if (!e.jaAlertado) toast(e.message, true); return; }
  if (d.fundado) { await atualizarPendencias(true); mostrarTutorialDoIdle(); return; }
  const cr = (d.fila || []).find((x) => x.fundacao);
  if (!cr) { toast("A fundação não apareceu — abra Clã → Crônicas.", true); return; }
  c.innerHTML = "";
  c.appendChild(tituloDaLuta("Antes do 2º andar"));
  const card = cartaoDaCronica(cr);
  card.querySelectorAll(".cronica-opcao").forEach((b, i) => {
    b.onclick = async () => {
      card.querySelectorAll(".cronica-opcao").forEach((x) => { x.disabled = true; });
      try {
        const r = await api("/api/clan/cronicas", { method: "POST", body: JSON.stringify({ uid: cr.uid, opcao: cr.opcoes[i].indice }) });
        som.moeda();
        for (const l of r.linhas || []) toast(l);
        await desenharFundacaoNaTorre();
      } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    };
  });
  c.appendChild(card);
}

/** 💤 O tutorial do idle — logo depois de fundar o clã (26/09/2026). */
function mostrarTutorialDoIdle() {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  c.appendChild(tituloDaLuta("Seu clã nasceu"));
  // (28/09) Era uma lista de 5 regras que o guia do clã repetia inteira
  // minutos depois. Aqui fica só a comemoração e o caminho; as regras são
  // explicadas UMA vez, no Resumo do clã, apontando pra cada coisa na tela.
  const box = el("div", "aldeia-box tutorial-idle");
  box.appendChild(el("div", "aldeia-estagio", "🏰 O clã trabalha enquanto você não está"));
  box.appendChild(el("p", "texto-fraco",
    "Seus aldeões coletam, comem e vivem histórias mesmo com você fora. " +
    "Abra 🏰 Clã quando quiser: lá eu te mostro como tudo funciona."));
  const subir = document.createElement("button");
  subir.className = "botao-holofote"; subir.style.cssText = "width:100%;margin-top:12px";
  subir.textContent = "⬆️ Subir pro 2º andar";
  subir.onclick = () => acaoTorreSimples("/api/tower/advance");
  box.appendChild(subir);
  c.appendChild(box);
}

async function acaoTorreSimples(caminho) {
  try {
    const r = await api(caminho, { method: "POST" });
    som.clique();
    // andar junto com o ouro: subir de andar é o efeito principal desta
    // ação, e a barra de cima ficava no andar velho até trocar de tela.
    atualizarTopo({ gold: r.gold, tower_floor: r.andar });
    desenharTorre(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function acaoAtacar() {
  try {
    const r = await api("/api/tower/attack", { method: "POST" });
    processarResultadoCombate(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function acaoSkillCombate(skillId) {
  try {
    const r = await api("/api/tower/skill", { method: "POST", body: JSON.stringify({ skill_id: skillId }) });
    processarResultadoCombate(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function acaoAlvo(idx) {
  try {
    const r = await api("/api/tower/target", { method: "POST", body: JSON.stringify({ idx }) });
    som.clique();
    if (EXPLORANDO_ATIVO || ONDA_ATIVA) desenharCombate(r); else desenharTorre(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function acaoFugir() {
  try {
    const r = await api("/api/tower/flee", { method: "POST" });
    som.clique();
    atualizarTopo({ gold: r.gold }); // 🔥 a fuga cobra uma multa em ouro

    if (r.onda?.tipo === "fuga") {
      ONDA_ATIVA = false;
      pararCronometroCombate();
      const corpo = el("div");
      corpo.appendChild(el("h3", "secao-titulo", "🏃 Você fugiu da Onda"));
      corpo.appendChild(el("p", "", r.log.replace(/<[^>]+>/g, "")));
      corpo.appendChild(el("p", "texto-fraco", r.onda.msg_onda.replace(/<[^>]+>/g, "")));
      const btn = document.createElement("button");
      btn.className = "botao-holofote sheet-opcao"; btn.textContent = "Voltar";
      btn.onclick = async () => { fecharSheet(); await irPara("onda"); };
      corpo.appendChild(btn);
      abrirSheet(corpo);
      return;
    }

    toast(r.log.replace(/<[^>]+>/g, ""));
    desenharTorre(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function acaoRevive() {
  try {
    const r = await api("/api/tower/revive", { method: "POST" });
    if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
    som.vitoria();
    toast(r.msg.replace(/<[^>]+>/g, ""));
    desenharTorre(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

function processarResultadoCombate(r) {
  if (EXPLORANDO_ATIVO) { processarResultadoExplorarCombate(r); return; }
  if (ONDA_ATIVA) { processarResultadoOndaCombate(r); return; }
  if (r.morreu) {
    som.erro();
  } else if (!r.em_combate) {
    som.vitoria();
  } else {
    som.clique();
  }
  // 🔥 ouro ganho ao matar inimigo, refletido na hora — e o ANDAR junto:
  // ele sobe dentro do combate (subir de andar é consequência da vitória)
  // e a barra de cima ficava no andar antigo até trocar de tela.
  atualizarTopo({ gold: r.gold, tower_floor: r.andar });
  desenharTorre(r);
}

async function processarResultadoOndaCombate(r) {
  atualizarTopo({ gold: r.gold });
  const info = r.onda;

  if (info && info.tipo === "derrota") {
    som.erro();
    ONDA_ATIVA = false;
    pararCronometroCombate();
    const msgOnda = info.msg_onda || r.log || "";
    const bateuRecorde = msgOnda.includes("Novo recorde");
    if (bateuRecorde) { som.vitoria(); notificacaoGrande("🏅", "Novo recorde!", `Você chegou na Onda ${ONDA_NUMERO_ATUAL}`); }
    const corpo = el("div");
    corpo.appendChild(el("h3", "secao-titulo", bateuRecorde ? "🏅 Novo recorde!" : "💀 A Onda terminou"));
    corpo.appendChild(el("p", "", msgOnda.replace(/<[^>]+>/g, "")));
    const btn = document.createElement("button");
    btn.className = "botao-holofote sheet-opcao"; btn.textContent = "Voltar";
    btn.onclick = async () => { fecharSheet(); await irPara("onda"); };
    corpo.appendChild(btn);
    abrirSheet(corpo);
    return;
  }

  if (info && info.tipo === "vitoria") {
    // a onda seguinte já foi spawnada no backend na mesma resposta — r já
    // é o snapshot dos 5 novos chefes, então continua direto pra próxima luta
    som.vitoria();
    ONDA_NUMERO_ATUAL = info.onda_atual;
    toast((info.msg_onda || "").replace(/<[^>]+>/g, ""));
    if (info.onda_atual % 3 === 1) notificacaoGrande("🌊", `Onda ${info.onda_atual}!`, "Chefes mais fortes à frente");
    ESTADO_COMBATE_ANTERIOR = null; // é um combate novo (novos 5 chefes)
    desenharCombate(r);
    return;
  }

  som.clique();
  desenharCombate(r);
}

async function processarResultadoExplorarCombate(r) {
  atualizarTopo({ gold: r.gold });
  if (r.em_combate) { som.clique(); desenharCombate(r); return; }
  if (r.morreu) {
    // o backend já restaurou o andar real da Torre e encerrou a expedição
    // (perda de item incluída) — a partir daqui é a mesma tela de morte de sempre.
    som.erro();
    EXPLORANDO_ATIVO = false;
    pararCronometroCombate();
    desenharTorre(r);
    return;
  }
  // vitória — o backend já restaurou o andar real e avançou o dia da expedição
  som.vitoria();
  EXPLORANDO_ATIVO = false;
  pararCronometroCombate();
  mostrarResultadoEventoExplorar(r.log || "", r.explorar);
}


// =============================================================================
// 🌍 EXPLORAR MUNDO (expedição de 7 dias, sem fuga até completar)
// =============================================================================
async function renderExplorar() {
  const dados = await api("/api/explore");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  if (!dados.ativo) {
    const box = el("div", "em-construcao");
    box.appendChild(el("div", "em-construcao-icone", "🌍"));
    box.appendChild(el("p", "",
      `Os portões da cidade se abrem pro mundo exterior a cada 7 dias. Pela sua força atual, você entraria no Tier ${dados.tier} (andares ${dados.andar_inicio}-${dados.andar_fim}).`));
    box.appendChild(el("p", "texto-fraco",
      `A partir do momento que entrar, não existe fuga: são 7 explorações seguidas até poder voltar. Cada uma pode trazer batalha, um chefe, ouro, uma skill rara, um pet raro ou uma montaria rara.`));
    const btn = document.createElement("button");
    btn.className = "botao-holofote"; btn.style.marginTop = "14px";
    btn.textContent = "🌍 Entrar no Mundo Exterior";
    btn.onclick = async () => {
      const r = await api("/api/explore/enter", { method: "POST" });
      som.clique(); toast(r.msg.replace(/<[^>]+>/g, ""));
      await renderExplorar();
    };
    box.appendChild(btn);
    c.appendChild(box);
    return;
  }

  const pct = dados.total > 0 ? Math.min(100, (dados.dia / dados.total) * 100) : 0;
  c.appendChild(barraDeProgresso("🌍 Expedição", `${dados.dia}/${dados.total}`, pct, "barra-xp"));
  c.appendChild(el("p", "texto-fraco", `Você está na área do Tier ${dados.tier} (andares ${dados.andar_inicio}-${dados.andar_fim}). Sem fuga até completar as ${dados.total} explorações.`));

  const btnExplorar = document.createElement("button");
  btnExplorar.className = "botao-holofote";
  btnExplorar.style.marginTop = "16px";
  btnExplorar.textContent = "🗺️ Explorar";
  btnExplorar.onclick = acaoExplorarMundo;
  c.appendChild(btnExplorar);
}

async function acaoExplorarMundo() {
  try {
    const r = await api("/api/explore/go", { method: "POST" });
    if (r.tipo_evento === "combate") {
      som.erro(); // sinaliza início de perigo, igual à Torre
      EXPLORANDO_ATIVO = true;
      ESTADO_COMBATE_ANTERIOR = null; // reseta o rastreamento — é um combate novo
      COMBATE_INICIO = null; // idem pro cronômetro
      toast(r.log.replace(/<[^>]+>/g, ""));
      desenharCombate(r);
      return;
    }
    som.clique();
    atualizarTopo({ gold: r.gold });
    mostrarResultadoEventoExplorar(r.msg, r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

// mostra o resultado de um evento (instantâneo ou vitória em combate) num
// bottom sheet, e decide se continua a expedição ou fecha (voltou pra cidade)
function mostrarResultadoEventoExplorar(msg, info) {
  const corpo = el("div");
  const finalizou = !!info?.expedicao_finalizada;
  const drop = info?.drop;
  corpo.appendChild(el("h3", "secao-titulo", finalizou ? "🏙️ De volta à cidade!" : "🌍 Evento da exploração"));

  // Só o que caiu. A narração ("uma carroça abandonada...") é a mesma
  // handful de frases repetindo a cada exploração — em 7 explorações
  // seguidas ela vira ruído, e o que o jogador quer saber é o que ganhou.
  if (drop && drop.nome) {
    const caixa = el("div", `drop-caixa${drop.raridade ? " " + classeRar(drop.raridade) : ""}`);
    const arte = el("div", "drop-arte");
    if (drop.img_key) porFundo(arte, urlImagem(drop.img_key, 72));
    else arte.textContent = drop.icone || "🎁";
    caixa.appendChild(arte);
    const txt = el("div", "drop-texto");
    txt.appendChild(el("div", "drop-nome", drop.nome));
    txt.appendChild(el("div", "drop-qtd",
      drop.tipo === "ouro" ? `+${Number(drop.quantidade).toLocaleString("pt-BR")}`
                           : `+${drop.quantidade}`));
    caixa.appendChild(txt);
    corpo.appendChild(caixa);
  } else {
    corpo.appendChild(el("p", "texto-fraco", "Nada desta vez."));
  }
  if (info?.msg_extra) corpo.appendChild(el("p", "texto-fraco", info.msg_extra.replace(/<[^>]+>/g, "")));

  const btn = document.createElement("button");
  btn.className = "botao-holofote sheet-opcao";
  btn.textContent = finalizou ? "Voltar" : "Continuar explorando";
  btn.onclick = async () => { fecharSheet(); await renderExplorar(); };
  corpo.appendChild(btn);
  abrirSheet(corpo);

  if (finalizou) { som.vitoria(); notificacaoGrande("🏙️", "Expedição concluída!", "Os portões se abrem de novo"); }
}

// =============================================================================
// 🌊 ONDA DE BOSSES (5 chefes ao mesmo tempo, sem fim — só 1 tentativa/dia)
// =============================================================================
async function renderOnda() {
  const dados = await api("/api/wave");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  ONDA_NUMERO_ATUAL = dados.onda_atual || 1;

  const selo = (r) => r > 0 ? `🏅 Seu recorde: Onda ${r}` : "🏅 Você ainda não tem recorde — a primeira tentativa já vira um.";

  if (!dados.pode_jogar_hoje) {
    c.appendChild(estadoVazio("🌊", "Você já tentou a Onda de Bosses hoje. Os portões abrem de novo amanhã."));
    c.appendChild(el("p", "texto-fraco", selo(dados.recorde)));
    return;
  }

  const box = el("div", "em-construcao");
  box.appendChild(el("div", "em-construcao-icone", "🌊"));
  box.appendChild(el("p", "",
    `${dados.bosses_por_onda} chefes vivos ao mesmo tempo na mesma batalha. Vencendo todos, a próxima onda já começa na hora — sempre mais forte. Não tem fim, só acaba quando você cair. Tudo que ganhar pelo caminho é seu, mesmo se cair no meio.`));
  box.appendChild(el("p", "texto-fraco", selo(dados.recorde)));
  box.appendChild(el("p", "texto-fraco", "Só 1 tentativa por dia — capriche."));
  const btn = document.createElement("button");
  btn.className = "botao-holofote"; btn.style.marginTop = "14px";
  btn.textContent = "🌊 Começar a Onda";
  btn.onclick = acaoIniciarOnda;
  box.appendChild(btn);
  c.appendChild(box);
}

async function acaoIniciarOnda() {
  try {
    const r = await api("/api/wave/start", { method: "POST" });
    som.erro(); // sinaliza início de perigo, igual à Torre/Exploração
    ONDA_ATIVA = true;
    ONDA_NUMERO_ATUAL = r.onda_atual || 1;
    ESTADO_COMBATE_ANTERIOR = null;
    COMBATE_INICIO = null;
    toast(r.log.replace(/<[^>]+>/g, ""));
    desenharCombate(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

// =============================================================================
// 🏪 LOJA (poção, vender cores/itens, VIP e pacotes de ⭐)
// =============================================================================
// =============================================================================
// 🏪 LOJA — comprar e vender o que é do JOGO
// =============================================================================
// A premium saiu daqui pra tela própria: misturada, ela transformava a loja
// numa lista onde "Poção 25g" e "VIP 500⭐" eram cartões do mesmo tamanho, e
// o jogador rolava a loja inteira pra achar o que vender.
//
// E o que ele mais faz aqui é VENDER. Por isso o inventário é o corpo da
// tela e cada linha ABRE no lugar, com as ações debaixo do nome — em vez de
// dois botões espremidos ao lado, que na largura do celular deixavam o nome
// do item com três letras e reticências.

let LOJA_ABERTO = null;   // qual linha está expandida
// A lista de cores começa FECHADA: ver "Vender cores" é uma decisão, não
// o caminho pra chegar no resto da loja.
let LOJA_CORES_ABERTAS = false;

function moedaFicha(icone, valor, rotulo, tom) {
  const f = el("div", "moeda-ficha" + (tom ? ` ${tom}` : ""));
  f.appendChild(el("span", "moeda-ficha-icone", icone));
  f.appendChild(el("span", "moeda-ficha-valor", valor));
  f.appendChild(el("span", "moeda-ficha-rotulo", rotulo));
  return f;
}

/** Linha de venda que abre no lugar. `acoes` só é montado quando abre —
 *  botão invisível não precisa existir no DOM. */
function linhaDeVenda(chave, titulo, sub, raridade, montarAcoes) {
  const aberta = LOJA_ABERTO === chave;
  const caixa = el("div", `venda-linha${raridade ? " " + classeRar(raridade) : ""}${aberta ? " aberta" : ""}`);
  const topo = document.createElement("button");
  topo.className = "venda-topo";
  const txt = el("div", "venda-txt");
  txt.appendChild(el("div", "venda-nome", titulo));
  txt.appendChild(el("div", "venda-sub", sub));
  topo.appendChild(txt);
  topo.appendChild(el("span", "venda-seta", aberta ? "▾" : "›"));
  topo.onclick = () => {
    LOJA_ABERTO = aberta ? null : chave;
    som.clique();
    renderLoja();
  };
  caixa.appendChild(topo);
  if (aberta) {
    const acoes = el("div", "venda-acoes");
    montarAcoes(acoes);
    caixa.appendChild(acoes);
  }
  return caixa;
}

function botaoVenda(rotulo, aoTocar, principal) {
  const b = document.createElement("button");
  b.className = principal ? "botao-holofote" : "botao-secundario";
  b.textContent = rotulo;
  b.onclick = aoTocar;
  return b;
}

function linhaMaterialDaLoja(m) {
  const card = el("div", "venda-linha");
  const topo = el("div", "venda-topo");
  const txt = el("div", "venda-txt");
  txt.appendChild(el("div", "venda-nome", `⛏️ ${m.nome} (rank ${m.rank})`));
  txt.appendChild(el("div", "venda-sub", `${m.preco}g cada · na mochila: ${m.tem} · cai de ${m.fonte}`));
  topo.appendChild(txt);
  card.appendChild(topo);
  const botoes = el("div", "habitante-acoes");
  for (const qtd of [1, 5]) {
    botoes.appendChild(botaoVenda(`+${qtd} (${qtd * m.preco}g)`, async () => {
      try {
        const r = await api("/api/shop/buy_material", { method: "POST", body: JSON.stringify({ rank: m.rank, quantidade: qtd }) });
        som.moeda(); toast(r.msg); atualizarTopo({ gold: r.gold }); await renderLoja();
      } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    }, true));
  }
  card.appendChild(botoes);
  return card;
}

async function renderLoja() {
  const dados = await api("/api/shop");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  const moedas = el("div", "moeda-linha");
  moedas.appendChild(moedaFicha("💰", dados.gold.toLocaleString("pt-BR"), "ouro"));
  moedas.appendChild(moedaFicha("🧪", `${dados.potions}/10`, "poções",
    dados.potions >= 10 ? "cheio" : ""));
  moedas.appendChild(moedaFicha("⭐", String(dados.premium), "premium"));
  c.appendChild(moedas);

  // ---------- comprar ----------
  c.appendChild(el("h3", "secao-titulo", "Comprar"));
  const cheio = dados.potions >= 10;
  const cardPocao = el("div", "venda-linha");
  const topo = el("div", "venda-topo");
  const txt = el("div", "venda-txt");
  txt.appendChild(el("div", "venda-nome", "🧪 Poção de Vida"));
  txt.appendChild(el("div", "venda-sub",
    cheio ? "mochila cheia — limite de 10" : `25g · você tem ${dados.potions} de 10`));
  topo.appendChild(txt);
  const btnPocao = botaoVenda(cheio ? "Cheio" : "Comprar", async () => {
    const r = await api("/api/shop/buy_potion", { method: "POST" });
    if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
    som.moeda(); toast(r.msg.replace(/<[^>]+>/g, "")); atualizarTopo({ gold: r.gold });
    await renderLoja();
  }, !cheio);
  if (cheio) { btnPocao.disabled = true; btnPocao.style.opacity = "0.45"; }
  btnPocao.classList.add("venda-botao-topo");
  topo.appendChild(btnPocao);
  cardPocao.appendChild(topo);
  c.appendChild(cardPocao);

  // 🛒 material de forja: caro de propósito — atalho pra quem tem ouro
  for (const m of (dados.materiais || [])) c.appendChild(linhaMaterialDaLoja(m));

  // ---------- vender: equipamento ----------
  c.appendChild(el("h3", "secao-titulo", `Vender equipamento (${dados.itens.length})`));
  if (!dados.itens.length) {
    c.appendChild(estadoVazio("📦", "Nada na mochila pra vender. Equipamento vem da Forja e dos baús da Torre; o que está equipado não aparece aqui."));
  } else {
    for (const it of dados.itens) {
      const chave = `item:${it.slot}:${it.idx}`;
      c.appendChild(linhaDeVenda(chave, it.nome,
        `${SLOT_INFO[it.slot]?.rotulo || it.slot} · ${it.raridade} · vale ${it.preco}g`,
        it.raridade,
        (acoes) => {
          acoes.appendChild(botaoVenda(`Vender por ${it.preco}g`,
            () => acaoVenderItem(it.slot, it.idx), true));
        }));
    }
  }

  // ---------- vender: cores ----------
  // 20/09/2026: a lista inteira ficava aberta. Quem tem 12 tipos de core
  // rolava uma tela de cores pra chegar em qualquer outra coisa da loja —
  // e vender core é a ação mais rara aqui, porque core vale mais forjado.
  // Agora é um botão que abre.
  c.appendChild(el("h3", "secao-titulo", `Vender cores (${dados.cores.length})`));
  const abrirCores = document.createElement("button");
  abrirCores.className = "botao-secundario";
  abrirCores.style.cssText = "width:100%";
  abrirCores.textContent = LOJA_CORES_ABERTAS
    ? "💎 Esconder cores" : `💎 Vender cores (${dados.cores.length})`;
  abrirCores.onclick = () => {
    LOJA_CORES_ABERTAS = !LOJA_CORES_ABERTAS;
    som.clique();
    renderLoja();
  };
  c.appendChild(abrirCores);
  if (!LOJA_CORES_ABERTAS) {
    // nada mais: a seção fica fechada
  } else if (!dados.cores.length) {
    c.appendChild(estadoVazio("💎", "Você não tem cores. Elas caem dos monstros da Torre e da Exploração — e rendem mais forjadas do que vendidas."));
  } else {
    for (const core of dados.cores) {
      const chave = `core:${core.core_id}`;
      c.appendChild(linhaDeVenda(chave, core.nome,
        `você tem ${core.quantidade} · ${core.preco_unidade}g cada`, null,
        (acoes) => {
          acoes.appendChild(botaoVenda(`Vender 1 (${core.preco_unidade}g)`,
            () => acaoVenderCore(core.core_id, false)));
          acoes.appendChild(botaoVenda(
            `Vender tudo (${core.preco_total.toLocaleString("pt-BR")}g)`,
            () => acaoVenderCore(core.core_id, true), true));
        }));
    }
  }

  // Um caminho pra premium, sem trazer a premium pra cá.
  const irPremium = document.createElement("button");
  irPremium.className = "botao-secundario";
  irPremium.style.cssText = "width:100%;margin-top:16px";
  irPremium.textContent = "⭐ Loja Premium";
  irPremium.onclick = () => irPara("loja_premium");
  c.appendChild(irPremium);
}

// =============================================================================
// ⭐ LOJA PREMIUM — tela própria
// =============================================================================
// Separada da loja do jogo de propósito: são duas decisões diferentes, com
// moedas diferentes. Juntas, "vender uma espada por 40g" e "comprar VIP por
// 500⭐" disputavam a mesma rolagem.
async function renderLojaPremium() {
  const dados = await api("/api/shop");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  const moedas = el("div", "moeda-linha");
  moedas.appendChild(moedaFicha("⭐", String(dados.premium), "premium"));
  moedas.appendChild(moedaFicha("💰", dados.gold.toLocaleString("pt-BR"), "ouro"));
  c.appendChild(moedas);
  // A tela e a barra de cima leem o mesmo saldo: sem isto, a barra podia
  // mostrar ⭐ de duas sessões atrás enquanto a loja mostrava o certo.
  atualizarTopo({ premium: dados.premium, gold: dados.gold });

  const oferta = (icone, titulo, texto, rotulo, rota, emoji, subtitulo) => {
    const painel = el("div", "gold-panel");
    painel.style.marginBottom = "10px";
    painel.appendChild(el("div", "arena-semana-titulo", `${icone} ${titulo}`));
    painel.appendChild(el("p", "texto-fraco", texto));
    const btn = document.createElement("button");
    btn.className = "botao-holofote";
    btn.style.marginTop = "8px";
    btn.textContent = rotulo;
    btn.onclick = async () => {
      try {
        const r = await api(rota, { method: "POST" });
        if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
        atualizarTopo({ premium: r.premium, gold: r.gold });
        som.raro(); notificacaoGrande(emoji, titulo, subtitulo);
        await renderLojaPremium();
      } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
    };
    painel.appendChild(btn);
    return painel;
  };

  c.appendChild(el("h3", "secao-titulo", "Benefícios"));
  c.appendChild(oferta("👑", "VIP — 28 dias", "2x XP e 2x drop por 28 dias — 500⭐",
    "Comprar VIP (500⭐)", "/api/shop/buy_vip", "👑", "28 dias de 2x XP e 2x drop"));
  c.appendChild(oferta("🤖", "Autobatalha — 28 dias", "Combate automático por 28 dias — 250⭐ (R$25)",
    "Comprar Autobatalha (250⭐)", "/api/shop/buy_autobattle", "🤖",
    "28 dias de combate automático"));

  c.appendChild(el("h3", "secao-titulo", "Recarregar"));
  const painelEstrelas = el("div", "gold-panel");
  painelEstrelas.appendChild(el("div", "arena-semana-titulo", "💳 Comprar ⭐ via Pix"));
  painelEstrelas.appendChild(el("p", "texto-fraco", "Escolha quantas ⭐ quer. O Pix e o comprovante são feitos aqui mesmo."));
  const pacotes = el("div", "gacha-botoes");
  const btn100 = document.createElement("button");
  btn100.className = "botao-secundario"; btn100.textContent = "R$10 → 100⭐";
  btn100.onclick = () => acaoPedirEstrelas(100);
  const btn500 = document.createElement("button");
  btn500.className = "botao-secundario"; btn500.textContent = "R$50 → 500⭐";
  btn500.onclick = () => acaoPedirEstrelas(500);
  pacotes.append(btn100, btn500);
  painelEstrelas.appendChild(pacotes);
  c.appendChild(painelEstrelas);
}

async function acaoVenderCore(coreId, all) {
  try {
    const r = await api("/api/shop/sell_core", { method: "POST", body: JSON.stringify({ core_id: coreId, all }) });
    if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
    som.moeda(); toast(r.msg.replace(/<[^>]+>/g, "")); atualizarTopo({ gold: r.gold }); await renderLoja();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function acaoVenderItem(slot, idx) {
  try {
    const r = await api("/api/shop/sell_item", { method: "POST", body: JSON.stringify({ slot, idx }) });
    if (!r.ok) { som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""), true); return; }
    som.moeda(); toast(r.msg.replace(/<[^>]+>/g, "")); atualizarTopo({ gold: r.gold }); await renderLoja();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function acaoPedirEstrelas(amount) {
  try {
    const r = await api("/api/shop/order_stars", { method: "POST", body: JSON.stringify({ amount }) });
    som.clique();
    abrirSheetComprovante(r.msg.replace(/<[^>]+>/g, ""));
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

// 🧾 O comprovante era uma foto mandada no chat do bot. Agora sobe daqui.
// Enquanto o jogo viveu dentro do Telegram isso era limitação real: Mini App
// não entrega arquivo pro bot. No site deixou de ser.
function abrirSheetComprovante(mensagemPedido) {
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", "💳 Pedido criado"));
  if (mensagemPedido) corpo.appendChild(el("p", "", mensagemPedido));
  corpo.appendChild(el("p", "texto-fraco",
    "Faça o Pix e mande o comprovante aqui mesmo. As ⭐ entram na hora; "
    + "até o administrador conferir, ficam bloqueados Arena, Arena dos Pets, "
    + "Raid e Mercado. O resto do jogo segue normal."));

  const entrada = document.createElement("input");
  entrada.type = "file";
  // O accept inclui PDF porque muito banco só exporta o recibo assim —
  // exigir print daria mais trabalho ao jogador sem ganhar nada.
  entrada.accept = "image/jpeg,image/png,image/webp,application/pdf";
  entrada.className = "sheet-input";
  corpo.appendChild(entrada);

  const nomeArquivo = el("p", "texto-fraco", "");
  corpo.appendChild(nomeArquivo);

  const botao = document.createElement("button");
  botao.className = "botao-holofote sheet-opcao";
  botao.textContent = "Enviar comprovante";
  corpo.appendChild(botao);

  const depois = document.createElement("button");
  depois.className = "botao-secundario sheet-opcao";
  depois.textContent = "Mando depois";
  depois.onclick = () => fecharSheet();
  corpo.appendChild(depois);

  entrada.onchange = () => {
    const f = entrada.files && entrada.files[0];
    nomeArquivo.textContent = f ? `Escolhido: ${f.name}` : "";
  };

  botao.onclick = async () => {
    const f = entrada.files && entrada.files[0];
    // Guarda COM aviso: botão que não faz nada faz o jogador achar que travou.
    if (!f) { som.erro(); toast("Escolha o arquivo do comprovante primeiro.", true); return; }
    if (f.size > 8 * 1024 * 1024) { som.erro(); toast("O arquivo passa de 8 MB.", true); return; }

    botao.disabled = true;
    botao.textContent = "Enviando...";
    try {
      const forma = new FormData();
      forma.append("arquivo", f);
      // Sem Content-Type aqui de propósito: o navegador precisa montar o
      // boundary do multipart sozinho. Definir "application/json" na mão
      // faz o servidor recusar um arquivo perfeitamente válido.
      const resp = await api("/api/shop/comprovante", {
        method: "POST", body: forma, headers: { "Content-Type": undefined },
      });
      som.moeda();
      fecharSheet();
      toast(resp.msg);
      if (resp.saldo !== undefined) atualizarTopo({ premium: resp.saldo });
    } catch (e) {
      som.erro();
      if (!e.jaAlertado) toast(e.message, true);
      botao.disabled = false;
      botao.textContent = "Enviar comprovante";
    }
  };

  abrirSheet(corpo);
}

// =============================================================================
// 🐲 BOSS GLOBAL (compartilhado entre todos os jogadores do servidor)
// =============================================================================
// 🐲 o boss é compartilhado entre TODOS os jogadores — enquanto você olha a
// tela, outras pessoas estão batendo nele. Esse polling atualiza a barra e a
// fase no lugar (sem re-renderizar tudo, pra não perder a rolagem nem piscar).
let BOSS_GLOBAL_TIMER = null;
function pararPollingBossGlobal() {
  if (BOSS_GLOBAL_TIMER) { clearInterval(BOSS_GLOBAL_TIMER); BOSS_GLOBAL_TIMER = null; }
}
function iniciarPollingBossGlobal() {
  pararPollingBossGlobal();
  BOSS_GLOBAL_TIMER = setInterval(async () => {
    if (TELA_ATUAL !== "boss_global") { pararPollingBossGlobal(); return; }
    try {
      const d = await api("/api/global_boss");
      const barra = document.getElementById("boss-global-fill");
      const numero = document.getElementById("boss-global-numero");
      const fase = document.getElementById("boss-global-fase");
      if (!barra) { pararPollingBossGlobal(); return; } // tela trocou no meio
      const pct = d.hp_max > 0 ? Math.max(0, Math.min(100, (d.hp / d.hp_max) * 100)) : 0;
      barra.style.width = `${pct}%`;
      if (numero) numero.textContent = `${d.hp.toLocaleString("pt-BR")} / ${d.hp_max.toLocaleString("pt-BR")} (${Math.round(pct)}%)`;
      if (fase) fase.textContent = `🌋 ${d.fase_nome} (ATK/DEF x${d.fase_mult})`;
    } catch (e) { /* falha de rede não deve derrubar a tela */ }
  }, 5000);
}

async function renderBossGlobal() {
  const dados = await api("/api/global_boss");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  iniciarPollingBossGlobal();

  const painel = el("div", "boss-global-painel");
  painel.appendChild(el("div", "boss-global-nome", `🐲 ${dados.nome}`));
  painel.appendChild(el("div", "boss-global-geracao", `Geração ${dados.geracao}`));
  const faseEl = el("div", "boss-global-fase", `🌋 ${dados.fase_nome} (ATK/DEF x${dados.fase_mult})`);
  faseEl.id = "boss-global-fase";
  painel.appendChild(faseEl);

  const hpPct = dados.hp_max > 0 ? Math.max(0, Math.min(100, (dados.hp / dados.hp_max) * 100)) : 0;
  const barraWrap = el("div", "boss-global-barra-wrap");
  const trilho = el("div", "barra-trilho");
  const preench = el("div", "barra-preenchimento barra-inimigo");
  preench.id = "boss-global-fill";
  preench.style.width = `${hpPct}%`;
  trilho.appendChild(preench);
  const numeroEl = el("div", "barra-numero-mini", `${dados.hp.toLocaleString("pt-BR")} / ${dados.hp_max.toLocaleString("pt-BR")} (${Math.round(hpPct)}%)`);
  numeroEl.id = "boss-global-numero";
  barraWrap.append(trilho, numeroEl);
  painel.appendChild(barraWrap);

  if (dados.dano_sessao > 0) {
    painel.appendChild(el("p", "boss-global-sessao", `⚔️ Dano acumulado nesta luta: ${dados.dano_sessao.toLocaleString("pt-BR")} — foge ou derruba o boss pra aplicar.`));
  }
  c.appendChild(painel);

  // ⚙️ 25/09/2026 (dev): a luta inteira é automática — um toque troca golpes
  // até você cair ou o boss cair, e o dano vai pro boss no fim.
  const semVida = (dados.meu_hp || 0) <= 0;
  const btnAuto = document.createElement("button");
  btnAuto.className = "botao-holofote";
  btnAuto.style.cssText = "width:100%";
  btnAuto.textContent = semVida ? "💀 Sem vida — cure-se primeiro" : "⚙️ Batalha automática";
  btnAuto.disabled = semVida;
  btnAuto.onclick = () => acaoBatalhaAutomaticaBoss(btnAuto);
  c.appendChild(btnAuto);
  c.appendChild(el("p", "texto-fraco",
    `Sua vida: ${(dados.meu_hp || 0).toLocaleString("pt-BR")}/${(dados.meu_hp_max || 1).toLocaleString("pt-BR")}. ` +
    "A luta segue sozinha até alguém cair; o dano que você causou fica no boss."));
  if (ULTIMA_BATALHA_BOSS) {
    c.appendChild(resultadoBatalhaBoss(ULTIMA_BATALHA_BOSS));
    ULTIMA_BATALHA_BOSS = null;
  }

  c.appendChild(el("h3", "secao-titulo", "🏆 Top Contribuidores"));
  if (dados.top_contribuidores.length === 0) {
    c.appendChild(estadoVazio("🐲", "Ninguém atacou este boss ainda. Quem bate primeiro fica no topo da lista de contribuição."));
  } else {
    dados.top_contribuidores.forEach((cont, idx) => {
      const medalha = idx === 0 ? " top-1" : idx === 1 ? " top-2" : idx === 2 ? " top-3" : "";
      const linha = el("div", `cartao-item ranking-linha${medalha}`);
      linha.appendChild(el("div", "ranking-posicao", idx < 3 ? ["🥇", "🥈", "🥉"][idx] : `#${idx + 1}`));
      const info = el("div", "cartao-item-info");
      info.appendChild(el("div", "cartao-item-nome", cont.nome));
      info.appendChild(el("div", "cartao-item-bonus", `${cont.pct}% do dano total`));
      linha.append(info, el("div", "ranking-valor", cont.dano.toLocaleString("pt-BR")));
      c.appendChild(linha);
    });
  }
}

let ULTIMA_BATALHA_BOSS = null;

async function acaoBatalhaAutomaticaBoss(botao) {
  botao.disabled = true; botao.textContent = "⚔️ Lutando...";
  try {
    const r = await api("/api/global_boss/auto", { method: "POST" });
    ULTIMA_BATALHA_BOSS = r;
    if (r.fim === "matou") { som.vitoria(); notificacaoGrande("🐲", "O boss caiu!", "Seu golpe fechou a luta"); }
    else if (r.fim === "morreu") { som.erro(); }
    else som.clique();
    await renderBossGlobal();
  } catch (e) {
    som.erro(); if (!e.jaAlertado) toast(e.message, true);
    botao.disabled = false; botao.textContent = "⚙️ Batalha automática";
  }
}

function resultadoBatalhaBoss(r) {
  const box = el("div", "boss-global-resultado");
  const titulo = r.fim === "matou" ? "🏆 Você derrubou o boss!"
    : r.fim === "morreu" ? "💀 Você caiu na luta" : "⏳ A luta chegou ao limite de trocas";
  box.appendChild(el("div", "boss-global-resultado-titulo", titulo));
  box.appendChild(el("div", "texto-fraco",
    `${r.trocas} troca(s) de golpes · vida ${r.hp_inicio.toLocaleString("pt-BR")} → ${r.hp_fim.toLocaleString("pt-BR")}`));
  if (r.dano != null) box.appendChild(el("div", "boss-global-resultado-dano", `⚔️ ${r.dano.toLocaleString("pt-BR")} de dano no boss`));
  if (r.log) {
    const log = el("div", "log-combate");
    log.textContent = r.log.replace(/<[^>]+>/g, "");
    box.appendChild(log);
  }
  return box;
}

// (acaoAtacarBossGlobal/acaoFugirBossGlobal saíram em 25/09: a luta virou
// automática. As rotas /attack e /flee continuam no servidor.)

// =============================================================================
// 🏆 ARENA PvP (contra cópia salva de outro jogador)
// =============================================================================
async function renderArena() {
  const dados = await api("/api/arena");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  if (!dados.cadastrado) {
    const box = el("div", "em-construcao");
    box.appendChild(el("div", "em-construcao-icone", "🏆"));
    box.appendChild(el("p", "", "Cadastre seu personagem na Arena pra poder desafiar outros jogadores."));
    const btn = document.createElement("button");
    btn.className = "botao-holofote"; btn.textContent = "✅ Cadastrar na Arena";
    btn.onclick = async () => {
      const r = await api("/api/arena/register", { method: "POST" });
      som.clique(); toast(r.msg.replace(/<[^>]+>/g, "")); await renderArena();
    };
    box.appendChild(btn);
    c.appendChild(box);
    return;
  }

  // 📅 se a semana acabou de fechar bem na hora que a tela abriu, avisa
  if (dados.semana_fechou_agora) {
    notificacaoGrande("📅", "Semana fechou!", "Confira o ranking — as estrelas já caíram na sua conta");
  }

  // painel de contagem regressiva + preview de recompensa por posição
  const painelSemana = el("div", "gold-panel");
  painelSemana.style.marginBottom = "14px";
  const restanteTxt = formatarContagem(dados.semana_restante_seg);
  painelSemana.appendChild(el("div", "arena-semana-titulo", `📅 Ranking fecha em ${restanteTxt}`));
  const faixasLinha = el("div", "arena-semana-faixas");
  for (const f of (dados.faixas_premiacao || []).slice(0, 5)) {
    const rotulo = { 1: "🥇", 2: "🥈", 3: "🥉" }[f.posicao] || `Top ${f.posicao}`;
    faixasLinha.appendChild(el("div", "arena-semana-faixa", `${rotulo} ${f.estrelas.toLocaleString("pt-BR")}⭐`));
  }
  painelSemana.appendChild(faixasLinha);
  c.appendChild(painelSemana);

  c.appendChild(el("p", "texto-fraco", `🏆 Pontos: ${dados.pontos} · ✅ ${dados.vitorias} · ❌ ${dados.derrotas}`));

  const btnAtualizar = document.createElement("button");
  btnAtualizar.className = "botao-secundario";
  btnAtualizar.textContent = "🔄 Atualizar minha cópia";
  btnAtualizar.onclick = async () => {
    const r = await api("/api/arena/register", { method: "POST" });
    som.clique(); toast(r.msg.replace(/<[^>]+>/g, ""));
  };
  c.appendChild(btnAtualizar);

  // 🎲 25/09/2026 (dev): não se escolhe mais da lista — o jogo sorteia um
  // adversário com pontos perto dos seus e a luta começa.
  c.appendChild(botaoProcurarAdversario("/api/arena/buscar", (r) => {
    COMBATE_INICIO = null;
    ARENA_ESTADO_ANTERIOR = null;
    desenharArenaCombate(r);
  }));
}

function botaoProcurarAdversario(rota, aoAchar) {
  const b = document.createElement("button");
  b.className = "botao-holofote";
  b.style.cssText = "width:100%;margin-top:14px";
  b.textContent = "🎲 Procurar adversário";
  b.onclick = async () => {
    b.disabled = true; b.textContent = "Procurando...";
    try {
      const r = await api(rota, { method: "POST" });
      som.clique();
      aoAchar(r);
    } catch (e) {
      som.erro(); if (!e.jaAlertado) toast(e.message, true);
      b.disabled = false; b.textContent = "🎲 Procurar adversário";
    }
  };
  const box = el("div");
  box.appendChild(b);
  box.appendChild(el("p", "texto-fraco", "Sorteia alguém com pontos de arena perto dos seus."));
  return box;
}

async function iniciarLutaArena(opponentId) {
  try {
    const r = await api("/api/arena/fight", { method: "POST", body: JSON.stringify({ opponent_id: opponentId }) });
    som.clique();
    // Cronômetro e "quem apanhou" zeram a cada luta nova — senão a segunda
    // luta abriria com o tempo da primeira e um flash de dano fantasma.
    COMBATE_INICIO = null;
    ARENA_ESTADO_ANTERIOR = null;
    desenharArenaCombate(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

function desenharArenaCombate(dados) {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  protegerProgresso(!dados.finalizado);

  if (dados.finalizado) {
    pararCronometroCombate();
    COMBATE_INICIO = null;
    ARENA_ESTADO_ANTERIOR = null;
    if (dados.venceu) atualizarTopo({ gold: dados.gold }); // 🔥 recompensa de ouro da vitória
    const box = el("div", `em-construcao resultado-combate ${dados.venceu ? "resultado-vitoria" : "resultado-derrota"}`);
    box.appendChild(el("div", "em-construcao-icone", dados.venceu ? "🏆" : "💀"));
    box.appendChild(el("p", "", dados.venceu ? "Vitória!" : "Derrota..."));
    if (dados.venceu) box.appendChild(el("p", "texto-fraco", `+${dados.ouro_ganho}g · pontos ${dados.pontos_delta >= 0 ? "+" : ""}${dados.pontos_delta}`));
    else box.appendChild(el("p", "texto-fraco", `pontos ${dados.pontos_delta}`));
    const btnVoltar = document.createElement("button");
    btnVoltar.className = "botao-holofote"; btnVoltar.textContent = "Voltar";
    btnVoltar.onclick = renderArena;
    box.appendChild(btnVoltar);
    c.appendChild(box);
    if (dados.venceu) { som.vitoria(); } else { som.erro(); }
    return;
  }

  // 🏟️ 20/09/2026 — A ARENA USA O DESENHO DA BATALHA DA TORRE.
  // Antes eram duas barras de progresso empilhadas e um botão: a tela não
  // se parecia com nenhuma outra luta do jogo, e nada dizia de quem era a
  // vez nem quanto faltava pro próximo turno. Aqui são os MESMOS blocos da
  // Torre (`combate-vs`, `filaIniciativa`, `log-combate`, a grade de
  // skills), com uma diferença que é do modo e não do desenho: do outro
  // lado não tem monstro, tem a cópia de combate de outro jogador — com o
  // retrato da raça e do sexo dele.
  const you = dados.voce, op = dados.oponente;

  if (COMBATE_INICIO === null) COMBATE_INICIO = Date.now();
  iniciarCronometroCombate();
  c.appendChild(tituloDaLuta("Arena", op.nome));

  const voceAtingido = ARENA_ESTADO_ANTERIOR && you.hp < ARENA_ESTADO_ANTERIOR.voce;
  const opAtingido = ARENA_ESTADO_ANTERIOR && op.hp < ARENA_ESTADO_ANTERIOR.oponente;
  ARENA_ESTADO_ANTERIOR = { voce: you.hp, oponente: op.hp };

  const painel = el("div", "combate-vs");
  painel.append(
    ladoDoDuelo(you, "Você", true, voceAtingido),
    (() => {
      const meio = el("div", "combate-vs-meio");
      const cron = el("div", "combate-vs-timer");
      cron.id = "combate-cronometro"; cron.textContent = "0s";
      meio.appendChild(cron);
      return meio;
    })(),
    ladoDoDuelo(op, op.nome, false, opAtingido),
  );
  c.appendChild(painel);

  // A fila de turnos é a informação que faltava: contra outro jogador,
  // saber se dá tempo de guardar a skill pro próximo turno É a decisão.
  c.appendChild(filaIniciativa([
    { tipo: "jogador", icone: "⚔️", nome: "Você", rotulo: "V",
      imagemUrl: you.img_key ? urlImagem(you.img_key, 34) : null,
      bar: you.bar, spd: you.spd, morto: false },
    { tipo: "inimigo", icone: "🛡️", nome: op.nome, rotulo: "",
      imagemUrl: op.img_key ? urlImagem(op.img_key, 34) : null,
      bar: op.bar, spd: op.spd, morto: false },
  ]));

  if (dados.log) {
    const logBox = el("div", "log-combate");
    logBox.textContent = dados.log;
    c.appendChild(logBox);
  }

  const acoesGrid = el("div", "combate-acoes");
  const btnAtacar = document.createElement("button");
  btnAtacar.className = "botao-holofote"; btnAtacar.textContent = "⚔️ Atacar";
  btnAtacar.onclick = () => acaoArena(null);
  acoesGrid.appendChild(btnAtacar);
  c.appendChild(acoesGrid);

  if (dados.skills.length > 0) {
    c.appendChild(el("h3", "secao-titulo", "Skills"));
    const skillsGrid = el("div", "combate-acoes");
    for (const sk of dados.skills) {
      const btn = document.createElement("button");
      const pronta = sk.cooldown_restante <= 0;
      btn.className = "botao-secundario btn-skill-combate";   // o guia inicial aponta aqui
      botaoComEmblema(btn, sk.skill_id, pronta ? sk.nome : `${sk.nome} (${sk.cooldown_restante}t)`);
      btn.disabled = !pronta;
      btn.onclick = () => acaoArena(sk.skill_id);
      skillsGrid.appendChild(btn);
    }
    c.appendChild(skillsGrid);
  }
}

let ARENA_ESTADO_ANTERIOR = null;

/** Um lado do duelo, no mesmo formato da Torre: retrato, nome, vida e a
 *  barra de ATB. O estado (escudo, atordoado, veneno) fica embaixo do
 *  retrato porque é o que decide se vale gastar a skill agora. */
function ladoDoDuelo(lutador, nome, ehVoce, atingido) {
  const caixa = el("div", `combate-vs-lado ${ehVoce ? "jogador" : "inimigo"}${atingido ? " atingido" : ""}`);
  const retrato = el("div", "combate-vs-retrato");
  if (lutador.img_key) porFundo(retrato, urlImagem(lutador.img_key, 130));
  else retrato.textContent = ehVoce ? "⚔️" : "🛡️";
  caixa.appendChild(retrato);
  caixa.appendChild(el("div", "combate-vs-nome", nome));

  const hpPct = lutador.hp_max > 0 ? Math.max(0, Math.min(100, (lutador.hp / lutador.hp_max) * 100)) : 0;
  const hpWrap = el("div", "combate-vs-barra-wrap");
  const hpTrilho = el("div", "barra-trilho mini" + (atingido ? " flash-dano" : ""));
  const hpFill = el("div", `barra-preenchimento ${ehVoce ? "barra-hp" : "barra-inimigo"}`);
  hpFill.style.width = `${hpPct}%`;
  hpTrilho.appendChild(hpFill);
  hpWrap.append(hpTrilho, el("div", "barra-numero-mini", `${lutador.hp}/${lutador.hp_max}`));
  caixa.appendChild(hpWrap);

  const atbPct = Math.min(100, lutador.bar || 0);
  const atbWrap = el("div", "combate-vs-barra-wrap");
  const atbTrilho = el("div", "barra-trilho mini");
  const atbFill = el("div", "barra-preenchimento barra-atb");
  atbFill.style.width = `${atbPct}%`;
  atbTrilho.appendChild(atbFill);
  atbWrap.append(atbTrilho, el("div", "barra-numero-mini", `${Math.round(atbPct)}%`));
  caixa.appendChild(atbWrap);

  const marcas = el("div", "pet-luta-marcas");
  if (lutador.escudo > 0) marcas.appendChild(el("span", "marca-escudo", `🛡️${lutador.escudo}`));
  if (lutador.atordoado) marcas.appendChild(el("span", "marca-stun", "💫"));
  for (const d of (lutador.dots || [])) marcas.appendChild(el("span", "marca-dot", `☠️${d}`));
  if (marcas.childNodes.length) caixa.appendChild(marcas);
  return caixa;
}

async function acaoArena(skillId) {
  try {
    const r = await api("/api/arena/action", { method: "POST", body: JSON.stringify({ skill_id: skillId }) });
    som.clique();
    desenharArenaCombate(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

// =============================================================================
// 🐾 ARENA DOS PETS
// =============================================================================
async function renderArenaPets() {
  const dados = await api("/api/pet_arena");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  if (!dados.cadastrado) {
    const box = el("div", "em-construcao");
    box.appendChild(el("div", "em-construcao-icone", "🐾"));
    box.appendChild(el("p", "", "Cadastre seu esquadrão na Arena dos Pets."));
    const btn = document.createElement("button");
    btn.className = "botao-holofote"; btn.textContent = "✅ Cadastrar Esquadrão";
    btn.onclick = async () => {
      const r = await api("/api/pet_arena/register", { method: "POST" });
      som.clique(); toast(r.msg.replace(/<[^>]+>/g, "")); await renderArenaPets();
    };
    box.appendChild(btn);
    c.appendChild(box);
    return;
  }

  c.appendChild(el("p", "texto-fraco", `🏆 Pontos: ${dados.pontos} · ✅ ${dados.vitorias} · ❌ ${dados.derrotas}`));

  const btnAtualizar = document.createElement("button");
  btnAtualizar.className = "botao-secundario";
  btnAtualizar.textContent = "🔄 Atualizar Esquadrão";
  btnAtualizar.onclick = async () => {
    const r = await api("/api/pet_arena/register", { method: "POST" });
    som.clique(); toast(r.msg.replace(/<[^>]+>/g, ""));
  };
  c.appendChild(btnAtualizar);

  c.appendChild(botaoProcurarAdversario("/api/pet_arena/buscar", (r) => desenharArenaPetsCombate(r)));
}

async function iniciarLutaArenaPets(opponentId) {
  try {
    const r = await api("/api/pet_arena/fight", { method: "POST", body: JSON.stringify({ opponent_id: opponentId }) });
    som.clique();
    desenharArenaPetsCombate(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}



/** O banco: os espíritos que ainda não entraram (ou já caíram), na mesma
 *  fileira compacta que a Torre usa pros inimigos. Quem está em campo
 *  aparece marcado — ele já está grande no painel de cima, aqui é só pra
 *  contar quantos faltam. */
// 25/09/2026: `opcoes.rival` põe a aura vermelha nos quadrados do time
// rival; `opcoes.aoTrocar(idx)` deixa tocar num pet do SEU banco pra trocar.
function fileiraDoBanco(lista, ativoIdx, opcoes = {}) {
  const fileira = el("div", `fileira-inimigos banco-pets${opcoes.rival ? " rival" : " meu"}`);
  (lista || []).forEach((pet, idx) => {
    const podeTrocar = !!opcoes.aoTrocar && pet.hp > 0 && idx !== ativoIdx;
    const ficha = el("div", `banco-pet${pet.hp <= 0 ? " morto" : ""}${idx === ativoIdx ? " em-campo" : ""}${podeTrocar ? " pode-trocar" : ""}`);
    if (podeTrocar) ficha.onclick = () => opcoes.aoTrocar(idx, pet);
    const arte = el("div", "banco-pet-arte");
    if (pet.img_key) porFundo(arte, urlImagem(pet.img_key, 52));
    else arte.textContent = "🐾";
    ficha.appendChild(arte);
    const pct = pet.hp_max > 0 ? (pet.hp / pet.hp_max) * 100 : 0;
    const trilho = el("div", "barra-trilho mini");
    const preench = el("div", "barra-preenchimento barra-hp");
    preench.style.width = `${pct}%`;
    trilho.appendChild(preench);
    ficha.appendChild(trilho);
    ficha.title = `${pet.nome} — ${pet.hp}/${pet.hp_max}`;
    fileira.appendChild(ficha);
  });
  return fileira;
}

function desenharArenaPetsCombate(dados) {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  protegerProgresso(!dados.finalizado);

  if (dados.finalizado) {
    const venceu = dados.resultado === "vitoria";
    const box = el("div", `em-construcao resultado-combate ${venceu ? "resultado-vitoria" : "resultado-derrota"}`);
    box.appendChild(el("div", "em-construcao-icone", venceu ? "🏆" : "💀"));
    box.appendChild(el("p", "", venceu ? "Vitória!" : "Derrota..."));
    box.appendChild(el("p", "texto-fraco", `pontos ${dados.pontos_delta >= 0 ? "+" : ""}${dados.pontos_delta}`));
    const btnVoltar = document.createElement("button");
    btnVoltar.className = "botao-holofote"; btnVoltar.textContent = "Voltar";
    btnVoltar.onclick = renderArenaPets;
    box.appendChild(btnVoltar);
    c.appendChild(box);
    if (venceu) { som.vitoria(); } else { som.erro(); }
    return;
  }

  // 🥊 Mesmo desenho da Raid e da Torre: título, painel VS com os dois em
  // campo, fila de próximos turnos, e o esquadrão embaixo como banco. A
  // tela própria que a Arena de Pets tinha (dez cartões do mesmo tamanho)
  // fazia a luta parecer cinco contra cinco e não dizia de quem era a vez.
  if (COMBATE_INICIO === null) COMBATE_INICIO = Date.now();
  iniciarCronometroCombate();

  const meu = dados.seu_time[dados.meu_ativo];
  const rival = dados.time_inimigo[dados.rival_ativo];
  c.appendChild(tituloDaLuta("Arena dos Pets", rival ? rival.nome : ""));

  // 🥊 de cima pra baixo — os dois em campo GRANDES lado a lado, os seus 5
  // (toque pra trocar), as ações e, embaixo delas, os 5 do rival (26/09).

  const painel = el("div", "combate-vs vs-pets");
  const meio = el("div", "combate-vs-meio");
  const cron = el("div", "combate-vs-timer");
  cron.id = "combate-cronometro"; cron.textContent = "0s";
  meio.appendChild(cron);
  painel.append(
    ladoDoDuelo(meu, meu ? meu.nome : "—", true, false),
    meio,
    ladoDoDuelo(rival, rival ? rival.nome : "—", false, false),
  );
  c.appendChild(painel);

  if (meu && rival) {
    c.appendChild(filaIniciativa([
      { tipo: "jogador", icone: "🐾", nome: meu.nome, rotulo: "",
        imagemUrl: meu.img_key ? urlImagem(meu.img_key, 34) : null,
        bar: meu.bar, spd: meu.spd, morto: false },
      { tipo: "inimigo", icone: "🐾", nome: rival.nome, rotulo: "",
        imagemUrl: rival.img_key ? urlImagem(rival.img_key, 34) : null,
        bar: rival.bar, spd: rival.spd, morto: false },
    ]));
  }

  // O seu banco. Na sua vez, tocar num pet vivo que está fora TROCA — e
  // gasta o turno: ele entra com a barra zerada e age no próximo.
  const suaVez = dados.acting_idx !== null;
  c.appendChild(el("h3", "secao-titulo", "Seu Esquadrão"));
  c.appendChild(fileiraDoBanco(dados.seu_time, dados.meu_ativo,
    suaVez ? { aoTrocar: trocarPetArena } : {}));
  if (suaVez) c.appendChild(el("p", "texto-fraco dica-troca", "🔁 Toque num espírito pra trocar — gasta o turno."));

  if (dados.acting_idx !== null) {
    // 🎯 20/09/2026 — AS 4 OPÇÕES.
    // Antes eram dois botões ("ataque normal" / "liberar skill") e o alvo
    // virava a ação: o jogador escolhia um modo e tocava num inimigo.
    // Agora cada pet leva 4 ações do arquétipo dele, e a AÇÃO vem
    // primeiro, porque é ela que decide se existe alvo pra escolher —
    // cura, escudo e buff não miram ninguém.
    const pet = dados.seu_time[dados.acting_idx];
    c.appendChild(el("h3", "secao-titulo", `Vez de ${pet.nome}`));
    const grade = el("div", "combate-acoes acoes-pet");
    for (const acao of (pet.acoes || [])) {
      const btn = document.createElement("button");
      const escolhida = ARENA_PETS_ACAO === acao.id;
      btn.className = escolhida ? "botao-holofote acao-pet" : "botao-secundario acao-pet";
      btn.disabled = !acao.pronta;
      const recarga = acao.pronta
        ? (acao.recarga ? `recarga ${acao.recarga}t` : "sem recarga")
        : `volta em ${acao.recarga_restante}t`;
      btn.innerHTML = "";
      btn.appendChild(el("span", "acao-pet-nome", `${acao.icone} ${acao.nome}`));
      btn.appendChild(el("span", "acao-pet-sub", acao.descricao || ""));
      btn.appendChild(el("span", "acao-pet-cd", recarga));
      // Toque resolve o turno na hora. Num 1x1 não existe alvo pra
      // escolher — o ataque vai em quem está em campo, e cura, escudo e
      // buff nunca miraram ninguém. Pedir um segundo toque seria pedir
      // uma decisão que não existe.
      btn.onclick = () => {
        ARENA_PETS_ACAO = acao.id;
        som.clique();
        escolherAlvoArenaPets(0);
      };
      grade.appendChild(btn);
    }
    c.appendChild(grade);
    c.appendChild(el("p", "texto-fraco",
      "Escolha a ação do turno. O ataque vai em quem está em campo."));
  }

  // 👹 26/09/2026 (dev): o time rival (aura vermelha) fica ABAIXO dos
  // botões de batalha, como a linha de inimigos em todos os modos
  c.appendChild(el("h3", "secao-titulo", "Time Rival"));
  c.appendChild(fileiraDoBanco(dados.time_inimigo, dados.rival_ativo, { rival: true }));

  if (dados.log) {
    const logBox = el("div", "log-combate");
    logBox.textContent = dados.log;
    c.appendChild(logBox);
  }
}

async function trocarPetArena(idx, pet) {
  if (!confirm(`Trocar por ${pet.nome}? A troca gasta o turno: ele entra agora e age no próximo.`)) return;
  try {
    const r = await api("/api/pet_arena/action", {
      method: "POST", body: JSON.stringify({ target_idx: 0, trocar_para: idx }) });
    ARENA_PETS_ACAO = null;
    som.clique();
    desenharArenaPetsCombate(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

let ARENA_PETS_ACAO = null;

async function escolherAlvoArenaPets(idx) {
  try {
    const r = await api("/api/pet_arena/action", {
      method: "POST",
      body: JSON.stringify({ target_idx: idx, skill_id: ARENA_PETS_ACAO }),
    });
    ARENA_PETS_ACAO = null;
    som.clique();
    desenharArenaPetsCombate(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}


// =============================================================================
// ⚔️ RAID (multiplayer real — consulta o servidor periodicamente enquanto
// espera a vez ou espera os outros jogadores, já que não dá pra "empurrar"
// atualização sem WebSocket)
// =============================================================================
let RAID_POLLING_TIMER = null;

function pararPollingRaid() {
  if (RAID_POLLING_TIMER) { clearInterval(RAID_POLLING_TIMER); RAID_POLLING_TIMER = null; }
}
function iniciarPollingRaid(fn, ms = 3000) {
  pararPollingRaid();
  RAID_POLLING_TIMER = setInterval(fn, ms);
}

async function renderRaid() {
  pararCronometroRaid(); // reseta em toda entrada fresca — desenharCombateRaidComSnapshot religa se ainda estiver em combate
  const status = await api("/api/raid/status");
  if (!status.em_raid) {
    await desenharRaidMenu();
    return;
  }
  if (status.estado_jogador === "RAID_DOWN") {
    await desenharRaidCaido();
  } else if (status.estado_sala === "RAID_PVP") {
    await desenharRaidPvp();
  } else if (status.estado_sala === "RAID_COMBAT") {
    await desenharRaidCombate();
  } else {
    await desenharRaidLobby();
  }
}

async function desenharRaidMenu() {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  c.appendChild(el("h3", "secao-titulo", "Raid"));
  c.appendChild(el("p", "texto-fraco", "Crie uma sala nova ou entre numa existente pelo número dela."));

  const btnCriar = document.createElement("button");
  btnCriar.className = "botao-holofote";
  btnCriar.textContent = "➕ Criar Sala";
  btnCriar.onclick = async () => {
    const r = await api("/api/raid/join", { method: "POST", body: JSON.stringify({}) });
    som.clique(); toast(r.msg);
    await renderRaid();
  };
  c.appendChild(btnCriar);

  const inputSala = document.createElement("input");
  inputSala.type = "number"; inputSala.placeholder = "Número da sala";
  inputSala.className = "sheet-input";
  c.appendChild(inputSala);

  const btnEntrar = document.createElement("button");
  btnEntrar.className = "botao-secundario";
  btnEntrar.textContent = "🔑 Entrar por número";
  btnEntrar.onclick = async () => {
    const roomId = parseInt(inputSala.value, 10);
    if (!roomId) { toast("Digite um número de sala válido.", true); return; }
    try {
      const r = await api("/api/raid/join", { method: "POST", body: JSON.stringify({ room_id: roomId }) });
      som.clique(); toast(r.msg.replace(/<[^>]+>/g, ""));
      await renderRaid();
    } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
  };
  c.appendChild(btnEntrar);

  c.appendChild(el("h3", "secao-titulo", "Salas Abertas"));
  const dados = await api("/api/raid/rooms");
  if (dados.salas.length === 0) c.appendChild(estadoVazio("🚪", "Nenhuma sala aberta agora. Crie a sua!"));
  for (const sala of dados.salas) {
    const card = el("div", "cartao-item");
    const info = el("div", "cartao-item-info");
    info.appendChild(el("div", "cartao-item-nome", `Sala #${sala.room_id} — Andar ${sala.andar}`));
    info.appendChild(el("div", "cartao-item-bonus", `👥 ${sala.membros}/${sala.max_membros}`));
    const btn = document.createElement("button");
    btn.className = "botao-secundario"; btn.textContent = "Entrar";
    btn.onclick = async () => {
      const r = await api("/api/raid/join", { method: "POST", body: JSON.stringify({ room_id: sala.room_id }) });
      som.clique(); toast(r.msg.replace(/<[^>]+>/g, ""));
      await renderRaid();
    };
    card.append(info, btn);
    c.appendChild(card);
  }
}

async function desenharRaidLobby() {
  const dados = await api("/api/raid/lobby");
  const c = document.getElementById("conteudo");
  c.innerHTML = "";

  c.appendChild(el("h3", "secao-titulo", `Sala #${dados.room_id} — Andar ${dados.andar}`));
  if (dados.senha) c.appendChild(el("p", "texto-fraco", `🔑 Senha: ${dados.senha} (compartilhe com quem quiser convidar)`));

  for (const m of dados.membros) {
    const card = el("div", `cartao-item${m.eh_voce ? " voce" : ""}`);
    card.appendChild(el("div", "cartao-item-nome", `${m.eh_voce ? "👉 " : ""}${m.pid}${m.eh_voce ? " (você)" : ""}`));
    card.appendChild(el("div", `cartao-item-bonus status-membro${m.pronto ? " pronto" : ""}`, m.pronto ? "✅ Pronto" : "⏳ Aguardando"));
    c.appendChild(card);
  }

  const acoes = el("div", "combate-acoes");
  if (dados.eh_lider) {
    const btnAbrir = document.createElement("button");
    btnAbrir.className = "botao-secundario";
    btnAbrir.textContent = dados.aberto ? "🔒 Fechar Sala" : "🔓 Abrir Sala";
    btnAbrir.onclick = async () => {
      await api("/api/raid/toggle_open", { method: "POST", body: JSON.stringify({ aberto: !dados.aberto }) });
      som.clique(); await desenharRaidLobby();
    };
    acoes.appendChild(btnAbrir);
  }
  const btnPronto = document.createElement("button");
  btnPronto.className = "botao-holofote"; btnPronto.textContent = "✅ Estou Pronto";
  btnPronto.onclick = async () => {
    await api("/api/raid/ready", { method: "POST", body: JSON.stringify({ pronto: true }) });
    som.clique();
    await renderRaid();
  };
  acoes.appendChild(btnPronto);
  c.appendChild(acoes);

  const btnSair = document.createElement("button");
  btnSair.className = "botao-secundario";
  btnSair.textContent = "🚪 Sair da Sala";
  btnSair.onclick = async () => {
    const r = await api("/api/raid/leave", { method: "POST" });
    som.clique(); toast(r.msg.replace(/<[^>]+>/g, ""));
    pararPollingRaid();
    await renderRaid();
  };
  c.appendChild(btnSair);

  // fica de olho se todo mundo ficou pronto e a luta começou
  iniciarPollingRaid(async () => {
    const status = await api("/api/raid/status");
    if (status.estado_sala === "RAID_COMBAT" || status.estado_jogador === "RAID_COMBAT") {
      pararPollingRaid();
      await renderRaid();
    } else {
      await desenharRaidLobby();
    }
  }, 3000);
}

async function desenharRaidCombate() {
  const dados = await api("/api/raid/combat");
  desenharCombateRaidComSnapshot(dados);
}

let ESTADO_RAID_ANTERIOR = null;
let RAID_COMBATE_INICIO = null;
let RAID_TIMER_INTERVAL = null;
function iniciarCronometroRaid() {
  if (RAID_TIMER_INTERVAL) return;
  RAID_TIMER_INTERVAL = setInterval(atualizarCronometroRaid, 1000);
}
function pararCronometroRaid() {
  if (RAID_TIMER_INTERVAL) { clearInterval(RAID_TIMER_INTERVAL); RAID_TIMER_INTERVAL = null; }
  RAID_COMBATE_INICIO = null;
}
function atualizarCronometroRaid() {
  const alvo = document.getElementById("raid-cronometro");
  if (!alvo || !RAID_COMBATE_INICIO) return;
  const seg = Math.floor((Date.now() - RAID_COMBATE_INICIO) / 1000);
  const m = Math.floor(seg / 60), s = seg % 60;
  alvo.textContent = m > 0 ? `${m}m${String(s).padStart(2, "0")}s` : `${s}s`;
}

function desenharCombateRaidComSnapshot(dados) {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  protegerProgresso(!!dados.em_combate);
  // A trava acompanha o snapshot: acabou o combate, libera sozinha. Não
  // pode depender de uma tela de vitória, senão desconexão deixa o jogador
  // preso na aba da raid pra sempre.
  RAID_EM_COMBATE = !!dados.em_combate;

  if (!dados.em_combate) {
    pararPollingRaid();
    if (dados.sala_estado === "RAID_PVP") {
      // 🗡️ acabou de virar a fase de traição — vai direto pra lá, sem
      // precisar de um clique a mais
      toast("Os monstros caíram! Algo se move nas sombras...");
      desenharRaidPvp();
      return;
    }
    const box = el("div", "em-construcao");
    box.appendChild(el("div", "em-construcao-icone", "🏁"));
    box.appendChild(el("p", "", "A batalha contra os monstros terminou."));
    const btn = document.createElement("button");
    btn.className = "botao-holofote"; btn.textContent = "Voltar"; btn.onclick = renderRaid;
    box.appendChild(btn);
    c.appendChild(box);
    pararCronometroRaid();
    return;
  }

  if (RAID_COMBATE_INICIO === null) RAID_COMBATE_INICIO = Date.now();
  iniciarCronometroRaid();

  // painel VS — você vs. o alvo que você escolheu no grupo de inimigos
  const alvoAtual = dados.inimigos?.find((i) => i.idx === dados.meu_alvo) || dados.inimigos?.[0];
  const meuHpPct = dados.meu_hp_max > 0 ? Math.max(0, Math.min(100, (dados.meu_hp / dados.meu_hp_max) * 100)) : 0;
  const meuBarPct = Math.min(100, dados.meu_bar || 0);
  const alvoPct = alvoAtual && alvoAtual.hp_max > 0 ? Math.max(0, Math.min(100, (alvoAtual.hp / alvoAtual.hp_max) * 100)) : 0;
  const meuAntesHp = ESTADO_RAID_ANTERIOR?.jogadores?.[dados.jogadores.find((j) => j.eh_voce)?.pid];
  const euAtingido = meuAntesHp !== undefined && dados.meu_hp < meuAntesHp;
  const alvoAntesHp = alvoAtual ? ESTADO_RAID_ANTERIOR?.inimigos?.[alvoAtual.idx] : undefined;
  const alvoAtingido = alvoAntesHp !== undefined && alvoAtual && alvoAtual.hp < alvoAntesHp;

  // Só "Raid": conferido, /api/raid/combat não devolve nem número de sala
  // nem andar. Inventar campo aqui daria "Andar undefined" no primeiro dia
  // em que alguém mexesse no ternário.
  c.appendChild(tituloDaLuta("Raid"));

  const painel = el("div", "combate-vs");

  const ladoJogador = el("div", "combate-vs-lado jogador");
  // O jogador é representado pela arte de STATUS, como no resto do jogo —
  // era o único lugar que ainda mostrava um emoji de espadas.
  const retratoJogador = el("div", "combate-vs-retrato");
  // 130 é o teto do CSS; urlImagem dobra sozinha pra retina.
  if (IMG_JOGADOR) porFundo(retratoJogador, urlImagem(IMG_JOGADOR, 130));
  else retratoJogador.textContent = "⚔️";
  ladoJogador.appendChild(retratoJogador);
  ladoJogador.appendChild(el("div", "combate-vs-nome", "Você"));
  const hpWrapJ = el("div", "combate-vs-barra-wrap");
  const hpTrilhoJ = el("div", "barra-trilho mini" + (euAtingido ? " flash-dano" : ""));
  hpTrilhoJ.appendChild(el("div", "barra-preenchimento barra-hp", "")); hpTrilhoJ.firstChild.style.width = `${meuHpPct}%`;
  hpWrapJ.append(hpTrilhoJ, el("div", "barra-numero-mini", `${dados.meu_hp}/${dados.meu_hp_max}`));
  const atbWrapJ = el("div", "combate-vs-barra-wrap");
  const atbTrilhoJ = el("div", "barra-trilho mini");
  atbTrilhoJ.appendChild(el("div", "barra-preenchimento barra-atb", "")); atbTrilhoJ.firstChild.style.width = `${meuBarPct}%`;
  atbWrapJ.append(atbTrilhoJ, el("div", "barra-numero-mini", `${Math.round(meuBarPct)}%`));
  ladoJogador.append(hpWrapJ, atbWrapJ);

  const meio = el("div", "combate-vs-meio");

  const cronometro = el("div", "combate-vs-timer");
  cronometro.id = "raid-cronometro";
  cronometro.textContent = "0s";
  meio.appendChild(cronometro);

  const ladoInimigo = el("div", "combate-vs-lado inimigo" + (alvoAtingido ? " atingido" : ""));
  const retratoInimigo = el("div", "combate-vs-retrato");
  retratoInimigo.style.backgroundImage = `url(${urlImagem(alvoAtual?.img_key || "RAID")})`;
  ladoInimigo.appendChild(retratoInimigo);
  ladoInimigo.appendChild(el("div", "combate-vs-nome", alvoAtual ? alvoAtual.nome : "—"));
  const hpWrapI = el("div", "combate-vs-barra-wrap");
  const hpTrilhoI = el("div", "barra-trilho mini" + (alvoAtingido ? " flash-dano" : ""));
  hpTrilhoI.appendChild(el("div", "barra-preenchimento barra-inimigo", "")); hpTrilhoI.firstChild.style.width = `${alvoPct}%`;
  hpWrapI.append(hpTrilhoI, el("div", "barra-numero-mini", alvoAtual ? `${alvoAtual.hp}/${alvoAtual.hp_max}` : "—"));
  ladoInimigo.appendChild(hpWrapI);

  painel.append(ladoJogador, meio, ladoInimigo);
  c.appendChild(painel);

  c.appendChild(el("h3", "secao-titulo", "Grupo"));
  const jogadoresVivos = dados.jogadores.filter((j) => !j.morto).map((j) => ({ tipo: "jogador", icone: j.eh_voce ? "⚔️" : "🛡️", bar: j.bar || 0, morto: false }));
  // Fila dos próximos turnos, igual à Torre — agora com os INIMIGOS junto.
  // Antes ela listava só os jogadores vivos, o que respondia "quem do grupo
  // age primeiro" e escondia justamente o que decide a raid: quantas vezes
  // o chefe bate antes de você.
  const LETRAS_RAID = "ABCDEFGH";
  const naFila = [
    ...dados.jogadores.filter((j) => !j.morto).map((j) => ({
      tipo: "jogador", icone: j.eh_voce ? "⚔️" : "🛡️", nome: j.nome,
      rotulo: j.eh_voce ? "V" : "", bar: j.bar || 0, spd: j.spd, morto: false,
    })),
    ...dados.inimigos.filter((i) => i.hp > 0).map((ini) => ({
      tipo: "inimigo", icone: "👹", nome: ini.nome,
      rotulo: dados.inimigos.length > 1 ? (LETRAS_RAID[ini.idx] || String(ini.idx + 1)) : "",
      imagemUrl: ini.img_key ? urlImagem(ini.img_key, 34) : null,
      bar: ini.bar || 0, spd: ini.spd, morto: false,
    })),
  ];
  if (naFila.length > 1) c.appendChild(filaIniciativa(naFila));
  const gradeGrupo = el("div", "grade-combatentes");
  for (const j of dados.jogadores) {
    const antesJ = ESTADO_RAID_ANTERIOR?.jogadores?.[j.pid];
    const atingidoJ = antesJ !== undefined && j.hp < antesJ;
    gradeGrupo.appendChild(quadradoCombatente({
      tipo: "jogador", icone: j.eh_voce ? "⚔️" : "🛡️",
      nome: `${j.nome}${j.eh_voce ? " (você)" : ""}`, hp: j.hp, hpMax: j.hp_max,
      selecionado: j.eh_voce, atingido: atingidoJ, morto: j.morto,
    }));
  }
  c.appendChild(gradeGrupo);


  if (dados.logs && dados.logs.length > 0) {
    const logBox = el("div", "log-combate");
    logBox.textContent = dados.logs.join(" · ");
    c.appendChild(logBox);
  }

  const prontoPraAgir = dados.meu_bar >= 100;
  if (prontoPraAgir) {
    c.appendChild(el("p", "texto-fraco", "🎯 Sua vez! Ataque, use uma skill, ou toque num inimigo aqui embaixo:"));
    const acoesGrid = el("div", "combate-acoes");
    const btnAtacar = document.createElement("button");
    btnAtacar.className = "botao-holofote"; btnAtacar.textContent = "⚔️ Ataque Normal";
    btnAtacar.onclick = () => acaoRaidAtacar();
    acoesGrid.appendChild(btnAtacar);
    c.appendChild(acoesGrid);

    if (dados.skills.length > 0) {
      const skillsGrid = el("div", "combate-acoes");
      for (const sk of dados.skills) {
        const btn = document.createElement("button");
        const pronta = sk.cooldown_restante <= 0;
        btn.className = "botao-secundario";
        botaoComEmblema(btn, sk.skill_id, pronta ? `${sk.nome}${sk.suporte ? " 💚" : ""}` : `${sk.nome} (${sk.cooldown_restante}t)`);
        btn.disabled = !pronta;
        btn.onclick = () => acaoRaidSkill(sk.skill_id, sk.suporte, dados.jogadores);
        skillsGrid.appendChild(btn);
      }
      c.appendChild(skillsGrid);
    }
  } else {
    c.appendChild(el("p", "texto-fraco", `⏳ Aguardando... (${Math.round(dados.meu_bar)}%)`));
  }

  // 👹 26/09: inimigos abaixo dos botões de batalha (como em todos os modos)
  // Mesma fileira de 5 por linha da Torre: arte grande, nome e a barra de
  // vida embaixo de cada um, em vez do quadradinho de 30px.
  c.appendChild(el("h3", "secao-titulo", "Inimigos"));
  const fileiraRaid = el("div", "fileira-inimigos");
  dados.inimigos.forEach((ini) => {
    if (ini.hp <= 0) return;
    const antesI = ESTADO_RAID_ANTERIOR?.inimigos?.[ini.idx];
    const atingidoI = antesI !== undefined && ini.hp < antesI;
    fileiraRaid.appendChild(fichaInimigo({
      icone: "👹",
      tag: dados.inimigos.length > 1 ? (LETRAS_RAID[ini.idx] || String(ini.idx + 1)) : "",
      imagemUrl: ini.img_key ? urlImagem(ini.img_key, 64) : null,
      nome: ini.nome, hp: ini.hp, hpMax: ini.hp_max,
      selecionado: ini.idx === dados.meu_alvo, atingido: atingidoI,
      onClick: () => acaoRaidAlvo(ini.idx),
    }));
  });
  c.appendChild(fileiraRaid);

  ESTADO_RAID_ANTERIOR = {
    jogadores: Object.fromEntries(dados.jogadores.map((j) => [j.pid, j.hp])),
    inimigos: Object.fromEntries(dados.inimigos.map((i) => [i.idx, i.hp])),
  };

  // 🗡️ opção discreta de traição — fica sempre disponível durante o
  // combate contra os monstros, mas escondida atrás de um toque a mais
  // pra não ficar gritando "aqui, escolha entre bem e mal" toda hora
  const linhaTraicao = el("div", "traicao-linha");
  const btnTraicao = document.createElement("button");
  btnTraicao.className = "botao-traicao";
  btnTraicao.textContent = "🗡️ Traição (secreto)";
  btnTraicao.onclick = () => abrirSheetTraicao();
  linhaTraicao.appendChild(btnTraicao);
  c.appendChild(linhaTraicao);

  iniciarPollingRaid(async () => { await desenharRaidCombate(); }, 2500);
}

function abrirSheetTraicao() {
  const corpo = el("div");
  corpo.appendChild(el("h3", "secao-titulo", "🗡️ Traição"));
  corpo.appendChild(el("p", "texto-fraco", "Sua escolha fica em segredo até os monstros serem derrotados. Se sobrar traidor vivo, vira uma luta interna — quem perde tem os itens quebrados ou divididos entre os traidores."));

  const btnTrair = document.createElement("button");
  btnTrair.className = "botao-secundario sheet-opcao";
  btnTrair.textContent = "🗡️ Trair a party";
  btnTrair.onclick = async () => {
    fecharSheet();
    const r = await api("/api/raid/betray", { method: "POST" });
    som.erro();
    toast(r.msg.replace(/<[^>]+>/g, ""));
  };
  const btnLeal = document.createElement("button");
  btnLeal.className = "botao-holofote sheet-opcao";
  btnLeal.textContent = "🤝 Continuar leal";
  btnLeal.onclick = async () => {
    fecharSheet();
    const r = await api("/api/raid/decline_betray", { method: "POST" });
    som.clique();
    toast(r.msg.replace(/<[^>]+>/g, ""));
  };
  corpo.append(btnTrair, btnLeal);
  abrirSheet(corpo);
}

// =============================================================================
// 🗡️ FASE DE PvP DA TRAIÇÃO
// =============================================================================
let ESTADO_PVP_ANTERIOR = null;

async function desenharRaidPvp() {
  const dados = await api("/api/raid/pvp");
  desenharPvpComSnapshot(dados);
}

function desenharPvpComSnapshot(dados) {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  protegerProgresso(!!dados.em_pvp);

  if (!dados.em_pvp) {
    pararPollingRaid();
    const box = el("div", "em-construcao");
    box.appendChild(el("div", "em-construcao-icone", "🏁"));
    box.appendChild(el("p", "", "A traição chegou ao fim."));
    const btn = document.createElement("button");
    btn.className = "botao-holofote"; btn.textContent = "Voltar"; btn.onclick = renderRaid;
    box.appendChild(btn);
    c.appendChild(box);
    return;
  }

  c.appendChild(el("h3", "secao-titulo", "⚔️ Só um lado sai vivo"));
  for (const j of dados.jogadores) {
    const antesJ = ESTADO_PVP_ANTERIOR?.[j.pid];
    const atingidoJ = antesJ !== undefined && j.hp < antesJ;
    const card = el("div", "cartao-inimigo" + (j.eh_voce ? " selecionado" : "") + (atingidoJ ? " flash-dano" : ""));
    card.onclick = () => { if (!j.eh_voce && !j.morto) acaoRaidPvpAtacar(j.pid); };
    const pct = j.hp_max > 0 ? (j.hp / j.hp_max) * 100 : 0;
    card.appendChild(el("div", "cartao-item-nome", `${j.nome}${j.eh_voce ? " (você)" : ""}${j.morto ? " 💀" : ""}`));
    const trilho = el("div", "barra-trilho mini");
    const preench = el("div", "barra-preenchimento barra-inimigo");
    preench.style.width = `${pct}%`;
    trilho.appendChild(preench);
    card.appendChild(trilho);
    card.appendChild(el("div", "barra-numero-mini", `${j.hp}/${j.hp_max}`));
    c.appendChild(card);
  }
  ESTADO_PVP_ANTERIOR = Object.fromEntries(dados.jogadores.map((j) => [j.pid, j.hp]));

  if (dados.logs && dados.logs.length > 0) {
    const logBox = el("div", "log-combate");
    logBox.textContent = dados.logs.join(" · ");
    c.appendChild(logBox);
  }

  c.appendChild(el("p", "texto-fraco", dados.meu_bar >= 100 ? "🎯 Sua vez! Toque num inimigo pra atacar." : `⏳ Aguardando... (${Math.round(dados.meu_bar)}%)`));

  iniciarPollingRaid(async () => { await desenharRaidPvp(); }, 2500);
}

async function acaoRaidPvpAtacar(targetPid) {
  try {
    const r = await api("/api/raid/pvp/attack", { method: "POST", body: JSON.stringify({ target_pid: targetPid }) });
    som.clique();
    if (!r.em_pvp) { pararPollingRaid(); som.erro(); }
    desenharPvpComSnapshot(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}


async function acaoRaidAlvo(idx) {
  try {
    await api("/api/raid/target", { method: "POST", body: JSON.stringify({ idx }) });
    som.clique();
    await acaoRaidAtacar();
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

async function acaoRaidAtacar() {
  try {
    const r = await api("/api/raid/attack", { method: "POST" });
    som.clique();
    if (!r.em_combate) { pararPollingRaid(); som.vitoria(); }
    desenharCombateRaidComSnapshot(r);
  } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
}

function acaoRaidSkill(skillId, suporte, jogadores) {
  if (suporte) {
    const corpo = el("div");
    corpo.appendChild(el("h3", "secao-titulo", "Em quem usar?"));
    for (const j of jogadores) {
      if (j.morto) continue;
      const btn = document.createElement("button");
      btn.className = "botao-secundario sheet-opcao";
      btn.textContent = `${j.nome}${j.eh_voce ? " (você)" : ""} — ${j.hp}/${j.hp_max}`;
      btn.onclick = async () => {
        fecharSheet();
        try {
          const r = await api("/api/raid/skill", { method: "POST", body: JSON.stringify({ skill_id: skillId, ally_target_pid: j.pid }) });
          som.moeda();
          desenharCombateRaidComSnapshot(r);
        } catch (e) { som.erro(); if (!e.jaAlertado) toast(e.message, true); }
      };
      corpo.appendChild(btn);
    }
    abrirSheet(corpo);
  } else {
    api("/api/raid/skill", { method: "POST", body: JSON.stringify({ skill_id: skillId }) })
      .then((r) => { som.clique(); desenharCombateRaidComSnapshot(r); })
      .catch((e) => { som.erro(); if (!e.jaAlertado) toast(e.message, true); });
  }
}



async function desenharRaidCaido() {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  const box = el("div", "em-construcao resultado-combate resultado-derrota");
  box.appendChild(el("div", "em-construcao-icone", "🩸"));
  box.appendChild(el("p", "", "Você caiu! Um curandeiro pode te reviver enquanto a batalha durar."));

  const acoes = el("div", "combate-acoes");
  const btnEsperar = document.createElement("button");
  btnEsperar.className = "botao-secundario"; btnEsperar.textContent = "⏳ Esperar Ressurreição";
  btnEsperar.onclick = async () => {
    const r = await api("/api/raid/wait_revive", { method: "POST" });
    if (r.revivido) { som.vitoria(); toast("Você foi trazido de volta!"); pararPollingRaid(); await renderRaid(); }
    else toast("Ainda no chão...");
  };
  const btnAceitar = document.createElement("button");
  btnAceitar.className = "botao-holofote"; btnAceitar.textContent = "☠️ Aceitar a Morte";
  btnAceitar.onclick = async () => {
    const r = await api("/api/raid/accept_death", { method: "POST" });
    som.erro(); toast(r.msg.replace(/<[^>]+>/g, ""));
    pararPollingRaid();
    await irPara("personagem");
  };
  acoes.append(btnEsperar, btnAceitar);
  box.appendChild(acoes);
  c.appendChild(box);

  iniciarPollingRaid(async () => {
    const r = await api("/api/raid/wait_revive", { method: "POST" });
    if (r.revivido) { pararPollingRaid(); som.vitoria(); toast("Você foi trazido de volta!"); await renderRaid(); }
  }, 3000);
}


// ---------- telas ainda não migradas (o que sobrou) ----------
function renderEmConstrucao(nomeTela) {
  const c = document.getElementById("conteudo");
  c.innerHTML = "";
  const box = el("div", "em-construcao");
  box.appendChild(el("div", "em-construcao-icone", "🚧"));
  box.appendChild(el("p", "", `"${nomeTela}" ainda não foi migrado pro Mini App.`));
  box.appendChild(el("p", "", "Por enquanto, use o bot no chat normal pra essa parte."));
  c.appendChild(box);
}

const TELAS = {
  personagem: renderPersonagem,
  perfil_jogador: renderPerfilJogador,     // 👤 (28/09) ficha de outro jogador
  skills: renderSkills,
  pets: renderPets,
  inventario: renderInventario,
  especialidade: renderEspecialidade,
  torre: renderTorre,
  explorar: renderExplorar,
  onda: renderOnda,
  missoes: renderMissoes,
  raid: renderRaid,
  party: renderRaid,
  boss_global: renderBossGlobal,
  arena: renderArena,
  arena_pets: renderArenaPets,
  clan: renderClan,
  clan_postos: renderClanPostos,
  clan_historico: renderClanHistorico,
  clan_ferreiro: renderClanFerreiro,
  clan_equipe: renderClanEquipe,
  clan_reliquias: renderClanReliquias,
  jornada: renderJornada,
  situacoes: renderSituacoes,
  conta: renderConta,
  personagens: renderPersonagens,
  mercado_personagens: renderMercadoPersonagens,
  trilhas: renderTrilhas,
  ajuda: renderAjuda,
  hospital: renderHospital,
  loja: renderLoja,
  loja_premium: renderLojaPremium,
  forja: renderForja,
  fusao: renderFusao,
  engaste: renderEngaste,
  gacha: renderGacha,
  estabulo: renderEstabulo,
  mercado: renderMercado,
  ranking: renderRanking,
};

async function irPara(tela) {
  // 🔒 luta de Exploração/Onda em andamento: não deixa "fugir" pro menu.
  // Vencer, morrer ou fugir (só a Onda permite) são as únicas saídas —
  // navegar embora escondendo o combate não é uma delas.
  if (EXPLORANDO_ATIVO || ONDA_ATIVA || RAID_EM_COMBATE) {
    som.erro();
    toast(EXPLORANDO_ATIVO
      ? "Termine essa batalha primeiro — não existe fuga aqui fora!"
      : RAID_EM_COMBATE
        ? "A raid está em andamento. Sair agora deixaria o grupo com um alvo que não age."
        : "Termine essa batalha primeiro (ou fuja) antes de sair.", true);
    return;
  }
  som.clique();
  pararPollingRaid(); // 🔥 sai de qualquer outra tela: para de consultar a raid
  pararPollingBossGlobal(); // idem pro boss global compartilhado
  pararCronometroCombate(); // idem pro cronômetro de combate da Torre
  pararCronometroRaid(); // idem pro cronômetro de combate do Raid
  EXPLORANDO_ATIVO = false; // evita vazar o contexto de exploração pra outra tela
  ONDA_ATIVA = false; // idem pra Onda de Bosses
  RAID_EM_COMBATE = false; // a tela da raid religa sozinha se ainda estiver em combate
  protegerProgresso(false); // telas de combate religam sozinhas se ainda estiverem em combate
  TELA_ATUAL = tela;
  mostrarEsqueleto();
  try {
    await TELAS[tela]();
    // 🖼️ 26/09/2026 (dev): a imagem do cabeçalho NÃO aparece nas batalhas
    // (Torre, Explorar, Onda, Raid, Arena, Arena de Pets, Boss Global) —
    // na luta, a tela é só a batalha
    if (!ehTelaDeBatalha(tela)) {
      inserirBanner(document.getElementById("conteudo"), chaveDoBanner(tela), tela);
    }
    atualizarBarraAbas();
    // A grade vai DEPOIS do conteúdo, no fim da página: ela é saída, não
    // entrada. No topo, competiria com o que a tela tem pra dizer.
    garantirGradeDeCaminhos();
    atualizarPendencias();
    // Tutorial DEPOIS de a tela montar, não antes: quem lê o guia precisa
    // ver o que ele está explicando atrás da folha.
    talvezMostrarTutorial(tela);
    // 💰⭐🗼 A barra de cima só era atualizada pela tela que por acaso
    // tinha o número em mãos: quem comprava ⭐ noutra tela, ou subia de
    // andar, via o valor velho até reabrir a Ficha. Uma chamada silenciosa
    // por navegação resolve sem competir com a tela (ela não espera).
    if (tela !== "personagem") atualizarEstadoSilenciosoTopo();
  } catch (e) {
    if (!e.jaAlertado) toast(e.message || "Falha ao carregar essa tela.", true);
    som.erro();
  }
}

// ---------- boot ----------
document.getElementById("btn-som")?.addEventListener("click", (ev) => {
  ev.stopPropagation();
  alternarSom();
  atualizarBotaoSom();
  pegarAudioCtx();
});

document.getElementById("btn-musica")?.addEventListener("click", (ev) => {
  ev.stopPropagation();
  const ligado = alternarMusica();
  atualizarBotaoMusica();
  toast(ligado ? "🎵 Trilha ligada" : "🎵 Trilha desligada");
});

// navegadores só deixam áudio tocar sozinho depois de um gesto do usuário —
// então a trilha (se já estava ligada de uma sessão anterior) só começa
// de verdade no primeiro toque na tela, não direto no carregamento
document.addEventListener("pointerdown", function iniciarAudioNaPrimeiraInteracao() {
  document.removeEventListener("pointerdown", iniciarAudioNaPrimeiraInteracao);
  pegarAudioCtx();
  if (musicaLigada()) iniciarTrilha();
}, { once: true });


// ===========================================================
// 🚪 BOOT
// Ordem de tentativa: sessão do site -> initData do Telegram -> login.
// O ramo do Telegram continua aqui de propósito: cortá-lo no mesmo
// commit em que o site nasce derrubaria, naquele segundo, todo mundo
// que ainda joga pelo bot. Ele sai quando o SOMENTE_SITE do servidor
// for ligado e ninguém mais estiver entrando por lá.
// ===========================================================
async function entrarNoJogo() {
  const tela = document.getElementById("tela-carregando");
  try {
    // 🔒 checa combate pendente ANTES de abrir a Ficha — se o jogador saiu
    // no meio de uma luta (Torre, Exploração ou Onda) e voltou, é jogado
    // direto de volta pra ela. Sem brecha pra "sumir" de uma derrota e
    // reaparecer livre depois: enquanto não vencer, fugir ou morrer, a
    // luta continua te esperando exatamente onde parou.
    // 🎭 Personagem sem classe ou raça não pode nem começar: a criação vem
    // ANTES de qualquer tela, senão ele joga a torre inteira sem os bônus e
    // descobre tarde demais que a escolha já não é mais possível.
    const faltaCriar = await precisaCriarPersonagem();
    if (faltaCriar && faltaCriar.erro) { mostrarFalhaNaCriacao(faltaCriar); return; }
    if (faltaCriar) {
      tela.classList.add("oculto");
      document.getElementById("app").classList.remove("oculto");
      await telaCriacao(faltaCriar);
      ativarPuxarAtualizar();
      return;
    }

    const status = await api("/api/tower/status");
    if (status.em_combate) {
      EXPLORANDO_ATIVO = !!status.explore_mode;
      ONDA_ATIVA = !!status.wave_mode;
      TELA_ATUAL = ONDA_ATIVA ? "onda" : EXPLORANDO_ATIVO ? "explorar" : "torre";
      document.getElementById("conteudo").innerHTML = "";
      desenharCombate(status);
    } else if (status.morreu) {
      // 💀 morreu (inclusive batalhando no clã enquanto você não estava):
      // abre direto na morte da Torre, onde está o reviver.
      await irPara("torre");
    } else {
      await irPara("personagem");
    }
    tela.classList.add("oculto");
    document.getElementById("app").classList.remove("oculto");
    // ✏️ personagem sem nome (o banco real tinha nomes vazios): pede um
    try {
      const eu = await api("/api/character");
      // (28/09) em luta também: se for a luta do guia, ele retoma no Atacar
      const comecando = Number(eu.level || 1) <= 5 && Number(eu.tower_floor || 1) <= 1;
      if (!String(eu.username || "").trim()) { GUIA_DEPOIS_DO_NOME = comecando && !status.em_combate; abrirEscolherNome("", true); }
      // 🎮 convidado que já passou do começo: lembra de salvar (1× por entrada)
      else if (CONVIDADO && Number(eu.level || 1) >= 3) {
        setTimeout(() => toast("🎮 Jogando como convidado — salve o progresso em Mais → Conta."), 1500);
      }
      else if (comecando) setTimeout(() => iniciarGuia("guia_inicio", GUIA_INICIO, !!status.em_combate), 700);
    } catch (e) { /* sem nome não trava a entrada */ }
    document.getElementById("barra-abas")?.classList.remove("oculto");
    montarBarraAbas();
    atualizarBarraAbas();
    checarEstadoCidade();
    checarAutobatalha();
    ativarPuxarAtualizar();
    atualizarBadgeMissoes(); // não precisa esperar — o badge aparece assim que chegar
    checarAvisos();          // idem: o sino acende sozinho quando a resposta chega
  } catch (e) {
    if (e.jaAlertado) return;   // o api() já mandou pro login
    tela.classList.remove("oculto");
    tela.innerHTML = "";
    const box = el("div", "em-construcao");
    box.appendChild(el("div", "em-construcao-icone", "⚠️"));
    box.appendChild(el("p", "", e.message || "Não foi possível carregar seu personagem."));
    const btn = document.createElement("button");
    btn.className = "botao-secundario";
    btn.textContent = "Tentar de novo";
    btn.onclick = () => location.reload();
    box.appendChild(btn);
    tela.appendChild(box);
  }
}

(async function iniciar() {
  atualizarBotaoSom();
  atualizarBotaoMusica();

  if (pegarToken()) {
    // Confere o token ANTES de desenhar qualquer coisa. Sem esta checagem,
    // um token vencido só aparecia na primeira chamada de dado — depois de
    // o jogador já ter visto meia tela montar e sumir.
    try {
      const eu = await api("/api/auth/eu");
      MEU_ID = eu && eu.telegram_id;   // o ranking acende a sua linha
      CONVIDADO = !!(eu && eu.convidado);
      await entrarNoJogo();
      return;
    } catch (e) {
      // 🐛 (28/09) antes: QUALQUER erro aqui (servidor reiniciando, 500,
      // internet caindo) apagava o token. Pra quem tem senha era só entrar
      // de novo; pra um convidado seria perder o personagem pra sempre.
      // Sessão vencida de verdade (401) o api() já trata: limpa e mostra o
      // login. O resto vira "tentar de novo", com o token guardado.
      if (!pegarToken()) return;
      const tela = document.getElementById("tela-carregando");
      tela.classList.remove("oculto");
      tela.innerHTML = "";
      const caixa = el("div", "portao");
      caixa.appendChild(el("div", "portao-marca", "⛩️"));
      caixa.appendChild(el("p", "portao-lore", "Não consegui falar com a Torre agora. Sua conta continua salva."));
      const b = document.createElement("button");
      b.className = "botao-holofote"; b.textContent = "Tentar de novo";
      b.onclick = () => location.reload();
      caixa.appendChild(b);
      tela.appendChild(caixa);
      return;
    }
  }

  mostrarLogin();
})();
