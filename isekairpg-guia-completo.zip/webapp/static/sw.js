// Service worker mínimo, de propósito.
//
// O que ele resolve: o jogo abre instalado na tela inicial, e a casca
// (HTML/CSS/JS/ícone) não precisa ser rebaixada a cada abertura.
//
// O que ele NÃO faz: guardar resposta de API. Num jogo com ouro, ⭐ e
// combate, servir dado velho de cache é pior que não abrir — o jogador
// veria um saldo que não existe mais e tomaria decisão em cima disso.
// Toda chamada a /api/ vai direto pra rede, sempre.
const CACHE = "isekai-casca-v1";
const CASCA = ["/", "/index.html", "/style.css", "/app.js", "/icone.svg", "/manifest.json"];

self.addEventListener("install", (ev) => {
  ev.waitUntil(caches.open(CACHE).then((c) => c.addAll(CASCA)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (ev) => {
  ev.waitUntil(
    caches.keys()
      .then((nomes) => Promise.all(nomes.filter((n) => n !== CACHE).map((n) => caches.delete(n))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (ev) => {
  const url = new URL(ev.request.url);
  if (ev.request.method !== "GET") return;
  if (url.pathname.startsWith("/api/")) return;   // dado de jogo: nunca do cache

  // Rede primeiro, cache como rede de segurança. O contrário serviria a
  // versão antiga do app.js depois de um commit, e a armadilha do ?v=N
  // existe justamente porque isso já mordeu este projeto.
  ev.respondWith(
    fetch(ev.request)
      .then((resp) => {
        const copia = resp.clone();
        caches.open(CACHE).then((c) => c.put(ev.request, copia)).catch(() => {});
        return resp;
      })
      .catch(() => caches.match(ev.request))
  );
});
