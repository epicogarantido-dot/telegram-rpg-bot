"""
As imagens do jogo, em arquivo local (`data/imagens/`).

20/09/2026 — O BOT SAIU. Este módulo nasceu pra tirar as artes do Telegram
(`file_id` só o bot sabe baixar) antes de desligá-lo; o espelho terminou e
o código de exportar pelo Telegram foi apagado junto com o bot. Hoje as
artes só entram pelo painel `/admin` (📤 Enviar / 🔁 Trocar — ver o fim do
arquivo), e ficam em `data/imagens/`: a pasta sobrevive a um commit na
Square Cloud e NUNCA entra no zip de deploy. É a ÚNICA cópia da arte — ao
limpar o `data` pra recomeçar testes, esta pasta fica.
"""
from __future__ import annotations

import os
import re

PASTA_IMAGENS = os.path.join("data", "imagens")

# O nome no disco é a CHAVE LÓGICA, que é a que o jogo usa de verdade.
_RE_CHAVE_SEGURA = re.compile(r"^[A-Za-z0-9_\-]{1,64}$")

# 🖼️ MINIATURAS
# As artes vêm do Telegram no tamanho cheio (tipicamente 1280px, 100–200 KB)
# e são desenhadas a 30–84px na tela. Isso é ~95% de bytes jogados fora, num
# WebView de celular, a cada abertura.
#
# Pillow é OPCIONAL de propósito. Foi a lição do python-multipart: um pacote
# faltando não pode derrubar funcionalidade inteira. Sem ele, serve o
# original — mais pesado, mas funcionando.
LARGURAS = (64, 128, 256, 512)
PASTA_MINIATURAS = os.path.join("data", "imagens", "mini")

try:
    from PIL import Image as _Image
    TEM_PILLOW = True
except ImportError:
    _Image = None
    TEM_PILLOW = False
    print("⚠️ Pillow ausente: as artes vão ser servidas em tamanho cheio. "
          "Funciona, mas gasta banda à toa no celular.")


def largura_valida(pedida) -> int | None:
    """Só as larguras da lista. Aceitar qualquer número deixaria qualquer um
    encher o disco pedindo 10 mil tamanhos diferentes da mesma arte."""
    try:
        alvo = int(pedida)
    except (TypeError, ValueError):
        return None
    for w in LARGURAS:
        if alvo <= w:
            return w
    return None   # maior que a maior: serve o original


def ler_miniatura(chave: str, largura: int) -> bytes | None:
    """Devolve a miniatura, gerando na primeira vez. Depois é só disco."""
    if not TEM_PILLOW or not chave_valida(chave):
        return None
    caminho = os.path.join(PASTA_MINIATURAS, f"{chave}_{largura}.jpg")
    if os.path.exists(caminho):
        try:
            with open(caminho, "rb") as f:
                return f.read()
        except OSError:
            pass
    original = ler_local(chave)
    if not original:
        return None
    try:
        import io
        os.makedirs(PASTA_MINIATURAS, exist_ok=True)
        img = _Image.open(io.BytesIO(original))
        img = img.convert("RGB")
        img.thumbnail((largura, largura * 3))   # preserva a proporção
        buffer = io.BytesIO()
        img.save(buffer, "JPEG", quality=82, optimize=True)
        dados = buffer.getvalue()
        temporario = caminho + ".tmp"
        with open(temporario, "wb") as f:
            f.write(dados)
        os.replace(temporario, caminho)
        return dados
    except Exception as e:
        # Miniatura é otimização: falhar aqui serve o original, não quebra.
        print(f"⚠️ [imagens] não consegui miniaturizar {chave}: {e}")
        return None


def chave_valida(chave: str) -> bool:
    """Barra path traversal: sem isso, /api/imagem/../../data/game.db
    viraria download do banco inteiro."""
    return bool(_RE_CHAVE_SEGURA.match(chave or ""))


def caminho_local(chave: str) -> str | None:
    if not chave_valida(chave):
        return None
    return os.path.join(PASTA_IMAGENS, f"{chave}.jpg")


def tem_local(chave: str) -> bool:
    caminho = caminho_local(chave)
    return bool(caminho) and os.path.exists(caminho)


def ler_local(chave: str) -> bytes | None:
    caminho = caminho_local(chave)
    if not caminho or not os.path.exists(caminho):
        return None
    try:
        with open(caminho, "rb") as f:
            return f.read()
    except OSError:
        return None


def gravar_local(chave: str, conteudo: bytes) -> bool:
    """Grava primeiro num .tmp e só então renomeia. Sem isso, uma queda no
    meio da escrita deixaria um .jpg truncado em disco — e como o resto do
    código só checa se o arquivo EXISTE, essa imagem quebrada seria servida
    pra sempre, sem nunca ser rebaixada."""
    caminho = caminho_local(chave)
    if not caminho or not conteudo:
        return False
    try:
        os.makedirs(PASTA_IMAGENS, exist_ok=True)
        temporario = caminho + ".tmp"
        with open(temporario, "wb") as f:
            f.write(conteudo)
        os.replace(temporario, caminho)
        return True
    except OSError:
        return False


# ============================================================================
# 📤 ENVIO DE ARTE PELO /admin (20/09/2026)
# ============================================================================
# Com o bot de saída, o Telegram deixa de ser o jeito de subir arte. O
# painel de admin passa a mandar o arquivo direto pra cá — tanto pra arte
# que falta quanto pra TROCAR uma que já existe.
#
# Duas armadilhas que este bloco evita:
#  - **Cache de 24h.** `/api/imagem` responde com max-age de um dia. Trocar
#    a arte sem mudar a URL deixaria a imagem velha na tela por até 24h —
#    indistinguível de "o envio não funcionou". Cada envio grava uma
#    VERSÃO por chave (`_versoes.json`) e o front põe `&v=` na URL.
#  - **Miniatura velha.** As miniaturas (`?w=`) ficam em disco; se não
#    forem apagadas, a arte nova aparece grande e a velha em todo lugar
#    pequeno — que é quase o jogo inteiro.

ARQUIVO_VERSOES = os.path.join(PASTA_IMAGENS, "_versoes.json")
TAMANHO_MAXIMO_ENVIO = 8 * 1024 * 1024

_ASSINATURAS = [
    (b"\xff\xd8\xff", "image/jpeg"),
    (b"\x89PNG\r\n\x1a\n", "image/png"),
    (b"GIF87a", "image/gif"),
    (b"GIF89a", "image/gif"),
]


def tipo_da_imagem(conteudo: bytes) -> str | None:
    """Tipo pelos PRIMEIROS BYTES, não pelo nome do arquivo — nome se muda à
    vontade, a assinatura não. None = não é imagem que o jogo aceite."""
    if not conteudo:
        return None
    for assinatura, tipo in _ASSINATURAS:
        if conteudo.startswith(assinatura):
            return tipo
    if conteudo[:4] == b"RIFF" and conteudo[8:12] == b"WEBP":
        return "image/webp"
    return None


def versoes_enviadas() -> dict:
    import json
    try:
        with open(ARQUIVO_VERSOES, encoding="utf-8") as f:
            dados = json.load(f)
        return dados if isinstance(dados, dict) else {}
    except (OSError, ValueError):
        return {}


def gravar_envio(chave: str, conteudo: bytes) -> dict:
    """Grava a arte enviada pelo admin. Devolve {ok, erro?, versao?}."""
    import json, time as _t
    if not chave_valida(chave):
        return {"ok": False, "erro": "Chave inválida (só letras, números, _ e -)."}
    if not conteudo or len(conteudo) > TAMANHO_MAXIMO_ENVIO:
        return {"ok": False, "erro": "Arquivo vazio ou maior que 8 MB."}
    if not tipo_da_imagem(conteudo):
        return {"ok": False, "erro": "Não é uma imagem JPG, PNG, WEBP ou GIF."}
    if not gravar_local(chave, conteudo):
        return {"ok": False, "erro": "Não consegui gravar no disco."}
    # miniaturas velhas dessa chave saem, senão a tela pequena mostra a antiga
    try:
        for nome in os.listdir(PASTA_MINIATURAS):
            if nome.startswith(f"{chave}_") and nome.endswith(".jpg"):
                os.remove(os.path.join(PASTA_MINIATURAS, nome))
    except OSError:
        pass
    versoes = versoes_enviadas()
    versoes[chave] = int(_t.time())
    temporario = ARQUIVO_VERSOES + ".tmp"
    with open(temporario, "w", encoding="utf-8") as f:
        json.dump(versoes, f)
    os.replace(temporario, ARQUIVO_VERSOES)
    return {"ok": True, "versao": versoes[chave]}
