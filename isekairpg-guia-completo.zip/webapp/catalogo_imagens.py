"""
Catálogo de imagens do jogo: o que EXISTE e o que FALTA, separado por tipo.

POR QUE ISSO EXISTE
-------------------
`/api/admin/imagens` responde uma coisa só: quantas das chaves de
`game/assets.py` já foram espelhadas em disco. Isso serve pra saber se dá
pra desligar o bot — e só. Não diz nada sobre a pergunta que aparece toda
vez que se cria arte nova: *de que ainda falta imagem?*

E a diferença entre as duas perguntas é grande, porque a pergunta da arte
tem um lado que o espelho não enxerga: chave que o JOGO PEDE e que nem
existe em `ASSETS`. Montaria é o caso extremo — `explore.py` monta
`MOUNT_{id}` pra 15 montarias e **não há uma única chave MOUNT_ no
`assets.py`**. Do ponto de vista do espelho está 100% completo; do ponto de
vista do jogador, toda montaria aparece com a arte da Cidade.

Por isso aqui o catálogo é montado ao contrário: primeiro a lista do que o
jogo PRECISA (derivada dos mesmos bancos que o jogo usa em tempo de
execução), e só depois se pergunta o que cada chave tem.

REGRA DE OURO DESTE ARQUIVO
---------------------------
As chaves são derivadas das MESMAS funções que o jogo chama
(`resolver_asset_key_inimigo`, `resolver_asset_key_item`) e dos MESMOS
bancos (`PETS_DB`, `MOUNTS_DB`, `RAÇAS_POR_BLOCO`, `items.SLOTS`). Nunca
copie uma lista pra cá: era exatamente assim que duas cópias da mesma
lógica iam se desencontrando neste projeto (armadilha nº 3). Se o jogo
ganhar um pet novo, este painel enxerga sozinho.

OS QUATRO ESTADOS DE UMA CHAVE
------------------------------
- `propria`     — tem file_id só dela. É a arte de verdade.
- `repetida`    — o file_id é o mesmo de outra chave (arte emprestada de
                  um vizinho). Funciona, mas não é a arte certa.
- `emprestada`  — cai no fallback (`DEFAULT_ASSET_KEY`, a Cidade).
- `ausente`     — o jogo pede essa chave e ela não existe em `ASSETS`.

`ausente` e `emprestada` são "falta arte". `repetida` é cinza: às vezes é
intencional (RAID e RAID_COMBAT dividem cenário de propósito), então ela
aparece separada em vez de ser contada como buraco.

Só leitura. Não baixa, não grava, não dispara exportação.
"""
from __future__ import annotations


# Telas e cenários não saem de banco nenhum — são chamadas na mão pelas
# views. Aqui é a única lista escrita à mão do arquivo, e ela é conferida
# contra o ASSETS: chave de tela que aparecer no assets.py e não estiver
# aqui cai em "Outras", em vez de sumir do painel.
TELAS = {
    "CITY": "Praça da Cidade",
    "TOWER": "Torre",
    "HOSPITAL": "Hospital",
    "LOJA": "Loja",
    "CLASSE": "Escolha de classe",
    "TRILHAS": "Trilhas",
    "APRENDER": "Aprender skill",
    "TROCAS": "Trocas",
    "RANKING": "Ranking",
    "SOCKETS": "Engaste de gemas",
    "SKILL": "Skills",
    "CRAFT": "Forja",
    "INVENTARIO": "Inventário",
    "DEAD": "Morte",
    "VIP": "VIP",
    "STATUS": "Status do jogador",
    "RAID": "Raid",
    "RAID_COMBAT": "Raid em combate",
    "COMBAT": "Combate",
    "MOB_DEFAULT": "Monstro sem arte (fallback)",
}


def _chaves_jogador() -> list[tuple[str, str]]:
    """STATUS_{RAÇA}_{M|F} — a arte da ficha, do topo e do combate.

    As raças saem do RACESDB do `logic.py`, lido do FONTE e não importado:
    o logic puxa o banco inteiro junto, e o catálogo precisa rodar dentro
    do /admin e dentro da auditoria sem esse peso. Só os nomes das chaves
    do dicionário são usados — nada de regra copiada.
    """
    import os, re
    caminho = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "game", "logic.py")
    fonte = open(caminho, encoding="utf-8").read()
    inicio = fonte.index("RACESDB = {")
    trecho = fonte[inicio:fonte.index("\n}\n", inicio)]      # só o bloco das raças
    # 🐛 (26/09) era [a-z_]+: "Bárbaro" (maiúscula e acento) nunca entrava
    racas = re.findall(r'^    "([^"]+)": \{', trecho, re.M)

    from game.assets import normalizar_chave, SEXOS
    saida = [("STATUS", "Jogador sem raça (fallback de todos)")]
    for raca in racas:
        base = normalizar_chave(f"STATUS_{raca}")
        for sigla, rotulo in SEXOS.items():
            saida.append((f"{base}_{sigla.upper()}", f"{raca.title()} · {rotulo}"))
    return saida


def _chaves_monstros() -> list[tuple[str, str]]:
    """(chave, rótulo) de todo monstro que a Torre sabe gerar.

    Usa `resolver_asset_key_inimigo` — a mesma função do combate — em vez
    de remontar o nome aqui. Assim a acentuação, o `split(" #")` e o
    tratamento de elite/boss não têm como divergir.
    """
    from game.assets import resolver_asset_key_inimigo
    from game.monsters import RAÇAS_POR_BLOCO

    saida: list[tuple[str, str]] = []
    vistas: set[str] = set()

    def por(chave: str, rotulo: str) -> None:
        if chave not in vistas:
            vistas.add(chave)
            saida.append((chave, rotulo))

    from game.monsters import normal_possivel
    for (ini, fim), dados in RAÇAS_POR_BLOCO.items():
        raca = dados["nome"]
        faixa = f"andares {ini}–{fim}"
        # 20/09: monstro NORMAL não nasce do andar 30 em diante (a regra é
        # `monsters.pesos_do_andar`, a mesma do combate). Cobrar arte pra
        # eles era pendência que nunca ia aparecer em tela nenhuma — o dev
        # apontou. Se a arte existir mesmo assim, ela cai em "Outras".
        if any(normal_possivel(a) for a in range(int(ini), int(fim) + 1)):
            for tipo in dados.get("tipos", []):
                mob = {"raca_nome": raca, "arquetipo": tipo, "tipo": "normal"}
                por(resolver_asset_key_inimigo(mob), f"{raca} {tipo.title()} · {faixa}")
        for nome in dados.get("elite", []):
            mob = {"raca_nome": raca, "name": nome, "tipo": "elite"}
            por(resolver_asset_key_inimigo(mob), f"{nome} (elite) · {faixa}")
        boss = dados.get("boss")
        if boss:
            mob = {"raca_nome": raca, "name": boss, "tipo": "boss"}
            por(resolver_asset_key_inimigo(mob), f"{boss} (boss) · {faixa}")
    return saida


def _chaves_pets() -> list[tuple[str, str]]:
    """PET_{id} — a mesma forma que `explore.py` usa ao dropar o pet."""
    from game.pets_db import PETS_DB
    saida = []
    for pet_id, dados in PETS_DB.items():
        nome = dados.get("name") or dados.get("nome") or pet_id
        rar = dados.get("rarity") or dados.get("raridade") or ""
        rotulo = f"{nome}" + (f" · {rar}" if rar else "")
        saida.append((f"PET_{str(pet_id).upper()}", rotulo))
    return saida


def _chaves_montarias() -> list[tuple[str, str]]:
    """MOUNT_{id} — mesma forma de `explore.py`. Hoje nenhuma existe."""
    from game.mounts import MOUNTS_DB
    saida = []
    for mid, dados in MOUNTS_DB.items():
        nome = dados.get("name") or mid
        rar = dados.get("rarity") or ""
        saida.append((f"MOUNT_{str(mid).upper()}", f"{nome}" + (f" · {rar}" if rar else "")))
    return saida


def _chaves_itens() -> list[tuple[str, str]]:
    """Cada slot x raridade (e, na arma, x tipo de arma), pela mesma
    `resolver_asset_key_item` que o inventário e a forja chamam."""
    from game.assets import resolver_asset_key_item
    from game.items import SLOTS, WEAPON_TYPES, RARITIES

    nome_pt = {"common": "Comum", "uncommon": "Incomum", "rare": "Raro",
               "epic": "Épico", "legendary": "Lendário"}
    nome_slot = {"weapon": "Arma", "armor": "Armadura", "helmet": "Capacete",
                 "gloves": "Luvas", "boots": "Botas", "shield": "Escudo",
                 "belt": "Cinto", "necklace": "Colar", "ring": "Anel"}

    saida = []
    for slot in SLOTS:
        subs = list(WEAPON_TYPES.keys()) if slot == "weapon" else [""]
        for sub in subs:
            for rar in RARITIES:
                chave = resolver_asset_key_item(slot, rar, sub)
                rotulo = nome_slot.get(slot, slot.title())
                if sub:
                    rotulo += " " + str(WEAPON_TYPES[sub].get("name", sub))
                rotulo += " · " + nome_pt.get(rar, rar)
                saida.append((chave, rotulo))
    return saida


def _chaves_miticos() -> list[tuple[str, str]]:
    """🖼️ (26/09/2026) MITICO_<SLOT>_<N> — um por item Mítico do banco, pela
    mesma `chave_mitico` que o inventário usa."""
    from game.assets import chave_mitico
    from game.mythic_items import MYTHIC_ITEMS_DB
    nome_slot = {"weapon": "Arma", "armor": "Armadura", "helmet": "Capacete", "gloves": "Luvas",
                 "boots": "Botas", "shield": "Escudo", "belt": "Cinto", "necklace": "Colar", "ring": "Anel"}
    saida = []
    for slot, variantes in MYTHIC_ITEMS_DB.items():
        for v in variantes:
            saida.append((chave_mitico(v[0]), f"{v[1]} · {nome_slot.get(slot, slot)} Mítico"))
    return saida


def _chaves_cronicas() -> list[tuple[str, str]]:
    """🖼️ (26/09/2026) CRONICA_<ID> — uma por Crônica (ou a chave do campo
    "imagem" do JSON, que várias podem dividir). Crônica nova no JSON
    aparece aqui sozinha."""
    from game.cronicas import catalogo, chave_de_imagem
    vistas, saida = set(), []
    for ev in catalogo().values():
        chave = chave_de_imagem(ev)
        if chave in vistas:
            continue
        vistas.add(chave)
        onde = {"torre": "Torre", "faixa": "Arco da Torre", "inicio": "Fundação"}.get(ev.get("gatilho"), "Clã")
        saida.append((chave, f"{ev.get('icone', '📖')} {ev.get('titulo', ev['id'])} · {onde}"))
    return saida


# Ordem em que os grupos aparecem no painel. A lista de telas vem primeiro
# porque é a que o jogador vê em toda sessão; monstro vem por último porque
# é a maior e a que mais aceita fallback sem estragar a tela.
GRUPOS = [
    ("telas",     "🏛️ Telas e cenários", lambda: [(k, v) for k, v in TELAS.items()]),
    ("jogador",   "🧍 Jogador (raça × sexo)", _chaves_jogador),
    ("itens",     "⚔️ Itens",            _chaves_itens),
    ("pets",      "🐾 Pets",             _chaves_pets),
    ("montarias", "🐎 Montarias",        _chaves_montarias),
    ("miticos",   "🌟 Itens Míticos",    _chaves_miticos),
    ("cronicas",  "📖 Crônicas",         _chaves_cronicas),
    ("monstros",  "👹 Monstros",         _chaves_monstros),
]


def montar_catalogo() -> dict:
    """O que o painel de admin desenha. Puro cálculo em memória: ~370
    chaves, nenhum I/O além do `os.path.exists` do espelho."""
    from game.assets import ASSETS, DEFAULT_ASSET_KEY
    from webapp.imagens import tem_local, chave_valida

    fallback_id = ASSETS.get(DEFAULT_ASSET_KEY)
    from webapp.imagens import versoes_enviadas, PASTA_IMAGENS
    import os as _os
    versoes = versoes_enviadas()
    # Só dá pra dizer "falta o arquivo" se o espelho existe (servidor). Sem
    # pasta nenhuma (ambiente de teste), o catálogo julga só pelas chaves.
    espelho_existe = _os.path.isdir(PASTA_IMAGENS) and any(
        n.endswith(".jpg") for n in _os.listdir(PASTA_IMAGENS))

    # Quantas chaves compartilham cada file_id. É o que separa "arte
    # própria" de "arte emprestada do vizinho" — asset_faltando() só
    # enxerga o fallback padrão e deixa esse caso passar batido.
    donos: dict[str, list[str]] = {}
    for chave, fid in ASSETS.items():
        if fid:
            donos.setdefault(fid, []).append(chave)

    # Índice achatado das chaves que existem, pra sugerir a arte quase-igual.
    por_plano: dict[str, str] = {}
    for chave in ASSETS:
        por_plano.setdefault(_normalizar(chave), chave)

    def estado_de(chave: str) -> dict:
        fid = ASSETS.get(chave)
        enviada = chave_valida(chave) and tem_local(chave) and chave in versoes
        if enviada:
            # Arte enviada pelo /admin: é o arquivo local que vale, com ou
            # sem file_id do Telegram (o bot está de saída).
            estado = "propria"
        elif not fid:
            estado = "ausente"
        elif espelho_existe and not (chave_valida(chave) and tem_local(chave)):
            # 🐛 20/09: o file_id existe, mas o ARQUIVO não está no servidor.
            # Com o bot fora, file_id sozinho não mostra nada: a arte só existe
            # no Telegram. Foi o caso das 31 chaves com acento (Xamã, Gárgula,
            # Demônio...) — o espelho recusava o nome acentuado e nunca as
            # baixou; o catálogo contava como "arte própria" e o jogo mostrava
            # emoji. Agora aparecem como faltando, com o botão de enviar.
            estado = "sem_arquivo"
        elif fallback_id and fid == fallback_id and chave != DEFAULT_ASSET_KEY:
            estado = "emprestada"
        elif len(donos.get(fid, [])) > 1:
            estado = "repetida"
        else:
            estado = "propria"
        parecida = ""
        if estado == "ausente":
            candidata = por_plano.get(_normalizar(chave), "")
            if candidata and candidata != chave:
                parecida = candidata

        return {
            "estado": estado,
            "enviada": bool(enviada),
            "espelhada": (bool(fid) or bool(enviada)) and tem_local(chave),
            "valida": chave_valida(chave),
            "parecida": parecida,
            "dividido_com": [c for c in donos.get(fid, []) if c != chave][:4]
                            if estado == "repetida" else [],
        }

    grupos = []
    vistas: set[str] = set()
    for gid, titulo, gerar in GRUPOS:
        itens = []
        try:
            esperadas = gerar()
        except Exception as e:
            # Um banco quebrado não pode derrubar o painel inteiro: o grupo
            # aparece com o erro escrito e os outros seguem.
            grupos.append({"id": gid, "titulo": titulo, "erro": str(e),
                           "itens": [], "contagem": {}})
            continue
        for chave, rotulo in esperadas:
            vistas.add(chave)
            itens.append(dict(chave=chave, rotulo=rotulo, **estado_de(chave)))
        grupos.append({
            "id": gid, "titulo": titulo, "itens": itens,
            "contagem": _contar(itens),
        })

    # Chaves que existem em ASSETS e nenhum grupo reivindicou. Nunca some
    # nada: arte carregada pelo bot que o código não pede mais também é
    # informação de operação.
    sobras = [dict(chave=k, rotulo="(não pedida por nenhum sistema)", **estado_de(k))
              for k in sorted(ASSETS) if k not in vistas]
    if sobras:
        grupos.append({"id": "outras", "titulo": "📦 Outras chaves em assets.py",
                       "itens": sobras, "contagem": _contar(sobras)})

    todos = [i for g in grupos for i in g["itens"]]
    return {
        "grupos": grupos,
        "total": _contar(todos),
        "fallback": DEFAULT_ASSET_KEY,
    }


def _normalizar(chave: str) -> str:
    """Achata acento e pontuação. Serve pra achar a arte que EXISTE com o
    nome quase igual ao que o jogo pede — que foi o achado que motivou
    isto: `MOB_ABERRAÇÃO_MUTANTE` está no assets.py e o combate pede
    `MOB_ABERRACAO_MUTANTE`, então a arte existe e nunca aparece."""
    import unicodedata
    plano = unicodedata.normalize("NFD", chave or "")
    plano = "".join(c for c in plano if unicodedata.category(c) != "Mn")
    return "".join(c for c in plano.upper() if c.isalnum())


def _contar(itens: list[dict]) -> dict:
    c = {"total": len(itens), "propria": 0, "repetida": 0,
         "emprestada": 0, "ausente": 0, "sem_arquivo": 0, "espelhadas": 0, "invalidas": 0}
    for i in itens:
        c[i["estado"]] += 1
        if i["espelhada"]:
            c["espelhadas"] += 1
        if not i["valida"]:
            c["invalidas"] += 1
    c["faltando"] = c["emprestada"] + c["ausente"] + c["sem_arquivo"]
    return c
