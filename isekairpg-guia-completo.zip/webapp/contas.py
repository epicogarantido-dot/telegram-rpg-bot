"""
Autenticação própria do site — substitui o initData do Telegram.

O PROBLEMA
----------
Dentro do Telegram a identidade vinha de graça: o Telegram assinava o
initData com HMAC e o servidor só conferia a assinatura (webapp/auth.py).
Fora do Telegram não existe esse terceiro confiável. O jogo precisa
guardar usuário e senha.

DECISÕES E PORQUÊS
------------------
SENHA — PBKDF2-HMAC-SHA256, sal de 16 bytes por usuário. É stdlib pura:
bcrypt/argon2 exigiriam compilar algo na Square Cloud.

SESSÃO — token de 32 bytes no header `Authorization: Bearer <token>`.
De propósito NÃO é cookie: o CORS deste app está liberado, e cookie com
origem liberada seria buraco de CSRF. Com token em header, o navegador não
anexa nada sozinho. No banco fica só o SHA-256 do token, então vazar o
arquivo do banco não dá acesso a ninguém.

IDENTIDADE — aqui está a diferença pro Mestre do Futebol. Lá o `chat_id`
era TEXT, e deu pra usar "web:<hex>". No Isekairpg `telegram_id` é
INTEGER PRIMARY KEY, e mudar o tipo significaria migrar a coluna em 6
tabelas com jogo no ar. Então contas nativas do site recebem
`telegram_id` NEGATIVO. IDs do Telegram são sempre positivos, então não
existe colisão possível, e o schema não muda uma linha.

VINCULAR SAVE ANTIGO — quem já joga tem o progresso preso a um
telegram_id positivo. Ele pede `/vincular` no bot, recebe um código de 6
caracteres válido por 15 minutos, e usa esse código no cadastro do site.
O código prova que ele controla aquela conta do Telegram.
É self-service de propósito: um script de terminal por jogador seria
inútil pra quem desenvolve do celular.

SENHA COM ESPAÇO — teclado de celular cola espaço no fim. Sem e-mail de
recuperação, isso tranca a conta pra sempre. A senha é limpada nas duas
pontas (cadastro e login), então um espaço sobrando simplesmente nunca
importa.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import time
import unicodedata

from infra.migracao import garantir_colunas, garantir_colunas_async

# 🧱 20/09/2026 — os CREATE deste arquivo viraram constantes pra que a
# MESMA string crie a tabela e migre banco velho (infra/migracao.py).
# Coluna nova entra aqui e chega sozinha em quem já tinha a tabela.
_SQL_USUARIOS_SESSOES = """
            CREATE TABLE IF NOT EXISTS usuarios (
                usuario_norm TEXT PRIMARY KEY,
                usuario      TEXT NOT NULL,
                senha_hash   TEXT NOT NULL,
                sal          TEXT NOT NULL,
                iteracoes    INTEGER NOT NULL,
                telegram_id  INTEGER NOT NULL UNIQUE,
                criado_em    INTEGER NOT NULL,
                ultimo_login INTEGER
            );
            CREATE TABLE IF NOT EXISTS sessoes (
                token_hash  TEXT PRIMARY KEY,
                telegram_id INTEGER NOT NULL,
                criado_em   INTEGER NOT NULL,
                expira_em   INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS codigos_vinculo (
                codigo      TEXT PRIMARY KEY,
                telegram_id INTEGER NOT NULL,
                expira_em   INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS convidados (
                telegram_id INTEGER PRIMARY KEY,
                criado_em   INTEGER NOT NULL,
                ip          TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_sessoes_tid ON sessoes(telegram_id);
            CREATE INDEX IF NOT EXISTS idx_usuarios_tid ON usuarios(telegram_id);
        """


ITERACOES = 120_000
SESSAO_DURACAO = 60 * 60 * 24 * 30        # 30 dias
CODIGO_DURACAO = 60 * 15                  # 15 minutos
USUARIO_MIN, USUARIO_MAX = 3, 20
SENHA_MIN = 6

# Só ASCII: evita que "Kim" e "Kím" sejam contas diferentes na prática.
_RE_USUARIO = re.compile(r"^[A-Za-z0-9._-]+$")

# Sem I, O, 0 e 1 — o jogador vai LER o código na tela do bot e DIGITAR no
# site, e esses quatro são os que todo mundo confunde.
_ALFABETO_CODIGO = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


class ErroConta(Exception):
    """Erro esperado, com mensagem que pode ser mostrada ao jogador."""
    pass


def _conn():
    from game.sql_repo import get_connection
    return get_connection()


def init_contas() -> None:
    """Cria as tabelas da autenticação. Idempotente: roda todo boot."""
    with _conn() as c:
        c.executescript(_SQL_USUARIOS_SESSOES)
        garantir_colunas(c, _SQL_USUARIOS_SESSOES)  # 🧱 migra o que o CREATE tem e o disco não
        c.commit()


# ---------------------------------------------------------------- utilidades

def normalizar(usuario: str) -> str:
    """Nome usado só pra unicidade: minúsculo e sem acento. O nome EXIBIDO
    guarda o original."""
    s = unicodedata.normalize("NFKD", (usuario or "").strip())
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return s.lower()


def _hash_senha(senha: str, sal: bytes, iteracoes: int = ITERACOES) -> str:
    return hashlib.pbkdf2_hmac("sha256", senha.encode("utf-8"), sal, iteracoes).hex()


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _limpar_senha(senha: str) -> str:
    """Ver nota sobre teclado de celular no topo do arquivo."""
    return (senha or "").strip()


def validar_credenciais(usuario: str, senha: str) -> tuple[str, str]:
    usuario = (usuario or "").strip()
    senha = _limpar_senha(senha)
    if not (USUARIO_MIN <= len(usuario) <= USUARIO_MAX):
        raise ErroConta(f"O nome precisa ter entre {USUARIO_MIN} e {USUARIO_MAX} caracteres.")
    if not _RE_USUARIO.match(usuario):
        raise ErroConta("O nome só aceita letras, números, ponto, hífen e underscore.")
    if len(senha) < SENHA_MIN:
        raise ErroConta(f"A senha precisa ter pelo menos {SENHA_MIN} caracteres.")
    return usuario, senha


def _novo_id_web(c) -> int:
    """Conta nativa do site recebe telegram_id NEGATIVO. IDs do Telegram são
    sempre positivos, então isso nunca colide — e o schema fica intacto.

    ⚠️ Só chame dentro de uma transação IMMEDIATE (ver criar_conta). Isto é
    ler-e-depois-gravar: sem o lock de escrita tomado ANTES da leitura, dois
    cadastros simultâneos leem o mesmo MIN e tentam o mesmo id. Aconteceu no
    teste de 12 cadastros concorrentes — 3 de 12 falharam.
    """
    linha = c.execute("SELECT MIN(telegram_id) FROM players").fetchone()
    menor = (linha[0] if linha and linha[0] is not None else 0)
    linha2 = c.execute("SELECT MIN(telegram_id) FROM usuarios").fetchone()
    menor2 = (linha2[0] if linha2 and linha2[0] is not None else 0)
    # 🎮 convidado reserva o id ANTES de ter linha em players (o personagem
    # só nasce na primeira chamada do jogo): sem contar esta tabela, o
    # cadastro seguinte pegava o MESMO id e as duas contas viravam uma só.
    linha3 = c.execute("SELECT MIN(telegram_id) FROM convidados").fetchone()
    menor3 = (linha3[0] if linha3 and linha3[0] is not None else 0)
    return min(0, menor, menor2, menor3) - 1


def _desfazer(c) -> None:
    """ROLLBACK que não estoura se a transação já tiver acabado — senão o
    erro do rollback esconde o erro de verdade que a gente queria ver."""
    try:
        c.execute("ROLLBACK")
    except sqlite3.OperationalError:
        pass


def _explicar_integridade(e: sqlite3.IntegrityError) -> ErroConta:
    """A tabela usuarios tem DOIS índices únicos: usuario_norm e telegram_id.
    Culpar sempre o nome de usuário mandava o jogador procurar no lugar
    errado — ele trocava o nome e falhava de novo pelo mesmo motivo."""
    texto = str(e)
    if "telegram_id" in texto:
        return ErroConta("Esse personagem já está ligado a uma conta do site.")
    return ErroConta("Esse nome de usuário já está em uso.")


# ------------------------------------------------------------------- cadastro

def criar_conta(usuario: str, senha: str, codigo_vinculo: str | None = None) -> tuple[int, str]:
    """Cadastra e devolve (telegram_id, usuario_exibido).

    Com `codigo_vinculo`, aponta a conta nova pro save ANTIGO do Telegram
    em vez de criar um personagem zerado — ninguém perde progresso na
    virada. Sem código, nasce uma conta nova com id negativo.
    """
    usuario, senha = validar_credenciais(usuario, senha)
    norm = normalizar(usuario)
    sal = os.urandom(16)
    agora = int(time.time())

    with _conn() as c:
        # 🔒 Transação IMMEDIATE: toma o lock de escrita ANTES de ler o MIN.
        # Sem isso, escolher o id é ler-e-depois-gravar e dois cadastros
        # simultâneos brigam pelo mesmo número. O busy_timeout de 5s já
        # configurado faz o segundo esperar em vez de estourar.
        c.isolation_level = None
        c.execute("BEGIN IMMEDIATE")
        try:
            if codigo_vinculo:
                telegram_id = _resgatar_codigo(c, codigo_vinculo)
                ja = c.execute("SELECT usuario FROM usuarios WHERE telegram_id = ?",
                               (telegram_id,)).fetchone()
                if ja:
                    raise ErroConta(f"Esse personagem já está ligado à conta '{ja[0]}'.")
            else:
                telegram_id = _novo_id_web(c)

            c.execute(
                "INSERT INTO usuarios(usuario_norm, usuario, senha_hash, sal, iteracoes,"
                " telegram_id, criado_em, ultimo_login) VALUES (?,?,?,?,?,?,?,?)",
                (norm, usuario, _hash_senha(senha, sal), sal.hex(), ITERACOES,
                 telegram_id, agora, agora))
            if codigo_vinculo:
                c.execute("DELETE FROM codigos_vinculo WHERE codigo = ?",
                          (codigo_vinculo.strip().upper(),))
            c.execute("COMMIT")
        except sqlite3.IntegrityError as e:
            _desfazer(c)
            raise _explicar_integridade(e)
        except Exception:
            _desfazer(c)
            raise

    return telegram_id, usuario


def conferir_senha(usuario: str, senha: str) -> tuple[int, str]:
    """Devolve (telegram_id, usuario) se bater.

    A mensagem de erro é genérica de propósito: dizer "usuário não existe"
    entregaria quais contas existem. O custo disso é que o suporte fica
    cego — por isso o painel de admin mostra a verdade.
    """
    senha = _limpar_senha(senha)
    generico = ErroConta("Usuário ou senha incorretos.")
    with _conn() as c:
        linha = c.execute(
            "SELECT usuario, senha_hash, sal, iteracoes, telegram_id FROM usuarios"
            " WHERE usuario_norm = ?", (normalizar(usuario),)).fetchone()
        if not linha:
            # Gasta o mesmo tempo de um hash real. Sem isso, a diferença de
            # tempo de resposta diz sozinha quais usuários existem.
            _hash_senha(senha, b"0" * 16)
            raise generico

        calculado = _hash_senha(senha, bytes.fromhex(linha["sal"]), int(linha["iteracoes"]))
        if not hmac.compare_digest(calculado, linha["senha_hash"]):
            raise generico

        c.execute("UPDATE usuarios SET ultimo_login = ? WHERE usuario_norm = ?",
                  (int(time.time()), normalizar(usuario)))
        c.commit()
        return int(linha["telegram_id"]), linha["usuario"]


def trocar_senha(telegram_id: int, senha_atual: str, senha_nova: str) -> None:
    senha_atual, senha_nova = _limpar_senha(senha_atual), _limpar_senha(senha_nova)
    if len(senha_nova) < SENHA_MIN:
        raise ErroConta(f"A senha nova precisa ter pelo menos {SENHA_MIN} caracteres.")
    with _conn() as c:
        linha = c.execute(
            "SELECT usuario_norm, senha_hash, sal, iteracoes FROM usuarios"
            " WHERE telegram_id = ?", (telegram_id,)).fetchone()
        if not linha:
            raise ErroConta("Conta não encontrada.")
        atual = _hash_senha(senha_atual, bytes.fromhex(linha["sal"]), int(linha["iteracoes"]))
        if not hmac.compare_digest(atual, linha["senha_hash"]):
            raise ErroConta("Senha atual incorreta.")
        sal = os.urandom(16)
        c.execute("UPDATE usuarios SET senha_hash = ?, sal = ?, iteracoes = ?"
                  " WHERE usuario_norm = ?",
                  (_hash_senha(senha_nova, sal), sal.hex(), ITERACOES, linha["usuario_norm"]))
        # Trocar senha derruba as outras sessões: é o único jeito de expulsar
        # alguém que já esteja dentro com a senha antiga.
        c.execute("DELETE FROM sessoes WHERE telegram_id = ?", (telegram_id,))
        c.commit()


# -------------------------------------------------------------------- sessões

def abrir_sessao(telegram_id: int, duracao: int = SESSAO_DURACAO) -> tuple[str, int]:
    token = secrets.token_urlsafe(32)
    agora = int(time.time())
    expira = agora + int(duracao)
    with _conn() as c:
        c.execute("INSERT INTO sessoes(token_hash, telegram_id, criado_em, expira_em)"
                  " VALUES (?,?,?,?)", (_hash_token(token), telegram_id, agora, expira))
        c.commit()
    return token, expira


def sessao_valida(token: str) -> int | None:
    """Devolve o telegram_id da sessão, ou None. Roda em TODA requisição."""
    if not token:
        return None
    with _conn() as c:
        linha = c.execute("SELECT telegram_id, expira_em FROM sessoes WHERE token_hash = ?",
                          (_hash_token(token),)).fetchone()
        if not linha:
            return None
        if int(linha["expira_em"]) < int(time.time()):
            c.execute("DELETE FROM sessoes WHERE token_hash = ?", (_hash_token(token),))
            c.commit()
            return None
        return int(linha["telegram_id"])


def fechar_sessao(token: str) -> None:
    with _conn() as c:
        c.execute("DELETE FROM sessoes WHERE token_hash = ?", (_hash_token(token),))
        c.commit()


def limpar_sessoes_vencidas() -> int:
    with _conn() as c:
        cur = c.execute("DELETE FROM sessoes WHERE expira_em < ?", (int(time.time()),))
        c.execute("DELETE FROM codigos_vinculo WHERE expira_em < ?", (int(time.time()),))
        c.commit()
        return cur.rowcount or 0


# ------------------------------------------------------- vincular save antigo

def gerar_codigo_vinculo(telegram_id: int) -> tuple[str, int]:
    """Chamado pelo BOT, por quem já tem personagem. Devolve (codigo, minutos)."""
    with _conn() as c:
        ja = c.execute("SELECT usuario FROM usuarios WHERE telegram_id = ?",
                       (telegram_id,)).fetchone()
        if ja:
            raise ErroConta(f"Este personagem já está no site, na conta '{ja[0]}'.")

        # Um código por vez por jogador: pedir de novo invalida o anterior,
        # senão um código antigo continuaria valendo sem ele saber.
        c.execute("DELETE FROM codigos_vinculo WHERE telegram_id = ?", (telegram_id,))
        for _ in range(10):
            codigo = "".join(secrets.choice(_ALFABETO_CODIGO) for _ in range(6))
            try:
                c.execute("INSERT INTO codigos_vinculo(codigo, telegram_id, expira_em)"
                          " VALUES (?,?,?)",
                          (codigo, telegram_id, int(time.time()) + CODIGO_DURACAO))
                c.commit()
                return codigo, CODIGO_DURACAO // 60
            except sqlite3.IntegrityError:
                continue
        raise ErroConta("Não consegui gerar um código agora. Tente de novo.")


def _resgatar_codigo(c, codigo: str) -> int:
    codigo = (codigo or "").strip().upper()
    linha = c.execute("SELECT telegram_id, expira_em FROM codigos_vinculo WHERE codigo = ?",
                      (codigo,)).fetchone()
    if not linha:
        raise ErroConta("Código inválido. Peça um novo com /vincular no bot.")
    if int(linha["expira_em"]) < int(time.time()):
        # Não apaga nem commita aqui: esta função roda DENTRO da transação de
        # criar_conta. Commitar no meio fecha a transação do chamador e o
        # ROLLBACK dele estoura com "no transaction is active" — que foi
        # exatamente o que aconteceu no teste. A faxina do código vencido
        # fica por conta de limpar_sessoes_vencidas().
        raise ErroConta("Esse código expirou. Peça um novo com /vincular no bot.")
    return int(linha["telegram_id"])


# ---------------------------------------------------------------------- admin

def info_conta(usuario: str) -> dict | None:
    """Pro painel de admin. Existe porque a mensagem de login é genérica:
    quando o próprio dono trava, alguém precisa poder ver a verdade."""
    with _conn() as c:
        linha = c.execute(
            "SELECT usuario, telegram_id, criado_em, ultimo_login FROM usuarios"
            " WHERE usuario_norm = ?", (normalizar(usuario),)).fetchone()
        return dict(linha) if linha else None


def redefinir_senha_admin(usuario: str, senha_nova: str) -> None:
    """Reset sem senha atual. É a saída da lição do espaço no fim da senha:
    sem e-mail de recuperação, sem isto a conta ficaria trancada pra sempre."""
    senha_nova = _limpar_senha(senha_nova)
    if len(senha_nova) < SENHA_MIN:
        raise ErroConta(f"A senha precisa ter pelo menos {SENHA_MIN} caracteres.")
    norm = normalizar(usuario)
    sal = os.urandom(16)
    with _conn() as c:
        linha = c.execute("SELECT telegram_id FROM usuarios WHERE usuario_norm = ?",
                          (norm,)).fetchone()
        if not linha:
            raise ErroConta("Conta não encontrada.")
        c.execute("UPDATE usuarios SET senha_hash = ?, sal = ?, iteracoes = ?"
                  " WHERE usuario_norm = ?",
                  (_hash_senha(senha_nova, sal), sal.hex(), ITERACOES, norm))
        c.execute("DELETE FROM sessoes WHERE telegram_id = ?", (int(linha["telegram_id"]),))
        c.commit()


# =============================================================================
# 🎮 CONVIDADO (28/09, dev): "o método pra começar o jogo como convidado"
# -----------------------------------------------------------------------------
# Um toque e o jogo começa: nasce uma conta SEM usuário e senha, com o mesmo
# tipo de id negativo das contas do site, e uma sessão. O token dessa sessão
# é a ÚNICA chave da conta — ela mora no navegador (localStorage). Por isso:
#   - a sessão do convidado dura anos, não 30 dias: vencer = perder a conta;
#   - "Salvar progresso" (converter_convidado) dá usuário e senha à MESMA
#     conta, sem mover nada: o id continua o mesmo, o personagem também;
#   - limite de convidados por IP por hora, senão um script enche o banco.
# Convidado abandonado fica no banco (sem limpeza automática por enquanto).
# =============================================================================
SESSAO_CONVIDADO = 60 * 60 * 24 * 365 * 5     # 5 anos
CONVIDADOS_POR_IP_HORA = 5


def criar_convidado(ip: str | None = None) -> int:
    agora = int(time.time())
    with _conn() as c:
        c.isolation_level = None
        c.execute("BEGIN IMMEDIATE")          # mesmo cuidado do criar_conta (id por MIN)
        try:
            if ip:
                recentes = c.execute("SELECT COUNT(*) FROM convidados WHERE ip = ? AND criado_em > ?",
                                     (ip, agora - 3600)).fetchone()[0]
                if recentes >= CONVIDADOS_POR_IP_HORA:
                    raise ErroConta("Muitos convidados criados daqui agora. "
                                    "Tente de novo daqui a pouco, ou crie uma conta.")
            telegram_id = _novo_id_web(c)
            c.execute("INSERT INTO convidados(telegram_id, criado_em, ip) VALUES (?,?,?)",
                      (telegram_id, agora, ip))
            c.execute("COMMIT")
        except Exception:
            _desfazer(c)
            raise
    return telegram_id


def eh_convidado(telegram_id: int) -> bool:
    with _conn() as c:
        return c.execute("SELECT 1 FROM convidados WHERE telegram_id = ?",
                         (int(telegram_id),)).fetchone() is not None


def converter_convidado(telegram_id: int, usuario: str, senha: str) -> str:
    """Dá usuário e senha à conta do convidado. O id não muda — personagens,
    clã, itens, tudo continua exatamente onde está."""
    usuario, senha = validar_credenciais(usuario, senha)
    norm = normalizar(usuario)
    sal = os.urandom(16)
    agora = int(time.time())
    with _conn() as c:
        c.isolation_level = None
        c.execute("BEGIN IMMEDIATE")
        try:
            if not c.execute("SELECT 1 FROM convidados WHERE telegram_id = ?", (int(telegram_id),)).fetchone():
                raise ErroConta("Esta conta já tem usuário e senha.")
            c.execute(
                "INSERT INTO usuarios(usuario_norm, usuario, senha_hash, sal, iteracoes,"
                " telegram_id, criado_em, ultimo_login) VALUES (?,?,?,?,?,?,?,?)",
                (norm, usuario, _hash_senha(senha, sal), sal.hex(), ITERACOES,
                 int(telegram_id), agora, agora))
            c.execute("DELETE FROM convidados WHERE telegram_id = ?", (int(telegram_id),))
            c.execute("COMMIT")
        except sqlite3.IntegrityError as e:
            _desfazer(c)
            raise _explicar_integridade(e)
        except Exception:
            _desfazer(c)
            raise
    return usuario
