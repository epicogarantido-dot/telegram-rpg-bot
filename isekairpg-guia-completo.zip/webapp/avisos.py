"""
Caixa de avisos dentro do jogo — substitui as mensagens que o bot mandava.

POR QUE ISSO É OBRIGATÓRIO PRA MIGRAÇÃO
---------------------------------------
Quatro coisas só chegavam ao jogador por mensagem no chat do bot:
Pix confirmado, conta bloqueada por Pix recusado, item vendido no Mercado,
e liberação manual do admin. Desligar o bot sem isto deixaria o jogador
sem saber que o pagamento dele foi liberado — ele veria Arena e Mercado
travados e nenhuma explicação.

BUG ACHADO NO CAMINHO
---------------------
`_pending_notify` (o aviso de "seu item foi vendido") só existe em
core/router.py, o caminho do BOT. Quem compra pelo Mini App nunca dispara
nada, então o vendedor nunca soube. É a armadilha nº 3 do projeto: lógica
do bot que não está no motor compartilhado. Aqui o aviso nasce no lugar
certo e vale pros dois caminhos.

REGRA DE OURO
-------------
Nada aqui pode derrubar uma rota. Aviso é acessório: se a gravação
falhar, a compra, o Pix e a venda continuam valendo. Por isso `avisar()`
engole a própria exceção — de propósito, e é o único lugar do projeto
onde isso é certo.
"""
from __future__ import annotations

import time

from infra.migracao import garantir_colunas, garantir_colunas_async

# 🧱 20/09/2026 — os CREATE deste arquivo viraram constantes pra que a
# MESMA string crie a tabela e migre banco velho (infra/migracao.py).
# Coluna nova entra aqui e chega sozinha em quem já tinha a tabela.
_SQL_AVISOS = """
            CREATE TABLE IF NOT EXISTS avisos (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_id INTEGER NOT NULL,
                tipo        TEXT NOT NULL,
                titulo      TEXT NOT NULL,
                texto       TEXT NOT NULL,
                criado_em   INTEGER NOT NULL,
                lido_em     INTEGER
            );
            CREATE INDEX IF NOT EXISTS idx_avisos_tid ON avisos(telegram_id, id DESC);
        """


# Quantos avisos guardar por jogador. Sem teto, quem joga muito acumula
# milhares de linhas e a tabela vira o maior arquivo do banco.
LIMITE_POR_JOGADOR = 50


def _conn():
    from game.sql_repo import get_connection
    return get_connection()


def init_avisos() -> None:
    with _conn() as c:
        c.executescript(_SQL_AVISOS)
        garantir_colunas(c, _SQL_AVISOS)  # 🧱 migra o que o CREATE tem e o disco não
        c.commit()


def avisar(telegram_id: int, tipo: str, titulo: str, texto: str) -> bool:
    """Guarda um aviso. NUNCA levanta exceção — ver regra de ouro no topo."""
    try:
        agora = int(time.time())
        with _conn() as c:
            c.execute(
                "INSERT INTO avisos(telegram_id, tipo, titulo, texto, criado_em)"
                " VALUES (?,?,?,?,?)",
                (int(telegram_id), tipo, titulo, texto, agora))
            # Poda na hora de escrever, não num faxineiro separado: assim o
            # teto vale mesmo se o processo nunca rodar manutenção.
            c.execute(
                "DELETE FROM avisos WHERE telegram_id = ? AND id NOT IN ("
                "  SELECT id FROM avisos WHERE telegram_id = ? ORDER BY id DESC LIMIT ?)",
                (int(telegram_id), int(telegram_id), LIMITE_POR_JOGADOR))
            c.commit()
        return True
    except Exception as e:
        print(f"⚠️ [AVISOS] não consegui gravar aviso pra {telegram_id}: {e}")
        return False


def listar(telegram_id: int, limite: int = LIMITE_POR_JOGADOR) -> list[dict]:
    try:
        with _conn() as c:
            linhas = c.execute(
                "SELECT id, tipo, titulo, texto, criado_em, lido_em FROM avisos"
                " WHERE telegram_id = ? ORDER BY id DESC LIMIT ?",
                (int(telegram_id), int(limite))).fetchall()
        return [dict(l) for l in linhas]
    except Exception as e:
        print(f"⚠️ [AVISOS] falha ao listar de {telegram_id}: {e}")
        return []


def contar_nao_lidos(telegram_id: int) -> int:
    try:
        with _conn() as c:
            linha = c.execute(
                "SELECT COUNT(*) AS n FROM avisos WHERE telegram_id = ? AND lido_em IS NULL",
                (int(telegram_id),)).fetchone()
        return int(linha["n"] or 0)
    except Exception:
        return 0


def marcar_lidos(telegram_id: int) -> int:
    try:
        agora = int(time.time())
        with _conn() as c:
            cur = c.execute(
                "UPDATE avisos SET lido_em = ? WHERE telegram_id = ? AND lido_em IS NULL",
                (agora, int(telegram_id)))
            c.commit()
            return cur.rowcount or 0
    except Exception as e:
        print(f"⚠️ [AVISOS] falha ao marcar lidos de {telegram_id}: {e}")
        return 0


# ------------------------------------------------------ avisos prontos
# Textos ficam aqui, e não espalhados nas rotas, pra quem mexer depois ver
# todos juntos e manter o tom igual.

def pix_confirmado(telegram_id: int, pedido: str, saldo: int) -> None:
    avisar(telegram_id, "pix", "Pagamento confirmado",
           f"O Pix do pedido {pedido} foi conferido. Seu saldo é {saldo}⭐. "
           f"Arena, Arena dos Pets, Raid e Mercado estão liberados de novo.")


def pix_recusado(telegram_id: int, pedido: str, valor: int) -> None:
    avisar(telegram_id, "pix", "Pagamento não confirmado",
           f"Não consegui confirmar o Pix do pedido {pedido}, e as {valor}⭐ "
           f"foram estornadas. Se você pagou mesmo, fale com o administrador "
           f"com o comprovante em mãos — o pedido fica registrado aqui.")


def item_vendido(telegram_id: int, nome_item: str, preco: int) -> None:
    avisar(telegram_id, "mercado", "Seu item foi vendido",
           f"{nome_item} saiu por {preco}⭐. O valor já está na sua conta.")
