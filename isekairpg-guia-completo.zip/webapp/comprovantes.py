"""
Comprovante de Pix no site — substitui a foto no chat do bot.

Portado do Mestre do Futebol, com as armadilhas que já custaram caro lá
mantidas resolvidas (estão anotadas em cada lugar).

REGRA DE NEGÓCIO — idêntica à do bot, de propósito
--------------------------------------------------
O comprovante credita as ⭐ NA HORA e marca `conta_em_analise`. Enquanto
está em análise ficam bloqueados Arena, Arena dos Pets, Raid e Mercado —
tudo que afeta OUTROS jogadores. O resto do jogo continua liberado.

Se o admin confirma, a trava cai. Se recusa, as ⭐ são estornadas.

⚠️ Esta regra existe em DOIS lugares: aqui e no handler de foto do bot
(main.py). É a armadilha nº 3 do projeto — lógica do bot que não está no
motor compartilhado. Não unifiquei porque o caminho do bot morre no fim
da migração; se por algum motivo ele ficar, unifique antes que as duas
versões divirjam.
"""
from __future__ import annotations

import os
import re
import secrets
import time

PASTA_COMPROVANTES = os.path.join("data", "comprovantes")

# PDF entra porque muito banco só deixa exportar o recibo nesse formato —
# exigir print de tela faria o jogador ter mais trabalho do que precisa.
TIPOS_ACEITOS = {
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "application/pdf": ".pdf",
}
TAMANHO_MAX = 8 * 1024 * 1024

_RE_NOME_SEGURO = re.compile(r"^\d+_-?\d+_[0-9a-f]{8}\.(jpg|png|webp|pdf)$")


class ErroComprovante(Exception):
    pass


# --------------------------------------------------------------- arquivo

def validar_arquivo(conteudo: bytes, content_type: str) -> str:
    ext = TIPOS_ACEITOS.get((content_type or "").split(";")[0].strip().lower())
    if not ext:
        raise ErroComprovante("Mande o comprovante como imagem (JPG, PNG, WEBP) ou PDF.")
    if not conteudo:
        raise ErroComprovante("O arquivo chegou vazio — tente enviar de novo.")
    if len(conteudo) > TAMANHO_MAX:
        raise ErroComprovante("O arquivo é grande demais (máximo 8 MB).")
    return ext


def salvar_arquivo(telegram_id: int, conteudo: bytes, content_type: str) -> str:
    """Devolve o nome gravado. O nome é montado por NÓS, nunca o que veio
    do navegador: nome de arquivo do usuário é entrada hostil — pode vir
    com '../', com barra, ou com extensão que não bate com o conteúdo."""
    ext = validar_arquivo(conteudo, content_type)
    os.makedirs(PASTA_COMPROVANTES, exist_ok=True)
    nome = f"{int(time.time())}_{int(telegram_id)}_{secrets.token_hex(4)}{ext}"
    caminho = os.path.join(PASTA_COMPROVANTES, nome)
    temporario = caminho + ".tmp"
    with open(temporario, "wb") as f:
        f.write(conteudo)
    os.replace(temporario, caminho)     # queda no meio não deixa arquivo pela metade
    return nome


def caminho_do_comprovante(nome: str) -> str:
    """Só aceita o formato exato que salvar_arquivo() gera. Checar apenas
    basename não basta: o que protege de verdade é a lista do que É
    válido, não a lista do que é proibido."""
    if not _RE_NOME_SEGURO.match(nome or ""):
        raise ErroComprovante("Nome de comprovante inválido.")
    caminho = os.path.join(PASTA_COMPROVANTES, nome)
    if not os.path.isfile(caminho):
        raise ErroComprovante("Comprovante não encontrado.")
    return caminho


# ------------------------------------------------------- regra de negócio

def registrar(p: dict, telegram_id: int, nome_arquivo: str) -> dict:
    """Liga o comprovante ao pedido aberto e credita as ⭐.
    Devolve um resumo pro front. Levanta ErroComprovante com texto pronto."""
    from game.premium_system import ensure_premium_player
    from game.premium_system import premium_repo

    pendentes = p.get("pending_orders") or []
    pedido = next((o for o in reversed(pendentes)
                   if o.get("status") == "waiting_payment"), None)
    if not pedido:
        raise ErroComprovante(
            "Você não tem nenhum pedido aberto. Abra a Loja, escolha quantas ⭐ "
            "quer comprar, e só então mande o comprovante.")

    expira = int(pedido.get("expires_at", 0))
    if expira and time.time() > expira:
        pedido["status"] = "expired"
        raise ErroComprovante(
            "Esse pedido expirou. Crie um novo na Loja antes de mandar o comprovante.")

    pedido["status"] = "proof_sent"
    pedido["proof_file"] = nome_arquivo
    pedido["proof_sent_at"] = int(time.time())

    ensure_premium_player(p, user_id=telegram_id)
    player_id = p.get("player_id")
    valor = int(pedido.get("amount", 0))
    ok, novo_saldo = premium_repo.add_premium(
        player_id, valor, f"Pix (em análise) - Pedido {pedido['id']}")

    if not ok:
        # Não estoura: o comprovante ESTÁ salvo e o pedido marcado. Quem
        # resolve é o admin pelo painel. Perder o comprovante porque o
        # crédito falhou seria bem pior que creditar depois.
        return {"ok": True, "creditado": False, "pedido": pedido["id"], "amount": valor,
                "msg": ("Comprovante recebido. O crédito automático não passou, "
                        "então o administrador vai liberar na mão — em geral é rápido.")}

    pedido["status"] = "auto_credited"
    p["premium"] = novo_saldo
    p["conta_em_analise"] = {"order_id": pedido["id"], "amount": valor,
                             "since": int(time.time())}
    return {
        "ok": True, "creditado": True, "pedido": pedido["id"],
        "amount": valor, "saldo": novo_saldo,
        "msg": (f"{valor}⭐ já estão na sua conta pra usar. O pagamento ainda será "
                f"conferido pelo administrador; até lá, Arena, Arena dos Pets, Raid "
                f"e Mercado ficam bloqueados. O resto do jogo segue normal."),
    }


def confirmar(p: dict, telegram_id: int | None = None) -> str:
    analise = p.get("conta_em_analise") or {}
    if not analise:
        return "Esse jogador não está em análise."
    for o in (p.get("pending_orders") or []):
        if o.get("id") == analise.get("order_id"):
            o["status"] = "confirmed"
            o["confirmed_at"] = int(time.time())
    p.pop("conta_em_analise", None)

    # 🔔 O bot mandava mensagem aqui. Sem aviso, o jogador veria Arena e
    # Mercado destravarem sem nunca saber por quê — e, pior, quem ficou
    # esperando não teria como saber que já pode voltar.
    if telegram_id is not None:
        from webapp.avisos import pix_confirmado
        pix_confirmado(int(telegram_id), analise.get("order_id", "?"),
                       int(p.get("premium") or 0))
    return f"Pagamento confirmado. {analise.get('amount', 0)}⭐ liberadas de vez."


def recusar(p: dict, telegram_id: int | None = None) -> str:
    """Desfaz o crédito. Só mexe no que este pedido deu — se o jogador já
    gastou, o saldo fica negativo e aparece no painel, o que é melhor do
    que fingir que não aconteceu."""
    from game.premium_system import premium_repo

    analise = p.get("conta_em_analise") or {}
    if not analise:
        return "Esse jogador não está em análise."
    valor = int(analise.get("amount", 0))
    order_id = analise.get("order_id")

    ok, novo_saldo = premium_repo.add_premium(
        p.get("player_id"), -valor, f"Pix recusado - Pedido {order_id}")
    if ok:
        p["premium"] = novo_saldo

    for o in (p.get("pending_orders") or []):
        if o.get("id") == order_id:
            o["status"] = "rejected"
            o["rejected_at"] = int(time.time())
    p.pop("conta_em_analise", None)

    if telegram_id is not None:
        from webapp.avisos import pix_recusado
        pix_recusado(int(telegram_id), order_id or "?", valor)
    return (f"Pedido recusado e {valor}⭐ estornadas."
            + ("" if ok else " (o estorno automático falhou — confira na mão)"))


# ---------------------------------------------------------------- listagem

def listar_pendentes() -> list[dict]:
    """Quem está esperando revisão. Lê direto do banco em vez de varrer o
    cache: o cache só tem quem jogou recentemente, e justamente quem está
    travado esperando confirmação é quem parou de jogar."""
    import json
    from game.sql_repo import get_connection

    pendentes = []
    with get_connection() as c:
        linhas = c.execute(
            "SELECT telegram_id, username, premium, extra_data FROM players"
            " WHERE extra_data LIKE '%conta_em_analise%'").fetchall()
    for linha in linhas:
        try:
            extra = json.loads(linha["extra_data"] or "{}")
        except (ValueError, TypeError):
            continue
        analise = extra.get("conta_em_analise")
        if not analise:
            continue
        pedido = next((o for o in (extra.get("pending_orders") or [])
                       if o.get("id") == analise.get("order_id")), {})
        pendentes.append({
            "telegram_id": int(linha["telegram_id"]),
            "username": linha["username"] or "(sem nome)",
            "saldo": int(linha["premium"] or 0),
            "order_id": analise.get("order_id"),
            "amount": analise.get("amount"),
            "since": analise.get("since"),
            "arquivo": pedido.get("proof_file"),
        })
    pendentes.sort(key=lambda x: x.get("since") or 0)
    return pendentes


# ------------------------------------------------------------------- admin

def senha_admin() -> str:
    return (os.environ.get("ADMIN_SENHA", "") or "").strip()


def conferir_senha_admin(enviada: str) -> None:
    """Duas armadilhas que faziam a senha CERTA ser recusada no Mestre:

    1. secrets.compare_digest com str só aceita ASCII. Senha com acento ou
       cedilha levantava TypeError e virava erro 500 — parecia painel
       quebrado, não senha fora da faixa. Comparando bytes UTF-8, some.
    2. O servidor fazia .strip() na variável de ambiente e o navegador não
       fazia no que era digitado. O mesmo espaço do teclado de celular que
       tranca a senha do jogador trancava o admin.
    """
    esperada = senha_admin()
    if not esperada:
        raise ErroComprovante("Painel desligado. Defina ADMIN_SENHA no ambiente.")
    if not secrets.compare_digest((enviada or "").strip().encode("utf-8"),
                                  esperada.encode("utf-8")):
        raise ErroComprovante("Senha de administrador incorreta.")
