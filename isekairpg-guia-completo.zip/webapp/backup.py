"""Backup do que não está no deploy.

POR QUE ISTO EXISTE
-------------------
O zip de deploy NUNCA leva `data/` — é regra do projeto, e é a regra certa:
subir o banco junto sobrescreveria o de produção. A consequência é que tudo
que importa de verdade existe em UM lugar só, o disco do servidor:

  data/game.db          jogadores, itens, skills, clãs
  data/premium.db       carteiras de ⭐ (dinheiro de verdade)
  data/player_ids.db    o mapa user_id -> player_id das carteiras
  data/imagens/         as 230 artes espelhadas do Telegram
  data/comprovantes/    os Pix que os jogadores mandaram

Perder qualquer um deles é irreversível, e o premium.db é o pior: apaga
compra que alguém pagou.

⚠️ O PONTO CRÍTICO: NÃO DÁ PRA SÓ COPIAR O ARQUIVO
--------------------------------------------------
SQLite em uso tem escrita em andamento e um WAL à parte. Copiar o .db com
shutil.copy enquanto o jogo roda produz, na melhor hipótese, um arquivo sem
as últimas transações — e, na pior, um banco corrompido que só se descobre
no dia em que se tenta restaurar. Backup que não restaura é pior que não ter
backup, porque dá a sensação de estar protegido.

Por isso o snapshot usa `VACUUM INTO`, que o SQLite executa como uma leitura
consistente, e cai na API `Connection.backup()` (que também é consistente)
quando o SQLite é antigo demais. Nunca copia o arquivo cru.
"""
import os
import shutil
import sqlite3
import tempfile
import time
import zipfile

PASTA_DADOS = "data"

# O que entra no backup. A ordem importa pouco, mas os bancos vêm primeiro
# porque são o que não dá pra reconstruir de jeito nenhum: imagem perdida
# se re-espelha do Telegram, carteira perdida não volta.
BANCOS = ["game.db", "premium.db", "player_ids.db"]
PASTAS = ["comprovantes", "imagens"]


def _caminho(*partes) -> str:
    return os.path.join(PASTA_DADOS, *partes)


def snapshot_sqlite(origem: str, destino: str) -> None:
    """Cópia CONSISTENTE de um SQLite que pode estar em uso.

    Tenta VACUUM INTO (SQLite 3.27+, uma leitura consistente que ainda
    compacta) e cai na API de backup, que faz o mesmo sem compactar. As duas
    respeitam transações em andamento; `shutil.copy` não respeita nenhuma e
    por isso não aparece aqui.
    """
    if os.path.exists(destino):
        os.remove(destino)
    conn = sqlite3.connect(f"file:{origem}?mode=ro", uri=True)
    try:
        try:
            conn.execute("VACUUM INTO ?", (destino,))
            return
        except sqlite3.OperationalError:
            pass  # SQLite antigo; vai pela API de backup
        alvo = sqlite3.connect(destino)
        try:
            conn.backup(alvo)
        finally:
            alvo.close()
    finally:
        conn.close()


def inventario() -> dict:
    """O que existe pra salvar, com tamanho. Serve pro painel mostrar o que
    o backup vai levar ANTES de baixar — um zip de 300 MB no 4G é o tipo de
    surpresa que se evita dizendo o número antes."""
    itens = []
    total = 0
    for nome in BANCOS:
        caminho = _caminho(nome)
        tam = os.path.getsize(caminho) if os.path.exists(caminho) else 0
        total += tam
        itens.append({"nome": nome, "tipo": "banco", "existe": tam > 0,
                      "bytes": tam, "arquivos": 1 if tam else 0})
    for pasta in PASTAS:
        caminho = _caminho(pasta)
        arquivos, tam = 0, 0
        if os.path.isdir(caminho):
            for raiz, _dirs, nomes in os.walk(caminho):
                for n in nomes:
                    arquivos += 1
                    tam += os.path.getsize(os.path.join(raiz, n))
        total += tam
        itens.append({"nome": pasta, "tipo": "pasta", "existe": arquivos > 0,
                      "bytes": tam, "arquivos": arquivos})
    return {"itens": itens, "bytes_total": total}


PREFIXO_TEMP = "isekai_backup_"
IDADE_MAXIMA_TEMP = 3600     # 1 hora


def limpar_temporarios(agora: float | None = None) -> int:
    """Apaga zips de backup antigos do diretório temporário.

    ⚠️ Faxina na ENTRADA, não na saída. A tentação é apagar o zip depois de
    enviar (BackgroundTask), mas download cancelado, conexão caída ou
    processo reiniciado no meio deixam o arquivo pra trás de qualquer jeito
    — e aí o disco do servidor enche justamente por causa da rotina que
    existe pra protegê-lo. Limpar o que ficou da vez passada cobre todos
    esses casos com uma regra só.
    """
    agora = agora or time.time()
    apagados = 0
    pasta = tempfile.gettempdir()
    try:
        nomes = os.listdir(pasta)
    except OSError:
        return 0
    for nome in nomes:
        if not (nome.startswith(PREFIXO_TEMP) and nome.endswith(".zip")):
            continue
        caminho = os.path.join(pasta, nome)
        try:
            if agora - os.path.getmtime(caminho) > IDADE_MAXIMA_TEMP:
                os.remove(caminho)
                apagados += 1
        except OSError:
            pass
    return apagados


def montar_backup(incluir_imagens: bool = True,
                  incluir_comprovantes: bool = True) -> str:
    """Escreve o zip num arquivo temporário e devolve o caminho.

    Em arquivo e não em memória de propósito: as imagens sozinhas passam de
    100 MB, e montar isso num BytesIO derruba um servidor pequeno justamente
    no momento em que se está tentando proteger os dados dele.
    """
    limpar_temporarios()
    carimbo = time.strftime("%Y-%m-%d_%H%M")
    fd, caminho_zip = tempfile.mkstemp(prefix=f"{PREFIXO_TEMP}{carimbo}_", suffix=".zip")
    os.close(fd)

    temp_dir = tempfile.mkdtemp(prefix="snapshot_")
    try:
        with zipfile.ZipFile(caminho_zip, "w", zipfile.ZIP_DEFLATED,
                             allowZip64=True) as z:
            leiame = []
            for nome in BANCOS:
                origem = _caminho(nome)
                if not os.path.exists(origem):
                    leiame.append(f"{nome}: NÃO EXISTIA no momento do backup")
                    continue
                snap = os.path.join(temp_dir, nome)
                snapshot_sqlite(origem, snap)
                z.write(snap, f"data/{nome}")
                leiame.append(f"{nome}: {os.path.getsize(snap):,} bytes (snapshot consistente)")

            pastas = []
            if incluir_comprovantes:
                pastas.append("comprovantes")
            if incluir_imagens:
                pastas.append("imagens")
            for pasta in pastas:
                base = _caminho(pasta)
                if not os.path.isdir(base):
                    leiame.append(f"{pasta}/: não existia")
                    continue
                n = 0
                for raiz, _dirs, nomes in os.walk(base):
                    for arq in nomes:
                        completo = os.path.join(raiz, arq)
                        relativo = os.path.relpath(completo, ".")
                        z.write(completo, relativo)
                        n += 1
                leiame.append(f"{pasta}/: {n} arquivo(s)")

            z.writestr("LEIA-ME.txt", _texto_leiame(carimbo, leiame,
                                                   incluir_imagens,
                                                   incluir_comprovantes))
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
    return caminho_zip


def _texto_leiame(carimbo: str, linhas: list, com_imagens: bool,
                  com_comprovantes: bool) -> str:
    return "\n".join([
        f"BACKUP DO ISEKAIRPG — {carimbo}",
        "=" * 60,
        "",
        "CONTEÚDO",
        *[f"  - {l}" for l in linhas],
        "",
        f"  imagens incluídas: {'sim' if com_imagens else 'NÃO'}",
        f"  comprovantes incluídos: {'sim' if com_comprovantes else 'NÃO'}",
        "",
        "COMO RESTAURAR",
        "  1. Pare o app (o banco não pode estar sendo escrito).",
        "  2. Renomeie a pasta data/ atual pra data_antiga/ — não apague,",
        "     enquanto não tiver certeza de que este backup abre.",
        "  3. Extraia este zip na raiz do app, criando data/ de novo.",
        "  4. Suba o app e confira: entre com uma conta e veja se o ouro,",
        "     o andar e o saldo de ⭐ estão certos.",
        "  5. Só então apague data_antiga/.",
        "",
        "SOBRE OS BANCOS",
        "  Os .db aqui dentro são snapshots consistentes (VACUUM INTO), não",
        "  cópias cruas do arquivo. Cópia crua de SQLite em uso pode vir sem",
        "  as últimas transações ou corrompida — e isso só se descobre na",
        "  hora de restaurar, que é a pior hora possível.",
        "",
        "O QUE NÃO ESTÁ AQUI",
        "  O código. Ele vem do deploy. Este zip é só o que o deploy NÃO",
        "  leva, que é exatamente o que não dá pra recriar.",
        "",
        "  ⚠️ premium.db são carteiras de ⭐ — compras que alguém pagou de",
        "  verdade. Guarde este arquivo em outro lugar que não o servidor.",
    ])
