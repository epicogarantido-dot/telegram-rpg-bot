# webapp/api.py
"""
🌐 API do site (FastAPI). O `main.py` prepara o banco e sobe este `app`
com o uvicorn — é o processo inteiro desde que o bot do Telegram saiu
(20/09/2026).
"""
import os
import time
from pathlib import Path

from fastapi import Body, FastAPI, File, Header, HTTPException, Response, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles



app = FastAPI(title="Isekairpg Mini App API")

# =============================================================================
# 🔒 A TRAVA DO JOGADOR MORRE COM A REQUISIÇÃO
# =============================================================================
# ⚠️ 17/09/2026 — ISTO É O QUE TRAVAVA O JOGO.
#
# A trava por jogador era guardada num `threading.local()` e solta "no
# começo do próximo _carregar_jogador", contando com o threadpool
# reaproveitar a thread. Ele não reaproveita: o FastAPI serve cada
# requisição síncrona numa thread QUALQUER do pool. Então:
#
#   1. GET /api/explore cai na thread 7, pega a trava e responde. Como é
#      rota de leitura, nunca chama _salvar_jogador — a trava fica presa.
#   2. POST /api/explore/go cai na thread 12. Ela não vê nada no
#      thread-local dela, tenta pegar a trava do jogador... e espera para
#      sempre, porque quem pode soltar é a thread 7, e só quando ELA
#      receber outra requisição do mesmo jogador.
#   3. O front fica no "carregando". O jogador recarrega, cada tentativa
#      prende mais uma thread do pool, e quando o pool acaba o processo
#      inteiro para — inclusive o bot, que roda no mesmo event loop.
#
# Medido: 38 rotas pegam a trava e nunca soltam. E qualquer rota de
# escrita que ESTOURE entre carregar e gravar deixa a trava presa do mesmo
# jeito, porque o `finally` mora em _salvar_jogador.
#
# A correção troca o dono da trava: em vez da thread, quem a segura é a
# REQUISIÇÃO. A caixa abaixo é criada no handler (no event loop), viaja
# junto pro threadpool — `anyio.to_thread.run_sync` copia o contexto, e a
# cópia aponta pro MESMO dicionário — e é esvaziada no `finally` do
# handler, tenha a rota gravado, só lido ou estourado no meio.
import contextvars as _contextvars

from fastapi.routing import APIRoute as _APIRoute

_TRAVA_DO_PEDIDO: "_contextvars.ContextVar[dict | None]" = _contextvars.ContextVar(
    "trava_do_pedido", default=None)


class RotaQueSoltaATrava(_APIRoute):
    """Toda rota nasce com isto. É de propósito que não dá pra esquecer:
    a versão anterior dependia de cada rota nova lembrar de soltar, e 38
    esqueceram."""

    def get_route_handler(self):
        original = super().get_route_handler()

        async def handler(request: Request):
            caixa: dict = {"trava": None}
            token = _TRAVA_DO_PEDIDO.set(caixa)
            try:
                return await original(request)
            finally:
                trava = caixa.get("trava")
                if trava is not None:
                    try:
                        trava.release()
                    except RuntimeError:
                        pass      # já estava solta; nada a fazer
                    caixa["trava"] = None
                _TRAVA_DO_PEDIDO.reset(token)

        return handler


app.router.route_class = RotaQueSoltaATrava

STATIC_DIR = Path(__file__).parent / "static"

# 🔥 Injeção do 'bot' do aiogram (evita import circular com main.py — o
# bot só existe DEPOIS que main.py roda, e main.py importa este módulo).


# =============================================================================
# 🔐 AUTENTICAÇÃO — extrai e valida o initData de toda requisição autenticada
# =============================================================================

def _extrair_usuario(authorization: str | None) -> dict:
    """Identidade da requisição: `Authorization: Bearer <token>` da conta do
    site (webapp/contas.py). O login pelo Mini App do Telegram (`tma
    <initData>`) saiu com o bot em 20/09/2026, junto com o webapp/auth.py.
    Nunca deixa passar requisição sem identidade confirmada."""
    if not authorization:
        raise HTTPException(status_code=401, detail="Faltando credencial (header Authorization).")

    # --- novo: conta do site ---
    if authorization.startswith("Bearer "):
        from webapp.contas import sessao_valida
        telegram_id = sessao_valida(authorization[7:].strip())
        if telegram_id is None:
            raise HTTPException(status_code=401, detail="Sessão expirada. Entre de novo.")
        return {"id": telegram_id, "username": ""}

    raise HTTPException(status_code=401, detail="Formato de credencial não reconhecido.")


# =============================================================================
# 🔐 CONTAS DO SITE (migração pra fora do Telegram)
# As rotas abaixo são as ÚNICAS que não exigem sessão — são justamente as
# que criam uma. Todas as outras continuam passando por _extrair_usuario.
# =============================================================================

def _erro_conta(e) -> HTTPException:
    """ErroConta carrega texto pronto pro jogador; qualquer outra exceção
    vira 500 genérico, pra não vazar detalhe de banco na tela."""
    return HTTPException(status_code=400, detail=str(e))


@app.post("/api/auth/registrar")
def post_auth_registrar(corpo: dict | None = Body(None)):
    from webapp.contas import criar_conta, abrir_sessao, ErroConta
    corpo = corpo or {}
    try:
        telegram_id, usuario = criar_conta(
            corpo.get("usuario", ""),
            corpo.get("senha", ""),
            (corpo.get("codigo") or "").strip() or None,
        )
    except ErroConta as e:
        raise _erro_conta(e)

    token, expira = abrir_sessao(telegram_id)
    return {"ok": True, "token": token, "expira_em": expira,
            "usuario": usuario, "vinculado": telegram_id > 0}


@app.post("/api/auth/entrar")
def post_auth_entrar(corpo: dict | None = Body(None)):
    from webapp.contas import conferir_senha, abrir_sessao, ErroConta
    corpo = corpo or {}
    try:
        telegram_id, usuario = conferir_senha(corpo.get("usuario", ""), corpo.get("senha", ""))
    except ErroConta as e:
        raise HTTPException(status_code=401, detail=str(e))

    token, expira = abrir_sessao(telegram_id)
    return {"ok": True, "token": token, "expira_em": expira, "usuario": usuario}


@app.post("/api/auth/convidado")
def post_auth_convidado(request: Request):
    """🎮 (28/09, dev) Começar como convidado: conta sem usuário e senha."""
    from webapp.contas import criar_convidado, abrir_sessao, ErroConta, SESSAO_CONVIDADO
    ip = (request.headers.get("x-forwarded-for") or "").split(",")[0].strip() or (
        request.client.host if request.client else None)
    try:
        telegram_id = criar_convidado(ip)
    except ErroConta as e:
        raise HTTPException(status_code=429, detail=str(e))
    token, expira = abrir_sessao(telegram_id, SESSAO_CONVIDADO)
    return {"ok": True, "token": token, "expira_em": expira, "convidado": True}


@app.post("/api/auth/converter")
def post_auth_converter(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """🎮 Convidado ganha usuário e senha — mesma conta, nada muda de lugar."""
    from webapp.contas import converter_convidado, ErroConta
    usuario = _extrair_usuario(authorization)
    corpo = corpo or {}
    try:
        nome = converter_convidado(int(usuario["id"]), corpo.get("usuario", ""), corpo.get("senha", ""))
    except ErroConta as e:
        raise _erro_conta(e)
    return {"ok": True, "usuario": nome}


@app.post("/api/auth/sair")
def post_auth_sair(authorization: str | None = Header(None)):
    from webapp.contas import fechar_sessao
    if authorization and authorization.startswith("Bearer "):
        fechar_sessao(authorization[7:].strip())
    return {"ok": True}


@app.post("/api/auth/trocar-senha")
def post_auth_trocar_senha(corpo: dict | None = Body(None),
                           authorization: str | None = Header(None)):
    from webapp.contas import trocar_senha, ErroConta
    usuario = _extrair_usuario(authorization)
    corpo = corpo or {}
    try:
        trocar_senha(int(usuario["id"]), corpo.get("senha_atual", ""), corpo.get("senha_nova", ""))
    except ErroConta as e:
        raise _erro_conta(e)
    return {"ok": True, "aviso": "Suas outras sessões foram encerradas."}


@app.get("/api/auth/eu")
def get_auth_eu(authorization: str | None = Header(None)):
    """Usada pelo front no boot: diz se o token guardado ainda vale, e por
    onde a pessoa entrou. Evita mostrar a tela de login pra quem já está
    autenticado."""
    from webapp.contas import eh_convidado
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    return {"ok": True, "telegram_id": telegram_id,
            "origem": "site" if telegram_id < 0 else "telegram",
            "convidado": eh_convidado(telegram_id)}


@app.get("/api/admin/catalogo-imagens")
def get_admin_catalogo_imagens(x_admin_senha: str | None = Header(None),
                               authorization: str | None = Header(None)):
    """O que TEM e o que FALTA de arte, separado por tipo (telas, itens,
    pets, montarias, monstros).

    É uma pergunta diferente da de cima: `/api/admin/imagens` mede o
    espelho (quantas chaves do assets.py já estão em disco) e por
    construção não enxerga a chave que o jogo pede e que nem existe no
    assets.py — foi assim que as 15 montarias passaram despercebidas.
    Aqui a lista sai dos bancos do jogo, não do assets.py.

    Só leitura, e tudo em memória: não baixa nada do Telegram."""
    senha = x_admin_senha
    if not senha and authorization and authorization.startswith("Bearer "):
        senha = authorization[7:]
    _exigir_admin(senha)
    from webapp.catalogo_imagens import montar_catalogo
    return JSONResponse(montar_catalogo())


@app.post("/api/admin/imagens/enviar")
def post_admin_enviar_imagem(corpo: dict | None = Body(None),
                             x_admin_senha: str | None = Header(None),
                             authorization: str | None = Header(None)):
    """📤 Envia (ou troca) a arte de uma chave, direto do painel.

    O arquivo vem em base64 dentro do JSON, e não como multipart, de
    propósito: multipart exige o `python-multipart`, e foi a falta dele
    que já derrubou as 147 rotas de uma vez (armadilha nº 9)."""
    import base64, binascii
    senha = x_admin_senha
    if not senha and authorization and authorization.startswith("Bearer "):
        senha = authorization[7:]
    _exigir_admin(senha)
    from webapp import imagens
    corpo = corpo or {}
    chave = str(corpo.get("chave") or "")
    dados = str(corpo.get("base64") or "")
    if "," in dados[:80]:               # aceita "data:image/png;base64,...."
        dados = dados.split(",", 1)[1]
    try:
        conteudo = base64.b64decode(dados, validate=False)
    except (binascii.Error, ValueError):
        raise HTTPException(status_code=400, detail="O arquivo não chegou inteiro (base64 inválido).")
    r = imagens.gravar_envio(chave, conteudo)
    if not r["ok"]:
        raise HTTPException(status_code=400, detail=r["erro"])
    _image_cache.pop(chave, None)        # a versão velha não pode sair da memória
    return JSONResponse(r)


@app.get("/api/imagens/versoes")
def get_imagens_versoes():
    """Versão de cada arte TROCADA pelo admin. Pública e pequena: o front põe
    `&v=` na URL dessas chaves, e a arte nova aparece sem esperar o cache de
    24h vencer."""
    from webapp.imagens import versoes_enviadas
    return JSONResponse(versoes_enviadas(), headers={"Cache-Control": "no-cache"})


# =============================================================================
# 🎭 CRIAÇÃO DE PERSONAGEM (classe, raça)
# Existia só no bot. `pick_class`/`pick_race` sempre estiveram no motor
# compartilhado, mas nenhuma rota os expunha — então todo mundo que criasse
# conta pelo site ficava SEM CLASSE E SEM RAÇA pra sempre, perdendo o bônus
# de atributo por nível e os modificadores da raça. E como as duas escolhas
# são definitivas, não havia conserto depois.
# =============================================================================

@app.get("/api/character/opcoes")
def get_character_opcoes(authorization: str | None = Header(None)):
    """Classes e raças com o efeito de cada uma — inclusive o negativo.
    Escolha definitiva merece a conta completa na tela, não só o bônus."""
    from game.logic import CLASSESDB, RACESDB
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)

    def formatar(origem):
        saida = []
        for chave, dados in origem.items():
            mods = dados.get("mods") or {}
            saida.append({
                "id": chave,
                "nome": dados.get("name", chave),
                "descricao": dados.get("desc", ""),
                "atributo": dados.get("main_attr"),
                "ganhos": [{"stat": k, "pct": round(v * 100)} for k, v in mods.items() if v > 0],
                "perdas": [{"stat": k, "pct": round(v * 100)} for k, v in mods.items() if v < 0],
            })
        return saida

    # 🖼️ (26/09) a raça mostra a arte do SEXO já escolhido (o sexo virou o
    # 1º passo): STATUS_<RAÇA>_<M|F>, senão STATUS_<RAÇA>. Sem arte da raça
    # enviada, fica sem imagem (o STATUS genérico seria igual pra todas).
    from game.assets import resolver_asset_key_jogador
    racas = formatar(RACESDB)
    for r in racas:
        chave = resolver_asset_key_jogador(r["id"], p.get("sexo"))
        r["img_key"] = None if chave == "STATUS" else chave
    return JSONResponse({
        "classe_atual": p.get("class_id"),
        "raca_atual": p.get("race_id"),
        "sexo_atual": p.get("sexo"),
        "classes": formatar(CLASSESDB),
        "racas": racas,
        # ✨ (28/09, dev) 4º passo: uma habilidade comum da profissão
        "skill_pendente": _skill_inicial_pendente(p),
        # 🌱 nascido na Torre: raça e profissão vieram sorteadas
        "nascido_na_torre": bool(p.get("origem_aldeao")),
        "skills_iniciais": _skills_iniciais(p) if p.get("class_id") else [],
    })


# ✨ (28/09, dev) "cria uma página na criação do personagem com os cards de
# skill pra o jogador escolher uma skill comum da classe dele". Motivo, da
# revisão da experiência inicial: o jogador novo começava SEM habilidade
# nenhuma (skill só vinha de drop, 15% de chance), então na primeira hora
# mago, guerreiro e arqueiro jogavam igual — só "Atacar".
# Oferece as ATIVAS comuns da profissão (3 por profissão, uma por caminho:
# fogo/gelo/raio, espada/luvas/lança...). As passivas comuns (+5% num
# atributo) ficam de fora de propósito: não mudam o que o jogador FAZ na
# luta, que é o problema que isto resolve. Elas seguem caindo como drop.
def _skill_inicial_pendente(p: dict) -> bool:
    # (28/09) só é pendente se HOUVER carta pra escolher: profissão sem ativa
    # comum no catálogo deixaria a criação presa em laço (a tela não tem o
    # que mostrar e a entrada pergunta de novo, pra sempre)
    return (bool(p.get("class_id")) and not p.get("skill_inicial") and not p.get("skills_learned")
            and bool(_skills_iniciais(p)))


def _descrever_skill(sk: dict) -> list[str]:
    """O que a skill faz, em frases — tudo em cima do SEU ataque, que é como
    o combate calcula (use_skill: dano, cura, escudo e regeneração)."""
    pct = lambda v: f"{round(float(v) * 100)}%"
    linhas = []
    todos = sk.get("target") == "all"
    if float(sk.get("mult") or 0) > 0:
        linhas.append(f"Dano de {pct(sk['mult'])} do seu ataque" + (" em todos os inimigos" if todos else ""))
    if sk.get("stun"):
        linhas.append(f"Atordoa o alvo por {int(sk['stun'])} turno(s)")
    if float(sk.get("dot_mult") or 0) > 0:
        linhas.append(f"{sk.get('dot_name', 'Dano contínuo')}: {pct(sk['dot_mult'])} do ataque por turno, "
                      f"{int(sk.get('dot_turns', 0))} turnos")
    if float(sk.get("heal_percent") or 0) > 0:
        linhas.append(f"Cura {pct(sk['heal_percent'])} do seu ataque em vida")
    if float(sk.get("hot_pct") or 0) > 0:
        linhas.append(f"Regenera {pct(sk['hot_pct'])} do ataque por turno, {int(sk.get('hot_turns', 3))} turnos")
    if float(sk.get("shield_pct") or 0) > 0:
        linhas.append(f"Barreira que absorve {pct(sk['shield_pct'])} do seu ataque em dano")
    for chave, nome in (("buff_atk", "Ataque"), ("buff_def", "Defesa"), ("buff_eva", "Esquiva")):
        if float(sk.get(chave) or 0) > 0:
            linhas.append(f"{nome} +{pct(sk[chave])} por {int(sk.get('buff_turns', 3))} turno(s)")
    if sk.get("taunt"):
        linhas.append(f"Provoca: os inimigos te atacam por {int(sk.get('taunt_turns', 2))} turno(s)")
    if float(sk.get("lifesteal_pct") or 0) > 0:
        linhas.append(f"Rouba {pct(sk['lifesteal_pct'])} do dano como vida")
    if float(sk.get("atb_boost") or 0) > 0:
        linhas.append("Adianta o seu próximo turno")
    if sk.get("cooldown"):
        linhas.append(f"Recarga: {int(sk['cooldown'])} turnos")
    return linhas


def _skills_iniciais(p: dict) -> list[dict]:
    from game.skills import SKILL_DB
    classe = str(p.get("class_id") or "").lower()
    saida = []
    for core_id, info in SKILL_DB.items():
        sk = info.get("skill") or {}
        if (int(sk.get("rarity", 0)) == 1 and sk.get("type") == "active"
                and str(sk.get("req_class") or "").lower() == classe):
            saida.append({"id": core_id, "skill_id": sk.get("id"), "nome": sk.get("name", core_id),
                          "efeitos": _descrever_skill(sk)})
    return saida


@app.post("/api/character/skill_inicial")
def post_character_skill_inicial(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """Aprende a skill escolhida pela mecânica de sempre (um core, aprendido
    na hora — mesmo afixo sorteado de quem aprende por drop) e já equipa no
    1º slot. Uma vez só: `skill_inicial` fica gravado."""
    from game.logic import learn_skill_from_core, equip_skill
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    if not _skill_inicial_pendente(p):
        raise HTTPException(status_code=409, detail="A habilidade inicial já foi escolhida.")
    core_id = str((corpo or {}).get("id") or "")
    opcoes = {o["id"]: o for o in _skills_iniciais(p)}
    if core_id not in opcoes:
        raise HTTPException(status_code=400, detail="Essa habilidade não é da sua profissão.")
    cores = p.setdefault("inv", {}).setdefault("cores", {})
    cores[core_id] = int(cores.get(core_id, 0) or 0) + 1
    msg = learn_skill_from_core(p, core_id)
    if "❌" in msg:
        # devolve o core emprestado (o jogador fica em cache na memória)
        resto = int(cores.get(core_id, 1) or 1) - 1
        if resto > 0:
            cores[core_id] = resto
        else:
            cores.pop(core_id, None)
        raise HTTPException(status_code=409, detail=_limpar_html_bot(msg))
    equip_skill(p, opcoes[core_id]["skill_id"], "equipped", 0)
    p["skill_inicial"] = core_id
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True, "msg": _limpar_html_bot(msg), "nome": opcoes[core_id]["nome"]})


# ✏️ (25/09/2026, dev) o jogador escolhe o nome do personagem que pilota.
# No banco real os personagens estavam com o nome VAZIO (a tela mostrava
# "Aventureiro" e o clã, "Personagem Principal"). 3 a 20 caracteres, letras
# (com acento), números, espaço, hífen e apóstrofo; não pode repetir o nome
# de outro jogador (sem diferenciar maiúscula). Muda também o nome nas
# cópias da Arena/Arena de Pets e no membro do clã.
NOME_MIN, NOME_MAX = 3, 20


def _validar_nome(nome: str, telegram_id: int) -> str:
    import re as _re
    from game.sql_repo import get_connection
    nome = _re.sub(r"\s+", " ", str(nome or "")).strip()
    if not (NOME_MIN <= len(nome) <= NOME_MAX):
        raise HTTPException(status_code=400, detail=f"O nome precisa ter de {NOME_MIN} a {NOME_MAX} caracteres.")
    if not _re.fullmatch(r"[0-9A-Za-zÀ-ÖØ-öø-ÿ' -]+", nome):
        raise HTTPException(status_code=400, detail="Use só letras, números, espaço, hífen ou apóstrofo.")
    if not _re.search(r"[A-Za-zÀ-ÖØ-öø-ÿ]", nome):
        raise HTTPException(status_code=400, detail="O nome precisa ter pelo menos uma letra.")
    with get_connection() as conn:
        dono = conn.execute("SELECT telegram_id FROM players WHERE lower(username) = lower(?) AND telegram_id != ?",
                            (nome, int(telegram_id))).fetchone()
    if dono:
        raise HTTPException(status_code=409, detail="Esse nome já é de outro jogador.")
    return nome


@app.post("/api/character/nome")
def post_character_nome(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    import sqlite3 as _sq
    from game.characters import get_active_slot
    telegram_id = int(_extrair_usuario(authorization)["id"])
    nome = _validar_nome((corpo or {}).get("nome"), telegram_id)
    p = _carregar_jogador(telegram_id)
    p["username"] = nome
    _salvar_jogador(telegram_id, p)
    try:
        from game.sql_repo import DB_PATH as _DB
    except ImportError:
        _DB = "data/game.db"
    with _sq.connect(_DB) as c:
        for tabela in ("arena_snapshots", "pet_arena_snapshots"):
            try:
                c.execute(f"UPDATE {tabela} SET username = ? WHERE telegram_id = ?", (nome, telegram_id))
            except _sq.OperationalError:
                pass
        try:
            c.execute("UPDATE clan_membro SET nome = ? WHERE owner_id = ? AND slot = ?",
                      (nome, telegram_id, get_active_slot(telegram_id)))
        except _sq.OperationalError:
            pass
        c.commit()
    return JSONResponse({"ok": True, "nome": nome})


@app.post("/api/character/classe")
def post_character_classe(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    from game.logic import pick_class
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    if not corpo.get("id"):
        raise HTTPException(status_code=400, detail="Faltando 'id' da classe.")
    p = _carregar_jogador(telegram_id)
    msg = pick_class(p, str(corpo["id"]))
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": "❌" not in msg, "msg": msg, "classe": p.get("class_id")})


@app.post("/api/character/raca")
def post_character_raca(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    from game.logic import pick_race
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    if not corpo.get("id"):
        raise HTTPException(status_code=400, detail="Faltando 'id' da raça.")
    p = _carregar_jogador(telegram_id)
    msg = pick_race(p, str(corpo["id"]))
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": "❌" not in msg, "msg": msg, "raca": p.get("race_id")})


@app.post("/api/character/sexo")
def post_character_sexo(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """Escolhe o sexo do personagem — é o que, junto com a raça, decide a
    arte da ficha. Só aceita 'm' ou 'f', e só na criação: depois de
    escolhido não volta atrás, como classe e raça."""
    from game.assets import SEXOS
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    sexo = str(corpo.get("sexo", "")).strip().lower()[:1]
    if sexo not in SEXOS:
        raise HTTPException(status_code=400, detail="Sexo inválido: use 'm' ou 'f'.")
    p = _carregar_jogador(telegram_id)
    if p.get("sexo"):
        raise HTTPException(status_code=409, detail="O sexo do personagem já foi escolhido.")
    p["sexo"] = sexo
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True, "sexo": sexo})


# =============================================================================
# 🏥 HOSPITAL — curar entre andares. Existia só no bot (hospital:heal).
# =============================================================================

@app.post("/api/hospital/heal")
def post_hospital_heal(authorization: str | None = Header(None)):
    from game.logic import hospital_heal
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)
    msg = hospital_heal(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": "❌" not in msg, "msg": msg,
                         "hp": p.get("hp"), "hp_max": p.get("hp_max"),
                         "gold": p.get("gold")})


# =============================================================================
# 📖 TUTORIAL DE PRIMEIRA VEZ + 📜 HISTÓRICO DE COMBATE
# Os dois existiam só no bot. O tutorial aparecia na primeira visita a cada
# tela (13 tópicos) e o site nunca mostrou nenhum. O histórico era a tela
# "combat_history": o app só mostra o último lance, e quem tocou rápido
# demais perdia o que aconteceu sem jeito de recuperar.
# =============================================================================

def _limpar_html_bot(texto: str) -> str:
    """Os textos foram escritos pro parse_mode HTML do Telegram. Aqui vira
    texto puro: o front decide como apresentar. Converter na API e não no
    JS evita ter a mesma tabela de tags nos dois lados."""
    import re
    t = re.sub(r"</?(b|i|u|s|code|pre)>", "", texto or "")
    t = t.replace("━" * 20, "").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    return t.strip()


@app.get("/api/tutorial/{topico}")
def get_tutorial(topico: str, authorization: str | None = Header(None)):
    """Devolve o tutorial e se ele já foi visto. Não marca como visto aqui:
    quem marca é a rota POST, depois que a pessoa realmente fechou a tela.
    Marcar na leitura perderia o tutorial de quem teve a conexão cair no
    meio — e ele só aparece uma vez na vida."""
    from game.tutoriais import HOWTO_TEXTS
    telegram_id = int(_extrair_usuario(authorization)["id"])
    if topico not in HOWTO_TEXTS:
        raise HTTPException(status_code=404, detail=f"Tutorial '{topico}' não existe.")
    p = _carregar_jogador(telegram_id)
    vistos = p.get("tut_seen") or {}
    resposta = {"topico": topico, "visto": bool(vistos.get(topico)),
                "texto": _limpar_html_bot(HOWTO_TEXTS[topico])}
    if topico == "guia_inicio" and not resposta["visto"]:
        resposta["retomar"] = _onde_retomar_guia(p)
    return JSONResponse(resposta)


@app.post("/api/tutorial/{topico}/visto")
def post_tutorial_visto(topico: str, authorization: str | None = Header(None)):
    from game.tutoriais import HOWTO_TEXTS
    telegram_id = int(_extrair_usuario(authorization)["id"])
    if topico not in HOWTO_TEXTS:
        raise HTTPException(status_code=404, detail=f"Tutorial '{topico}' não existe.")
    p = _carregar_jogador(telegram_id)
    p.setdefault("tut_seen", {})[topico] = True
    if topico == "guia_inicio":
        _dar_material_do_guia(telegram_id, p)   # pulou antes da luta: o ferro vem aqui
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True})


@app.get("/api/tutoriais")
def get_tutoriais(authorization: str | None = Header(None)):
    """Todos os tópicos, pra poder reler depois. O do bot só dava uma
    chance: apareceu, fechou, acabou."""
    from game.tutoriais import HOWTO_TEXTS
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    vistos = p.get("tut_seen") or {}
    return JSONResponse({"tutoriais": [
        {"topico": k, "visto": bool(vistos.get(k)), "texto": _limpar_html_bot(v)}
        for k, v in HOWTO_TEXTS.items()]})


@app.get("/api/tower/historico")
def get_tower_historico(authorization: str | None = Header(None)):
    """Histórico completo da luta atual. O bot cortava em 3800 caracteres
    por causa do limite de mensagem do Telegram; aqui esse teto não existe,
    mas mantenho um limite de linhas pra não mandar um combate de mil
    turnos inteiro pro celular de ninguém."""
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    cmb = p.get("combat") or {}
    linhas = [_limpar_html_bot(x) for x in (cmb.get("history") or [])]
    return JSONResponse({"em_combate": bool(cmb.get("enemies")),
                         "total": len(linhas),
                         "linhas": linhas[-200:]})


# =============================================================================
# 🏰 CLÃ — o pilar idle
# O mapa é a própria Torre: cada andar é uma área de AFK, e você só manda
# gente pros andares que já ficaram atrás de você.
#
# O tick roda AQUI, no GET, e não por cronômetro no servidor. Motivo: um
# cronômetro processaria milhares de clãs de gente que não joga há semanas,
# e o resultado seria descartado pelo teto de qualquer jeito. Processar no
# login faz o trabalho só pra quem voltou.
# =============================================================================



def _modelo_de_combate(p: dict, nivel: int, equip: int = 0) -> dict:
    """O dict que o perfil de risco usa pra simular. Só o necessário —
    simular com a ficha inteira não mudaria o resultado e custaria mais."""
    return {"telegram_id": 1, "level": int(nivel), "xp": 0, "xp_next": 9**9,
            "gold": 0, "tower_floor": 1, "hp": 100, "hp_max": 100, "state": "TOWER",
            "class_id": p.get("class_id"), "race_id": p.get("race_id"),
            # O equipamento entra como atributo: é o que faz forjar
            # realmente empurrar a fronteira do membro.
            "attrs": {k: int(nivel) + int(equip) for k in ("str", "vit", "agi", "dex")},
            "trails": {}, "combat": None,
            "inv": {"potion": 0, "cores": {}, "items": {}}, "equip": {},
            "pets": {"owned": {}, "deck": [None] * 5},
            "skills_learned": {}, "skill_slots": {"equipped": [None] * 5},
            "chakra": None}


# =============================================================================
# ⚔️ CULTIVO EM BATALHA (25/09/2026) — ver game/clan_cultivo.py
# O relógio fica em clan_membro.cultivo_json ("tick"), NÃO em p["last_xp_tick"]:
# esse campo nunca foi gravado (não tem coluna e não está em CAMPOS_EXTRAS),
# então o cultivo antigo zerava a cada reinício do servidor.
# =============================================================================
def _cultivo_do_cla(telegram_id: int, p: dict, andar_do_cla: int, rodar: bool = True,
                    agora: int | None = None, rng=None) -> list:
    """Roda o cultivo pendente de cada personagem que está batalhando e
    devolve o estado de todos pra tela. `p` (o personagem ao vivo) é
    alterado aqui; quem chama salva. Os do armário são salvos aqui."""
    import json as _json, random as _random, time as _time
    from game import clan_repo as CR, clan_cultivo as K
    from game.clan_afk import montar_perfil
    from game.characters import (get_active_slot, _carregar_do_armario, _salvar_no_armario,
                                  jogador_do_armario, devolver_ao_armario)
    import game.logic as L
    agora = int(agora or _time.time())
    rng = rng or _random.Random()
    ativo = get_active_slot(telegram_id)
    saida = []
    # 🛡️ (26/09) guardas do clã batalhando: +10% de XP cada (até +100%)
    guardas = sum(1 for h in CR.listar_habitantes(telegram_id) if h.get("funcao") == "guarda")
    for m in CR.listar_membros(telegram_id):
        slot = int(m["slot"])
        snap = None
        if slot == ativo:
            pdata = p
        else:
            snap = _carregar_do_armario(telegram_id, slot)
            pdata = jogador_do_armario(snap)      # linha crua → personagem de verdade
        try:
            est = _json.loads(m.get("cultivo_json") or "{}") or {}
        except ValueError:
            est = {}
        nivel = int((pdata or {}).get("level") or m.get("nivel") or 1)
        # O duelo usa a FICHA DE VERDADE (equipamento, trilhas, skills), não
        # o modelo simplificado do AFK. Medido em 25/09: com o modelo (atributo
        # = nível, sem equipamento) nível 10 perdia 100% das lutas no andar 10
        # e até nível 40 perdia no andar 5 — mandar batalhar seria morte certa.
        # Recalcula quando muda o nível, o andar ou o equipamento.
        import hashlib as _h
        assinatura = _h.md5(_json.dumps([(pdata or {}).get("equip"), (pdata or {}).get("trails"),
                                         (pdata or {}).get("skill_slots")], sort_keys=True,
                                        default=str).encode()).hexdigest()[:10]
        chave = f"{nivel}:{andar_do_cla}:{assinatura}"
        if pdata and est.get("chave") != chave:
            est["perfil"] = montar_perfil(pdata, {"id": f"cultivo_{andar_do_cla}", "andar": andar_do_cla})
            est["chave"] = chave
        perfil = est.get("perfil") or {"chance_morte": 0, "resumo": ""}
        batalhando = bool(m.get("batalhando"))
        mudou_snap = False
        # ⚡ (26/09) XP pelo PODER de combate (e os guardas), não mais pelo andar
        poder = 0
        if pdata:
            try:
                import copy as _copy
                _pc = _copy.deepcopy(pdata)
                L.recalc(_pc)
                poder = L.calc_power_level(_pc)
            except Exception:
                poder = 0
        xp_bloco = K.xp_por_bloco_pelo_poder(poder, guardas)
        # 💤 idle AUTOMÁTICO do personagem ativo: 20 min sem ação e ele entra
        # sozinho (sem risco de morte — é o AFK passivo)
        idle_auto = False
        if rodar and not batalhando and slot == ativo and pdata and not K.ocupado(pdata):
            if not pdata.get("ultima_acao"):
                pdata["ultima_acao"] = agora        # antes do relógio: começa a contar agora
            inicio = K.inicio_do_idle_auto(pdata.get("ultima_acao"), agora)
            if inicio is not None:
                idle_auto = True
                blocos, novo_tick = K.blocos_passados(max(int(est.get("tick") or 0), inicio), agora)
                if blocos:
                    xp = blocos * xp_bloco
                    pdata.pop("_last_xp_capped", None)
                    L.gain_xp(pdata, xp)
                    est["ultimo"] = {"quando": agora, "xp": xp, "lutas": 0, "morreu": False, "auto": True,
                                     "travado": bool(pdata.get("_last_xp_capped"))}
                    est["tick"] = novo_tick
        if rodar and batalhando and pdata and not (slot == ativo and K.ocupado(pdata)):
            blocos, novo_tick = K.blocos_passados(est.get("tick") or agora, agora)
            if blocos:
                r = K.simular(blocos, perfil.get("chance_morte", 0), rng)
                xp = r["blocos"] * xp_bloco
                pdata.pop("_last_xp_capped", None)
                if xp > 0:
                    L.gain_xp(pdata, xp)
                est["ultimo"] = {"quando": agora, "xp": xp, "lutas": r["lutas"], "morreu": r["morreu"],
                                 "travado": bool(pdata.get("_last_xp_capped"))}
                est["tick"] = agora if r["morreu"] else novo_tick
                if r["morreu"]:
                    K.morrer(pdata)
                    batalhando = False
                mudou_snap = True
        with CR._conn() as c:
            c.execute("UPDATE clan_membro SET cultivo_json = ?, batalhando = ?, nivel = ?"
                      " WHERE owner_id = ? AND slot = ?",
                      (_json.dumps(est), int(batalhando), int((pdata or {}).get("level") or nivel),
                       telegram_id, slot))
            c.commit()
        if snap is not None and mudou_snap and pdata:
            devolver_ao_armario(snap, pdata)
            _salvar_no_armario(telegram_id, slot, snap)
        morto = bool(pdata) and (pdata.get("state") == "DEAD" or int(pdata.get("hp", 1) or 0) <= 0)
        saida.append({
            "slot": slot, "nome": m.get("nome") or f"Personagem #{slot}",
            "nivel": int((pdata or {}).get("level") or nivel), "ativo": slot == ativo,
            "existe": bool(pdata), "batalhando": batalhando, "morto": morto,
            "chance_morte": perfil.get("chance_morte", 0),
            "risco_sessao": round(K.risco_da_sessao(perfil.get("chance_morte", 0)) * 100, 1),
            "resumo": perfil.get("resumo", ""),
            "xp_por_hora": 12 * xp_bloco, "poder": poder, "idle_auto": idle_auto,
            "ultimo": est.get("ultimo"),
        })
    return saida


@app.post("/api/clan/cultivo")
def post_clan_cultivo(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """Liga/desliga a batalha de um personagem no andar do clã."""
    import json as _json, time as _time
    from game import clan_repo as CR, clan_cultivo as K
    from game.characters import get_active_slot, _carregar_do_armario
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    slot, batalhar = int(corpo.get("slot", -1)), bool(corpo.get("batalhar"))
    p = _carregar_jogador(telegram_id)
    clan = CR.carregar_clan(telegram_id)
    andar_cla = CR.andar_de_trabalho(clan, int(p.get("tower_floor") or 1))
    # o que já correu até agora conta antes de mudar
    _cultivo_do_cla(telegram_id, p, andar_cla)
    _salvar_jogador(telegram_id, p)
    m = next((x for x in CR.listar_membros(telegram_id) if int(x["slot"]) == slot), None)
    if not m:
        raise HTTPException(status_code=404, detail="Esse personagem não é membro do clã.")
    from game.characters import jogador_do_armario
    pdata = p if slot == get_active_slot(telegram_id) else jogador_do_armario(_carregar_do_armario(telegram_id, slot))
    if batalhar:
        ok, erro = K.pode_batalhar(pdata)
        if not ok:
            raise HTTPException(status_code=409, detail=erro)
    try:
        est = _json.loads(m.get("cultivo_json") or "{}") or {}
    except ValueError:
        est = {}
    if batalhar:
        est["tick"] = int(_time.time())      # só conta dali pra frente
    with CR._conn() as c:
        c.execute("UPDATE clan_membro SET batalhando = ?, cultivo_json = ? WHERE owner_id = ? AND slot = ?",
                  (int(batalhar), _json.dumps(est), telegram_id, slot))
        c.commit()
    return JSONResponse({"ok": True, "cultivo": _cultivo_do_cla(telegram_id, p, andar_cla, rodar=False)})


def _sem_quebrar(rotulo: str, padrao, fn, *args, **kwargs):
    """🛡️ (25/09) As partes NOVAS da rota do clã (batalha, 12h, refúgio,
    busca antiga) não derrubam a página se um dado antigo do banco pegar
    elas de surpresa: a página abre sem aquela parte, e o erro completo vai
    pro log com a marca [clan-novo] pra achar e corrigir a causa."""
    try:
        return fn(*args, **kwargs)
    except Exception:
        import traceback as _tb
        print(f"[clan-novo] {rotulo} falhou:\n{_tb.format_exc()}", flush=True)
        return padrao


def _refugio_do_andar(telegram_id: int, andar: int) -> dict | None:
    """🏕️ O refúgio do andar do clã (1 por andar): ninguém ataca, fica 12h.
    Vai fixo em "Explorar andar" desde que a página do Território saiu."""
    from game import clan_repo as CR
    clan = CR.carregar_clan(telegram_id)
    ref = next((pt for pt in CR.listar_mapa(int(andar)) if pt["seguro"]), None)
    if not ref:
        return None
    aqui = clan.get("ponto_id") and int(clan["ponto_id"]) == int(ref["id"])
    return {"id": ref["id"], "nome": ref["nome"], "ativo": bool(aqui),
            "restante_seg": CR.restante_da_estadia(clan.get("ponto_desde")) if aqui else CR.ESTADIA_SEG,
            "tem_outro_ponto": bool(clan.get("ponto_id")) and not aqui}


def _achados_do_andar(telegram_id: int, andar: int) -> dict:
    """A última busca, se ela for do andar de trabalho; senão, nada (e a
    lista velha é apagada — ela não serve pra mais nada)."""
    from game import clan_repo as CR
    ach = CR.achados_do_cla(telegram_id)
    if ach and int(ach.get("andar") or 0) != int(andar):
        CR._gravar_achados(telegram_id, {})
        return {}
    return ach


def _equipes_para_tela(telegram_id: int, areas: dict) -> list:
    """Cada posto achado no andar do clã, com a equipe que está nele (ou
    nenhuma), o poder da escolta contra a ameaça do andar e quem PODE ir."""
    from game import clan_repo as CR, clan_equipes as E
    equipes = CR.equipes_do_cla(telegram_id)
    habs = {int(h["id"]): h for h in CR.listar_habitantes(telegram_id)}
    saida = []
    # ⚔️ a equipe do ponto do mapa (é ela que marcha e que defende)
    eqp = equipes.get(CR.EQUIPE_DO_PONTO) or {"coletores": [], "guardas": []}
    guardas_p = [habs[i] for i in eqp["guardas"] if i in habs]
    from game import territorio as _T
    seg = CR.ponto(CR.carregar_clan(telegram_id).get("ponto_id") or 0)
    saida.append({"posto_id": CR.EQUIPE_DO_PONTO, "nome": "🚩 Equipe do ponto do mapa", "recurso": None,
                  "especial": "ponto",
                  # 🔮 ponto só de guardas (Veio de Cores): a tela esconde os coletores
                  "so_guardas": bool(seg and _T.TIPOS.get(seg["tipo"], {}).get("so_guardas")),
                  "coletores": [i for i in eqp["coletores"] if i in habs],
                  "guardas": [i for i in eqp["guardas"] if i in habs],
                  "poder": sum(E.poder_do_guarda(g) for g in guardas_p),
                  "ameaca": None, "producao": 0})
    # 🏰 a guarnição da cidade: guardas que ficam em casa
    eqc = equipes.get(CR.EQUIPE_DA_CIDADE) or {"coletores": [], "guardas": []}
    guardas_c = [habs[i] for i in eqc["guardas"] if i in habs]
    saida.append({"posto_id": CR.EQUIPE_DA_CIDADE, "nome": "🏰 Guarnição da cidade", "recurso": None,
                  "especial": "cidade", "so_guardas": True, "coletores": [],
                  "guardas": [i for i in eqc["guardas"] if i in habs],
                  "poder": sum(E.poder_do_guarda(g) for g in guardas_c),
                  "ameaca": None, "producao": 0})
    for pid, a in areas.items():
        eq = equipes.get(pid) or {"coletores": [], "guardas": []}
        recurso, fator_posto = CR.recurso_e_fator_da_equipe(eq, a)
        guardas = [habs[i] for i in eq["guardas"] if i in habs]
        saida.append({"posto_id": pid, "nome": a["nome"], "recurso": recurso,
                      # (25/09) o que o posto dá de bônus e o que a equipe escolheu
                      "recurso_do_posto": E.RECURSO_DO_POSTO.get(a.get("tipo"), "comida"),
                      "bonus_do_posto": recurso == E.RECURSO_DO_POSTO.get(a.get("tipo"), "comida"),
                      "restante_seg": (CR.restante_da_estadia(eq.get("desde"))
                                       if (eq["coletores"] or eq["guardas"]) else None),
                      "coletores": [i for i in eq["coletores"] if i in habs],
                      "guardas": [i for i in eq["guardas"] if i in habs],
                      "poder": sum(E.poder_do_guarda(g) for g in guardas),
                      "ameaca": E.ameaca_do_andar(a["andar"]),
                      "producao": int(fator_posto * sum(E.producao_do_coletor(habs[i], recurso)
                                                        for i in eq["coletores"] if i in habs))})
    return saida


def _vizinhos(p: dict) -> int:
    """🤝 A relação com as aldeias vizinhas (0–100), qualidade dos storylets."""
    from game.storylets import _estado
    return int(_estado(p)["qualidades"].get("vizinhos", 50))


def _ferreiro_para_tela(telegram_id: int) -> dict:
    """⚒️ O plano do ferreiro em cada trilha: o que ele faz agora, quanto
    custa, quanto o clã tem, e o bônus atual e o próximo."""
    from game import clan_repo as CR, clan_ferreiro as F
    habs = CR.listar_habitantes(telegram_id)
    mats = CR.carregar_clan(telegram_id)["materiais"]
    trabalho = CR.trabalho_dos_habitantes(telegram_id)
    saida = {}
    for trilha in F.TRILHAS:
        pl = F.plano(habs, trilha, trabalho)
        lote = pl.get("tier_lote", 1)
        saida[trilha] = {"nome": F.NOME_TRILHA[trilha], "acao": pl["acao"], "tier_lote": lote,
                         "alvo": pl.get("alvo"), "total": pl.get("total", 0), "quem": len(pl.get("quem", [])),
                         "custo": {str(k): v for k, v in pl["custo"].items()},
                         "tem": {str(k): mats.get(int(k), 0) for k in pl["custo"]},
                         "bonus": F.BONUS[trilha][lote],
                         "bonus_proximo": F.BONUS[trilha].get(pl.get("alvo") or lote)}
    return saida


@app.post("/api/clan/defesa")
def post_clan_defesa(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """⚔️ O que a equipe do ponto faz quando outro jogador ataca: lutar ou fugir."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    r = CR.definir_defesa(telegram_id, str((corpo or {}).get("defesa") or ""))
    if not r["ok"]:
        raise HTTPException(status_code=400, detail=r["erro"])
    return JSONResponse(r)


@app.post("/api/clan/guarda_pessoal")
def post_clan_guarda_pessoal(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """⚔️ Põe (ou tira) o SEU personagem de guarda no ponto do clã. De guarda
    ele soma à defesa e não entra na Torre."""
    from game import clan_repo as CR
    from game.clan_batalha import poder_do_personagem
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    ativo = bool((corpo or {}).get("ativo"))
    if ativo and p.get("combat"):
        raise HTTPException(status_code=409, detail="Termine o combate na Torre antes de ir pra guarda.")
    p["de_guarda"] = ativo
    poder = poder_do_personagem(int(p.get("level") or 1)) if ativo else 0
    CR.definir_guarda_pessoal(telegram_id, poder)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True, "de_guarda": ativo, "poder": poder})


def _reliquias_para_tela(telegram_id: int) -> dict:
    from game import clan_repo as CR
    from game.clan_reliquias import RELIQUIAS, SLOTS, CHANCE_POR_EQUIPE
    d = CR.reliquias_do_cla(telegram_id)
    return {"slots": SLOTS, "chance": CHANCE_POR_EQUIPE, "total": len(RELIQUIAS),
            "acervo": [{"id": k, **RELIQUIAS[k], "ativa": k in d["ativas"]} for k in d["acervo"]]}


@app.post("/api/clan/reliquia")
def post_clan_reliquia(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """🏺 Ativa ou guarda uma relíquia (o clã sustenta 3 ativas)."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    r = CR.ativar_reliquia(telegram_id, str(corpo.get("reliquia") or ""), bool(corpo.get("ativa")))
    if not r["ok"]:
        raise HTTPException(status_code=409, detail=r["erro"])
    return JSONResponse(r)


@app.post("/api/clan/ferreiro")
def post_clan_ferreiro(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """⚒️ Nivela os novos ou evolui o lote de uma trilha (ferramenta/equipamento)."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    r = CR.usar_ferreiro(telegram_id, str((corpo or {}).get("trilha") or ""))
    if not r["ok"]:
        raise HTTPException(status_code=409, detail=r["erro"])
    return JSONResponse(r)


def _manutencao_para_tela(telegram_id: int) -> dict:
    from game import clan_repo as CR, clan_equipes as E
    return {"custo": E.manutencao_da_aldeia(CR.listar_habitantes(telegram_id)),
            "precos": E.PRECO_OUTRAS_ALDEIAS}


def _exigir_fora_da_guarda(p: dict) -> None:
    """⚔️ Chamado no começo de toda rota da Torre/combate. 26/09/2026 (dev):
    em vez de RECUSAR quem está de guarda ou batalhando no clã, o personagem
    SAI SOZINHO das atividades do clã (guarda pessoal e batalha no andar) e
    o aviso vai pro log da Torre. Também marca a última ação — é dela que
    conta o idle automático (20 min sem jogar)."""
    import time as _t
    from game import clan_repo as CR
    from game.characters import get_active_slot
    tid = int(p.get("telegram_id") or p.get("user_id") or 0)
    p["ultima_acao"] = int(_t.time())
    avisos = []
    if p.get("de_guarda"):
        p["de_guarda"] = False
        if tid:
            CR.definir_guarda_pessoal(tid, 0)
        avisos.append("saiu da guarda do clã")
    if tid:
        try:
            slot = get_active_slot(tid)
            with CR._conn() as c:
                n = c.execute("UPDATE clan_membro SET batalhando = 0 WHERE owner_id = ? AND slot = ? AND batalhando = 1",
                              (tid, slot)).rowcount
                c.commit()
            if n:
                avisos.append("parou de batalhar no andar do clã")
        except Exception:
            pass
    if avisos:
        p["_aviso_cla"] = "⚔️ Pra lutar na Torre, seu personagem " + " e ".join(avisos) + "."


def _exploracao_do_cla(telegram_id: int, andar_do_cla: int) -> list:
    """Só o andar onde o clã está: é lá que ele domina e procura."""
    from game import clan_repo as CR, clan_postos as P
    descobertos = CR.postos_descobertos(telegram_id)
    saida = []
    for andar in (int(andar_do_cla),):
        faltam = P.escondidos(andar, descobertos)
        if faltam:
            saida.append({"andar": andar, "escondidos": len(faltam),
                          "custo": P.custo_exploracao(andar),
                          # o que PODE existir ali (a lista conforme o andar),
                          # não o que vai sair — isso é sorte
                          "pode_ter": [P.TIPOS_POSTO[t]["icone"] for t in faltam]})
    return saida


@app.post("/api/clan/explorar")
def post_clan_explorar(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """🔎 Uma equipe (com guarda) explora o andar do clã: custa comida, pode ser
    emboscada, e volta com 5 achados. Explorar de novo refaz a lista."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    r = CR.explorar_com_equipe(telegram_id, str((corpo or {}).get("equipe") or ""),
                               int(p.get("tower_floor") or 1))
    if not r["ok"]:
        raise HTTPException(status_code=409, detail=r["erro"])
    from game import diarias as D
    D.contar(p, "clan_explorar")               # 📅 conta pra diária
    _salvar_jogador(telegram_id, p)
    return JSONResponse(r)


@app.post("/api/clan/achado")
def post_clan_achado(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """🔎 Leva a equipe que explorou pro achado escolhido (posto, ponto do
    mapa ou cidade de outro clã)."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    clan = CR.carregar_clan(telegram_id)
    nome = clan.get("nome") or p.get("name") or "Clã"
    r = CR.escolher_achado(telegram_id, int((corpo or {}).get("indice", -1)), nome,
                           int(p.get("tower_floor") or 1))
    if not r.get("ok"):
        raise HTTPException(status_code=409, detail=r.get("erro") or "Não deu.")
    return JSONResponse(r)


@app.get("/api/clan")
def get_clan(authorization: str | None = Header(None)):
    """Estado do clã + o que aconteceu enquanto você não estava."""
    _extrair_usuario(authorization)          # sessão conferida aqui, na porta da rota
    return _tela_do_cla(authorization, receber=False)


@app.post("/api/clan/receber")
def post_clan_receber(authorization: str | None = Header(None)):
    """🎁 (28/09, dev) "um botão de receber recompensa e aí uma janela de
    notificação com o que se conseguiu". Roda a sessão AFK que a tela segurou
    e devolve, além do clã, o resumo do que entrou (`recompensa`)."""
    _extrair_usuario(authorization)          # sessão conferida aqui, na porta da rota
    return _tela_do_cla(authorization, receber=True)


def _resumo_da_recompensa(relatorio: dict, cultivo: list, cores: list, desde: int) -> dict:
    """O que a janela mostra: só o que ENTROU (e o que marcou a sessão).
    Saldo negativo de um recurso (a manutenção comeu mais do que veio) não
    aparece como ganho."""
    from game.items import core_name
    from game.clan_materiais import RANKS
    itens = []
    for chave, icone, nome in (("comida", "🍖", "Comida"), ("madeira", "🪵", "Madeira"), ("couro", "🟫", "Couro")):
        q = int(relatorio.get(chave) or 0)
        if q > 0:
            itens.append({"icone": icone, "texto": nome, "valor": f"+{q}"})
    for r, q in sorted((relatorio.get("materiais") or {}).items(), key=lambda x: int(x[0])):
        if int(q) > 0:
            itens.append({"icone": "⛏️", "texto": RANKS.get(int(r), {}).get("nome", f"Material rank {r}"),
                          "valor": f"+{int(q)}"})
    contagem = {}
    for cid in cores or []:
        contagem[cid] = contagem.get(cid, 0) + 1
    for cid, q in contagem.items():
        nome = core_name(cid)
        itens.append({"icone": "💎", "texto": nome if nome != cid else cid, "valor": f"+{q}", "raro": True})
    for x in cultivo or []:
        u = x.get("ultimo") or {}
        if int(u.get("quando") or 0) >= desde and (int(u.get("xp") or 0) > 0 or u.get("travado") or u.get("morreu")):
            if u.get("morreu"):
                itens.append({"icone": "⚰️", "texto": f"{x['nome']} caiu batalhando", "valor": "", "ruim": True})
            elif u.get("travado"):
                itens.append({"icone": "🔒", "texto": f"{x['nome']}: XP travado no nível máximo do andar", "valor": ""})
            else:
                itens.append({"icone": "⭐", "texto": f"XP de {x['nome']}", "valor": f"+{int(u['xp'])}"})
    aldeia = relatorio.get("aldeia") or {}
    for nome in aldeia.get("despertaram") or []:
        itens.append({"icone": "✨", "texto": f"{nome} despertou a aura!", "valor": "", "raro": True})
    for nome in aldeia.get("chegou") or []:
        itens.append({"icone": "🏠", "texto": f"{nome} chegou à aldeia", "valor": ""})
    reliquia = (relatorio.get("equipes") or {}).get("reliquia")
    if reliquia:
        itens.append({"icone": "🏺", "texto": f"Relíquia: {reliquia.get('nome')}", "valor": "", "raro": True})
    if aldeia.get("ataque"):
        itens.append({"icone": "⚔️", "texto": "A aldeia foi atacada", "valor": "", "ruim": True})
    for m in relatorio.get("mortos") or []:
        itens.append({"icone": "⚰️", "texto": f"{m.get('nome')} morreu", "valor": "", "ruim": True})
    # O que a aldeia GASTOU pra se manter: sessão sem ganho nenhum não pode
    # virar janela vazia — o jogador precisa ver que a aldeia comeu e não
    # produziu (é o sinal pra montar equipes).
    gastos = []
    if int(relatorio.get("consumido") or 0) > 0:
        gastos.append({"icone": "🍖", "texto": "Comida consumida", "valor": f"-{int(relatorio['consumido'])}"})
    for chave, icone, nome in (("madeira", "🪵", "Madeira"), ("couro", "🟫", "Couro")):
        if int(relatorio.get(chave) or 0) < 0:
            gastos.append({"icone": icone, "texto": f"{nome} gasta", "valor": str(int(relatorio[chave]))})
    ticks = int(relatorio.get("ticks") or 0)
    dica = None
    if not any(not x.get("ruim") for x in itens):
        dica = "Sem ganhos nesta sessão: monte equipes de coleta em Clã → Equipes pra aldeia produzir enquanto você não está."
    return {"horas": round(ticks * 15 / 60, 1), "itens": itens, "gastos": gastos, "dica": dica,
            "greve": list(((relatorio.get("equipes") or {}).get("greve")) or [])}


def _tela_do_cla(authorization: str | None, receber: bool):
    from game import clan_repo as CR
    from game import clan_habitantes as H
    from game.clan_materiais import RANKS, COMODIDADES, bonus_do_clan, teto_de_comida

    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    # 🔒 (26/09/2026, dev) o clã é BLOQUEADO até a fundação — a crônica que
    # acontece quando o jogador tenta subir pro 2º andar. Quem já passou do
    # 1º andar antes disso é marcado como fundado (garantir_fundacao).
    from game import cronicas as _K0
    CR.carregar_clan(telegram_id)
    _K0.garantir_fundacao(telegram_id, p)
    if not _K0.fundado(CR.carregar_clan(telegram_id)):
        return JSONResponse({"bloqueado": True,
                             "motivo": "O clã nasce quando você subir pro 2º andar da Torre."})
    CR.sincronizar_com_slots(telegram_id)
    # 🌅 (25/09) a página da Fundação saiu: o clã que nunca fundou ganha o que
    # ela dava sem perguntas (o velho do portão, madeira/couro/ferro, humor
    # 50 e a flag que os storylets leem) — e todo clã sobe pra 50 aldeões.
    from game.clan_fundacao import aplicar_fundacao, fundacao_feita as _fundou
    if not _fundou(p):
        _res = aplicar_fundacao(p, {})
        CR.fundar_aldeia(telegram_id, _res.get("gente", []), _res.get("extras", {}))
        _salvar_jogador(telegram_id, p)
    CR.garantir_populacao_inicial(telegram_id)

    andar = int(p.get("tower_floor") or 1)
    # 🧭 O clã trabalha só até o andar onde ESTÁ (travessia leva adiante).
    areas = CR.areas_do_cla(telegram_id, andar)
    recolhidos = CR.recolher_fora_do_alcance(telegram_id, areas)
    membros = CR.listar_membros(telegram_id)
    modelos = {m["slot"]: _modelo_de_combate(p, m.get("nivel") or 1,
                                             m.get("equip_poder") or 0) for m in membros}

    # 🎁 (28/09, dev) com 15 min ou mais fora (1 tick), a tela SEGURA a
    # sessão: mostra o botão "Receber recompensa", e só o toque roda a sessão
    # (POST /api/clan/receber) — aí a janela mostra o que entrou. Menos que
    # isso (reabrir a tela) roda como sempre, sem cerimônia.
    _inicio_receber = int(__import__("time").time())
    _ticks_pend, _ = CR.quantos_ticks(CR.carregar_clan(telegram_id))
    segurar = _ticks_pend > 0 and not receber
    if segurar:
        relatorio = {"ticks": 0}
    else:
        relatorio = CR.rodar_afk(telegram_id, areas, modelos)
    # ⏳ depois de a sessão render: o que passou das 12h volta pra casa
    estadias = _sem_quebrar("estadias 12h", {"equipes": [], "refugio": None},
                            CR.expirar_estadias, telegram_id)
    clan = CR.carregar_clan(telegram_id)
    membros = CR.listar_membros(telegram_id)

    # 🥇 OURO DA SESSÃO. `rodar_afk` só calcula (não tem `p`); quem soma e
    # salva é aqui, que já carregou o personagem pra montar os `modelos`.
    ganho_ouro = int(relatorio.get("ouro", 0))
    if ganho_ouro:
        p["gold"] = int(p.get("gold", 0)) + ganho_ouro
    # 🔮 cores do Veio de Cores → inventário do personagem
    cores_ganhas = list(relatorio.get("cores") or [])
    if cores_ganhas:
        inv_cores = p.setdefault("inv", {}).setdefault("cores", {})
        for cid in cores_ganhas:
            inv_cores[cid] = int(inv_cores.get(cid, 0)) + 1

    # 🌾 COMPRA AUTOMÁTICA DE COMIDA. Só dispara quando a SESSÃO que acabou
    # de rodar (não uma reabertura da tela) deixou gente faminta — famintos
    # é o sinal de que a produção não bastou, não o celeiro estar baixo (um
    # celeiro baixo com todo mundo bem alimentado não é emergência).
    compra_auto = None
    regras_clan = clan.get("regras") or {}
    if relatorio.get("ticks") and regras_clan.get("compra_comida_auto") and relatorio.get("famintos"):
        limite = int(regras_clan.get("limite_ouro_comida", H.REGRAS_PADRAO["limite_ouro_comida"]))
        gasto_max = min(limite, int(p.get("gold", 0)))
        if gasto_max > 0:
            r = CR.comprar_comida(telegram_id, gasto_max // max(1, CR.custo_comida(1)))
            if r.get("ok") and r.get("comprado"):
                p["gold"] = max(0, int(p["gold"]) - int(r["custo_ouro"]))
                compra_auto = {"comprado": r["comprado"], "custo_ouro": r["custo_ouro"]}
                clan = CR.carregar_clan(telegram_id)  # comida mudou

    # 🛒 (26/09) compra automática de MATERIAIS (madeira, couro, ferro)
    compra_materiais = None
    if relatorio.get("ticks") and (clan.get("regras") or {}).get("compra_materiais_auto"):
        rm = CR.compra_automatica_de_materiais(telegram_id, int(p.get("gold", 0)), _vizinhos(p))
        if rm["custo_ouro"]:
            p["gold"] = max(0, int(p["gold"]) - int(rm["custo_ouro"]))
            compra_materiais = rm
            clan = CR.carregar_clan(telegram_id)

    # ⚔️ cultivo em batalha: XP (e risco) de quem ficou lutando no andar
    cultivo = _sem_quebrar("cultivo", [], _cultivo_do_cla, telegram_id, p,
                           CR.andar_de_trabalho(clan, andar), not segurar)
    cultivo_mexeu_em_p = any(x["ativo"] and x.get("ultimo") for x in cultivo)
    if ganho_ouro or compra_auto or compra_materiais or cores_ganhas or cultivo_mexeu_em_p:
        _salvar_jogador(telegram_id, p)

    # 📖 (26/09) CRÔNICAS: a fundação (antes do 2º andar) e, se a sessão
    # andou, os FATOS dela viram gatilhos (ver game/cronicas.py).
    from game import cronicas as _K
    _sem_quebrar("fundação", None, _K.garantir_fundacao, telegram_id, p)
    if int((relatorio or {}).get("ticks") or 0) > 0:
        _agora = int(__import__("time").time())
        fatos = {"sessao": True, "andar": int(p.get("tower_floor") or 1)}
        if (estadias or {}).get("equipes"):
            fatos["equipe_voltou"] = {}
        if ((relatorio.get("equipes") or {}).get("greve")):
            fatos["baixa"] = {}
        if ((relatorio.get("aldeia") or {}).get("ataque")):
            fatos["ataque"] = {}
        caidos = [x["nome"] for x in cultivo if (x.get("ultimo") or {}).get("morreu")
                  and int((x.get("ultimo") or {}).get("quando") or 0) >= _agora - 5]
        if caidos:
            fatos["morte_cultivo"] = {"alvo": caidos[0]}
        _sem_quebrar("crônicas", None, _K.avancar_sessao, telegram_id, fatos, p)
        _salvar_jogador(telegram_id, p)

    distribuicao = CR.distribuir_equipamento(telegram_id)
    from game.clan_fundacao import humor, descrever_humor, fundacao_feita
    clan_andar = int(clan.get("andar") or 1)
    return JSONResponse({
        "gold": p.get("gold", 0),
        # 🎁 sessão esperando o toque em "Receber" / o que entrou nela
        "recompensa_pendente": ({"horas": round(min(_ticks_pend, CR.TETO_TICKS) * 15 / 60, 1)}
                                if segurar else None),
        "recompensa": (_resumo_da_recompensa(relatorio, cultivo, cores_ganhas, _inicio_receber)
                       if receber else None),
        # 🧭 onde o clã está e até onde trabalha; e quem voltou do posto
        # porque o clã ainda não alcança aquele andar
        "andar_do_cla": clan_andar,
        "andar_de_trabalho": CR.andar_de_trabalho(clan, andar),
        "cultivo": cultivo,
        "cronicas_pendentes": len(_K.carregar(CR.carregar_clan(telegram_id))["fila"]),
        "guerras": _K.guerras_ativas(CR.carregar_clan(telegram_id)),
        "estadias_encerradas": estadias,
        "refugio": _sem_quebrar("refúgio", None, _refugio_do_andar, telegram_id, clan_andar),
        "recolhidos": recolhidos,
        # 🔎 onde ainda dá pra explorar: andares alcançados com posto escondido
        "exploracao": _exploracao_do_cla(telegram_id, CR.andar_de_trabalho(clan, andar)),
        # 🔎 a última busca (5 achados) e o preço de explorar de novo
        # 25/09/2026: só a busca do andar ONDE O CLÃ ESTÁ. A lista ficava
        # gravada depois da Travessia e a tela mostrava postos de um andar
        # que o clã já deixou — e escolher um deles só dava erro.
        "achados": _sem_quebrar("achados", {}, _achados_do_andar, telegram_id,
                                CR.andar_de_trabalho(clan, andar)),
        "custo_busca": __import__("game.clan_explorar", fromlist=["x"]).custo_da_busca(
            CR.andar_de_trabalho(clan, andar)),
        "madeira_busca": __import__("game.clan_explorar", fromlist=["x"]).madeira_da_busca(
            CR.andar_de_trabalho(clan, andar)),
        "equipes": _equipes_para_tela(telegram_id, areas),
        "ferreiro": _ferreiro_para_tela(telegram_id),
        "reliquias": _reliquias_para_tela(telegram_id),
        "reliquia_nova": ((relatorio.get("equipes") or {}).get("reliquia")),
        "defesa": clan.get("defesa") or "lutar",
        "de_guarda": bool(p.get("de_guarda")),
        "guarda_pessoal": int(clan.get("guarda_pessoal") or 0),
        "greve": ((relatorio.get("equipes") or {}).get("greve") or []),
        "manutencao": _manutencao_para_tela(telegram_id),
        "compra_comida_auto": compra_auto,
        "compra_materiais_auto": compra_materiais,
        # O humor muda QUAIS eventos aparecem. Mostrar a faixa por nome e não
        # só o número é o que faz o jogador entender que o clã está diferente
        # — "inquieto" diz o que está acontecendo, "34" não diz nada.
        "humor": descrever_humor(humor(p)),
        "fundacao_feita": fundacao_feita(p),
        # A situação SEMPRE vai, tenha rodado tick ou não. Antes o jogador
        # só via o clã quando voltava depois de um tempo: reabrir a tela
        # zerava o relatório e sobrava uma lista de membros sem contexto.
        "situacao": CR.situacao_do_cla(telegram_id, clan, CR.listar_membros(telegram_id)),
        # E o histórico das últimas sessões, gravado no banco. Sem isto,
        # "o que aconteceu enquanto eu não estava" durava uma requisição.
        "diario": clan.get("diario") or [],
        "comida": clan["comida"],
        "madeira": clan.get("madeira", 0),
        "couro": clan.get("couro", 0),
        # O teto vai junto do valor: "48 de comida" não diz nada sozinho, e
        # é o par 48/120 que explica pra que serve construir o Celeiro.
        "teto_comida": (relatorio.get("teto_comida")
                        or teto_de_comida(clan["comodidades"], CR.bocas_do_cla(telegram_id))),
        "racao_por_membro": CR.TETO_TICKS // CR.RACAO_TICKS,
        "ganho_ouro_sessao": ganho_ouro,
        "arsenal": clan["arsenal"],
        # Quem ficou com o quê. Como a distribuição é automática, mostrar o
        # resultado é o que impede parecer que a forja não fez nada.
        "distribuicao": distribuicao,
        "materiais": [{"rank": r, "nome": RANKS[r]["nome"],
                       "cor": RANKS[r]["cor"], "qtd": clan["materiais"].get(r, 0)}
                      for r in sorted(RANKS)],
        "comodidades": clan["comodidades"],
        "bonus": bonus_do_clan(clan["comodidades"]),
        "catalogo_comodidades": COMODIDADES,
        "membros": [{"slot": m["slot"], "nome": m["nome"], "nivel": m["nivel"],
                     "area_id": m["area_id"], "fome": m["fome"],
                     "ferimento": m["ferimento"],
                     "equip_poder": m.get("equip_poder") or 0,
                     "equip_rank": m.get("equip_rank"),
                     "perfil": (m.get("perfil") or {}).get("resumo"),
                     "chance_morte": (m.get("perfil") or {}).get("chance_morte")}
                    for m in membros],
        "mortos": [{"nome": m["nome"], "causa": m["causa_morte"], "quando": m["morreu_em"]}
                   for m in CR.listar_membros(telegram_id, incluir_mortos=True)
                   if not m["vivo"]],
        "areas": list(areas.values()),
        "situacoes": clan["situacoes"],
        # 🏘️ A aldeia viva: quem mora, em que estágio ela está e o livro de
        # Memórias. Vai inteira em toda abertura da tela do clã, como a
        # situação — reabrir a tela não pode esconder a própria aldeia.
        "aldeia_viva": _aldeia_viva(telegram_id, clan),
        # O relatório é o que transforma "24 ticks processados" em história.
        "afk": {"ticks": relatorio["ticks"], "descartados": relatorio.get("descartados", 0),
                "comida": relatorio.get("comida", 0),
                # 🐛 madeira e couro nunca vinham aqui: o diário do front lia
                # `afk.madeira`/`afk.couro` e sempre dava undefined, então o
                # "O clã trouxe..." escondia dois dos quatro recursos.
                "madeira": relatorio.get("madeira", 0),
                "couro": relatorio.get("couro", 0),
                "ouro": ganho_ouro,
                "cores": cores_ganhas,
                "saque": ((relatorio.get("equipes") or {}).get("saque") or {}),
                "reliquia": ((relatorio.get("equipes") or {}).get("reliquia")),
                "compra_auto": compra_auto,
                "materiais": relatorio.get("materiais", {}),
                "mortos": relatorio.get("mortos", []),
                # A ração aparece no diário porque ela é a conta que o
                # jogador precisa pra decidir: quem ficou sem comer hoje é
                # quem farma mais raso amanhã.
                "consumido": relatorio.get("consumido", 0),
                "racao": relatorio.get("racao", 0),
                "famintos": relatorio.get("famintos", []),
                "perdido": relatorio.get("perdido", 0),
                # 🏘️ o que a aldeia fez na mesma sessão (produção, ataque,
                # despertar, chegada). Sem isto, o diário contava só a
                # metade de quem luta e a aldeia trabalhava invisível.
                "aldeia": ({k: (relatorio.get("aldeia") or {}).get(k)
                            for k in ("producao", "frases", "ataque", "despertaram", "chegou")}
                           if relatorio.get("aldeia") else None),
                "eventos": relatorio.get("eventos", [])[-20:]},
    })


@app.get("/api/clan/previsao")
def get_clan_previsao(slot: int, area_id: str, authorization: str | None = Header(None)):
    """O perfil de risco ANTES de mandar. Com morte permanente, mandar sem
    ver a conta é armadilha, não aposta."""
    from game import clan_repo as CR
    from game.clan_afk import montar_perfil

    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    areas = CR.areas_do_cla(telegram_id, int(p.get("tower_floor") or 1))
    area = areas.get(area_id)
    if not area:
        raise HTTPException(status_code=404, detail="Essa área não está disponível pra você.")
    membro = next((m for m in CR.listar_membros(telegram_id) if m["slot"] == int(slot)), None)
    if not membro:
        raise HTTPException(status_code=404, detail="Membro não encontrado (ou já morreu).")

    # A previsão tem que ser a do membro COMO ELE ESTÁ. Mostrar a chance do
    # cavaleiro alimentado e mandar o faminto é exatamente a armadilha que
    # esta tela existe pra evitar.
    modelo = CR.penalizar_modelo(
        _modelo_de_combate(p, membro.get("nivel") or 1, membro.get("equip_poder") or 0),
        membro)
    perfil = montar_perfil(modelo, area)
    return JSONResponse({"slot": slot, "area": area, "perfil": perfil,
                         "fome": membro.get("fome") or 0,
                         "ferimento": membro.get("ferimento") or 0})


@app.post("/api/clan/posto")
def post_clan_posto(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    if corpo.get("slot") is None:
        raise HTTPException(status_code=400, detail="Faltando 'slot'.")
    # 🧭 Só posto que o clã alcança (o andar onde ele está).
    if corpo.get("area_id"):
        p = _carregar_jogador(telegram_id)
        if corpo["area_id"] not in CR.areas_do_cla(telegram_id, int(p.get("tower_floor") or 1)):
            raise HTTPException(status_code=409,
                                detail="O clã ainda não alcança esse andar — atravesse até lá primeiro.")
    # 🧭 Durante a jornada os lutadores estão na estrada, não no posto.
    if corpo.get("area_id") and CR.jornada_atual(telegram_id):
        raise HTTPException(status_code=409,
                            detail="O clã está numa jornada — os lutadores voltam quando ela acabar.")
    CR.definir_posto(telegram_id, int(corpo["slot"]),
                     corpo.get("area_id") or None, corpo.get("posto_id") or None)
    return JSONResponse({"ok": True})


@app.post("/api/clan/forjar")
def post_clan_forjar(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    from game import clan_repo as CR
    from game.clan_materiais import custo_equipamento, poder_do_equipamento, EQUIPAMENTO
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    rank = int(corpo.get("rank") or 0)
    if rank not in EQUIPAMENTO:
        raise HTTPException(status_code=400, detail="Rank de equipamento inválido.")

    clan = CR.carregar_clan(telegram_id)
    custo = custo_equipamento(rank, clan["comodidades"])
    if not CR.gastar_material(telegram_id, rank, custo):
        tem = clan["materiais"].get(rank, 0)
        raise HTTPException(status_code=409,
                            detail=f"Falta material rank {rank}: você tem {tem}, "
                                   f"precisa de {custo}. Ele cai nos andares "
                                   f"{EQUIPAMENTO[rank]['nome']}.")
    # A peça vai pro ARSENAL do clã, não pra um membro. Quem recebe é
    # decidido na distribuição automática, que roda em toda sessão — assim
    # forjar hoje já beneficia quem for o melhor amanhã.
    poder = poder_do_equipamento(rank)
    CR.guardar_peca(telegram_id, rank, poder)
    atribuicao = CR.distribuir_equipamento(telegram_id)
    recebeu = next((a for a in atribuicao if a["rank"] == rank), None)
    return JSONResponse({"ok": True, "rank": rank, "custo": custo, "poder": poder,
                         "distribuicao": atribuicao,
                         "msg": f"{EQUIPAMENTO[rank]['nome']} forjado (+{poder} de poder)"
                                + (f" e entregue a {recebeu['nome']}." if recebeu else ".")})


@app.post("/api/clan/construir")
def post_clan_construir(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    import json as _json
    from game import clan_repo as CR
    from game.clan_materiais import COMODIDADES
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    chave = corpo.get("comodidade")
    dados = COMODIDADES.get(chave)
    if not dados:
        raise HTTPException(status_code=400, detail="Comodidade desconhecida.")

    clan = CR.carregar_clan(telegram_id)
    from game.clan_materiais import nivel_da_comodidade, custo_do_proximo_nivel
    por_niveis = bool(dados.get("niveis"))
    nivel_atual = nivel_da_comodidade(clan["comodidades"], chave)
    if por_niveis:
        # 🏠 (25/09) por níveis: o preço é o do PRÓXIMO nível
        if nivel_atual >= int(dados.get("nivel_max", 20)):
            raise HTTPException(status_code=409, detail=f"{dados['nome']} já está no nível máximo.")
        _metal, _madeira = custo_do_proximo_nivel(chave, nivel_atual)
        dados = dict(dados, custo=_metal, madeira=_madeira)
    elif clan["comodidades"].get(chave):
        raise HTTPException(status_code=409, detail=f"{dados['nome']} já está construída.")

    # ⚠️ CONFERE OS DOIS ANTES DE GASTAR QUALQUER UM.
    #
    # Construção custa metal E madeira. Descontar o metal e só então
    # descobrir que falta madeira cobraria por uma construção que não
    # aconteceu — e não há rota de reembolso. Por isso a checagem vem
    # inteira antes do primeiro débito.
    # 👷 Mão de obra contratada baixa o custo dos DOIS materiais — e só é
    # consumida se a construção sair.
    custo_metal, custo_madeira = CR.custo_com_mao_de_obra(
        clan, dados["custo"], int(dados.get("madeira", 0)))
    dados = dict(dados, custo=custo_metal)
    if int(clan.get("madeira", 0)) < custo_madeira:
        raise HTTPException(status_code=409,
                            detail=f"Falta madeira: você tem {clan.get('madeira', 0)}, "
                                   f"precisa de {custo_madeira}. Ela cai nos andares "
                                   f"3, 11 e 31.")
    if clan["materiais"].get(dados["rank"], 0) < dados["custo"]:
        tem = clan["materiais"].get(dados["rank"], 0)
        raise HTTPException(status_code=409,
                            detail=f"Falta metal rank {dados['rank']}: você tem {tem}, "
                                   f"precisa de {dados['custo']}.")

    if not CR.gastar_material(telegram_id, dados["rank"], dados["custo"]):
        # Corrida com outra requisição do mesmo jogador: a trava por jogador
        # torna isso quase impossível, mas "quase" não é motivo pra gastar
        # madeira em seguida.
        raise HTTPException(status_code=409, detail="O metal acabou de sair do estoque.")
    with CR._conn() as c:
        c.execute("UPDATE clan SET madeira = MAX(0, madeira - ?) WHERE owner_id = ?",
                  (custo_madeira, telegram_id))
        c.commit()
    clan["comodidades"][chave] = (nivel_atual + 1) if por_niveis else True
    with CR._conn() as c:
        c.execute("UPDATE clan SET comodidades = ? WHERE owner_id = ?",
                  (_json.dumps(clan["comodidades"]), telegram_id))
        c.commit()
    if float(clan.get("mao_de_obra") or 0):
        CR.consumir_mao_de_obra(telegram_id)
    if por_niveis:
        return JSONResponse({"ok": True, "msg": f"{dados['nome']} nível {nivel_atual + 1}: "
                                               f"+{dados.get('valor', 0)} no limite de aldeões."})
    return JSONResponse({"ok": True, "msg": f"{dados['nome']} construída. {dados['porque']}"})


# =============================================================================
# 📜 DECISÕES, CONSELHO E SAGA — o pilar 1 dentro do pilar 3
# Copiado do Six Ages / King of Dragon Pass, e as três peças são a mesma
# ideia vista de ângulos diferentes:
#
#   DECISÕES — o AFK guarda as situações; você resolve ao voltar.
#   CONSELHO — os conselheiros opinam com VIÉS, e a perícia de quem executa
#              é o que vai ser testado. É isso que faz "quem senta no
#              conselho" ser decisão em vez de sabor.
#   SAGA     — o log de causa vira história legível. Sem ela, um arco de
#              oito turnos acontece e ninguém percebe que foi um arco.
# =============================================================================

def _conselheiros_do_clan(telegram_id: int) -> list:
    """Os membros vivos do clã são o conselho. Não é uma lista à parte: quem
    aconselha é quem você tem, e perder alguém no AFK tira do conselho
    junto — que é o peso que a morte permanente deveria ter."""
    from game import clan_repo as CR
    saida = []
    for m in CR.listar_membros(telegram_id):
        nivel = int(m.get("nivel") or 1)
        equip = int(m.get("equip_poder") or 0)
        # A perícia sai do que o membro é: quem está equipado e subiu de
        # nível executa melhor. Assim investir nele vale duas vezes.
        saida.append({
            "id": f"slot{m['slot']}", "nome": m["nome"], "slot": m["slot"],
            "pericias": {"autoridade": max(1, nivel // 6 + equip // 10),
                         "lealdade": max(1, nivel // 8 + 1),
                         "astucia": max(1, nivel // 10 + equip // 14)},
            # O viés vem do posto: quem guarda o celeiro valoriza comida,
            # quem patrulha valoriza medo. Conselho honesto seria dica;
            # conselho enviesado é informação que precisa ser pesada.
            "valoriza": ({"comida": 1.0, "moral": 0.5} if not m.get("area_id")
                         else {"medo": 1.0, "territorios": 0.8}),
            "fala_padrao": ("Guarde o que temos." if not m.get("area_id")
                            else "Quem hesita perde o terreno."),
        })
    return saida


def _situacao_da_vez(telegram_id: int, p: dict, clan: dict, catalogo: dict) -> tuple:
    """Delega pra `clan_repo.situacao_da_vez` (onde mora a explicação do bug
    da fila) e salva o jogador se o sorteio mexeu no estado de storylets."""
    from game import clan_repo as CR
    sit, fila, mexeu_no_jogador = CR.situacao_da_vez(telegram_id, p, catalogo)
    if mexeu_no_jogador:
        _salvar_jogador(telegram_id, p)
    return sit, fila


@app.get("/api/clan/cronicas")
def get_clan_cronicas(authorization: str | None = Header(None)):
    """📖 (26/09) A fila das Crônicas, com custo e chance de cada escolha."""
    from game import clan_repo as CR, cronicas as K
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    CR.carregar_clan(telegram_id)
    # o clã nasce igual, entrando por aqui ou pelo Resumo: 50 aldeões e a
    # reserva antes da fundação (senão a fundação dava recurso pra 3 bocas)
    CR.sincronizar_com_slots(telegram_id)
    CR.garantir_populacao_inicial(telegram_id)
    K.garantir_fundacao(telegram_id, p)
    clan = CR.carregar_clan(telegram_id)
    st = K.carregar(clan)
    return JSONResponse({"fila": K.fila_publica(telegram_id), "guerras": K.guerras_ativas(clan),
                         "fundado": K.fundado(clan), "sessao": st["sessao"],
                         "historico": list(reversed(st["historico"][-8:]))})


@app.post("/api/clan/cronicas")
def post_clan_cronicas(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    from game import cronicas as K
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    p = _carregar_jogador(telegram_id)
    r = K.resolver(telegram_id, int(corpo.get("uid", -1)), int(corpo.get("opcao", -1)), p)
    if not r.get("ok"):
        raise HTTPException(status_code=409, detail=r.get("erro") or "Não deu.")
    _salvar_jogador(telegram_id, p)          # espírito ganho numa crônica mora em p
    return JSONResponse(r)


# 🧹 26/09/2026: as rotas do sistema antigo de decisões saíram —
# /api/clan/decisoes, /api/clan/decidir, /api/clan/fundacao (GET/POST),
# /api/clan/saga e /api/clan/conselho. As histórias agora são as Crônicas
# (/api/clan/cronicas); a fundação é a crônica do 1º andar.

def _aldeia_viva(telegram_id: int, clan: dict) -> dict:
    from game import clan_repo as CR
    from game import clan_habitantes as H
    from game import clan_equipes as E
    todos = CR.listar_habitantes(telegram_id, incluir_mortos=True)
    vivos = [h for h in todos if h["vivo"]]
    estagio = H.estagio_da_aldeia(len(vivos), clan.get("comodidades") or {})
    cfg = CR.config_da_aldeia(clan)
    mods = H.modificadores_da_aldeia(vivos, cfg)
    estagio["capacidade"] += mods["capacidade"]
    nomes = {h["id"]: h["nome"] for h in todos}
    cargo_de = {int(v): k for k, v in (cfg["comandantes"] or {}).items()
                if k in mods["chefes"]}

    def resumo(h):
        faixa, fator = H.faixa_de_fadiga(h["fadiga"])
        return {"id": h["id"], "nome": h["nome"], "profissao": h["profissao"],
                "titulo": H.titulo_da_profissao(h), "nivel": h["nivel"],
                "nivel_max": H.nivel_maximo(h), "potencial": h["potencial"],
                # 👥 talentos (0★ = não pode), função e equipe
                "talentos": h.get("talentos") or {}, "funcao": h.get("funcao"),
                # ⭐ XP até o próximo nível (0 quando está no teto)
                "xp": int(h.get("xp") or 0),
                "xp_proximo": (0 if int(h["nivel"]) >= H.nivel_maximo(h)
                               else H.XP_POR_NIVEL * int(h["nivel"])),
                "equipe": h.get("equipe"),
                "fadiga": h["fadiga"], "faixa": faixa, "fator": fator,
                "descansando": bool(h["descansando"]), "aura": h["aura"],
                # O que ele rende AGORA, por sessão cheia — o número que
                # decide se vale mandar descansar.
                "rende": round(H.producao_do_tick(h, mods) * CR.TETO_TICKS, 1),
                # "material_r1" é chave interna; a tela mostra "material rank 1".
                "produz": (lambda x: (f"material rank {x[len('material_r'):]}"
                                      if x and x.startswith("material_r") else x))(
                    H.PROFISSOES.get(h["profissao"], {}).get("produz")),
                # Família e cargo: o que faz a linha ser uma PESSOA e não um
                # número — e os dois mudam o que acontece num ataque e na
                # produção, então não são enfeite.
                "familia": (f"{h['laco']} de {nomes.get(h['parente_de'], '?')}"
                            if h.get("parente_de") and h.get("laco") else None),
                "cargo": (H.CARGOS[cargo_de[h["id"]]]["nome"] if h["id"] in cargo_de else None),
                # ⚔️✨ (28/09) cavaleiro (e quanto falta de treino) / desperto
                # que pode virar personagem
                "cavaleiro": bool(h.get("cavaleiro")),
                "treino_horas": max(0, (int(h.get("treino_ate") or 0) - int(time.time()) + 3599) // 3600),
                # 💰 soldo que falta (em horas); 0 = sem soldo, parado na cidade
                "soldo_horas": (max(0, (int(h.get("soldo_ate") or 0) - int(time.time())) // 3600)
                                if h.get("cavaleiro") else None),
                "soldo_dia": E.SOLDO_CAVALEIRO_DIA if h.get("cavaleiro") else None,
                "pode_virar_personagem": bool(int(h.get("aura") or 0)) and not h.get("cavaleiro")}

    return {
        "estagio": estagio,
        "habitantes": [resumo(h) for h in vivos],
        # Memorial: a aldeia lembra quem perdeu, com a causa. Morte sem
        # porquê, com morte permanente, é arbitrária (mesma regra dos lutadores).
        "memorial": [{"nome": h["nome"], "causa": h.get("causa"), "quando": h.get("morreu_em")}
                     for h in todos if not h["vivo"]],
        "memorias": (clan.get("memorias") or [])[:30],
        "profissoes": {k: {"nome": v["nome"], "icone": v["icone"], "produz": v["produz"]}
                       for k, v in H.PROFISSOES.items()},
        "custo_recrutar": __import__("game.clan_aldeia", fromlist=["SERVICOS"]).SERVICOS["recrutar"]["ouro"],
        "defesa": H.defesa_da_aldeia(vivos, estagio["indice"], mods),
        "cargos": {k: {"nome": v["nome"], "exige": v["exige"],
                       "chefe": mods["chefes"].get(k)} for k, v in H.CARGOS.items()},
        "especializacoes": {"escolhidas": cfg["especializacoes"],
                            "vagas": H.vagas_de_especializacao(estagio["indice"]),
                            "custo_troca": H.CUSTO_TROCAR_ESPECIALIZACAO,
                            "catalogo": {k: {"nome": v["nome"], "icone": v["icone"],
                                             "efeito": v["efeito"]}
                                         for k, v in H.ESPECIALIZACOES.items()}},
        "regras": {**H.REGRAS_PADRAO, **(cfg["regras"] or {})},
    }


# 🧹 26/09/2026: /api/clan/habitante/acolher (recrutar por comida) saiu —
# recrutar é só pelo serviço da aldeia, em ouro.

@app.get("/api/clan/territorio")
def get_clan_territorio(authorization: str | None = Header(None)):
    """O mapa compartilhado, com a SUA chance de tomar cada ponto.

    A chance vai calculada no servidor, com a força do clã medida agora e a
    defesa de cada dono (bot ou jogador) — o jogador não precisa fazer
    conta nenhuma pra saber onde vale marchar."""
    from game import clan_repo as CR, territorio as T
    telegram_id = int(_extrair_usuario(authorization)["id"])
    clan = CR.carregar_clan(telegram_id)
    forca = CR.forca_atual(telegram_id)
    forcas_de_jogador: dict[int, int] = {}
    pontos = []
    # 🗺️ Só o andar onde o clã está (e o ponto dele, se ficou em outro): o
    # clã só toma e segura ponto do próprio andar, e o mundo tem ~1.100.
    do_andar = CR.listar_mapa(int(clan.get("andar") or 1))
    if clan.get("ponto_id") and all(p_["id"] != clan["ponto_id"] for p_ in do_andar):
        meu_pt = CR.ponto(clan["ponto_id"])
        if meu_pt:
            do_andar.append(meu_pt)
    for pt in do_andar:
        dono_jog = int(pt["dono_id"]) if pt["dono_tipo"] == "jogador" else None
        eh_meu = dono_jog == telegram_id or (pt["seguro"] and clan.get("ponto_id") == pt["id"])
        if dono_jog and dono_jog != telegram_id and dono_jog not in forcas_de_jogador:
            forcas_de_jogador[dono_jog] = CR.forca_atual(dono_jog)
        defesa = T.defesa_do_ponto(pt, forcas_de_jogador.get(dono_jog))
        info = T.SEGURO if pt["seguro"] else T.TIPOS[pt["tipo"]]
        pontos.append({
            "id": pt["id"], "tipo": pt["tipo"], "nome": pt["nome"], "tier": pt["tier"],
            "andar": T.andar_do_ponto(pt), "seguro": bool(pt["seguro"]),
            # ⚔️ só dá pra tomar/abrigar no andar onde o clã está
            "no_andar": T.andar_do_ponto(pt) == int(clan.get("andar") or 1),
            "so_guardas": bool(info.get("so_guardas")),
            "icone": info["icone"],
            # 📈 o ponto dá BÔNUS no que o clã tira (+100% a +150% pelo tier)
            "bonus": T.bonus_do_ponto(pt),
            "dono": pt["dono_nome"], "dono_tipo": pt["dono_tipo"], "meu": bool(eh_meu),
            "integridade": pt["integridade"], "estado": T.estado_do_ponto(pt["integridade"]),
            "defesa": defesa,
            "chance": 1.0 if pt["seguro"] else round(T.chance_de_vencer(forca, defesa), 3),
            "custo": 0 if pt["seguro"] else T.custo_de_ataque(pt["tier"]),
        })
    return JSONResponse({"forca": forca, "ponto_id": clan.get("ponto_id"),
                         "andar_do_cla": int(clan.get("andar") or 1),
                         "comida": clan["comida"], "pontos": pontos,
                         "tipos": {k: {"nome": v["nome"], "icone": v["icone"]}
                                   for k, v in T.TIPOS.items()}})


@app.post("/api/clan/territorio/conquistar")
def post_clan_conquistar(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    from game import clan_repo as CR
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    if corpo.get("id") is None:
        raise HTTPException(status_code=400, detail="Faltando 'id'.")
    clan = CR.carregar_clan(telegram_id)
    p = _carregar_jogador(telegram_id)
    _soltar_trava_pendente()
    nome = clan.get("nome") or f"Clã de {p.get('username') or 'alguém'}"
    r = CR.conquistar_ponto(telegram_id, int(corpo["id"]), nome)
    if not r["ok"]:
        raise HTTPException(status_code=400, detail=r["erro"])
    return JSONResponse(r)


@app.post("/api/clan/territorio/abandonar")
def post_clan_abandonar(authorization: str | None = Header(None)):
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    r = CR.abandonar_ponto(telegram_id)
    if not r["ok"]:
        raise HTTPException(status_code=400, detail=r["erro"])
    return JSONResponse(r)


def _andar_max(p: dict) -> int:
    """O andar mais fundo que o jogador já alcançou. `tower_floor` é onde ele
    ESTÁ; se um dia descer, o máximo não pode cair junto — por isso fica
    guardado em `andar_max` (em CAMPOS_EXTRAS)."""
    return max(int(p.get("tower_floor") or 1), int(p.get("andar_max") or 1))


def _lutadores_da_travessia(p: dict, telegram_id: int) -> list:
    """A ficha de combate de cada membro vivo, pelo MESMO modelo do AFK
    (`_modelo_de_combate` + `logic.recalc`) — quem não aguenta um andar no
    AFK também não o atravessa."""
    import game.logic as L
    from game import clan_repo as CR, clan_jornada as J
    clan = CR.carregar_clan(telegram_id)
    lutadores = []
    for m in CR.listar_membros(telegram_id):
        if not int(m.get("vivo", 1)):
            continue
        modelo = _modelo_de_combate(p, m.get("nivel") or 1, int(m.get("equip_poder") or 0))
        L.recalc(modelo)
        lutadores.append(J.lutador(m["slot"], m.get("nome") or f"Membro {m['slot']}", modelo))
    return lutadores


def _jornada_para_tela(t: dict | None) -> dict | None:
    from game import clan_jornada as J
    if not t:
        return None
    campos = ("origem", "destino", "tempo", "turno", "comida", "tatica", "turno_da_batalha",
              "batalhas_vencidas", "reforcos", "espolio_couro", "abatidos", "fim")
    saida = {k: t.get(k) for k in campos}
    saida["espolio_material"] = t.get("espolio_material", {})
    saida["limite"] = J.LIMITE_BATALHA
    saida["grupo"] = [{k: m[k] for k in ("nome", "hp", "hp_max")} for m in t["grupo"]]
    saida["inimigos"] = [{k: e[k] for k in ("nome", "tipo", "hp", "hp_max")} for e in t["inimigos"]]
    saida["taticas"] = {k: v["nome"] for k, v in J.TATICAS.items()}
    saida["custo_comer"] = J.CUSTO_REFEICAO * len(J.de_pe(t))
    saida["log"] = t["log"][-10:]
    return saida


@app.get("/api/clan/jornada")
def get_clan_jornada(authorization: str | None = Header(None)):
    """🧭 A travessia em andamento, ou a próxima possível (só UM andar à frente
    do clã, e só se o jogador já chegou lá na Torre)."""
    from game import clan_repo as CR, clan_jornada as J
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    andar_max = _andar_max(p)
    if int(p.get("andar_max") or 0) != andar_max:
        p["andar_max"] = andar_max
        _salvar_jogador(telegram_id, p)
    t = CR.jornada_atual(telegram_id)
    if t:
        return JSONResponse({"jornada": _jornada_para_tela(t)})
    clan = CR.carregar_clan(telegram_id)
    origem = int(clan.get("andar") or 1)
    destino = J.andar_permitido(origem, andar_max)
    lutadores = _lutadores_da_travessia(p, telegram_id)
    postos = [m for m in CR.listar_membros(telegram_id) if int(m.get("vivo", 1)) and m.get("area_id")]
    info = {"jornada": None, "andar_do_cla": origem, "andar_max": andar_max,
            "destino": destino, "comida": clan["comida"], "em_posto": len(postos),
            "lutadores": [{"nome": l["nome"], "hp_max": l["hp_max"], "atk": l["atk"], "def": l["def"]}
                          for l in lutadores]}
    if destino:
        n = len(lutadores)
        info.update({"tempo": J.tempo_da_travessia(destino), "limite": J.LIMITE_BATALHA,
                     "chefe": destino % 5 == 0,
                     "comida_min": J.racoes_necessarias(destino, n),
                     "comida_max": J.comida_maxima(destino, n),
                     # referência: o lutador "no ponto" pra esse andar (régua do AFK)
                     "nivel_referencia": 2 * destino})
    return JSONResponse(info)


@app.post("/api/clan/jornada/partir")
def post_clan_jornada_partir(corpo: dict | None = Body(None),
                             authorization: str | None = Header(None)):
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    r = CR.iniciar_jornada(telegram_id, _lutadores_da_travessia(p, telegram_id),
                           int((corpo or {}).get("comida") or 0), _andar_max(p))
    if not r["ok"]:
        raise HTTPException(status_code=400, detail=r["erro"])
    return JSONResponse({"jornada": _jornada_para_tela(r["jornada"])})


@app.post("/api/clan/jornada/acao")
def post_clan_jornada_acao(corpo: dict | None = Body(None),
                           authorization: str | None = Header(None)):
    """avancar (1 turno) · seguir (até algo pedir atenção) · tatica · comer ·
    recuar. Se a travessia acabar aqui, o resultado é entregue na hora."""
    import random as _r
    from game import clan_repo as CR, clan_jornada as J
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    t = CR.jornada_atual(telegram_id)
    if not t:
        raise HTTPException(status_code=409, detail="Nenhuma travessia em andamento.")
    acao = str(corpo.get("acao") or "")
    rng = _r.Random()
    try:
        if acao == "avancar":
            J.avancar(t, rng, 1)
        elif acao == "seguir":
            J.avancar(t, rng, 60, parar_em_evento=True)
        elif acao == "tatica":
            J.mudar_tatica(t, str(corpo.get("tatica") or ""))
        elif acao == "comer":
            if not J.comer(t):
                raise HTTPException(status_code=409, detail="Não há comida na carroça pra essa refeição.")
        elif acao == "recuar":
            J.recuar(t)
        else:
            raise HTTPException(status_code=400, detail="Ação desconhecida.")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    resposta = {}
    if t.get("fim"):
        final = CR.encerrar_jornada(telegram_id, t)
        # 🪙 (20/09) a Travessia não dá ouro: o espólio é couro (vai pro clã)
        resposta["final"] = final
    else:
        CR.gravar_jornada(telegram_id, t)
    resposta["jornada"] = _jornada_para_tela(t)
    return JSONResponse(resposta)


@app.post("/api/clan/chefe")
def post_clan_chefe(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """Nomeia (ou tira, com id nulo) o chefe de um cargo."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    hab_id = corpo.get("id")
    r = CR.nomear_chefe(telegram_id, str(corpo.get("cargo", "")),
                        None if hab_id is None else int(hab_id))
    if not r["ok"]:
        raise HTTPException(status_code=400, detail=r["erro"])
    return JSONResponse(r)


@app.post("/api/clan/especializacao")
def post_clan_especializacao(corpo: dict | None = Body(None),
                             authorization: str | None = Header(None)):
    """Dá (ou troca, pagando ouro) uma identidade à aldeia.

    O ouro é do PERSONAGEM: esta rota carrega `p`, passa o saldo pra
    `escolher_especializacao` decidir se dá, e só debita se ela aprovar —
    `clan_repo` continua sem saber o que é `p`."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    p = _carregar_jogador(telegram_id)
    r = CR.escolher_especializacao(telegram_id, str(corpo.get("especializacao", "")),
                                   corpo.get("trocar"), ouro_disponivel=p.get("gold", 0))
    if not r["ok"]:
        raise HTTPException(status_code=400, detail=r["erro"])
    if r.get("custo_ouro"):
        p["gold"] = int(p.get("gold", 0)) - int(r["custo_ouro"])
        _salvar_jogador(telegram_id, p)
        r["gold"] = p["gold"]
    return JSONResponse(r)


@app.post("/api/clan/regras")
def post_clan_regras(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """Regras de automação da aldeia: descanso automático e compra
    automática de comida (as duas em `game.clan_habitantes.REGRAS_PADRAO`)."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    return JSONResponse(CR.definir_regras(telegram_id, corpo or {}))


@app.post("/api/clan/habitante/mudar")
def post_clan_habitante_mudar(corpo: dict | None = Body(None),
                              authorization: str | None = Header(None)):
    """Troca a profissão (zera o nível) ou alterna o descanso."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    if corpo.get("id") is None:
        raise HTTPException(status_code=400, detail="Faltando 'id'.")
    descansar = corpo.get("descansar")
    r = CR.mudar_habitante(telegram_id, int(corpo["id"]),
                           profissao=corpo.get("profissao"),
                           descansar=None if descansar is None else bool(descansar))
    if not r["ok"]:
        raise HTTPException(status_code=400, detail=r["erro"])
    return JSONResponse(r)


@app.get("/api/clan/aldeia")
def get_clan_aldeia(authorization: str | None = Header(None)):
    """🥇 20/09/2026: os serviços custam ouro do PERSONAGEM, não bronze do
    clã — por isso esta rota agora carrega `p` também, só pra devolver o
    saldo (nenhuma escrita aqui, é rota de leitura)."""
    from game import clan_repo as CR
    from game import clan_habitantes as H
    from game.clan_equipes import PRECO_OUTRAS_ALDEIAS, preco_de_outra_aldeia
    from game.clan_aldeia import SERVICOS, FONTES_OURO
    from game.clan_materiais import RANKS, teto_de_comida
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    clan = CR.carregar_clan(telegram_id)
    membros = len(CR.listar_membros(telegram_id))
    teto = teto_de_comida(clan["comodidades"], CR.bocas_do_cla(telegram_id))
    return JSONResponse({
        "gold": p.get("gold", 0),
        "servicos": SERVICOS, "fontes_ouro": FONTES_OURO,
        # A compra de comida mora aqui, não em SERVICOS: ela tem quantidade
        # ajustável e o custo muda com ela — não é um preço fixo de menu.
        "comida": clan["comida"], "teto_comida": teto,
        "custo_comida_unidade": CR.custo_comida(1),
        # 🛒 o que as outras aldeias vendem (ouro por unidade)
        # o preço anda com a RELAÇÃO com as aldeias vizinhas (storylets)
        "precos_outras_aldeias": {r: preco_de_outra_aldeia(r, _vizinhos(p)) for r in PRECO_OUTRAS_ALDEIAS},
        "vizinhos": _vizinhos(p),
        "estoque": {"madeira": clan.get("madeira", 0), "couro": clan.get("couro", 0),
                    "ferro": clan["materiais"].get(1, 0)},
        "regras_comida_auto": bool((clan.get("regras") or {}).get("compra_comida_auto")),
        "regras_materiais_auto": bool((clan.get("regras") or {}).get("compra_materiais_auto")),
        "regras_limite_materiais": int((clan.get("regras") or {}).get(
            "limite_ouro_materiais", H.REGRAS_PADRAO["limite_ouro_materiais"])),
        "mao_de_obra_pendente": float(clan.get("mao_de_obra") or 0),
        "regras_limite_comida": int((clan.get("regras") or {})
                                    .get("limite_ouro_comida", H.REGRAS_PADRAO["limite_ouro_comida"])),
        # O material some daqui: agora é ingrediente da forja (ver a Forja)
        # e do equipamento do clã, não sobra mais o que vender.
        "materiais": [{"rank": r, "nome": RANKS[r]["nome"], "cor": RANKS[r]["cor"],
                       "qtd": clan["materiais"].get(r, 0)} for r in sorted(RANKS)],
    })


@app.post("/api/clan/aldeia/servico")
def post_clan_servico(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """Serviços da aldeia. 🥇 20/09/2026: custam OURO, não bronze/prata —
    e ouro é do PERSONAGEM (`p["gold"]`), então esta rota carrega `p` e
    cobra dele, coisa que ela nunca precisou fazer antes."""
    from game import clan_repo as CR
    from game.clan_aldeia import SERVICOS
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    chave = corpo.get("servico")
    servico = SERVICOS.get(chave)
    if not servico:
        raise HTTPException(status_code=400, detail="Serviço desconhecido.")

    p = _carregar_jogador(telegram_id)
    custo = int(servico["ouro"])
    if int(p.get("gold", 0)) < custo:
        raise HTTPException(status_code=409,
                            detail=f"{servico['nome']} custa {custo}g de ouro; "
                                   f"você tem {p.get('gold', 0)}g.")

    efeito, valor, msg = servico["efeito"], servico["valor"], servico["nome"] + " feito."
    if efeito == "desconto_construcao":
        # Confere e grava ANTES de cobrar: desconto já pendente não se paga duas vezes.
        if not CR.contratar_mao_de_obra(telegram_id, float(valor)):
            raise HTTPException(status_code=409,
                                detail="Já tem mão de obra contratada esperando a próxima construção.")
        msg = f"Mão de obra contratada: a próxima construção sai {round(valor * 100)}% mais barata."
    with CR._conn() as c:
        if efeito == "cura_todos":
            c.execute("UPDATE clan_membro SET ferimento = MAX(0, ferimento - ?)"
                      " WHERE owner_id = ? AND vivo = 1", (valor, telegram_id))
            msg = "O curandeiro passou por todos."
        c.commit()
    if efeito == "aldeao":
        r_ = CR.mudar_populacao_por_decisao(telegram_id, int(valor))
        if not r_.get("chegaram"):
            raise HTTPException(status_code=409, detail=(
                "A aldeia está cheia — construa Moradias (Ferreiro → Forja) pra abrir vagas."))
        msg = f"🚶 {r_['chegaram'][0]} se juntou à aldeia."

    # Só debita DEPOIS do efeito ter dado certo — recrutar pode falhar
    # (conta sem slot livre) e aí não faz sentido cobrar por nada.
    p["gold"] = int(p.get("gold", 0)) - custo
    _salvar_jogador(telegram_id, p)

    return JSONResponse({"ok": True, "msg": msg, "gold": p["gold"]})


@app.post("/api/clan/aldeia/comprar")
def post_clan_comprar(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """🛒 Compra de outras aldeias (comida, madeira, couro, ferro) com o ouro
    do personagem. É a saída da greve: faltou pra manter, compra."""
    from game import clan_repo as CR
    from game.clan_equipes import PRECO_OUTRAS_ALDEIAS
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    recurso = str(corpo.get("recurso") or "")
    quantidade = int(corpo.get("quantidade") or 0)
    if recurso not in PRECO_OUTRAS_ALDEIAS or quantidade < 1:
        raise HTTPException(status_code=400, detail="Faltando 'recurso' ou 'quantidade'.")
    p = _carregar_jogador(telegram_id)
    from game.clan_equipes import preco_de_outra_aldeia
    from game.storylets import _estado
    vizinhos = int(_estado(p)["qualidades"].get("vizinhos", 50))
    preco = quantidade * preco_de_outra_aldeia(recurso, vizinhos)
    if int(p.get("gold", 0)) < preco:
        raise HTTPException(status_code=409, detail=f"Custa {preco} de ouro; você tem {p.get('gold', 0)}.")
    r = CR.comprar_de_outras_aldeias(telegram_id, recurso, quantidade)
    if not r["ok"]:
        raise HTTPException(status_code=409, detail=r["erro"])
    r["custo_ouro"] = int(r["comprado"]) * preco_de_outra_aldeia(recurso, vizinhos)
    p["gold"] = int(p.get("gold", 0)) - int(r["custo_ouro"])
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True, "comprado": r["comprado"], "custo_ouro": r["custo_ouro"],
                         "gold": p["gold"], "msg": f"+{r['comprado']} de {recurso} por {r['custo_ouro']} de ouro."})


@app.post("/api/clan/equipe")
def post_clan_equipe(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """👥 Monta (ou desfaz, com desfazer=true) a equipe de um posto."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    posto = str(corpo.get("posto_id") or "")
    if corpo.get("desfazer"):
        r = CR.desfazer_equipe(telegram_id, posto)
    else:
        p = _carregar_jogador(telegram_id)
        r = CR.montar_equipe(telegram_id, posto, corpo.get("coletores") or [],
                             corpo.get("guardas") or [], int(p.get("tower_floor") or 1),
                             recurso=corpo.get("recurso"))
    if not r["ok"]:
        raise HTTPException(status_code=409, detail=r["erro"])
    return JSONResponse(r)


@app.post("/api/clan/aldeia/comprar_comida")
def post_clan_comprar_comida(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """🌾 20/09/2026: comprar comida pagando ouro. Substitui "vender
    material" (que saiu — material virou ingrediente da forja e do
    equipamento do clã, não sobra mais o que vender).

    O ouro é do PERSONAGEM: esta rota carrega `p` e cobra dele. O clã só
    entra pra saber quanto CABE comprar (o teto do celeiro)."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    quantidade = int(corpo.get("quantidade") or 0)
    if quantidade < 1:
        raise HTTPException(status_code=400, detail="Faltando 'quantidade'.")

    p = _carregar_jogador(telegram_id)
    custo = CR.custo_comida(quantidade)
    if int(p.get("gold", 0)) < custo:
        raise HTTPException(status_code=409,
                            detail=f"Comprar {quantidade} de comida custa {custo}g; "
                                   f"você tem {p.get('gold', 0)}g.")

    r = CR.comprar_comida(telegram_id, quantidade)
    if not r["ok"]:
        raise HTTPException(status_code=409, detail=r["erro"])

    # Cobra só o que REALMENTE entrou — comprar_comida já cortou pelo teto
    # do celeiro, e cobrar pelo pedido inteiro pagaria por comida que foi
    # pro lixo sem avisar.
    custo_real = r["custo_ouro"]
    p["gold"] = int(p.get("gold", 0)) - custo_real
    _salvar_jogador(telegram_id, p)
    msg = f"+{r['comprado']} de comida por {custo_real}g."
    if r["comprado"] < quantidade:
        msg += f" (o celeiro só tinha espaço pra {r['comprado']})"
    return JSONResponse({"ok": True, "comprado": r["comprado"], "custo_ouro": custo_real,
                         "gold": p["gold"], "msg": msg})


# =============================================================================
# 👥 PERSONAGENS DA CONTA — a base do clã
# characters.py (5 slots, armário, mercado de personagens) era a última coisa
# grande ainda presa no bot: ZERO alcance pelo site.
#
# Vale registrar a forma dos dados, porque ela decide o clã inteiro:
# `character_storage` guarda SNAPSHOT CONGELADO (player_json, items_json,
# skills_json). Foi feito pra "qual personagem estou jogando" — é armário.
# Cavaleiro de clã precisa ser agente ATIVO: posto, fome, equipamento,
# estado, tudo consultável sem descongelar o blob.
#
# Decisão: não duplicar. Personagem num slot É membro do clã; o slot ativo é
# só quem você está pilotando. O que ele ESTÁ FAZENDO vai numa tabela à
# parte (clan_membro), e o armário segue guardando QUEM ELE É.
#
# ⚠️ trocar_personagem move o save vivo pro armário e traz outro. É a
# operação mais destrutiva do jogo inteiro: se ela falhar no meio, o
# personagem pode sumir. Por isso ela não entra no portão da cidade nem em
# nada que possa abortar no meio do caminho — e o front confirma antes.
# =============================================================================

@app.get("/api/personagens")
def get_personagens(authorization: str | None = Header(None)):
    from game.characters import (listar_personagens_da_conta, get_active_slot,
                                 slots_livres, MAX_SLOTS_EXTRAS,
                                 _carregar_do_armario, jogador_do_armario, _origem_do_slot)
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    ativo = get_active_slot(telegram_id)
    personagens = listar_personagens_da_conta(telegram_id)
    from game.sql_repo import load_player as _ler_ativo
    from game.clan_equipes import SOLDO_CAVALEIRO_DIA
    ouro_ativo = int((_ler_ativo(telegram_id) or {}).get("gold") or 0)
    for pe in personagens:
        # ⚔️ (28/09) treino de cavaleiro: pode ou não, e o PORQUÊ na tela
        slot = int(pe["slot"])
        pj = None
        if slot != ativo:
            snap = _carregar_do_armario(telegram_id, slot)
            pj = jogador_do_armario(snap) if snap and snap.get("player") else None
        pode, motivo = CR.pode_treinar_cavaleiro(telegram_id, pj, slot, ouro_ativo)
        pe["cavaleiro"] = {"pode": pode, "motivo": motivo}
        if slot == ativo:
            from game.sql_repo import load_player as _ler          # só leitura: sem trava
            origem = (_ler(telegram_id) or {}).get("origem_aldeao")
        else:
            origem = (pj or {}).get("origem_aldeao") or _origem_do_slot(telegram_id, slot)
        pe["origem"] = origem
    return JSONResponse({
        "ativo": ativo,
        "livres": slots_livres(telegram_id),
        "max_extras": MAX_SLOTS_EXTRAS,
        "personagens": personagens,
        "regras_cavaleiro": {"nivel_min": CR.NIVEL_MIN_CAVALEIRO, "custo": CR.CUSTO_CAVALEIRO,
                             "horas": CR.HORAS_TREINO_CAVALEIRO, "ouro": CR.ouro_do_treino(),
                             "soldo_dia": SOLDO_CAVALEIRO_DIA},
    })


@app.post("/api/personagens/cavaleiro")
def post_personagens_cavaleiro(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """⚔️ (28/09, dev) o personagem larga a Torre e vira cavaleiro do clã."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    if corpo.get("slot") is None:
        raise HTTPException(status_code=400, detail="Faltando 'slot'.")
    # 💰 a 1ª semana de soldo sai do ouro do personagem que você pilota
    p = _carregar_jogador(telegram_id)
    r = CR.treinar_cavaleiro(telegram_id, int(corpo["slot"]), int(p.get("gold") or 0))
    if not r.get("ok"):
        raise HTTPException(status_code=409, detail=r.get("erro") or "Não deu.")
    p["gold"] = int(p.get("gold") or 0) - int(r["custo_ouro"])
    _salvar_jogador(telegram_id, p)
    r["gold"] = p["gold"]
    return JSONResponse(r)


@app.post("/api/clan/cavaleiro/soldo")
def post_clan_cavaleiro_soldo(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """💰 (28/09, dev) paga o soldo do cavaleiro (1, 7 ou 30 dias), em ouro
    do personagem que você pilota. Sem soldo ele não luta nem defende."""
    from game import clan_repo as CR
    from game import clan_equipes as E
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    if corpo.get("id") is None:
        raise HTTPException(status_code=400, detail="Faltando 'id'.")
    dias = int(corpo.get("dias") or 7)
    p = _carregar_jogador(telegram_id)
    custo = dias * E.SOLDO_CAVALEIRO_DIA
    if int(p.get("gold") or 0) < custo:
        raise HTTPException(status_code=409, detail=f"O soldo de {dias} dia(s) custa {custo} de ouro "
                                                    f"(você tem {int(p.get('gold') or 0)}).")
    r = CR.pagar_soldo(telegram_id, int(corpo["id"]), dias)
    if not r.get("ok"):
        raise HTTPException(status_code=409, detail=r.get("erro") or "Não deu.")
    p["gold"] = int(p.get("gold") or 0) - custo
    _salvar_jogador(telegram_id, p)
    r["gold"] = p["gold"]
    return JSONResponse(r)


@app.post("/api/clan/habitante/promover")
def post_clan_habitante_promover(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """✨ (28/09, dev) o aldeão desperto sai da aldeia e vira personagem."""
    from game import clan_repo as CR
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    if corpo.get("id") is None:
        raise HTTPException(status_code=400, detail="Faltando 'id'.")
    r = CR.promover_a_personagem(telegram_id, int(corpo["id"]))
    if not r.get("ok"):
        raise HTTPException(status_code=409, detail=r.get("erro") or "Não deu.")
    return JSONResponse(r)


@app.post("/api/personagens/criar")
def post_personagens_criar(authorization: str | None = Header(None)):
    from game.characters import criar_personagem_slot
    telegram_id = int(_extrair_usuario(authorization)["id"])
    # ⚠️ criar_personagem_slot devolve (True, slot) — o segundo valor é o
    # NÚMERO do slot, não uma mensagem. Mandar ele direto pro front faria a
    # tela mostrar "3" como se fosse texto. Monto a frase aqui.
    ok, resultado = criar_personagem_slot(telegram_id)
    if ok:
        msg = (f"Slot {resultado} reservado. O personagem nasce quando você "
               f"trocar para ele pela primeira vez.")
    else:
        msg = str(resultado)
    return JSONResponse({"ok": bool(ok), "msg": msg, "slot": resultado if ok else None})


@app.post("/api/personagens/trocar")
def post_personagens_trocar(corpo: dict | None = Body(None),
                            authorization: str | None = Header(None)):
    """Guarda o personagem atual e traz outro. Recusa com combate em aberto:
    trocar no meio de uma luta deixaria o combate pendurado num save que
    acabou de ir pro armário — e é assim que save some."""
    from game.characters import trocar_personagem
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    if corpo.get("slot") is None:
        raise HTTPException(status_code=400, detail="Faltando 'slot'.")

    # _carregar_jogador toma a trava do jogador, e aqui isso é o que eu QUERO:
    # enquanto o save está sendo movido pro armário, nenhuma outra requisição
    # pode tocar nele. Mas a trava só se solta em _salvar_jogador, e esta rota
    # não grava — quem grava é o trocar_personagem, que cuida da própria
    # persistência. Então solto na mão, no fim, com finally.
    p = _carregar_jogador(telegram_id)
    try:
        if p.get("combat") or p.get("explore_mode") or p.get("wave_mode"):
            raise HTTPException(status_code=409,
                                detail="Termine o que está fazendo antes de trocar de personagem.")
        ok, msg = trocar_personagem(telegram_id, int(corpo["slot"]))
    finally:
        _soltar_trava_pendente()
    return JSONResponse({"ok": bool(ok), "msg": msg})


@app.get("/api/personagens/mercado")
def get_personagens_mercado(authorization: str | None = Header(None)):
    from game.characters import ver_mercado_personagens, ver_minhas_vendas
    telegram_id = int(_extrair_usuario(authorization)["id"])
    return JSONResponse({"mercado": ver_mercado_personagens(20),
                         "minhas": ver_minhas_vendas(telegram_id)})


@app.post("/api/personagens/anunciar")
def post_personagens_anunciar(corpo: dict | None = Body(None),
                              authorization: str | None = Header(None)):
    from game.characters import listar_personagem_a_venda
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    if corpo.get("slot") is None or corpo.get("preco") is None:
        raise HTTPException(status_code=400, detail="Faltando 'slot' e/ou 'preco'.")
    ok, msg = listar_personagem_a_venda(telegram_id, int(corpo["slot"]), int(corpo["preco"]))
    return JSONResponse({"ok": bool(ok), "msg": msg})


@app.post("/api/personagens/comprar")
def post_personagens_comprar(corpo: dict | None = Body(None),
                             authorization: str | None = Header(None)):
    from game.characters import comprar_personagem
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    if corpo.get("id") is None:
        raise HTTPException(status_code=400, detail="Faltando 'id' do anúncio.")
    ok, msg = comprar_personagem(telegram_id, int(corpo["id"]))
    return JSONResponse({"ok": bool(ok), "msg": msg})


@app.post("/api/personagens/cancelar")
def post_personagens_cancelar(corpo: dict | None = Body(None),
                              authorization: str | None = Header(None)):
    from game.characters import cancelar_venda
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    if corpo.get("id") is None:
        raise HTTPException(status_code=400, detail="Faltando 'id' do anúncio.")
    ok, msg = cancelar_venda(telegram_id, int(corpo["id"]))
    return JSONResponse({"ok": bool(ok), "msg": msg})


# =============================================================================
# 📚 SKILLS, MONTARIAS E RAID — as últimas funções presas no bot
# Varredura de 11/09/2026, continuação. Destas, três não viraram rota e vale
# registrar o porquê:
#   - pick_specialty é LEGADO. O campo specialty_id virou os 3 slots de
#     `specialties` (ver get_specialty_slots, que converte a string antiga).
#     Dar rota a ela reintroduziria a escolha única já aposentada e brigaria
#     com os slots pelo mesmo campo.
#   - craft_toggle_core e craft_reset são estado de BOTÃO do bot: lá o
#     jogador liga uma core por clique. O site manda a seleção inteira em
#     /api/craft/confirm, então não há o que portar.
# =============================================================================

@app.post("/api/skills/aprender")
def post_skills_aprender(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """Aprende (ou evolui) uma skill gastando a core dela. A checagem de
    classe está dentro de can_learn_skill, no motor — não replico aqui."""
    from game.logic import learn_skill_from_core
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    core_id = corpo.get("core")
    if not core_id:
        raise HTTPException(status_code=400, detail="Faltando 'core'.")
    p = _carregar_jogador(telegram_id)
    msg = learn_skill_from_core(p, str(core_id))
    sucesso = "❌" not in msg
    if sucesso:
        _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": sucesso, "msg": msg,
                         "cores": (p.get("inv") or {}).get("cores", {})})


@app.post("/api/skills/rerolar")
def post_skills_rerolar(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """Re-rola os bônus de uma skill. Custa 500 de ouro + 1 core dela, e o
    resultado pode sair PIOR — é aposta, e o front avisa antes."""
    from game.logic import reroll_skill_affix
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    skill_id = corpo.get("skill")
    if not skill_id:
        raise HTTPException(status_code=400, detail="Faltando 'skill'.")
    p = _carregar_jogador(telegram_id)
    msg = reroll_skill_affix(p, str(skill_id))
    sucesso = "❌" not in msg
    if sucesso:
        _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": sucesso, "msg": msg, "gold": p.get("gold")})


@app.post("/api/estabulo/fundir")
def post_estabulo_fundir(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    from game.mounts import fuse_mounts
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    mount_id = corpo.get("montaria")
    if not mount_id:
        raise HTTPException(status_code=400, detail="Faltando 'montaria'.")
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)
    resultado = fuse_mounts(p, str(mount_id))
    ok, msg = (resultado[0], resultado[1]) if isinstance(resultado, tuple) else (True, str(resultado))
    if ok:
        _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": bool(ok), "msg": msg})


@app.post("/api/raid/fugir")
def post_raid_fugir(authorization: str | None = Header(None)):
    """Sair da raid no meio. Existia só no bot — quem entrasse numa sala
    pelo site ficava preso nela até a raid acabar."""
    from game.logic import raid_flee
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    msg = raid_flee(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": "❌" not in msg, "msg": msg})


# =============================================================================
# 🧪 AÇÕES QUE O SITE VENDIA MAS NÃO DEIXAVA USAR
# Varredura de 11/09/2026: 18 funções do motor que mexem no jogador eram
# alcançáveis só pelo bot. Duas delas são vendidas na Loja do próprio site:
#
#   - POÇÃO: /api/shop/buy_potion existia; usar, não. Comprava e guardava.
#   - AUTOBATALHA: 500⭐ (dinheiro real via Pix) e nenhuma rota pra ligar.
#
# É o padrão nº 6 do checklist na pior forma possível — o jogador paga e não
# recebe. Estas rotas fecham isso.
# =============================================================================

@app.post("/api/combate/pocao")
def post_combate_pocao(authorization: str | None = Header(None)):
    """Usa uma poção. Cura 50 + 10×andar, então o valor sobe com a Torre.
    Não exige estar em combate: curar antes de subir é uso legítimo."""
    from game.logic import use_potion
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)
    msg = use_potion(p)
    sucesso = "Curou" in msg
    if sucesso:
        _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": sucesso, "msg": msg,
                         "hp": p.get("hp"), "hp_max": p.get("hp_max"),
                         "potions": (p.get("inv") or {}).get("potion", 0)})


@app.post("/api/combate/auto")
def post_combate_auto(authorization: str | None = Header(None)):
    """Resolve o resto da luta sozinho. Exige a Autobatalha comprada — a
    checagem é aqui no servidor, não no botão: quem paga 500⭐ merece que
    quem não pagou não consiga usar escondendo o front."""
    from game.logic import auto_battle, tem_autobattle_ativa
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)

    if not tem_autobattle_ativa(p):
        raise HTTPException(status_code=403,
                            detail="Autobatalha não está ativa. Ela é comprada na Loja e dura 28 dias.")
    if not (p.get("combat") or {}).get("enemies"):
        raise HTTPException(status_code=409, detail="Você não está em combate.")

    log = auto_battle(p)

    # 🐛 20/09/2026 — A AUTOBATALHA TRAVAVA A TELA.
    # A luta era resolvida certinho no servidor, mas esta rota pulava os
    # dois passos que TODA outra ação de combate faz depois de bater:
    # `_pos_combate_explorar` e `_pos_combate_onda`. Sem eles a exploração
    # e a Onda nunca sabiam que o combate acabou, e a resposta não
    # carregava o snapshot — o front pedia /api/tower/combat, que responde
    # 400 quando não há combate, e a tela ficava parada no começo da luta
    # com um toast de erro. Ou seja: o jogador pagava 500⭐ e via a tela
    # travar.
    #
    # Agora esta rota devolve exatamente o mesmo formato de /api/tower/attack,
    # pra que o front use o mesmo caminho de sempre.
    explorar_info = _pos_combate_explorar(p)
    onda_info = _pos_combate_onda(p)
    _salvar_jogador(telegram_id, p)

    snap = _montar_snapshot_combate(p, log)
    if explorar_info:
        snap["explorar"] = explorar_info
    if onda_info:
        snap["onda"] = onda_info
    snap["log_auto"] = log
    return JSONResponse(snap)


@app.get("/api/combate/auto/status")
def get_combate_auto_status(authorization: str | None = Header(None)):
    """O front precisa saber se mostra o botão. Sem isto ele apareceria pra
    todo mundo e só falharia ao ser tocado."""
    from game.logic import tem_autobattle_ativa
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    from game.logic import autobattle_da_conta
    return JSONResponse({"ativa": bool(tem_autobattle_ativa(p)),
                         "ate": int(autobattle_da_conta(p))})


@app.post("/api/diario/resgatar")
def post_diario_resgatar(authorization: str | None = Header(None)):
    """Recompensa diária. Existia no bot (act:daily) e em lugar nenhum aqui."""
    from game.logic import claim_daily_reward
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    ok, msg = claim_daily_reward(p)
    if ok:
        _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": bool(ok), "msg": msg,
                         # 🐛 (26/09) era p["premium"] — a CÓPIA do personagem:
                         # com outro personagem, o topo mostrava menos estrelas
                         "gold": p.get("gold"), "premium": _saldo_premium(p, telegram_id)})


@app.post("/api/missoes/resgatar_tudo")
def post_missoes_resgatar_tudo(authorization: str | None = Header(None)):
    """Resgata todas as missões prontas de uma vez. Com missão diária, pegar
    uma por uma é trabalho repetido sem decisão nenhuma no meio."""
    from game.logic import claim_all_rewards
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    msg = claim_all_rewards(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True, "msg": msg,
                         # 🐛 (26/09) era p["premium"] — a CÓPIA do personagem:
                         # com outro personagem, o topo mostrava menos estrelas
                         "gold": p.get("gold"), "premium": _saldo_premium(p, telegram_id)})


# =============================================================================
# 🌿 TRILHAS — distribuir pontos
# `spend_trail_point` sempre esteve no motor, mas nunca teve rota. O site
# mostrava a tela de Especialidade (equipar/desequipar) e mais nada: os
# pontos de trilha acumulavam sem lugar nenhum pra gastar. Mais um sistema
# que existia e ninguém alcançava.
#
# A barreira do passo 5 é a parte que exige cuidado: ali o jogador tem que
# ESCOLHER um secundário antes de continuar, e `spend_trail_point` sinaliza
# isso com a terceira posição da tupla (need_choose). Gastar 10 pontos de
# uma vez trava nessa barreira de propósito — o resto dos pontos volta pra
# carteira em vez de ser queimado numa escolha que ninguém fez.
# =============================================================================

_NOME_TRILHA = {"str": "Força", "vit": "Vitalidade", "agi": "Agilidade", "dex": "Destreza"}
_NOME_SEC = {"atk": "Ataque", "def": "Defesa", "hp_max": "Vida", "reg": "Regeneração",
             "spd": "Velocidade", "eva": "Evasão", "crit": "Crítico", "acc": "Precisão"}


def _resumo_trilhas(p: dict) -> dict:
    from game.logic import TRAILS_DB
    trilhas = []
    for chave, dados in TRAILS_DB.items():
        t = (p.get("trails") or {}).get(chave) or {}
        passo = int(t.get("step", 0))
        sec = t.get("sec")
        trilhas.append({
            "id": chave,
            "nome": _NOME_TRILHA.get(chave, chave),
            "passo": passo,
            "ciclos": int(t.get("cycles", 0)),
            "sec": sec,
            "sec_nome": _NOME_SEC.get(sec) if sec else None,
            # O front precisa saber ANTES de gastar que a próxima parada é a
            # barreira — senão o jogador toca "gastar tudo" e não entende
            # por que sobrou ponto.
            "precisa_escolher": passo == 5 and not sec,
            "opcoes_sec": [{"id": o, "nome": _NOME_SEC.get(o, o)} for o in dados["sec_opts"]],
        })
    return {"pontos": int(p.get("trail_points", 0) or 0), "trilhas": trilhas}


@app.get("/api/trilhas")
def get_trilhas(authorization: str | None = Header(None)):
    telegram_id = int(_extrair_usuario(authorization)["id"])
    return JSONResponse(_resumo_trilhas(_carregar_jogador(telegram_id)))


@app.post("/api/trilhas/gastar")
def post_trilhas_gastar(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    from game.logic import spend_trail_point
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    trilha = corpo.get("trilha")
    if not trilha:
        raise HTTPException(status_code=400, detail="Faltando 'trilha'.")
    try:
        quantidade = max(1, int(corpo.get("quantidade", 1)))
    except (TypeError, ValueError):
        quantidade = 1

    p = _carregar_jogador(telegram_id)
    ok, msg, precisa_escolher = spend_trail_point(
        p, str(trilha), amount=quantidade, sec=corpo.get("sec"))
    if ok:
        _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": bool(ok), "msg": msg,
                         "precisa_escolher": bool(precisa_escolher),
                         **_resumo_trilhas(p)})


# =============================================================================
# 🏙️ ESTADO: CIDADE x FORA DA CIDADE
# Os serviços da cidade (loja, forja, engaste, mercado, templo, estábulo,
# hospital) só funcionam com o jogador NA cidade. Sair da torre custa ouro.
#
# ⚠️ Isto NÃO é uma restauração do bot — é regra nova, e vale dizer por quê.
# No core/router.py o bloqueio existia só no nome:
#     estado_atual = p.get("state", "CITY")
#     if estado_atual in ["COMBAT", "TOWER", "RAID_LOBBY"]:
#         # ... (seu código de bloqueio aqui)
#         pass
# Um `pass`. E `nav:city` voltava pra cidade de graça, num clique. O teleporte
# pago (act:tp, 100g) existia como BOTÃO OPCIONAL na tela da Torre — ninguém
# precisava usar. Ou seja: o custo nunca foi cobrado de fato, nem no bot.
# Aqui ele passa a ser o único caminho de volta.
#
# A checagem fica no servidor, não no menu. Esconder o botão no front é
# conveniência; quem decide é quem guarda o ouro.
# =============================================================================

ESTADOS_FORA_DA_CIDADE = ("TOWER", "COMBAT", "RAID_LOBBY", "RAID", "EXPLORE", "WAVE")

# O portão vale também nas rotas de VISUALIZAÇÃO (ver a Loja, o Mercado, as
# cores da Forja, o Estábulo), não só nas de ação. Deixar navegar e falhar só
# no "comprar" é a armadilha de descobrir o bloqueio por erro: o jogador
# escolhe o item, toca, e só aí leva o não. Com a lista fechada, tocar no
# quadro trancado já mostra o preço da volta — a informação chega no momento
# em que ele precisa dela.


def _custo_volta(p: dict) -> int:
    """Mesmo cálculo do teleporte do bot, montaria inclusa."""
    from game.logic import TP_COST
    from game.mounts import get_equipped_mount_bonus
    mecanica = (get_equipped_mount_bonus(p) or {}).get("mechanic", {}) or {}
    desconto = mecanica.get("value", 0) if mecanica.get("type") == "tp_discount" else 0.0
    return max(1, int(TP_COST * (1.0 - desconto)))


def _esta_fora_da_cidade(p: dict) -> bool:
    if p.get("combat") or p.get("explore_mode") or p.get("wave_mode"):
        return True
    return str(p.get("state") or "CITY").upper() in ESTADOS_FORA_DA_CIDADE


def _exigir_cidade(p: dict) -> None:
    """Levanta 409 com tudo que o front precisa pra oferecer a volta: o custo,
    quanto o jogador tem, e se dá pra pagar. Erro que não diz o preço obriga
    o jogador a sair da tela pra descobrir."""
    if not _esta_fora_da_cidade(p):
        return
    custo = _custo_volta(p)
    ouro = int(p.get("gold") or 0)
    _soltar_trava_pendente()   # a rota vai abortar; não deixa a trava presa
    raise HTTPException(status_code=409, detail={
        "fora_da_cidade": True,
        "custo": custo,
        "gold": ouro,
        "pode_pagar": ouro >= custo,
        "em_combate": bool(p.get("combat")),
        "msg": ("Você está no meio de uma luta." if p.get("combat")
                else f"Você não está na cidade. Voltar custa {custo}💰."),
    })


@app.get("/api/cidade/estado")
def get_cidade_estado(authorization: str | None = Header(None)):
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    fora = _esta_fora_da_cidade(p)
    return JSONResponse({
        "na_cidade": not fora,
        "estado": p.get("state") or "CITY",
        "em_combate": bool(p.get("combat")),
        "custo_volta": _custo_volta(p) if fora else 0,
        "gold": int(p.get("gold") or 0),
    })


@app.post("/api/cidade/voltar")
def post_cidade_voltar(authorization: str | None = Header(None)):
    """O caminho de volta. Cobra o teleporte usando a MESMA função do bot —
    inclusive o desconto de montaria."""
    from game.logic import tower_tp_paid
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)

    if not _esta_fora_da_cidade(p):
        return JSONResponse({"ok": True, "msg": "Você já está na cidade.", "gold": p.get("gold", 0)})

    # Luta pendente não tem teleporte: senão fugir de uma derrota custaria
    # 100g e o combate perderia o sentido. Vence, foge ou morre.
    if p.get("combat"):
        raise HTTPException(status_code=409, detail={
            "fora_da_cidade": True, "em_combate": True, "custo": 0,
            "msg": "Termine a luta primeiro — não dá pra teleportar no meio dela."})

    ok, msg = tower_tp_paid(p)
    if not ok:
        raise HTTPException(status_code=409, detail={
            "fora_da_cidade": True, "custo": _custo_volta(p),
            "gold": int(p.get("gold") or 0), "pode_pagar": False, "msg": msg})

    p["explore_mode"] = False
    p["wave_mode"] = False
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True, "msg": msg, "gold": p.get("gold", 0)})


# =============================================================================
# 🔒 CONTA BLOQUEADA — as duas únicas portas que ficam abertas
# =============================================================================

@app.get("/api/conta/status")
def get_conta_status(authorization: str | None = Header(None)):
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id, permitir_bloqueada=True)
    bloqueio = p.get("conta_bloqueada") or {}
    return JSONResponse({
        "bloqueada": bool(bloqueio),
        "motivo": bloqueio.get("motivo") or ("Pagamento não confirmado." if bloqueio else None),
        "pedido": bloqueio.get("order_id"),
        "desde": bloqueio.get("since"),
    })


@app.post("/api/conta/reset")
def post_conta_reset(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """Apaga o personagem e começa do zero. É a saída de emergência de quem
    ficou bloqueado e não consegue (ou não quer) comprovar o pagamento.

    Exige a palavra RESETAR digitada: um toque errado não pode apagar meses
    de jogo, e no celular o toque errado é a regra, não a exceção."""
    from game.logic import create_player
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    if (corpo.get("confirmacao") or "").strip().upper() != "RESETAR":
        raise HTTPException(status_code=400,
                            detail="Digite RESETAR para confirmar que quer apagar o personagem.")

    p = _carregar_jogador(telegram_id, permitir_bloqueada=True)
    nome = p.get("username")
    novo = create_player(telegram_id)
    if nome:
        novo["username"] = nome
    _salvar_jogador(telegram_id, novo)
    return JSONResponse({"ok": True, "msg": "Personagem resetado. Bem-vindo de volta do começo."})


# =============================================================================
# 💎 ENGASTE DE GEMAS (socket) — existia só no bot
# Sem isto, toda gema que cai vira item morto: o jogador acumula cores e não
# tem onde usar. É o padrão nº 6 do checklist — sistema que existe e ninguém
# pode alcançar.
#
# O motor (`socket_apply`) foi escrito pro fluxo de botões do bot: ele lê o
# alvo de `p["socket_temp"]`, preenchido por dois cliques anteriores. Aqui a
# rota preenche esse estado e chama a MESMA função, em vez de reescrever a
# regra — inclusive a parte hardcore de destruir a gema antiga.
# =============================================================================

@app.get("/api/socket/itens")
def get_socket_itens(authorization: str | None = Header(None)):
    """Itens com slot de gema (equipados e na mochila) + as cores que o
    jogador tem. Uma chamada só: a tela precisa dos dois lados pra montar."""
    from game.items import core_name, core_bonus
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)

    def descrever(item, alvo):
        maximo = int(item.get("sock_max", 0) or 0)
        if maximo <= 0:
            return None
        engastadas = list(item.get("socked", []) or [])
        slots = []
        for i in range(maximo):
            cid = engastadas[i] if i < len(engastadas) else None
            slots.append({"indice": i, "core": cid,
                          "nome": core_name(cid) if cid else None,
                          "bonus": core_bonus(cid) if cid else {}})
        # 🖼️ A arte do item faltava aqui: a tela de engaste mostrava só o
        # nome, então o jogador escolhia encaixe sem ver em QUE peça está
        # mexendo — e é a única tela onde a escolha destrói a gema antiga.
        from game.assets import resolver_asset_key_item, chave_de_imagem_do_item
        slot_do_item = alvo.split(":")[1] if ":" in alvo else ""
        return {"alvo": alvo, "nome": item.get("name", "?"),
                "raridade": item.get("rar", "comum"),
                "img_key": chave_de_imagem_do_item(item, slot_do_item),
                # 📈 (28/09) bônus de raridade também no Engaste
                "bonus_raridade": __import__("game.logic", fromlist=["x"]).bonus_de_raridade_do_item(item, slot_do_item),
                "slots": slots, "livres": sum(1 for x in slots if not x["core"])}

    itens = []
    for slot, item in (p.get("equip") or {}).items():
        if item:
            d = descrever(item, f"equip:{slot}")
            if d:
                d["equipado"] = True
                itens.append(d)
    for slot, lista in ((p.get("inv") or {}).get("items") or {}).items():
        for i, item in enumerate(lista or []):
            if item:
                d = descrever(item, f"inv:{slot}:{i}")
                if d:
                    d["equipado"] = False
                    itens.append(d)

    cores = [{"id": cid, "nome": core_name(cid), "bonus": core_bonus(cid), "qtd": int(qtd)}
             for cid, qtd in ((p.get("inv") or {}).get("cores") or {}).items() if int(qtd) > 0]
    cores.sort(key=lambda c: c["nome"])

    return JSONResponse({"itens": itens, "cores": cores})


@app.post("/api/socket/aplicar")
def post_socket_aplicar(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    from game.logic import socket_apply
    telegram_id = int(_extrair_usuario(authorization)["id"])
    corpo = corpo or {}
    alvo, core = corpo.get("alvo"), corpo.get("core")
    if not alvo or not core:
        raise HTTPException(status_code=400, detail="Faltando 'alvo' e/ou 'core'.")
    try:
        indice = int(corpo.get("slot", -1))
    except (TypeError, ValueError):
        indice = -1
    if indice < 0:
        raise HTTPException(status_code=400, detail="Faltando o número do slot.")

    p = _carregar_jogador(telegram_id)

    _exigir_cidade(p)
    # É o estado que socket_apply espera encontrar; montamos e chamamos.
    p["socket_temp"] = {"target": str(alvo), "slot_idx": indice}
    msg = socket_apply(p, str(core))
    p.pop("socket_temp", None)   # transitório: não tem por que ir pro banco
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": "❌" not in msg, "msg": msg})


# =============================================================================
# 🔔 CAIXA DE AVISOS (migração: o bot mandava mensagem, agora fica no jogo)
# =============================================================================

@app.get("/api/avisos")
def get_avisos(authorization: str | None = Header(None)):
    from webapp.avisos import listar, contar_nao_lidos
    telegram_id = int(_extrair_usuario(authorization)["id"])
    return JSONResponse({"avisos": listar(telegram_id),
                         "nao_lidos": contar_nao_lidos(telegram_id)})


@app.post("/api/avisos/lidos")
def post_avisos_lidos(authorization: str | None = Header(None)):
    from webapp.avisos import marcar_lidos
    telegram_id = int(_extrair_usuario(authorization)["id"])
    return JSONResponse({"ok": True, "marcados": marcar_lidos(telegram_id)})


# =============================================================================
# 🧾 COMPROVANTE DE PIX (migração: saiu do chat do bot, virou upload aqui)
# =============================================================================

# 🩹 11/09/2026 — Esta rota usa File()/UploadFile, e o FastAPI EXIGE o pacote
# python-multipart pra registrar uma rota assim. Ele valida no momento em que
# a rota é definida, não quando ela é chamada — então o pacote faltando não
# quebrava só o upload: derrubava a API INTEIRA no boot, e o jogo sumia do ar
# deixando só o bot de pé. Aconteceu em produção.
#
# Agora o registro é condicional. Sem o pacote, as outras 111 rotas sobem
# normalmente e só o upload responde 503 dizendo exatamente o que instalar.
# O pacote está no requirements.txt; isto aqui é a rede, não o conserto.
try:
    import multipart as _multipart_check  # noqa: F401
    _TEM_MULTIPART = True
except ImportError:
    try:
        import python_multipart as _multipart_check  # noqa: F401
        _TEM_MULTIPART = True
    except ImportError:
        _TEM_MULTIPART = False
        print("⚠️ python-multipart ausente: o upload de comprovante fica fora do ar. "
              "O resto do jogo sobe normalmente.")


def _registrar_upload_comprovante():
    @app.post("/api/shop/comprovante")
    def post_shop_comprovante(arquivo: UploadFile = File(...),
                              authorization: str | None = Header(None)):
        from webapp import comprovantes
        usuario = _extrair_usuario(authorization)
        telegram_id = int(usuario["id"])

        # .file.read() e não await .read(): esta rota é síncrona (roda no
        # threadpool do FastAPI), então a leitura do arquivo não pode ser a
        # versão async — e assim ela também não bloqueia o event loop.
        conteudo = arquivo.file.read()
        try:
            comprovantes.validar_arquivo(conteudo, arquivo.content_type or "")
        except comprovantes.ErroComprovante as e:
            raise HTTPException(status_code=400, detail=str(e))

        p = _carregar_jogador(telegram_id)
        # Grava o arquivo só DEPOIS de saber que existe pedido aberto — senão
        # a pasta enche de comprovante órfão de quem clicou sem pedido nenhum.
        try:
            pendentes = p.get("pending_orders") or []
            if not any(o.get("status") == "waiting_payment" for o in pendentes):
                raise comprovantes.ErroComprovante(
                    "Você não tem nenhum pedido aberto. Abra a Loja, escolha quantas ⭐ "
                    "quer comprar, e só então mande o comprovante.")
            nome = comprovantes.salvar_arquivo(telegram_id, conteudo, arquivo.content_type or "")
            resumo = comprovantes.registrar(p, telegram_id, nome)
        except comprovantes.ErroComprovante as e:
            raise HTTPException(status_code=400, detail=str(e))

        _salvar_jogador(telegram_id, p)
        return JSONResponse(resumo)


if _TEM_MULTIPART:
    _registrar_upload_comprovante()
else:
    @app.post("/api/shop/comprovante")
    def post_shop_comprovante_indisponivel(authorization: str | None = Header(None)):
        """Mesma rota, sem File(): registra sem exigir o pacote e diz o que
        houve. Erro claro no lugar certo é melhor que 404 — 404 faria parecer
        que a funcionalidade não existe."""
        raise HTTPException(
            status_code=503,
            detail="Upload de comprovante indisponível: falta o pacote python-multipart "
                   "no servidor. Mande o comprovante pelo chat do bot enquanto isso.")



# =============================================================================
# 🛡️ PAINEL DO ADMIN
# Autenticação separada da dos jogadores de propósito: admin não é um
# personagem, é uma senha de operação. Sem ADMIN_SENHA no ambiente o painel
# fica DESLIGADO — nunca aberto por padrão.
# =============================================================================

def _exigir_admin(senha: str | None) -> None:
    from webapp.comprovantes import conferir_senha_admin, ErroComprovante
    try:
        conferir_senha_admin(senha or "")
    except ErroComprovante as e:
        raise HTTPException(status_code=401, detail=str(e))


# =============================================================================
# 💾 BACKUP — o que o deploy não leva
# =============================================================================
# O zip de deploy nunca leva `data/`, então bancos, imagens e comprovantes
# existem num lugar só: o disco do servidor. Perder o premium.db apaga
# compra que alguém pagou.
#
# ⚠️ Os .db saem como SNAPSHOT (VACUUM INTO), não como cópia do arquivo:
# copiar SQLite em uso produz backup sem as últimas transações ou
# corrompido, e isso só aparece na hora de restaurar. Ver webapp/backup.py.

@app.get("/api/admin/backup/info")
def get_admin_backup_info(x_admin_senha: str | None = Header(None)):
    from webapp.backup import inventario
    _exigir_admin(x_admin_senha)
    return JSONResponse(inventario())


@app.get("/api/admin/backup")
def get_admin_backup(request: Request, x_admin_senha: str | None = Header(None),
                     senha: str | None = None):
    """Baixa o backup. Aceita a senha no cabeçalho OU na query porque um
    download é uma navegação do navegador, e navegação não manda cabeçalho
    — sem isso o botão simplesmente não teria como funcionar."""
    from webapp.backup import montar_backup
    _exigir_admin(x_admin_senha or senha)

    q = request.query_params if hasattr(request, "query_params") else {}
    com_imagens = str(q.get("imagens", "1")) not in ("0", "false", "nao", "não")
    com_comprovantes = str(q.get("comprovantes", "1")) not in ("0", "false", "nao", "não")

    caminho = montar_backup(incluir_imagens=com_imagens,
                            incluir_comprovantes=com_comprovantes)
    import time as _t
    nome = f"isekairpg-backup-{_t.strftime('%Y%m%d-%H%M')}.zip"

    # O temporário NÃO é apagado aqui. montar_backup() faz a faxina na
    # entrada, apagando os zips da vez passada: download cancelado, conexão
    # caída ou processo reiniciado no meio deixariam o arquivo pra trás de
    # qualquer forma, e uma limpeza que só roda no caminho feliz não é
    # limpeza. Ver limpar_temporarios() em webapp/backup.py.
    return FileResponse(caminho, filename=nome, media_type="application/zip")


@app.get("/api/admin/pendentes")
def get_admin_pendentes(x_admin_senha: str | None = Header(None)):
    from webapp.comprovantes import listar_pendentes
    _exigir_admin(x_admin_senha)
    return JSONResponse({"pendentes": listar_pendentes()})


@app.get("/api/admin/comprovante/{nome}")
def get_admin_comprovante(nome: str, s: str = "", x_admin_senha: str | None = Header(None)):
    """Único endpoint de admin que aceita a senha por query string: o
    comprovante abre em aba nova, e aba nova não carrega header nenhum.
    É só leitura — confirmar e recusar continuam exigindo o header."""
    from webapp.comprovantes import caminho_do_comprovante, ErroComprovante
    _exigir_admin(s or x_admin_senha)
    try:
        caminho = caminho_do_comprovante(nome)
    except ErroComprovante as e:
        raise HTTPException(status_code=404, detail=str(e))
    return FileResponse(caminho)


@app.post("/api/admin/confirmar/{alvo_id}")
def post_admin_confirmar(alvo_id: int, x_admin_senha: str | None = Header(None)):
    from webapp.comprovantes import confirmar
    _exigir_admin(x_admin_senha)
    p = _carregar_jogador(alvo_id)
    msg = confirmar(p, alvo_id)
    _salvar_jogador(alvo_id, p)
    return JSONResponse({"ok": True, "msg": msg})


@app.post("/api/admin/recusar/{alvo_id}")
def post_admin_recusar(alvo_id: int, x_admin_senha: str | None = Header(None)):
    from webapp.comprovantes import recusar
    _exigir_admin(x_admin_senha)
    p = _carregar_jogador(alvo_id)
    msg = recusar(p, alvo_id)
    _salvar_jogador(alvo_id, p)
    return JSONResponse({"ok": True, "msg": msg})


# --- suporte a conta (lição 19 do Mestre) ---
# A mensagem de login é genérica de propósito — "usuário ou senha
# incorretos" não entrega quais contas existem. O preço disso é que quando
# o próprio dono trava, ninguém sabe o que houve. Estas duas rotas são o
# contrapeso: em algum lugar tem que dar pra ver a verdade.

@app.get("/api/admin/conta")
def get_admin_conta(usuario: str = "", x_admin_senha: str | None = Header(None)):
    from webapp.contas import info_conta
    _exigir_admin(x_admin_senha)
    info = info_conta(usuario)
    if not info:
        return JSONResponse({"ok": False, "msg": f"Nenhuma conta com o nome '{usuario}'."})
    return JSONResponse({"ok": True, "conta": info})


@app.post("/api/admin/resetar-senha")
def post_admin_resetar_senha(corpo: dict | None = Body(None),
                             x_admin_senha: str | None = Header(None)):
    from webapp.contas import redefinir_senha_admin, ErroConta
    _exigir_admin(x_admin_senha)
    corpo = corpo or {}
    try:
        redefinir_senha_admin(corpo.get("usuario", ""), corpo.get("senha_nova", ""))
    except ErroConta as e:
        raise HTTPException(status_code=400, detail=str(e))
    return JSONResponse({"ok": True, "msg": "Senha redefinida. As sessões abertas caíram."})


# As DUAS formas. /admin funcionava e /admin/ dava 404 no Mestre, porque o
# teclado do celular completa a barra sozinho. Registrar as duas custa uma
# linha; descobrir isso em produção custou bem mais.
@app.get("/admin")
@app.get("/admin/")
def get_pagina_admin():
    return FileResponse(str(STATIC_DIR / "admin.html"))


# =============================================================================
# 📊 PERSONAGEM
# =============================================================================

@app.get("/api/character")
def get_character(authorization: str | None = Header(None)):
    """Ficha completa do personagem: status, atributos, equipamentos,
    pets. Reaproveita a MESMA lógica (create_player/load_player/recalc)
    que o bot usa no chat — zero regra de negócio duplicada."""
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    # imports locais: a lógica do jogo (game.logic) é pesada e só
    # precisamos dela quando a rota é chamada, não no boot da API
    from game.sql_repo import load_player
    from game.logic import create_player, recalc, ensure_player

    p = load_player(telegram_id)
    if not p:
        p = create_player(telegram_id)
        p["username"] = usuario.get("username") or usuario.get("first_name") or "Jogador"
    return JSONResponse(_montar_ficha(p, telegram_id, publica=False))


# 👤 (28/09, dev) "no rank, se outro jogador clicar no nome dele vê a página
# de status desse jogador: os itens, equipamentos, tudo o que aparece no
# meu personagem — e as skills e especialidades". A ficha pública é a MESMA
# montagem da sua (uma função só, as duas telas nunca divergem), sem o que é
# da conta e não do personagem: ouro, ⭐, XP, vida atual, pontos parados.
@app.get("/api/jogador/{alvo}/ficha")
def get_ficha_publica(alvo: str, authorization: str | None = Header(None)):
    _extrair_usuario(authorization)              # precisa estar logado pra ver
    from game.sql_repo import load_player
    try:
        alvo_id = int(alvo)
    except ValueError:
        raise HTTPException(status_code=400, detail="Jogador inválido.")
    p = load_player(alvo_id)                     # só leitura: nada é criado nem salvo
    if not p:
        raise HTTPException(status_code=404, detail="Jogador não encontrado.")
    return JSONResponse(_montar_ficha(p, alvo_id, publica=True))


def _habilidades_da_ficha(p: dict) -> list:
    """As 5 habilidades equipadas, com o que cada uma faz (mesma descrição
    das cartas da criação). Passiva: os bônus em %."""
    from game.logic import find_skill_by_id
    aprendidas = p.get("skills_learned") or {}
    saida = []
    for sid in ((p.get("skill_slots") or {}).get("equipped") or [None] * 5):
        if not sid:
            saida.append(None)
            continue
        dados = aprendidas.get(sid) or (find_skill_by_id(sid) or (None, {}))[1] or {}
        if dados.get("type") == "passive":
            efeitos = [f"{ROTULO_STAT_FICHA.get(k, k.upper())} +{round(float(v) * 100)}%"
                       for k, v in (dados.get("bonus_pct") or {}).items()]
        else:
            efeitos = _descrever_skill(dados)
        saida.append({"skill_id": sid, "nome": dados.get("name", sid), "tipo": dados.get("type", "active"),
                      "raridade": int(dados.get("rarity") or 1), "nivel": int(dados.get("level") or 1),
                      "efeitos": efeitos})
    return saida


ROTULO_STAT_FICHA = {"atk": "Ataque", "def": "Defesa", "hp_max": "Vida", "spd": "Velocidade",
                     "crit": "Crítico", "acc": "Precisão", "eva": "Esquiva", "reg": "Regeneração"}


def _especialidades_da_ficha(p: dict) -> list:
    from game.logic import get_specialty_slots
    from game.specialties import SPECIALTIES_DB
    saida = []
    for sid in get_specialty_slots(p):
        d = SPECIALTIES_DB.get(sid) if sid else None
        if not d:
            saida.append(None)
            continue
        passivas = [f"{ROTULO_STAT_FICHA.get(k, k.upper())} +{round(float(v) * 100)}%"
                    for k, v in (d.get("passives") or {}).items()]
        saida.append({"spec_id": sid, "nome": d.get("name", sid), "desc": d.get("desc", ""), "passivas": passivas})
    return saida


def _montar_ficha(p: dict, telegram_id: int, publica: bool) -> dict:
    from game.logic import recalc, ensure_player
    recalc(p)

    from game.assets import resolver_asset_key_item, chave_de_imagem_do_item

    equip_resumo = {}
    for slot, item in (p.get("equip") or {}).items():
        if not item:
            equip_resumo[slot] = None
            continue
        equip_resumo[slot] = {
            "nome": item.get("name", "?"),
            "raridade": item.get("rar", "comum"),
            "sockets_usados": len(item.get("socked", []) or []),
            "sockets_max": item.get("sock_max", 0),
            "img_key": chave_de_imagem_do_item(item, slot),
            # 📈 (28/09) bônus de raridade também na Ficha
            "bonus_raridade": __import__("game.logic", fromlist=["x"]).bonus_de_raridade_do_item(item, slot),
        }

    pets_resumo = []
    deck = (p.get("pets") or {}).get("deck", [None] * 5)
    for pet_id in deck:
        if not pet_id:
            pets_resumo.append(None)
            continue
        try:
            from game.pets_db import PETS_DB, get_pet_progress, derive_pet_combat_stats
            pet_base = PETS_DB.get(pet_id, {})
            prog = get_pet_progress(p, pet_id)
            # ⚔️ Os atributos que a Arena de Pets usa de verdade. Eles já
            # eram calculados por `derive_pet_combat_stats` e não apareciam
            # em tela nenhuma: o jogador montava o time sem saber qual pet
            # bate mais. Mesma função da Arena — nada recalculado aqui.
            combate = derive_pet_combat_stats(p, pet_id) or {}
            pets_resumo.append({
                "nome": pet_base.get("name", "?"),
                "raridade": pet_base.get("rarity", "comum"),
                "evolucao": prog.get("evolution", 1),
                "nivel": prog.get("level", 1),
                "img_key": f"PET_{pet_id.upper()}",
                "stats": {k: combate.get(k, 0) for k in
                          ("hp_max", "atk", "def", "spd", "acc", "eva", "crit")},
                "skill_id": combate.get("skill_id"),
            })
        except Exception:
            pets_resumo.append(None)

    from game.chakras import chakra_label
    ensure_player(p)  # garante chakra/skill_slots/etc. em jogadores antigos, sem duplicar a lógica
    if publica:
        # ficha de OUTRO jogador: nada de carteira (nem a cópia, nem o banco)
        p["premium"] = 0

    # ⭐ `p["premium"]` é CÓPIA da carteira, não a carteira (armadilha nº 17):
    # o saldo mora no premium.db. Sem ressincronizar, a barra do topo
    # mostrava o número congelado de quando o personagem foi salvo — foi
    # relatado como "as moedas premium não atualizam". `ensure_premium_player`
    # busca pelo user_id, então devolve a MESMA carteira do bot.
    if not publica:
        p["premium"] = _saldo_premium(p, telegram_id)

    # 🐎 A montaria equipada não aparecia em lugar nenhum da ficha, mesmo
    # dando bônus de ouro/XP na Torre.
    montaria = None
    try:
        from game.mounts import MOUNTS_DB
        mid = p.get("mount_equipped")
        if mid and mid in MOUNTS_DB:
            base_m = MOUNTS_DB[mid]
            montaria = {
                "id": mid,
                "nome": base_m.get("name", mid),
                "raridade": base_m.get("rarity", "comum"),
                "img_key": f"MOUNT_{str(mid).upper()}",
                "efeito": base_m.get("desc") or base_m.get("descricao") or "",
            }
    except Exception:
        montaria = None

    from game.logic import attrs_efetivos
    attrs = attrs_efetivos(p)

    ficha = {
        "username": p.get("username", "Jogador"),
        "sexo": p.get("sexo"),
        # 🧍 A arte do jogador deixou de ser "STATUS" fixo: é resolvida por
        # raça e sexo, com queda pra arte da raça e depois pro STATUS de
        # sempre. O front usa esta chave em TODAS as telas (ficha, topo,
        # combate), então a queda acontece num lugar só.
        "img_jogador": _arte_do_jogador(p),
        "poder": __import__("game.logic", fromlist=["calc_power_level"]).calc_power_level(p),
        "level": p.get("level", 1),
        "class_id": p.get("class_id"),
        "race_id": p.get("race_id"),
        "hp": p.get("hp", 0),
        "hp_max": p.get("hp_max", 1),
        "xp": p.get("xp", 0),
        "xp_next": p.get("xp_next", 1),
        "gold": p.get("gold", 0),
        "premium": p.get("premium", 0),
        "tower_floor": (p.get("explore_state", {}).get("saved_tower_floor")
                        if p.get("explore_mode") and p.get("explore_state", {}).get("saved_tower_floor") is not None
                        else p.get("tower_floor", 1)),
        "chakra": chakra_label(p.get("chakra")),
        # 🌱 (28/09) nascido na Torre: +10% em tudo, raça e profissão sorteadas
        "nascido_na_torre": bool(p.get("origem_aldeao")),
        "stats": {
            "atk": p.get("atk", 0),
            "def": p.get("def", 0),
            "spd": p.get("spd", 0),
            "acc": p.get("acc", 0),
            "eva": p.get("eva", 0),
            "crit": p.get("crit", 0),
            "reg": p.get("reg", 0),
        },
        # `attrs` continua sendo o TOTAL (é o que o jogo usa e o que a
        # ficha deve mostrar); `attrs_base` e `attrs_trilha` deixam a conta
        # visível — "1 de base + 32 da trilha = 33".
        "attrs": attrs["total"],
        "attrs_base": attrs["base"],
        "attrs_trilha": attrs["trilha"],
        "trail_points": int(p.get("trail_points", 0) or 0),
        "equip": equip_resumo,
        "pets": pets_resumo,
        "mount": montaria,
        # 👤 (28/09) também na ficha: o que está equipado de habilidade e
        # especialidade — é o que explica a força de um personagem
        "skills": _habilidades_da_ficha(p),
        "especialidades": _especialidades_da_ficha(p),
        "publica": publica,
    }
    if publica:
        # o que é da conta, não do personagem
        for chave in ("gold", "premium", "xp", "xp_next", "hp", "trail_points", "sexo"):
            ficha.pop(chave, None)
    return ficha


# =============================================================================
# 🖼️ PROXY DE IMAGEM — o navegador não consegue acessar file_id do
# Telegram direto; baixa uma vez aqui e guarda em cache na memória.
# =============================================================================

_image_cache: dict[str, bytes] = {}
_IMAGE_CACHE_MAX_ENTRIES = 500


@app.get("/api/imagem/{chave}")
async def get_imagem(chave: str, w: int = 0):
    """Ordem de busca: memória -> miniatura em disco -> arquivo em disco.
    (O Telegram era a última rede; saiu com o bot em 20/09/2026.)"""
    from webapp import imagens

    if not imagens.chave_valida(chave):
        raise HTTPException(status_code=400, detail="Chave de imagem inválida.")

    cabecalho = {"Cache-Control": "public, max-age=86400"}

    if chave in _image_cache:
        conteudo = _image_cache[chave]
        return Response(content=conteudo, headers=cabecalho,
                        media_type=imagens.tipo_da_imagem(conteudo) or "image/jpeg")

    # 🖼️ Miniatura na medida pedida. A arte de 1280px desenhada a 42px é
    # banda jogada fora — e no WebView de celular isso aparece como tela
    # que demora pra montar.
    largura = imagens.largura_valida(w) if w else None
    if largura:
        mini = imagens.ler_miniatura(chave, largura)
        if mini:
            return Response(content=mini, media_type="image/jpeg", headers=cabecalho)

    conteudo = imagens.ler_local(chave)
    if conteudo:
        _guardar_no_cache(chave, conteudo)
        # O tipo sai dos bytes: arte enviada pelo /admin pode ser PNG ou WEBP,
        # e servir PNG dizendo "jpeg" depende do navegador adivinhar.
        return Response(content=conteudo, headers=cabecalho,
                        media_type=imagens.tipo_da_imagem(conteudo) or "image/jpeg")

    # Sem arquivo em disco, a arte não existe (o download pelo Telegram saiu
    # com o bot). 404 faz o front cair na reserva (emoji). Pra pôr a arte:
    # /admin → Imagens → 📤 Enviar.
    raise HTTPException(status_code=404, detail=f"Arte '{chave}' não está no servidor.")


def _guardar_no_cache(chave: str, conteudo: bytes) -> None:
    if len(_image_cache) >= _IMAGE_CACHE_MAX_ENTRIES:
        _image_cache.pop(next(iter(_image_cache)))
    _image_cache[chave] = conteudo


# =============================================================================
# 🎒 INVENTÁRIO — equipar/desequipar itens
# =============================================================================

# =============================================================================
# 🔒 UMA REQUISIÇÃO POR JOGADOR DE CADA VEZ
# Achado no teste de concorrência de 11/09/2026: 12 pedidos de teleporte
# simultâneos do MESMO jogador cobraram 200g em vez de 1200g. Cada thread leu
# o mesmo saldo (1000), descontou 100 e gravou 900 — a última gravação vence
# e as outras onze somem. É o problema clássico de ler-modificar-gravar.
#
# Não vira ouro infinito, mas vira COBRANÇA perdida: tocar o botão várias
# vezes rápido paga uma vez só. E vale pra tudo que gasta — poção, VIP,
# forja, compra no mercado —, não só o teleporte.
#
# A trava é POR JOGADOR: dois jogadores diferentes nunca esperam um pelo
# outro. Como as rotas são síncronas e rodam no threadpool do FastAPI, um
# Lock comum aqui não segura o event loop.
#
# Ela mora em _carregar_jogador/_salvar_jogador de propósito: são os dois
# pontos por onde TODA rota passa. Espalhar `with trava(...)` por 123 rotas
# seria garantir que alguém esquece numa rota nova.
# =============================================================================

import threading as _threading

_TRAVAS_JOGADOR: dict[int, "_threading.Lock"] = {}
_TRAVA_DAS_TRAVAS = _threading.Lock()

# Rede de segurança. Se um dia alguém segurar a trava e sumir, o jogador vê
# um erro claro em 20s em vez de um "carregando" eterno que come as threads
# do pool até o processo inteiro (bot incluso) parar. Nenhuma rota legítima
# chega perto disso: a mais lenta é /api/clan, que monta perfis de AFK em
# dezenas de ms.
ESPERA_MAXIMA_TRAVA = 20.0


def _pegar_trava(telegram_id: int):
    with _TRAVA_DAS_TRAVAS:
        return _TRAVAS_JOGADOR.setdefault(int(telegram_id), _threading.Lock())


def _soltar_trava_pendente() -> None:
    """Solta a trava que ESTA REQUISIÇÃO ainda segure.

    ⚠️ Antes isto olhava um `threading.local()`, e aí só funcionava se a
    próxima requisição do mesmo jogador caísse na mesma thread do pool —
    o que o FastAPI não garante. Era o travamento do "Explorar": a rota de
    leitura prendia a trava numa thread, a rota seguinte caía noutra e
    esperava pra sempre. Ver a nota grande no topo do arquivo.

    Continua existindo pras rotas que carregam dois jogadores (mercado,
    troca): carregar o segundo solta o primeiro, como sempre foi. O caso
    normal — soltar no fim da requisição — é a RotaQueSoltaATrava que faz,
    e ela não tem como ser esquecida.
    """
    caixa = _TRAVA_DO_PEDIDO.get()
    if not caixa:
        return
    trava = caixa.get("trava")
    if trava is not None:
        try:
            trava.release()
        except RuntimeError:
            pass   # já estava solta; nada a fazer
        caixa["trava"] = None


def _carregar_jogador(telegram_id: int, permitir_bloqueada: bool = False):
    """Carrega (ou cria) o jogador e recalcula os stats. Compartilhado por
    todos os endpoints que precisam do estado completo do jogador.

    🔒 11/09/2026 — A checagem de conta bloqueada mora AQUI, e não em cada
    rota, porque só assim ela não pode ser esquecida numa rota nova. O bot
    barrava conta bloqueada (core/router.py:251); o Mini App nunca barrou, e
    conta_bloqueada nem era gravada no banco. Ou seja: o admin bloqueava por
    Pix não confirmado e a pessoa continuava jogando normalmente pelo app,
    e depois de um reinício o bloqueio sumia até no bot.

    `permitir_bloqueada` existe pras poucas rotas que a pessoa bloqueada
    PRECISA alcançar — ver o próprio status e resetar a conta. Sem essa
    saída, o bloqueio viraria uma parede sem porta.
    """
    from game.sql_repo import load_player
    from game.logic import create_player, recalc

    _soltar_trava_pendente()
    trava = _pegar_trava(telegram_id)
    if not trava.acquire(timeout=ESPERA_MAXIMA_TRAVA):
        # Não pode virar espera infinita: cada requisição pendurada come uma
        # thread do pool, e quando o pool acaba o processo inteiro para.
        raise HTTPException(status_code=409, detail="Outra ação sua ainda está "
                            "em andamento. Tente de novo em alguns segundos.")
    caixa = _TRAVA_DO_PEDIDO.get()
    if caixa is not None:
        caixa["trava"] = trava
    else:
        # Fora de uma requisição (script, teste, o bot chamando direto) não
        # há quem solte no fim — então não segura.
        trava.release()

    p = load_player(telegram_id)
    if not p:
        p = create_player(telegram_id)

    # 🟢 Marca presença. O bot gravava isto a cada clique (core/router.py:216);
    # o site nunca gravou, então quem jogasse só pelo Mini App aparecia como
    # sumido há dias. É o carimbo que o contador de "online agora" lê.
    p["last_update"] = int(time.time())

    bloqueio = p.get("conta_bloqueada")
    if bloqueio and not permitir_bloqueada:
        _soltar_trava_pendente()   # a rota vai abortar; não deixa a trava presa
        raise HTTPException(status_code=403, detail={
            "bloqueada": True,
            "motivo": bloqueio.get("motivo") or "Pagamento não confirmado.",
            "pedido": bloqueio.get("order_id"),
            "desde": bloqueio.get("since"),
        })

    recalc(p)
    return p


def _salvar_jogador(telegram_id: int, p: dict) -> None:
    from game.sql_repo import save_player_sql
    try:
        save_player_sql(telegram_id, p)
    finally:
        # Solta mesmo se a gravação falhar — senão um erro de banco deixaria
        # o jogador travado até o processo reiniciar.
        _soltar_trava_pendente()


def _resumo_item(item: dict, slot: str = "") -> dict:
    if not item:
        return None
    from game.assets import resolver_asset_key_item, chave_de_imagem_do_item
    from game.craft import nome_bonito_do_item
    return {
        "nome": nome_bonito_do_item(item.get("name", "?")),
        "raridade": item.get("rar", "comum"),
        "bonus": item.get("bonus", {}),
        "sockets_usados": len(item.get("socked", []) or []),
        "sockets_max": item.get("sock_max", 0),
        "img_key": chave_de_imagem_do_item(item, slot),
        "bonus_raridade": __import__("game.logic", fromlist=["x"]).bonus_de_raridade_do_item(item, slot),
    }


@app.get("/api/inventory")
def get_inventory(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))

    from game.items import SLOTS

    resultado = {}
    for slot in SLOTS:
        equipado = p.get("equip", {}).get(slot)
        mochila = p.get("inv", {}).get("items", {}).get(slot, [])
        resultado[slot] = {
            "equipado": _resumo_item(equipado, slot),
            "mochila": [dict(_resumo_item(it, slot), idx=i) for i, it in enumerate(mochila)],
        }
    return JSONResponse({"gold": p.get("gold", 0), "slots": resultado})


@app.post("/api/inventory/equip")
def post_inventory_equip(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    slot = corpo.get("slot")
    idx = corpo.get("idx")

    if slot is None or idx is None:
        raise HTTPException(status_code=400, detail="Faltando 'slot' ou 'idx'.")

    from game.logic import equip_from_inventory

    p = _carregar_jogador(telegram_id)
    msg = equip_from_inventory(p, slot, int(idx))
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


@app.post("/api/inventory/unequip")
def post_inventory_unequip(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    slot = corpo.get("slot")
    if slot is None:
        raise HTTPException(status_code=400, detail="Faltando 'slot'.")

    from game.logic import unequip_item

    p = _carregar_jogador(telegram_id)
    msg = unequip_item(p, slot)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


# =============================================================================
# 🐾 PETS — esquadrão, evolução e nível
# =============================================================================

def _resumo_auto_skill(auto) -> dict | None:
    """A skill automática do pet, com o nome resolvido."""
    if not auto or not auto.get("skill_id"):
        return None
    from game.skills import get_skill_by_id
    info = get_skill_by_id(auto["skill_id"]) or {}
    sk = info.get("skill") or {}
    return {"id": auto["skill_id"], "nome": sk.get("name", auto["skill_id"]),
            "cooldown": auto.get("cooldown"),
            "forca": auto.get("power_mult")}


def _stats_do_pet(p: dict, pet_id: str) -> dict:
    """Atributos de combate do pet, pela MESMA função que a Arena usa."""
    try:
        from game.pets_db import derive_pet_combat_stats
        st = derive_pet_combat_stats(p, pet_id) or {}
        return {k: st.get(k, 0) for k in ("hp_max", "atk", "def", "spd", "acc", "eva", "crit")}
    except Exception:
        return {}


def _acoes_do_pet(base: dict) -> list[dict]:
    """As 4 opções de batalha do pet (ataque básico + 3 do arquétipo)."""
    try:
        from game.pet_skills import skills_do_pet
        return [{"nome": s["nome"], "icone": s.get("icone", "✨"),
                 "descricao": s.get("descricao", ""), "recarga": s.get("recarga", 0)}
                for s in skills_do_pet(base.get("archetype"), base.get("rarity"))]
    except Exception:
        return []


@app.get("/api/pets")
def get_pets(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))

    from game.pets_db import PETS_DB, get_pet_progress

    owned = p.get("pets", {}).get("owned", {})
    deck = p.get("pets", {}).get("deck", [None] * 5)

    lista_owned = []
    for pet_id, qtd in owned.items():
        base = PETS_DB.get(pet_id)
        if not base:
            continue
        prog = get_pet_progress(p, pet_id)
        lista_owned.append({
            "pet_id": pet_id,
            "nome": base.get("name", "?"),
            "raridade": base.get("rarity", "comum"),
            "quantidade": qtd,
            "evolucao": prog.get("evolution", 1),
            "nivel": prog.get("level", 1),
            "img_key": f"PET_{pet_id.upper()}",
            "arquetipo": base.get("archetype"),
            "bonus_stats": base.get("bonus_stats") or {},
            "mecanica": base.get("mechanic") or None,
            "economia": base.get("economy_buff") or None,
            # A skill que o pet dispara sozinho no combate. Estava no
            # PETS_DB desde sempre e nunca chegava na tela — o jogador
            # montava o esquadrão sem saber o que cada bicho faz em luta.
            "auto_skill": _resumo_auto_skill(base.get("auto_skill")),
            # ⚔️ 20/09/2026: os atributos de COMBATE e as 4 opções de
            # batalha passaram a viver AQUI, na tela dos Espíritos — que é
            # onde se decide o esquadrão. Na ficha do personagem eles só
            # enchiam o slot; quem compara pet com pet está nesta tela.
            "stats": _stats_do_pet(p, pet_id),
            "acoes": _acoes_do_pet(base),
        })

    deck_resumo = []
    for pet_id in deck:
        if not pet_id:
            deck_resumo.append(None)
            continue
        base = PETS_DB.get(pet_id, {})
        prog = get_pet_progress(p, pet_id)
        deck_resumo.append({
            "pet_id": pet_id, "nome": base.get("name", "?"),
            "raridade": base.get("rarity", "comum"),
            "evolucao": prog.get("evolution", 1), "nivel": prog.get("level", 1),
            "img_key": f"PET_{pet_id.upper()}",
            "arquetipo": base.get("archetype"),
            "bonus_stats": base.get("bonus_stats") or {},
            "mecanica": base.get("mechanic") or None,
            "economia": base.get("economy_buff") or None,
            # A skill que o pet dispara sozinho no combate. Estava no
            # PETS_DB desde sempre e nunca chegava na tela — o jogador
            # montava o esquadrão sem saber o que cada bicho faz em luta.
            "auto_skill": _resumo_auto_skill(base.get("auto_skill")),
            # ⚔️ 20/09/2026: os atributos de COMBATE e as 4 opções de
            # batalha passaram a viver AQUI, na tela dos Espíritos — que é
            # onde se decide o esquadrão. Na ficha do personagem eles só
            # enchiam o slot; quem compara pet com pet está nesta tela.
            "stats": _stats_do_pet(p, pet_id),
            "acoes": _acoes_do_pet(base),
        })

    from game.pets_db import copias_extras_por_raridade, FUSAO_QTD, FUSAO_CHANCE
    return JSONResponse({"gold": p.get("gold", 0), "owned": lista_owned, "deck": deck_resumo,
                         # 🔮 (26/09) fusão: cópias extras por raridade
                         "fusao": {"extras": copias_extras_por_raridade(p), "qtd": FUSAO_QTD,
                                   "chance": round(FUSAO_CHANCE * 100)}})


@app.post("/api/pets/equip")
def post_pets_equip(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    pet_id = corpo.get("pet_id")  # None/"remove" limpa o slot
    slot_idx = corpo.get("slot_idx")
    if slot_idx is None:
        raise HTTPException(status_code=400, detail="Faltando 'slot_idx'.")

    from game.logic import equip_pet

    p = _carregar_jogador(telegram_id)
    msg = equip_pet(p, pet_id or "remove", int(slot_idx))
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


@app.post("/api/pets/fundir")
def post_pets_fundir(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """🔮 (26/09) 5 espíritos da mesma raridade → 15% de virar 1 da de cima."""
    from game.pets_db import fundir_pets
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    r = fundir_pets(p, str((corpo or {}).get("raridade") or ""))
    if not r.get("ok"):
        raise HTTPException(status_code=409, detail=r.get("erro") or "Não deu.")
    _salvar_jogador(telegram_id, p)
    return JSONResponse(r)


@app.post("/api/pets/evolve")
def post_pets_evolve(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    pet_id = corpo.get("pet_id")
    if not pet_id:
        raise HTTPException(status_code=400, detail="Faltando 'pet_id'.")

    from game.pets_db import evolve_pet

    p = _carregar_jogador(telegram_id)
    ok, msg = evolve_pet(p, pet_id)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": ok, "msg": msg})


@app.post("/api/pets/level")
def post_pets_level(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    """Sobe o nível de um pet sacrificando cópias de OUTROS pets de uma
    raridade escolhida. Auto-seleciona os materiais (prioriza quem tem
    mais cópias sobrando) — o mesmo algoritmo do fluxo no bot."""
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    pet_id = corpo.get("pet_id")
    raridade = corpo.get("raridade")
    quantidade = int(corpo.get("quantidade", 0))
    if not pet_id or not raridade or quantidade <= 0:
        raise HTTPException(status_code=400, detail="Faltando 'pet_id', 'raridade' ou 'quantidade' inválida.")

    from game.pets_db import level_up_pet, PETS_DB

    p = _carregar_jogador(telegram_id)
    owned = p.get("pets", {}).get("owned", {})

    candidatos = sorted(
        [(pid, q) for pid, q in owned.items()
         if PETS_DB.get(pid, {}).get("rarity") == raridade and pid != pet_id and q > 1],
        key=lambda kv: kv[1], reverse=True
    )
    materiais = []
    restante = quantidade
    for pid, q in candidatos:
        if restante <= 0:
            break
        extras = q - 1  # sempre guarda 1 cópia protegida de cada pet
        pega = min(extras, restante)
        materiais.extend([pid] * pega)
        restante -= pega

    ok, msg = level_up_pet(p, pet_id, materiais)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": ok, "msg": msg})


# =============================================================================
# ⚔️ SKILLS
# =============================================================================

def _cores_de_skill(p: dict) -> list:
    """Cores do inventário que correspondem a uma skill aprendível."""
    from game.skills import SKILL_DB
    aprendidas = p.get("skills_learned") or {}
    saida = []
    for core_id, qtd in ((p.get("inv") or {}).get("cores") or {}).items():
        if int(qtd or 0) <= 0:
            continue
        dados = SKILL_DB.get(core_id)
        skill = (dados or {}).get("skill")
        if not skill:
            continue
        sid = skill.get("id") or core_id
        saida.append({"id": core_id, "qtd": int(qtd),
                      "nome": skill.get("name", core_id),
                      "ja_aprendida": sid in aprendidas})
    saida.sort(key=lambda c: c["nome"])
    return saida


@app.get("/api/skills")
def get_skills(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))

    from game.skills import format_skill_affix

    learned = p.get("skills_learned", {})
    equipados = p.get("skill_slots", {}).get("equipped", [None] * 5)

    # O core que ENSINA cada skill. Aprender de novo com ele é o que evolui
    # (learn_skill_from_core faz as duas coisas), e sem saber qual core é, o
    # jogador não tinha como usar a mecânica que já existia.
    from game.skills import SKILL_DB
    core_da_skill = {}
    for cid, info in SKILL_DB.items():
        sid = (info.get("skill") or {}).get("id")
        if sid and sid not in core_da_skill:
            core_da_skill[sid] = {"core_id": cid, "core_nome": info.get("name", cid)}

    cores_guardados = (p.get("inv", {}) or {}).get("cores", {}) or {}

    lista = []
    for skill_id, dados in learned.items():
        nivel = int(dados.get("level", 1) or 1)
        fonte = core_da_skill.get(skill_id, {})
        cid = fonte.get("core_id")
        lista.append({
            "skill_id": skill_id,
            "nome": dados.get("name", "?"),
            "tipo": dados.get("type", "active"),
            "raridade": int(dados.get("rarity", 1)),
            "nivel": nivel,
            "nivel_max": 10,
            "bonus_texto": format_skill_affix(dados.get("affix"), int(dados.get("rarity", 1) or 1),
                                              int(dados.get("level", 1) or 1)),
            "equipado_em": equipados.index(skill_id) if skill_id in equipados else None,
            # Tudo que a carta mostra no verso:
            "cooldown": dados.get("cooldown"),
            "mult": dados.get("mult"),
            "alvo": dados.get("target"),
            "bonuses": dados.get("bonuses") or {},
            "bonus_pct": dados.get("bonus_pct") or {},
            # E a evolução, com a conta pronta:
            "evolucao": None if nivel >= 10 or not cid else {
                "core_id": cid, "core_nome": fonte.get("core_nome"),
                "custo": nivel + 1,
                "tem": int(cores_guardados.get(cid, 0) or 0),
                "ganho": "+10% em tudo que a skill faz",
            },
        })

    return JSONResponse({"aprendidas": lista, "equipadas": equipados,
        # 📚 11/09/2026 — as cores de skill que o jogador tem guardadas.
        # Sem elas a tela não tinha como oferecer "aprender", e as cores
        # ficavam no inventário sem uso nenhum pelo site.
        "cores_skill": _cores_de_skill(p)})


@app.post("/api/skills/equip")
def post_skills_equip(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    skill_id = corpo.get("skill_id")
    slot_idx = corpo.get("slot_idx")
    if not skill_id or slot_idx is None:
        raise HTTPException(status_code=400, detail="Faltando 'skill_id' ou 'slot_idx'.")

    from game.logic import equip_skill

    p = _carregar_jogador(telegram_id)
    msg = equip_skill(p, skill_id, "equipped", int(slot_idx))
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


@app.post("/api/skills/unequip")
def post_skills_unequip(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    slot_idx = corpo.get("slot_idx")
    if slot_idx is None:
        raise HTTPException(status_code=400, detail="Faltando 'slot_idx'.")

    from game.logic import equip_skill

    p = _carregar_jogador(telegram_id)
    msg = equip_skill(p, "remove", "equipped", int(slot_idx))
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


# =============================================================================
# 📜 MISSÕES
# =============================================================================

@app.get("/api/pendencias")
def get_pendencias(authorization: str | None = Header(None)):
    """🔴 (26/09/2026, dev) o que está esperando o jogador — vira ponto
    vermelho na aba e no atalho da página: missões/diárias prontas, pontos
    de trilha pra gastar, aldeões livres e crônicas esperando decisão."""
    from game import diarias as D
    from game.missions import status_missoes
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    st = D.status(p)
    missoes = sum(1 for d in st.get("diarias") or [] if d.get("pronta") and not d.get("resgatada")) \
        + (1 if st.get("bonus_pronto") else 0) \
        + sum(1 for m in status_missoes(p) if m.get("concluida") and not m.get("resgatada"))
    saida = {"missoes": missoes, "trilhas": int(p.get("trail_points") or 0), "aldeia": 0, "cronicas": 0,
             "clan_bloqueado": True}
    try:
        from game import clan_repo as CR, cronicas as K
        with CR._conn() as c:
            existe = c.execute("SELECT 1 FROM clan WHERE owner_id = ?", (telegram_id,)).fetchone()
        if existe or int(p.get("tower_floor") or 1) > 1:
            clan = CR.carregar_clan(telegram_id)
            K.garantir_fundacao(telegram_id, p)
            clan = CR.carregar_clan(telegram_id)
            if K.fundado(clan):
                saida["clan_bloqueado"] = False
                saida["aldeia"] = sum(1 for h in CR.listar_habitantes(telegram_id)
                                      if not h.get("funcao") and not h.get("descansando"))
                # 🎁 (28/09) sessão AFK esperando o "Receber": acende o 🔴 do Clã
                saida["recompensa_cla"] = CR.quantos_ticks(clan)[0] > 0
                saida["aldeia"] += int(saida["recompensa_cla"])
                saida["cronicas"] = len(K.carregar(clan)["fila"])
    except Exception:
        pass
    return JSONResponse(saida)


@app.get("/api/diarias")
def get_diarias(authorization: str | None = Header(None)):
    """📅 As missões diárias de hoje (o que o reino paga)."""
    from game import diarias as D
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    antes = (p.get("diarias") or {}).get("dia")
    st = D.status(p)
    if antes != st["dia"]:
        _salvar_jogador(telegram_id, p)        # virou o dia: grava o zerado
    return JSONResponse(st)


@app.post("/api/diarias/resgatar")
def post_diarias_resgatar(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    from game import diarias as D
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    ok, msg, _ouro = D.resgatar(p, str((corpo or {}).get("id") or ""))
    if not ok:
        raise HTTPException(status_code=409, detail=msg)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True, "msg": msg, "gold": p["gold"], **D.status(p)})


@app.get("/api/missions")
def get_missions(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))

    from game.missions import status_missoes

    return JSONResponse({"missoes": status_missoes(p)})


@app.post("/api/missions/claim")
def post_missions_claim(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    missao_id = corpo.get("missao_id")
    if not missao_id:
        raise HTTPException(status_code=400, detail="Faltando 'missao_id'.")

    from game.missions import resgatar_recompensa

    p = _carregar_jogador(telegram_id)
    ok, msg = resgatar_recompensa(p, missao_id)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": ok, "msg": msg})


# =============================================================================
# 🏆 RANKING
# =============================================================================

_RANKING_FUNCOES = {
    "floors": ("get_ranking_floors_sync", "floor", "🗼"),
    "gold": ("get_ranking_gold_sync", "gold", "💰"),
    "level": ("get_ranking_level_sync", "level", "✨"),
    "arena": ("get_ranking_arena_sync", "arena_points", "⚔️"),
}


@app.get("/api/ranking")
def get_ranking(request: Request, authorization: str | None = Header(None)):
    _extrair_usuario(authorization)  # só pra confirmar que é um usuário válido
    tipo = request.query_params.get("tipo", "floors") if hasattr(request, "query_params") else "floors"

    if tipo not in _RANKING_FUNCOES:
        raise HTTPException(status_code=400, detail=f"Tipo de ranking inválido: {tipo}")

    nome_fn, campo_valor, icone = _RANKING_FUNCOES[tipo]
    import game.sql_repo as sql_repo
    fn = getattr(sql_repo, nome_fn)
    lista = fn(limit=10)

    return JSONResponse({"tipo": tipo, "icone": icone, "campo": campo_valor,
                         "ranking": lista, "comunidade": _comunidade()})


def _comunidade() -> dict:
    """Quantos estão jogando agora, como no Mestre do Futebol.

    Janela de 5 minutos pra "online": mais curto pisca o número a cada
    recarga e faz o jogo parecer vazio; mais longo conta quem já fechou.
    As faixas de 24h e 7 dias existem porque num jogo pequeno "0 online"
    às 3 da manhã não quer dizer abandono — e é a única leitura possível
    se esse for o único número na tela."""
    import time as _t
    from game.sql_repo import get_connection
    agora = int(_t.time())
    try:
        with get_connection() as c:
            linha = c.execute(
                "SELECT COUNT(*) AS total,"
                " SUM(CASE WHEN last_update > ? THEN 1 ELSE 0 END) AS agora,"
                " SUM(CASE WHEN last_update > ? THEN 1 ELSE 0 END) AS dia,"
                " SUM(CASE WHEN last_update > ? THEN 1 ELSE 0 END) AS semana"
                " FROM players",
                (agora - 300, agora - 86400, agora - 604800)).fetchone()
        return {"total": int(linha["total"] or 0),
                "online_agora": int(linha["agora"] or 0),
                "ativos_24h": int(linha["dia"] or 0),
                "ativos_7d": int(linha["semana"] or 0)}
    except Exception as e:
        # Contador é enfeite informativo: não pode derrubar o ranking.
        print(f"⚠️ [COMUNIDADE] falha ao contar online: {e}")
        return {}


# =============================================================================
# 🛡️ ESPECIALIDADE
# =============================================================================

@app.get("/api/specialties")
def get_specialties(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))

    from game.logic import get_specialty_slots
    from game.specialties import SPECIALTIES_DB

    equipadas = get_specialty_slots(p)
    todas = [
        {"spec_id": sid, "nome": d.get("name", "?"), "desc": d.get("desc", ""),
         # O verso da carta mostra o que a especialidade FAZ, em número —
         # a descrição em prosa sozinha não deixa comparar duas.
         "passivas": d.get("passives") or {},
         "gatilhos": d.get("triggers") or {}}
        for sid, d in SPECIALTIES_DB.items()
    ]
    return JSONResponse({"todas": todas, "equipadas": equipadas, "level": p.get("level", 1)})


@app.post("/api/specialties/equip")
def post_specialties_equip(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    spec_id = corpo.get("spec_id")
    slot_idx = corpo.get("slot_idx")
    if not spec_id or slot_idx is None:
        raise HTTPException(status_code=400, detail="Faltando 'spec_id' ou 'slot_idx'.")

    from game.logic import equip_specialty

    p = _carregar_jogador(telegram_id)
    msg = equip_specialty(p, spec_id, int(slot_idx))
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


@app.post("/api/specialties/unequip")
def post_specialties_unequip(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    slot_idx = corpo.get("slot_idx")
    if slot_idx is None:
        raise HTTPException(status_code=400, detail="Faltando 'slot_idx'.")

    from game.logic import unequip_specialty

    p = _carregar_jogador(telegram_id)
    msg = unequip_specialty(p, int(slot_idx))
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


# =============================================================================
# 🔮 TEMPLO DE EVOCAÇÃO (gacha de pets)
# =============================================================================

@app.post("/api/gacha/roll")
def post_gacha_roll(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    amount = int(corpo.get("amount", 1))
    if amount not in (1, 11):
        raise HTTPException(status_code=400, detail="'amount' precisa ser 1 ou 11.")

    from game.logic import roll_pet_gacha
    from game.pets_db import PETS_DB

    p = _carregar_jogador(telegram_id)

    _exigir_cidade(p)
    ok, msg, rolled = roll_pet_gacha(p, amount)
    _salvar_jogador(telegram_id, p)

    resultado = [
        {"pet_id": pid, "nome": PETS_DB.get(pid, {}).get("name", "?"), "raridade": PETS_DB.get(pid, {}).get("rarity", "comum"),
         "img_key": f"PET_{pid.upper()}"}
        for pid in rolled
    ]
    return JSONResponse({"ok": ok, "msg": msg, "gold_restante": p.get("gold", 0), "rolados": resultado})


# =============================================================================
# 🐴 ESTÁBULO (gacha de montarias)
# =============================================================================

# 🐴 Montaria só a partir do andar 10. Existe pra a montaria chegar quando
# ela significa alguma coisa: antes disso o jogador não tem ouro pro gacha
# nem distância pra sentir o bônus de deslocamento, e gastar ali é o tipo de
# escolha ruim que o jogo não deveria oferecer.
#
# O bloqueio vale pra INVOCAR e EQUIPAR. Quem já tem uma equipada de antes
# não perde — tirar à força seria punir por uma regra nova.
ANDAR_MINIMO_MONTARIA = 10


def _exigir_andar_de_montaria(p: dict) -> None:
    andar = int(p.get("tower_floor", 1) or 1)
    if andar < ANDAR_MINIMO_MONTARIA:
        raise HTTPException(
            status_code=403,
            detail=f"Montarias só a partir do andar {ANDAR_MINIMO_MONTARIA}. "
                   f"Você está no {andar} — suba a Torre e volte.")


@app.get("/api/stable")
def get_stable(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))
    _exigir_cidade(p)

    from game.mounts import MOUNTS_DB

    owned = p.get("mounts_owned", {})
    equipado = p.get("mount_equipped")

    lista = [
        {
            "mount_id": mid, "nome": MOUNTS_DB.get(mid, {}).get("name", "?"),
            "raridade": MOUNTS_DB.get(mid, {}).get("rarity", "comum"), "quantidade": qtd,
            "img_key": f"MOUNT_{mid.upper()}",
            # O card mostra o que a montaria FAZ. Sem isto, escolher entre
            # duas era escolher pelo nome.
            "bonus_stats": MOUNTS_DB.get(mid, {}).get("bonus_stats") or {},
            "mecanica": MOUNTS_DB.get(mid, {}).get("mechanic") or None,
        }
        for mid, qtd in owned.items() if qtd > 0
    ]
    andar = int(p.get("tower_floor", 1) or 1)
    return JSONResponse({"owned": lista, "equipado": equipado, "gold": p.get("gold", 0),
                         "andar": andar, "andar_minimo": ANDAR_MINIMO_MONTARIA,
                         "liberado": andar >= ANDAR_MINIMO_MONTARIA})


@app.post("/api/stable/roll")
def post_stable_roll(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    amount = int(corpo.get("amount", 1))
    if amount not in (1, 11):
        raise HTTPException(status_code=400, detail="'amount' precisa ser 1 ou 11.")

    from game.mounts import roll_mount_gacha, MOUNTS_DB

    p = _carregar_jogador(telegram_id)

    _exigir_cidade(p)
    _exigir_andar_de_montaria(p)
    ok, msg, rolled = roll_mount_gacha(p, amount)
    _salvar_jogador(telegram_id, p)

    resultado = [
        {"mount_id": mid, "nome": MOUNTS_DB.get(mid, {}).get("name", "?"), "raridade": MOUNTS_DB.get(mid, {}).get("rarity", "comum"),
         "img_key": f"MOUNT_{mid.upper()}"}
        for mid in rolled
    ]
    return JSONResponse({"ok": ok, "msg": msg, "gold_restante": p.get("gold", 0), "rolados": resultado})


@app.post("/api/stable/equip")
def post_stable_equip(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    mount_id = corpo.get("mount_id")
    if not mount_id:
        raise HTTPException(status_code=400, detail="Faltando 'mount_id'.")

    from game.mounts import equip_mount

    p = _carregar_jogador(telegram_id)

    _exigir_cidade(p)
    _exigir_andar_de_montaria(p)
    msg = equip_mount(p, mount_id)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


# =============================================================================
# 🛠️ FORJA
# =============================================================================
# 🔥 MELHORIA (09/07/2026): no bot no chat, escolher os cores é feito clique
# a clique (cada toque em um core manda uma requisição e volta a mesma tela).
# Aqui, a seleção fica guardada NO NAVEGADOR (o jogador marca os cores na
# tela) e só manda UMA requisição quando confirma — sem ida-e-volta ao
# servidor por core marcado. É uma vantagem real de ser um app de verdade
# em vez de um chat: o navegador guarda estado local, o Telegram bot não.

def _raridade_do_tier(tier: int) -> str:
    """Tier do core -> nome de raridade, só pra cor do cartão."""
    t = int(tier or 1)
    if t >= 15:
        return "lendario"
    if t >= 10:
        return "epico"
    if t >= 5:
        return "raro"
    if t >= 2:
        return "incomum"
    return "comum"


def _material_da_forja(p: dict, telegram_id: int) -> dict:
    from game.items import REQ_MATERIAL_CRAFT, MATERIAL_POR_TIER
    from game.clan_materiais import RANKS, onde_cai
    from game.craft import material_disponivel
    saida = {}
    for rar, req in REQ_MATERIAL_CRAFT.items():
        tem = material_disponivel(p, req["rank"], telegram_id)
        # "qtd" aqui é o PISO da raridade; o extra por tier de core depende
        # dos cores escolhidos e é somado na tela (`por_tier`), com a mesma
        # conta de `craft.custo_material`.
        saida[rar] = {"rank": req["rank"], "qtd": req["qtd"],
                      "por_tier": MATERIAL_POR_TIER,
                      "nome": RANKS[req["rank"]]["nome"],
                      "onde": onde_cai(req["rank"]),
                      "mochila": tem["mochila"], "cla": tem["cla"], "tem": tem["total"]}
    return saida


@app.get("/api/craft/cores")
def get_craft_cores(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))
    _exigir_cidade(p)

    from game.items import (core_name, core_base_and_tier, core_bonus,
                            core_bonus_pct, RARITIES)
    from game.craft import REQ_CRAFT, WEAPON_TYPES, COST_CRAFT
    from game.mythic_items import get_fusable_legendary_items, FUSION_COST, FUSION_SUCCESS_CHANCE

    cores = p.get("inv", {}).get("cores", {})
    lista_cores = [
        # O tier vira "raridade" só pra pintar o cartão: T1 comum, T20
        # lendário. Sem isso todos os cores saem cinza e iguais na tela, que
        # é exatamente o que o cartão grande veio resolver.
        {"core_id": cid, "nome": core_name(cid), "quantidade": qtd,
         "bonus": core_bonus(cid), "bonus_pct": core_bonus_pct(cid),
         "tier": core_base_and_tier(cid)[1],
         "raridade": _raridade_do_tier(core_base_and_tier(cid)[1])}
        for cid, qtd in cores.items() if qtd > 0
    ]

    slots_equip = ["weapon", "armor", "helmet", "gloves", "boots", "shield", "belt", "necklace", "ring"]
    fusao_miticos = [
        {"slot": slot, "disponiveis": len(get_fusable_legendary_items(p, slot))}
        for slot in slots_equip
    ]

    return JSONResponse({
        "gold": p.get("gold", 0),
        "cores": lista_cores,
        "raridades": RARITIES,
        "custos": COST_CRAFT,
        "requisitos": REQ_CRAFT,
        # 🔤 O cartão mostrava o ID cru do core ("wa_atk x2"), que é nome de
        # variável, não de item — ninguém sabia o que ir buscar. `core_name`
        # já existia e já é usada na loja e no engaste.
        "nomes_cores": {cid: core_name(cid) for cid in
                        {c for req in REQ_CRAFT.values() for c in req}},
        "tipos_arma": list(WEAPON_TYPES.keys()),
        # 🔤 (26/09) o cartão mostrava "sword"/"axe" crus
        "nomes_armas": {k: (v.get("name") or k) for k, v in WEAPON_TYPES.items()},
        "fusao_miticos": fusao_miticos,
        "fusao_custo": FUSION_COST,
        "fusao_chance": FUSION_SUCCESS_CHANCE,
        # ⛏️ Material por raridade, com quanto você TEM (mochila + clã). A
        # conta vai pronta: a tela não precisa saber de onde vem cada parte.
        "material": _material_da_forja(p, int(usuario["id"])),
    })


@app.post("/api/craft/mythic_fuse")
def post_craft_mythic_fuse(body: dict | None = Body(None), authorization: str | None = Header(None)):
    """Funde 5 itens Lendários da mesma categoria — chance de virar 1 item
    Mítico. Mesma função (fuse_legendary_items) que o bot já usa no chat."""
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)

    body = body or {}
    slot = str(body.get("slot", ""))

    from game.mythic_items import fuse_legendary_items
    ok, msg = fuse_legendary_items(p, slot)

    from game.sql_repo import save_player_sql
    save_player_sql(telegram_id, p)

    return JSONResponse({"ok": ok, "msg": msg})


# =============================================================================
# ✨ FUSÃO MÍTICA — tela própria
# =============================================================================
# Saiu do fim da Forja: lá embaixo, depois de slot, raridade e cores, ela era
# um bloco que ninguém rolava até. E a mecânica mudou — agora aceita 5
# Lendários QUAISQUER, e a composição decide o tipo do mítico.

@app.get("/api/fusao")
def get_fusao(authorization: str | None = Header(None)):
    from game.mythic_items import (lendarios_do_jogador, chance_por_tipo,
                                   FUSION_COST, FUSION_SUCCESS_CHANCE,
                                   SLOTS_MITICOS, PESO_DO_ITEM)
    from game.assets import resolver_asset_key_item, chave_de_imagem_do_item

    p = _carregar_jogador(int(_extrair_usuario(authorization)["id"]))
    _exigir_cidade(p)

    lendarios = lendarios_do_jogador(p)
    from game.logic import bonus_de_raridade_do_item
    _inv = (p.get("inv") or {}).get("items") or {}
    for it in lendarios:
        it["img_key"] = resolver_asset_key_item(it["slot"], "legendary", "")
        # 📈 (28/09) o bônus de raridade também aqui (só a Mochila mostrava)
        it["bonus_raridade"] = bonus_de_raridade_do_item(_inv[it["slot"]][it["idx"]], it["slot"])

    # 📖 (28/09, dev) catálogo dos 45 míticos pro carrossel da tela
    from game.mythic_items import catalogo_miticos
    catalogo = catalogo_miticos()

    # A tabela inteira vai pra tela: a chance por quantidade de iguais é
    # linear e simples, e mostrá-la é o que impede o jogador achar que a
    # fusão é roleta cega.
    tabela = [{"iguais": k,
               "chance": round(chance_por_tipo(["weapon"] * k
                                               + ["ring"] * (FUSION_COST - k))["weapon"], 4)}
              for k in range(FUSION_COST + 1)]

    return JSONResponse({
        "lendarios": lendarios,
        "catalogo": catalogo,
        "custo": FUSION_COST,
        "chance_sucesso": FUSION_SUCCESS_CHANCE,
        "tabela_tipo": tabela,
        "slots": SLOTS_MITICOS,
    })


@app.post("/api/fusao/fundir")
def post_fusao_fundir(corpo: dict | None = Body(None),
                      authorization: str | None = Header(None)):
    from game.mythic_items import fundir_composicao
    from game.assets import resolver_asset_key_item, chave_de_imagem_do_item

    corpo = corpo or {}
    escolhidos = corpo.get("itens")
    if not isinstance(escolhidos, list):
        raise HTTPException(status_code=400, detail="Faltando 'itens'.")

    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)

    antes = {s: len(((p.get("inv") or {}).get("items") or {}).get(s, []))
             for s in ((p.get("inv") or {}).get("items") or {})}
    ok, msg = fundir_composicao(p, escolhidos)

    # Qual slot cresceu = onde o mítico caiu. Mesmo truque do craft: não
    # dependo de o motor me devolver o item pra poder mostrá-lo na tela.
    item_novo = None
    if ok:
        itens = (p.get("inv") or {}).get("items") or {}
        for slot, lista in itens.items():
            if len(lista) > antes.get(slot, 0):
                item_novo = _resumo_item(lista[-1], slot)
                break

    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": ok, "msg": msg, "item": item_novo})


@app.post("/api/craft/confirm")
def post_craft_confirm(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    slot = corpo.get("slot")
    rar = corpo.get("rar")
    sub = corpo.get("sub")
    cores_selecionadas = corpo.get("cores", [])
    if not slot or not rar or not isinstance(cores_selecionadas, list):
        raise HTTPException(status_code=400, detail="Faltando 'slot', 'rar' ou 'cores'.")

    from game.craft import craft_confirm

    p = _carregar_jogador(telegram_id)

    _exigir_cidade(p)
    # monta o estado que craft_confirm espera, direto da seleção que o
    # navegador já fez — reaproveita 100% da validação/regra real do jogo
    # (quantidade exigida por raridade, requisitos mínimos por slot, custo
    # em ouro, chance de sucesso), só sem precisar do vaivém clique a clique.
    p["craft"] = {"slot": slot, "rar": rar, "sub": sub, "sel": list(cores_selecionadas)}

    # 🛠️ O ITEM FORJADO PRECISA VOLTAR.
    #
    # A rota devolvia só {ok, msg, gold}, então a janela de "item forjado!"
    # não tinha como mostrar arte, atributos nem o efeito de raridade — o
    # dado simplesmente nunca chegava no navegador. Forjar é o momento de
    # pagamento da Forja inteira e ele estava saindo como um toast de texto.
    #
    # craft_confirm anexa o item novo no fim da lista do slot; guardo o
    # tamanho antes pra saber qual é o novo sem depender de o motor me
    # devolver alguma coisa.
    antes = len(((p.get("inv") or {}).get("items") or {}).get(slot, []))
    ok, msg = craft_confirm(p, owner_id=telegram_id)
    depois = ((p.get("inv") or {}).get("items") or {}).get(slot, [])
    item_novo = _resumo_item(depois[-1], slot) if ok and len(depois) > antes else None

    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": ok, "msg": msg, "gold": p.get("gold", 0),
                         "item": item_novo})


# =============================================================================
# 🔄 MERCADO (P2P entre jogadores — negocia em ⭐, não em ouro)
# =============================================================================

@app.get("/api/market")
def get_market(request: Request, authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    # Esta rota lê só o catálogo global e não precisava do jogador. Carrego
    # mesmo assim: sem isso o Mercado seria o único serviço da cidade que
    # abre de qualquer lugar, e a inconsistência sairia mais cara que a
    # consulta a mais.
    _exigir_cidade(_carregar_jogador(int(usuario["id"])))
    slot = request.query_params.get("slot") if hasattr(request, "query_params") else None
    rarity = request.query_params.get("rarity") if hasattr(request, "query_params") else None
    page = int(request.query_params.get("page", 0)) if hasattr(request, "query_params") else 0
    ordem = request.query_params.get("ordem") if hasattr(request, "query_params") else None

    from game.trade_repo import trade_repo
    from game.assets import resolver_asset_key_item, chave_de_imagem_do_item

    itens, total = trade_repo.get_items_by_filter(
        slot=slot or None, rarity=rarity or None, page=page, per_page=10,
        ordem=ordem or "recentes")

    lista = [{
        "item_id": it["id"], "nome": it["item"].get("name", "?"), "slot": it["slot"],
        "raridade": it["rarity"], "preco": it["price"], "vendedor": it.get("seller_name", "?"),
        # Os atributos precisam chegar na tela: sem eles não dá pra comparar
        # dois anúncios nem justificar a ordenação por maior atk.
        "bonus": (it["item"].get("bonus") or {}),
        "sockets_max": it["item"].get("sock_max", 0),
        "img_key": chave_de_imagem_do_item(dict(it["item"], rar=it["item"].get("rar") or it["rarity"]), it["slot"]),
        "bonus_raridade": __import__("game.logic", fromlist=["x"]).bonus_de_raridade_do_item(
            dict(it["item"], rar=it["item"].get("rar") or it["rarity"]), it["slot"]),
    } for it in itens]

    return JSONResponse({"itens": lista, "total": total, "page": page,
                         "ordem": ordem or "recentes"})


@app.get("/api/market/mine")
def get_market_mine(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)

    from game.premium_system import ensure_premium_player
    from game.trade_repo import trade_repo
    from game.assets import resolver_asset_key_item, chave_de_imagem_do_item

    ensure_premium_player(p, user_id=telegram_id)
    pid = p.get("player_id") or p.get("playerid")
    itens = trade_repo.get_items_by_seller(pid) if pid else []

    lista = [{
        "item_id": it["id"], "nome": it["item"].get("name", "?"), "slot": it["slot"],
        "raridade": it["rarity"], "preco": it["price"],
        "img_key": chave_de_imagem_do_item(dict(it["item"], rar=it["item"].get("rar") or it["rarity"]), it["slot"]),
        "bonus_raridade": __import__("game.logic", fromlist=["x"]).bonus_de_raridade_do_item(
            dict(it["item"], rar=it["item"].get("rar") or it["rarity"]), it["slot"]),
    } for it in itens]

    return JSONResponse({"itens": lista, "premium": p.get("premium", 0)})


@app.post("/api/market/list")
def post_market_list(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    slot = corpo.get("slot")
    idx = corpo.get("idx")
    preco = int(corpo.get("preco", 50))
    if slot is None or idx is None:
        raise HTTPException(status_code=400, detail="Faltando 'slot' ou 'idx'.")

    from game.logic import marketplace_list_item
    from game.premium_system import ensure_premium_player

    p = _carregar_jogador(telegram_id)

    _exigir_cidade(p)
    ensure_premium_player(p, user_id=telegram_id)
    msg = marketplace_list_item(p, slot, int(idx), preco)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg, "premium": p.get("premium", 0)})


@app.post("/api/market/buy")
def post_market_buy(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    item_id = corpo.get("item_id")
    if item_id is None:
        raise HTTPException(status_code=400, detail="Faltando 'item_id'.")

    from game.logic import marketplace_buy_item
    from game.premium_system import ensure_premium_player

    p = _carregar_jogador(telegram_id)

    _exigir_cidade(p)
    ensure_premium_player(p, user_id=telegram_id)

    # 🔔 Quem vende precisa saber ANTES da compra acontecer, porque depois o
    # anúncio some do mercado e não dá mais pra descobrir de quem era nem
    # por quanto saiu. No caminho do bot isso virava p["_pending_notify"];
    # aqui nunca existiu, então o vendedor do Mini App nunca era avisado.
    from game import trade_repo as _trade
    try:
        anuncio = _trade.trade_repo.get_item_by_id(int(item_id)) or {}
    except Exception:
        anuncio = {}

    ok, msg = marketplace_buy_item(p, int(item_id))
    _salvar_jogador(telegram_id, p)

    if ok and anuncio:
        from webapp.avisos import item_vendido
        vendedor = anuncio.get("seller_chat_id") or anuncio.get("seller_id")
        nome = (anuncio.get("item") or {}).get("name", "Seu item")
        if vendedor:
            item_vendido(int(vendedor), nome, int(anuncio.get("price", 0)))

    return JSONResponse({"ok": ok, "msg": msg, "premium": p.get("premium", 0)})


@app.post("/api/market/cancel")
def post_market_cancel(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    item_id = corpo.get("item_id")
    if item_id is None:
        raise HTTPException(status_code=400, detail="Faltando 'item_id'.")

    from game.premium_system import ensure_premium_player
    from game.trade_repo import trade_repo

    p = _carregar_jogador(telegram_id)

    _exigir_cidade(p)
    ensure_premium_player(p, user_id=telegram_id)
    pid = p.get("player_id") or p.get("playerid")

    ok, result = trade_repo.cancel_item(int(item_id), pid)
    if ok:
        slot = result["slot"]
        inv = p.setdefault("inv", {}).setdefault("items", {})
        inv.setdefault(slot, []).append(result["item"])
        # 🔥 (09/07/2026): usa o telegram_id de verdade pra salvar — o
        # handler equivalente no bot usa 'chat_id', que coincide com o
        # telegram_id em conversa privada mas não é o dado certo por
        # definição; aqui uso a identidade que a autenticação confirmou.
        _salvar_jogador(telegram_id, p)
        msg = f"✅ {result['item'].get('name','Item')} devolvido ao inventário."
    else:
        msg = result

    return JSONResponse({"ok": ok, "msg": msg})


# =============================================================================
# 🗼 TORRE / COMBATE
# =============================================================================
# 🔥 Cada ação (attack/skill/flee) já resolve o turno INTEIRO por dentro —
# combat_attack/execute_combat_skill avançam o relógio de ATB sozinhos até
# ser a vez do jogador de novo, processando os golpes do inimigo pelo
# caminho. A API só chama a ação e devolve o retrato atualizado do combate.

def _cooldown_revive_se_morto(p: dict) -> int:
    """Segundos restantes até o portal divino (revive grátis) reabrir —
    só calcula se o jogador está morto, pra não gastar import à toa."""
    if p.get("hp", 1) > 0:
        return 0
    from game.logic import get_free_revive_cooldown, e_novato
    # 🛡️ novato não espera: o portal está sempre aberto até o andar 10
    return 0 if e_novato(p) else get_free_revive_cooldown(p)


def _arte_do_jogador(p: dict) -> str:
    from game.assets import resolver_asset_key_jogador
    return resolver_asset_key_jogador(p.get("race_id"), p.get("sexo"))


def _saldo_premium(p: dict, telegram_id: int) -> int:
    """Saldo de ⭐ lido da carteira, nunca de p["premium"].

    `p["premium"]` é uma CÓPIA: `spend_premium`/`add_premium` mexem no
    premium.db e não tocam nela (armadilha nº 17). Toda rota que devolve
    saldo pra barra de cima passa por aqui."""
    try:
        from game.premium_system import ensure_premium_player, premium_repo
        pid = ensure_premium_player(p, user_id=telegram_id)
        return int(premium_repo.get_premium(pid)) if pid else 0
    except Exception:
        return int(p.get("premium", 0) or 0)


def _derrota_publica(p: dict) -> dict | None:
    """🔎 (28/09) A tela de morte dizia só "Você caiu em combate". No chefe do
    5º andar o jogador morria em 2 toques sem saber se faltava ataque, vida,
    velocidade ou só gastar os pontos parados. Aqui vai o lado a lado com
    quem derrubou e até 3 dicas tiradas dos números — nenhuma genérica."""
    d = p.get("ultima_derrota")
    if not isinstance(d, dict):
        return None
    voce = {k: int(p.get(k) or 0) for k in ("atk", "def", "spd", "hp_max")}
    ele = {k: int(d.get(k) or 0) for k in ("atk", "def", "spd", "hp_max")}
    dicas = []
    pontos = int(p.get("trail_points") or 0)
    if pontos > 0:
        dicas.append(f"Você tem {pontos} ponto(s) de trilha parados: gaste em Você → Trilhas.")
    if ele["def"] >= voce["atk"] * 0.6:
        dicas.append("A defesa dele engole quase todo o seu ataque: Força (Ataque) ou uma arma melhor na Forja.")
    if voce["spd"] and ele["spd"] >= voce["spd"] * 1.5:
        dicas.append("Ele age bem mais vezes que você: Agilidade (Velocidade) te dá mais turnos.")
    if voce["hp_max"] and ele["atk"] - voce["def"] >= voce["hp_max"] * 0.15:
        dicas.append("Cada golpe dele tira muito da sua vida: Vitalidade ou armadura melhor na Forja.")
    chefe = str(d.get("tipo")) == "boss"
    if chefe and int(d.get("andar") or 0) in (p.get("chefes_vencidos") or []):
        chefe = False
    return {"nome": d.get("nome"), "tipo": d.get("tipo"), "chefe": chefe,
            "ele": ele, "voce": voce, "dicas": dicas[:3]}


def _montar_snapshot_combate(p: dict, log_msg: str = "") -> dict:
    cmb = p.get("combat")

    inimigos = []
    imagem_alvo = "TOWER"
    if cmb:
        from game.assets import resolver_asset_key_inimigo
        from game.logic import calc_power_level, comparar_poder
        enemies_lista = cmb.get("enemies", [])
        # ⚡ (26/09) o PODER DE COMBATE do bot antigo, de volta: o do jogador
        # e o de cada inimigo, com a comparação ("🟠 Mais forte que você")
        meu_poder = calc_power_level(p)
        for e in enemies_lista:
            poder_e = calc_power_level(e)
            emoji_p, desc_p = comparar_poder(meu_poder, poder_e)
            inimigos.append({
                "poder": poder_e, "poder_emoji": emoji_p, "poder_desc": desc_p,
                "nome": e.get("name", "?"), "hp": max(0, int(e.get("hp", 0))),
                "hp_max": int(e.get("hp_max", 1)), "tipo": e.get("tipo", "normal"),
                "tier": e.get("tier", 1), "bar": float(e.get("bar", 0.0)),
                # spd é o que enche a barra. Sem ele o front consegue
                # ordenar quem está mais pronto AGORA, mas não prever
                # a ordem dos próximos turnos.
                "spd": max(1, int(e.get("spd", 1))),
                "img_key": resolver_asset_key_inimigo(e),
            })
        t_idx = int(cmb.get("target", 0) or 0)
        if enemies_lista:
            t_idx = max(0, min(t_idx, len(enemies_lista) - 1))
            imagem_alvo = resolver_asset_key_inimigo(enemies_lista[t_idx])

    skills = []
    if cmb:
        from game.logic import get_skill_by_id
        cds = cmb.get("p_cooldowns", {})
        slots = p.get("skill_slots", {}).get("equipped", [None] * 5)
        for idx, sk_id in enumerate(slots):
            if not sk_id:
                continue
            base = get_skill_by_id(sk_id)
            sk_data = (base or {}).get("skill", base or {})
            if sk_data.get("type") != "active":
                continue
            skills.append({
                "slot_idx": idx, "skill_id": sk_id, "nome": sk_data.get("name", "?"),
                "cooldown_restante": int(cds.get(sk_id, 0)),
                "cooldown_max": int(sk_data.get("cooldown", 0)),
            })

    import game.logic as _L
    aviso_cla = p.pop("_aviso_cla", None)
    if aviso_cla:
        log_msg = aviso_cla + ("\n" + log_msg if log_msg else "")
    return {
        "log": (log_msg or "").strip(),
        "em_combate": bool(cmb and cmb.get("enemies")),
        "explore_mode": bool(p.get("explore_mode")),
        "wave_mode": bool(p.get("wave_mode")),
        "revive_cooldown_seg": _cooldown_revive_se_morto(p),
        # 🛡️ privilégio do novato e 💰 revive pago
        "novato": _L.e_novato(p), "andar_novato": _L.ANDAR_DO_NOVATO,
        "custo_reviver": _L.CUSTO_REVIVER_OURO, "gold": p.get("gold", 0),
        "morreu": p.get("state") == "DEAD",
        "andar": p.get("tower_floor", 1),
        "tower_choice": bool(p.get("tower_choice")),
        # 🎁 (28/09) o que a vitória rendeu (XP, cores, material) — sai do
        # jogador aqui, então a janela aparece uma vez só
        "recompensa": p.pop("_ultima_recompensa", None),
        # 👑 (28/09) o portal veio do chefe vencido / o andar só abre assim
        "portal_do_chefe": p.get("tower_choice") == "chefe",
        "portal_preso": _L.portal_preso_ao_chefe(p),
        "derrota": _derrota_publica(p) if p.get("state") == "DEAD" else None,
        "torre_encontro": bool(p.get("torre_encontro")),
        "hp": max(0, int(p.get("hp", 0))), "hp_max": int(p.get("hp_max", 1)),
        "p_bar": float(cmb.get("p_bar", 0.0)) if cmb else 0.0,
        "p_spd": float(cmb.get("p_spd", 1)) if cmb else 1.0,
        "atb_max": 100.0,
        "alvo": int(cmb.get("target", 0)) if cmb else 0,
        "inimigos": inimigos,
        "skills": skills,
        "img_key": imagem_alvo,
        "gold": p.get("gold", 0),
        # 🧪 11/09/2026 — a tela de combate precisa saber quantas poções
        # existem pra rotular o botão. Sem isso ele diria "(0)" sempre, e o
        # jogador tocaria pra descobrir que não tem — descobrir por erro é o
        # pior jeito de saber.
        "potions": int((p.get("inv") or {}).get("potion", 0) or 0),
    }


def _pos_combate_explorar(p: dict) -> dict | None:
    """Se essa vitória veio de uma batalha da Exploração, restaura o andar
    real da Torre e avança o dia da expedição — mesma lógica que
    core/router.py já faz pro bot de chat (só replicada aqui pro Mini App).
    Retorna None se não havia exploração em andamento, ou se o combate
    ainda não terminou (a morte já é tratada dentro do próprio game.logic,
    então não precisa de nada especial aqui pra esse caso)."""
    if not p.get("explore_mode"):
        return None
    cmb = p.get("combat")
    venceu = (not cmb or not cmb.get("enemies")) and p.get("hp", 0) > 0
    if not venceu:
        return None

    p["explore_mode"] = False
    saved_floor = p.get("explore_state", {}).get("saved_tower_floor")
    if saved_floor is not None:
        p["tower_floor"] = saved_floor

    from game.explore import avancar_dia, finalizar_expedicao
    completou = avancar_dia(p)
    resultado = {"dia_completo": True, "expedicao_finalizada": completou, "msg_extra": ""}
    if completou:
        resultado["msg_extra"] = finalizar_expedicao(p)
    return resultado


@app.get("/api/explore")
def get_explore(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))

    from game.explore import get_tier_range, TOTAL_EXPLORACOES, TIER_SIZE

    st = p.get("explore_state", {})
    # 🐛 durante um combate de exploração, p["tower_floor"] guarda o andar
    # TEMPORÁRIO da batalha, não o andar real do jogador — usar ele aqui
    # mostraria o Tier errado na tela. O andar real fica em saved_tower_floor.
    andar_real = st.get("saved_tower_floor") if p.get("explore_mode") else None
    if andar_real is None:
        andar_real = p.get("tower_floor", 1)
    inicio, fim = get_tier_range(andar_real)
    tier_num = (inicio - 1) // TIER_SIZE + 1

    return JSONResponse({
        "ativo": bool(st.get("active")),
        "dia": int(st.get("day", 0)),
        "total": TOTAL_EXPLORACOES,
        "tier": tier_num,
        "andar_inicio": inicio,
        "andar_fim": fim,
    })


@app.post("/api/explore/enter")
def post_explore_enter(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)

    from game.explore import iniciar_expedicao
    msg = iniciar_expedicao(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


@app.post("/api/explore/go")
def post_explore_go(authorization: str | None = Header(None)):
    """Rola o evento de uma exploração. Se cair batalha/chefe, usa o MESMO
    motor de combate da Torre (start_combat) — o Mini App reaproveita as
    telas e endpoints de /api/tower/* pra lutar, exatamente como o bot de
    chat reaproveita view_combat."""
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)

    st = p.get("explore_state", {})
    if not st.get("active"):
        raise HTTPException(status_code=400, detail="Você não está numa expedição ativa.")
    if p.get("combat"):
        raise HTTPException(status_code=400, detail="Você tem uma batalha pendente — resolva-a (vença ou morra) antes de continuar.")

    from game.explore import rolar_evento, resolver_evento_instantaneo, avancar_dia, finalizar_expedicao
    from game.logic import start_combat

    evento = rolar_evento(p)

    if evento["tipo"] in ("batalha", "boss"):
        andar = evento["andar"]
        st["saved_tower_floor"] = p.get("tower_floor", 1)
        p["explore_state"] = st
        p["tower_floor"] = andar
        p["explore_mode"] = True
        start_combat(p)
        _salvar_jogador(telegram_id, p)
        aviso = ("👹 Um CHEFE poderoso surge no seu caminho!" if evento["tipo"] == "boss"
                 else "⚔️ Um inimigo surge do nada — sem chance de fuga!")
        snap = _montar_snapshot_combate(p, aviso)
        snap["tipo_evento"] = "combate"
        return JSONResponse(snap)

    drop = {}
    msg = resolver_evento_instantaneo(p, evento, drop)
    completou = avancar_dia(p)
    resultado = {"tipo_evento": "instantaneo", "msg": msg, "gold": p.get("gold", 0),
                 # O que caiu, em forma de dado. A tela mostra só isto — a
                 # narração fica pro bot, que só sabe mandar texto.
                 "drop": drop or None,
                 "dia_completo": True, "expedicao_finalizada": completou, "msg_extra": ""}
    if completou:
        resultado["msg_extra"] = finalizar_expedicao(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse(resultado)


def _pos_combate_onda(p: dict) -> dict | None:
    """Onda de Bosses: nem vitória nem derrota têm tratamento dentro do
    motor de combate compartilhado (diferente da Exploração, que ao menos
    tem a morte tratada lá) — as duas vêm só do core/router.py. Replicado
    aqui por inteiro."""
    if not p.get("wave_mode"):
        return None

    if p.get("hp", 0) <= 0:
        from game.wave_mode import finalizar_onda
        msg_onda = finalizar_onda(p)
        return {"tipo": "derrota", "msg_onda": msg_onda}

    cmb = p.get("combat")
    venceu = not cmb or not cmb.get("enemies")
    if venceu:
        from game.wave_mode import avancar_onda
        _, msg_onda = avancar_onda(p)  # 🌊 "terminou" sempre False — só a morte encerra
        return {"tipo": "vitoria", "msg_onda": msg_onda, "onda_atual": p.get("wave_state", {}).get("onda_atual", 1)}

    return None


@app.get("/api/wave")
def get_wave(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))

    from game.wave_mode import pode_jogar_hoje, BOSSES_POR_ONDA

    st = p.get("wave_state", {})
    return JSONResponse({
        "pode_jogar_hoje": pode_jogar_hoje(p),
        "ativo": bool(st.get("active")),
        "onda_atual": int(st.get("onda_atual", 1)),
        "bosses_por_onda": BOSSES_POR_ONDA,
        "recorde": int(p.get("wave_recorde", 0)),
    })


@app.post("/api/wave/start")
def post_wave_start(authorization: str | None = Header(None)):
    """Começa a tentativa do dia — os 5 chefes da Onda 1 já entram em
    combate na hora (spawn_onda_completa é chamado dentro de iniciar_onda)."""
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)

    from game.wave_mode import iniciar_onda, pode_jogar_hoje
    if not pode_jogar_hoje(p):
        raise HTTPException(status_code=400, detail="Você já tentou a Onda de Bosses hoje. Volte amanhã!")
    if p.get("combat"):
        raise HTTPException(status_code=400, detail="Você tem uma batalha pendente — resolva-a (vença ou morra) antes de continuar.")

    msg = iniciar_onda(p)
    _salvar_jogador(telegram_id, p)
    snap = _montar_snapshot_combate(p, msg)
    snap["onda_atual"] = p.get("wave_state", {}).get("onda_atual", 1)
    return JSONResponse(snap)


@app.get("/api/global_boss")
def get_global_boss(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))

    from game.global_boss import get_or_create_boss, get_current_phase_idx, get_phase_multiplier, get_phase_name
    from game.sql_repo import load_player

    state = get_or_create_boss()
    fase_idx = get_current_phase_idx(state)
    mult_fase = get_phase_multiplier(fase_idx)

    contributors = state.get("contributors", {})
    dano_total = sum(contributors.values()) or 1
    ranking = sorted(contributors.items(), key=lambda x: x[1], reverse=True)[:5]
    top = []
    for pid, dano in ranking:
        nome = f"Jogador {pid}"
        try:
            pdata = load_player(int(pid))
            if pdata and pdata.get("username"):
                nome = pdata["username"]
        except Exception:
            pass
        top.append({"nome": nome, "dano": dano, "pct": round(dano / dano_total * 100)})

    sessao = p.get("global_boss_session") or {}

    return JSONResponse({
        "nome": state["nome"], "geracao": state["geracao"],
        "hp": state["hp"], "hp_max": state["hp_max"],
        "fase_idx": fase_idx, "fase_nome": get_phase_name(fase_idx), "fase_mult": int(mult_fase),
        "top_contribuidores": top,
        "dano_sessao": int(sessao.get("dano_acumulado", 0)),
        "meu_hp": p.get("hp", 0), "meu_hp_max": p.get("hp_max", 1),
    })


@app.post("/api/global_boss/attack")
def post_global_boss_attack(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)

    from game.global_boss import attack_global_boss
    msg = attack_global_boss(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg, "hp": p.get("hp", 0), "hp_max": p.get("hp_max", 1)})


@app.post("/api/global_boss/auto")
def post_global_boss_auto(authorization: str | None = Header(None)):
    """⚙️ (25/09) A luta inteira contra o boss global, automática."""
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    from game.global_boss import batalha_automatica
    r = batalha_automatica(p)
    _salvar_jogador(telegram_id, p)
    if not r.get("ok"):
        raise HTTPException(status_code=409, detail=r.get("erro") or "Não deu.")
    return JSONResponse(r)


@app.post("/api/global_boss/flee")
def post_global_boss_flee(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)

    from game.global_boss import flee_global_boss
    msg = flee_global_boss(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


@app.get("/api/shop")
def get_shop(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)

    from game.items import core_name, core_sell_value
    from game.premium_system import ensure_premium_player, premium_repo

    # Sem user_id, ensure_premium_player procura por 0 e devolve "" — o
    # saldo de ⭐ da loja aparecia zerado pra todo mundo no site.
    pid = ensure_premium_player(p, user_id=telegram_id)
    saldo_premium = premium_repo.get_premium(pid) if pid else 0

    cores = p.get("inv", {}).get("cores", {}) or {}
    lista_cores = [
        {"core_id": cid, "nome": core_name(cid), "quantidade": qtd,
         "preco_unidade": core_sell_value(cid, 1), "preco_total": core_sell_value(cid, 1) * qtd}
        for cid, qtd in cores.items() if qtd > 0
    ]

    slots_order = ["weapon", "armor", "helmet", "gloves", "boots", "shield", "necklace", "ring", "belt"]
    lista_itens = []
    for slot in slots_order:
        for idx, item in enumerate(p.get("inv", {}).get("items", {}).get(slot, [])):
            lista_itens.append({
                "slot": slot, "idx": idx, "nome": item.get("name", "Item"),
                "raridade": item.get("rar", "comum"), "preco": item.get("price", 0),
            })

    from game.clan_materiais import PRECO_NA_LOJA, RANKS
    mochila = p.get("materiais_torre") or {}
    return JSONResponse({
        "gold": p.get("gold", 0),
        "premium": saldo_premium,
        "potions": p.get("inv", {}).get("potion", 0),
        "cores": lista_cores,
        "itens": lista_itens,
        # 🛒 material de forja à venda (vai pra mochila do personagem)
        "materiais": [{"rank": r, "nome": RANKS[r]["nome"], "fonte": RANKS[r]["fonte"],
                       "preco": PRECO_NA_LOJA[r], "tem": int(mochila.get(str(r), 0))}
                      for r in sorted(PRECO_NA_LOJA)],
    })


@app.post("/api/shop/buy_potion")
def post_shop_buy_potion(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)

    from game.logic import shop_buy_potion
    msg = shop_buy_potion(p)
    _salvar_jogador(telegram_id, p)
    ok = "❌" not in msg
    return JSONResponse({"ok": ok, "msg": msg, "gold": p.get("gold", 0)})


@app.post("/api/shop/buy_material")
def post_shop_buy_material(body: dict | None = Body(None), authorization: str | None = Header(None)):
    """🛒 Compra material de forja na loja da cidade: 50/100/200 de ouro por
    unidade (rank 1/2/3). Vai pra mochila, que a Forja gasta primeiro."""
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)
    from game.clan_materiais import PRECO_NA_LOJA, RANKS
    body = body or {}
    rank, qtd = int(body.get("rank") or 0), int(body.get("quantidade") or 0)
    if rank not in PRECO_NA_LOJA or not (1 <= qtd <= 100):
        raise HTTPException(status_code=400, detail="Escolha o rank (1 a 3) e de 1 a 100 unidades.")
    preco = PRECO_NA_LOJA[rank] * qtd
    if int(p.get("gold", 0)) < preco:
        raise HTTPException(status_code=409, detail=f"Custa {preco} de ouro; você tem {p.get('gold', 0)}.")
    p["gold"] = int(p.get("gold", 0)) - preco
    mochila = p.setdefault("materiais_torre", {})
    mochila[str(rank)] = int(mochila.get(str(rank), 0)) + qtd
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True, "gold": p["gold"], "tem": mochila[str(rank)],
                         "msg": f"+{qtd} de {RANKS[rank]['nome']} por {preco} de ouro."})


@app.post("/api/shop/sell_core")
def post_shop_sell_core(body: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)

    body = body or {}
    core_id = str(body.get("core_id", ""))
    all_qty = bool(body.get("all", False))

    from game.logic import shop_sell_core
    msg = shop_sell_core(p, core_id, all_qty=all_qty)
    _salvar_jogador(telegram_id, p)
    ok = "❌" not in msg
    return JSONResponse({"ok": ok, "msg": msg, "gold": p.get("gold", 0)})


@app.post("/api/shop/sell_item")
def post_shop_sell_item(body: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)

    body = body or {}
    slot = str(body.get("slot", ""))
    idx = int(body.get("idx", 0))

    from game.logic import sell_item
    msg = sell_item(p, slot, idx)
    _salvar_jogador(telegram_id, p)
    ok = "❌" not in msg
    return JSONResponse({"ok": ok, "msg": msg, "gold": p.get("gold", 0)})


@app.post("/api/shop/buy_vip")
def post_shop_buy_vip(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)

    # 🪙 ⚠️ A CARTEIRA DE ⭐ PRECISA SER RESOLVIDA AQUI.
    #
    # `shop_buy_vip`/`shop_buy_autobattle` leem `p["player_id"]` e abortam
    # com "❌ Erro: player_id inválido" quando ele não existe. E ele NUNCA
    # existe no site: player_id não é coluna nem está em CAMPOS_EXTRAS, então
    # não sobrevive ao save — só o bot o injetava, no começo de cada callback.
    # Resultado: comprar VIP e Autobatalha pelo site dava erro de id sempre.
    #
    # ensure_premium_player busca o id no player_registry POR user_id (o
    # chat_id é só metadado que ele atualiza), então passar o telegram_id
    # devolve exatamente a mesma carteira que o bot usa — ninguém perde ⭐.
    from game.premium_system import ensure_premium_player
    ensure_premium_player(p, user_id=telegram_id)

    from game.logic import shop_buy_vip
    msg = shop_buy_vip(p, days=28, cost=500)
    _salvar_jogador(telegram_id, p)
    ok = "❌" not in msg
    # 🪙 O saldo vai na resposta, lido da CARTEIRA e não de p["premium"],
    # que é cópia (armadilha nº 17). Sem isso a barra de cima continuava
    # mostrando o saldo velho depois de gastar 500⭐ — e número parado é
    # indistinguível de "não cobrou".
    return JSONResponse({"ok": ok, "msg": msg,
                         "premium": _saldo_premium(p, telegram_id),
                         "gold": p.get("gold", 0)})


PRECO_AUTOBATALHA = 250   # ⭐ — era 500 (R$50); o dev baixou pra R$25 em 26/09/2026


@app.post("/api/shop/buy_autobattle")
def post_shop_buy_autobattle(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)

    from game.premium_system import ensure_premium_player
    ensure_premium_player(p, user_id=telegram_id)   # ver a nota em buy_vip

    from game.logic import shop_buy_autobattle
    msg = shop_buy_autobattle(p, days=28, cost=PRECO_AUTOBATALHA)   # 26/09: R$25 (10⭐ por real)
    _salvar_jogador(telegram_id, p)
    ok = "❌" not in msg
    # 🪙 O saldo vai na resposta, lido da CARTEIRA e não de p["premium"],
    # que é cópia (armadilha nº 17). Sem isso a barra de cima continuava
    # mostrando o saldo velho depois de gastar 500⭐ — e número parado é
    # indistinguível de "não cobrou".
    return JSONResponse({"ok": ok, "msg": msg,
                         "premium": _saldo_premium(p, telegram_id),
                         "gold": p.get("gold", 0)})


@app.post("/api/shop/order_stars")
def post_shop_order_stars(body: dict | None = Body(None), authorization: str | None = Header(None)):
    """Cria o pedido de compra de ⭐ (mesma função que o bot de chat usa).
    O pagamento em si (Pix + print do comprovante) continua acontecendo no
    chat do bot — o Mini App não tem como receber upload de foto pro bot
    processar, então só inicia o pedido aqui e direciona pro chat."""
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_cidade(p)

    body = body or {}
    amount = int(body.get("amount", 0))

    from game.logic import shop_buy_stars
    msg = shop_buy_stars(p, amount)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


@app.get("/api/tower/status")
def get_tower_status(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))
    return JSONResponse(_montar_snapshot_combate(p))


@app.post("/api/tower/explore")
def post_tower_explore(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.logic import tower_explore

    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)
    msg = tower_explore(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_combate(p, msg))


# =============================================================================
# 👣 ENCONTROS DA TORRE
# =============================================================================
# Explorar deixou de ser só "monstro ou portal". A Torre é habitada: gente
# que nasceu aqui, gente mandada pra cá que não tem como descer (só quem usa
# aura desce) e clãs já formados. É desse encontro que saem os aldeões — e,
# raramente, outro usuário de aura, que é como se ganha personagem novo.
#
# O saco é separado do saco do clã pelo campo `contexto` do storylet. Sem
# essa separação, o encontro da Torre sairia na tela de Decisões do clã e
# vice-versa.

@app.get("/api/tower/encontro")
def get_tower_encontro(authorization: str | None = Header(None)):
    """👣 (26/09) O encontro da Torre agora é uma Crônica (game/cronicas.py)."""
    from game import cronicas as K
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    enc = p.get("torre_encontro")
    ev = K.encontro_publico(p, enc) if isinstance(enc, dict) else None
    if not ev:
        if enc:                               # encontro do sistema antigo: descarta
            p["torre_encontro"] = None
            _salvar_jogador(telegram_id, p)
        return JSONResponse({"evento": None})
    return JSONResponse({"evento": ev})


@app.post("/api/tower/encontro/decidir")
def post_tower_encontro_decidir(corpo: dict | None = Body(None),
                                authorization: str | None = Header(None)):
    from game import cronicas as K
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)          # de guarda no ponto do mapa, não age na Torre
    r = K.resolver_encontro(p, int((corpo or {}).get("opcao", -1)))
    if not r.get("ok"):
        raise HTTPException(status_code=409, detail=r.get("erro") or "Não deu.")
    # O encontro se fecha aqui, dê certo ou errado (resolver_encontro zera
    # p["torre_encontro"]): deixar aberto faria o jogador repetir a escolha
    # até sair o resultado que queria.
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True, "resultado": r, "hp": p.get("hp"), "gold": p.get("gold")})


# =============================================================================
# 👆 GUIA INICIAL — a luta e a forja do tutorial (26/09/2026, pedido do dev)
# "Faz o jogador batalhar um pouco contra um monstro normal, para no meio e
# leva a fugir; na Cidade escolhe uma espada e forja, depois armadura, elmo e
# anel; na Mochila equipa tudo."
#   /api/guia/luta  → UMA luta preparada: 1 monstro comum do 1º andar que
#                     aguenta os golpes do guia (vida ≥ 6× o seu ataque) e bate
#                     fraco (não mata) — o Explorar normal às vezes dá encontro
#                     em vez de luta. Também garante o material da forja: os
#                     cores das 4 peças e 100 de ferro (a forja comum pede 25 de
#                     ferro do clã, e no 1º andar o clã ainda não nasceu).
#   /api/guia/fugir → a fuga do guia, garantida (a fuga normal tem chance).
# Só no 1º andar: fora dele as rotas recusam (não viram atalho).
# =============================================================================
# 🔒 (28/09) As duas rotas eram repetíveis no 1º andar pra sempre: cada
# chamada da luta completava os cores e punha o ferro do clã de volta em 100
# (forja comum grátis sem fim), e a fuga do guia era fuga garantida e volta
# de graça pra cidade a qualquer hora. Agora: a luta só existe enquanto o
# guia inicial não terminou, o material sai UMA vez na vida, e a fuga só vale
# pra luta que o próprio guia montou.
_GUIA_MATERIAL = "_guia_material"          # marca em tut_seen (campo que já persiste)


def _dar_material_do_guia(telegram_id: int, p: dict) -> None:
    """Cores das 4 peças + 100 de ferro — uma vez só. Também roda quando o
    jogador PULA o guia: no 1º andar o clã ainda não nasceu e o ferro só vinha
    da luta do guia, então quem pulava tinha os cores e não conseguia forjar."""
    import json
    from game import clan_repo as CR
    vistos = p.setdefault("tut_seen", {})
    if vistos.get(_GUIA_MATERIAL):
        return
    cores = p.setdefault("inv", {}).setdefault("cores", {})
    for cid, qtd in (("wa_atk", 4), ("ar_def", 8), ("ac_atk", 4)):
        cores[cid] = max(int(cores.get(cid, 0) or 0), qtd)
    clan = CR.carregar_clan(telegram_id)
    mats = dict(clan["materiais"])
    if int(mats.get(1, 0)) < 100:
        mats[1] = 100
        with CR._conn() as c:
            c.execute("UPDATE clan SET materiais = ? WHERE owner_id = ?",
                      (json.dumps({str(k): v for k, v in mats.items()}), telegram_id))
            c.commit()
    vistos[_GUIA_MATERIAL] = True


# 🔁 (28/09) ATUALIZAR A PÁGINA NO MEIO DO GUIA. O guia mora na memória do
# navegador: ao atualizar, ele recomeçava do passo 1 — e a partir da forja
# isso quebrava, porque os cores já tinham sido gastos (o "+" que o guia
# mandava tocar nem existia mais). Agora o guia retoma no último MARCO.
# O marco vem de duas fontes, e vale a mais adiantada:
#   - o que o navegador gravou ao passar por ele (/api/guia/marco);
#   - o que o ESTADO do jogo prova (luta do guia aberta, fugiu, tem espada,
#     tem a espada equipada...). Isso cobre quem atualizou entre o toque e a
#     gravação do marco — o estado não mente.
MARCOS_DO_GUIA = ["inicio", "luta", "atacar", "forja", "forja_resto",
                  "equipar", "equipar_resto", "fim"]
_PECAS_DO_GUIA = (("armor", None, ["ar_def"] * 4), ("helmet", None, ["ar_def"] * 4),
                  ("ring", None, ["ac_atk"] * 4))


def _tem_peca(p: dict, slot: str) -> bool:
    return bool((p.get("equip") or {}).get(slot)) or bool(
        ((p.get("inv") or {}).get("items") or {}).get(slot))


def _onde_retomar_guia(p: dict) -> str:
    vistos = p.get("tut_seen") or {}
    gravado = vistos.get("_guia_marco") or "inicio"
    if gravado not in MARCOS_DO_GUIA or gravado == "atacar":
        gravado = "inicio"       # "atacar" só vale com a luta aberta (abaixo)
    provas = []
    if (p.get("combat") or {}).get("guia"):
        provas.append("atacar")
    if vistos.get("_guia_fugiu"):
        provas.append("forja")
    if _tem_peca(p, "weapon"):
        provas.append("forja_resto")
    if all(_tem_peca(p, s) for s in ("weapon", "armor", "helmet", "ring")):
        provas.append("equipar")
    if (p.get("equip") or {}).get("weapon"):
        provas.append("equipar_resto")
    if all((p.get("equip") or {}).get(s) for s in ("weapon", "armor", "helmet", "ring")):
        provas.append("fim")
    return max([gravado] + provas, key=MARCOS_DO_GUIA.index)


@app.post("/api/guia/marco")
def post_guia_marco(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    telegram_id = int(_extrair_usuario(authorization)["id"])
    marco = str((corpo or {}).get("marco") or "")
    if marco not in MARCOS_DO_GUIA:
        raise HTTPException(status_code=400, detail="Marco desconhecido.")
    p = _carregar_jogador(telegram_id)
    vistos = p.setdefault("tut_seen", {})
    atual = vistos.get("_guia_marco") or "inicio"
    if atual not in MARCOS_DO_GUIA or MARCOS_DO_GUIA.index(marco) > MARCOS_DO_GUIA.index(atual):
        vistos["_guia_marco"] = marco        # só anda pra frente
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True})


@app.post("/api/guia/forjar_resto")
def post_guia_forjar_resto(authorization: str | None = Header(None)):
    """(28/09, dev) "Ensina só a primeira arma e depois já faz automático":
    a Armadura, o Elmo e o Anel saem pela forja DE VERDADE (craft_confirm,
    mesmo ouro, mesmo ferro, mesmos cores), só sem os 12 toques. Pode ser
    chamada de novo sem dobrar nada: pula a peça que o jogador já tem."""
    from game.craft import craft_confirm
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    if (p.get("tut_seen") or {}).get("guia_inicio"):
        raise HTTPException(status_code=409, detail="O guia inicial já terminou.")
    _exigir_cidade(p)
    feitas, falhas = [], []
    for slot, sub, cores in _PECAS_DO_GUIA:
        if _tem_peca(p, slot):
            continue
        p["craft"] = {"slot": slot, "rar": "common", "sub": sub, "sel": list(cores)}
        antes = len(p["inv"]["items"].get(slot, []))
        ok, msg = craft_confirm(p, owner_id=telegram_id)
        depois = p["inv"]["items"].get(slot, [])
        if ok and len(depois) > antes:
            feitas.append(_resumo_item(depois[-1], slot))
        else:
            falhas.append(_limpar_html_bot(msg))
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": not falhas, "feitas": feitas, "falhas": falhas,
                         "gold": p.get("gold", 0)})


@app.post("/api/guia/equipar_resto")
def post_guia_equipar_resto(authorization: str | None = Header(None)):
    """Veste o que estiver na mochila nos slots do guia e ainda vazio no
    corpo. Nunca troca uma peça que o jogador já vestiu."""
    from game.logic import equip_from_inventory
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    if (p.get("tut_seen") or {}).get("guia_inicio"):
        raise HTTPException(status_code=409, detail="O guia inicial já terminou.")
    vestidas = []
    for slot in ("weapon", "armor", "helmet", "ring"):
        itens = p["inv"]["items"].get(slot, [])
        if not p["equip"].get(slot) and itens:
            equip_from_inventory(p, slot, len(itens) - 1)
            vestidas.append(slot)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True, "vestidas": vestidas})


@app.post("/api/guia/luta")
def post_guia_luta(authorization: str | None = Header(None)):
    import game.logic as L
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)
    if int(p.get("tower_floor") or 1) != 1:
        raise HTTPException(status_code=409, detail="A luta do guia é só no 1º andar.")
    if (p.get("tut_seen") or {}).get("guia_inicio"):
        raise HTTPException(status_code=409, detail="O guia inicial já terminou.")
    if not p.get("combat"):
        L.recalc(p)
        p["state"] = "TOWER"
        L.start_combat(p)
        cmb = p.get("combat") or {}
        if cmb.get("enemies"):
            e = cmb["enemies"][0]
            e["tipo"] = "normal"
            e["hp_max"] = max(int(e.get("hp_max") or 1), int(p.get("atk") or 5) * 6 + 40)
            e["hp"] = e["hp_max"]
            e["atk"] = int(p.get("def") or 0) + max(2, int(int(p.get("hp_max") or 100) * 0.04))
            e["skills"] = []
            cmb["enemies"] = [e]
            cmb["guia"] = True             # só esta luta aceita a fuga do guia
    _dar_material_do_guia(telegram_id, p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_combate(p, "👹 Um monstro bloqueia o caminho!"))


@app.post("/api/guia/fugir")
def post_guia_fugir(authorization: str | None = Header(None)):
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)
    if int(p.get("tower_floor") or 1) != 1:
        raise HTTPException(status_code=409, detail="A fuga do guia é só no 1º andar.")
    if not (p.get("combat") or {}).get("guia"):
        raise HTTPException(status_code=409, detail="Essa fuga é só da luta do guia.")
    # "leva a fugir e ir pra cidade": a fuga do guia já te deixa na cidade,
    # de graça (a volta normal custa ouro) — a Forja só funciona lá
    p["combat"] = None
    p.setdefault("tut_seen", {})["_guia_fugiu"] = True   # retoma na forja
    p["state"] = "CITY"
    p["explore_mode"] = False
    p["wave_mode"] = False
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_combate(p, "🏃 Você fugiu da luta e voltou pra cidade."))


@app.post("/api/tower/advance")
def post_tower_advance(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)
    msg = ""
    # 🔥 (26/09, dev) "um storylet pra começar o clã, algo que se faz ANTES
    # de ir pro 2º andar": no 1º andar, sem clã fundado, o portal não abre.
    # O portal (tower_choice) continua valendo: é só fundar e voltar.
    if p.get("tower_choice") and int(p.get("tower_floor", 1)) == 1:
        from game import clan_repo as CR, cronicas as K
        CR.carregar_clan(telegram_id)
        K.garantir_fundacao(telegram_id, p)
        if not K.fundado(CR.carregar_clan(telegram_id)):
            raise HTTPException(status_code=409, detail=(
                "🔥 Antes de subir pro 2º andar, funde o seu clã: abra Clã → Crônicas "
                "e decida o que o acampamento vai ser. O portal espera você."))
    if p.get("tower_choice"):
        p["tower_choice"] = None
        p["tower_floor"] = int(p.get("tower_floor", 1)) + 1
        p["state"] = "TOWER"
        msg = f"⬆️ Andar {p['tower_floor']}!"
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_combate(p, msg))


@app.post("/api/tower/stay")
def post_tower_stay(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)
    p["tower_choice"] = None
    p["state"] = "TOWER"
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_combate(p, "🔁 Mesmo andar."))


@app.get("/api/tower/combat")
def get_tower_combat(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))
    if not p.get("combat"):
        raise HTTPException(status_code=400, detail="Não há combate em andamento.")
    return JSONResponse(_montar_snapshot_combate(p))


@app.post("/api/tower/attack")
def post_tower_attack(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.logic import combat_attack

    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)
    if not p.get("combat"):
        raise HTTPException(status_code=400, detail="Não há combate em andamento.")
    msg = combat_attack(p)
    explorar_info = _pos_combate_explorar(p)
    onda_info = _pos_combate_onda(p)
    _salvar_jogador(telegram_id, p)
    snap = _montar_snapshot_combate(p, msg)
    if explorar_info:
        snap["explorar"] = explorar_info
    if onda_info:
        snap["onda"] = onda_info
    return JSONResponse(snap)


@app.post("/api/tower/skill")
def post_tower_skill(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    skill_id = corpo.get("skill_id")
    if not skill_id:
        raise HTTPException(status_code=400, detail="Faltando 'skill_id'.")

    from game.logic import execute_combat_skill

    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)
    if not p.get("combat"):
        raise HTTPException(status_code=400, detail="Não há combate em andamento.")
    msg = execute_combat_skill(p, skill_id)
    explorar_info = _pos_combate_explorar(p)
    onda_info = _pos_combate_onda(p)
    _salvar_jogador(telegram_id, p)
    snap = _montar_snapshot_combate(p, msg)
    if explorar_info:
        snap["explorar"] = explorar_info
    if onda_info:
        snap["onda"] = onda_info
    return JSONResponse(snap)


@app.post("/api/tower/target")
def post_tower_target(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    idx = corpo.get("idx")
    if idx is None:
        raise HTTPException(status_code=400, detail="Faltando 'idx'.")

    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)
    cmb = p.get("combat")
    if not cmb:
        raise HTTPException(status_code=400, detail="Não há combate em andamento.")
    if 0 <= int(idx) < len(cmb.get("enemies", [])):
        cmb["target"] = int(idx)
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_combate(p))


@app.post("/api/tower/flee")
def post_tower_flee(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.logic import combat_flee

    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)
    if not p.get("combat"):
        raise HTTPException(status_code=400, detail="Não há combate em andamento.")
    if p.get("explore_mode"):
        return JSONResponse(_montar_snapshot_combate(p, "❌ Não existe fuga no Mundo Exterior! Vença ou pereça."))

    msg = combat_flee(p)

    # 🌊 fugir da Onda de Bosses precisa encerrar a onda de verdade — sem
    # isso, o jogador ficava com wave_mode=True preso sem combate nenhum
    # pra continuar (bug que já existia no bot de chat original, corrigido
    # aqui pro Mini App: fugir agora fecha a run igual à morte fecha).
    onda_info = None
    if p.get("wave_mode"):
        from game.wave_mode import finalizar_onda
        msg_onda = finalizar_onda(p)
        onda_info = {"tipo": "fuga", "msg_onda": msg_onda}

    _salvar_jogador(telegram_id, p)
    snap = _montar_snapshot_combate(p, msg)
    if onda_info:
        snap["onda"] = onda_info
    return JSONResponse(snap)


@app.post("/api/tower/revive")
def post_tower_revive(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.logic import free_revive_player

    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)
    ok, msg = free_revive_player(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": ok, "msg": msg, **_montar_snapshot_combate(p)})


@app.post("/api/tower/revive_pago")
def post_tower_revive_pago(authorization: str | None = Header(None)):
    """💰 Reviver na hora pagando ouro (quando o portal divino está fechado)."""
    from game.logic import revive_pago
    telegram_id = int(_extrair_usuario(authorization)["id"])
    p = _carregar_jogador(telegram_id)
    _exigir_fora_da_guarda(p)
    ok, msg = revive_pago(p)
    if not ok:
        raise HTTPException(status_code=409, detail=msg.replace("<b>", "").replace("</b>", ""))
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"ok": True, "msg": msg, **_montar_snapshot_combate(p)})


# =============================================================================
# 🏆 ARENA PvP (luta contra uma CÓPIA salva do oponente, não ele ao vivo —
# por isso não precisa de sincronização em tempo real, funciona igual à
# Torre: cada ação já resolve o turno inteiro sozinha)
# =============================================================================

def _montar_snapshot_arena(p: dict, log_msg: str = "") -> dict:
    state = p.get("arena_combat")
    resultado = {"log": (log_msg or "").strip(), "em_combate": bool(state and state["a"]["hp"] > 0 and state["d"]["hp"] > 0)}
    if state:
        a, d = state["a"], state["d"]
        # A tela da Arena passou a usar o MESMO desenho da batalha da Torre
        # (retratos, barra de ATB e fila de turnos), então precisa dos
        # mesmos campos: arte, velocidade e o estado que muda a decisão.
        def lado(e):
            return {"nome": e["name"], "hp": max(0, e["hp"]), "hp_max": e["hp_max"],
                    "bar": round(float(e.get("bar", 0) or 0), 1),
                    "spd": max(1, int(e.get("spd", 1) or 1)),
                    "img_key": e.get("img_key") or "STATUS",
                    "escudo": int(e.get("shield", 0) or 0),
                    "atordoado": int(e.get("stun", 0) or 0) > 0,
                    "dots": [x.get("name") for x in (e.get("dots") or [])]}

        resultado["voce"] = lado(a)
        resultado["oponente"] = lado(d)
        from game.arena import skills_da_luta
        skills = skills_da_luta(p)
        resultado["skills"] = [
            {"skill_id": s.get("id"), "nome": s.get("name", "?"), "cooldown_restante": int(a["cooldowns"].get(s.get("id"), 0)), "cooldown_max": int(s.get("cooldown", 0))}
            for s in skills
        ]
    return resultado


@app.get("/api/arena")
def get_arena(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))

    from game.arena import ensure_daily_refresh
    from game.sql_repo import get_arena_snapshot_sync
    from game.arena_weekly import verificar_e_fechar_semana, tempo_restante_semana, FAIXAS_PREMIACAO

    uid = int(usuario["id"])
    ensure_daily_refresh(p)
    snap = get_arena_snapshot_sync(uid)

    # ⏳ checagem "preguiçosa": só fecha de verdade se já passou 1 semana
    # desde o último fechamento — mesma lógica que o bot já usa no chat.
    fechamento_msg = verificar_e_fechar_semana()
    restante = tempo_restante_semana()
    if fechamento_msg:
        # a semana acabou de fechar agora mesmo — o snapshot antigo (pontos
        # de antes do reset) ainda está em memória, busca de novo pra não
        # mostrar pro jogador uma pontuação que já foi zerada.
        snap = get_arena_snapshot_sync(uid)

    return JSONResponse({
        "cadastrado": bool(snap),
        "pontos": snap.get("arena_points", 0) if snap else 0,
        "vitorias": snap.get("wins", 0) if snap else 0,
        "derrotas": snap.get("losses", 0) if snap else 0,
        "semana_restante_seg": restante,
        "semana_fechou_agora": fechamento_msg,
        "faixas_premiacao": [{"posicao": pos, "estrelas": premio} for pos, premio in FAIXAS_PREMIACAO],
    })


@app.post("/api/arena/register")
def post_arena_register(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.arena import register_in_arena

    p = _carregar_jogador(telegram_id)
    msg = register_in_arena(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


@app.get("/api/arena/opponents")
def get_arena_opponents(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)

    from game.sql_repo import get_arena_snapshot_sync, get_arena_opponents_sync

    meu_snap = get_arena_snapshot_sync(telegram_id)
    if not meu_snap:
        raise HTTPException(status_code=400, detail="Cadastre-se na Arena primeiro.")

    meus_pontos = float(meu_snap.get("arena_points", 0) or 0)
    oponentes = get_arena_opponents_sync(telegram_id, meus_pontos, limit=5) or [meu_snap]

    lista = [{
        "telegram_id": o["telegram_id"], "nome": o.get("username", "?"),
        "pontos": o.get("arena_points", 0), "vitorias": o.get("wins", 0), "derrotas": o.get("losses", 0),
    } for o in oponentes]
    return JSONResponse({"oponentes": lista})


@app.post("/api/arena/buscar")
def post_arena_buscar(authorization: str | None = Header(None)):
    """🎲 (25/09) Em vez de escolher da lista: um adversário aleatório com
    pontos perto dos seus (bot ou jogador), e a luta já começa."""
    from game.arena import start_arena_combat, _get_equipped_active_skills
    from game.sql_repo import get_arena_snapshot_sync
    from game import arena_bots as B
    telegram_id = int(_extrair_usuario(authorization)["id"])
    B.garantir_bots_arena()
    meu = get_arena_snapshot_sync(telegram_id)
    if not meu:
        raise HTTPException(status_code=400, detail="Cadastre-se na Arena primeiro.")
    alvo = B.sortear_oponente("arena_snapshots", telegram_id, float(meu.get("arena_points", 0) or 0))
    if alvo is None:
        raise HTTPException(status_code=409, detail="Ninguém pra lutar agora — tente de novo daqui a pouco.")
    p = _carregar_jogador(telegram_id)
    resultado = start_arena_combat(p, alvo)
    if resultado.get("erro"):
        raise HTTPException(status_code=400, detail=resultado["erro"])
    p["_arena_my_skills"] = _get_equipped_active_skills(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_arena(p, "⚔️ Adversário encontrado!"))


@app.post("/api/arena/fight")
def post_arena_fight(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    opponent_id = corpo.get("opponent_id")
    if opponent_id is None:
        raise HTTPException(status_code=400, detail="Faltando 'opponent_id'.")

    from game.arena import start_arena_combat, _get_equipped_active_skills

    p = _carregar_jogador(telegram_id)
    resultado = start_arena_combat(p, int(opponent_id))
    if resultado.get("erro"):
        raise HTTPException(status_code=400, detail=resultado["erro"])

    p["_arena_my_skills"] = _get_equipped_active_skills(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_arena(p, "⚔️ Luta iniciada!"))


@app.post("/api/arena/action")
def post_arena_action(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    skill_id = corpo.get("skill_id")  # None = ataque básico

    from game.arena import arena_combat_action, is_combat_over, finalize_arena_combat

    p = _carregar_jogador(telegram_id)
    if not p.get("arena_combat"):
        raise HTTPException(status_code=400, detail="Não há luta em andamento.")

    # 🐛 (25/09) quando a ação dá certo, `arena_combat_action` devolve "" e
    # guarda a narração em arena_combat["logs"] — a rota não repassava, e
    # durante a luta a tela nunca mostrava o que a skill (ou o golpe do
    # rival) fez. Agora vai tudo o que aconteceu desde a ação anterior.
    logs_antes = len((p.get("arena_combat") or {}).get("logs") or [])
    erro = arena_combat_action(p, skill_id)
    if erro:
        _salvar_jogador(telegram_id, p)
        return JSONResponse(_montar_snapshot_arena(p, erro))

    novas = ((p.get("arena_combat") or {}).get("logs") or [])[logs_antes:]
    resposta = _montar_snapshot_arena(p, "\n".join(novas))
    if is_combat_over(p):
        resultado = finalize_arena_combat(p)
        resposta["finalizado"] = True
        resposta["venceu"] = resultado.get("venceu", False)
        resposta["ouro_ganho"] = resultado.get("ouro_ganho", 0)
        resposta["pontos_delta"] = resultado.get("pontos_delta", 0)
        resposta["log"] = "\n".join(resultado.get("logs", [])[-4:])
        resposta["gold"] = p.get("gold", 0)

    _salvar_jogador(telegram_id, p)
    return JSONResponse(resposta)


# =============================================================================
# 🐾 ARENA DOS PETS
# =============================================================================

def _montar_snapshot_pet_arena(p: dict, log_msg: str = "") -> dict:
    state = p.get("pet_arena_combat")
    resultado = {"log": (log_msg or "").strip(), "em_combate": False, "acting_idx": None}
    if state:
        resultado["em_combate"] = not state.get("finalizado")
        resultado["acting_idx"] = state.get("acting_idx")
        from game.pet_arena import opcoes_de_batalha

        def descrever(c, meu):
            d = {"nome": c["name"], "hp": max(0, c["hp"]), "hp_max": c["hp_max"],
                 "escudo": int(c.get("shield", 0) or 0),
                 "atordoado": int(c.get("stun", 0) or 0) > 0,
                 "raridade": c.get("rarity", "comum"),
                 "arquetipo": c.get("archetype", "dps"),
                 # A arte do pet: a batalha mostrava só o nome, e nome de
                 # pet é a coisa menos reconhecível numa fila de dez.
                 "img_key": f"PET_{str(c.get('pet_id', '')).upper()}" if c.get("pet_id") else None,
                 "bar": round(float(c.get("bar", 0) or 0), 1),
                 # spd alimenta a fila de próximos turnos, igual na Raid.
                 "spd": max(1, int(c.get("spd", 1) or 1)),
                 "dots": [d.get("name") for d in (c.get("dots") or [])],
                 "buffs": len(c.get("buffs") or [])}
            if meu:
                # As 4 opções, com a recarga de cada uma. Só do SEU time:
                # ver a recarga do adversário entregaria o turno dele.
                d["acoes"] = [
                    {"id": s["id"], "nome": s["nome"], "icone": s.get("icone", "✨"),
                     "descricao": s.get("descricao", ""), "alvo": s.get("alvo", "inimigo"),
                     "recarga": s.get("recarga", 0),
                     "recarga_restante": s["recarga_restante"], "pronta": s["pronta"]}
                    for s in opcoes_de_batalha(c)
                ]
            return d

        resultado["seu_time"] = [descrever(c, True) for c in state.get("player_team", [])]
        resultado["time_inimigo"] = [descrever(c, False) for c in state.get("enemy_team", [])]
        # 🥊 Quem está EM CAMPO de cada lado. A luta é 1x1: o resto é banco
        # e a tela precisa saber a diferença, senão volta a parecer 5x5.
        resultado["meu_ativo"] = state.get("player_active")
        resultado["rival_ativo"] = state.get("enemy_active")
    return resultado


@app.get("/api/pet_arena")
def get_pet_arena(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.pet_arena import ensure_pet_arena_daily_refresh
    from game.sql_repo import get_pet_arena_snapshot_sync

    p = _carregar_jogador(telegram_id)
    ensure_pet_arena_daily_refresh(p)
    snap = get_pet_arena_snapshot_sync(telegram_id)

    return JSONResponse({
        "cadastrado": bool(snap),
        "pontos": snap.get("arena_points", 0) if snap else 0,
        "vitorias": snap.get("wins", 0) if snap else 0,
        "derrotas": snap.get("losses", 0) if snap else 0,
    })


@app.post("/api/pet_arena/register")
def post_pet_arena_register(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.pet_arena import register_in_pet_arena

    p = _carregar_jogador(telegram_id)
    msg = register_in_pet_arena(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


@app.get("/api/pet_arena/opponents")
def get_pet_arena_opponents(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.sql_repo import get_pet_arena_snapshot_sync, get_pet_arena_opponents_sync

    meu_snap = get_pet_arena_snapshot_sync(telegram_id)
    if not meu_snap:
        raise HTTPException(status_code=400, detail="Cadastre-se na Arena dos Pets primeiro.")

    meus_pontos = float(meu_snap.get("arena_points", 0) or 0)
    oponentes = get_pet_arena_opponents_sync(telegram_id, meus_pontos, limit=5) or [meu_snap]

    lista = [{
        "telegram_id": o["telegram_id"], "nome": o.get("username", "?"),
        "pontos": o.get("arena_points", 0), "vitorias": o.get("wins", 0), "derrotas": o.get("losses", 0),
    } for o in oponentes]
    return JSONResponse({"oponentes": lista})


@app.post("/api/pet_arena/buscar")
def post_pet_arena_buscar(authorization: str | None = Header(None)):
    """🎲 (25/09) Adversário aleatório nos mesmos pontos da Arena de Pets."""
    from game.pet_arena import start_pet_arena_combat
    from game.sql_repo import get_pet_arena_snapshot_sync
    from game import arena_bots as B
    telegram_id = int(_extrair_usuario(authorization)["id"])
    B.garantir_bots_pets()
    meu = get_pet_arena_snapshot_sync(telegram_id)
    if not meu:
        raise HTTPException(status_code=400, detail="Cadastre seu esquadrão na Arena de Pets primeiro.")
    alvo = B.sortear_oponente("pet_arena_snapshots", telegram_id, float(meu.get("arena_points", 0) or 0))
    if alvo is None:
        raise HTTPException(status_code=409, detail="Ninguém pra lutar agora — tente de novo daqui a pouco.")
    p = _carregar_jogador(telegram_id)
    resultado = start_pet_arena_combat(p, alvo)
    if resultado.get("erro"):
        raise HTTPException(status_code=400, detail=resultado["erro"])
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_pet_arena(p, "⚔️ Adversário encontrado!"))


@app.post("/api/pet_arena/fight")
def post_pet_arena_fight(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    opponent_id = corpo.get("opponent_id")
    if opponent_id is None:
        raise HTTPException(status_code=400, detail="Faltando 'opponent_id'.")

    from game.pet_arena import start_pet_arena_combat

    p = _carregar_jogador(telegram_id)
    resultado = start_pet_arena_combat(p, int(opponent_id))
    if resultado.get("erro"):
        raise HTTPException(status_code=400, detail=resultado["erro"])

    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_pet_arena(p, "⚔️ Batalha iniciada!"))


@app.post("/api/pet_arena/action")
def post_pet_arena_action(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    target_idx = corpo.get("target_idx")
    usar_skill = bool(corpo.get("usar_skill", False))
    # 🎯 20/09/2026: a ação passou a ser uma das 4 do pet. `usar_skill`
    # continua aceito pro bot, que ainda manda o booleano antigo.
    skill_id = corpo.get("skill_id") or None
    if target_idx is None:
        # Cura, escudo e buff não miram ninguém: exigir alvo nelas seria
        # pedir uma escolha que não existe.
        target_idx = 0

    from game.pet_arena import resolve_player_pet_turn, is_pet_arena_over, finalize_pet_arena_combat

    p = _carregar_jogador(telegram_id)
    if not p.get("pet_arena_combat"):
        raise HTTPException(status_code=400, detail="Não há batalha em andamento.")

    trocar_para = corpo.get("trocar_para")          # 🔁 troca de pet (gasta o turno)
    log = resolve_player_pet_turn(p, int(target_idx), usar_skill, skill_id,
                                  None if trocar_para is None else int(trocar_para))
    resposta = _montar_snapshot_pet_arena(p, log)

    if is_pet_arena_over(p):
        resultado = finalize_pet_arena_combat(p)
        resposta["finalizado"] = True
        resposta["resultado"] = resultado.get("resultado")
        resposta["pontos_delta"] = resultado.get("pontos", 0)

    _salvar_jogador(telegram_id, p)
    return JSONResponse(resposta)


# =============================================================================
# ⚔️ RAID (multiplayer real — várias pessoas na mesma sala, persistida no
# banco. Como não dá pra "empurrar" atualização pro navegador sem
# WebSocket, o Mini App consulta o estado periodicamente (polling) enquanto
# espera a vez ou espera os outros jogadores.)
# =============================================================================

def _raid_pid(telegram_id: int) -> str:
    return str(telegram_id)


@app.get("/api/raid/status")
def get_raid_status(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    p = _carregar_jogador(int(usuario["id"]))

    room_id = p.get("raid_room_id")
    if not room_id:
        return JSONResponse({"em_raid": False})

    from game.raid_repo import get_room
    room = get_room(room_id)
    if not room:
        return JSONResponse({"em_raid": False})

    return JSONResponse({
        "em_raid": True, "room_id": room["id"], "estado_sala": room.get("state", "LOBBY"),
        "estado_jogador": p.get("state", "RAID_LOBBY"),
    })


@app.get("/api/raid/rooms")
def get_raid_rooms(authorization: str | None = Header(None)):
    _extrair_usuario(authorization)
    from game.raid_repo import list_open_rooms
    salas = list_open_rooms()
    lista = [{"room_id": r["id"], "andar": r.get("floor", 1), "membros": len(r.get("members", [])), "max_membros": r.get("max_members", 5)} for r in salas]
    return JSONResponse({"salas": lista})


@app.post("/api/raid/join")
def post_raid_join(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    room_id = corpo.get("room_id")

    from game.logic import raid_create_or_get_room, raid_join_room

    p = _carregar_jogador(telegram_id)
    if room_id:
        msg = raid_join_room(p, int(room_id))
    else:
        raid_create_or_get_room(p)
        msg = f"✅ Sala #{p.get('raid_room_id')} pronta."
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg, "room_id": p.get("raid_room_id")})


@app.post("/api/raid/leave")
def post_raid_leave(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.logic import raid_leave_room

    p = _carregar_jogador(telegram_id)
    msg = raid_leave_room(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


@app.post("/api/raid/toggle_open")
def post_raid_toggle_open(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    aberto = bool(corpo.get("aberto", True))

    from game.logic import raid_toggle_open

    p = _carregar_jogador(telegram_id)
    msg = raid_toggle_open(p, aberto)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


@app.get("/api/raid/lobby")
def get_raid_lobby(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)

    room_id = p.get("raid_room_id")
    if not room_id:
        raise HTTPException(status_code=400, detail="Você não está em nenhuma sala.")

    from game.raid_repo import get_room
    room = get_room(room_id)
    if not room:
        raise HTTPException(status_code=400, detail="Sala não encontrada.")

    pid = _raid_pid(telegram_id)
    membros = [{"pid": m, "pronto": bool(room.get("ready_map", {}).get(m, False)), "eh_voce": m == pid} for m in room.get("members", [])]

    return JSONResponse({
        "room_id": room["id"], "andar": room.get("floor", 1), "aberto": room.get("open", False),
        "estado": room.get("state", "LOBBY"), "membros": membros, "eh_lider": room.get("leader_pid") == pid,
        "senha": room.get("password") if room.get("leader_pid") == pid else None,
    })


@app.post("/api/raid/ready")
def post_raid_ready(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    pronto = bool(corpo.get("pronto", True))

    from game.logic import raid_set_ready

    p = _carregar_jogador(telegram_id)
    msg = raid_set_ready(p, pronto)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg, "estado_jogador": p.get("state")})


def _montar_snapshot_raid_combat(p: dict, telegram_id: int, log_extra: str = "") -> dict:
    from game.raid_repo import get_room
    from game.logic import get_skill_by_id

    room_id = p.get("raid_room_id")
    room = get_room(room_id) if room_id else None
    pid = _raid_pid(telegram_id)

    if not room or not room.get("raid_state"):
        return {"em_combate": False, "log": log_extra}

    rs = room["raid_state"]
    players = rs.get("players", {})
    minha = players.get(pid, {})
    atb = rs.get("atb", {})
    my_cds = rs.get("cooldowns", {}).get(pid, {})

    jogadores = [{
        "pid": pp, "nome": pl.get("name", "Jogador"), "hp": max(0, int(pl.get("hp", 0))),
        "hp_max": int(pl.get("hp_max", 1)), "morto": bool(pl.get("dead")), "bar": float(atb.get(pp, 0.0)),
        "spd": max(1, int(pl.get("spd", 20))),
        "eh_voce": pp == pid,
    } for pp, pl in players.items()]

    # 🖼️ mesma fórmula de chave que game/views.py já usa pro raid no bot
    # (MOB_{NOME_LIMPO}) — só replicada aqui pro Mini App usar a mesma imagem.
    def _chave_mob(e: dict) -> str:
        nome_base = e.get("base_name") or e.get("name", "MOB")
        return f"MOB_{str(nome_base).upper().replace(' ', '_')}"

    inimigos = [{
        "idx": i, "nome": e.get("name", "?"), "hp": max(0, int(e.get("hp", 0))), "hp_max": int(e.get("hp_max", 1)),
        "img_key": _chave_mob(e),
        # ATB do raid, pra a fila de próximos turnos funcionar aqui igual
        # na Torre. O motor já tinha os dois campos; o snapshot não mandava.
        "bar": float(e.get("bar", 0.0)), "spd": max(1, int(e.get("spd", 20))),
    } for i, e in enumerate(rs.get("enemies", []))]

    # 🎯 o endpoint /api/raid/target já salvava isso em p["raid_target"], mas
    # o snapshot nunca devolvia de volta pro Mini App — corrigido aqui.
    meu_alvo = int(p.get("raid_target", 0) or 0)
    if inimigos:
        meu_alvo = max(0, min(meu_alvo, len(inimigos) - 1))
    else:
        meu_alvo = 0

    skills = []
    for sk_id in (p.get("skill_slots", {}).get("equipped", [None] * 5)):
        if not sk_id:
            continue
        base = get_skill_by_id(sk_id)
        sk_data = (base or {}).get("skill", base or {})
        if sk_data.get("type") != "active":
            continue
        skills.append({
            "skill_id": sk_id, "nome": sk_data.get("name", "?"),
            "cooldown_restante": int(my_cds.get(sk_id, 0)), "cooldown_max": int(sk_data.get("cooldown", 0)),
            "suporte": float(sk_data.get("heal_percent", 0)) > 0 or float(sk_data.get("shield_pct", 0)) > 0,
        })

    return {
        "em_combate": room.get("state") == "RAID_COMBAT",
        "sala_estado": room.get("state"),
        "meu_estado": p.get("state"),
        "meu_hp": max(0, int(minha.get("hp", 0))), "meu_hp_max": int(minha.get("hp_max", 1)),
        "meu_bar": float(atb.get(pid, 0.0)),
        "meu_alvo": meu_alvo,
        "jogadores": jogadores, "inimigos": inimigos, "skills": skills,
        "logs": (rs.get("logs") or [])[-6:],
        "log": log_extra,
    }


@app.get("/api/raid/combat")
def get_raid_combat(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)
    return JSONResponse(_montar_snapshot_raid_combat(p, telegram_id))


@app.post("/api/raid/attack")
def post_raid_attack(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.logic import raid_player_attack

    p = _carregar_jogador(telegram_id)
    msg = raid_player_attack(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_raid_combat(p, telegram_id, msg))


@app.post("/api/raid/skill")
def post_raid_skill(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    skill_id = corpo.get("skill_id")
    ally_target = corpo.get("ally_target_pid")
    if not skill_id:
        raise HTTPException(status_code=400, detail="Faltando 'skill_id'.")

    from game.logic import raid_player_skill

    p = _carregar_jogador(telegram_id)
    msg = raid_player_skill(p, skill_id, ally_target_pid=ally_target)
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_raid_combat(p, telegram_id, msg))


@app.post("/api/raid/target")
def post_raid_target(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    idx = corpo.get("idx")
    if idx is None:
        raise HTTPException(status_code=400, detail="Faltando 'idx'.")

    p = _carregar_jogador(telegram_id)
    p["raid_target"] = int(idx)
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_raid_combat(p, telegram_id))


@app.post("/api/raid/wait_revive")
def post_raid_wait_revive(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)

    if p.get("state") != "RAID_DOWN" or int(p.get("hp", 0)) > 0:
        return JSONResponse(dict(_montar_snapshot_raid_combat(p, telegram_id, "✝️ Você foi trazido de volta à luta!"), revivido=True))
    return JSONResponse(dict(_montar_snapshot_raid_combat(p, telegram_id, "Ainda no chão..."), revivido=False))


@app.post("/api/raid/accept_death")
def post_raid_accept_death(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.raid_repo import get_room, save_room
    from game.logic import raid_finalizar_morte

    p = _carregar_jogador(telegram_id)
    room = get_room(p.get("raid_room_id"))
    if room:
        pid = _raid_pid(telegram_id)
        raid_finalizar_morte(room, pid)
        save_room(room)
        p_novo = _carregar_jogador(telegram_id)
        p.clear()
        p.update(p_novo)
    p["state"] = "DEAD"
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": "☠️ Você aceitou o destino e deixou a raid."})


# =============================================================================
# 🗡️ TRAIÇÃO (fase de PvP dentro da Raid — escolha secreta durante o
# combate contra os monstros; só vira luta de verdade se sobrar traidor
# vivo depois deles serem derrotados)
# =============================================================================

@app.post("/api/raid/betray")
def post_raid_betray(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.logic import raid_declare_betrayal

    p = _carregar_jogador(telegram_id)
    msg = raid_declare_betrayal(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


@app.post("/api/raid/decline_betray")
def post_raid_decline_betray(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])

    from game.logic import raid_decline_betrayal

    p = _carregar_jogador(telegram_id)
    msg = raid_decline_betrayal(p)
    _salvar_jogador(telegram_id, p)
    return JSONResponse({"msg": msg})


def _montar_snapshot_raid_pvp(p: dict, telegram_id: int, log_msg: str = "") -> dict:
    from game.raid_repo import get_room

    room_id = p.get("raid_room_id")
    room = get_room(room_id) if room_id else None
    pid = _raid_pid(telegram_id)

    # 🔥 se a sala já voltou pro LOBBY, a fase de traição terminou — sem
    # isso, quem tava esperando ficaria preso numa tela de PvP morta
    if not room or room.get("state") != "RAID_PVP" or not room.get("raid_state"):
        return {"em_pvp": False, "log": log_msg}

    rs = room["raid_state"]
    players = rs.get("players", {})
    atb = rs.get("atb", {})

    jogadores = [{
        "pid": pp, "nome": pl.get("name", "Jogador"), "hp": max(0, int(pl.get("hp", 0))),
        "hp_max": int(pl.get("hp_max", 1)), "morto": bool(pl.get("dead")), "bar": float(atb.get(pp, 0.0)),
        "spd": max(1, int(pl.get("spd", 20))),
        "eh_voce": pp == pid,
    } for pp, pl in players.items()]

    minha = players.get(pid, {})
    return {
        "em_pvp": True, "log": log_msg,
        "meu_bar": float(atb.get(pid, 0.0)), "meu_hp": max(0, int(minha.get("hp", 0))),
        "jogadores": jogadores, "logs": (rs.get("logs") or [])[-6:],
    }


@app.get("/api/raid/pvp")
def get_raid_pvp(authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    p = _carregar_jogador(telegram_id)
    return JSONResponse(_montar_snapshot_raid_pvp(p, telegram_id))


@app.post("/api/raid/pvp/attack")
def post_raid_pvp_attack(corpo: dict | None = Body(None), authorization: str | None = Header(None)):
    usuario = _extrair_usuario(authorization)
    telegram_id = int(usuario["id"])
    corpo = corpo or {}
    target_pid = corpo.get("target_pid")

    from game.logic import raid_pvp_attack

    p = _carregar_jogador(telegram_id)
    msg = raid_pvp_attack(p, target_pid)
    _salvar_jogador(telegram_id, p)
    return JSONResponse(_montar_snapshot_raid_pvp(p, telegram_id, msg))


# =============================================================================
# 🗂️ ARQUIVOS ESTÁTICOS (HTML/CSS/JS do Mini App)
# =============================================================================
# 🔥 cache-busting: HTML/JS/CSS NUNCA cacheiam (Cache-Control: no-cache) —
# é o bug clássico de WebView do Telegram: sem isso, o Telegram continua
# servindo a versão antiga do JS/CSS mesmo depois de atualizar o arquivo
# no servidor, e parece bug de código quando não é.

@app.middleware("http")
async def no_cache_para_html_js_css(request, call_next):
    response = await call_next(request)
    if request.url.path.endswith((".html", ".js", ".css")) or request.url.path == "/":
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response


# =============================================================================
# 🔄 VERSÃO DE CACHE AUTOMÁTICA
# Armadilha nº 7 do projeto: "sempre subir a versão do cache (?v=N) ao mexer
# em app.js/style.css, senão o Telegram serve a versão antiga".
#
# Eu caí nela. Ao inventariar o projeto achei o index.html preso em v=31
# enquanto eu achava que estava em v=43 — uma cadeia de substituições de
# texto tinha falhado em silêncio, e DOZE versões de mudança estavam sendo
# servidas do cache antigo no aparelho de quem já tinha aberto o jogo.
#
# Lembrar de subir um número à mão é justamente o tipo de coisa que falha.
# Agora o servidor calcula: a versão é o hash do conteúdo de app.js +
# style.css. Mudou o arquivo, mudou a URL. Não mudou, o navegador reusa.
# Não tem como esquecer porque não tem o que lembrar.
# =============================================================================

def _versao_dos_estaticos() -> str:
    import hashlib
    h = hashlib.sha256()
    # ⚠️ Arquivo estático novo tem que entrar AQUI e no regex de get_index.
    # Ficar de fora do hash é a armadilha nº 7 acontecendo de novo, e dessa
    # vez sem ninguém pra perceber: a URL nunca muda, o cache nunca solta.
    for nome in ("app.js", "style.css"):
        caminho = STATIC_DIR / nome
        try:
            h.update(caminho.read_bytes())
        except OSError:
            h.update(nome.encode())
    return h.hexdigest()[:10]


@app.get("/")
@app.get("/index.html")
def get_index():
    """Serve o index com a versão de cache carimbada na hora."""
    import re as _re
    try:
        html = (STATIC_DIR / "index.html").read_text(encoding="utf-8")
    except OSError:
        raise HTTPException(status_code=500, detail="index.html não encontrado.")
    versao = _versao_dos_estaticos()
    html = _re.sub(r'(app\.js|style\.css)\?v=[^"\']*',
                   lambda m: f"{m.group(1)}?v={versao}", html)
    return Response(content=html, media_type="text/html",
                    headers={"Cache-Control": "no-cache"})


app.mount("/", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")
