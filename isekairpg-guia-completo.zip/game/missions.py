# game/missions.py
"""
📜 MISSÕES INICIAIS (08/07/2026)

Guiam o jogador novo pelos sistemas do jogo (forja, trilhas, sockets,
skills) antes do Andar 5 — que é onde ele escolhe a classe e o jogo
"começa pra valer". Dão ouro e XP, e algumas partes do jogo só liberam
depois que todas forem concluídas.

DESIGN IMPORTANTE: nenhuma missão rastreia eventos. Cada uma só olha o
ESTADO ATUAL do jogador ("tem o set equipado?", "está no nível 5?").
Isso deixa o sistema simples e à prova de falhas — não tem como perder
progresso por um evento não capturado, e funciona pra quem já jogava
antes das missões existirem (se já fez, já conta como feito).
"""
from game.items import SLOTS

RARIDADES_ACIMA_DE_COMUM = {"uncommon", "rare", "epic", "legendary", "mythic"}
MIN_ITENS_EQUIPADOS = 3
SKILL_INICIAL_ID = "a_starter_1"


# =============================================================================
# ✅ VERIFICADORES — cada um olha só o estado atual, sem rastrear eventos
# =============================================================================

def _todos_itens(p: dict) -> list:
    """Junta tudo que o jogador tem: equipado + guardado no inventário."""
    itens = []
    for it in (p.get("equip") or {}).values():
        if it:
            itens.append(it)
    inv_items = (p.get("inv") or {}).get("items") or {}
    for lista in inv_items.values():
        for it in (lista or []):
            if it:
                itens.append(it)
    return itens


def _chegou_nivel_5(p: dict) -> bool:
    return int(p.get("level", 1)) >= 5


def _set_completo_equipado(p: dict) -> bool:
    equip = p.get("equip") or {}
    return sum(1 for slot in SLOTS if equip.get(slot)) >= MIN_ITENS_EQUIPADOS


def _usou_ponto_de_trilha(p: dict) -> bool:
    trails = p.get("trails") or {}
    for t in trails.values():
        if not isinstance(t, dict):
            continue
        if int(t.get("step", 0) or 0) > 0 or int(t.get("cycles", 0) or 0) > 0:
            return True
    return False


def _tem_item_incomum_ou_melhor(p: dict) -> bool:
    return any(str(it.get("rar", "")).lower() in RARIDADES_ACIMA_DE_COMUM for it in _todos_itens(p))


def _colocou_core_em_socket(p: dict) -> bool:
    return any((it.get("socked") or []) for it in _todos_itens(p))


def _aprendeu_skill_inicial(p: dict) -> bool:
    return SKILL_INICIAL_ID in (p.get("skills_learned") or {})


# =============================================================================
# 📋 A LISTA DE MISSÕES
# =============================================================================

MISSOES = [
    {
        "id": "m_skill_equip",
        "nome": "Aprenda sua primeira magia",
        "desc": "Derrote monstros na Torre até dropar o <b>Core de Golpe Firme</b>, e aprenda a magia (Status → Gerenciar Skills).",
        "check": _aprendeu_skill_inicial,
        "ouro": 500,
        "xp": 50,
    },
    {
        "id": "m_craft_uncommon",
        "nome": "Forje algo melhor",
        "desc": "Forje um item de raridade <b>Incomum</b> ou superior na Forja (use 5 cores em vez de 4).",
        "check": _tem_item_incomum_ou_melhor,
        "ouro": 1_000,
        "xp": 100,
    },
    {
        "id": "m_trail",
        "nome": "Trilhe seu caminho",
        "desc": "Gaste pelo menos 1 ponto de trilha (Status → Trilhas). Você ganha pontos subindo de nível.",
        "check": _usou_ponto_de_trilha,
        "ouro": 800,
        "xp": 80,
    },
    {
        "id": "m_socket",
        "nome": "Encaixe um core",
        "desc": "Coloque um core no socket de um item (Centro da Cidade → Sockets). Itens Incomuns ou melhores têm sockets.",
        "check": _colocou_core_em_socket,
        "ouro": 1_200,
        "xp": 120,
    },
    {
        "id": "m_full_set",
        "nome": "Equipe-se",
        "desc": f"Tenha pelo menos <b>{MIN_ITENS_EQUIPADOS} itens</b> equipados ao mesmo tempo.",
        "check": _set_completo_equipado,
        "ouro": 3_000,
        "xp": 300,
    },
    {
        "id": "m_level_5",
        "nome": "Alcance o Nível 5",
        "desc": "Suba até o <b>Nível 5</b> enfrentando monstros na Torre.",
        "check": _chegou_nivel_5,
        "ouro": 2_000,
        "xp": 0,
    },
]


# =============================================================================
# 🎯 API PÚBLICA
# =============================================================================

def get_missao(missao_id: str) -> dict | None:
    return next((m for m in MISSOES if m["id"] == missao_id), None)


def status_missoes(p: dict) -> list:
    """Lista todas as missões com o estado atual de cada uma:
    - concluida: o jogador cumpre o requisito AGORA
    - resgatada: já pegou a recompensa (não dá pra pegar 2x)"""
    resgatadas = set((p.get("missions_claimed") or []))
    resultado = []
    for m in MISSOES:
        try:
            concluida = bool(m["check"](p))
        except Exception:
            concluida = False
        resultado.append({
            "id": m["id"],
            "nome": m["nome"],
            "desc": m["desc"],
            "ouro": m["ouro"],
            "xp": m["xp"],
            "concluida": concluida,
            "resgatada": m["id"] in resgatadas,
        })
    return resultado


def todas_concluidas(p: dict) -> bool:
    """True se o jogador cumpre TODOS os requisitos (independente de já ter
    resgatado a recompensa ou não) — é isso que libera o conteúdo travado."""
    return all(s["concluida"] for s in status_missoes(p))


def quantas_faltam(p: dict) -> int:
    return sum(1 for s in status_missoes(p) if not s["concluida"])


def resgatar_recompensa(p: dict, missao_id: str) -> tuple:
    """Entrega ouro/XP de uma missão concluída. Retorna (ok, mensagem)."""
    m = get_missao(missao_id)
    if not m:
        return False, "❌ Missão não encontrada."

    resgatadas = p.setdefault("missions_claimed", [])
    if missao_id in resgatadas:
        return False, "❌ Você já resgatou essa recompensa."

    try:
        if not m["check"](p):
            return False, "❌ Você ainda não cumpriu essa missão."
    except Exception:
        return False, "❌ Não deu pra verificar essa missão agora."

    p["gold"] = int(p.get("gold", 0)) + int(m["ouro"])
    resgatadas.append(missao_id)

    msg = f"✅ <b>{m['nome']}</b> concluída!\n💰 +{m['ouro']:,}g"

    xp_ganho = int(m.get("xp", 0))
    if xp_ganho > 0:
        from game.logic import gain_xp
        msg_xp = gain_xp(p, xp_ganho)
        msg += f"  ✨ +{xp_ganho} XP\n"
        if msg_xp:
            msg += str(msg_xp)
    else:
        msg += "\n"

    return True, msg


def resgatar_todas(p: dict) -> str:
    """Resgata de uma vez tudo que estiver concluído e ainda não pego."""
    linhas = []
    for s in status_missoes(p):
        if s["concluida"] and not s["resgatada"]:
            ok, msg = resgatar_recompensa(p, s["id"])
            if ok:
                linhas.append(msg)
    if not linhas:
        return "❌ Nenhuma recompensa disponível pra resgatar agora."
    return "\n".join(linhas)
