"""
Risco do AFK — o preço de mandar alguém pra fora.

POR QUE ISTO NÃO USA O COMBATE DA TORRE
---------------------------------------
Tentei medir a chance de morte rodando autobatalha de verdade. Deu **0% ou
100%**, nunca no meio: no combate atual, se o ATK do membro não passa da DEF
do inimigo ele nunca vence; se passa, quase nunca perde. Isso não é escolha,
é tabela de consulta — o jogador olharia qual o andar mais alto com 0% e
mandaria todo mundo pra lá.

Como a morte aqui é PERMANENTE, o risco precisa ser um número próprio: suave,
tunável e — o mais importante — **mostrável antes de confirmar**. Número
escondido vira injustiça; número na tela vira aposta.

AS TRÊS REGRAS QUE FAZEM A ESCOLHA EXISTIR
------------------------------------------
1. **Curva suave.** Risco logístico sobre a margem (poder − perigo). Sem
   degrau: cada ponto de poder muda alguma coisa.

2. **Morreu, perdeu a carga.** Sem esta regra o resultado ficava em U — área
   segura e a mais mortal ganhavam, o meio perdia. Medido: com risco travado
   no teto e recompensa crescendo sem limite, a área mais perigosa sempre
   vencia. Com a carga se perdendo, 90% de risco deixa de pagar.

3. **Piso e teto.** O risco nunca chega a zero (o AFK mata livremente, então
   área segura é segura, não imune) nem a 100% (sempre há chance de voltar,
   senão mandar seria suicídio e ninguém mandaria).

O QUE A MEDIÇÃO MOSTROU, E O QUE ISSO EXIGE DO CONTEÚDO
-------------------------------------------------------
Com estes números, o posto matematicamente ótimo é sempre de risco BAIXO
(entre 0,7% e 10%), e ele sobe com o poder — poder 10 quer perigo 10, poder
100 quer perigo 45. Isso é bom: progredir tem pra onde ir.

Mas tem uma consequência que o conteúdo precisa resolver: se a conta sempre
aponta pro seguro, **quem otimiza nunca vê a área perigosa**. É o bug de
sempre em forma de número. A saída não é mexer na curva — é área perigosa
dar o que a segura NÃO dá: material raro, ponto de mapa, membro novo. Aí
deixa de ser comparação de números e vira "eu preciso daquilo".
"""
from __future__ import annotations

import math
import random

# Calibrados medindo a COMPOSIÇÃO, não a expedição solta — ver a nota abaixo.
ESCALA = 9.0
PISO_INCIDENTE = 0.005
TETO_INCIDENTE = 0.70

# Chance de morrer DADO que houve incidente. Fica separado de propósito:
# o cavaleiro que se mete em encrenca ainda tem 3 em 4 de escapar. Fundir
# os dois números foi o erro da primeira versão.
MORTE_NO_INCIDENTE_BASE = 0.25


def chance_incidente(poder: float, perigo: float) -> float:
    """Chance de algo dar errado na expedição. NÃO é chance de morte.

    ⚠️ A primeira versão disto era 'chance de morrer', e a composição
    destruía o jogo. Medido: risco 6% por expedição, 3 expedições por
    sessão, dá 83% de voltar vivo — o cavaleiro morre em menos de uma
    semana de jogo normal. Com 1 expedição/hora e 8h de sono, 61%.
    Ninguém joga assim.

    A correção é estrutural, não de número: a maior parte das expedições é
    sem graça — ele vai, junta, volta. Quando dá incidente, aí existe
    teste, e morrer é UM dos resultados. A morte vira produto de duas
    chances, e o incidente é o storylet do AFK.

    Com morte|incidente em 25% e teto de 3 expedições por sessão, o
    espectro medido fica:
        guardar o celeiro   0,6% incidente -> dura ~223 sessões
        caçar nas matas     1,5%           -> ~89
        patrulhar fronteira 4,8%           -> ~28  (cerca de um mês)
        vasculhar ruínas     24%           -> ~6   (uma semana)
        descer ao abismo     60%           -> ~3   (poucos dias)
    """
    margem = float(poder) - float(perigo)
    return PISO_INCIDENTE + (TETO_INCIDENTE - PISO_INCIDENTE) / (1.0 + math.exp(margem / ESCALA))


def chance_morte_no_incidente(poder: float, perigo: float) -> float:
    """Dado o incidente, quanto ele tem de não voltar.

    ⚠️ Esta parte NÃO satura de propósito. A chance de encrenca satura
    (acima de certo ponto, encrenca é praticamente certa), e o auditor
    pegou o efeito disso: no nível 20, 'ruínas' (perigo 65) e 'abismo'
    (perigo 95) davam risco quase igual, mas o abismo rendia o dobro. Risco
    igual e prêmio maior é dominância disfarçada — e a curva logística é
    ótima em esconder isso.

    Aqui a margem entra LINEAR, sem teto de saturação, então perigo 95
    continua sendo pior que 65 mesmo pra quem já está muito atrás.
    """
    margem = float(poder) - float(perigo)
    # 5% no melhor caso (até o mais forte pode cair — é o que 'mata
    # livremente' significa) até 85% quando se está muito atrás.
    fatia = max(0.0, min(1.0, (30.0 - margem) / 90.0))
    return max(0.05, min(0.85, 0.05 + 0.80 * fatia))


def risco_expedicao(poder: float, perigo: float) -> float:
    """Chance de morrer numa expedição = incidente x morte no incidente."""
    return chance_incidente(poder, perigo) * chance_morte_no_incidente(poder, perigo)


def poder_do_membro(membro: dict) -> float:
    """Quanto o membro aguenta lá fora.

    Nível pesa mais que equipamento de propósito: equipar todo mundo até os
    dentes não pode substituir formar gente. Mas equipamento pesa o
    bastante pra valer a pena — senão a forja fica sem função no clã.
    """
    nivel = int(membro.get("level") or membro.get("nivel") or 1)
    equipamento = int(membro.get("equip_poder") or 0)
    fome = int(membro.get("fome") or 0)
    ferimento = int(membro.get("ferimento") or 0)
    # Fome e ferimento derrubam o poder: é assim que "cuidar do clã" vira
    # mecânica em vez de enfeite.
    return max(1.0, nivel + equipamento * 0.4 - fome * 0.5 - ferimento * 0.8)


def previsao(membro: dict, posto: dict) -> dict:
    """O que a tela mostra ANTES de confirmar. Tudo que a conta usa fica
    visível — inclusive quantas expedições ele aguenta em média, que é o
    número que as pessoas realmente entendem."""
    poder = poder_do_membro(membro)
    perigo = float(posto.get("perigo", 0))
    inc = chance_incidente(poder, perigo)
    morte_inc = chance_morte_no_incidente(poder, perigo)
    r = inc * morte_inc
    bruto = int(posto.get("rende", 0))
    return {
        "poder": round(poder, 1),
        "perigo": perigo,
        # Os três separados de propósito: "10% de encrenca, e se der
        # encrenca 25% de não voltar" é muito mais legível que "2,5%".
        "incidente": round(inc * 100, 1),
        "morte_no_incidente": round(morte_inc * 100, 1),
        "risco": round(r * 100, 2),
        "rende": bruto,
        # Carga perdida na morte: o valor ESPERADO é o que ele entrega, não
        # o que ele junta. Mostrar só o bruto seria propaganda enganosa.
        "esperado": round(bruto * (1 - r), 1),
        "expedicoes_ate_morrer": round(1 / r, 1) if r > 0 else None,
        "raro": posto.get("raro"),
    }


def resolver(membro: dict, posto: dict, rng: random.Random | None = None) -> dict:
    """Roda uma expedição. Devolve o que aconteceu, com a conta aberta —
    é ela que o log de causa guarda pra responder 'por que ele morreu?'."""
    rng = rng or random
    poder = poder_do_membro(membro)
    perigo = float(posto.get("perigo", 0))
    inc = chance_incidente(poder, perigo)
    morte_inc = chance_morte_no_incidente(poder, perigo)

    rolagem_inc = rng.random()
    houve_incidente = rolagem_inc < inc
    rolagem_morte = rng.random() if houve_incidente else 1.0
    morreu = houve_incidente and rolagem_morte < morte_inc

    resultado = {
        "posto": posto.get("id"), "incidente": houve_incidente, "morreu": morreu,
        "poder": round(poder, 1), "perigo": perigo,
        "chance_incidente": round(inc * 100, 1),
        "chance_morte_no_incidente": round(morte_inc * 100, 1),
        "rolagem_incidente": round(rolagem_inc * 100, 1),
        "rolagem_morte": round(rolagem_morte * 100, 1) if houve_incidente else None,
        "carga": 0, "raro": None,
    }
    if morreu:
        # A conta inteira na mensagem: com morte permanente, "ele morreu" sem
        # o porquê é arbitrário. Com os números na mesa, é a sua aposta.
        resultado["motivo"] = (
            f"em '{posto.get('nome', posto.get('id'))}': {inc*100:.1f}% de encrenca, "
            f"rolou {rolagem_inc*100:.1f} — deu encrenca. Aí {morte_inc*100:.0f}% de não "
            f"voltar, rolou {rolagem_morte*100:.1f}. Morreu com a carga.")
        return resultado
    if houve_incidente:
        resultado["motivo"] = (
            f"teve encrenca em '{posto.get('nome', posto.get('id'))}' e escapou "
            f"(rolou {rolagem_morte*100:.1f} contra {morte_inc*100:.0f}%)")
        resultado["ferimento"] = 1

    bruto = int(posto.get("rende", 0))
    # Variação de ±25% pra a expedição não virar sempre o mesmo número.
    resultado["carga"] = max(0, int(bruto * rng.uniform(0.75, 1.25)))
    raro = posto.get("raro")
    if raro and rng.random() < float(posto.get("chance_raro", 0)):
        resultado["raro"] = raro
    resultado.setdefault("motivo",
        f"voltou de '{posto.get('nome', posto.get('id'))}' sem novidade")
    return resultado


def ordenar_postos(membro: dict, postos: list) -> list:
    """Postos com a previsão de cada um, do mais seguro ao mais mortal.

    Ordenar por RISCO e não por recompensa é decisão de interface: numa
    lista onde a primeira opção mata, o toque errado custa um personagem
    permanente.
    """
    saida = [dict(p, previsao=previsao(membro, p)) for p in postos]
    saida.sort(key=lambda x: x["previsao"]["risco"])
    return saida
