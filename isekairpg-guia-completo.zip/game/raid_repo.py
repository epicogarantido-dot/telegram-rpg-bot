import json
import time
import random
import string
from typing import Dict, Any, List, Optional

from game.sql_repo import get_connection

from infra.migracao import garantir_colunas, garantir_colunas_async

# 🧱 20/09/2026 — os CREATE deste arquivo viraram constantes pra que a
# MESMA string crie a tabela e migre banco velho (infra/migracao.py).
# Coluna nova entra aqui e chega sozinha em quem já tinha a tabela.
_SQL_RAID_ROOMS = """
            CREATE TABLE IF NOT EXISTS raid_rooms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                leader_pid TEXT NOT NULL,
                members TEXT,      -- JSON lista de pids
                ready_map TEXT,    -- JSON {pid: bool}
                state TEXT DEFAULT 'LOBBY',
                floor INTEGER DEFAULT 1,
                max_members INTEGER DEFAULT 5,
                open INTEGER DEFAULT 1,
                data TEXT,         -- JSON completo da room
                created_at INTEGER,
                updated_at INTEGER
            );
            """



def init_tables() -> None:
    """Cria tabelas de raid se não existirem."""
    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            _SQL_RAID_ROOMS
        )
        garantir_colunas(c, _SQL_RAID_ROOMS)  # 🧱 migra o que o CREATE tem e o disco não
        conn.commit()


init_tables()


def _now() -> int:
    return int(time.time())


def generate_password(length: int = 6) -> str:
    chars = string.ascii_uppercase + string.digits
    return "".join(random.choice(chars) for _ in range(length))

# raid_repo.py

def create_room(leader_pid: str, floor: int = 1, max_members: int = 5) -> Dict[str, Any]:
    room: Dict[str, Any] = {
        "leader_pid": leader_pid,
        "members": [leader_pid],
        "ready_map": {leader_pid: False},
        "floor": int(floor),
        "state": "LOBBY",
        # COMEÇA FECHADA
        "open": False,
        # senha aleatória de 6 caracteres
        "password": generate_password(),
        "max_members": int(max_members),
        "combat": None,
        "created_at": _now(),
        "updated_at": _now(),
    }
    

    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            """
            INSERT INTO raid_rooms (
                leader_pid, members, ready_map, state, floor,
                max_members, open, data, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                leader_pid,
                json.dumps(room["members"]),
                json.dumps(room["ready_map"]),
                room["state"],
                room["floor"],
                room["max_members"],
                int(room["open"]),
                json.dumps(room),
                room["created_at"],
                room["updated_at"],
            ),
        )
        room["id"] = c.lastrowid
        conn.commit()
    return room


def get_room(room_id: int) -> Optional[Dict[str, Any]]:
    """Carrega uma sala pelo id (ou None)."""
    with get_connection() as conn:
        c = conn.cursor()
        try:
            c.execute(
                "SELECT id, data FROM raid_rooms WHERE id = ?", (int(room_id),)
            )
            row = c.fetchone()
            if not row:
                return None
            data = json.loads(row["data"])
            data["id"] = row["id"]
            return data
        except Exception:
            return None


def save_room(room: Dict[str, Any]) -> None:
    """Salva alterações da sala no banco (usando campo data JSON)."""
    room_copy = dict(room)
    rid = int(room_copy.pop("id"))
    room_copy["updated_at"] = _now()
    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            "UPDATE raid_rooms SET data = ?, updated_at = ? WHERE id = ?",
            (json.dumps(room_copy), room_copy["updated_at"], rid),
        )
        conn.commit()


def delete_room(room_id: int) -> None:
    """Apaga a sala definitivamente."""
    with get_connection() as conn:
        c = conn.cursor()
        try:
            c.execute("DELETE FROM raid_rooms WHERE id = ?", (int(room_id),))
            conn.commit()
        except Exception:
            pass


def find_room_by_member(pid: str) -> Optional[Dict[str, Any]]:
    """Procura a sala mais recente em que o pid é membro."""
    with get_connection() as conn:
        c = conn.cursor()
        c.execute("SELECT id, data FROM raid_rooms ORDER BY id DESC")
        rows = c.fetchall()

    for row in rows:
        data = json.loads(row["data"])
        if pid in data.get("members", []):
            data["id"] = row["id"]
            return data
    return None


def list_open_rooms() -> List[Dict[str, Any]]:
    """Lista salas abertas em LOBBY para o menu de rooms."""
    with get_connection() as conn:
        c = conn.cursor()
        try:
            c.execute(
                "SELECT id, data FROM raid_rooms ORDER BY id DESC LIMIT 20"
            )
            rows = c.fetchall()
        except Exception:
            return []

    rooms: List[Dict[str, Any]] = []
    for r in rows:
        data = json.loads(r["data"])
        data["id"] = r["id"]
        if data.get("open") and data.get("state") == "LOBBY":
            rooms.append(data)
    return rooms


class RaidRepo:
    """
    Classe fina só para manter compatibilidade com main.py,
    que faz RaidRepo().init_tables().
    """

    def __init__(self) -> None:
        init_tables()

    def init_tables(self) -> None:
        init_tables()