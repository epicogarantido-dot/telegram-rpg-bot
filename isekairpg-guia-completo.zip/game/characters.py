# game/characters.py
"""
🎭 SLOTS DE PERSONAGEM (08/07/2026) — v2, modelo "guarda e traz".

Em vez de dar um ID próprio pra cada personagem (que exigiria ensinar
TODO o resto do jogo a lidar com "personagem ativo" — main.py, router,
raid, arena...), a abordagem aqui é mais simples e não muda NADA do
motor existente:

- O jogo continua sempre usando o telegram_id real de sempre, do jeito
  que já funciona hoje.
- Trocar de personagem = "guardar o que está na mesa, trazer outro do
  armário": copia as linhas ao vivo (players/items/skills/arena) pra uma
  tabela de armazenamento, limpa a mesa, e recoloca os dados do slot
  escolhido (ou começa um personagem zerado, se o slot ainda não tinha
  nada guardado).

Zero risco pro código existente — pro resto do jogo, é sempre "só um
personagem", porque literalmente só um está "ao vivo" por vez.
"""
import json
import time

from infra.migracao import garantir_colunas, garantir_colunas_async

# 🧱 20/09/2026 — os CREATE deste arquivo viraram constantes pra que a
# MESMA string crie a tabela e migre banco velho (infra/migracao.py).
# Coluna nova entra aqui e chega sozinha em quem já tinha a tabela.
_SQL_CHARACTER_MARKET = """
            CREATE TABLE IF NOT EXISTS character_market (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                seller_id INTEGER NOT NULL,
                player_json TEXT,
                items_json TEXT,
                skills_json TEXT,
                arena_json TEXT,
                nome TEXT DEFAULT '',
                nivel INTEGER DEFAULT 1,
                price INTEGER DEFAULT 0,
                listed_at INTEGER
            );
            """
_SQL_ACTIVE_SLOT = """
            CREATE TABLE IF NOT EXISTS active_slot (
                owner_id INTEGER PRIMARY KEY,
                slot INTEGER DEFAULT 0
            );
            """
_SQL_CHARACTER_STORAGE = """
            CREATE TABLE IF NOT EXISTS character_storage (
                owner_id INTEGER NOT NULL,
                slot INTEGER NOT NULL,
                player_json TEXT,
                items_json TEXT,
                skills_json TEXT,
                arena_json TEXT,
                nome TEXT DEFAULT '',
                nivel INTEGER DEFAULT 1,
                saved_at INTEGER,
                origem_json TEXT,
                PRIMARY KEY (owner_id, slot)
            );
            """


MAX_SLOTS_EXTRAS = 5


def init_tables() -> None:
    from game.sql_repo import get_connection
    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            _SQL_CHARACTER_STORAGE
        )
        garantir_colunas(c, _SQL_CHARACTER_STORAGE)  # 🧱 migra o que o CREATE tem e o disco não
        c.execute(
            _SQL_ACTIVE_SLOT
        )
        garantir_colunas(c, _SQL_ACTIVE_SLOT)  # 🧱 migra o que o CREATE tem e o disco não
        c.execute(
            _SQL_CHARACTER_MARKET
        )
        garantir_colunas(c, _SQL_CHARACTER_MARKET)  # 🧱 migra o que o CREATE tem e o disco não
        conn.commit()


init_tables()


# =============================================================================
# 📸 SNAPSHOT — ler/escrever as tabelas "ao vivo" de forma genérica (sem
# fixar colunas na mão, pra não quebrar se o schema mudar no futuro)
# =============================================================================

def _tabela_existe(conn, nome: str) -> bool:
    c = conn.cursor()
    c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (nome,))
    return c.fetchone() is not None


def _snapshot_conta_atual(owner_id: int) -> dict:
    """Lê tudo que está ao vivo pra esse telegram_id: a linha de players,
    todas as linhas de items e skills, e o snapshot de arena (se tiver)."""
    from game.sql_repo import get_connection

    with get_connection() as conn:
        c = conn.cursor()

        c.execute("SELECT * FROM players WHERE telegram_id = ?", (owner_id,))
        row = c.fetchone()
        player = dict(row) if row else None

        c.execute("SELECT * FROM items WHERE telegram_id = ?", (owner_id,))
        items = [dict(r) for r in c.fetchall()]

        c.execute("SELECT * FROM skills WHERE telegram_id = ?", (owner_id,))
        skills = [dict(r) for r in c.fetchall()]

        arena = None
        if _tabela_existe(conn, "arena_snapshots"):
            c.execute("SELECT * FROM arena_snapshots WHERE telegram_id = ?", (owner_id,))
            row_a = c.fetchone()
            arena = dict(row_a) if row_a else None

    return {"player": player, "items": items, "skills": skills, "arena": arena}


def _limpar_dados_ao_vivo(owner_id: int) -> None:
    """Apaga items/skills/arena_snapshot da conta — a linha de 'players'
    em si é sobrescrita direto na restauração, não precisa apagar antes."""
    from game.sql_repo import get_connection

    with get_connection() as conn:
        c = conn.cursor()
        c.execute("DELETE FROM items WHERE telegram_id = ?", (owner_id,))
        c.execute("DELETE FROM skills WHERE telegram_id = ?", (owner_id,))
        if _tabela_existe(conn, "arena_snapshots"):
            c.execute("DELETE FROM arena_snapshots WHERE telegram_id = ?", (owner_id,))
        conn.commit()


def _restaurar_dados_ao_vivo(owner_id: int, snapshot: dict) -> None:
    """Recoloca um snapshot guardado de volta nas tabelas ao vivo, sempre
    sob o telegram_id real de sempre (a conta nunca muda de ID)."""
    from game.sql_repo import get_connection

    with get_connection() as conn:
        c = conn.cursor()

        if snapshot.get("player"):
            pdata = dict(snapshot["player"])
            pdata["telegram_id"] = owner_id
            colunas = list(pdata.keys())
            placeholders = ",".join(["?"] * len(colunas))
            colunas_str = ",".join(colunas)
            valores = [pdata[col] for col in colunas]
            c.execute(f"INSERT OR REPLACE INTO players ({colunas_str}) VALUES ({placeholders})", valores)

        for item in snapshot.get("items") or []:
            item = dict(item)
            item.pop("id", None)  # deixa o autoincrement gerar um id novo
            item["telegram_id"] = owner_id
            colunas = list(item.keys())
            placeholders = ",".join(["?"] * len(colunas))
            colunas_str = ",".join(colunas)
            valores = [item[col] for col in colunas]
            c.execute(f"INSERT INTO items ({colunas_str}) VALUES ({placeholders})", valores)

        for skill in snapshot.get("skills") or []:
            skill = dict(skill)
            skill.pop("id", None)
            skill["telegram_id"] = owner_id
            colunas = list(skill.keys())
            placeholders = ",".join(["?"] * len(colunas))
            colunas_str = ",".join(colunas)
            valores = [skill[col] for col in colunas]
            c.execute(f"INSERT INTO skills ({colunas_str}) VALUES ({placeholders})", valores)

        if snapshot.get("arena") and _tabela_existe(conn, "arena_snapshots"):
            arena = dict(snapshot["arena"])
            arena["telegram_id"] = owner_id
            colunas = list(arena.keys())
            placeholders = ",".join(["?"] * len(colunas))
            colunas_str = ",".join(colunas)
            valores = [arena[col] for col in colunas]
            c.execute(f"INSERT OR REPLACE INTO arena_snapshots ({colunas_str}) VALUES ({placeholders})", valores)

        conn.commit()


# =============================================================================
# 🗄️ ARMAZENAMENTO (o "armário" onde os personagens fora de uso ficam)
# =============================================================================

def _salvar_no_armario(owner_id: int, slot: int, snapshot: dict) -> None:
    from game.sql_repo import get_connection

    pdata = snapshot.get("player") or {}
    nome = pdata.get("username", "") or ""
    nivel = int(pdata.get("level", 1) or 1)

    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            """
            INSERT INTO character_storage (owner_id, slot, player_json, items_json, skills_json, arena_json, nome, nivel, saved_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(owner_id, slot) DO UPDATE SET
                player_json=excluded.player_json, items_json=excluded.items_json,
                skills_json=excluded.skills_json, arena_json=excluded.arena_json,
                nome=excluded.nome, nivel=excluded.nivel, saved_at=excluded.saved_at
            """,
            (
                owner_id, slot,
                json.dumps(snapshot.get("player")), json.dumps(snapshot.get("items") or []),
                json.dumps(snapshot.get("skills") or []), json.dumps(snapshot.get("arena")),
                nome, nivel, int(time.time()),
            ),
        )
        conn.commit()


def _carregar_do_armario(owner_id: int, slot: int) -> dict | None:
    from game.sql_repo import get_connection

    with get_connection() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM character_storage WHERE owner_id = ? AND slot = ?", (owner_id, slot))
        row = c.fetchone()
        if not row:
            return None
        row = dict(row)

    return {
        "player": json.loads(row["player_json"]) if row["player_json"] else None,
        "items": json.loads(row["items_json"]) if row["items_json"] else [],
        "skills": json.loads(row["skills_json"]) if row["skills_json"] else [],
        "arena": json.loads(row["arena_json"]) if row["arena_json"] else None,
    }


# 🐛 25/09/2026: o armário guarda a LINHA CRUA do banco — attrs, trails,
# combat, pets e extra_data como TEXTO JSON, e itens/skills em listas de
# linhas. O cultivo do clã passava isso direto pro recálculo de atributos
# (`recalc`), que quebrava em `attrs.get` numa string — era o 500 do clã.
# Estas duas funções fazem a mesma conversão do `load_player` e o caminho
# de volta, pra quem precisa do personagem do armário "de verdade".
_CAMPOS_JSON_DO_JOGADOR = ("attrs", "trails", "combat", "pets")


def jogador_do_armario(snapshot: dict | None) -> dict | None:
    """O personagem do armário montado como o `load_player` monta."""
    from game.sql_repo import SLOTS
    if not snapshot or not snapshot.get("player"):
        return None
    cru = snapshot["player"]
    p = dict(cru)
    for campo in _CAMPOS_JSON_DO_JOGADOR:
        v = cru.get(campo)
        if isinstance(v, str):
            try:
                p[campo] = json.loads(v) if v else ({} if campo != "combat" else None)
            except ValueError:
                p[campo] = {} if campo != "combat" else None
        elif v is None:
            p[campo] = {} if campo != "combat" else None
    extra = cru.get("extra_data")
    if isinstance(extra, str) and extra:
        try:
            for k, v in (json.loads(extra) or {}).items():
                p[k] = v
        except ValueError:
            pass
    if not isinstance(p.get("pets"), dict) or not p["pets"]:
        p["pets"] = {"owned": {}, "deck": [None] * 5}
    p["pets"].setdefault("deck", [None] * 5)
    p["inv"] = {"potion": 0, "cores": {}, "items": {s: [] for s in SLOTS}}
    p["equip"] = {s: None for s in SLOTS}
    for it in snapshot.get("items") or []:
        tipo = it.get("item_type")
        if tipo == "potion":
            p["inv"]["potion"] = it.get("quantity", 0)
        elif tipo == "core":
            p["inv"]["cores"][it.get("item_key")] = it.get("quantity", 0)
        elif tipo == "equipment":
            try:
                dado = json.loads(it.get("item_data") or "{}")
            except ValueError:
                continue
            slot = it.get("equip_slot")
            if slot not in p["equip"]:
                continue
            if it.get("is_equipped"):
                p["equip"][slot] = dado
            else:
                p["inv"]["items"][slot].append(dado)
    p["skills_learned"], p["skill_slots"] = {}, {"equipped": [None] * 5}
    for sk in snapshot.get("skills") or []:
        try:
            dado = json.loads(sk.get("skill_data") or "{}")
        except ValueError:
            dado = {}
        dado["level"] = sk.get("level", 1)
        p["skills_learned"][sk.get("skill_id")] = dado
        idx = sk.get("equip_index")
        if sk.get("is_equipped") and idx is not None and 0 <= int(idx) < 5:
            p["skill_slots"]["equipped"][int(idx)] = sk.get("skill_id")
    return p


def devolver_ao_armario(snapshot: dict, p: dict) -> None:
    """Grava de volta na linha crua o que o cultivo mexeu (nível, XP, vida,
    estado, trilhas...): colunas simples voltam como estão; as JSON voltam
    como texto. Itens e skills não mudam no cultivo e ficam como estavam."""
    cru = snapshot["player"]
    for k in list(cru.keys()):
        if k in _CAMPOS_JSON_DO_JOGADOR:
            cru[k] = json.dumps(p.get(k)) if p.get(k) is not None else None
        elif k == "extra_data":
            continue
        elif k in p and not isinstance(p[k], (dict, list)):
            cru[k] = p[k]


def _remover_do_armario(owner_id: int, slot: int) -> None:
    from game.sql_repo import get_connection
    with get_connection() as conn:
        c = conn.cursor()
        c.execute("DELETE FROM character_storage WHERE owner_id = ? AND slot = ?", (owner_id, slot))
        conn.commit()


# =============================================================================
# 🎯 API PÚBLICA
# =============================================================================

def get_active_slot(owner_id: int) -> int:
    from game.sql_repo import get_connection
    with get_connection() as conn:
        c = conn.cursor()
        c.execute("SELECT slot FROM active_slot WHERE owner_id = ?", (owner_id,))
        row = c.fetchone()
        return int(row[0]) if row else 0


def _set_active_slot(owner_id: int, slot: int) -> None:
    from game.sql_repo import get_connection
    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            """
            INSERT INTO active_slot (owner_id, slot) VALUES (?, ?)
            ON CONFLICT(owner_id) DO UPDATE SET slot = excluded.slot
            """,
            (owner_id, slot),
        )
        conn.commit()


def slots_ocupados(owner_id: int) -> list:
    """Slots extras (1-5) que já têm personagem guardado no armário —
    NÃO inclui o slot que está ao vivo agora (esse não está no armário)."""
    from game.sql_repo import get_connection
    with get_connection() as conn:
        c = conn.cursor()
        c.execute("SELECT slot, nome, nivel FROM character_storage WHERE owner_id = ? ORDER BY slot", (owner_id,))
        return [{"slot": r[0], "nome": r[1], "nivel": r[2]} for r in c.fetchall()]


def slots_livres(owner_id: int) -> list:
    ativo = get_active_slot(owner_id)
    ocupados = {s["slot"] for s in slots_ocupados(owner_id)}
    if ativo != 0:
        ocupados.add(ativo)  # o slot ao vivo (se não for o principal) também conta como ocupado
    return [s for s in range(1, MAX_SLOTS_EXTRAS + 1) if s not in ocupados]


def listar_personagens_da_conta(owner_id: int) -> list:
    """Lista TODOS os personagens da conta: o que está ao vivo agora
    (direto da tabela players) + os que estão guardados no armário."""
    from game.sql_repo import load_player

    ativo = get_active_slot(owner_id)
    resultado = []

    pdata_vivo = load_player(owner_id)
    if pdata_vivo:
        resultado.append({
            "slot": ativo,
            "nome": pdata_vivo.get("username") or ("Personagem Principal" if ativo == 0 else f"Personagem #{ativo}"),
            "level": pdata_vivo.get("level", 1),
            "ativo": True,
        })

    for entrada in slots_ocupados(owner_id):
        resultado.append({
            "slot": entrada["slot"],
            "nome": entrada["nome"] or f"Personagem #{entrada['slot']}",
            "level": entrada["nivel"],
            "ativo": False,
        })

    resultado.sort(key=lambda x: x["slot"])
    return resultado


def criar_personagem_slot(owner_id: int) -> tuple:
    """'Reserva' o próximo slot livre — o personagem de verdade só é
    criado quando o jogador TROCAR pra esse slot (trocar_personagem já
    sabe criar um zerado quando o armário não tem nada guardado ainda)."""
    from game.sql_repo import get_connection

    livres = slots_livres(owner_id)
    if not livres:
        return False, f"❌ Você já tem os {MAX_SLOTS_EXTRAS} slots extras ocupados."

    slot = livres[0]
    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            """
            INSERT INTO character_storage (owner_id, slot, player_json, items_json, skills_json, arena_json, nome, nivel, saved_at)
            VALUES (?, ?, NULL, '[]', '[]', NULL, ?, 1, ?)
            """,
            (owner_id, slot, f"Personagem #{slot}", int(time.time())),
        )
        conn.commit()

    return True, slot


# ✨ (28/09, dev) "O aldeão desperto vira personagem". O slot nasce reservado
# com a ORIGEM (quem ele era na aldeia); o personagem de verdade nasce na
# primeira troca, como qualquer slot — e passa pela criação (sexo, raça,
# profissão, habilidade). O nome vem da aldeia, e a aura dele vira pontos de
# trilha: 4 por estrela, o que um nível dá. Um 5★ começa com 20 pontos.
PONTOS_POR_ESTRELA_DE_AURA = 4


def criar_slot_de_aldeao(owner_id: int, nome: str, aura: int, profissao: str | None = None,
                         nivel: int = 1) -> tuple:
    from game.sql_repo import get_connection
    livres = slots_livres(owner_id)
    if not livres:
        return False, f"❌ Os {MAX_SLOTS_EXTRAS} slots extras estão ocupados."
    slot = livres[0]
    origem = {"nome": nome, "aura": int(aura), "profissao": profissao, "nivel": int(nivel)}
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO character_storage (owner_id, slot, player_json, items_json, skills_json,"
            " arena_json, nome, nivel, saved_at, origem_json) VALUES (?, ?, NULL, '[]', '[]', NULL, ?, 1, ?, ?)",
            (owner_id, slot, nome, int(time.time()), json.dumps(origem)))
        conn.commit()
    return True, slot


def _origem_do_slot(owner_id: int, slot: int) -> dict | None:
    from game.sql_repo import get_connection
    with get_connection() as conn:
        linha = conn.execute("SELECT origem_json FROM character_storage WHERE owner_id = ? AND slot = ?",
                             (owner_id, slot)).fetchone()
    try:
        return json.loads(linha[0]) if linha and linha[0] else None
    except (ValueError, TypeError):
        return None


def _nome_livre(nome: str, owner_id: int) -> bool:
    from game.sql_repo import get_connection
    with get_connection() as conn:
        return conn.execute("SELECT 1 FROM players WHERE lower(username) = lower(?) AND telegram_id != ?",
                            (nome, owner_id)).fetchone() is None


def trocar_personagem(owner_id: int, slot_destino: int) -> tuple:
    """O coração do sistema: guarda o que está ao vivo agora no armário,
    e traz o personagem do slot escolhido pra mesa."""
    slot_atual = get_active_slot(owner_id)
    if slot_atual == slot_destino:
        return False, "❌ Você já está jogando esse personagem."

    # 1. Guarda o que está ao vivo agora (exceto se for um slot "fantasma"
    # sem personagem de verdade — não deveria acontecer, mas por segurança)
    snapshot_atual = _snapshot_conta_atual(owner_id)
    if snapshot_atual.get("player"):
        _salvar_no_armario(owner_id, slot_atual, snapshot_atual)

    # 2. Limpa a mesa
    _limpar_dados_ao_vivo(owner_id)

    # 3. Traz o personagem de destino
    snapshot_destino = _carregar_do_armario(owner_id, slot_destino)
    if snapshot_destino and snapshot_destino.get("player"):
        _restaurar_dados_ao_vivo(owner_id, snapshot_destino)
    else:
        from game.logic import create_player
        from game.sql_repo import save_player_sql
        novo = create_player(owner_id)
        origem = _origem_do_slot(owner_id, slot_destino)
        if origem:
            # ✨ o aldeão desperto nascendo como usuário de aura
            # 🌱 (28/09, dev) "+10% em todos os status pra quem nasceu na
            # Torre, mas a raça e a classe são aleatórias": sorteadas aqui,
            # antes da criação — que então só pergunta o sexo e a habilidade.
            import random as _rnd
            from game.logic import RACESDB, CLASSESDB, recalc
            novo["origem_aldeao"] = origem
            novo["race_id"] = _rnd.choice(sorted(RACESDB))
            novo["class_id"] = _rnd.choice(sorted(CLASSESDB))
            recalc(novo)
            novo["hp"] = novo["hp_max"]
            novo["trail_points"] = int(novo.get("trail_points") or 0) + \
                PONTOS_POR_ESTRELA_DE_AURA * int(origem.get("aura") or 0)
            if origem.get("nome") and _nome_livre(origem["nome"], owner_id):
                novo["username"] = origem["nome"]      # nome repetido: a entrada pede outro
        save_player_sql(owner_id, novo)
    # 🔥 Remove o registro do armário nos dois casos — senão um slot recém
    # criado (só com placeholder, sem 'player' de verdade ainda) fica
    # "fantasma" lá e aparece duplicado na listagem.
    _remover_do_armario(owner_id, slot_destino)

    _set_active_slot(owner_id, slot_destino)
    return True, f"✅ Troca feita! Agora você está jogando o personagem do slot {slot_destino if slot_destino else 'Principal'}."


# =============================================================================
# 💰 MERCADO DE PERSONAGENS (08/07/2026) — mesma moeda do mercado de itens
# (⭐ estrelas). Só dá pra vender um personagem que está NO ARMÁRIO (ou
# seja, não pode ser o que está ao vivo agora — troque pra outro primeiro).
# =============================================================================

def listar_personagem_a_venda(owner_id: int, slot: int, price: int) -> tuple:
    """Tira um personagem do armário do vendedor e coloca no mercado."""
    from game.sql_repo import get_connection

    if slot == get_active_slot(owner_id):
        return False, "❌ Esse personagem está ao vivo agora — troque pra outro antes de vender esse."

    snapshot = _carregar_do_armario(owner_id, slot)
    if not snapshot or not snapshot.get("player"):
        return False, "❌ Não há personagem de verdade guardado nesse slot."

    price = max(1, int(price))

    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            """
            INSERT INTO character_market (seller_id, player_json, items_json, skills_json, arena_json, nome, nivel, price, listed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                owner_id, json.dumps(snapshot["player"]), json.dumps(snapshot.get("items") or []),
                json.dumps(snapshot.get("skills") or []), json.dumps(snapshot.get("arena")),
                snapshot["player"].get("username", "") or f"Personagem #{slot}",
                int(snapshot["player"].get("level", 1) or 1), price, int(time.time()),
            ),
        )
        conn.commit()

    _remover_do_armario(owner_id, slot)
    return True, f"✅ Personagem colocado à venda por ⭐{price}!"


def ver_mercado_personagens(limit: int = 20) -> list:
    from game.sql_repo import get_connection
    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            "SELECT id, seller_id, nome, nivel, price, listed_at FROM character_market ORDER BY listed_at DESC LIMIT ?",
            (limit,),
        )
        return [
            {"id": r[0], "seller_id": r[1], "nome": r[2], "nivel": r[3], "price": r[4], "listed_at": r[5]}
            for r in c.fetchall()
        ]


def ver_minhas_vendas(owner_id: int) -> list:
    from game.sql_repo import get_connection
    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            "SELECT id, nome, nivel, price FROM character_market WHERE seller_id = ? ORDER BY listed_at DESC",
            (owner_id,),
        )
        return [{"id": r[0], "nome": r[1], "nivel": r[2], "price": r[3]} for r in c.fetchall()]


def cancelar_venda(owner_id: int, listing_id: int) -> tuple:
    """O vendedor desiste — o personagem volta pro armário dele, no
    primeiro slot livre."""
    from game.sql_repo import get_connection

    with get_connection() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM character_market WHERE id = ? AND seller_id = ?", (listing_id, owner_id))
        row = c.fetchone()
        if not row:
            return False, "❌ Anúncio não encontrado (ou não é seu)."
        row = dict(row)

    livres = slots_livres(owner_id)
    if not livres:
        return False, "❌ Você não tem nenhum slot livre pra receber esse personagem de volta."

    slot = livres[0]
    snapshot = {
        "player": json.loads(row["player_json"]) if row["player_json"] else None,
        "items": json.loads(row["items_json"]) if row["items_json"] else [],
        "skills": json.loads(row["skills_json"]) if row["skills_json"] else [],
        "arena": json.loads(row["arena_json"]) if row["arena_json"] else None,
    }
    _salvar_no_armario(owner_id, slot, snapshot)

    with get_connection() as conn:
        c = conn.cursor()
        c.execute("DELETE FROM character_market WHERE id = ?", (listing_id,))
        conn.commit()

    return True, f"✅ Anúncio cancelado — o personagem voltou pro seu slot {slot}."


def comprar_personagem(buyer_id: int, listing_id: int) -> tuple:
    """Compra um personagem do mercado — vai pro primeiro slot livre do
    comprador. Paga em ⭐ estrelas, direto pro vendedor."""
    from game.sql_repo import get_connection
    from game.premium_system import premium_repo, player_id_gen

    livres = slots_livres(buyer_id)
    if not livres:
        return False, f"❌ Você já tem os {MAX_SLOTS_EXTRAS} slots extras ocupados — libere um antes de comprar."

    with get_connection() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM character_market WHERE id = ?", (listing_id,))
        row = c.fetchone()
        if not row:
            return False, "❌ Esse personagem já não está mais à venda."
        row = dict(row)

    if int(row["seller_id"]) == int(buyer_id):
        return False, "❌ Você não pode comprar seu próprio personagem."

    price = int(row["price"])

    buyer_pid = player_id_gen.get_or_create_id(buyer_id, buyer_id)
    seller_pid = player_id_gen.get_or_create_id(int(row["seller_id"]), int(row["seller_id"]))

    ok, saldo = premium_repo.spend_premium(buyer_pid, price, f"Compra de personagem #{listing_id}")
    if not ok:
        return False, f"❌ Você precisa de ⭐{price}. Saldo: ⭐{saldo}."

    # Confirma que o anúncio ainda existe antes de finalizar (evita comprar 2x o mesmo)
    with get_connection() as conn:
        c = conn.cursor()
        c.execute("DELETE FROM character_market WHERE id = ?", (listing_id,))
        linhas_afetadas = conn.total_changes
        conn.commit()

    if not linhas_afetadas:
        premium_repo.add_premium(buyer_pid, price, "Estorno: personagem já vendido")
        return False, "❌ Alguém comprou esse personagem um instante antes de você. Estrelas devolvidas."

    premium_repo.add_premium(seller_pid, price, f"Venda de personagem #{listing_id}")

    slot = livres[0]
    snapshot = {
        "player": json.loads(row["player_json"]) if row["player_json"] else None,
        "items": json.loads(row["items_json"]) if row["items_json"] else [],
        "skills": json.loads(row["skills_json"]) if row["skills_json"] else [],
        "arena": json.loads(row["arena_json"]) if row["arena_json"] else None,
    }
    _salvar_no_armario(buyer_id, slot, snapshot)

    return True, f"✅ Personagem comprado por ⭐{price}! Ele está no seu slot {slot} — troque pra ele em Personagens."
