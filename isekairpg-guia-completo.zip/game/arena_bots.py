# game/arena_bots.py
"""
🤖 OPONENTES DA ARENA (25/09/2026 — pedido do dev)

"Cria uns oponentes fake pra começar, e em vez de escolher, um sistema que
escolhe um adversário aleatório nos mesmos pontos de arena" — na Arena e na
Arena de Pets.

BOTS
----
- Moram numa faixa de ID só deles (BOT_MIN..BOT_MAX), longe das contas
  reais (que são -1, -2, -3...). NÃO têm linha em `players`: não aparecem
  nos rankings de andar/ouro/nível. O ranking da Arena, o prêmio semanal e
  o reset semanal os ignoram (`sql_repo.SEM_BOT`).
- Ficam ESPALHADOS pelos pontos (0 a ~12), com força crescendo junto: quem
  sobe de pontos encontra bot mais forte. Os pontos deles nunca mudam (a
  luta só mexe nos pontos de quem ataca) e o reset semanal não os zera —
  é isso que mantém sempre alguém em toda faixa.
- A ficha do bot sai das MESMAS funções do jogador (`ensure_player` +
  `recalc` + `build_snapshot_data`; `build_pet_team` nos pets), então o bot
  luta com números de verdade, não inventados.
- Criados sob demanda e uma vez só (`garantir_bots`): se já tem bot, nada.

SORTEIO
-------
`sortear_oponente`: alguém (bot ou jogador) com pontos perto dos seus; a
janela começa em ±0,6 e abre até achar. Nunca você mesmo.
"""
from __future__ import annotations

import json
import random
import sqlite3
import time

BOT_MIN, BOT_MAX = -999_999, -900_000
QTD_BOTS = 30
# ↑ quando o jeito de montar o bot mudar, sobe a versão: bot de versão velha
# é apagado e refeito (guardada em `updated_at`, que no bot não é usado).
# 1 = só atributos · 2 = equipamento, skills e trilhas (25/09)
# 3 = + especialidades, chakra, esquadrão de espíritos e cores nos soquetes
# 4 = o kit vem AOS POUCOS com os pontos (medido: com tudo cheio, o bot de
#     0 pts tinha ATK 231 contra 10–30 de um jogador novo, e o de 8,7 pts
#     vencia 20/20 um jogador real Nv72 — que tinha 2 espíritos, só a arma
#     equipada e 201 pontos de trilha sem gastar)
BOTS_VERSAO = 7      # 5 = peças mais devagar e metade dos soquetes · 7 = topo nível 200, kit cheio no topo


def _quanto_do_kit(pontos: float) -> dict:
    """O que um jogador costuma ter nessa faixa de pontos."""
    f = max(0.0, min(1.0, pontos / PONTOS_MAX_BOT))
    return {"pecas": min(9, 1 + int(f * 8 + 1e-9)),          # 1 → 9 no topo
            "espiritos": min(5, int(round(f * 5))),         # 0 → 5
            "especialidades": min(3, 1 + int(f * 3)),       # 1 → 3
            "trilha_gasta": 0.9}
PONTOS_MAX_BOT = 12.0
NIVEL_MIN_BOT, NIVEL_MAX_BOT = 3, 200
JANELAS = (0.6, 1.0, 2.0, 4.0, 8.0, 1e9)

NOMES_BOT = [
    "Aldric", "Bryn", "Caspian", "Darya", "Eldon", "Fenna", "Gorin", "Hesper",
    "Ilvar", "Jora", "Kestrel", "Lunet", "Maelis", "Norvin", "Orsa", "Pell",
    "Quill", "Rowan", "Sabine", "Tobias", "Ulric", "Vesna", "Wyn", "Xandra",
    "Yorick", "Zelda", "Brisa", "Corvo", "Duna", "Estela",
]
CLASSES = ("guerreiro", "mago", "assassino", "curandeiro", "guardiao", "bezerk", "arqueiro")
RACAS = ("humano", "elfo", "anao", "orc")

DB = "data/game.db"


def _conn():
    # conexão direta, SEM "PRAGMA foreign_keys": o bot não tem linha em
    # `players` de propósito (senão entraria nos rankings de andar/ouro)
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


def eh_bot(telegram_id) -> bool:
    try:
        return BOT_MIN <= int(telegram_id) <= BOT_MAX
    except (TypeError, ValueError):
        return False


def _pontos_do_bot(i: int) -> float:
    return round(PONTOS_MAX_BOT * i / max(1, QTD_BOTS - 1), 1)


def _nivel_do_bot(pontos: float) -> int:
    # 25/09 (dev): "o topo é nível 200" (nível vai até 2× o andar, andar 100)
    return int(round(NIVEL_MIN_BOT + (NIVEL_MAX_BOT - NIVEL_MIN_BOT) * pontos / PONTOS_MAX_BOT))


# 🎒 25/09/2026 (2ª rodada, dev): "pode dar equipamento, skill e pontos de
# trilha gastos". O kit sai do NÍVEL do bot com as regras do jogador:
#   trilhas  → 4 pontos por nível (o mesmo +4 do level up), espalhados nas
#              4 trilhas pela própria `spend_trail_point`, secundário no passo 5
#   equipam. → as 9 peças, forjadas como a forja monta (cores somados), com
#              cores do TIER do andar dele (tier do monstro = andar/10) e a
#              raridade do andar (comum até o 10 ... lendária do 41 em diante,
#              onde o material Primordial da forja lendária cai)
#   skills   → 3 ativas + 2 passivas da classe, da raridade da faixa, com
#              afixo sorteado e nível = 1 a cada 10 níveis do bot (teto 10)
RARIDADE_DO_ITEM = ((10, "common"), (20, "uncommon"), (30, "rare"), (40, "epic"), (10**9, "legendary"))
CORES_DO_SLOT = {
    "weapon": ("wa_atk", "crit", "acc"), "armor": ("ar_def", "reg", "spd"), "helmet": ("ar_def", "reg"),
    "gloves": ("ar_def", "acc", "crit"), "boots": ("ar_def", "spd", "eva"), "shield": ("ar_def", "reg"),
    "belt": ("ac_def", "reg", "eva"), "necklace": ("ac_def", "crit", "acc"), "ring": ("ac_atk", "crit", "spd"),
}


def _raridade_do_item(andar: int) -> str:
    return next(r for teto, r in RARIDADE_DO_ITEM if andar <= teto)


def _equipar_bot(p: dict, andar: int, rng: random.Random, pecas: int = 9) -> None:
    from game.items import RARITIES, SLOTS, WEAPON_TYPES, REQ_CRAFT, core_bonus, apply_bonus
    from game.craft import gen_item_id
    tier = max(1, andar // 10)
    rar = _raridade_do_item(andar)
    p["equip"] = {s: None for s in SLOTS}
    ordem_slots = ["weapon"] + [s for s in SLOTS if s != "weapon"]   # a arma vem primeiro
    for slot in ordem_slots[:max(0, int(pecas))]:
        base, qtd_base = next(iter(REQ_CRAFT[slot].items()))
        extras = CORES_DO_SLOT.get(slot, (base,))
        cores = [base] * qtd_base
        while len(cores) < int(RARITIES[rar]["cores"]):
            cores.append(rng.choice(extras))
        cores = [f"{c}_t{tier}" if tier > 1 else c for c in cores]
        bonus = {}
        for cid in cores:
            bonus = apply_bonus(bonus, core_bonus(cid))
        sub = rng.choice(list(WEAPON_TYPES)) if slot == "weapon" else None
        item = {"id": gen_item_id(), "slot": slot, "rar": rar,
                "name": f"{WEAPON_TYPES[sub]['name'] if sub else slot} {RARITIES[rar]['name']}",
                "bonus": bonus, "cores": cores, "sub": sub, "socked": [],
                "sock_max": {"common": 0, "uncommon": 1, "rare": 2, "epic": 3, "legendary": 4}.get(rar, 2)}
        # soquetes cheios, com cores do mesmo tier (o jogador encaixa o que tem)
        item["socked"] = [(f"{c}_t{tier}" if tier > 1 else c)
                          for c in (rng.choice(extras) for _ in range(int(item["sock_max"]) // 2))]
        if slot in ("belt", "necklace", "ring"):
            item["rnd_stat"] = rng.choice(["atk", "def", "hp_max", "spd", "acc", "eva", "crit"])
        p["equip"][slot] = item


def _gastar_trilhas(p: dict, rng: random.Random, fracao: float = 1.0) -> None:
    import game.logic as L
    from game.items import TRAILS_DB
    p["trail_points"] = int(4 * max(0, int(p.get("level", 1)) - 1) * fracao)
    ordem = list(TRAILS_DB)
    guarda = 0
    while p["trail_points"] > 0 and guarda < 10000:
        guarda += 1
        k = ordem[guarda % len(ordem)]
        ok, _msg, precisa_sec = L.spend_trail_point(p, k, 1)
        if precisa_sec:
            L.spend_trail_point(p, k, 1, sec=rng.choice(TRAILS_DB[k]["sec_opts"]))


def _skills_do_bot(p: dict, raridade: int, rng: random.Random) -> None:
    from game.skills import SKILL_DB, roll_skill_affix
    classe = p.get("class_id")
    nivel_skill = max(1, min(10, int(p.get("level", 1)) // 10 + 1))
    escolhidas = []
    for tipo, qtd in (("active", 3), ("passive", 2)):
        cands = [v["skill"] for v in SKILL_DB.values()
                 if v["skill"].get("type") == tipo and v["skill"].get("req_class") == classe]
        for r in range(raridade, 0, -1):          # a da faixa; se faltar, a de baixo
            da_r = [s for s in cands if int(s.get("rarity", 1)) == r and s not in escolhidas]
            rng.shuffle(da_r)
            while da_r and sum(1 for s in escolhidas if s.get("type") == tipo) < qtd:
                escolhidas.append(da_r.pop())
    p["skills_learned"], equip = {}, []
    for s in escolhidas:
        entrada = dict(s)
        entrada["level"] = nivel_skill
        entrada["affix"] = roll_skill_affix(int(s.get("rarity", 1)))
        p["skills_learned"][s["id"]] = entrada
        equip.append(s["id"])
    p["skill_slots"] = {"equipped": (equip + [None] * 5)[:5]}


def _esquadrao(pontos: float, rng: random.Random, qtd: int = 5) -> tuple[list, dict]:
    """5 espíritos sem repetir; raridade, nível e evolução sobem com os pontos.
    O mesmo esquadrão serve pro bot da Arena (espírito no deck soma status no
    personagem) e pro time do bot da Arena de Pets."""
    from game.pets_db import PETS_DB
    por_raridade = {}
    for pid, pet in PETS_DB.items():
        por_raridade.setdefault(pet.get("rarity", "comum"), []).append(pid)
    ordem = ["comum", "incomum", "raro", "epico", "lendario"]
    teto_rar = min(len(ordem) - 1, int(pontos / PONTOS_MAX_BOT * len(ordem)))
    deck, progresso = [], {}
    for _ in range(max(0, int(qtd))):
        rar = ordem[rng.randint(max(0, teto_rar - 1), teto_rar)]
        livres = [x for x in (por_raridade.get(rar) or por_raridade["comum"]) if x not in deck] \
            or [x for x in PETS_DB if x not in deck]
        pid = rng.choice(livres)
        deck.append(pid)
        f = max(0.0, min(1.0, pontos / PONTOS_MAX_BOT))
        progresso[pid] = {"level": max(1, int(1 + f * 49)), "xp": 0,
                          "evolution": max(1, min(5, 1 + int(f * 4 + 1e-9)))}
    return deck, progresso


def _especialidades_e_chakra(p: dict, rng: random.Random, qtd: int = 3) -> None:
    import game.logic as L
    from game.specialties import SPECIALTIES_DB
    from game.chakras import roll_chakra
    for idx, sid in enumerate(rng.sample(list(SPECIALTIES_DB), k=min(max(0, int(qtd)), 3, len(SPECIALTIES_DB)))):
        L.equip_specialty(p, sid, idx)            # a mesma função do jogador (e o recalc dela)
    estado = random.getstate()
    random.seed(rng.random())                     # roll_chakra usa o random global
    p["chakra"] = roll_chakra()
    random.setstate(estado)


def _jogador_do_bot(i: int, rng: random.Random) -> dict:
    import game.logic as L
    pontos = _pontos_do_bot(i)
    nivel = _nivel_do_bot(pontos)
    andar = max(1, nivel // 2)                      # nível do jogador vai até 2× o andar
    p = L.ensure_player({"telegram_id": BOT_MIN + i, "username": NOMES_BOT[i % len(NOMES_BOT)],
                         "class_id": rng.choice(CLASSES), "race_id": rng.choice(RACAS)})
    p["level"] = nivel
    p["tower_floor"] = andar
    p["attrs"] = {"str": 1, "vit": 1, "agi": 1, "dex": 1}   # como o jogador: base 1 + trilhas
    kit = _quanto_do_kit(pontos)
    _gastar_trilhas(p, rng, kit["trilha_gasta"])
    _equipar_bot(p, andar, rng, kit["pecas"])
    _skills_do_bot(p, max(1, min(5, (andar - 1) // 20 + 1 + (1 if andar > 10 else 0))), rng)
    deck, progresso = _esquadrao(pontos, rng, kit["espiritos"])
    p["pets"] = {"owned": {k: 1 for k in deck}, "deck": (deck + [None] * 5)[:5], "progress": progresso}
    _especialidades_e_chakra(p, rng, kit["especialidades"])
    L.recalc(p)
    p["hp"] = p["hp_max"]
    return p


def garantir_bots_arena() -> int:
    from game.arena import build_snapshot_data
    with _conn() as c:
        tem = c.execute("SELECT COUNT(*) FROM arena_snapshots WHERE telegram_id BETWEEN ? AND ?"
                        " AND updated_at = ?", (BOT_MIN, BOT_MAX, BOTS_VERSAO)).fetchone()[0]
        if tem:
            return 0
        c.execute("DELETE FROM arena_snapshots WHERE telegram_id BETWEEN ? AND ?", (BOT_MIN, BOT_MAX))
        c.commit()
    rng = random.Random(4242)
    with _conn() as c:
        for i in range(QTD_BOTS):
            p = _jogador_do_bot(i, rng)
            d = build_snapshot_data(p)
            c.execute("""INSERT OR REPLACE INTO arena_snapshots (telegram_id, username, level, atk, def, hp_max,
                         crit, eva, acc, spd, triggers_json, skills_json, arena_points, wins, losses, updated_at)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,0,0,?)""",
                      (BOT_MIN + i, d.get("username") or p["username"], int(d.get("level", 1)),
                       int(d.get("atk", 5)), int(d.get("def", 0)), int(d.get("hp_max", 100)),
                       int(d.get("crit", 0)), int(d.get("eva", 0)), int(d.get("acc", 0)), int(d.get("spd", 20)),
                       json.dumps(d.get("triggers") or d.get("triggers_json") or {}) if not isinstance(d.get("triggers_json"), str) else d["triggers_json"],
                       json.dumps(d.get("skills") or []) if not isinstance(d.get("skills_json"), str) else d["skills_json"],
                       _pontos_do_bot(i), BOTS_VERSAO))
        c.commit()
    return QTD_BOTS


def garantir_bots_pets() -> int:
    from game.pets_db import build_pet_team
    with _conn() as c:
        tem = c.execute("SELECT COUNT(*) FROM pet_arena_snapshots WHERE telegram_id BETWEEN ? AND ?"
                        " AND updated_at = ?", (BOT_MIN, BOT_MAX, BOTS_VERSAO)).fetchone()[0]
        if tem:
            return 0
        c.execute("DELETE FROM pet_arena_snapshots WHERE telegram_id BETWEEN ? AND ?", (BOT_MIN, BOT_MAX))
        c.commit()
    rng = random.Random(7331)
    with _conn() as c:
        for i in range(QTD_BOTS):
            pontos = _pontos_do_bot(i)
            deck, progresso = _esquadrao(pontos, rng)
            p = {"pets": {"owned": {k: 1 for k in deck}, "deck": deck, "progress": progresso}}
            time_ = build_pet_team(p)
            c.execute("""INSERT OR REPLACE INTO pet_arena_snapshots (telegram_id, username, team_json,
                         arena_points, wins, losses, updated_at) VALUES (?,?,?,?,0,0,?)""",
                      (BOT_MIN + i, NOMES_BOT[(i + 7) % len(NOMES_BOT)], json.dumps(time_),
                       pontos, BOTS_VERSAO))
        c.commit()
    return QTD_BOTS


def sortear_oponente(tabela: str, telegram_id: int, meus_pontos: float) -> int | None:
    """Um adversário aleatório nos mesmos pontos (a janela abre até achar)."""
    assert tabela in ("arena_snapshots", "pet_arena_snapshots")
    with _conn() as c:
        for janela in JANELAS:
            linha = c.execute(f"SELECT telegram_id FROM {tabela} WHERE telegram_id != ?"
                              " AND arena_points BETWEEN ? AND ? ORDER BY RANDOM() LIMIT 1",
                              (int(telegram_id), meus_pontos - janela, meus_pontos + janela)).fetchone()
            if linha:
                return int(linha[0])
    return None
