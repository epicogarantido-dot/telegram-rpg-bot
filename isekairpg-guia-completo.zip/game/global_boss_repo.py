# game/global_boss_repo.py
"""
🐲 BOSS GLOBAL — repositório de dados.

Diferente da Raid (uma sala por grupo), o Boss Global é UM SÓ, compartilhado
por TODOS os jogadores do servidor ao mesmo tempo — todo mundo ataca o
mesmo bicho, e quando ele cai, os danos causados por cada um decidem a
fatia da recompensa.
"""
import json
import time

from game.sql_repo import get_connection

from infra.migracao import garantir_colunas, garantir_colunas_async

# 🧱 20/09/2026 — os CREATE deste arquivo viraram constantes pra que a
# MESMA string crie a tabela e migre banco velho (infra/migracao.py).
# Coluna nova entra aqui e chega sozinha em quem já tinha a tabela.
_SQL_GLOBAL_BOSS = """
            CREATE TABLE IF NOT EXISTS global_boss (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                data TEXT,
                updated_at INTEGER
            );
            """



def init_tables() -> None:
    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            _SQL_GLOBAL_BOSS
        )
        garantir_colunas(c, _SQL_GLOBAL_BOSS)  # 🧱 migra o que o CREATE tem e o disco não
        conn.commit()


init_tables()


def get_boss_state() -> dict | None:
    with get_connection() as conn:
        c = conn.cursor()
        c.execute("SELECT data FROM global_boss WHERE id = 1")
        row = c.fetchone()
        if not row or not row[0]:
            return None
        try:
            return json.loads(row[0])
        except Exception:
            return None


def save_boss_state(state: dict) -> None:
    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            """
            INSERT INTO global_boss (id, data, updated_at) VALUES (1, ?, ?)
            ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at
            """,
            (json.dumps(state), int(time.time())),
        )
        conn.commit()
