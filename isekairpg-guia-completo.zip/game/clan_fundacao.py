"""
Mito de fundação e humor do clã — as duas peças do Six Ages que faltavam.

MITO DE FUNDAÇÃO
----------------
No King of Dragon Pass / Six Ages o jogo começa com uma história curta do
clã, sem resposta certa: você está criando passado. E o passado volta —
"se você acolheu os pastores de cabras no mito de fundação, isso decide como
o clã vai se sentir sobre acolhê-los agora".

No motor de storylets isso é BARATO: cada escolha de fundação grava uma
flag e move umas qualidades. Depois é só escrever storylets que leem essas
flags. Efeito grande, custo quase zero — e é o que faz duas partidas
diferentes parecerem clãs diferentes em vez do mesmo clã com outro nome.

HUMOR DO CLÃ
------------
Uma qualidade global que muda QUAIS eventos aparecem. No Six Ages as
disputas internas saem mais quando o humor está baixo. Aqui é a mesma
ideia: humor entra nas condições dos storylets, então o saco muda sozinho
conforme o clã vai bem ou mal.

É a peça que faz o jogo "responder" sem precisar de evento novo: os mesmos
storylets passam a sair em ordem diferente porque o clã mudou.
"""
from __future__ import annotations

# Cada pergunta tem 3 respostas, nenhuma certa. O que muda é o que o clã
# passa a ser bom, e o que ele vai sentir depois.
PERGUNTAS = [
    {
        "id": "origem",
        "pergunta": "De onde veio o seu clã?",
        "lore": "Antes da Torre existir, seu povo já estava em algum lugar.",
        "opcoes": [
            {"id": "montanha", "label": "Das montanhas do norte",
             "gente": [{"funcao": "minerador", "min": 2, "quantos": 2}, {"funcao": "guarda", "min": 2, "quantos": 1}], "recursos": {"ferro": 10},
             "efeitos": {"autoridade": 2, "medo": 5},
             "flag": "origem_montanha",
             "depois": "Gente de montanha desconfia de quem chega fácil demais."},
            {"id": "planicie", "label": "Das planícies de pastoreio",
             "gente": [{"funcao": "agricultor", "min": 2, "quantos": 3}, {"funcao": "cacador", "min": 1, "quantos": 1}], "recursos": {},
             "efeitos": {"comida": 20, "moral": 5},
             "flag": "origem_planicie",
             "depois": "Quem viveu de rebanho sabe esperar a estação virar."},
            {"id": "exilio", "label": "De um exílio que ninguém conta",
             "gente": [{"funcao": "lenhador", "min": 1, "quantos": 1}, {"funcao": "cacador", "min": 2, "quantos": 1}, {"funcao": "minerador", "min": 1, "quantos": 1}], "recursos": {"couro": 10},
             "efeitos": {"astucia": 3, "moral": -5, "informacao": 8},
             "flag": "origem_exilio",
             "depois": "Clã de exilados acolhe outros exilados — e desconfia de reis."},
        ],
    },
    {
        "id": "primeira_prova",
        "pergunta": "Qual foi a primeira prova que vocês passaram?",
        "lore": "Todo clã tem uma noite que os mais velhos ainda contam.",
        "opcoes": [
            {"id": "fome", "label": "Um inverno de fome",
             "gente": [{"funcao": "agricultor", "min": 3, "quantos": 1}], "recursos": {},
             "efeitos": {"lealdade": 3, "comida": -10},
             "flag": "prova_fome",
             "depois": "Ninguém deste clã joga comida fora. Nem em ano bom."},
            {"id": "guerra", "label": "Uma guerra que vocês não começaram",
             "gente": [{"funcao": "guarda", "min": 2, "quantos": 2}], "recursos": {"ferro": 10},
             "efeitos": {"autoridade": 3, "medo": 10},
             "flag": "prova_guerra",
             "depois": "O clã responde rápido demais a ameaça — às vezes rápido demais."},
            {"id": "traicao", "label": "Uma traição de dentro de casa",
             "gente": [{"funcao": "guarda", "min": 3, "quantos": 1}], "recursos": {},
             "efeitos": {"astucia": 2, "lealdade": -2, "medo": 5},
             "flag": "prova_traicao",
             "depois": "Vocês olham duas vezes pra quem fala bonito."},
        ],
    },
    {
        "id": "acolhida",
        "pergunta": "Quando os pastores sem terra pediram abrigo, o que vocês fizeram?",
        "lore": "A resposta de então é a resposta que o clã espera de você agora.",
        "opcoes": [
            {"id": "acolheu", "label": "Abrimos os portões",
             "gente": [{"funcao": "agricultor", "min": 1, "quantos": 2}, {"funcao": "cacador", "min": 1, "quantos": 1}], "recursos": {},
             "efeitos": {"moral": 10, "comida": -15},
             "flag": "fundacao_acolhedor",
             "depois": "O clã espera que você acolha. Recusar vai custar moral."},
            {"id": "negociou", "label": "Cobramos um preço",
             "gente": [{"funcao": "lenhador", "min": 2, "quantos": 1}], "recursos": {"madeira": 20},
             # 🥇 20/09/2026: era "bronze" (a moeda do clã, que não existe
             # mais). Vira "ouro" — a qualidade de storylet lê de
             # `p["gold"]`, então este efeito soma na CONTA NARRATIVA, não
             # no ouro de verdade do personagem (ver `_aplicar_efeitos`
             # em storylets.py: qualidade é abstrata, não é `p["gold"]`).
             # 🪙 (20/09) decisão do clã não dá mais ouro: couro (40 ouro ≈ 13 couro)
             "efeitos": {"astucia": 3, "couro": 13},
             "flag": "fundacao_mercador",
             "depois": "Tudo tem preço aqui, e ninguém acha isso estranho."},
            {"id": "recusou", "label": "Mandamos seguir viagem",
             "gente": [], "recursos": {"madeira": 10},
             "efeitos": {"medo": 10, "comida": 10, "moral": -5},
             "flag": "fundacao_fechado",
             "depois": "O clã não espera generosidade sua. Ter, agora, surpreende."},
        ],
    },
]


def aplicar_fundacao(p: dict, respostas: dict) -> dict:
    """Grava as escolhas de fundação no estado de storylets.

    As flags são o ponto: elas ficam pra sempre e os storylets futuros as
    leem. Sem elas isso seria só um bônus de começo com texto bonito.
    """
    from game.storylets import _estado, _aplicar_efeitos

    st = _estado(p)
    escolhidas = []
    # Soma dos efeitos de recurso (ouro, comida) pra quem chama levar ao jogo
    # de verdade — sozinhos, eles só mexiam na qualidade abstrata.
    recursos = {"ouro": 0, "comida": 0, "couro": 0}
    # 👥 20/09 (fase 4): as respostas decidem QUEM VEM no clã inicial e com
    # que talento, e um pouco de madeira/couro/ferro. Todo clã ganha ainda o
    # velho que vigia o portão (um guarda 1★): sem guarda nenhuma equipe sai.
    gente = [{"funcao": "guarda", "min": 1, "quantos": 1, "nome_extra": "o velho do portão"}]
    extras = {"madeira": 20, "couro": 10, "ferro": 10}
    for q in PERGUNTAS:
        escolha = respostas.get(q["id"])
        op = next((o for o in q["opcoes"] if o["id"] == escolha), None)
        if not op:
            continue
        _aplicar_efeitos(p, dict(op["efeitos"], flag=op["flag"]))
        for chave in recursos:
            recursos[chave] += int(op["efeitos"].get(chave, 0) or 0)
        gente.extend(op.get("gente") or [])
        for chave, qtd in (op.get("recursos") or {}).items():
            extras[chave] = extras.get(chave, 0) + int(qtd)
        escolhidas.append({"pergunta": q["pergunta"], "resposta": op["label"],
                           "depois": op["depois"], "flag": op["flag"]})
    st["flags"].append("fundacao_feita")
    st.setdefault("qualidades", {})["humor"] = 50
    return {"escolhas": escolhidas, "recursos": recursos, "gente": gente, "extras": extras}


def fundacao_feita(p: dict) -> bool:
    from game.storylets import _estado
    return "fundacao_feita" in _estado(p)["flags"]


# ------------------------------------------------------------------ humor

# Faixas do humor. O nome importa mais que o número: "o clã está inquieto"
# diz o que está acontecendo; "humor 34" não diz nada.
FAIXAS_HUMOR = [
    (0,  20, "à beira do motim", "As disputas internas dominam. Quase nada mais acontece."),
    (20, 40, "inquieto",         "Brigas e queixas aparecem com frequência."),
    (40, 60, "resignado",        "O clã toca a vida."),
    (60, 80, "confiante",        "As pessoas se oferecem antes de serem chamadas."),
    (80, 101, "em festa",        "Ninguém reclama de nada, e isso também é um aviso."),
]


def humor(p: dict) -> int:
    from game.storylets import _estado
    return int(_estado(p)["qualidades"].get("humor", 50))


def descrever_humor(valor: int) -> dict:
    for menor, maior, nome, texto in FAIXAS_HUMOR:
        if menor <= valor < maior:
            return {"valor": valor, "nome": nome, "texto": texto}
    return {"valor": valor, "nome": "resignado", "texto": ""}


def mexer_humor(p: dict, delta: int) -> int:
    """Humor é limitado nos dois extremos.

    Sem teto, o clã em festa fica em festa pra sempre e o humor para de
    significar alguma coisa. Sem piso, uma sequência ruim vira espiral sem
    volta — e espiral sem volta faz largar o jogo.
    """
    from game.storylets import _estado
    st = _estado(p)
    novo = max(0, min(100, humor(p) + int(delta)))
    st["qualidades"]["humor"] = novo
    return novo
