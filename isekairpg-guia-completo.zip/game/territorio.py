# game/territorio.py
"""
🗺️ MAPA DO TERRITÓRIO (20/09/2026)

O QUE É
-------
Um mapa COMPARTILHADO por todos os jogadores: 6 tipos de área com 10
pontos cada (60 pontos disputados) e mais 10 locais seguros. Cada ponto
disputado tem um dono — um clã de bot, outro jogador, ou ninguém — e pode
ser tomado. É o "Ocupação de Recursos" e a "Defesa dos Pontos" do
documento do clã.

AS TRÊS REGRAS PEDIDAS
----------------------
1. **Um ponto por vez.** Cada clã ocupa UM lugar do mapa. Tomar outro
   larga o anterior (que fica sem dono, esperando quem chegue primeiro).
   Isso é o que transforma o mapa em escolha: a Mina rica ou a Floresta
   segura, não as duas.
2. **Locais seguros.** Ninguém ataca e ninguém toma. Rendem pouco, mas
   rendem sempre — é o refúgio de quem perdeu o ponto, ou de quem ainda
   não tem força pra disputar. Vários clãs podem dividir o mesmo refúgio.
3. **Qualquer ponto disputado pode ser tomado** — por outro jogador (a
   força do clã dele contra a sua, medida na hora) ou pelos clãs de bot,
   que atacam os pontos dos jogadores entre uma sessão e outra.

A PERDA É GRADUAL
-----------------
O documento pede que não exista "você perdeu tudo" de uma vez. Todo ponto
tem INTEGRIDADE (0 a 100): cada ataque de bot que passa pela sua força
tira um pedaço, e a produção cai junto — 100% é produção cheia, 50% é
metade. Só em 0 o ponto é perdido. Entre ataques, ele se recupera. Você
vê chegando e tem sessões pra reagir (reforçar o clã, ou largar antes).

REGRA DESTE ARQUIVO
-------------------
Cálculo puro, sem banco — como `clan_habitantes.py`. Quem grava é
`clan_repo`. É o que deixa `testes/auditar_territorio.py` medir o mapa
inteiro em simulação.
"""
from __future__ import annotations

import random

# 📈 20/09/2026 (regra do dev) — PONTO DO MAPA DÁ BÔNUS, NÃO PRODUZ.
# "Os pontos do mapa dão um bônus de 100 a 150% de rendimento. Um clã que
# não domina um ponto ainda pega madeira e comida, só que menos."
# Então o ponto não fabrica recurso do nada: ele MULTIPLICA o que o clã já
# tira dos postos (e a aldeia produz) — +100% no tier 1 até +150% no tier
# 10, vezes a integridade. `bonus` diz em quê. O recurso de verdade vem de
# trabalho (postos, aldeia, monstros); o mapa é o que faz esse trabalho
# render o dobro — por isso vale a disputa.
TIPOS = {
    "mina":     {"nome": "Mina", "icone": "⛏️", "bonus": ["material"]},
    "floresta": {"nome": "Floresta", "icone": "🌲", "bonus": ["madeira"]},
    # 🪙 20/09 (dev): ouro só do reino — Cristais, Ruínas e Covil passaram a
    # multiplicar MATERIAL (antes multiplicavam o ouro do clã, que acabou)
    "cristais": {"nome": "Cristais", "icone": "💎", "bonus": ["material"]},
    "caca":     {"nome": "Área de Caça", "icone": "🦌", "bonus": ["couro", "comida"]},
    "ruinas":   {"nome": "Ruínas", "icone": "🏛️", "bonus": ["material", "couro"]},
    "nascente": {"nome": "Nascente", "icone": "💧", "bonus": ["comida"]},
    # 👹 Covil do Chefe: um por andar de chefe. O bônus é de tudo que vem de
    # material — e é o ponto mais guardado e mais atacado do mapa.
    "covil":    {"nome": "Covil do Chefe", "icone": "👹", "bonus": ["material"],
                 "mult_guarda": 1.5, "pressao_extra": 0.10, "so_chefe": True},
    # 🔮 (dev, 20/09): um ponto que DÁ CORES — direto pro inventário do
    # personagem, do tier do andar. Só guardas ficam nele (sem coletores).
    "cores":    {"nome": "Veio de Cores", "icone": "🔮", "bonus": [], "so_guardas": True,
                 "cores_por_sessao": 2},
}
# Refúgio não dá bônus: é abrigo (ninguém ataca), não fonte.
SEGURO = {"nome": "Local Seguro", "icone": "🏕️", "bonus": []}
BONUS_MIN, BONUS_MAX = 1.0, 1.5      # +100% no tier 1 … +150% no tier 10
PONTOS_POR_TIPO = 10
LOCAIS_SEGUROS = 10

# Nomes: dez por tipo, na ordem do tier (o 1º é o mais raso e mais fraco).
NOMES = {
    "mina": ["do Eco", "da Pedra Rachada", "Funda", "do Ferro Velho", "das Lanternas",
             "do Carvão Negro", "Esquecida", "do Veio Rubro", "dos Anões Mudos", "do Coração"],
    "floresta": ["dos Galhos Baixos", "do Musgo", "Sussurrante", "dos Cipós", "Enevoada",
                 "das Raízes Altas", "Sombria", "dos Ecos Verdes", "Antiga", "do Carvalho Rei"],
    "cristais": ["Opacos", "do Riacho", "Azuis", "Partidos", "Cantantes",
                 "da Caverna Fria", "Violeta", "do Abismo Raso", "Estelares", "da Aura Viva"],
    "caca": ["da Lebre", "do Cervo", "da Trilha Seca", "dos Javalis", "das Pegadas",
             "do Uivo", "dos Chifres", "da Garra", "das Feras", "do Grande Alce"],
    "ruinas": ["do Portão", "da Capela", "da Muralha Caída", "do Mercado", "da Biblioteca",
               "do Observatório", "da Cripta", "do Palácio", "da Torre Menor", "do Primeiro Rei"],
    "nascente": ["Clara", "do Vale", "Morna", "das Pedras", "Escondida",
                 "da Cascata", "Salgada", "do Lago Parado", "Termal", "da Vida"],
    "covil": [f"do Andar {5 * t}" for t in range(1, 11)],
}
NOMES_SEGUROS = ["Clareira do Abrigo", "Gruta Quieta", "Acampamento do Viajante",
                 "Ponte Velha", "Pousada Abandonada", "Vale Calmo", "Colina do Vigia",
                 "Bosque Manso", "Fonte dos Peregrinos", "Pátio do Silêncio"]

# Clãs de bot. Ocupam o mapa no começo (decisão já tomada no CONTEXTO: "Clãs
# de NPC ocupam o mapa no começo; PvP por território é escalada").
BOTS = [
    {"id": "corvo", "nome": "Clã do Corvo Cinzento", "icone": "🐦"},
    {"id": "presa", "nome": "Presas de Ferro", "icone": "🐺"},
    {"id": "musgo", "nome": "Povo do Musgo", "icone": "🍄"},
    {"id": "brasa", "nome": "Irmandade da Brasa", "icone": "🔥"},
    {"id": "sal", "nome": "Guardiões do Sal", "icone": "🧂"},
    {"id": "osso", "nome": "Tribo do Osso Branco", "icone": "💀"},
    {"id": "nevoa", "nome": "Filhos da Névoa", "icone": "🌫️"},
    {"id": "raiz", "nome": "Clã da Raiz Funda", "icone": "🌳"},
]
FRACAO_DOS_BOTS = 0.75       # 3 em cada 4 pontos começam com dono bot

ANDAR_POR_TIER = 5           # tier 1 = andar 5 ... tier 10 = andar 50


ANDARES_DO_MAPA = 50
PONTOS_POR_TIPO_POR_ANDAR = 3      # (dev, 20/09) 3 de cada tipo em CADA andar
ROMANOS = ("I", "II", "III", "IV", "V")


def tier_do_andar(andar: int) -> int:
    """Força e bônus seguem de 5 em 5 andares (tier 1 = andares 1–5 ... 10 = 46–50)."""
    return max(1, min(10, (int(andar) + 4) // 5))


def andar_do_ponto(ponto) -> int:
    """O andar do ponto. Desde 20/09 o ponto GUARDA o próprio andar (3 de
    cada tipo em todo andar); o cálculo pelo tier fica só pra ponto velho."""
    if isinstance(ponto, dict):
        if ponto.get("andar"):
            return int(ponto["andar"])
        return int(ponto.get("tier") or 1) * ANDAR_POR_TIER
    return int(ponto) * ANDAR_POR_TIER


def _andar_do_ponto_legado(tier: int) -> int:
    """Todo ponto do mapa fica num andar de CHEFE (5, 10, ..., 50).
    ⚔️ 20/09/2026 (regra do dev): o clã só toma e segura pontos do andar
    onde ESTÁ — e só andar de chefe tem ponto, então é lá que a disputa
    acontece (casa com o material de rank alto, que também só sai lá)."""
    return int(tier) * ANDAR_POR_TIER

# ─────────────────────────────────────────────────────── força e defesa ──
#
# Guarnição do bot no tier t.
#
# Medido contra a força de um clã comum (5 lutadores Nv.10 + aldeia
# pequena ≈ 75). A primeira curva era linear (12 + 9t) e dava a esse clã
# 35% de chance no tier 10: o topo do mapa ficava a três tentativas de
# distância, e não havia pra onde crescer. A curva quadrática abaixo dá
# ~93% no tier 1, ~55% no 5 e ~15% no 10 — o fundo do mapa passa a pedir
# um clã de verdade, e o raso continua acessível pra quem está começando.
def guarnicao_bot(tier: int) -> int:
    t = int(tier)
    return int(9 + 6.5 * t + t * t)


def forca_do_cla(membros: list, defesa_aldeia: int) -> int:
    """Força com que um clã toma e segura um ponto: os lutadores (o nível
    de cada um) mais a defesa da própria aldeia (guardas, aura, estágio).
    Morto e ausente não contam — o mapa não pode ser tomado com gente que
    não existe."""
    lutadores = sum(3 + int(m.get("nivel") or 1) for m in membros if int(m.get("vivo", 1)))
    return max(1, lutadores + int(defesa_aldeia))


def chance_de_vencer(forca: int, defesa: int) -> float:
    """Quadrática, não linear: forças iguais dão 50%, o dobro dá 80%, a
    metade dá 20%. Linear (f/(f+d)) deixaria 33% de chance pra quem tem
    metade da força — o bastante pra virar loteria de insistir."""
    f, d = max(1, int(forca)), max(1, int(defesa))
    return (f * f) / (f * f + d * d)


def custo_de_ataque(tier: int) -> int:
    """Comida pra marchar. A tropa come no caminho — e é o que impede
    tentar de novo e de novo até a sorte vir."""
    return 8 + 2 * int(tier)


# ──────────────────────────────────────────────────────────────── bônus ──
def fracao_de_bonus(tier: int) -> float:
    """+100% no tier 1 até +150% no tier 10 (linear)."""
    t = max(1, min(10, int(tier)))
    return BONUS_MIN + (BONUS_MAX - BONUS_MIN) * (t - 1) / 9


def bonus_do_ponto(ponto: dict) -> dict:
    """{recurso: fração extra} que o ponto dá ao que o clã tira. Integridade
    pesa: ponto em 50% dá metade do bônus."""
    if ponto.get("seguro"):
        return {}
    info = TIPOS.get(ponto.get("tipo"), {})
    fr = fracao_de_bonus(ponto.get("tier", 1)) * max(0, int(ponto.get("integridade", 100))) / 100
    return {recurso: round(fr, 3) for recurso in info.get("bonus", [])}


# ───────────────────────────────────────────────── ataques entre sessões ──
CHANCE_ATAQUE_BOT = 0.25          # + 2% por tier
DANO_INTEGRIDADE = (25, 45)
RECUPERACAO_POR_SESSAO = 10
LIMIAR_AMEACADO = 50


def estado_do_ponto(integridade: int) -> str:
    """As etapas do documento: operação normal → ameaçada → perdido."""
    if integridade <= 0:
        return "perdido"
    if integridade < LIMIAR_AMEACADO:
        return "ameaçado"
    if integridade < 100:
        return "sob pressão"
    return "seguro"


def pressao_dos_bots(ponto: dict, forca: int, fracao_sessao: float,
                     rng: random.Random) -> dict:
    """Uma sessão de pressão dos bots sobre o ponto de um JOGADOR. Muta a
    integridade e devolve o que aconteceu, pro diário.

    Local seguro nunca é atacado. Ponto de bot não sofre (bot não ataca bot).
    """
    if ponto.get("seguro") or ponto.get("dono_tipo") != "jogador":
        return {"atacado": False}
    tier = int(ponto["tier"])
    extra = TIPOS.get(ponto.get("tipo"), {}).get("pressao_extra", 0.0)
    chance = min(0.9, (CHANCE_ATAQUE_BOT + extra + 0.02 * tier) * float(fracao_sessao))
    if rng.random() >= chance:
        ponto["integridade"] = min(100, int(ponto.get("integridade", 100))
                                   + int(RECUPERACAO_POR_SESSAO * float(fracao_sessao)))
        return {"atacado": False}
    atacante = rng.choice(BOTS)
    poder = int(guarnicao_bot(tier) * TIPOS.get(ponto.get("tipo"), {}).get("mult_guarda", 1.0)
                * rng.uniform(0.6, 1.25))
    if forca >= poder:
        return {"atacado": True, "repelido": True, "bot": atacante["nome"], "poder": poder}
    dano = rng.randint(*DANO_INTEGRIDADE)
    ponto["integridade"] = max(0, int(ponto.get("integridade", 100)) - dano)
    return {"atacado": True, "repelido": False, "bot": atacante["nome"], "bot_id": atacante["id"],
            "poder": poder, "dano": dano, "estado": estado_do_ponto(ponto["integridade"])}


# ──────────────────────────────────────────────────────────── o mapa ──
def gerar_mapa(semente: int = 20260920) -> list[dict]:
    """O mapa inicial, IGUAL pra todo mundo (semente fixa).

    (dev, 20/09) 3 pontos de cada tipo em CADA andar, do 1 ao 50 — o clã
    sempre tem o que disputar onde estiver. O Covil do Chefe é diferente:
    só nos andares de chefe (5, 10 ... 50), 3 em cada, porque é lá que sai o
    material de chefe. Um refúgio por andar. A força (guarnição dos bots) e
    o bônus seguem o tier do andar (de 5 em 5)."""
    rng = random.Random(semente)
    pontos = []
    for andar in range(1, ANDARES_DO_MAPA + 1):
        tier = tier_do_andar(andar)
        for tipo, info in TIPOS.items():
            if info.get("so_chefe") and andar % 5:
                continue
            for i in range(PONTOS_POR_TIPO_POR_ANDAR):
                dono = rng.choice(BOTS) if rng.random() < FRACAO_DOS_BOTS else None
                pontos.append({
                    "tipo": tipo, "seguro": 0, "tier": tier, "andar": andar,
                    "nome": f"{info['nome']} {ROMANOS[i]} · Andar {andar}",
                    "dono_tipo": "bot" if dono else None,
                    "dono_id": dono["id"] if dono else None,
                    "dono_nome": dono["nome"] if dono else None,
                    "guarnicao": int(guarnicao_bot(tier) * info.get("mult_guarda", 1.0))
                                 // (1 if dono else 3),
                    "integridade": 100,
                })
        pontos.append({"tipo": "seguro", "seguro": 1, "tier": tier, "andar": andar,
                       "nome": f"{NOMES_SEGUROS[andar % len(NOMES_SEGUROS)]} · Andar {andar}",
                       "dono_tipo": None, "dono_id": None, "dono_nome": None,
                       "guarnicao": 0, "integridade": 100})
    return pontos


def cores_do_ponto(ponto: dict, fracao_sessao: float, rng: random.Random) -> list:
    """🔮 As cores que um Veio de Cores rende numa sessão: bases de forja, no
    tier do ANDAR (o mesmo da Torre: 1 a cada 10 andares)."""
    info = TIPOS.get(ponto.get("tipo"), {})
    if not info.get("cores_por_sessao"):
        return []
    from game.items import REQ_CRAFT
    bases = sorted({b for req in REQ_CRAFT.values() for b in req})
    qtd = info["cores_por_sessao"] * float(fracao_sessao) * max(0, int(ponto.get("integridade", 100))) / 100
    n = int(qtd) + (1 if rng.random() < qtd - int(qtd) else 0)
    tier = (andar_do_ponto(ponto) - 1) // 10 + 1
    return [f"{rng.choice(bases)}_t{tier}" for _ in range(n)]


def defesa_do_ponto(ponto: dict, forca_do_dono_jogador: int | None = None) -> int:
    """Quanto é preciso vencer pra tomar o ponto. Dono jogador defende com
    a força ATUAL do clã dele (medida na hora, não a da conquista) — senão
    um clã que cresceu seria defendido pelo tamanho que tinha na semana
    passada."""
    if ponto.get("seguro"):
        return 0
    if ponto.get("dono_tipo") == "jogador" and forca_do_dono_jogador is not None:
        return max(1, int(forca_do_dono_jogador * max(20, int(ponto.get("integridade", 100))) / 100))
    return max(1, int(ponto.get("guarnicao") or guarnicao_bot(int(ponto["tier"])) // 3))
