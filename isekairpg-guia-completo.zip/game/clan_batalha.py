# game/clan_batalha.py
"""
⚔️ BATALHA PELO PONTO (20/09/2026 — fase 3 do redesenho do dev)

Quando um clã ataca um ponto que OUTRO JOGADOR domina, não é mais a "força
do clã" contra a "defesa do ponto": é o PODER MILITAR de um contra o do
outro — os guardas da equipe que marchou contra os guardas da equipe que
segura o ponto (mais o personagem do defensor, se ele estiver de guarda).

AS REGRAS (as do dev)
---------------------
- O defensor deixa configurado: FUGIR (a equipe dele volta pra casa inteira
  e o ponto fica com quem atacou — ninguém morre) ou LUTAR.
- Lutando, QUEM VENCE ROUBA OS COLETORES da equipe do outro e os GUARDAS de
  quem perdeu MORREM. Vale nos dois sentidos: atacar e perder custa os
  próprios guardas e entrega os próprios coletores ao defensor.
- A chance é a mesma do resto do mapa (`territorio.chance_de_vencer`):
  poder² / (poder² + poder²), então o mais forte vence quase sempre, mas não
  sempre.

Puro: `clan_repo.batalha_pelo_ponto` cobra as consequências no banco.
"""
from __future__ import annotations

import random

DEFESAS = {"lutar": "⚔️ Lutar quando atacado", "fugir": "🏃 Fugir quando atacado (ninguém morre)"}


def poder_do_personagem(nivel: int) -> int:
    """O personagem do jogador de guarda vale como um guarda 3★ do mesmo
    nível — forte, mas não tanto que um só dispense a equipe."""
    from game.clan_equipes import mult_estrelas
    return int((10 + 3 * max(1, int(nivel))) * mult_estrelas(3))


def poder_da_escolta(guardas: list, extra: int = 0) -> int:
    from game.clan_equipes import poder_do_guarda
    return sum(poder_do_guarda(g) for g in guardas) + int(extra)


def resolver(poder_ataque: int, poder_defesa: int, defesa: str, rng: random.Random) -> dict:
    """Quem ficou com o ponto e quem perdeu gente."""
    from game.territorio import chance_de_vencer
    if defesa == "fugir":
        return {"resultado": "fuga", "chance": 1.0, "ataque": poder_ataque, "defesa": poder_defesa}
    chance = chance_de_vencer(max(1, int(poder_ataque)), max(1, int(poder_defesa)))
    venceu = rng.random() < chance
    return {"resultado": "ataque" if venceu else "defesa", "chance": round(chance, 3),
            "ataque": poder_ataque, "defesa": poder_defesa}
