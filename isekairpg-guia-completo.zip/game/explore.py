# game/explore.py
"""
🌍 EXPLORAR MUNDO — sistema novo e isolado (08/07/2026).

Lore: a cidade abre os portões pro mundo exterior. Uma vez lá fora, não
existe fuga — é preciso completar 7 explorações antes de poder voltar.

Cada exploração sorteia um evento:
- 80% Batalha normal (andar aleatório de 1 a 20, reaproveita o motor da Torre)
- 10% Chefe (sorteia entre os bosses dos andares 5, 10, 15, 20)
-  5% Muito ouro (+5.000g na hora, sem luta)
-  3% Skill rara (dropa 1 core de skill até raridade "raro")
-  1% Pet raro (ganha 1 pet até raridade "raro")
-  1% Montaria rara (ganha 1 montaria até raridade "raro")
"""
import random

TOTAL_EXPLORACOES = 7
OURO_RECOMPENSA = 5000
MAX_RARIDADE_DROP = 3  # 1=comum .. 5=lendário — capa em "raro" pra skill/pet/montaria
TIER_SIZE = 20  # cada tier cobre 20 andares (1-20, 21-40, 41-60, 61-80, 81-100)


def get_tier_range(tower_floor: int) -> tuple[int, int]:
    """Filtra a área de exploração pelo andar real do jogador na Torre.
    Ex: andar 21 → já cai na área do Tier 2 (andares 21-40)."""
    tower_floor = max(1, int(tower_floor))
    tier = min(5, ((tower_floor - 1) // TIER_SIZE) + 1)
    inicio = (tier - 1) * TIER_SIZE + 1
    fim = tier * TIER_SIZE
    return inicio, fim


def iniciar_expedicao(p: dict) -> str:
    """Abre os portões — a partir de agora, sem fuga até completar as 7."""
    p["explore_state"] = {"day": 0, "active": True}
    inicio, fim = get_tier_range(p.get("tower_floor", 1))
    tier_num = (inicio - 1) // TIER_SIZE + 1
    return (
        "🌍 <b>OS PORTÕES SE ABREM...</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "A cidade libera seus aventureiros pro mundo exterior — algo que só "
        "acontece a cada 7 dias.\n\n"
        f"🗺️ Pela sua força atual, você entra na área do <b>Tier {tier_num}</b> "
        f"(andares {inicio}-{fim}).\n\n"
        "A partir de agora, <b>não existe fuga</b>. Você precisa sobreviver a "
        f"{TOTAL_EXPLORACOES} explorações antes que os portões se abram de novo "
        "e você possa voltar.\n\n"
        "Boa sorte lá fora."
    )


def rolar_evento(p: dict) -> dict:
    """Sorteia o que acontece numa exploração, respeitando a área (tier)
    que corresponde ao andar atual do jogador na Torre."""
    inicio, fim = get_tier_range(p.get("tower_floor", 1))
    boss_andares = [inicio + 4, inicio + 9, inicio + 14, inicio + 19]

    roll = random.uniform(0, 100)
    # 🔥 (09/07/2026): chance de pet subiu de 1% pra 10% — alimenta a
    # Evolução e o Nível dos pets, que consomem cópias como material.
    # Os 9pp extras saem da fatia de "batalha simples" (71% em vez de
    # 80%): combate já sobra em Torre/Raid/Onda, não precisa duplicar
    # aqui também.
    if roll < 71:
        return {"tipo": "batalha", "andar": random.randint(inicio, fim)}
    elif roll < 81:
        return {"tipo": "boss", "andar": random.choice(boss_andares)}
    elif roll < 86:
        return {"tipo": "ouro", "quantidade": OURO_RECOMPENSA}
    elif roll < 89:
        return {"tipo": "skill"}
    elif roll < 99:
        return {"tipo": "pet"}
    else:
        return {"tipo": "montaria"}


def _sortear_skill_core(max_raridade: int = MAX_RARIDADE_DROP) -> str | None:
    from game.skills import SKILL_DB
    candidatos = [
        cid for cid, data in SKILL_DB.items()
        if int(data.get("skill", {}).get("rarity", 1)) <= max_raridade
    ]
    return random.choice(candidatos) if candidatos else None


# 🔥 (09/07/2026): pesos REAIS de raridade no drop de pet do Explorar
# Mundo. Antes, _sortear_pet fazia random.choice() uniforme entre TODOS os
# pets permitidos — a "distribuição por raridade" era um acidente que
# dependia de quantos pets cada raridade tinha cadastrado no PETS_DB, não
# um número desenhado. Agora sorteia a raridade primeiro (com peso), e só
# depois escolhe um pet dentro dela.
PET_DROP_RARITY_WEIGHTS = {"comum": 60, "incomum": 30, "raro": 10}


def _sortear_pet(max_raridade_nome: str = "raro") -> str | None:
    from game.pets_db import PETS_DB, RARITY_ORDER
    limite = RARITY_ORDER.index(max_raridade_nome)
    raridades_disponiveis = RARITY_ORDER[:limite + 1]

    pesos = {r: PET_DROP_RARITY_WEIGHTS.get(r, 0) for r in raridades_disponiveis}
    total_peso = sum(pesos.values())
    if total_peso <= 0:
        return None

    roll = random.uniform(0, total_peso)
    acumulado = 0.0
    raridade_sorteada = raridades_disponiveis[0]
    for r in raridades_disponiveis:
        acumulado += pesos[r]
        if roll <= acumulado:
            raridade_sorteada = r
            break

    candidatos = [pid for pid, data in PETS_DB.items() if data.get("rarity") == raridade_sorteada]
    return random.choice(candidatos) if candidatos else None


def _sortear_montaria(max_raridade_nome: str = "raro") -> str | None:
    from game.mounts import MOUNTS_DB, RARITY_ORDER
    limite = RARITY_ORDER.index(max_raridade_nome)
    candidatos = [
        mid for mid, data in MOUNTS_DB.items()
        if data.get("rarity") in RARITY_ORDER[:limite + 1]
    ]
    return random.choice(candidatos) if candidatos else None


def resolver_evento_instantaneo(p: dict, evento: dict, detalhe: dict | None = None) -> str:
    """Resolve eventos que NÃO precisam de batalha (ouro/skill/pet/montaria).
    Eventos de batalha/boss são tratados à parte, no router (usam o motor
    de combate de verdade).

    `detalhe` é opcional e é preenchido com o DROP em forma de dado — tipo,
    id, nome e quantidade. O texto continua sendo o retorno porque o bot de
    chat só sabe mandar texto; o site usa o detalhe pra mostrar só o que
    caiu, sem a narração em volta. Quem não passa `detalhe` não muda em nada.
    """
    tipo = evento["tipo"]

    def anotar(**campos):
        if detalhe is not None:
            detalhe.update(campos)

    if tipo == "ouro":
        p["gold"] = int(p.get("gold", 0)) + OURO_RECOMPENSA
        anotar(tipo="ouro", nome="Ouro", quantidade=OURO_RECOMPENSA, icone="💰")
        return f"💰 <b>Uma carroça abandonada!</b>\nVocê encontrou {OURO_RECOMPENSA}g."

    if tipo == "skill":
        core_id = _sortear_skill_core()
        if not core_id:
            return "🌫️ Você vasculhou a área, mas não achou nada de interessante."
        cores = p.setdefault("inv", {}).setdefault("cores", {})
        cores[core_id] = cores.get(core_id, 0) + 1
        from game.skills import SKILL_DB
        nome = SKILL_DB.get(core_id, {}).get("name", core_id)
        anotar(tipo="skill", id=core_id, nome=nome, quantidade=1, icone="🔮",
               raridade=SKILL_DB.get(core_id, {}).get("rarity"))
        return f"🔮 <b>Relíquia encontrada!</b>\nVocê achou 1x {nome} — vá aprendê-la nas Skills."

    if tipo == "pet":
        pet_id = _sortear_pet()
        if not pet_id:
            return "🌫️ Você ouviu um rugido ao longe, mas não achou nada."
        owned = p.setdefault("pets", {}).setdefault("owned", {})
        owned[pet_id] = owned.get(pet_id, 0) + 1
        from game.pets_db import PETS_DB
        nome = PETS_DB.get(pet_id, {}).get("name", pet_id)
        anotar(tipo="pet", id=pet_id, nome=nome, quantidade=1, icone="🐾",
               raridade=PETS_DB.get(pet_id, {}).get("rarity"),
               img_key=f"PET_{pet_id.upper()}")
        return f"🐉 <b>Um espírito selvagem se juntou a você!</b>\nVocê ganhou 1x {nome}."

    if tipo == "montaria":
        mount_id = _sortear_montaria()
        if not mount_id:
            return "🌫️ Você viu pegadas estranhas na terra, mas nada mais."
        owned = p.setdefault("mounts_owned", {})
        owned[mount_id] = owned.get(mount_id, 0) + 1
        from game.mounts import MOUNTS_DB
        nome = MOUNTS_DB.get(mount_id, {}).get("name", mount_id)
        anotar(tipo="montaria", id=mount_id, nome=nome, quantidade=1, icone="🐴",
               raridade=MOUNTS_DB.get(mount_id, {}).get("rarity"),
               img_key=f"MOUNT_{mount_id.upper()}")
        return f"🐴 <b>Uma montaria selvagem se deixou domar!</b>\nVocê ganhou 1x {nome}."

    return "🌫️ Nada de interessante aconteceu."


def avancar_dia(p: dict) -> bool:
    """Soma 1 exploração completada. Retorna True se já pode voltar pra cidade."""
    st = p.setdefault("explore_state", {"day": 0, "active": True})
    st["day"] = int(st.get("day", 0)) + 1
    if st["day"] >= TOTAL_EXPLORACOES:
        st["active"] = False
        return True
    return False


def perder_item_aleatorio(p: dict) -> str:
    """Penalidade de morte no Mundo Exterior: perde 1 item equipado
    aleatório. Reflete o risco de ter tanto recurso bom disponível aqui."""
    equip = p.get("equip", {})
    slots_com_item = [slot for slot, item in equip.items() if item]
    if not slots_com_item:
        return "😮‍💨 Ao menos você não tinha nada equipado pra perder."

    slot_perdido = random.choice(slots_com_item)
    item_perdido = equip[slot_perdido]
    nome_item = item_perdido.get("name", "um item") if isinstance(item_perdido, dict) else "um item"
    equip[slot_perdido] = None
    return f"💔 Na queda, o Mundo Exterior tomou de você: <b>{nome_item}</b> ({slot_perdido})!"


def finalizar_expedicao(p: dict) -> str:
    """Fecha a expedição e devolve o jogador pra cidade."""
    p["explore_state"] = {"day": 0, "active": False}
    return (
        "🏙️ <b>OS PORTÕES SE ABREM DE NOVO!</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Depois de sobreviver a 7 explorações, você finalmente vê os muros da "
        "cidade no horizonte. Bem-vindo de volta."
    )
