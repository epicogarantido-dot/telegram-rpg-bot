# game/cronicas.py
"""
📖 CRÔNICAS — o sistema novo de storylets do clã (26/09/2026, pedido do dev)

"Esquece moral, conselho e reputação." A revisão de 25/09 mostrou o problema
do sistema antigo: metade das escolhas mexia em QUALIDADES que nada no jogo
lia (moral, medo, informação, reputação...). Aqui toda escolha mexe em algo
que o jogo usa. As regras, uma por ideia aprovada:

 1. ALDEÕES COM NOME — o evento acontece com alguém da aldeia ("Arlo, o
    lenhador 4★..."); a escolha mexe NELE: talento, cansaço, nível, vida.
 2. EVENTOS QUE NASCEM DE FATOS — equipe voltou das 12h, baixa de 50%,
    ataque à cidade, morte no cultivo, faixa nova da Torre. Além deles, um
    sorteio leve por sessão (`gatilho: "sessao"`).
 3. NÚMEROS QUE ACOMPANHAM A ECONOMIA — recurso vem em "sessões de consumo"
    (`{"recurso": "comida", "sessoes": 0.5}` = meia sessão do que ESTA aldeia
    come). O sistema antigo envelheceu porque +20 de comida virou nada.
 4. APOSTAS COM VOLTA MARCADA — `agenda` chama outra crônica N sessões
    depois, carregando o contexto (quem foi, quanto levou).
 5. ARCOS POR FAIXA DA TORRE — `gatilho: "faixa"` na chegada a cada faixa
    de 10 andares; o fim do arco dá algo ÚNICO (espírito raro, recruta).
 6. DECISÕES EM CAMPO — `alvo: {"equipe": true}` pega uma equipe que está
    num posto; `equipe_fator` mexe no rendimento dela nas próximas sessões.
 7. LAÇOS — `laco: irmaos/rivais` entre dois aldeões. Irmãos na mesma
    equipe rendem +10%; rivais juntos cansam mais (clan_repo).
 8. GENTE NOVA — `chegam` traz aldeões de verdade (talento forte, aura).
 9. EXPIRA — toda crônica espera `expira` sessões; se ninguém decidir, a
    aldeia escolhe a opção `padrao`, e isso vai pras memórias.
 +  GUERRA COM CLÃ NPC — `guerra` aumenta a chance de ataque à cidade por N
    sessões (clan_habitantes lê `chance_ataque_extra`); `paz` encerra.
 +  FUNDAÇÃO — 3 crônicas de `gatilho: "inicio"` antes do 2º andar.

Estado em `clan.cronicas` (JSON): fila, agenda, flags, guerras,
modificadores das equipes, cooldowns, faixas vistas e histórico.
"""
from __future__ import annotations

import glob
import json
import os
import random
import time

PASTA = os.path.join(os.path.dirname(__file__), "conteudo", "cronicas")
TETO_FILA = 6
# ⏰ 26/09/2026 (dev): uma "sessão" das Crônicas é TEMPO DE RELÓGIO, não
# abertura do clã. Antes cada abertura com ≥15 min contava uma sessão:
# "3 sessões pra decidir" podia ser 45 min (quem abre toda hora) ou 18 h.
# Agora é sempre 6 h por sessão — prazo, volta das apostas e cooldown.
SEG_POR_SESSAO = 6 * 3600
EXPIRA_PADRAO = 3
CHANCE_SESSAO = 0.35          # chance de sair uma crônica "solta" por sessão
BONUS_GUERRA_ATAQUE = 0.20    # +20 pontos na chance de ataque (base 15%)
RECURSOS = ("comida", "madeira", "couro", "ferro")

_CATALOGO = None


# ---------------------------------------------------------------- catálogo
def chave_de_imagem(ev: dict) -> str:
    """🖼️ (26/09) CRONICA_<ID> — ou o campo "imagem" do JSON, pra várias
    crônicas dividirem a mesma arte. Envie pelo /admin → Imagens."""
    return str(ev.get("imagem") or ("CRONICA_" + str(ev["id"]).upper()))[:64]


def catalogo() -> dict:
    global _CATALOGO
    if _CATALOGO is None:
        cat = {}
        for arq in sorted(glob.glob(os.path.join(PASTA, "*.json"))):
            with open(arq, encoding="utf-8") as f:
                for ev in json.load(f):
                    cat[ev["id"]] = ev
        _CATALOGO = cat
    return _CATALOGO


def validar() -> list[str]:
    """Erros de conteúdo: agenda pra evento que não existe, opção padrão
    fora do lugar, efeito desconhecido. Rodado pela suíte de testes."""
    erros, cat = [], catalogo()
    conhecidos = {"recurso", "alvo", "alvo2", "chegam", "laco", "equipe_fator", "agenda",
                  "flag", "tirar_flag", "guerra", "paz", "pet", "texto", "jogador"}
    for sid, ev in cat.items():
        ops = ev.get("opcoes") or []
        if not ops:
            erros.append(f"{sid}: sem opções")
        if not (0 <= int(ev.get("padrao", len(ops) - 1)) < len(ops)):
            erros.append(f"{sid}: 'padrao' fora das opções")
        for i, op in enumerate(ops):
            for lado in ("efeitos", "sucesso", "falha"):
                for ef in op.get(lado) or []:
                    for k in ef:
                        if k not in conhecidos and k not in ("sessoes", "qtd", "talento", "valor",
                                                             "estrelas", "aura", "causa", "id", "em",
                                                             "fator", "raridade", "pct", "por_andar"):
                            erros.append(f"{sid}#{i}: efeito '{k}' desconhecido")
                    # 💰 (28/09, dev) "não faz sentido cair ouro de uma torre de
                    # treinamento — o ouro vem de cumprir missões pro reino".
                    # Na Torre, ouro só SAI (mercador, pedágio, oferenda).
                    if (ev.get("gatilho") in ("torre", "faixa") and ef.get("jogador") == "ouro"
                            and int(ef.get("qtd", 0)) > 0):
                        erros.append(f"{sid}#{i}: ouro não cai na Torre (vem das missões do reino)")
                    ag = ef.get("agenda")
                    if ag and ag.get("id") not in cat:
                        erros.append(f"{sid}#{i}: agenda pra '{ag.get('id')}', que não existe")
    return erros


# ---------------------------------------------------------------- estado
def estado_vazio() -> dict:
    return {"sessao": 0, "relogio": 0, "fila": [], "agenda": [], "flags": [], "guerras": {},
            "modificadores": {}, "cooldown": {}, "cooldown_torre": {}, "faixas": [],
            "historico": [], "uid": 0}


def carregar(clan: dict) -> dict:
    bruto = clan.get("cronicas")
    try:
        st = json.loads(bruto) if isinstance(bruto, str) else (bruto or {})
    except ValueError:
        st = {}
    base = estado_vazio()
    base.update(st or {})
    return base


def salvar(owner_id: int, st: dict) -> None:
    from game import clan_repo as CR
    st["historico"] = st["historico"][-40:]
    with CR._conn() as c:
        c.execute("UPDATE clan SET cronicas = ? WHERE owner_id = ?", (json.dumps(st), owner_id))
        c.commit()


def chance_ataque_extra(clan: dict) -> float:
    st = carregar(clan)
    ativas = [g for g in st["guerras"].values() if int(g.get("ate", 0)) >= int(st["sessao"])]
    return BONUS_GUERRA_ATAQUE if ativas else 0.0


def fator_da_equipe(clan: dict, posto_id: str) -> float:
    st = carregar(clan)
    m = st["modificadores"].get(posto_id)
    if m and int(m.get("ate", 0)) >= int(st["sessao"]):
        return float(m.get("fator", 1.0))
    return 1.0


# ---------------------------------------------------------------- economia
def consumo_por_sessao(owner_id: int, recurso: str) -> int:
    """Quanto ESTA aldeia gasta de `recurso` numa sessão — a unidade dos
    efeitos. Couro e ferro têm piso de 10: o gasto deles é pequeno (só os
    guardas), e meia sessão de 4 seria nada."""
    from game import clan_repo as CR
    from game import clan_habitantes as H
    from game.clan_equipes import LENHA_POR_ALDEAO
    aldeoes = len(CR.listar_habitantes(owner_id))
    if recurso == "comida":
        return max(30, CR.bocas_do_cla(owner_id) * (CR.TETO_TICKS // max(1, H.RACAO_HABITANTE_TICKS)))
    if recurso == "madeira":
        return max(20, int(aldeoes * LENHA_POR_ALDEAO))
    guardas = sum(1 for h in CR.listar_habitantes(owner_id) if h.get("funcao") == "guarda")
    return max(10, 2 * guardas)


# ---------------------------------------------------------------- alvos
def _escolher_alvo(owner_id: int, pedido: dict, rng) -> dict | None:
    from game import clan_repo as CR
    from game import territorio as T
    ctx = {}
    habs = CR.listar_habitantes(owner_id)
    if pedido.get("aldeao"):
        req = pedido["aldeao"] if isinstance(pedido["aldeao"], dict) else {}
        tal, minimo = req.get("talento"), int(req.get("min", 0))
        cands = [h for h in habs if not tal or int((h.get("talentos") or {}).get(tal, 0)) >= minimo]
        if req.get("livre"):
            cands = [h for h in cands if not h.get("funcao")]
        if not cands:
            return None
        h = rng.choice(cands)
        ctx["alvo_id"], ctx["alvo"] = h["id"], h["nome"]
        ctx["alvo_estrelas"] = int((h.get("talentos") or {}).get(tal, 0)) if tal else 0
    if pedido.get("dois_aldeoes"):
        livres = [h for h in habs if int(h.get("id")) != int(ctx.get("alvo_id", 0))]
        if len(livres) < 2 and "alvo_id" not in ctx:
            return None
        if "alvo_id" not in ctx:
            a = rng.choice(livres)
            ctx["alvo_id"], ctx["alvo"] = a["id"], a["nome"]
            livres = [h for h in livres if h["id"] != a["id"]]
        if not livres:
            return None
        b = rng.choice(livres)
        ctx["alvo2_id"], ctx["alvo2"] = b["id"], b["nome"]
    if pedido.get("equipe"):
        eqs = [(pid, e) for pid, e in CR.equipes_do_cla(owner_id).items()
               if e.get("coletores") and pid not in (CR.EQUIPE_DA_CIDADE, CR.EQUIPE_DO_PONTO)]
        if not eqs:
            return None
        pid, e = rng.choice(eqs)
        areas = CR.areas_do_cla(owner_id, 999)
        area = areas.get(pid) or {}
        recurso, _f = CR.recurso_e_fator_da_equipe(e, area)
        ctx.update({"posto_id": pid, "posto": area.get("nome", pid), "recurso": recurso,
                    "equipe_tamanho": len(e.get("coletores") or [])})
    if pedido.get("cla"):
        bot = rng.choice(T.BOTS)
        ctx["cla_id"], ctx["cla"] = bot["id"], f"{bot['icone']} {bot['nome']}"
    return ctx


def _texto(modelo: str, ctx: dict) -> str:
    try:
        return str(modelo).format(**{k: v for k, v in ctx.items()})
    except (KeyError, IndexError, ValueError):
        return str(modelo)


# ---------------------------------------------------------------- elegibilidade
def _elegivel(ev: dict, st: dict, fatos: dict, clan: dict, p: dict | None) -> bool:
    c = ev.get("condicoes") or {}
    flags = set(st["flags"])
    if c.get("flag") and c["flag"] not in flags:
        return False
    if c.get("sem_flag") and c["sem_flag"] in flags:
        return False
    andar = int((p or {}).get("tower_floor") or fatos.get("andar") or 1)
    if andar < int(c.get("andar_min", 0)) or andar > int(c.get("andar_max", 10**6)):
        return False
    if ev.get("gatilho") == "torre":
        # encontro da Torre: cooldown em HORAS (a Torre roda muito mais que
        # 6 h por vez; em sessões de 6 h um encontro sumiria por dias)
        if int(st.get("cooldown_torre", {}).get(ev["id"], 0)) > int(time.time()):
            return False
    elif int(st["cooldown"].get(ev["id"], -1)) >= int(st["sessao"]):
        return False
    if any(item.get("id") == ev["id"] for item in st["fila"]):
        return False
    if c.get("em_guerra") and not any(int(g.get("ate", 0)) >= int(st["sessao"]) for g in st["guerras"].values()):
        return False
    return True


def _completar_ctx(owner_id: int, st: dict, ev: dict, ctx: dict, rng=None) -> dict | None:
    """Evento que chega pela agenda com um `alvo` pedido e sem ninguém no
    contexto escolhe na hora; evento de guerra usa o clã EM GUERRA."""
    rng = rng or random.Random()
    ctx = dict(ctx or {})
    pedido = dict(ev.get("alvo") or {})
    if (ev.get("condicoes") or {}).get("em_guerra"):
        ativas = [(k, g) for k, g in st["guerras"].items() if int(g.get("ate", 0)) >= int(st["sessao"])]
        if not ativas:
            return None
        k, g = rng.choice(ativas)
        ctx["cla_id"], ctx["cla"] = k, g.get("nome")
        pedido.pop("cla", None)
    if pedido.get("aldeao") and ctx.get("alvo_id"):
        pedido.pop("aldeao")
    if pedido.get("dois_aldeoes") and ctx.get("alvo_id") and ctx.get("alvo2_id"):
        pedido.pop("dois_aldeoes")      # a dupla já veio escolhida (agenda)
    if pedido.get("cla") and ctx.get("cla_id"):
        pedido.pop("cla")
    if pedido:
        extra = _escolher_alvo(owner_id, pedido, rng)
        if extra is None:
            return None
        ctx.update(extra)
    return ctx


def _enfileirar(owner_id: int, st: dict, ev: dict, ctx: dict, rng=None) -> dict | None:
    ctx = _completar_ctx(owner_id, st, ev, ctx, rng)
    if ctx is None:
        return None
    st["uid"] = int(st.get("uid", 0)) + 1
    item = {"uid": st["uid"], "id": ev["id"], "ctx": ctx, "criada": int(st["sessao"]),
            "expira": int(st["sessao"]) + int(ev.get("expira", EXPIRA_PADRAO))}
    st["fila"].append(item)
    if ev.get("cooldown"):
        st["cooldown"][ev["id"]] = int(st["sessao"]) + int(ev["cooldown"])
    return item


def _tentar(owner_id: int, st: dict, ev: dict, ctx_base: dict, rng, clan, p, fatos) -> bool:
    if len(st["fila"]) >= TETO_FILA or not _elegivel(ev, st, fatos, clan, p):
        return False
    return _enfileirar(owner_id, st, ev, dict(ctx_base), rng) is not None


# ---------------------------------------------------------------- a sessão
def avancar_sessao(owner_id: int, fatos: dict, p: dict | None = None, rng=None) -> dict:
    """Chamado quando o AFK processou uma sessão. Anda o relógio, resolve o
    que expirou, dispara o que a agenda marcou e o que os FATOS pedem."""
    from game import clan_repo as CR
    rng = rng or random.Random()
    clan = CR.carregar_clan(owner_id)
    st = carregar(clan)
    agora = int(time.time())
    if not int(st.get("relogio") or 0):
        st["relogio"] = agora                 # estado de antes do relógio: começa agora
    passos = max(0, (agora - int(st["relogio"])) // SEG_POR_SESSAO)
    if passos:
        st["sessao"] = int(st["sessao"]) + passos
        st["relogio"] = int(st["relogio"]) + passos * SEG_POR_SESSAO
    cat = catalogo()
    saida = {"expiradas": [], "novas": []}

    # 9) expiração: a aldeia decide sozinha
    for item in list(st["fila"]):
        if int(item["expira"]) < int(st["sessao"]):
            ev = cat.get(item["id"])
            if ev:
                r = _resolver_item(owner_id, st, item, int(ev.get("padrao", len(ev["opcoes"]) - 1)),
                                   p, rng, automatica=True)
                saida["expiradas"].append(r)
            st["fila"] = [x for x in st["fila"] if x["uid"] != item["uid"]]

    # 4) agenda: as apostas voltam
    for ag in list(st["agenda"]):
        if int(ag["sessao"]) <= int(st["sessao"]):
            st["agenda"].remove(ag)
            ev = cat.get(ag["id"])
            if ev and len(st["fila"]) < TETO_FILA:
                _enfileirar(owner_id, st, ev, dict(ag.get("ctx") or {}))
                saida["novas"].append(ev["id"])

    # 2) fatos → gatilhos
    por_gatilho = {}
    for ev in cat.values():
        por_gatilho.setdefault(ev.get("gatilho", "sessao"), []).append(ev)
    for fato, ctx_fato in (fatos or {}).items():
        # 🐛 (26/09) era `or not ctx_fato`: os fatos marcados com {} (equipe
        # voltou, baixa, ataque) são "falsos" em Python e eram PULADOS — só a
        # morte no cultivo (que leva o nome) disparava crônica.
        if fato in ("sessao", "andar") or ctx_fato is None or ctx_fato is False:
            continue
        cands = [e for e in por_gatilho.get(fato, [])]
        rng.shuffle(cands)
        for ev in cands:
            if _tentar(owner_id, st, ev, ctx_fato if isinstance(ctx_fato, dict) else {}, rng, clan, p, fatos):
                saida["novas"].append(ev["id"])
                break

    # 5) faixas da Torre
    andar = int((p or {}).get("tower_floor") or 1)
    faixa = (andar - 1) // 10 + 1
    for ev in por_gatilho.get("faixa", []):
        fx = int((ev.get("condicoes") or {}).get("faixa", 0))
        if fx and fx <= faixa and fx not in st["faixas"]:
            if _tentar(owner_id, st, ev, {"faixa": fx}, rng, clan, p, fatos):
                st["faixas"].append(fx)
                saida["novas"].append(ev["id"])

    # sorteio leve: uma chance a cada 6 h de relógio que passaram
    if passos and rng.random() < CHANCE_SESSAO:
        cands = [e for e in por_gatilho.get("sessao", []) if _elegivel(e, st, fatos, clan, p)]
        pesos = [float(e.get("peso", 1)) for e in cands]
        tentativas = 0
        while cands and tentativas < 6:
            tentativas += 1
            ev = rng.choices(cands, weights=pesos)[0]
            if _tentar(owner_id, st, ev, {}, rng, clan, p, fatos):
                saida["novas"].append(ev["id"])
                break

    salvar(owner_id, st)
    return saida


def garantir_fundacao(owner_id: int, p: dict) -> None:
    """Os 3 eventos de fundação entram na fila de quem ainda não fundou —
    um de cada vez: a crônica seguinte é chamada pela `agenda` da anterior."""
    from game import clan_repo as CR
    clan = CR.carregar_clan(owner_id)
    st = carregar(clan)
    if "fundado" in st["flags"] or any(i["id"].startswith("fundacao_") for i in st["fila"]) \
            or any(a["id"].startswith("fundacao_") for a in st["agenda"]):
        return
    if int(p.get("tower_floor") or 1) > 1:
        # quem já passou do 1º andar antes das Crônicas não é travado
        st["flags"].append("fundado")
        salvar(owner_id, st)
        return
    ev = catalogo().get("fundacao_acampamento")
    if ev:
        _enfileirar(owner_id, st, ev, {})
        salvar(owner_id, st)


def fundado(clan: dict) -> bool:
    return "fundado" in carregar(clan)["flags"]


# ---------------------------------------------------------------- a tela
def _chance(op: dict, ctx: dict, owner_id: int) -> float | None:
    ch = op.get("chance")
    if not ch:
        return None
    from game import clan_repo as CR
    p_ = float(ch.get("base", 0.5))
    if ch.get("por_estrela") and ctx.get("alvo_estrelas") is not None:
        p_ += float(ch["por_estrela"]) * int(ctx.get("alvo_estrelas") or 0)
    if ch.get("por_nivel") and ctx.get("nivel") is not None:
        # nível do jogador contra o esperado do andar (2× o andar)
        p_ += float(ch["por_nivel"]) * (int(ctx["nivel"]) - 2 * int(ctx.get("andar") or 1))
    if ch.get("guardas"):
        guardas = [h for h in CR.listar_habitantes(owner_id)
                   if int((h.get("talentos") or {}).get("guarda", 0)) >= 1]
        estrelas = sorted((int(h["talentos"]["guarda"]) for h in guardas), reverse=True)[:4]
        p_ += float(ch["guardas"]) * sum(estrelas)
    return max(0.05, min(0.95, p_))


def _custo_ok(op: dict, owner_id: int, clan: dict, p: dict | None = None) -> tuple[bool, str]:
    for ef in op.get("efeitos") or []:
        if ef.get("jogador") and p is not None:
            andar = int(p.get("tower_floor") or 1)
            if ef["jogador"] == "ouro" and int(ef.get("qtd", 0)) < 0:
                custo = -int(ef["qtd"]) * (andar if ef.get("por_andar", True) else 1)
                if int(p.get("gold") or 0) < custo:
                    return False, f"precisa de {custo} de ouro (tem {int(p.get('gold') or 0)})"
            if ef["jogador"] == "pocao" and int(ef.get("qtd", 0)) < 0:
                tem = int((p.get("inv") or {}).get("potion") or 0)
                if tem < -int(ef["qtd"]):
                    return False, "você não tem poção"
        r = ef.get("recurso")
        if r and _quantidade(ef, owner_id) < 0:
            falta = -_quantidade(ef, owner_id)
            tem = int(clan["materiais"].get(1, 0)) if r == "ferro" else int(clan.get(r) or 0)
            if tem < falta:
                return False, f"precisa de {falta} de {r} (tem {tem})"
    return True, ""


def _quantidade(ef: dict, owner_id: int) -> int:
    if "qtd" in ef:
        return int(ef["qtd"])
    return int(round(float(ef.get("sessoes", 0)) * consumo_por_sessao(owner_id, ef["recurso"])))


def _resumo_efeitos(efs: list, owner_id: int, ctx: dict, p: dict | None = None) -> list[str]:
    out = []
    for ef in efs or []:
        if ef.get("jogador"):
            j = ef["jogador"]
            if j == "ouro":
                q = int(ef.get("qtd", 0)) * (int((p or {}).get("tower_floor") or 1) if ef.get("por_andar", True) else 1)
                out.append(f"{'+' if q >= 0 else ''}{q} ouro")
            elif j == "hp":
                out.append(f"{'+' if float(ef.get('pct', 0)) >= 0 else ''}{int(float(ef.get('pct', 0)) * 100)}% vida")
            elif j == "pocao":
                out.append(f"{'+' if int(ef.get('qtd', 1)) >= 0 else ''}{int(ef.get('qtd', 1))} poção")
            elif j == "xp":
                out.append(f"+XP")
            continue
        if ef.get("recurso"):
            q = _quantidade(ef, owner_id)
            out.append(f"{'+' if q >= 0 else ''}{q} {ef['recurso']}")
        elif ef.get("chegam"):
            out.append(f"+{ef['chegam']} aldeão(ões)")
        elif ef.get("equipe_fator"):
            out.append(f"equipe ×{ef['equipe_fator']} por {ef.get('sessoes', 1)} sessão(ões)")
        elif ef.get("guerra"):
            out.append(f"⚔️ guerra com {ctx.get('cla', 'o clã')}")
        elif ef.get("paz"):
            out.append("🕊️ fim da guerra")
    return out


def fila_publica(owner_id: int) -> list[dict]:
    from game import clan_repo as CR
    clan = CR.carregar_clan(owner_id)
    st, cat = carregar(clan), catalogo()
    saida = []
    for item in st["fila"]:
        ev = cat.get(item["id"])
        if not ev:
            continue
        ctx = item.get("ctx") or {}
        ops = []
        for i, op in enumerate(ev["opcoes"]):
            ok, motivo = _custo_ok(op, owner_id, clan)
            ch = _chance(op, ctx, owner_id)
            ops.append({"indice": i, "texto": _texto(op["label"], ctx), "disponivel": ok, "motivo": motivo,
                        "chance": None if ch is None else round(ch * 100),
                        "custos": _resumo_efeitos(op.get("efeitos"), owner_id, ctx)})
        padrao = int(ev.get("padrao", len(ev["opcoes"]) - 1))
        saida.append({"uid": item["uid"], "id": ev["id"], "img_key": chave_de_imagem(ev),
                      "titulo": _texto(ev.get("titulo", ""), ctx),
                      "icone": ev.get("icone", "📖"), "texto": _texto(ev["texto"], ctx),
                      "restam": max(0, int(item["expira"]) - int(st["sessao"]) + 1),
                      "restam_horas": _horas_ate(st, int(item["expira"])),
                      "padrao": _texto(ev["opcoes"][padrao]["label"], ctx), "opcoes": ops,
                      "fundacao": ev["id"].startswith("fundacao_")})
    return saida


def _horas_ate(st: dict, sessao_final: int) -> int:
    """Horas de relógio até a sessão `sessao_final` acabar."""
    relogio = int(st.get("relogio") or time.time())
    fim = relogio + (int(sessao_final) - int(st["sessao"]) + 1) * SEG_POR_SESSAO
    return max(0, round((fim - int(time.time())) / 3600))


def guerras_ativas(clan: dict) -> list[dict]:
    st = carregar(clan)
    return [{"cla": g.get("nome"), "restam": int(g["ate"]) - int(st["sessao"]) + 1,
             "restam_horas": _horas_ate(st, int(g["ate"]))}
            for g in st["guerras"].values() if int(g.get("ate", 0)) >= int(st["sessao"])]


# ---------------------------------------------------------------- resolver
def resolver(owner_id: int, uid: int, indice: int, p: dict | None = None, rng=None) -> dict:
    from game import clan_repo as CR
    rng = rng or random.Random()
    clan = CR.carregar_clan(owner_id)
    st = carregar(clan)
    item = next((x for x in st["fila"] if int(x["uid"]) == int(uid)), None)
    if not item:
        return {"ok": False, "erro": "Essa crônica já foi decidida."}
    ev = catalogo().get(item["id"])
    if not ev or not (0 <= int(indice) < len(ev["opcoes"])):
        return {"ok": False, "erro": "Escolha inválida."}
    ok, motivo = _custo_ok(ev["opcoes"][int(indice)], owner_id, clan)
    if not ok:
        return {"ok": False, "erro": f"Não dá: {motivo}."}
    r = _resolver_item(owner_id, st, item, int(indice), p, rng)
    st["fila"] = [x for x in st["fila"] if x["uid"] != item["uid"]]
    salvar(owner_id, st)
    return dict(r, ok=True)


def _resolver_item(owner_id, st, item, indice, p, rng, automatica=False) -> dict:
    from game import clan_repo as CR
    ev = catalogo()[item["id"]]
    op = ev["opcoes"][indice]
    ctx = item.get("ctx") or {}
    efs = list(op.get("efeitos") or [])
    sucesso = None
    ch = _chance(op, ctx, owner_id)
    if ch is not None:
        sucesso = rng.random() < ch
        efs += list(op.get("sucesso" if sucesso else "falha") or [])
    linhas = [_aplicar(owner_id, st, ef, ctx, p, rng) for ef in efs]
    linhas = [l for l in linhas if l]
    titulo = _texto(ev.get("titulo", ""), ctx)
    rotulo = _texto(op["label"], ctx)
    resumo = (f"📖 {titulo}: " + ("(a aldeia decidiu sozinha) " if automatica else "")
              + rotulo + (" — deu certo." if sucesso else " — deu errado." if sucesso is False else ""))
    st["historico"].append({"sessao": st["sessao"], "texto": resumo, "detalhes": linhas})
    with CR._conn() as c:
        CR._anotar(c, owner_id, resumo, tipo="cronica")
        c.commit()
    return {"titulo": titulo, "escolha": rotulo, "sucesso": sucesso, "chance": None if ch is None else round(ch * 100),
            "linhas": linhas, "automatica": automatica}


# ---------------------------------------------------------------- efeitos
def _aplicar(owner_id, st, ef, ctx, p, rng) -> str:
    from game import clan_repo as CR
    from game import clan_habitantes as H
    from game.clan_materiais import teto_de_comida
    if ef.get("texto"):
        return _texto(ef["texto"], ctx)
    if ef.get("recurso"):
        r, q = ef["recurso"], _quantidade(ef, owner_id)
        clan = CR.carregar_clan(owner_id)
        with CR._conn() as c:
            if r == "ferro":
                mats = dict(clan["materiais"])
                mats[1] = max(0, int(mats.get(1, 0)) + q)
                c.execute("UPDATE clan SET materiais = ? WHERE owner_id = ?",
                          (json.dumps({str(k): v for k, v in mats.items()}), owner_id))
            elif r == "comida":
                teto = teto_de_comida(clan["comodidades"], CR.bocas_do_cla(owner_id))
                c.execute("UPDATE clan SET comida = MAX(0, MIN(MAX(?, comida), comida + ?)) WHERE owner_id = ?",
                          (teto, q, owner_id))
            else:
                c.execute(f"UPDATE clan SET {r} = MAX(0, {r} + ?) WHERE owner_id = ?", (q, owner_id))
            c.commit()
        return f"{'+' if q >= 0 else ''}{q} de {r}"
    for chave_alvo, chave_id, chave_nome in (("alvo", "alvo_id", "alvo"), ("alvo2", "alvo2_id", "alvo2")):
        if ef.get(chave_alvo) and ctx.get(chave_id):
            habs = {int(h["id"]): h for h in CR.listar_habitantes(owner_id)}
            h = habs.get(int(ctx[chave_id]))
            if not h:
                return f"{ctx.get(chave_nome)} já não está na aldeia."
            oque, nome = ef[chave_alvo], h["nome"]
            if oque == "talento":
                tal = ef.get("talento") or "lenhador"
                h["talentos"] = dict(h.get("talentos") or {})
                antes = int(h["talentos"].get(tal, 0))
                h["talentos"][tal] = max(0, min(5, antes + int(ef.get("valor", 1))))
                texto = f"{nome}: {tal} {antes}★ → {h['talentos'][tal]}★"
            elif oque == "fadiga":
                h["fadiga"] = max(0, min(H.FADIGA_MAX, int(h.get("fadiga") or 0) + int(ef.get("valor", 0))))
                texto = f"{nome}: cansaço {h['fadiga']}%"
            elif oque == "nivel":
                h["nivel"] = min(int(h.get("nivel_max") or 99), int(h.get("nivel") or 1) + int(ef.get("valor", 1)))
                texto = f"{nome} subiu pro nível {h['nivel']}"
            elif oque == "aura":
                h["aura"] = max(1, int(h.get("aura") or 0))
                texto = f"✨ {nome} despertou a aura"
            elif oque in ("morre", "parte"):
                h["vivo"] = 0
                h["causa"] = ef.get("causa") or ("foi embora" if oque == "parte" else "morreu")
                h["funcao"], h["equipe"] = None, None
                texto = f"{'🚪' if oque == 'parte' else '🕯️'} {nome} {h['causa']}"
            else:
                return ""
            with CR._conn() as c:
                CR._gravar_habitantes(c, owner_id, [h], int(time.time()))
                c.commit()
            if oque in ("morre", "parte"):
                eqs = CR.equipes_do_cla(owner_id)
                for e in eqs.values():
                    for papel in ("coletores", "guardas"):
                        e[papel] = [x for x in (e.get(papel) or []) if int(x) != int(h["id"])]
                CR._sincronizar_funcoes(owner_id, eqs)
            return texto
    if ef.get("chegam"):
        clan = CR.carregar_clan(owner_id)
        vivos = CR.listar_habitantes(owner_id)
        casa = H.moradores(vivos)                # 🏙️ cavaleiro não ocupa casa
        cap = H.estagio_da_aldeia(len(casa), clan["comodidades"] or {})["capacidade"]
        vem = min(int(ef["chegam"]), max(0, cap - len(casa)))
        em_uso = {h["nome"] for h in CR.listar_habitantes(owner_id, incluir_mortos=True)}
        novos = []
        for _ in range(vem):
            h = H.novo_habitante(rng, em_uso)
            if ef.get("talento"):
                h["talentos"][ef["talento"]] = max(int(h["talentos"].get(ef["talento"], 0)), int(ef.get("estrelas", 3)))
                h["profissao"] = ef["talento"]
            if ef.get("aura"):
                h["aura"] = 1
            em_uso.add(h["nome"])
            novos.append(h)
        if novos:
            with CR._conn() as c:
                CR._gravar_habitantes(c, owner_id, novos, int(time.time()))
                c.commit()
        nomes = ", ".join(h["nome"] for h in novos)
        falta = int(ef["chegam"]) - vem
        return (f"🚶 Chegou: {nomes}" if novos else "") + (f" (sem vaga pra {falta} — construa Moradias)" if falta else "")
    if ef.get("laco") and ctx.get("alvo_id") and ctx.get("alvo2_id"):
        habs = {int(h["id"]): h for h in CR.listar_habitantes(owner_id)}
        a, b = habs.get(int(ctx["alvo_id"])), habs.get(int(ctx["alvo2_id"]))
        if not (a and b):
            return ""
        a["laco"], b["laco"] = ef["laco"], ef["laco"]
        a["parente_de"], b["parente_de"] = b["id"], a["id"]
        with CR._conn() as c:
            CR._gravar_habitantes(c, owner_id, [a, b], int(time.time()))
            c.commit()
        return {"irmaos": f"🤝 {a['nome']} e {b['nome']} agora são como irmãos (+10% juntos numa equipe)",
                "rivais": f"😠 {a['nome']} e {b['nome']} viraram rivais (juntos numa equipe, cansam mais)"
                }.get(ef["laco"], "")
    if ef.get("equipe_fator") and ctx.get("posto_id"):
        st["modificadores"][ctx["posto_id"]] = {"fator": float(ef["equipe_fator"]),
                                                "ate": int(st["sessao"]) + int(ef.get("sessoes", 1))}
        return f"{ctx.get('posto')}: rendimento ×{ef['equipe_fator']} por {ef.get('sessoes', 1)} sessão(ões)"
    if ef.get("agenda"):
        ag = ef["agenda"]
        if int(ag.get("em", 3)) <= 0:
            # "em 0": a próxima crônica entra NA HORA (a fundação é uma sequência)
            ev = catalogo().get(ag["id"])
            if ev:
                _enfileirar(owner_id, st, ev, dict(ctx))
            return ""
        st["agenda"].append({"id": ag["id"], "sessao": int(st["sessao"]) + int(ag.get("em", 3)), "ctx": dict(ctx)})
        return ""
    if ef.get("flag"):
        if ef["flag"] not in st["flags"]:
            st["flags"].append(ef["flag"])
        return ""
    if ef.get("tirar_flag"):
        st["flags"] = [f for f in st["flags"] if f != ef["tirar_flag"]]
        return ""
    if ef.get("guerra") and ctx.get("cla_id"):
        st["guerras"][ctx["cla_id"]] = {"nome": ctx.get("cla"), "ate": int(st["sessao"]) + int(ef.get("sessoes", 6))}
        return f"⚔️ {ctx.get('cla')} declarou guerra: a cidade será atacada com mais frequência"
    if ef.get("paz") and ctx.get("cla_id"):
        st["guerras"].pop(ctx["cla_id"], None)
        return f"🕊️ A guerra com {ctx.get('cla')} acabou"
    if ef.get("jogador") and p is not None:
        # 🧍 (26/09) efeitos no PERSONAGEM (encontros da Torre). Valores
        # relativos, pra valer igual no andar 3 e no 90: vida em % da
        # máxima, XP em % do que falta pro nível, ouro × andar.
        oque = ef["jogador"]
        andar = int(p.get("tower_floor") or 1)
        if oque == "hp":
            hp_max = int(p.get("hp_max") or 1)
            delta = int(round(hp_max * float(ef.get("pct", 0))))
            p["hp"] = max(1, min(hp_max, int(p.get("hp") or 0) + delta))
            return f"{'💚 +' if delta >= 0 else '💔 '}{delta} de vida"
        if oque == "xp":
            import game.logic as L
            ganho = max(1, int(int(p.get("xp_next") or 100) * float(ef.get("pct", 0.1))))
            L.gain_xp(p, ganho)
            # 🐛 (28/09) no teto de nível do andar o gain_xp não dá nada, mas
            # o texto dizia "+10 XP" do mesmo jeito
            if p.get("_last_xp_capped"):
                return "✨ XP travado: você está no nível máximo deste andar"
            return f"✨ +{ganho} XP"
        if oque == "ouro":
            q = int(ef.get("qtd", 0)) * (andar if ef.get("por_andar", True) else 1)
            p["gold"] = max(0, int(p.get("gold") or 0) + q)
            return f"💰 {'+' if q >= 0 else ''}{q} de ouro"
        if oque == "pocao":
            inv = p.setdefault("inv", {})
            inv["potion"] = max(0, int(inv.get("potion") or 0) + int(ef.get("qtd", 1)))
            return f"🧪 {'+' if int(ef.get('qtd', 1)) >= 0 else ''}{int(ef.get('qtd', 1))} poção"
        return ""
    if ef.get("pet") and p is not None:
        from game.pets_db import PETS_DB
        rar = ef.get("raridade") or ef["pet"]
        cands = [pid for pid, pet in PETS_DB.items() if pet.get("rarity") == rar] or list(PETS_DB)
        pid = rng.choice(cands)
        pets = p.setdefault("pets", {})
        owned = pets.setdefault("owned", {})
        owned[pid] = int(owned.get(pid, 0) or 0) + 1
        return f"🐾 Um espírito se juntou a você: {PETS_DB[pid].get('name', pid)}"
    return ""



# ---------------------------------------------------------------- Torre
# 👣 (26/09) Os ENCONTROS DA TORRE entram no sistema novo: gatilho "torre",
# sorteados no Explorar (logic.tower_explore) e resolvidos na hora, na tela
# da Torre. O encontro mora em p["torre_encontro"] = {"cronica", "ctx"}.
def sortear_encontro_torre(p: dict, rng=None) -> dict | None:
    from game import clan_repo as CR
    rng = rng or random.Random()
    owner_id = int(p.get("telegram_id") or p.get("user_id") or 0)
    clan = CR.carregar_clan(owner_id)
    st = carregar(clan)
    andar = int(p.get("tower_floor") or 1)
    cands = [e for e in catalogo().values() if e.get("gatilho") == "torre"
             and _elegivel(e, st, {"andar": andar}, clan, p)]
    rng.shuffle(cands)
    pesos = [float(e.get("peso", 1)) for e in cands]
    for _ in range(min(6, len(cands))):
        ev = rng.choices(cands, weights=pesos)[0]
        ctx = _completar_ctx(owner_id, st, ev, {"andar": andar, "nivel": int(p.get("level") or 1)}, rng)
        if ctx is not None:
            if ev.get("cooldown"):
                st.setdefault("cooldown_torre", {})[ev["id"]] = int(time.time()) + int(ev["cooldown"]) * 3600
                salvar(owner_id, st)
            return {"cronica": ev["id"], "ctx": ctx}
    return None


# 🏕️ (28/09) Antes da fundação (1º andar) o clã não existe pro jogador, mas
# encontros como "A família perdida" ofereciam "Mandar pro seu clã" — e
# falhavam com "precisa de 8 de comida (tem 0)", ou mandavam gente pra um clã
# que ainda não foi fundado. Opção que mexe no clã fica indisponível até a
# fundação, com o motivo na tela. Só nos ENCONTROS: as crônicas da fundação
# mexem no clã justamente pra fundá-lo.
EFEITOS_DO_CLA = ("recurso", "chegam", "alvo", "alvo2", "laco", "equipe_fator", "guerra", "paz")


def _mexe_no_cla(op: dict) -> bool:
    return any(k in ef for lado in ("efeitos", "sucesso", "falha")
               for ef in op.get(lado) or [] for k in EFEITOS_DO_CLA)


def _opcao_do_encontro_ok(op: dict, owner_id: int, clan: dict, p: dict) -> tuple[bool, str]:
    if _mexe_no_cla(op) and not fundado(clan):
        return False, "você ainda não fundou o seu clã"
    return _custo_ok(op, owner_id, clan, p)


def encontro_publico(p: dict, enc: dict) -> dict | None:
    from game import clan_repo as CR
    ev = catalogo().get((enc or {}).get("cronica"))
    if not ev:
        return None
    owner_id = int(p.get("telegram_id") or p.get("user_id") or 0)
    clan = CR.carregar_clan(owner_id)
    ctx = enc.get("ctx") or {}
    ops = []
    for i, op in enumerate(ev["opcoes"]):
        ok, motivo = _opcao_do_encontro_ok(op, owner_id, clan, p)
        ch = _chance(op, ctx, owner_id)
        ops.append({"indice": i, "texto": _texto(op["label"], ctx), "disponivel": ok, "motivo": motivo,
                    "chance": None if ch is None else round(ch * 100),
                    "custos": _resumo_efeitos(op.get("efeitos"), owner_id, ctx, p)})
    return {"id": ev["id"], "img_key": chave_de_imagem(ev), "icone": ev.get("icone", "👣"),
            "titulo": _texto(ev.get("titulo", ""), ctx),
            "texto": _texto(ev["texto"], ctx), "opcoes": ops}


def resolver_encontro(p: dict, indice: int, rng=None) -> dict:
    from game import clan_repo as CR
    rng = rng or random.Random()
    enc = p.get("torre_encontro")
    if not isinstance(enc, dict) or enc.get("cronica") not in catalogo():
        return {"ok": False, "erro": "Não há encontro esperando."}
    ev = catalogo()[enc["cronica"]]
    if not (0 <= int(indice) < len(ev["opcoes"])):
        return {"ok": False, "erro": "Escolha inválida."}
    owner_id = int(p.get("telegram_id") or p.get("user_id") or 0)
    clan = CR.carregar_clan(owner_id)
    ok, motivo = _opcao_do_encontro_ok(ev["opcoes"][int(indice)], owner_id, clan, p)
    if not ok:
        return {"ok": False, "erro": f"Não dá: {motivo}."}
    st = carregar(clan)
    item = {"uid": 0, "id": ev["id"], "ctx": enc.get("ctx") or {}}
    r = _resolver_item(owner_id, st, item, int(indice), p, rng)
    salvar(owner_id, st)
    p["torre_encontro"] = None
    return dict(r, ok=True)
