# game/clan_postos.py
"""
🔎 POSTOS — o que existe em cada andar, e como o clã os acha (20/09/2026)

O QUE MUDOU
-----------
Antes, cada andar era UM posto pronto (andar 1 = comida, andar 3 = madeira,
...), todos visíveis desde o início. O dev pediu duas coisas:
- a lista de postos depende do ANDAR (andar raso tem clareira e bosque;
  fundo tem veio de minério, veio rico...);
- pra ter um posto, o clã precisa ACHAR — explorando, com sorte. Nem
  sempre se acha o posto que se quer: às vezes volta de mãos vazias, às
  vezes acha um bosque quando queria o veio, e a qualidade (★) também é
  sorteada.

COMO ENCAIXA NO AFK
-------------------
Cada posto achado vira uma "área" no formato que `clan_afk`/`rodar_afk` já
entendem (id, andar, nome, recurso, rende, rank) — o motor do AFK não
mudou. O perigo continua sendo o do ANDAR (os monstros de lá); o posto
decide O QUE e QUANTO se tira dele.

Puro: sem banco. `clan_repo` guarda o que foi achado em `clan.postos`.
"""
from __future__ import annotations

import random

# peso = quão comum é achar; a partir_de = andar mínimo; mult = rendimento
TIPOS_POSTO = {
    "clareira":  {"nome": "Clareira",        "icone": "🌾", "recurso": "comida",  "peso": 5, "a_partir_de": 1,  "mult": 1.0},
    "nascente":  {"nome": "Nascente",        "icone": "💧", "recurso": "comida",  "peso": 2, "a_partir_de": 1,  "mult": 1.35},
    "bosque":    {"nome": "Bosque",          "icone": "🌲", "recurso": "madeira", "peso": 4, "a_partir_de": 2,  "mult": 1.0},
    "caca":      {"nome": "Trilha de Caça",  "icone": "🦌", "recurso": "couro",   "peso": 3, "a_partir_de": 4,  "mult": 1.0},
    # material: veio dá rank 1 (o do bicho comum), veio profundo rank 2 (o da
    # elite). Rank 3 NÃO sai de posto: é só de chefe (regra do dev, 20/09).
    # a partir do 5 (dev, 20/09): antes era 6, e a Mina do mapa no andar 5
    # não tinha o que multiplicar (medir_material.py achou o buraco)
    "veio":      {"nome": "Veio de Minério", "icone": "⛏️", "recurso": "metal",   "peso": 3, "a_partir_de": 5,  "mult": 1.0, "rank": 1},
    "veio_rico": {"nome": "Veio Profundo",   "icone": "💎", "recurso": "metal",   "peso": 1, "a_partir_de": 12, "mult": 1.0, "rank": 2},
}

# ★ sorteada ao achar: é o "nem sempre acha o que quer" dentro do próprio tipo
QUALIDADES = [(1, 0.85, 50), (2, 1.0, 35), (3, 1.2, 15)]   # (estrelas, mult, peso)

CHANCE_DE_ACHAR = 0.6


def custo_exploracao(andar: int) -> int:
    """Comida que a expedição de busca gasta. Cresce com o andar: ir fundo
    procurar custa mais — e comida é o recurso escasso do clã."""
    return 4 + int(andar) // 2


def posto_id(andar: int, tipo: str) -> str:
    return f"p{int(andar)}_{tipo}"


def pool_do_andar(andar: int) -> list:
    """Os tipos de posto que EXISTEM naquele andar (a lista conforme o andar)."""
    return [t for t, info in TIPOS_POSTO.items() if int(andar) >= info["a_partir_de"]]


def escondidos(andar: int, descobertos: dict) -> list:
    """O que ainda não foi achado naquele andar (um de cada tipo por andar)."""
    return [t for t in pool_do_andar(andar) if posto_id(andar, t) not in descobertos]


def _sortear(pares, rng):
    total = sum(p for _, p in pares)
    corte, acc = rng.uniform(0, total), 0.0
    for item, peso in pares:
        acc += peso
        if corte <= acc:
            return item
    return pares[-1][0]


def explorar(andar: int, descobertos: dict, rng: random.Random, garantido: bool = False) -> dict | None:
    """Uma busca. Devolve o posto achado, ou None (voltou sem nada).
    `garantido` = achar com certeza (a chegada de uma travessia)."""
    restantes = escondidos(andar, descobertos)
    if not restantes:
        return None
    if not garantido and rng.random() > CHANCE_DE_ACHAR:
        return None
    tipo = _sortear([(t, TIPOS_POSTO[t]["peso"]) for t in restantes], rng)
    estrelas, mult, _ = _sortear([((q, m, p), p) for q, m, p in QUALIDADES], rng)
    return {"id": posto_id(andar, tipo), "andar": int(andar), "tipo": tipo,
            "estrelas": int(estrelas), "mult": float(mult)}


def area_do_posto(posto: dict) -> dict:
    """O posto no formato de área que o AFK entende."""
    from game.clan_materiais import rende_no_andar, RANKS
    info = TIPOS_POSTO[posto["tipo"]]
    andar = int(posto["andar"])
    rende = rende_no_andar(andar)
    rank = int(info.get("rank", 1))
    return {"id": posto["id"], "andar": andar, "tipo": posto["tipo"],
            "nome": f"{info['icone']} {info['nome']} {'★' * int(posto['estrelas'])} · Andar {andar}",
            "rank": rank, "rank_nome": RANKS[rank]["nome"],
            "rende": max(1, int(round(rende["quantidade"] * info["mult"] * float(posto["mult"])))),
            "recurso": info["recurso"], "estrelas": int(posto["estrelas"])}
