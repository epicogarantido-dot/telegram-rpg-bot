# game/premium_system.py
from __future__ import annotations

import sqlite3
import threading
import time
import os

from infra.migracao import garantir_colunas, garantir_colunas_async

# 🧱 20/09/2026 — os CREATE deste arquivo viraram constantes pra que a
# MESMA string crie a tabela e migre banco velho (infra/migracao.py).
# Coluna nova entra aqui e chega sozinha em quem já tinha a tabela.
_SQL_PLAYER_REGISTRY = """CREATE TABLE IF NOT EXISTS player_registry (
                    player_id TEXT PRIMARY KEY,
                    user_id INTEGER UNIQUE,
                    chat_id INTEGER,
                    created_at INTEGER,
                    last_seen INTEGER
                )"""
_SQL_PREMIUM_HISTORY = """CREATE TABLE IF NOT EXISTS premium_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    player_id TEXT,
                    user_id INTEGER,
                    chat_id INTEGER,
                    amount INTEGER,
                    reason TEXT,
                    timestamp INTEGER
                )"""
_SQL_PREMIUM_WALLET = """CREATE TABLE IF NOT EXISTS premium_wallet (
                    player_id TEXT PRIMARY KEY,
                    user_id INTEGER,
                    chat_id INTEGER,
                    premium INTEGER DEFAULT 0,
                    updated_at INTEGER
                )"""


# 🔥 Corrigido (07/07/2026): premium_repo e player_id_gen são criados assim
# que este módulo é importado (fim do arquivo), antes de qualquer init_db()
# do resto do jogo rodar. Sem a pasta "data/" isso derrubava o bot com
# "unable to open database file" logo na inicialização.
os.makedirs("data", exist_ok=True)


def _now() -> int:
    return int(time.time())


def _millis() -> int:
    return int(time.time() * 1000)


def _get_int(p: dict, *keys: str, default: int = 0) -> int:
    for k in keys:
        v = p.get(k)
        if v is None:
            continue
        try:
            return int(v)
        except:
            pass
    return int(default)


def _get_str(p: dict, *keys: str, default: str = "") -> str:
    for k in keys:
        v = p.get(k)
        if v is None:
            continue
        s = str(v).strip()
        if s:
            return s
    return default


# ==========================================
# BANCO DE MOEDAS PREMIUM (SEPARADO)
# ==========================================
class PremiumRepo:
    def __init__(self, db_path: str = "data/premium.db"):
        self.db_path = db_path
        self._lock = threading.RLock()
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        # WAL melhora concorrência leitura/escrita e é habilitado por PRAGMA journal_mode=WAL [web:15]
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def _init_db(self) -> None:
        conn = self._conn()
        try:
            c = conn.cursor()
            # chat_id NÃO é UNIQUE aqui (evita travar quando o player fala em outro chat)
            c.execute(
                _SQL_PREMIUM_WALLET
            )
            garantir_colunas(c, _SQL_PREMIUM_WALLET)  # 🧱 migra o que o CREATE tem e o disco não
            c.execute(
                _SQL_PREMIUM_HISTORY
            )
            garantir_colunas(c, _SQL_PREMIUM_HISTORY)  # 🧱 migra o que o CREATE tem e o disco não
            c.execute(
                "CREATE INDEX IF NOT EXISTS idx_premium_history_player_ts ON premium_history(player_id, timestamp)"
            )
            conn.commit()
        finally:
            conn.close()

    def ensure_wallet(self, player_id: str, chat_id: int, user_id: int) -> None:
        if not player_id:
            return
        with self._lock:
            now = _now()
            conn = self._conn()
            try:
                conn.execute(
                    """
                    INSERT INTO premium_wallet (player_id, user_id, chat_id, premium, updated_at)
                    VALUES (?, ?, ?, 0, ?)
                    ON CONFLICT(player_id) DO UPDATE SET
                        user_id = excluded.user_id,
                        chat_id = excluded.chat_id,
                        updated_at = excluded.updated_at
                    """,
                    (player_id, int(user_id), int(chat_id), now),
                )
                conn.commit()
            finally:
                conn.close()

    def get_premium(self, player_id: str) -> int:
        if not player_id:
            return 0
        with self._lock:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT premium FROM premium_wallet WHERE player_id = ?",
                    (player_id,),
                ).fetchone()
                return int(row[0]) if row else 0
            finally:
                conn.close()

    def add_premium(self, player_id: str, amount: int, reason: str = "") -> tuple[bool, int]:
        if not player_id:
            return False, 0
        with self._lock:
            conn = self._conn()
            try:
                now = _now()
                conn.execute("BEGIN IMMEDIATE")
                row = conn.execute(
                    """
                    UPDATE premium_wallet
                       SET premium = premium + ?, updated_at = ?
                     WHERE player_id = ?
                 RETURNING premium, user_id, chat_id
                    """,
                    (int(amount), now, player_id),
                ).fetchone()

                if not row:
                    conn.rollback()
                    return False, 0

                new_balance, user_id, chat_id = int(row[0]), int(row[1]), int(row[2])
                conn.execute(
                    """
                    INSERT INTO premium_history (player_id, user_id, chat_id, amount, reason, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (player_id, user_id, chat_id, int(amount), str(reason), now),
                )
                conn.commit()
                return True, new_balance
            except:
                conn.rollback()
                return False, 0
            finally:
                conn.close()

    def spend_premium(self, player_id: str, cost: int, reason: str = "") -> tuple[bool, int]:
        if not player_id:
            return False, 0
        cost = int(cost)
        if cost <= 0:
            return False, self.get_premium(player_id)

        with self._lock:
            conn = self._conn()
            try:
                now = _now()
                conn.execute("BEGIN IMMEDIATE")
                # RETURNING evita SELECT extra e mantém operação atômica no SQLite [web:17]
                row = conn.execute(
                    """
                    UPDATE premium_wallet
                       SET premium = premium - ?, updated_at = ?
                     WHERE player_id = ? AND premium >= ?
                 RETURNING premium, user_id, chat_id
                    """,
                    (cost, now, player_id, cost),
                ).fetchone()

                if not row:
                    conn.rollback()
                    return False, self.get_premium(player_id)

                new_balance, user_id, chat_id = int(row[0]), int(row[1]), int(row[2])
                conn.execute(
                    """
                    INSERT INTO premium_history (player_id, user_id, chat_id, amount, reason, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (player_id, user_id, chat_id, -cost, str(reason), now),
                )
                conn.commit()
                return True, new_balance
            except:
                conn.rollback()
                return False, self.get_premium(player_id)
            finally:
                conn.close()
    def get_or_create_wallet(self, player_id: str, chat_id: int, user_id: int):
        """Cria carteira se não existir."""
        PREMIUM_DB = "data/premium.db"  # ou o caminho do teu banco premium
    
        import sqlite3
        import time
    
        conn = sqlite3.connect(PREMIUM_DB)
        c = conn.cursor()
    
        c.execute("""
            INSERT OR IGNORE INTO wallets (player_id, chat_id, user_id, balance, created_at)
            VALUES (?, ?, ?, 0, ?)
    """, (player_id, chat_id, user_id, int(time.time())))
    
        conn.commit()
        conn.close()
        return True
# ==========================================
# GERADOR DE PLAYER ID ÚNICO (DO TEU CÓDIGO)
# ==========================================
class PlayerIDGenerator:
    """
    Gera 1 player_id e salva; depois sempre retorna o mesmo.
    Lookup por user_id (estável), e guarda chat_id só como last_seen/último chat.
    """
    def __init__(self, db_path: str = "data/player_ids.db"):
        self.db_path = db_path
        self._lock = threading.RLock()
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def _init_db(self) -> None:
        conn = self._conn()
        try:
            conn.execute(
                _SQL_PLAYER_REGISTRY
            )
            garantir_colunas(conn, _SQL_PLAYER_REGISTRY)  # 🧱 migra o que o CREATE tem e o disco não
            conn.execute("CREATE INDEX IF NOT EXISTS idx_player_registry_user ON player_registry(user_id)")
            conn.commit()
        finally:
            conn.close()

    def get_or_create_id(self, chat_id: int, user_id: int) -> str:
        chat_id = int(chat_id)
        user_id = int(user_id)
        if not user_id:
            return ""

        with self._lock:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT player_id FROM player_registry WHERE user_id = ?",
                    (user_id,),
                ).fetchone()

                now = _now()
                if row:
                    pid = str(row[0])
                    conn.execute(
                        "UPDATE player_registry SET chat_id = ?, last_seen = ? WHERE user_id = ?",
                        (chat_id, now, user_id),
                    )
                    conn.commit()
                    return pid

                # ID único gerado pelo teu código (não UUID)
                pid = f"PLY-{user_id}-{_millis()}"
                conn.execute(
                    """
                    INSERT INTO player_registry (player_id, user_id, chat_id, created_at, last_seen)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (pid, user_id, chat_id, now, now),
                )
                conn.commit()
                return pid
            finally:
                conn.close()


# ==========================================
# INSTÂNCIAS GLOBAIS
# ==========================================
premium_repo = PremiumRepo()
player_id_gen = PlayerIDGenerator()


# ==========================================
# BOOTSTRAP + CACHE (silencioso)
# ==========================================
def ensure_premium_player(p: dict, chat_id: int | None = None, user_id: int | None = None, sync_fn=None) -> str:
    """
    Chame no começo de TODO callback/comando.
    - garante player_id em p
    - garante wallet no premium.db
    - corrige p['premium'] silenciosamente
    """
    chat_id = int(chat_id) if chat_id is not None else _get_int(p, "chatid", "chat_id", default=0)
    user_id = int(user_id) if user_id is not None else _get_int(p, "userid", "user_id", default=0)

    pid = _get_str(p, "player_id", "playerid", default="")
    if not pid:
        pid = player_id_gen.get_or_create_id(chat_id, user_id)
        if not pid:
            return ""

    p["player_id"] = pid
    p["playerid"] = pid  # compat se teu jogo usa esse nome

    premium_repo.ensure_wallet(pid, chat_id, user_id)

    bal = premium_repo.get_premium(pid)
    if int(p.get("premium", 0) or 0) != int(bal):
        p["premium"] = int(bal)
        if callable(sync_fn):
            sync_fn(p)  # silencioso

    return pid