"""
Clã: tabelas e o tick do AFK.

DUAS BALIZAS SEPARADAS, E ISSO É O PONTO
----------------------------------------
Medido: com tick de 15 min e 30% dos ticks virando encontro, 8 horas fora
dão 32 ticks e ~10 encontros. Um cavaleiro de perfil 5,9% ("morre se
esbarrar no chefe") tem 43% de não estar lá de manhã. Ninguém joga assim.

Mas baixar o teto de ticks pra consertar isso corta junto o que o jogador
RECEBE — storylets pra ler, recursos pra gastar. Ficaria seguro e vazio.

Então são dois tetos:
    TETO_TICKS     — quanto o mundo andou (recursos, storylets, membros)
    TETO_ENCONTROS — quanto perigo o cavaleiro comeu

Quanta história você recebe e quanto risco você corre são recursos
diferentes. Fundir os dois num número só foi o erro da primeira conta.

Com TETO_ENCONTROS = 4:
    perfil  0%   -> eterno (ele vence tudo que mora lá)
    perfil  5,9% -> ~21% de morte por sessão, dura ~5 sessões
    perfil 29%   -> ~76% por sessão, dura ~1
Ou seja: área folgada é folgada, esticar custa caro, e a diferença entre
as duas é visível ANTES de mandar.

POR QUE O TEMPO NÃO ACUMULA PARA SEMPRE
---------------------------------------
Ficar três dias fora não pode virar 300 situações pra resolver. Isso não é
recompensa, é dever de casa — e faz o jogador evitar voltar. O tempo acima
do teto simplesmente não rende: o clã descansou.
"""
from __future__ import annotations

import json
import random
import time

INTERVALO_TICK = 15 * 60      # um tick a cada 15 minutos de mundo
TETO_TICKS = 24               # ~6h de acúmulo por sessão
SESSOES_DE_COMIDA_INICIAL = 20   # (25/09) reserva inicial de comida do clã
GUARDAS_PREVISTOS_NA_RESERVA = 4  # (25/09) 2 equipes × 2 guardas
FERRO_DE_FORJA_INICIAL = 100      # (26/09) 4 peças comuns na Forja (25 de ferro cada)
TETO_ENCONTROS = 4            # quanto perigo cabe numa sessão
TETO_SITUACOES = 12           # fila máxima de coisas pra resolver no login
SESSOES_NO_DIARIO = 5         # quantas sessões passadas o diário guarda

# ------------------------------------------------------------------ a ração
#
# QUEM COME, E POR QUÊ SÓ ELE
# ---------------------------
# Come quem está EM POSTO. Quem ficou na aldeia se vira — não porque seja
# realista, mas porque é o que dá saída ao jogador: se a comida acabou, ele
# recolhe o pessoal e o clã se recupera. Fome que cobra de todo mundo o
# tempo todo não é decisão, é imposto por jogar; e sem porta de saída ela
# vira espiral sem fundo, que com morte permanente é armadilha.
#
# O NÚMERO, MEDIDO
# ----------------
# A renda de comida do jogo tem teto duro: só o Andar 1 alimenta (a regra é
# `comida if andar <= 5`, e `areas_disponiveis` anda de 5 em 5, então a
# única área de comida que existe é a do andar 1), e ele rende 2 por coleta
# — ~24 por sessão, em qualquer nível. Com 1 comida por membro postado a
# cada 4 ticks (6 por sessão cheia):
#
#     3 postados, 1 deles na comida    +6 por sessão   sustentável, apertado
#     3 postados, nenhum na comida    -18 por sessão   custa 8🥉 de 73
#     5 postados, 1 deles na comida    -6 por sessão   custa 2🥉 de 208
#     5 postados, nenhum na comida    -30 por sessão   custa 12🥉 de 191
#
# É esse o desenho: cedo, alimentar custa um CORPO (alguém tem que ficar no
# andar raso, que não rende material); tarde, custa BRONZE, via o serviço
# 'mantimentos' da aldeia, que já existia justamente pra isso. A pressão
# fica onde deve ficar — no começo, quando ainda há pouca gente.
RACAO_TICKS = 4               # 1 comida por membro postado a cada 4 ticks

# ---------------------------------------------------------------- recursos
#
# O clã vive de quatro coisas, e cada área rende UMA. Com 5 membros e 4
# recursos, postar vira a decisão central: dá pra cobrir os quatro e sobrar
# um, ou concentrar em dois e aceitar ficar sem os outros.
#
#   🌾 comida   ração; sem ela o membro perde atributo no combate
#   🪵 madeira  construções, e reerguer o acampamento quando o clã muda
#   🐂 couro    abrigo e vestimenta — protege do andar, não do monstro
#   ⛏️ metal    armas e armaduras; é o ÚNICO com ranks, porque é onde o
#               rank decide poder (300 de metal bruto não fazem uma peça
#               rúnica). Guardado na coluna `materiais`, que sempre
#               significou "material com rank" — renomear a coluna só
#               arriscaria os dados de quem já joga.
#
# ⚠️ A TABELA ABAIXO TEM DUAS AMARRAS, e mexer nela sem conferir as duas
# quebra coisa medida:
#
#  1. Cada rank de metal (1-5) precisa de UMA área na sua faixa de andares,
#     senão o equipamento daquele rank fica inalcançável (auditar_materiais).
#  2. A melhor área de comida tem que continuar sendo o Andar 5 (rende 6):
#     a renda de ~85/sessão que calibra a ração saiu dali (auditar_fome).
#     Por isso a comida caiu de três andares pra dois — 1 e 5 — sem que a
#     renda mudasse, já que o 3 nunca era o melhor.
RECURSO_DO_ANDAR = {
    1: "comida",  3: "madeira", 5: "comida", 7: "couro", 9: "metal",
    11: "madeira", 16: "metal",
    21: "couro",   26: "metal",
    31: "madeira", 36: "metal",
    41: "couro",   46: "metal",
}
RECURSOS = ("comida", "madeira", "couro", "metal")

# Mantido porque o resto do código pergunta "esta área alimenta?".
ANDAR_MAXIMO_DE_COMIDA = 5

# Fome e ferimento derrubam ATRIBUTO no perfil de combate. O teto existe pra
# o buraco ter fundo: sem ele, uma sequência ruim vira morte certa e o
# jogador não tem mais o que decidir.
#
# Medido com fome no teto: a chance de morte muda em 6 de 16 combinações de
# (área, nível), com saltos de +23 a +47 pontos. Não muda nada pra quem está
# muito à frente nem pra quem já estava perdido — morde exatamente na
# fronteira. Na prática, clã com fome farma cerca de meia faixa mais raso.
FOME_MAX = 6
FERIMENTO_MAX = 5


def _conn():
    from game.sql_repo import get_connection
    return get_connection()


# =============================================================================
# 📐 SCHEMA — UMA FONTE DE VERDADE SÓ
# =============================================================================
# ⚠️ 17/09/2026 — o jogo estourava em produção com
# `sqlite3.OperationalError: no such column: equip_poder`.
#
# A causa: `CREATE TABLE IF NOT EXISTS` não faz NADA numa tabela que já
# existe. O banco de produção foi criado antes de `equip_poder`,
# `equip_rank`, `perfil_json` e `perfil_nivel` entrarem no CREATE — e como
# nunca houve migração aqui, essas colunas simplesmente não existiam lá. O
# CREATE parecia certo lendo o código e estava errado no disco. `fome` e
# `ferimento` corriam o mesmo risco.
#
# A correção não é acrescentar um ALTER pra cada coluna que faltou: seria a
# mesma armadilha esperando a próxima. A lista abaixo é a ÚNICA fonte —
# dela sai o CREATE e dela sai a migração. Coluna nova não tem como existir
# num lugar e faltar no outro, porque só existe um lugar.
#
# (O `players` de `sql_repo.py` já tinha migração, mas no formato antigo:
# CREATE de um lado, dicionário de ALTERs do outro, sincronizados na mão.)

TABELAS = {
    "clan": {
        "colunas": [
            ("owner_id", "INTEGER PRIMARY KEY"),
            ("nome", "TEXT DEFAULT ''"),
            ("comida", "INTEGER DEFAULT 0"),
            # 18/09: madeira e couro entraram com o clã de quatro recursos.
            # Bancos antigos ganham as colunas pela migração de _garantir_tabela.
            ("madeira", "INTEGER DEFAULT 0"),
            ("couro", "INTEGER DEFAULT 0"),
            # Material é por RANK, não um número só: 300 de rank 1 não fazem
            # uma peça de rank 3. Guardar somado apagaria justamente a
            # informação que faz o jogador escolher onde farmar.
            ("materiais", "TEXT DEFAULT '{}'"),
            ("comodidades", "TEXT DEFAULT '{}'"),
            # Arsenal: as peças forjadas que ainda não estão em ninguém. Fica
            # no clã, não no membro, porque a distribuição é automática e
            # refeita a cada sessão.
            ("arsenal", "TEXT DEFAULT '[]'"),
            ("ultimo_tick", "INTEGER DEFAULT 0"),
            ("situacoes", "TEXT DEFAULT '[]'"),
            ("diario", "TEXT DEFAULT '[]'"),
            # 🏘️ 20/09: Memórias do Clã — o livro do que marcou a aldeia
            # (chegadas, despertares de Aura, mortes, estágios). Diferente
            # do diário, que guarda as últimas sessões e esquece: aqui fica
            # a história, com teto só pra não virar arquivo morto.
            ("memorias", "TEXT DEFAULT '[]'"),
            # O estágio é DERIVADO (gente + construções). Este campo guarda só
            # o último visto, pra saber quando ele SUBIU e escrever nas Memórias.
            ("estagio_registrado", "INTEGER DEFAULT 0"),
            # 20/09: chefes por cargo ({cargo: id do habitante}), a identidade
            # da aldeia (lista de especializações) e as regras de automação.
            ("comandantes", "TEXT DEFAULT '{}'"),
            ("especializacoes", "TEXT DEFAULT '[]'"),
            ("regras", "TEXT DEFAULT '{}'"),
            # 🗺️ O ÚNICO ponto do mapa que o clã ocupa (regra: um por vez).
            ("ponto_id", "INTEGER"),
            # 👷 Mão de obra contratada na aldeia: a PRÓXIMA construção sai
            # mais barata e o desconto é consumido nela. 0 = nada contratado.
            ("mao_de_obra", "REAL DEFAULT 0"),
            # 🧭 A travessia em andamento (JSON do `clan_jornada`), ou vazio.
            ("jornada", "TEXT"),
            # 🧭 O andar onde o clã ESTÁ. Travessia leva ao seguinte.
            ("andar", "INTEGER DEFAULT 1"),
            # 🔎 Os postos que o clã JÁ ACHOU explorando ({id: posto}).
            ("postos", "TEXT DEFAULT '{}'"),
            # 👥 As equipes em cada posto ({posto_id: {coletores, guardas}}).
            # A chave especial "ponto" é a equipe que segura/ataca o ponto do mapa.
            ("equipes", "TEXT DEFAULT '{}'"),
            # ⚔️ Fase 3: o que a equipe do ponto faz quando atacada por outro
            # jogador ('lutar' | 'fugir'), e o poder do personagem do dono se
            # ele estiver de guarda (0 = não está).
            ("defesa", "TEXT DEFAULT 'lutar'"),
            # 🔎 A última busca: {"equipe": chave, "lista": [5 achados]}.
            ("achados", "TEXT DEFAULT '{}'"),
            # 🏺 Relíquias: {"acervo": [ids achados], "ativas": [até 3]}.
            ("reliquias", "TEXT DEFAULT '{}'"),
            ("guarda_pessoal", "INTEGER DEFAULT 0"),
            # ⏳ (25/09) quando o clã entrou no ponto atual — o refúgio
            # abriga por ESTADIA_SEG e depois o clã sai.
            ("ponto_desde", "INTEGER"),
            # 👥 (25/09) o clã já ganhou a população mínima (50)? uma vez só
            ("populacao_inicial", "INTEGER DEFAULT 0"),
            # 📖 (26/09) Crônicas — o sistema novo de storylets (game/cronicas.py)
            ("cronicas", "TEXT DEFAULT '{}'"),
        ],
        "extra": [],
    },
    # 🏘️ 20/09: quem mora na aldeia e NÃO usa aura. Os 5 lutadores continuam
    # em clan_membro (são os slots da conta); aqui é a gente que trabalha
    # enquanto eles lutam. Ver game/clan_habitantes.py.
    "clan_habitante": {
        "colunas": [
            ("id", "INTEGER PRIMARY KEY AUTOINCREMENT"),
            ("owner_id", "INTEGER NOT NULL"),
            ("nome", "TEXT DEFAULT ''"),
            ("profissao", "TEXT DEFAULT 'agricultor'"),
            ("nivel", "INTEGER DEFAULT 1"),
            ("xp", "INTEGER DEFAULT 0"),
            ("potencial", "INTEGER DEFAULT 1"),
            ("fadiga", "INTEGER DEFAULT 0"),
            ("descansando", "INTEGER DEFAULT 0"),
            ("aura", "INTEGER DEFAULT 0"),
            ("vivo", "INTEGER DEFAULT 1"),
            ("causa", "TEXT"),
            ("morreu_em", "INTEGER"),
            ("chegou_em", "INTEGER DEFAULT 0"),
            # Família: de quem é parente, e o laço ("irmã", "filho"...).
            ("parente_de", "INTEGER"),
            ("laco", "TEXT"),
            # 👥 Equipes (20/09): estrelas em cada profissão (0 = não pode),
            # a função atual ('coletor' | 'guarda' | vazio = na aldeia) e o
            # posto da equipe em que está.
            ("talentos", "TEXT DEFAULT '{}'"),
            ("funcao", "TEXT"),
            ("equipe", "TEXT"),
            # ⚒️ Ferreiro (fase 2): tier da ferramenta e do equipamento (1–5).
            # Quem chega novo nasce no 1 e precisa ser nivelado.
            ("tier_ferramenta", "INTEGER DEFAULT 1"),
            ("tier_equipamento", "INTEGER DEFAULT 1"),
            # ⚒️ desde a 2ª rodada: o tier de CADA função ({função: tier})
            ("tiers", "TEXT DEFAULT '{}'"),
            # ⚔️ (28/09) cavaleiro: a profissão (classe) do personagem que
            # virou cavaleiro; vazio = aldeão comum. E até quando treina.
            ("cavaleiro", "TEXT"),
            ("treino_ate", "INTEGER DEFAULT 0"),
            # 💰 (28/09) cavaleiro: soldo pago até quando
            ("soldo_ate", "INTEGER DEFAULT 0"),
        ],
        "extra": [],
    },
    "clan_membro": {
        "colunas": [
            ("owner_id", "INTEGER NOT NULL"),
            ("slot", "INTEGER NOT NULL"),
            ("nome", "TEXT DEFAULT ''"),
            ("nivel", "INTEGER DEFAULT 1"),
            ("area_id", "TEXT"),
            ("posto_id", "TEXT"),
            ("fome", "INTEGER DEFAULT 0"),
            ("ferimento", "INTEGER DEFAULT 0"),
            ("vivo", "INTEGER DEFAULT 1"),
            ("morreu_em", "INTEGER"),
            ("causa_morte", "TEXT"),
            ("perfil_json", "TEXT"),
            ("perfil_nivel", "INTEGER DEFAULT 0"),
            ("equip_poder", "INTEGER DEFAULT 0"),
            ("equip_rank", "INTEGER"),
            # ⚔️ Cultivo em batalha (25/09/2026): o personagem luta no andar
            # do clã enquanto você não está e ganha XP (o antigo Cultivo de
            # Aura). `cultivo_json` guarda o perfil de risco e a última sessão.
            ("batalhando", "INTEGER DEFAULT 0"),
            ("cultivo_json", "TEXT"),
        ],
        "extra": ["PRIMARY KEY (owner_id, slot)"],
    },
}

TABELAS["territorio"] = {
    # 🗺️ O mapa é COMPARTILHADO: uma linha por ponto, sem owner_id na chave.
    # Quem é dono está nas colunas dono_*. Ver game/territorio.py.
    "colunas": [
        ("id", "INTEGER PRIMARY KEY AUTOINCREMENT"),
        ("tipo", "TEXT NOT NULL"),
        ("nome", "TEXT DEFAULT ''"),
        ("tier", "INTEGER DEFAULT 1"),
        # 🗺️ (20/09) o andar do ponto: 3 de cada tipo em CADA andar
        ("andar", "INTEGER"),
        ("seguro", "INTEGER DEFAULT 0"),
        ("dono_tipo", "TEXT"),
        ("dono_id", "TEXT"),
        ("dono_nome", "TEXT"),
        ("guarnicao", "INTEGER DEFAULT 0"),
        ("integridade", "INTEGER DEFAULT 100"),
        ("desde", "INTEGER DEFAULT 0"),
    ],
    "extra": [],
}

INDICES = [
    "CREATE INDEX IF NOT EXISTS idx_clan_membro_owner ON clan_membro(owner_id)",
    "CREATE INDEX IF NOT EXISTS idx_clan_habitante_owner ON clan_habitante(owner_id)",
    # o mapa tem ~1.100 pontos; a tela só pede os do andar do clã
    "CREATE INDEX IF NOT EXISTS idx_territorio_andar ON territorio(andar)",
]


def _colunas_existentes(c, tabela: str) -> list:
    return [linha[1] for linha in c.execute(f"PRAGMA table_info({tabela})").fetchall()]


def _garantir_tabela(c, tabela: str, definicao: dict) -> list:
    """Cria a tabela se não existir e acrescenta as colunas que faltarem.

    Devolve as colunas que precisaram ser adicionadas — quem chama imprime,
    porque migração silenciosa é a que ninguém percebe que não rodou.
    """
    partes = [f"{nome} {tipo}" for nome, tipo in definicao["colunas"]]
    partes += definicao.get("extra", [])
    c.execute(f"CREATE TABLE IF NOT EXISTS {tabela} ({', '.join(partes)})")

    existentes = set(_colunas_existentes(c, tabela))
    adicionadas = []
    for nome, tipo in definicao["colunas"]:
        if nome in existentes:
            continue
        if "PRIMARY KEY" in tipo.upper():
            # SQLite não deixa adicionar chave primária depois. Se faltou,
            # a tabela é velha demais pra consertar sozinha.
            print(f"[clan] ⚠️ {tabela}.{nome} é chave primária e não pode ser "
                  f"adicionada por ALTER — banco antigo demais.")
            continue
        try:
            c.execute(f"ALTER TABLE {tabela} ADD COLUMN {nome} {tipo}")
            adicionadas.append(nome)
        except Exception as e:
            print(f"[clan] ⚠️ não consegui adicionar {tabela}.{nome}: {e}")
    return adicionadas


def init_clan() -> None:
    with _conn() as c:
        for tabela, definicao in TABELAS.items():
            novas = _garantir_tabela(c, tabela, definicao)
            if novas:
                print(f"[clan] migração: {tabela} ganhou {', '.join(novas)}")
        for sql in INDICES:
            c.execute(sql)
        c.commit()
    migrar_talentos_antigos()


def migrar_talentos_antigos() -> int:
    """⭐ (25/09) Aldeão de antes dos talentos veio convertido com UMA
    estrela só (a profissão antiga). Ganha o sorteio completo, uma vez:
    fica com o MAIOR entre o que já tinha e o sorteado. O sorteio novo
    sempre grava todas as profissões (inclusive as de 0★), então quem já
    passou por aqui não entra de novo. Semente pelo id: reinício do
    servidor não re-sorteia diferente."""
    from game.clan_equipes import sortear_talentos, PROFISSOES as _P
    mudou = 0
    with _conn() as c:
        linhas = c.execute("SELECT id, talentos FROM clan_habitante WHERE vivo = 1").fetchall()
        for hid, bruto in linhas:
            try:
                atual = json.loads(bruto or "{}") or {}
            except ValueError:
                atual = {}
            if len(atual) >= len(_P):
                continue
            novo = sortear_talentos(random.Random(int(hid) * 7919))
            for k, v in atual.items():
                novo[k] = max(int(novo.get(k, 0)), int(v))
            c.execute("UPDATE clan_habitante SET talentos = ? WHERE id = ?", (json.dumps(novo), hid))
            mudou += 1
        c.commit()
    if mudou:
        print(f"[clan] migração: {mudou} aldeão(ões) antigo(s) ganharam o sorteio completo de talentos")
    return mudou


def mudar_populacao_por_decisao(owner_id: int, qtd: int, com_aura: bool = False,
                                rng=None) -> dict:
    """👥 (25/09, revisão dos storylets) "Convidar pro clã", "Levar junto",
    "Exigir submissão"... davam `membros: +N` — uma qualidade que NADA lia:
    ninguém chegava. Agora chega gente de verdade (respeitando o limite da
    aldeia, com as Moradias) e `membros: -N` faz gente ir embora. `com_aura`
    = o "usuário de aura" recrutado chega com aura ★."""
    from game import clan_habitantes as H
    rng = rng or random.Random()
    clan = carregar_clan(owner_id)
    vivos = listar_habitantes(owner_id)
    agora = int(time.time())
    if qtd > 0:
        casa = H.moradores(vivos)               # 🏙️ cavaleiro não ocupa casa
        cap = H.estagio_da_aldeia(len(casa), clan["comodidades"] or {})["capacidade"]
        vagas = max(0, cap - len(casa))
        vem = min(int(qtd), vagas)
        em_uso = {h["nome"] for h in listar_habitantes(owner_id, incluir_mortos=True)}
        novos = []
        for _ in range(vem):
            h = H.novo_habitante(rng, em_uso)
            if com_aura:
                h["aura"] = max(1, int(h.get("aura") or 0))
            em_uso.add(h["nome"])
            novos.append(h)
        with _conn() as c:
            if novos:
                _gravar_habitantes(c, owner_id, novos, agora)
                _anotar(c, owner_id, "🚶 Chegaram pela decisão: " + ", ".join(h["nome"] for h in novos) + ".",
                        tipo="chegada")
            c.commit()
        return {"chegaram": [h["nome"] for h in novos], "sem_vaga": int(qtd) - vem}
    if qtd < 0:
        # vai embora quem não está em equipe nem tem cargo (quem sustenta a
        # aldeia não larga o posto no meio)
        livres = [h for h in vivos if not h.get("funcao") and not h.get("cargo")]
        rng.shuffle(livres)
        saem = livres[:abs(int(qtd))]
        for h in saem:
            h["vivo"] = 0
            h["causa"] = "foi embora"
        with _conn() as c:
            if saem:
                _gravar_habitantes(c, owner_id, saem, agora)
                _anotar(c, owner_id, "🚪 Foram embora: " + ", ".join(h["nome"] for h in saem) + ".",
                        tipo="partida")
            c.commit()
        return {"partiram": [h["nome"] for h in saem]}
    return {}


def garantir_populacao_inicial(owner_id: int, rng=None) -> list:
    """👥 (25/09, dev) Todo clã começa com no mínimo 50 aldeões. Uma vez só
    por clã (quem morrer depois não volta sozinho). Garante ao menos um
    guarda — sem guarda nenhuma equipe sai do portão."""
    from game import clan_habitantes as H
    clan = carregar_clan(owner_id)
    if int(clan.get("populacao_inicial") or 0):
        return []
    rng = rng or random.Random()
    vivos = listar_habitantes(owner_id)
    em_uso = {h["nome"] for h in listar_habitantes(owner_id, incluir_mortos=True)}
    novos = []
    tem_guarda = any(int((h.get("talentos") or {}).get("guarda", 0)) >= 1 for h in vivos)
    for _ in range(max(0, H.POPULACAO_INICIAL - len(vivos))):
        h = H.novo_habitante(rng, em_uso)
        if not tem_guarda:
            h["talentos"]["guarda"] = max(1, int(h["talentos"].get("guarda", 0)))
            h["profissao"] = "guarda"
            tem_guarda = True
        em_uso.add(h["nome"])
        novos.append(h)
    # 🌾 (25/09, dev) e começa com comida pra ~20 sessões: cada boca (aldeão
    # ou personagem) come 1 a cada RACAO_HABITANTE_TICKS turnos, e uma
    # sessão tem até TETO_TICKS turnos. Não diminui a fome — dá o fôlego
    # pra montar as equipes de coleta antes de apertar.
    bocas = len(vivos) + len(novos) + len(listar_membros(owner_id))
    por_sessao = TETO_TICKS // max(1, H.RACAO_HABITANTE_TICKS)
    # 🪵 medido 25/09: só com a comida, a aldeia de 50 entrava em GREVE na
    # 5ª sessão por falta de MADEIRA (a manutenção cresce com a população),
    # e em greve ninguém sai pra coletar — a reserva de comida não servia
    # pra montar as equipes. A manutenção ganha a mesma reserva de 20.
    from game.clan_equipes import manutencao_da_aldeia
    manut = manutencao_da_aldeia(list(vivos) + list(novos))
    # 🛡️ (25/09, revisão do gasto) a reserva contava a aldeia toda PARADA —
    # sem guarda. Mas equipe nenhuma sai sem guarda, e guarda gasta +12 de
    # comida, 1 de couro e 1 de ferro por sessão. Medido: com 2 equipes de
    # comida (4 guardas) o ferro inicial (20) acabava na 5ª sessão e a GREVE
    # parava toda a coleta. A reserva agora cobre os guardas de 2 equipes.
    from game.clan_equipes import MANUTENCAO as _M
    for r_, q_ in _M["guarda"].items():
        manut[r_] = int(manut.get(r_, 0)) + int(round(q_ * GUARDAS_PREVISTOS_NA_RESERVA))
    n = SESSOES_DE_COMIDA_INICIAL
    reserva = n * (por_sessao * bocas + int(manut.get("comida", 0)))
    clan_atual = carregar_clan(owner_id)
    mats = dict(clan_atual["materiais"])
    # 🔨 (26/09) + ferro de FORJA: as primeiras 4 peças comuns (25 cada)
    mats[1] = max(int(mats.get(1, 0)), n * int(manut.get("ferro", 0))) + FERRO_DE_FORJA_INICIAL
    with _conn() as c:
        if novos:
            _gravar_habitantes(c, owner_id, novos, int(time.time()))
        c.execute("UPDATE clan SET populacao_inicial = 1, comida = MAX(comida, ?),"
                  " madeira = MAX(madeira, ?), couro = MAX(couro, ?), materiais = ? WHERE owner_id = ?",
                  (reserva, n * int(manut.get("madeira", 0)), n * int(manut.get("couro", 0)),
                   json.dumps({str(k): v for k, v in mats.items()}), owner_id))
        c.commit()
    return [h["nome"] for h in novos]


# ------------------------------------------------------------------ leitura

def carregar_clan(owner_id: int) -> dict:
    with _conn() as c:
        linha = c.execute("SELECT * FROM clan WHERE owner_id = ?", (owner_id,)).fetchone()
        if not linha:
            c.execute("INSERT INTO clan(owner_id, ultimo_tick) VALUES (?,?)",
                      (owner_id, int(time.time())))
            c.commit()
            linha = c.execute("SELECT * FROM clan WHERE owner_id = ?", (owner_id,)).fetchone()
        clan = dict(linha)
    clan["situacoes"] = []      # 🧹 26/09: sistema antigo de decisões desligado
    clan["diario"] = json.loads(clan.get("diario") or "[]")
    # 3 ranks desde 20/09 (o rank é do monstro): material velho de rank 4/5
    # (banco de antes) entra no 3, em vez de ficar num rank que nada usa.
    bruto = json.loads(clan.get("materiais") or "{}")   # lê ANTES de sobrescrever
    clan["materiais"] = {}
    for k, v in bruto.items():
        r = min(3, max(1, int(k)))
        clan["materiais"][r] = clan["materiais"].get(r, 0) + int(v)
    clan["comodidades"] = json.loads(clan.get("comodidades") or "{}")
    clan["arsenal"] = json.loads(clan.get("arsenal") or "[]")
    clan["memorias"] = json.loads(clan.get("memorias") or "[]")
    clan["comandantes"] = json.loads(clan.get("comandantes") or "{}")
    clan["especializacoes"] = json.loads(clan.get("especializacoes") or "[]")
    clan["regras"] = json.loads(clan.get("regras") or "{}")
    return clan


def config_da_aldeia(clan: dict) -> dict:
    """O que a sessão da aldeia precisa saber do clã, num lugar só."""
    from game.cronicas import chance_ataque_extra
    return {"comandantes": clan.get("comandantes") or {},
            "especializacoes": clan.get("especializacoes") or [],
            "regras": clan.get("regras") or {},
            # ⚔️ (26/09) guerra com clã NPC (Crônicas): a cidade é mais atacada
            "chance_ataque_extra": chance_ataque_extra(clan)}


# ------------------------------------------------------------ habitantes

MEMORIAS_MAX = 80
CAMPOS_HABITANTE = ("nome", "profissao", "nivel", "xp", "potencial", "fadiga",
                    "descansando", "aura", "vivo", "causa", "morreu_em",
                    "parente_de", "laco", "talentos", "funcao", "equipe",
                    "tier_ferramenta", "tier_equipamento", "tiers", "cavaleiro", "treino_ate", "soldo_ate")


def _talentos_do_habitante(h: dict) -> dict:
    """Talentos gravados, ou — habitante de antes de 20/09 — a estrela de
    potencial na profissão que ele já tinha (o resto 0★)."""
    bruto = h.get("talentos")
    if isinstance(bruto, dict) and bruto:
        return bruto
    try:
        t = json.loads(bruto) if bruto else {}
    except ValueError:
        t = {}
    if not t:
        t = {h.get("profissao") or "agricultor": int(h.get("potencial") or 1)}
    return {k: int(v) for k, v in t.items()}


def _valor_gravavel(chave: str, valor):
    return json.dumps(valor) if chave in ("talentos", "tiers") and isinstance(valor, dict) else valor


def listar_habitantes(owner_id: int, incluir_mortos: bool = False) -> list:
    sql = "SELECT * FROM clan_habitante WHERE owner_id = ?"
    if not incluir_mortos:
        sql += " AND vivo = 1"
    with _conn() as c:
        linhas = [dict(l) for l in c.execute(sql + " ORDER BY id", (owner_id,)).fetchall()]
    for h in linhas:
        h["talentos"] = _talentos_do_habitante(h)
        try:
            h["tiers"] = json.loads(h.get("tiers") or "{}") if not isinstance(h.get("tiers"), dict) else h["tiers"]
        except ValueError:
            h["tiers"] = {}
    return linhas


def _gravar_habitantes(c, owner_id: int, habitantes: list, agora: int) -> None:
    """Grava o estado que `clan_habitantes` mutou. Habitante sem `id` é
    gente que CHEGOU nesta sessão e ganha linha nova."""
    for h in habitantes:
        if h.get("id"):
            if not int(h.get("vivo", 1)) and not h.get("morreu_em"):
                h["morreu_em"] = agora
            sets = ", ".join(f"{k} = ?" for k in CAMPOS_HABITANTE)
            c.execute(f"UPDATE clan_habitante SET {sets} WHERE id = ? AND owner_id = ?",
                      tuple(_valor_gravavel(k, h.get(k)) for k in CAMPOS_HABITANTE)
                      + (int(h["id"]), owner_id))
        else:
            c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, xp,"
                      " potencial, fadiga, descansando, aura, vivo, chegou_em, parente_de, laco,"
                      " talentos, funcao, equipe, cavaleiro, treino_ate, soldo_ate)"
                      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (owner_id, h["nome"], h["profissao"], h["nivel"], h["xp"],
                       h["potencial"], h["fadiga"], h["descansando"], h["aura"], 1, agora,
                       h.get("parente_de"), h.get("laco"),
                       json.dumps(h.get("talentos") or {}), h.get("funcao"), h.get("equipe"),
                       h.get("cavaleiro"), int(h.get("treino_ate") or 0), int(h.get("soldo_ate") or 0)))


def _somar_memorias(clan: dict, novas: list, agora: int) -> list:
    registro = [{"quando": agora, **m} for m in novas]
    return (registro + list(clan.get("memorias") or []))[:MEMORIAS_MAX]


def acolher_habitante(owner_id: int, rng: random.Random | None = None) -> dict:
    """Recebe alguém na aldeia: custa comida e precisa de lugar.

    O custo é em COMIDA, e não em ouro, de propósito: gente nova é boca
    nova. Pagar com moeda deixaria crescer sem pensar se dá pra alimentar.
    """
    from game import clan_habitantes as H
    rng = rng or random.Random()
    clan = carregar_clan(owner_id)
    vivos = listar_habitantes(owner_id)
    casa = H.moradores(vivos)                   # 🏙️ cavaleiro não ocupa casa
    estagio = H.estagio_da_aldeia(len(casa), clan["comodidades"] or {})
    estagio["capacidade"] += H.modificadores_da_aldeia(vivos, config_da_aldeia(clan))["capacidade"]
    if len(casa) >= estagio["capacidade"]:
        return {"ok": False, "erro": f"A aldeia está cheia ({estagio['nome']}: "
                                     f"{estagio['capacidade']} lugares). Construa ou cresça de estágio."}
    if int(clan["comida"]) < H.CUSTO_ACOLHER:
        return {"ok": False, "erro": f"Precisa de {H.CUSTO_ACOLHER} de comida pra receber alguém."}
    todos = listar_habitantes(owner_id, incluir_mortos=True)
    novo = H.novo_habitante(rng, {h["nome"] for h in todos})
    laco = H.ligar_parente(novo, vivos, rng)
    agora = int(time.time())
    texto = (f"🚶 {novo['nome']} foi acolhido na aldeia "
             f"({H.PROFISSOES[novo['profissao']]['nome']}, {'★' * novo['potencial']})"
             + (f" — é {laco}." if laco else "."))
    with _conn() as c:
        c.execute("UPDATE clan SET comida = comida - ? WHERE owner_id = ? AND comida >= ?",
                  (H.CUSTO_ACOLHER, owner_id, H.CUSTO_ACOLHER))
        _gravar_habitantes(c, owner_id, [novo], agora)
        c.execute("UPDATE clan SET memorias = ? WHERE owner_id = ?",
                  (json.dumps(_somar_memorias(clan, [{"tipo": "chegada", "texto": texto}], agora)),
                   owner_id))
        c.commit()
    return {"ok": True, "habitante": novo["nome"], "texto": texto}


def nomear_chefe(owner_id: int, cargo: str, hab_id: int | None) -> dict:
    """Põe (ou tira, com hab_id None) um habitante num cargo.

    A validação que importa (profissão certa, aura pro Mestre) é conferida
    aqui E de novo a cada sessão em `modificadores_da_aldeia`: o chefe que
    morrer ou trocar de ofício perde o posto sozinho, sem ninguém lembrar.
    """
    from game import clan_habitantes as H
    regra = H.CARGOS.get(cargo)
    if not regra:
        return {"ok": False, "erro": "Cargo desconhecido."}
    clan = carregar_clan(owner_id)
    chefes = dict(clan["comandantes"])
    if hab_id is None:
        chefes.pop(cargo, None)
    else:
        h = next((x for x in listar_habitantes(owner_id) if int(x["id"]) == int(hab_id)), None)
        if not h:
            return {"ok": False, "erro": "Habitante não encontrado."}
        if regra["exige"] and h["profissao"] != regra["exige"]:
            return {"ok": False, "erro": f"{regra['nome']} precisa ser "
                                         f"{H.PROFISSOES[regra['exige']]['nome'].lower()}."}
        if cargo == "aura" and not int(h["aura"] or 0):
            return {"ok": False, "erro": "O Mestre da Aura precisa ter despertado a Aura."}
        # Um habitante, um cargo: chefiar duas coisas seria somar dois bônus
        # no mesmo nível, e o melhor da aldeia viraria o único que importa.
        chefes = {k: v for k, v in chefes.items() if int(v) != int(hab_id)}
        chefes[cargo] = int(hab_id)
    with _conn() as c:
        c.execute("UPDATE clan SET comandantes = ? WHERE owner_id = ?", (json.dumps(chefes), owner_id))
        c.commit()
    return {"ok": True, "comandantes": chefes}


def escolher_especializacao(owner_id: int, especializacao: str, trocar: str | None = None,
                            ouro_disponivel: int = 0) -> dict:
    """Soma uma especialização se há vaga; com `trocar`, substitui uma
    existente, cobrando OURO.

    🥇 20/09/2026: o custo saiu do bronze (que não existe mais) pro ouro do
    jogador. Mas ouro mora em `p["gold"]`, não no clã — este módulo não
    tem `p`, só `owner_id`. Por isso quem chama passa `ouro_disponivel`
    (o `p["gold"]` de quem está pedindo) e, se a troca for aprovada aqui,
    a FUNÇÃO NÃO DEBITA NADA — devolve `custo_ouro` pro chamador debitar
    de `p` e salvar. Clan_repo continua sem saber o que é `p`.
    """
    from game import clan_habitantes as H
    if especializacao not in H.ESPECIALIZACOES:
        return {"ok": False, "erro": "Especialização desconhecida."}
    clan = carregar_clan(owner_id)
    vivos = H.moradores(listar_habitantes(owner_id))
    estagio = H.estagio_da_aldeia(len(vivos), clan["comodidades"] or {})
    vagas = H.vagas_de_especializacao(estagio["indice"])
    atuais = list(clan["especializacoes"])
    if especializacao in atuais:
        return {"ok": False, "erro": "A aldeia já tem essa identidade."}
    custo_ouro = 0
    if trocar:
        if trocar not in atuais:
            return {"ok": False, "erro": "Não há essa especialização pra trocar."}
        custo_ouro = H.CUSTO_TROCAR_ESPECIALIZACAO
        if int(ouro_disponivel) < custo_ouro:
            return {"ok": False, "erro": f"Trocar custa {custo_ouro}g de ouro; "
                                         f"você tem {int(ouro_disponivel)}g."}
        atuais[atuais.index(trocar)] = especializacao
    else:
        if vagas == 0:
            return {"ok": False, "erro": "A aldeia ganha identidade ao virar Vila."}
        if len(atuais) >= vagas:
            return {"ok": False, "erro": "Sem vaga: troque uma especialização existente."}
        atuais.append(especializacao)
    with _conn() as c:
        c.execute("UPDATE clan SET especializacoes = ? WHERE owner_id = ?",
                  (json.dumps(atuais), owner_id))
        c.commit()
    return {"ok": True, "especializacoes": atuais, "custo_ouro": custo_ouro}


def definir_regras(owner_id: int, regras: dict) -> dict:
    """Grava as regras de automação, só com as chaves conhecidas e com os
    limites dentro do que faz sentido (voltar precisa ser menor que parar)."""
    from game import clan_habitantes as H
    base = {**H.REGRAS_PADRAO, **(carregar_clan(owner_id)["regras"] or {})}
    if "descanso_auto" in regras:
        base["descanso_auto"] = bool(regras["descanso_auto"])
    if "limite" in regras:
        base["limite"] = max(40, min(100, int(regras["limite"])))
    if "volta" in regras:
        base["volta"] = max(0, min(base["limite"] - 20, int(regras["volta"])))
    if "compra_comida_auto" in regras:
        base["compra_comida_auto"] = bool(regras["compra_comida_auto"])
    if "limite_ouro_comida" in regras:
        base["limite_ouro_comida"] = max(0, min(5000, int(regras["limite_ouro_comida"])))
    if "compra_materiais_auto" in regras:
        base["compra_materiais_auto"] = bool(regras["compra_materiais_auto"])
    if "limite_ouro_materiais" in regras:
        base["limite_ouro_materiais"] = max(0, min(5000, int(regras["limite_ouro_materiais"])))
    with _conn() as c:
        c.execute("UPDATE clan SET regras = ? WHERE owner_id = ?", (json.dumps(base), owner_id))
        c.commit()
    return {"ok": True, "regras": base}


# ------------------------------------------------------------- território

def garantir_mapa() -> None:
    """Semeia o que FALTA no mapa. Nunca regera: o mapa é mundo
    compartilhado, e regerar apagaria o que os jogadores conquistaram.

    20/09: antes só semeava com a tabela vazia — o que servia pro primeiro
    boot e mais nada. Quando o Covil do Chefe entrou como tipo novo, os
    bancos que já tinham os 70 pontos NUNCA ganhariam os covis (o mesmo
    buraco do `CREATE TABLE IF NOT EXISTS`, armadilha nº 14). Agora ele
    confere ponto a ponto, por (tipo, nome), e só insere o que não existe.
    """
    from game import territorio as T
    with _conn() as c:
        # 🗺️ Mapa do formato antigo (10 de cada tipo, só nos andares de chefe,
        # sem a coluna andar preenchida): o formato mudou demais pra somar
        # ponto a ponto — o mundo é refeito, e os clãs soltam o ponto antigo.
        if c.execute("SELECT COUNT(*) FROM territorio WHERE andar IS NULL").fetchone()[0]:
            c.execute("DELETE FROM territorio")
            c.execute("UPDATE clan SET ponto_id = NULL")
        # 🧹 25/09/2026: o inverso também. Ponto que o gerador de hoje não
        # cria mais (ex.: Covil fora de andar de chefe, de um mapa de versão
        # anterior) ficava pra sempre, porque aqui só se ACRESCENTAVA. Sai, e
        # o clã que estava nele solta o ponto — igual à regra do mapa velho.
        mapa = T.gerar_mapa()
        validos = {(pt["tipo"], pt["nome"]) for pt in mapa}
        velhos = [l[0] for l in c.execute("SELECT id, tipo, nome FROM territorio").fetchall()
                  if (l[1], l[2]) not in validos]
        for pid in velhos:
            c.execute("DELETE FROM territorio WHERE id = ?", (pid,))
            c.execute("UPDATE clan SET ponto_id = NULL WHERE ponto_id = ?", (pid,))
        existentes = {(l[0], l[1]) for l in
                      c.execute("SELECT tipo, nome FROM territorio").fetchall()}
        agora = int(time.time())
        for pt in mapa:
            if (pt["tipo"], pt["nome"]) in existentes:
                continue
            c.execute("INSERT INTO territorio(tipo, nome, tier, andar, seguro, dono_tipo, dono_id,"
                      " dono_nome, guarnicao, integridade, desde) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                      (pt["tipo"], pt["nome"], pt["tier"], pt["andar"], pt["seguro"], pt["dono_tipo"],
                       pt["dono_id"], pt["dono_nome"], pt["guarnicao"], pt["integridade"], agora))
        c.commit()


def listar_mapa(andar: int | None = None) -> list:
    """O mapa inteiro, ou só um andar (a tela pede só o do clã: são ~1.100
    pontos no mundo, 22 por andar)."""
    garantir_mapa()
    with _conn() as c:
        if andar is not None:
            return [dict(l) for l in c.execute(
                "SELECT * FROM territorio WHERE andar = ? ORDER BY tipo, nome", (int(andar),)).fetchall()]
        return [dict(l) for l in c.execute("SELECT * FROM territorio ORDER BY andar, tipo, nome").fetchall()]


def ponto(ponto_id: int) -> dict | None:
    with _conn() as c:
        l = c.execute("SELECT * FROM territorio WHERE id = ?", (int(ponto_id),)).fetchone()
    return dict(l) if l else None


def forca_atual(owner_id: int) -> int:
    """A força do clã AGORA — lutadores vivos + defesa da aldeia. Medida na
    hora em que é usada, nunca guardada: força guardada envelhece."""
    from game import territorio as T, clan_habitantes as H
    clan = carregar_clan(owner_id)
    habs = listar_habitantes(owner_id)
    est = H.estagio_da_aldeia(len(habs), clan["comodidades"] or {})
    defesa = H.defesa_da_aldeia(habs, est["indice"],
                                H.modificadores_da_aldeia(habs, config_da_aldeia(clan)))
    return T.forca_do_cla(listar_membros(owner_id), defesa)


def _anotar(c, owner_id: int, texto: str, tipo: str = "territorio") -> None:
    clan = carregar_clan(owner_id)
    agora = int(time.time())
    c.execute("UPDATE clan SET memorias = ? WHERE owner_id = ?",
              (json.dumps(_somar_memorias(clan, [{"tipo": tipo, "texto": texto}], agora)), owner_id))


def _largar(c, owner_id: int, ponto_id: int | None) -> None:
    """Solta o ponto atual: ele fica SEM dono, com guarnição rala, esperando
    quem chegar primeiro. Local seguro não tem dono, então só limpa o ponteiro."""
    if ponto_id:
        from game import territorio as T
        linha = c.execute("SELECT tier FROM territorio WHERE id = ?", (int(ponto_id),)).fetchone()
        # A guarnição de ponto largado sai da MESMA função dos bots (um terço
        # dela): fórmula repetida em SQL já divergiu uma vez aqui mesmo.
        rala = T.guarnicao_bot(int(linha[0])) // 3 if linha else 1
        c.execute("UPDATE territorio SET dono_tipo = NULL, dono_id = NULL, dono_nome = NULL,"
                  " guarnicao = ?, integridade = 100"
                  " WHERE id = ? AND seguro = 0 AND dono_tipo = 'jogador' AND dono_id = ?",
                  (rala, int(ponto_id), str(owner_id)))
    c.execute("UPDATE clan SET ponto_id = NULL WHERE owner_id = ?", (owner_id,))


def abandonar_ponto(owner_id: int) -> dict:
    clan = carregar_clan(owner_id)
    if not clan.get("ponto_id"):
        return {"ok": False, "erro": "O clã não ocupa nenhum ponto."}
    pt = ponto(clan["ponto_id"])
    with _conn() as c:
        _largar(c, owner_id, clan["ponto_id"])
        if pt:
            _anotar(c, owner_id, f"🏳️ O clã deixou {pt['nome']}.")
        c.commit()
    return {"ok": True}


def conquistar_ponto(owner_id: int, ponto_id: int, nome_do_cla: str,
                     rng: random.Random | None = None) -> dict:
    """Tenta tomar (ou, se for seguro, ocupar) um ponto do mapa.

    Um ponto por vez: vencer larga o anterior. Perder custa a comida da
    marcha e nada mais — a derrota não pode apagar o clã, só a tentativa.
    """
    from game import territorio as T
    rng = rng or random.Random()
    alvo = ponto(ponto_id)
    if not alvo:
        return {"ok": False, "erro": "Ponto não encontrado."}
    clan = carregar_clan(owner_id)
    anterior = clan.get("ponto_id")
    if anterior and int(anterior) == int(ponto_id):
        return {"ok": False, "erro": "O clã já está aqui."}
    andar_alvo = T.andar_do_ponto(alvo)
    if andar_alvo != int(clan.get("andar") or 1):
        return {"ok": False, "erro": f"Esse ponto fica no Andar {andar_alvo}. O clã só toma "
                                     f"pontos do andar onde está (Andar {int(clan.get('andar') or 1)})."}

    if alvo["seguro"]:
        with _conn() as c:
            _largar(c, owner_id, anterior)
            c.execute("UPDATE clan SET ponto_id = ?, ponto_desde = ? WHERE owner_id = ?",
                      (int(ponto_id), int(time.time()), owner_id))
            _anotar(c, owner_id, f"🏕️ O clã se abrigou em {alvo['nome']} (por 12h).")
            c.commit()
        return {"ok": True, "venceu": True, "seguro": True,
                "texto": f"O clã se abrigou em {alvo['nome']} — fica 12h, depois sai."}

    if alvo["dono_tipo"] == "jogador" and str(alvo["dono_id"]) == str(owner_id):
        return {"ok": False, "erro": "Esse ponto já é do seu clã."}
    if T.TIPOS.get(alvo["tipo"], {}).get("so_guardas"):
        eqp = equipes_do_cla(owner_id).get(EQUIPE_DO_PONTO) or {}
        if eqp.get("coletores"):
            return {"ok": False, "erro": f"{alvo['nome']} só aceita guardas: tire os coletores da "
                                         "equipe do ponto antes de marchar."}

    custo = T.custo_de_ataque(alvo["tier"])
    if int(clan["comida"]) < custo:
        return {"ok": False, "erro": f"A marcha precisa de {custo} de comida."}

    dono_jogador = int(alvo["dono_id"]) if alvo["dono_tipo"] == "jogador" else None
    if dono_jogador:
        # ⚔️ Fase 3: ponto de OUTRO JOGADOR se toma com guardas contra guardas.
        return batalha_pelo_ponto(owner_id, dono_jogador, alvo, nome_do_cla, custo, rng)
    forca = forca_atual(owner_id)
    defesa = T.defesa_do_ponto(alvo, None)
    chance = T.chance_de_vencer(forca, defesa)
    venceu = rng.random() < chance
    agora = int(time.time())

    with _conn() as c:
        c.execute("UPDATE clan SET comida = MAX(0, comida - ?) WHERE owner_id = ?", (custo, owner_id))
        if not venceu:
            texto = (f"⚔️ O clã tentou tomar {alvo['nome']} e foi repelido "
                     f"(força {forca} × defesa {defesa}).")
            _anotar(c, owner_id, texto)
            c.commit()
            return {"ok": True, "venceu": False, "chance": chance, "forca": forca,
                    "defesa": defesa, "texto": texto}

        # Troca de dono condicionada ao dono que LEMOS: se outro jogador
        # tomou o ponto no meio do caminho, este UPDATE não pega nada e a
        # vitória não vira duplicação de dono (armadilha nº 22, a de
        # ler-modificar-gravar sem trava).
        _largar(c, owner_id, anterior)
        cur = c.execute("UPDATE territorio SET dono_tipo = 'jogador', dono_id = ?, dono_nome = ?,"
                        " guarnicao = ?, integridade = 100, desde = ?"
                        " WHERE id = ? AND COALESCE(dono_id, '') = COALESCE(?, '')",
                        (str(owner_id), nome_do_cla, forca, agora, int(ponto_id), alvo["dono_id"]))
        if cur.rowcount == 0:
            c.rollback()
            return {"ok": False, "erro": "O ponto mudou de dono enquanto o clã marchava. Tente de novo."}
        c.execute("UPDATE clan SET ponto_id = ? WHERE owner_id = ?", (int(ponto_id), owner_id))
        texto = f"🚩 O clã tomou {alvo['nome']}" + (
            f" de {alvo['dono_nome']}." if alvo["dono_nome"] else ".")
        _anotar(c, owner_id, texto)
        if dono_jogador:
            # Quem perdeu fica sabendo pelas Memórias, e perde o ponteiro.
            c.execute("UPDATE clan SET ponto_id = NULL WHERE owner_id = ? AND ponto_id = ?",
                      (dono_jogador, int(ponto_id)))
            _anotar(c, dono_jogador, f"🏴 {nome_do_cla} tomou {alvo['nome']} do nosso clã.")
        c.commit()
    return {"ok": True, "venceu": True, "chance": chance, "forca": forca, "defesa": defesa,
            "texto": texto}


def sessao_do_territorio(owner_id: int, ticks: int, rng: random.Random) -> dict:
    """O que o ponto ocupado fez durante a ausência: produziu e aguentou (ou
    não) a pressão dos bots. Chamado de dentro de `rodar_afk`."""
    clan_agora = carregar_clan(owner_id)
    if clan_agora.get("ponto_id"):
        from game import territorio as _T
        segurado = ponto(clan_agora["ponto_id"])
        if segurado and _T.andar_do_ponto(segurado) != int(clan_agora.get("andar") or 1):
            # O clã não está mais ali (regra: só domina onde está).
            with _conn() as c:
                _largar(c, owner_id, clan_agora["ponto_id"])
                _anotar(c, owner_id, f"🏳️ O clã deixou {segurado['nome']} pra trás.")
                c.commit()
    from game import territorio as T
    clan = carregar_clan(owner_id)
    if not clan.get("ponto_id"):
        return {"ponto": None, "bonus": {}}
    pt = ponto(clan["ponto_id"])
    if not pt:
        return {"ponto": None, "bonus": {}}
    fracao = max(0.0, min(1.0, int(ticks) / TETO_TICKS))
    if pt["dono_tipo"] == "jogador" and str(pt["dono_id"]) != str(owner_id):
        # Tomaram enquanto você estava fora: o ponteiro é que ficou velho.
        with _conn() as c:
            c.execute("UPDATE clan SET ponto_id = NULL WHERE owner_id = ?", (owner_id,))
            c.commit()
        return {"ponto": pt["nome"], "bonus": {}, "perdido": True}
    pressao = T.pressao_dos_bots(pt, forca_atual(owner_id), fracao, rng)
    # 📈 O ponto não produz: dá BÔNUS no que o clã tira (ver territorio.TIPOS).
    # A integridade é a de DEPOIS da pressão desta sessão.
    bonus = T.bonus_do_ponto(pt)
    # 🔮 Veio de Cores: esse produz — cores pro inventário do personagem
    # (quem soma é a rota, que tem `p`).
    cores = T.cores_do_ponto(pt, fracao, rng)
    perdido = not pt["seguro"] and int(pt["integridade"]) <= 0
    with _conn() as c:
        if perdido:
            bot = next((b for b in T.BOTS if b["id"] == pressao.get("bot_id")), T.BOTS[0])
            c.execute("UPDATE territorio SET dono_tipo = 'bot', dono_id = ?, dono_nome = ?,"
                      " guarnicao = ?, integridade = 100 WHERE id = ?",
                      (bot["id"], bot["nome"], T.guarnicao_bot(pt["tier"]), pt["id"]))
            c.execute("UPDATE clan SET ponto_id = NULL WHERE owner_id = ?", (owner_id,))
            _anotar(c, owner_id, f"🏴 {bot['nome']} tomou {pt['nome']} depois de vários ataques.")
        else:
            c.execute("UPDATE territorio SET integridade = ? WHERE id = ?",
                      (int(pt["integridade"]), pt["id"]))
        c.commit()
    return {"ponto": pt["nome"], "bonus": {} if perdido else bonus, "pressao": pressao,
            "cores": [] if perdido else cores,
            "integridade": int(pt["integridade"]), "perdido": perdido,
            "estado": T.estado_do_ponto(int(pt["integridade"]))}


def mudar_habitante(owner_id: int, hab_id: int, profissao: str | None = None,
                    descansar: bool | None = None) -> dict:
    """Troca a profissão ou manda descansar.

    Trocar de profissão ZERA o nível: um minerador Nv10 não vira agricultor
    Nv10. Sem esse custo, a profissão seria só um seletor e o nível não
    valeria nada — é o investimento que faz a troca ser uma decisão.
    """
    from game import clan_habitantes as H
    with _conn() as c:
        linha = c.execute("SELECT * FROM clan_habitante WHERE id = ? AND owner_id = ? AND vivo = 1",
                          (int(hab_id), owner_id)).fetchone()
        if not linha:
            return {"ok": False, "erro": "Habitante não encontrado."}
        h = dict(linha)
        if profissao is not None:
            if profissao not in H.PROFISSOES:
                return {"ok": False, "erro": "Profissão desconhecida."}
            if h.get("cavaleiro") and profissao != h["profissao"]:
                # trocar zera o nível: um cavaleiro Nv.40 viraria agricultor Nv.1
                return {"ok": False, "erro": "Cavaleiro não troca de ofício — a guerra é a vida dele."}
            if profissao != h["profissao"]:
                c.execute("UPDATE clan_habitante SET profissao = ?, nivel = 1, xp = 0"
                          " WHERE id = ? AND owner_id = ?", (profissao, int(hab_id), owner_id))
        if descansar is not None:
            c.execute("UPDATE clan_habitante SET descansando = ? WHERE id = ? AND owner_id = ?",
                      (1 if descansar else 0, int(hab_id), owner_id))
        c.commit()
    return {"ok": True}


def gastar_material(owner_id: int, rank: int, quantidade: int) -> bool:
    """Tira material de um rank. Não empresta de rank vizinho de propósito:
    poder converter rank baixo em alto apagaria a razão de descer."""
    clan = carregar_clan(owner_id)
    tem = int(clan["materiais"].get(int(rank), 0))
    if tem < int(quantidade):
        return False
    clan["materiais"][int(rank)] = tem - int(quantidade)
    with _conn() as c:
        c.execute("UPDATE clan SET materiais = ? WHERE owner_id = ?",
                  (json.dumps({str(k): v for k, v in clan["materiais"].items()}), owner_id))
        c.commit()
    return True


def listar_membros(owner_id: int, incluir_mortos: bool = False) -> list:
    sql = "SELECT * FROM clan_membro WHERE owner_id = ?"
    if not incluir_mortos:
        sql += " AND vivo = 1"
    with _conn() as c:
        linhas = c.execute(sql + " ORDER BY slot", (owner_id,)).fetchall()
    saida = []
    for l in linhas:
        m = dict(l)
        m["perfil"] = json.loads(m.get("perfil_json") or "null")
        saida.append(m)
    return saida


def sincronizar_com_slots(owner_id: int) -> int:
    """Traz pro clã os personagens que existem na conta.

    O roster do clã NÃO é uma lista paralela: personagem num slot é membro
    do clã, ponto. Esta função só garante que quem existe em
    character_storage tem linha aqui — sem duplicar quem ele é, que
    continua morando lá.
    """
    from game.characters import listar_personagens_da_conta
    criados = 0
    with _conn() as c:
        for pe in listar_personagens_da_conta(owner_id):
            existe = c.execute(
                "SELECT 1 FROM clan_membro WHERE owner_id = ? AND slot = ?",
                (owner_id, int(pe["slot"]))).fetchone()
            if existe:
                # Nome e nível podem ter mudado desde a última vez.
                c.execute("UPDATE clan_membro SET nome = ?, nivel = ?"
                          " WHERE owner_id = ? AND slot = ?",
                          (pe["nome"], int(pe["level"]), owner_id, int(pe["slot"])))
                continue
            c.execute("INSERT INTO clan_membro(owner_id, slot, nome, nivel) VALUES (?,?,?,?)",
                      (owner_id, int(pe["slot"]), pe["nome"], int(pe["level"])))
            criados += 1
        # 🐛 (28/09) quem SAIU da conta (vendido no Mercado, ou que virou
        # cavaleiro) continuava listado como membro vivo — o clã mostrava
        # gente que não existe mais. Morto fica (é o memorial).
        existentes = {int(pe["slot"]) for pe in listar_personagens_da_conta(owner_id)}
        for (slot,) in c.execute("SELECT slot FROM clan_membro WHERE owner_id = ? AND vivo = 1",
                                 (owner_id,)).fetchall():
            if int(slot) not in existentes:
                c.execute("DELETE FROM clan_membro WHERE owner_id = ? AND slot = ?", (owner_id, int(slot)))
        c.commit()
    return criados


# ------------------------------------------------------------------- postos

def definir_posto(owner_id: int, slot: int, area_id: str | None, posto_id: str | None) -> None:
    """Onde o membro fica enquanto você não está.

    É AQUI que a agência acontece. Como a morte é permanente e o AFK roda
    sozinho, a única decisão do jogador é esta — e por isso a tela que
    chama esta função tem que mostrar o perfil de risco antes.
    """
    with _conn() as c:
        c.execute("UPDATE clan_membro SET area_id = ?, posto_id = ?"
                  " WHERE owner_id = ? AND slot = ? AND vivo = 1",
                  (area_id, posto_id, owner_id, int(slot)))
        c.commit()


def situacao_do_cla(owner_id: int, clan: dict, membros: list) -> dict:
    """O estado do clã em números, pronto pra tela.

    Calculado aqui e não no front porque é a MESMA conta que decide o jogo
    (quem come, quanto dura a comida) — duas implementações da mesma regra
    divergem, e a que o jogador lê é a que ele usa pra decidir.
    """
    from game.clan_materiais import teto_de_comida

    vivos = [m for m in membros if m.get("vivo", 1)]
    em_posto = [m for m in vivos if m.get("area_id")]
    racao = (TETO_TICKS // RACAO_TICKS) * max(1, len(em_posto))
    # Autonomia: quantas sessões cheias o estoque aguenta no ritmo de hoje.
    # É o número que o jogador precisa pra decidir entre postar mais gente e
    # mandar alguém colher — e é o que nenhuma tela mostrava.
    autonomia = (int(clan["comida"]) / racao) if racao else None

    return {
        "vivos": len(vivos),
        "em_posto": len(em_posto),
        "na_aldeia": len(vivos) - len(em_posto),
        "com_fome": len([m for m in vivos if int(m.get("fome") or 0) > 0]),
        "feridos": len([m for m in vivos if int(m.get("ferimento") or 0) > 0]),
        "mortos": len([m for m in membros if not m.get("vivo", 1)]),
        "colhendo_comida": len([m for m in em_posto
                                if str(m.get("area_id") or "").startswith("andar")
                                and int(str(m["area_id"]).replace("andar", "") or 99)
                                <= ANDAR_MAXIMO_DE_COMIDA]),
        "racao_por_sessao": racao,
        "autonomia_sessoes": round(autonomia, 1) if autonomia is not None else None,
        "teto_comida": teto_de_comida(clan["comodidades"], bocas_do_cla(owner_id)),
        "situacoes_pendentes": len(clan.get("situacoes") or []),
    }


def assinatura_do_perfil(membro: dict) -> int:
    """O que faz o perfil guardado deixar de valer.

    Inclui o EQUIPAMENTO (equipar muda a fronteira, e um perfil de antes
    mentiria justo quando o jogador acabou de gastar material pra mudar
    isso) e também FOME e FERIMENTO — senão o clã faminto seria calculado
    com a força de quando estava alimentado, que é o mesmo bug com outro
    nome.

    Os fatores são folgados de propósito: fome e ferimento são limitados
    por FOME_MAX/FERIMENTO_MAX, então nunca invadem a casa do vizinho.
    """
    nivel = int(membro.get("nivel") or 1)
    equip = int(membro.get("equip_poder") or 0)
    fome = min(FOME_MAX, max(0, int(membro.get("fome") or 0)))
    ferimento = min(FERIMENTO_MAX, max(0, int(membro.get("ferimento") or 0)))
    return ((nivel * 100000 + equip) * 100 + fome) * 100 + ferimento


def penalizar_modelo(modelo: dict, membro: dict) -> dict:
    """Fome e ferimento entram como ATRIBUTO A MENOS na simulação.

    ⚠️ Esta é a única porta pela qual o estado do membro chega no resultado
    do AFK. `clan_risco.poder_do_membro` também desconta fome e ferimento,
    mas aquele módulo inteiro não é importado por ninguém fora dos testes —
    quem decide vida e morte aqui é `clan_afk.montar_perfil`, que só olha
    os atributos. Descontar em `poder_do_membro` e achar que isso muda o
    jogo foi exatamente o que manteve a fome de enfeite.

    A escala é comparável à do equipamento (que entra como `+equip` no
    mesmo atributo): fome no teto custa 6 pontos, um pouco mais que a peça
    de rank 1. Dá pra dizer na tela: com fome, é como se ele tivesse
    perdido a arma.
    """
    penalidade = (min(FOME_MAX, max(0, int(membro.get("fome") or 0)))
                  + min(FERIMENTO_MAX, max(0, int(membro.get("ferimento") or 0))))
    if penalidade <= 0:
        return modelo
    saida = dict(modelo)
    saida["attrs"] = {k: max(1, int(v) - penalidade)
                      for k, v in (modelo.get("attrs") or {}).items()}
    return saida


def perfil_do_membro(owner_id: int, membro: dict, area: dict, modelo: dict) -> dict:
    """Devolve o perfil guardado, ou recalcula se o membro mudou.

    Recalcular a cada tick jogaria fora a única coisa que torna o AFK
    barato. Recalcula quando o nível muda ou quando a área muda — que é
    quando o resultado realmente pode mudar.
    """
    from game.clan_afk import montar_perfil
    guardado = membro.get("perfil")
    assinatura = assinatura_do_perfil(membro)
    if (guardado and guardado.get("area") == area.get("id")
            and int(membro.get("perfil_nivel") or 0) == assinatura):
        return guardado
    perfil = montar_perfil(penalizar_modelo(modelo, membro), area)
    with _conn() as c:
        c.execute("UPDATE clan_membro SET perfil_json = ?, perfil_nivel = ?"
                  " WHERE owner_id = ? AND slot = ?",
                  (json.dumps(perfil), assinatura, owner_id, int(membro["slot"])))
        c.commit()
    return perfil


# --------------------------------------------------------------------- tick

def quantos_ticks(clan: dict, agora: int | None = None) -> tuple[int, int]:
    """(ticks a processar, segundos que sobraram e não rendem).

    O tempo acima do teto não vira nada. Três dias fora não pode virar 300
    situações: isso não é recompensa, é dever de casa.
    """
    agora = agora or int(time.time())
    passado = max(0, agora - int(clan.get("ultimo_tick") or agora))
    brutos = passado // INTERVALO_TICK
    return min(brutos, TETO_TICKS), max(0, brutos - TETO_TICKS)


def aplicar_bonus_do_ponto(ganhos: dict, bonus: dict) -> dict:
    """O EXTRA que o bônus do ponto soma em cima do que foi ganho. Puro —
    é o que o teste confere direto. `material` vale pra todos os ranks."""
    extra = {"comida": 0, "madeira": 0, "couro": 0, "ouro": 0, "material": {}}
    for recurso in ("comida", "madeira", "couro", "ouro"):
        extra[recurso] = int(int(ganhos.get(recurso, 0)) * float(bonus.get(recurso, 0)))
    if bonus.get("material"):
        extra["material"] = {int(r): int(int(q) * float(bonus["material"]))
                             for r, q in (ganhos.get("material") or {}).items()
                             if int(int(q) * float(bonus["material"]))}
    return extra


import re as _re
_RE_MATERIAL_RANK = _re.compile(r"^material_r(\d+)$")


def _somar_producao(producao: dict, ganho_material: dict) -> dict:
    """Separa uma `producao` genérica (de `clan_habitantes` ou de
    `territorio`) em recursos planos e material por rank.

    As duas fontes que não são posto de lutador — habitante minerador e
    ponto de mina/ruínas no mapa — devolvem material como chave especial
    `material_rN`. Uma função só faz a extração pras duas, em vez de
    reescrever o mesmo laço duas vezes (é assim que duas cópias da mesma
    regra se desencontram — armadilha nº 3 deste projeto).
    """
    resto = {"comida": 0, "madeira": 0, "couro": 0, "ouro": 0}
    for chave, qtd in (producao or {}).items():
        m = _RE_MATERIAL_RANK.match(chave)
        if m:
            r = int(m.group(1))
            ganho_material[r] = ganho_material.get(r, 0) + int(qtd)
        elif chave in resto:
            resto[chave] += int(qtd)
    return resto


def rodar_afk(owner_id: int, areas: dict, modelos: dict,
              agora: int | None = None, rng: random.Random | None = None) -> dict:
    """Processa o AFK acumulado. Chamado no login, não por cronômetro.

    `areas` é o catálogo por id; `modelos` é o dict de combate de cada
    membro (por slot), usado só se o perfil precisar ser recalculado.
    """
    from game.clan_afk import rodar_tick, perfil_do_grupo
    rng = rng or random
    agora = agora or int(time.time())
    clan = carregar_clan(owner_id)
    ticks, descartados = quantos_ticks(clan, agora)
    if ticks <= 0:
        return {"ticks": 0, "eventos": [], "situacoes": clan["situacoes"],
                "descartados": descartados}

    # Distribui ANTES de rodar: equipar muda o perfil de risco, e rodar com
    # o perfil de ontem seria calcular a morte com a força de antes.
    distribuir_equipamento(owner_id)
    membros = [m for m in listar_membros(owner_id) if m.get("area_id")]
    # Agrupa por área: quem está no mesmo lugar luta junto.
    por_area: dict[str, list] = {}
    for m in membros:
        por_area.setdefault(m["area_id"], []).append(m)

    eventos, situacoes, mortos = [], list(clan["situacoes"]), []
    feridos: dict[int, int] = {}
    ganho_comida = 0
    ganho_madeira = 0
    ganho_couro = 0
    ganho_material: dict[int, int] = {}
    # 🥇 20/09/2026: bronze e prata saíram do jogo — só existe ouro, e ouro
    # é do JOGADOR (`p["gold"]`), não do clã. Por isso `rodar_afk` só
    # ACUMULA `ganho_ouro` aqui (puro cálculo, sem SQL nenhum); quem grava
    # é a rota (`get_clan`), que já tem `p` carregado e é quem soma e salva.
    ganho_ouro = 0

    for area_id, grupo_membros in por_area.items():
        area = areas.get(area_id)
        if not area:
            continue
        perfis = [perfil_do_membro(owner_id, m, area, modelos.get(m["slot"], {}))
                  for m in grupo_membros]
        grupo = perfil_do_grupo(perfis)
        # O mais fraco é quem cai — decidido aqui, não sorteado.
        mais_fraco = min(grupo_membros, key=lambda m: int(m.get("nivel") or 1))
        encontros = 0

        for _ in range(ticks):
            ev = rodar_tick(grupo, area, rng)
            ev["area_nome"] = area.get("nome", area_id)
            if ev["tipo"] == "monstro":
                if encontros >= TETO_ENCONTROS:
                    # Teto de perigo atingido: o grupo recolhe e o resto da
                    # sessão rende só o que é seguro.
                    continue
                encontros += 1
            if ev.get("morte"):
                ev["quem"] = mais_fraco["nome"]
                ev["slot"] = mais_fraco["slot"]
                mortos.append((mais_fraco, ev))
                eventos.append(ev)
                break   # morreu; o posto acabou pra este grupo
            if ev.get("ferimento"):
                # 🩸 20/09/2026: `rodar_tick` devolvia `ferimento = 1` no RECUA
                # desde sempre e ninguém lia — o mesmo bug da fome, no campo
                # vizinho (armadilha nº 10). `penalizar_modelo` já desconta
                # ferimento e o curandeiro já cura: faltava alguém ESCREVER.
                # Fere o mais fraco, pela mesma regra de quem cai.
                ev["quem"] = mais_fraco["nome"]
                feridos[int(mais_fraco["slot"])] = feridos.get(int(mais_fraco["slot"]), 0) + int(ev["ferimento"])
            if ev.get("recurso"):
                qtd = int(ev["recurso"])
                tipo_recurso = area.get("recurso")
                if tipo_recurso == "metal":
                    r = int(area.get("rank", 1))
                    ganho_material[r] = ganho_material.get(r, 0) + qtd
                    ev["rank"] = r
                elif tipo_recurso == "madeira":
                    ganho_madeira += qtd
                elif tipo_recurso == "couro":
                    ganho_couro += qtd
                else:
                    ganho_comida += qtd
            # 🧹 26/09: as "situações" do sistema antigo de decisões saíram —
            # as histórias agora são as Crônicas (game/cronicas.py).
            # 🪙 20/09 (dev): o AFK do clã não gera mais ouro (nem o "achado
            # raro" nem o pingo por tick) — ouro vem só do que o reino paga.
            eventos.append(ev)

    # ------------------------------------------------------------- a ração
    #
    # Come quem esteve EM POSTO, e o que o clã trouxe hoje já entra na conta
    # de hoje — o grupo comeu o que carregou de volta.
    #
    # Alimenta-se o MAIS FORTE primeiro, pela mesma razão que já foi medida
    # em distribuir_equipamento: o grupo vence se ALGUÉM vence, então
    # dividir pouca comida igual entre todos enfraquece o time inteiro sem
    # salvar ninguém. Concentrar mantém de pé quem ainda ganha as lutas.
    #
    # ⚠️ A fome desta sessão só morde na PRÓXIMA: o perfil de combate é
    # calculado uma vez, antes do laço de ticks, e recalcular no meio jogaria
    # fora justamente o que torna o AFK barato. O atraso é aceitável e é
    # melhor que o custo — mas está escrito aqui pra não virar mistério.
    from game.clan_materiais import teto_de_comida

    mortos_slots = {int(m["slot"]) for m, _e in mortos}
    postados = [m for m in membros if int(m["slot"]) not in mortos_slots]
    refeicoes = ticks // RACAO_TICKS
    racao_total = refeicoes * len(postados)
    estoque = int(clan["comida"]) + ganho_comida
    consumido = min(estoque, racao_total)
    # Do mais forte pro mais fraco: é a ordem em que a comida é servida.
    fila = sorted(postados, key=lambda m: int(m.get("nivel") or 1), reverse=True)
    quantos_comem = (consumido // refeicoes) if refeicoes else len(fila)
    alimentados = fila[:quantos_comem]
    famintos = fila[quantos_comem:]
    # Só cobra o que realmente foi servido — senão o estoque pagaria por
    # refeição que ninguém comeu.
    consumido = refeicoes * len(alimentados)

    # O teto olha o clã INTEIRO, não só quem está em posto: o depósito é da
    # aldeia, e recolher todo mundo não pode encolher o celeiro.
    # ------------------------------------------------------------- a aldeia
    #
    # 🏘️ Os habitantes trabalham as MESMAS horas que os lutadores ficaram
    # fora, e comem do que sobrou depois da ração deles — quem luta come
    # primeiro, porque é quem volta ferido se ficar sem.
    from game import clan_habitantes as H
    habitantes = listar_habitantes(owner_id, incluir_mortos=False)
    aldeia = H.sessao_da_aldeia(habitantes, ticks, max(0, estoque - consumido),
                                clan["comodidades"] or {}, rng, config_da_aldeia(clan))
    # 👥 20/09/2026: o habitante NÃO produz mais de dentro da aldeia — quem
    # coleta são as EQUIPES, fora, num posto, com guarda junto (abaixo). A
    # sessão da aldeia continua cuidando da vida: ração, cansaço, XP, aura,
    # chegadas, ataques, luto.
    consumido += aldeia["comida_consumida"]
    memorias_novas = list(aldeia["memorias"])

    # ----------------------------------------------- manutenção e equipes
    equipes_rel = sessao_das_equipes(owner_id, clan, habitantes, ticks, rng,
                                     estoque - consumido, ganho_madeira, ganho_couro, ganho_material)
    ganho_comida += equipes_rel["ganho"]["comida"]
    estoque += equipes_rel["ganho"]["comida"]
    ganho_madeira += equipes_rel["ganho"]["madeira"] - equipes_rel["pago"]["madeira"]
    ganho_couro += equipes_rel["ganho"]["couro"] - equipes_rel["pago"]["couro"]
    consumido += equipes_rel["pago"]["comida"]
    for r, q in equipes_rel["material"].items():
        ganho_material[r] = ganho_material.get(r, 0) + q
    if equipes_rel["pago"]["ferro"]:
        ganho_material[1] = ganho_material.get(1, 0) - equipes_rel["pago"]["ferro"]
    # 🏰 A cidade: se o ataque à aldeia NÃO foi repelido, levam 20% do que ela
    # guarda (comida, madeira, couro, ferro). Quem defende é a guarnição.
    saque = {}
    ataque_ald = aldeia.get("ataque") or {}
    if ataque_ald and not ataque_ald.get("repelido"):
        base = {"comida": max(0, estoque - consumido),
                "madeira": int(clan.get("madeira", 0)) + ganho_madeira,
                "couro": int(clan.get("couro", 0)) + ganho_couro,
                "ferro": int(clan["materiais"].get(1, 0)) + int(ganho_material.get(1, 0))}
        saque = {r: int(q * 0.2) for r, q in base.items() if int(q * 0.2) > 0}
        consumido += saque.get("comida", 0)
        ganho_madeira -= saque.get("madeira", 0)
        ganho_couro -= saque.get("couro", 0)
        if saque.get("ferro"):
            ganho_material[1] = ganho_material.get(1, 0) - saque["ferro"]
        if saque:
            memorias_novas.append({"tipo": "saque", "texto": "🏚️ Atacaram a cidade e levaram " + ", ".join(
                f"{q} de {r}" for r, q in saque.items()) + ". Faltou guarda em casa."})
    # 🏺 o achado raro do trabalho braçal: ~1% por equipe por sessão
    equipes_rel["reliquia"] = sortear_reliquia(
        owner_id, len(equipes_rel.get("saidas") or []), min(1.0, ticks / TETO_TICKS), rng)
    if equipes_rel["reliquia"]:
        memorias_novas.append({"tipo": "reliquia",
                               "texto": f"🏺 Desenterraram {equipes_rel['reliquia']['nome']}: "
                                        f"{equipes_rel['reliquia']['historia']}"})
    equipes_rel["saque"] = saque
    guarnicao = [h for h in habitantes if h.get("funcao") == "guarda" and h.get("equipe") == EQUIPE_DA_CIDADE
                 and int(h.get("vivo", 1))]
    xp_guarnicao = XP_VIGIA * min(1.0, ticks / TETO_TICKS)
    if ataque_ald:
        xp_guarnicao += XP_DEFESA if ataque_ald.get("repelido") else XP_DEFESA // 3
    for g in guarnicao:
        equipes_rel["xp_frases"] += H.ganhar_xp(g, int(round(xp_guarnicao)))
    aldeia.setdefault("frases", []).extend(equipes_rel["xp_frases"])
    if equipes_rel["greve"]:
        memorias_novas.append({"tipo": "greve", "texto": "📉 Faltou " + ", ".join(
            equipes_rel["greve"]) + " pra manter a aldeia: as equipes renderam só metade."})

    vivos_depois = [h for h in habitantes if int(h.get("vivo", 1))]
    estagio = H.estagio_da_aldeia(len(vivos_depois), clan["comodidades"] or {})
    if estagio["indice"] > int(clan.get("estagio_registrado") or 0):
        memorias_novas.append({"tipo": "estagio",
                               "texto": f"🏘️ O povoado cresceu e virou {estagio['nome']}."})

    # ------------------------------------------------------------ o ponto
    # 🗺️ O ponto ocupado no mapa rende junto com a aldeia — e sofre a
    # pressão dos bots no mesmo intervalo.
    terr = sessao_do_territorio(owner_id, ticks, rng)
    # 📈 O ponto do mapa MULTIPLICA o que o trabalho rendeu (postos + aldeia):
    # +100% a +150%. Sem ponto, o clã pega o mesmo — só que menos.
    extra = aplicar_bonus_do_ponto({"comida": ganho_comida, "madeira": ganho_madeira,
                                    "couro": ganho_couro, "ouro": ganho_ouro,
                                    "material": dict(ganho_material)}, terr.get("bonus") or {})
    ganho_comida += extra["comida"]
    estoque += extra["comida"]
    ganho_madeira += extra["madeira"]
    ganho_couro += extra["couro"]
    ganho_ouro += extra["ouro"]
    for r, q in extra["material"].items():
        ganho_material[r] = ganho_material.get(r, 0) + q
    terr["extra"] = extra

    teto = teto_de_comida(clan["comodidades"], bocas_do_cla(owner_id))
    # 🌾 (25/09) o celeiro NÃO joga fora o que já estava guardado: o teto só
    # corta a comida NOVA que passaria dele. Sem isso, a reserva inicial de
    # 20 sessões (acima do teto) sumia inteira na primeira sessão.
    teto_efetivo = max(teto, int(clan["comida"]))
    sobra = estoque - consumido
    perdido = max(0, sobra - teto_efetivo)

    with _conn() as c:
        for membro, ev in mortos:
            # Morte permanente. A causa fica gravada: com permadeath, "ele
            # morreu" sem o porquê é arbitrário.
            c.execute("UPDATE clan_membro SET vivo = 0, morreu_em = ?, causa_morte = ?,"
                      " area_id = NULL, posto_id = NULL WHERE owner_id = ? AND slot = ?",
                      (agora, ev.get("motivo", ""), owner_id, int(membro["slot"])))

        # Quem comeu melhora; quem ficou sem piora. E quem NÃO estava em
        # posto se recupera de graça: é a porta de saída do jogador. Se a
        # comida acabou, recolher o pessoal conserta o clã — custa a
        # produção da sessão, que é o preço certo, e impede que a fome vire
        # espiral sem fundo, que com morte permanente seria armadilha.
        if refeicoes > 0:
            for m in alimentados:
                c.execute("UPDATE clan_membro SET fome = MAX(0, fome - 1)"
                          " WHERE owner_id = ? AND slot = ? AND vivo = 1",
                          (owner_id, int(m["slot"])))
            for m in famintos:
                c.execute("UPDATE clan_membro SET fome = MIN(?, fome + 1)"
                          " WHERE owner_id = ? AND slot = ? AND vivo = 1",
                          (FOME_MAX, owner_id, int(m["slot"])))
            c.execute("UPDATE clan_membro SET fome = MAX(0, fome - 1)"
                      " WHERE owner_id = ? AND vivo = 1 AND area_id IS NULL",
                      (owner_id,))

        for slot, qtd in feridos.items():
            if slot in mortos_slots:
                continue
            c.execute("UPDATE clan_membro SET ferimento = MIN(?, ferimento + ?)"
                      " WHERE owner_id = ? AND slot = ? AND vivo = 1",
                      (FERIMENTO_MAX, qtd, owner_id, slot))
        # 🩺 Cada curandeiro da aldeia trata 1 ponto de ferimento de cada
        # lutador por sessão. É a Enfermaria do desenho, e é o que impede o
        # ferimento — agora que ele é gravado — de só acumular.
        if aldeia["curandeiros"]:
            c.execute("UPDATE clan_membro SET ferimento = MAX(0, ferimento - ?)"
                      " WHERE owner_id = ? AND vivo = 1", (aldeia["curandeiros"], owner_id))
        _gravar_habitantes(c, owner_id, habitantes, agora)
        for m, e in mortos:
            memorias_novas.append({"tipo": "morte",
                                   "texto": f"⚰️ {m['nome']} caiu em combate: {e.get('motivo', '')}".strip()})

        acumulado = dict(clan["materiais"])
        for r, q in ganho_material.items():
            acumulado[r] = acumulado.get(r, 0) + q
        # Delta e não valor absoluto, e com MIN/MAX no próprio SQL: assim a
        # gravação não depende de o estoque lido ainda ser o mesmo, e o
        # estoque não tem como ficar negativo nem passar do celeiro.
        # 📓 O DIÁRIO FICA GRAVADO.
        #
        # ⚠️ A coluna `diario` existia desde o começo, era carregada em
        # carregar_clan() e NUNCA era escrita por ninguém — mesma classe do
        # teto_comida e da fome. Sem ela, o relatório da sessão vivia só na
        # resposta daquela requisição: bastava o jogador reabrir a tela do
        # clã pra tudo sumir, e ele nunca mais saberia o que aconteceu com
        # a aldeia enquanto esteve fora.
        #
        # Guarda as últimas SESSOES_NO_DIARIO. Mais que isso vira arquivo
        # morto dentro de uma coluna de texto, e ninguém rola até lá.
        pagina = {
            "quando": agora, "ticks": ticks, "descartados": descartados,
            "comida": ganho_comida, "consumido": consumido, "racao": racao_total,
            "madeira": ganho_madeira, "couro": ganho_couro, "perdido": perdido,
            "ouro": ganho_ouro,
            "materiais": {str(k): v for k, v in ganho_material.items()},
            "famintos": [{"nome": m["nome"], "slot": m["slot"]} for m in famintos],
            "mortos": [{"nome": m["nome"], "slot": m["slot"], "causa": e.get("motivo")}
                       for m, e in mortos],
            "feridos": [{"slot": sl, "qtd": q} for sl, q in feridos.items()],
            # A aldeia no relatório: o que produziu e o que marcou a sessão.
            "territorio": {k: terr.get(k) for k in ("ponto", "producao", "integridade",
                                                     "perdido", "estado", "pressao")},
            "aldeia": {"producao": aldeia["producao"], "frases": aldeia["frases"][-12:],
                       "ataque": aldeia["ataque"], "despertaram": aldeia["despertaram"],
                       "chegou": aldeia["chegou"]},
        }
        diario = ([pagina] + list(clan.get("diario") or []))[:SESSOES_NO_DIARIO]

        # 🥇 OURO NÃO É GRAVADO AQUI. Ele é do JOGADOR (`p["gold"]`), não do
        # clã — `rodar_afk` só toca a tabela `clan`. `ganho_ouro` volta no
        # relatório pra quem chama (a rota `/api/clan`, que já tem `p`
        # carregado) somar e salvar. Gravar aqui seria criar um segundo
        # lugar pra guardar ouro, e é exatamente essa duplicação que a
        # troca por moeda única veio evitar.
        c.execute("UPDATE clan SET comida = MAX(0, MIN(?, comida + ? - ?)), materiais = ?,"
                  " madeira = madeira + ?, couro = couro + ?,"
                  " ultimo_tick = ?, situacoes = ?, diario = ?,"
                  " memorias = ?, estagio_registrado = MAX(estagio_registrado, ?)"
                  " WHERE owner_id = ?",
                  (teto_efetivo, ganho_comida, consumido,
                   json.dumps({str(k): v for k, v in acumulado.items()}),
                   ganho_madeira, ganho_couro,
                   agora, json.dumps(situacoes[:TETO_SITUACOES]),
                   json.dumps(diario),
                   json.dumps(_somar_memorias(clan, memorias_novas, agora)),
                   estagio["indice"], owner_id))
        c.commit()

    return {"ticks": ticks, "descartados": descartados, "eventos": eventos,
            "situacoes": situacoes[:TETO_SITUACOES],
            "comida": ganho_comida, "materiais": ganho_material,
            "madeira": ganho_madeira, "couro": ganho_couro, "ouro": ganho_ouro,
            "equipes": equipes_rel,
            "cores": terr.get("cores") or [],
            # A conta da ração vai inteira pro relatório: "o clã comeu 18"
            # sem dizer quem ficou sem é o tipo de número que o jogador não
            # consegue transformar em decisão.
            "racao": racao_total, "consumido": consumido,
            "teto_comida": teto, "perdido": perdido,
            "famintos": [{"nome": m["nome"], "slot": m["slot"]} for m in famintos],
            "mortos": [{"nome": m["nome"], "slot": m["slot"], "causa": e.get("motivo")}
                       for m, e in mortos],
            "aldeia": aldeia, "territorio": terr}


# ------------------------------------------------------- áreas = andares

def andares_oferecidos(topo: int) -> list:
    """Quais andares viram área de AFK.

    ⚠️ Isto era `range(1, topo+1, 5)` — 1, 6, 11, 16… Como a faixa que
    alimenta é `andar <= 5`, existia **uma única área de comida no jogo
    inteiro**, a do andar 1, rendendo 2 por coleta. A renda de comida
    ficava travada em ~24 por sessão em qualquer nível, enquanto a de
    material crescia até 300+.

    A faixa rasa agora vem de 2 em 2. São três andares que alimentam (1, 3
    e 5) em vez de um, e os andares 7 e 9 continuam dando material de rank
    1 — o que o passo de 5 quase tirou do jogo, porque com a comida
    ocupando o andar 1 o rank 1 dependia sozinho do andar 6.

    Do 11 pra cima o passo volta a ser 5: lá a diferença entre o andar 21 e
    o 22 não é decisão, é ruído.
    """
    topo = max(1, min(50, int(topo)))
    andares = [a for a in (1, 3, 5, 7, 9) if a <= topo]
    andares += list(range(11, topo + 1, 5))
    return andares or [1]


def areas_disponiveis(andar_do_jogador: int) -> dict:
    """O mapa é a Torre. Cada andar é uma área, e você só oferece os que
    ficaram atrás de você.
    """
    from game.clan_materiais import rende_no_andar, RANKS

    areas = {}
    for andar in andares_oferecidos(andar_do_jogador):
        rende = rende_no_andar(andar)
        areas[f"andar{andar}"] = {
            "id": f"andar{andar}", "andar": andar,
            "nome": f"Andar {andar}",
            "rank": rende["rank"],
            "rank_nome": RANKS[rende["rank"]]["nome"],
            "rende": rende["quantidade"],
            # Um recurso por área, pela tabela acima. Andares que não
            # estejam nela (se o passo mudar um dia) caem em metal, que é
            # o recurso genérico do fundo.
            "recurso": RECURSO_DO_ANDAR.get(andar, "metal"),
        }
    return areas


# ------------------------------------------------------ arsenal automático

def guardar_peca(owner_id: int, rank: int, poder: int) -> None:
    """Põe uma peça forjada no arsenal do clã."""
    clan = carregar_clan(owner_id)
    arsenal = list(clan["arsenal"])
    arsenal.append({"rank": int(rank), "poder": int(poder)})
    with _conn() as c:
        c.execute("UPDATE clan SET arsenal = ? WHERE owner_id = ?",
                  (json.dumps(arsenal), owner_id))
        c.commit()


def distribuir_equipamento(owner_id: int) -> list:
    """Melhor peça pro melhor guerreiro. Automático, refeito a cada sessão.

    MEDIDO antes de escolher a regra. Grupo [nv60, nv35, nv18] com peças
    [+26, +16, +4]:

        melhor peça pro melhor   -> fronteira andar 27, morte 5,9% no 26
        melhor peça pro mais fraco -> fronteira andar 21, morte 76,5% no 26

    Força ganha nos dois eixos, e a razão é o próprio jeito que o grupo
    resolve o combate: ele vence se ALGUÉM vence. Concentrar poder faz esse
    alguém existir; espalhar faz ninguém vencer, e aí o grupo inteiro cai.

    Isto é só do idle. O personagem que você pilota na Torre continua com o
    equipamento dele, escolhido na mão — são duas coisas diferentes e não
    se misturam.
    """
    clan = carregar_clan(owner_id)
    pecas = sorted(clan["arsenal"], key=lambda x: int(x.get("poder", 0)), reverse=True)
    membros = sorted(listar_membros(owner_id),
                     key=lambda m: int(m.get("nivel") or 1), reverse=True)

    atribuicao = []
    with _conn() as c:
        for i, m in enumerate(membros):
            peca = pecas[i] if i < len(pecas) else None
            poder = int(peca["poder"]) if peca else 0
            c.execute("UPDATE clan_membro SET equip_poder = ?, equip_rank = ?"
                      " WHERE owner_id = ? AND slot = ?",
                      (poder, int(peca["rank"]) if peca else None, owner_id, m["slot"]))
            atribuicao.append({"slot": m["slot"], "nome": m["nome"],
                               "nivel": m["nivel"], "poder": poder,
                               "rank": peca["rank"] if peca else None})
        c.commit()
    return atribuicao


# -------------------------------------------------------------- comida a ouro

def custo_comida(quantidade: int) -> int:
    """Quanto custa comprar comida com ouro. 1g por unidade: é caro o
    bastante pra farmar continuar valendo mais (um lutador em posto no
    Andar 5 rende ~85 de comida de graça), mas existe pra socorrer uma
    sessão ruim sem deixar o clã passar fome."""
    return max(0, int(quantidade))


def comprar_comida(owner_id: int, quantidade: int) -> dict:
    """Só a parte do CLÃ: soma comida até o teto e devolve quanto REALMENTE
    entrou (pode ser menos que `quantidade`, se o celeiro já estava perto
    de cheio — comprar além do teto seria ouro jogado fora sem avisar).

    Não mexe em ouro: isso é `p["gold"]`, e quem chama (a rota) já tem `p`
    carregado — cobra e salva lá, do mesmo jeito que `escolher_especializacao`.
    """
    from game.clan_materiais import teto_de_comida
    quantidade = max(0, int(quantidade))
    if quantidade == 0:
        return {"ok": False, "erro": "Quantidade precisa ser maior que zero."}
    clan = carregar_clan(owner_id)
    teto = teto_de_comida(clan["comodidades"], bocas_do_cla(owner_id))
    espaco = max(0, teto - int(clan["comida"]))
    comprado = min(quantidade, espaco)
    if comprado == 0:
        return {"ok": False, "erro": f"O celeiro já está no teto ({teto})."}
    with _conn() as c:
        c.execute("UPDATE clan SET comida = MIN(?, comida + ?) WHERE owner_id = ?",
                  (teto, comprado, owner_id))
        c.commit()
    return {"ok": True, "comprado": comprado, "custo_ouro": custo_comida(comprado)}



# -------------------------------------------------------------- situações

# 🧹 26/09: situacao_da_vez / consumir_situacao saíram com o sistema antigo
# de decisões (a fila agora é das Crônicas, game/cronicas.py).



# ------------------------------------------------------------ mão de obra

def custo_com_mao_de_obra(clan: dict, metal: int, madeira: int) -> tuple[int, int]:
    """Custo da construção já com a mão de obra contratada (se houver).
    Arredonda pra CIMA: desconto nunca transforma custo em zero."""
    import math
    d = max(0.0, min(0.9, float(clan.get("mao_de_obra") or 0)))
    if not d:
        return int(metal), int(madeira)
    return int(math.ceil(int(metal) * (1 - d))), int(math.ceil(int(madeira) * (1 - d)))


def contratar_mao_de_obra(owner_id: int, desconto: float) -> bool:
    """Grava o desconto pendente. False se já havia um — pagar duas vezes
    pelo mesmo desconto seria ouro jogado fora, então a rota recusa antes
    de cobrar."""
    with _conn() as c:
        cur = c.execute("UPDATE clan SET mao_de_obra = ? WHERE owner_id = ? AND COALESCE(mao_de_obra, 0) = 0",
                        (float(desconto), owner_id))
        c.commit()
        return cur.rowcount > 0


def consumir_mao_de_obra(owner_id: int) -> None:
    with _conn() as c:
        c.execute("UPDATE clan SET mao_de_obra = 0 WHERE owner_id = ?", (owner_id,))
        c.commit()



# ------------------------------------------------------------------ jornada

def jornada_atual(owner_id: int) -> dict | None:
    bruto = carregar_clan(owner_id).get("jornada")
    try:
        return json.loads(bruto) if bruto else None
    except ValueError:
        return None


def gravar_jornada(owner_id: int, j: dict | None) -> None:
    with _conn() as c:
        c.execute("UPDATE clan SET jornada = ? WHERE owner_id = ?",
                  (json.dumps(j) if j else None, owner_id))
        c.commit()


def iniciar_jornada(owner_id: int, lutadores: list, comida: int, andar_max: int,
                    rng=None) -> dict:
    """Parte na travessia pro andar SEGUINTE ao do clã — só se o jogador já
    chegou nele. Tira a comida do celeiro na hora. Uma travessia por vez.
    `lutadores` já vem com a ficha de combate (quem monta é a rota, que tem
    o motor de combate)."""
    from game import clan_jornada as J
    rng = rng or random.Random()
    if jornada_atual(owner_id):
        return {"ok": False, "erro": "Já há uma travessia em andamento."}
    clan = carregar_clan(owner_id)
    origem = int(clan.get("andar") or 1)
    destino = J.andar_permitido(origem, andar_max)
    if destino is None:
        return {"ok": False, "erro": f"O clã está no Andar {origem}. Chegue ao Andar "
                                     f"{origem + 1} na Torre antes de levar o clã pra lá."}
    membros = [m for m in listar_membros(owner_id) if int(m.get("vivo", 1))]
    if any(m.get("area_id") for m in membros):
        return {"ok": False, "erro": "Recolha os lutadores dos postos antes de partir — "
                                     "eles não podem estar em dois lugares."}
    if not lutadores:
        return {"ok": False, "erro": "Nenhum lutador vivo pra partir."}
    minimo = J.racoes_necessarias(destino, len(lutadores))
    comida = max(0, min(int(comida), J.comida_maxima(destino, len(lutadores))))
    if comida < minimo:
        return {"ok": False, "erro": f"Leve pelo menos {minimo} de comida (as rações do caminho)."}
    with _conn() as c:
        cur = c.execute("UPDATE clan SET comida = comida - ? WHERE owner_id = ? AND comida >= ?",
                        (comida, owner_id, comida))
        c.commit()
        if cur.rowcount == 0:
            return {"ok": False, "erro": f"O celeiro só tem {clan['comida']} de comida."}
    t = J.nova_travessia(origem, destino, lutadores, comida, rng)
    gravar_jornada(owner_id, t)
    return {"ok": True, "jornada": t}


def encerrar_jornada(owner_id: int, t: dict) -> dict:
    """Entrega o resultado: chegou → o clã MUDA de andar. Material por rank,
    comida que sobrou, ferimentos e a Memória. O OURO volta no resultado pra
    rota somar em `p` (clan_repo não mexe no ouro do personagem)."""
    from game import clan_jornada as J
    r = J.resultado_final(t)
    agora = int(time.time())
    clan = carregar_clan(owner_id)
    mats = dict(clan["materiais"])
    for rank, qtd in r["material"].items():
        mats[int(rank)] = int(mats.get(int(rank), 0)) + int(qtd)
    texto = {"sucesso": f"🏁 O clã atravessou do Andar {t['origem']} ao Andar {t['destino']} "
                        f"({r['batalhas']} batalha(s) vencida(s)).",
             "recuou": f"↩️ A travessia ao Andar {t['destino']} voltou antes do fim.",
             "fracasso": f"💀 A travessia ao Andar {t['destino']} terminou com todos caídos."}.get(
                 r["fim"], "A travessia terminou.")
    with _conn() as c:
        c.execute("UPDATE clan SET couro = couro + ? WHERE owner_id = ?", (int(r.get("couro", 0)), owner_id))
        c.execute("UPDATE clan SET materiais = ?, comida = comida + ?, jornada = NULL,"
                  " andar = CASE WHEN ? THEN ? ELSE andar END WHERE owner_id = ?",
                  (json.dumps({str(k): v for k, v in mats.items()}), r["comida_volta"],
                   1 if r["chegou"] else 0, int(t["destino"]), owner_id))
        for slot, qtd in r["ferimentos"].items():
            c.execute("UPDATE clan_membro SET ferimento = MIN(?, ferimento + ?)"
                      " WHERE owner_id = ? AND slot = ? AND vivo = 1",
                      (FERIMENTO_MAX, int(qtd), owner_id, int(slot)))
        c.execute("UPDATE clan SET memorias = ? WHERE owner_id = ?",
                  (json.dumps(_somar_memorias(clan, [{"tipo": "jornada", "texto": texto}], agora)),
                   owner_id))
        c.commit()
    if r["chegou"]:
        r["posto_revelado"] = revelar_na_chegada(owner_id, int(t["destino"]))
        segurado = ponto(clan["ponto_id"]) if clan.get("ponto_id") else None
        if segurado:
            from game import territorio as _T
            if _T.andar_do_ponto(segurado) != int(t["destino"]):
                with _conn() as c:
                    _largar(c, owner_id, clan["ponto_id"])
                    _anotar(c, owner_id, f"🏳️ Ao mudar de andar, o clã deixou {segurado['nome']} pra trás.")
                    c.commit()
                r["ponto_deixado"] = segurado["nome"]
    return r



# ------------------------------------------------------ onde o clã trabalha

def andar_de_trabalho(clan: dict, tower_floor: int) -> int:
    """O andar onde o clã trabalha no AFK: o andar onde ele ESTÁ
    (`clan.andar`), nunca além de onde o jogador chegou na Torre.

    🧭 20/09/2026 (2ª regra, do dev): "não se anda mais que 1 andar, e o clã
    só domina os pontos onde ele está". Os postos dos andares que ficaram
    pra trás NÃO são mais trabalhados — mudar de andar é recomeçar a achar
    postos. A 1ª versão deixava trabalhar em todos os andares de 1 até o do
    clã, o que pedia uma logística de caravanas entre andares distantes; com
    a regra do dev essa distância não existe, e a logística saiu inteira.
    Uma regra, um lugar: as rotas que oferecem áreas passam por aqui."""
    return max(1, min(int(tower_floor or 1), int(clan.get("andar") or 1)))


def postos_descobertos(owner_id: int) -> dict:
    """Os postos achados. Clã sem nenhum ganha a Clareira do Andar 1 — sem
    ela um clã novo não teria onde pôr ninguém pra trabalhar nem comida
    pra pagar a primeira exploração."""
    clan = carregar_clan(owner_id)
    try:
        postos = json.loads(clan.get("postos") or "{}")
    except ValueError:
        postos = {}
    if not postos:
        from game.clan_postos import posto_id
        pid = posto_id(1, "clareira")
        postos = {pid: {"id": pid, "andar": 1, "tipo": "clareira", "estrelas": 2, "mult": 1.0}}
        _gravar_postos(owner_id, postos)
    return postos


def _gravar_postos(owner_id: int, postos: dict) -> None:
    with _conn() as c:
        c.execute("UPDATE clan SET postos = ? WHERE owner_id = ?", (json.dumps(postos), owner_id))
        c.commit()


def areas_do_cla(owner_id: int, tower_floor: int) -> dict:
    """🔎 As áreas do AFK são os postos que o clã ACHOU no andar onde ele
    está — só esses."""
    from game.clan_postos import area_do_posto
    andar = andar_de_trabalho(carregar_clan(owner_id), tower_floor)
    return {pid: area_do_posto(pt) for pid, pt in postos_descobertos(owner_id).items()
            if int(pt["andar"]) == andar}


def explorar_andar(owner_id: int, andar: int, tower_floor: int, rng=None) -> dict:
    """Manda uma busca por postos num andar que o clã alcança. Custa comida
    na hora — achando ou não."""
    from game import clan_postos as P
    rng = rng or random.Random()
    clan = carregar_clan(owner_id)
    andar = int(andar)
    if andar != andar_de_trabalho(clan, tower_floor):
        return {"ok": False, "erro": "O clã só explora o andar onde está."}
    descobertos = postos_descobertos(owner_id)
    if not P.escondidos(andar, descobertos):
        return {"ok": False, "erro": f"Não há mais nada escondido no Andar {andar}."}
    custo = P.custo_exploracao(andar)
    with _conn() as c:
        cur = c.execute("UPDATE clan SET comida = comida - ? WHERE owner_id = ? AND comida >= ?",
                        (custo, owner_id, custo))
        c.commit()
        if cur.rowcount == 0:
            return {"ok": False, "erro": f"Explorar o Andar {andar} custa {custo} de comida."}
    achado = P.explorar(andar, descobertos, rng)
    if achado:
        descobertos[achado["id"]] = achado
        _gravar_postos(owner_id, descobertos)
        return {"ok": True, "achado": P.area_do_posto(achado), "custo": custo}
    return {"ok": True, "achado": None, "custo": custo}


def revelar_na_chegada(owner_id: int, andar: int, rng=None) -> dict | None:
    """Quem chega a um andar novo numa travessia já acha UM posto por lá."""
    from game import clan_postos as P
    descobertos = postos_descobertos(owner_id)
    achado = P.explorar(int(andar), descobertos, rng or random.Random(), garantido=True)
    if achado:
        descobertos[achado["id"]] = achado
        _gravar_postos(owner_id, descobertos)
        return P.area_do_posto(achado)
    return None


def recolher_fora_do_alcance(owner_id: int, areas: dict) -> list:
    """Lutador num posto que o clã não alcança volta pra casa, com o nome
    devolvido pra tela avisar. Sem isto, `rodar_afk` pulava o posto em
    silêncio (`if not area: continue`) e o lutador ficaria "trabalhando"
    sem produzir nada — a pior forma de bug, a que parece funcionar."""
    fora = [m for m in listar_membros(owner_id)
            if m.get("area_id") and m["area_id"] not in areas]
    if fora:
        with _conn() as c:
            for m in fora:
                c.execute("UPDATE clan_membro SET area_id = NULL, posto_id = NULL"
                          " WHERE owner_id = ? AND slot = ?", (owner_id, m["slot"]))
            c.commit()
    return [m.get("nome") or f"Membro {m['slot']}" for m in fora]



# ------------------------------------------------------------------ equipes
# 👥 A aldeia por equipes (game/clan_equipes.py). `clan.equipes` guarda
# {posto_id: {"coletores": [ids], "guardas": [ids]}}; cada habitante sabe a
# função ('coletor' | 'guarda') e a equipe. Uma equipe só sai com guarda.

EQUIPE_DO_PONTO = "ponto"
# 🏰 (dev, 20/09) a CIDADE — onde fica o que a aldeia tem — também é atacada:
# os guardas desta "equipe" ficam em casa e são a defesa dela.
EQUIPE_DA_CIDADE = "cidade"
CHANCE_SITUACAO_POR_EQUIPE = 0.35


def equipes_do_cla(owner_id: int) -> dict:
    try:
        return json.loads(carregar_clan(owner_id).get("equipes") or "{}")
    except ValueError:
        return {}


def _gravar_equipes(c, owner_id: int, equipes: dict) -> None:
    c.execute("UPDATE clan SET equipes = ? WHERE owner_id = ?", (json.dumps(equipes), owner_id))


def montar_equipe(owner_id: int, posto_id: str, coletores: list, guardas: list,
                  tower_floor: int, recurso: str | None = None) -> dict:
    """Monta (ou refaz) a equipe de um posto. Confere TUDO antes de gravar:
    posto do andar do clã, ao menos um guarda, guarda com talento de guarda,
    coletor com talento pro recurso do posto, ninguém nos dois papéis."""
    from game import clan_equipes as E
    areas = areas_do_cla(owner_id, tower_floor)
    area = areas.get(posto_id)
    if posto_id in (EQUIPE_DO_PONTO, EQUIPE_DA_CIDADE):
        area = {"tipo": None}              # a equipe do ponto do mapa / a guarnição da cidade
    if not area:
        return {"ok": False, "erro": "Esse posto não é do andar onde o clã está."}
    coletores = [int(x) for x in (coletores or [])]
    guardas = [int(x) for x in (guardas or [])]
    if posto_id == EQUIPE_DA_CIDADE and coletores:
        return {"ok": False, "erro": "A guarnição da cidade é só de guardas."}
    if posto_id == EQUIPE_DO_PONTO and coletores:
        from game import territorio as _T
        seg = ponto(carregar_clan(owner_id).get("ponto_id") or 0)
        if seg and _T.TIPOS.get(seg["tipo"], {}).get("so_guardas"):
            return {"ok": False, "erro": f"{seg['nome']} só aceita guardas — sem coletores."}
    # Equipe pode ficar INCOMPLETA (tirar gente um a um tem que funcionar);
    # ela só não SAI sem guarda e sem coletor (`sessao_das_equipes`). Vazia
    # de todo, ela deixa de existir.
    if set(coletores) & set(guardas):
        return {"ok": False, "erro": "Ninguém pode ser coletor e guarda ao mesmo tempo."}
    vivos = {int(h["id"]): h for h in listar_habitantes(owner_id)}
    recurso_do_posto = E.RECURSO_DO_POSTO.get(area.get("tipo"), "comida")
    recurso = recurso if recurso in RECURSOS_DE_EQUIPE else (
        (equipes_do_cla(owner_id).get(posto_id) or {}).get("recurso") or recurso_do_posto)
    for i in guardas:
        h = vivos.get(i)
        if not h or not E.pode(h, "guarda"):
            return {"ok": False, "erro": f"{(h or {}).get('nome', 'Alguém')} não tem talento de guarda (0★)."}
        if E.em_treino(h):
            horas = max(1, (int(h["treino_ate"]) - int(time.time()) + 3599) // 3600)
            return {"ok": False, "erro": f"{h['nome']} ainda está no treinamento de cavaleiro (~{horas}h)."}
    for i in coletores:
        h = vivos.get(i)
        if posto_id == EQUIPE_DO_PONTO:
            if not h:
                return {"ok": False, "erro": "Habitante desconhecido."}
            continue                         # no ponto, qualquer coletor serve
        if not h or not any(E.pode(h, p) for p, r in E.COLETA.items() if r == recurso):
            return {"ok": False, "erro": f"{(h or {}).get('nome', 'Alguém')} não sabe coletar {recurso} (0★)."}
    equipes = equipes_do_cla(owner_id)
    envolvidos = set(coletores) | set(guardas)
    for pid, eq in list(equipes.items()):       # quem mudou de equipe sai da antiga
        eq["coletores"] = [x for x in eq.get("coletores", []) if x not in envolvidos]
        eq["guardas"] = [x for x in eq.get("guardas", []) if x not in envolvidos]
        if pid != posto_id and not eq["coletores"] and not eq["guardas"]:
            del equipes[pid]                    # equipe que ficou vazia deixa de existir
    if coletores or guardas:
        # ⏳ mexer na equipe NÃO renova as 12h (senão era só trocar alguém
        # pra ficar pra sempre); equipe nova no posto começa a contar agora
        desde = (equipes.get(posto_id) or {}).get("desde") or int(time.time())
        equipes[posto_id] = {"coletores": coletores, "guardas": guardas, "desde": desde}
        if recurso != recurso_do_posto:
            equipes[posto_id]["recurso"] = recurso   # coleta fora do tipo do posto
    else:
        equipes.pop(posto_id, None)
    _sincronizar_funcoes(owner_id, equipes)
    return {"ok": True, "equipe": equipes.get(posto_id, {"coletores": [], "guardas": []})}


# ⏳ ESTADIAS DE 12h (25/09/2026, regra do dev): "o refúgio vai ter tempo de
# 12h, depois disso ele sai, e os outros postos também só 12h". Uma equipe
# fica no posto 12h e volta pra aldeia; o clã fica no refúgio 12h e sai.
# A guarnição da cidade (fica em casa) e a equipe do ponto do mapa (que tem
# a própria regra de integridade e ataque) não entram nessa conta.
# Equipe/refúgio de antes desta regra, sem hora de chegada, ganha a hora de
# agora — ninguém é despejado na hora do commit.
ESTADIA_SEG = 12 * 3600


def restante_da_estadia(desde, agora: int | None = None) -> int:
    agora = int(agora or time.time())
    return max(0, int(desde or agora) + ESTADIA_SEG - agora)


def expirar_estadias(owner_id: int, agora: int | None = None) -> dict:
    """Encerra o que passou de 12h. Devolve o que saiu, pra tela avisar."""
    agora = int(agora or time.time())
    equipes = equipes_do_cla(owner_id)
    saiu, mudou = [], False
    for pid in list(equipes):
        if pid in (EQUIPE_DO_PONTO, EQUIPE_DA_CIDADE):
            continue
        eq = equipes[pid]
        if not eq.get("desde"):
            eq["desde"] = agora
            mudou = True
        elif restante_da_estadia(eq["desde"], agora) <= 0:
            saiu.append(pid)
            del equipes[pid]
            mudou = True
    if mudou:
        _sincronizar_funcoes(owner_id, equipes)
    refugio = None
    clan = carregar_clan(owner_id)
    pt = ponto(clan.get("ponto_id") or 0) if clan.get("ponto_id") else None
    if pt and pt.get("seguro"):
        with _conn() as c:
            if not clan.get("ponto_desde"):
                c.execute("UPDATE clan SET ponto_desde = ? WHERE owner_id = ?", (agora, owner_id))
            elif restante_da_estadia(clan["ponto_desde"], agora) <= 0:
                c.execute("UPDATE clan SET ponto_id = NULL, ponto_desde = NULL WHERE owner_id = ?", (owner_id,))
                _anotar(c, owner_id, f"🏕️ As 12h no {pt['nome']} acabaram — o clã saiu do refúgio.")
                refugio = pt["nome"]
            c.commit()
    return {"equipes": saiu, "refugio": refugio}


def desfazer_equipe(owner_id: int, posto_id: str) -> dict:
    equipes = equipes_do_cla(owner_id)
    if posto_id not in equipes:
        return {"ok": False, "erro": "Não há equipe nesse posto."}
    del equipes[posto_id]
    _sincronizar_funcoes(owner_id, equipes)
    return {"ok": True}


def _sincronizar_funcoes(owner_id: int, equipes: dict) -> None:
    """A função/equipe de cada habitante segue as equipes (uma fonte só)."""
    papel = {}
    for pid, eq in equipes.items():
        for i in eq.get("coletores", []):
            papel[int(i)] = ("coletor", pid)
        for i in eq.get("guardas", []):
            papel[int(i)] = ("guarda", pid)
    with _conn() as c:
        _gravar_equipes(c, owner_id, equipes)
        for h in listar_habitantes(owner_id):
            funcao, pid = papel.get(int(h["id"]), (None, None))
            c.execute("UPDATE clan_habitante SET funcao = ?, equipe = ? WHERE id = ? AND owner_id = ?",
                      (funcao, pid, int(h["id"]), owner_id))
        c.commit()


FATOR_BAIXA_POR_FALTA = 0.5   # (25/09) faltou manutenção: as equipes rendem metade
# 🧺 (25/09, dev) "as equipes sempre funcionam: mesmo sem estar num posto de
# madeira ainda coleta, mas não tem o bônus do posto". A equipe escolhe o
# recurso (`eq["recurso"]`; sem escolha = o do posto). No posto CERTO vale o
# bônus das estrelas (0,85/1,0/1,2); fora dele, 0,7 — abaixo até de um posto
# de 1★, pra o posto certo sempre valer a pena procurar.
FATOR_SEM_POSTO = 0.7
RECURSOS_DE_EQUIPE = ("comida", "madeira", "couro", "ferro")


def bocas_do_cla(owner_id: int) -> int:
    """🌾 (25/09, dev) "se tem 50 pessoas na aldeia, estão comendo": o celeiro
    conta os personagens E os aldeões vivos. Antes contava só os personagens
    (3 → teto 180) — com 50 aldeões comendo 300 por sessão, a aldeia não
    guardava nem uma sessão, e a sobra das equipes se perdia."""
    with _conn() as c:
        # 🏙️ cavaleiro come na cidade, não no celeiro da aldeia
        aldeoes = c.execute("SELECT COUNT(*) FROM clan_habitante WHERE owner_id = ? AND vivo = 1"
                            " AND (cavaleiro IS NULL OR cavaleiro = '')", (owner_id,)).fetchone()[0]
    return len(listar_membros(owner_id)) + int(aldeoes)


def recurso_e_fator_da_equipe(eq: dict, area: dict) -> tuple[str, float]:
    from game import clan_equipes as E
    do_posto = E.RECURSO_DO_POSTO.get(area.get("tipo"), "comida")
    recurso = eq.get("recurso") if eq.get("recurso") in RECURSOS_DE_EQUIPE else do_posto
    if recurso == do_posto:
        return recurso, {1: 0.85, 2: 1.0, 3: 1.2}.get(int(area.get("estrelas") or 2), 1.0)
    return recurso, FATOR_SEM_POSTO


def sessao_das_equipes(owner_id: int, clan: dict, habitantes: list, ticks: int, rng,
                       comida_livre: int, madeira_ganha: int, couro_ganho: int,
                       material_ganho: dict) -> dict:
    """Uma sessão das equipes: paga a MANUTENÇÃO da aldeia; faltando algo, é
    GREVE (ninguém sai). Pagando, cada equipe sai com a escolta — que dá
    conta ou não da ameaça do andar — e os coletores trazem o recurso do
    posto. Puro na conta (clan_equipes); aqui só junta as peças."""
    from game import clan_equipes as E
    fracao = min(1.0, max(0, int(ticks)) / TETO_TICKS)
    vivos = [h for h in habitantes if int(h.get("vivo", 1))]
    pago = {"comida": 0, "madeira": 0, "couro": 0, "ferro": 0}
    rel = {"ganho": {"comida": 0, "madeira": 0, "couro": 0}, "material": {}, "pago": pago,
           "greve": [], "saidas": [], "situacoes": [], "xp_frases": []}
    if not ticks or not vivos:
        return rel
    # 🏺 Cantil sem Fundo: a aldeia gasta menos pra se manter
    from game import clan_reliquias as _R0
    _fator_manut = _R0.fator(reliquias_do_cla(owner_id)["ativas"], "manutencao")
    custo = {r: int(round(q / _fator_manut))
             for r, q in E.manutencao_da_aldeia(vivos, fracao).items()}
    estoque = {"comida": max(0, int(comida_livre)),
               "madeira": int(clan.get("madeira", 0)) + int(madeira_ganha),
               "couro": int(clan.get("couro", 0)) + int(couro_ganho),
               "ferro": int(clan["materiais"].get(1, 0)) + int(material_ganho.get(1, 0))}
    falta = E.falta_pra_manter(estoque, custo)
    # 📉 25/09/2026 (dev): "em vez de greve, uma baixa de 50%". Antes, faltar
    # 3 de ferro parava TODA a coleta (inclusive a de comida) e a aldeia
    # afundava. Agora paga o que tem do que faltou, e as equipes saem assim
    # mesmo, rendendo METADE. `greve` continua no relatório (o que faltou).
    baixa = 1.0
    if falta:
        rel["greve"] = [f"{q} de {r}" for r, q in falta.items()]
        baixa = FATOR_BAIXA_POR_FALTA
        custo = {r: min(int(q), max(0, int(estoque.get(r, 0)))) for r, q in custo.items()}
    rel["baixa"] = baixa
    pago.update(custo)

    from game import clan_reliquias as _R
    ativas = reliquias_do_cla(owner_id)["ativas"]
    por_id = {int(h["id"]): h for h in vivos if h.get("id")}
    areas = areas_do_cla(owner_id, 10 ** 6)
    for pid, eq in equipes_do_cla(owner_id).items():
        area = areas.get(pid)
        guardas = [por_id[i] for i in eq.get("guardas", []) if i in por_id]
        coletores = [por_id[i] for i in eq.get("coletores", []) if i in por_id]
        if not area or not guardas or not coletores:
            continue                            # sem escolta ninguém sai
        saida = E.resultado_da_saida(guardas, area["andar"], rng)
        recurso, fator_posto = recurso_e_fator_da_equipe(eq, area)
        total = sum(E.producao_do_coletor(h, recurso, fracao) for h in coletores)
        # 📖 (26/09) Crônicas: decisão em campo (×1,5, ×0,5...) e laços —
        # irmãos na mesma equipe +10%; rivais juntos cansam mais (abaixo)
        from game.cronicas import fator_da_equipe
        ids_col = {int(h["id"]) for h in coletores}
        irmaos = sum(1 for h in coletores if h.get("laco") == "irmaos" and int(h.get("parente_de") or 0) in ids_col)
        fator_laco = 1.10 if irmaos >= 2 else 1.0
        rivais = [h for h in coletores if h.get("laco") == "rivais" and int(h.get("parente_de") or 0) in ids_col]
        for h in rivais:
            h["fadiga"] = min(100, int(h.get("fadiga") or 0) + int(round(15 * fracao)))
        qtd = int(total * saida["fator"] * fator_posto * baixa * fator_da_equipe(clan, pid) * fator_laco
                  * _R.fator(ativas, "producao")
                  * (_R.fator(ativas, "material_extra") if recurso == "ferro" else 1.0))
        if recurso == "ferro":
            # rank 2 só no veio rico — e só com a equipe tirando FERRO de lá
            rank = 2 if (area.get("tipo") == "veio_rico" and fator_posto != FATOR_SEM_POSTO) else 1
            rel["material"][rank] = rel["material"].get(rank, 0) + qtd
        else:
            rel["ganho"][recurso] += qtd
        if saida["ferido"]:
            for h in coletores:
                h["fadiga"] = min(100, int(h.get("fadiga") or 0) + 20)
        # ⭐ XP de quem trabalhou: coletor pelo tempo coletando, guarda pela
        # ameaça que enfrentou (mais fundo, mais aprende; escolta que apanhou
        # aprende um pouco mais)
        from game import clan_habitantes as _H
        for h in coletores:
            rel["xp_frases"] += _H.ganhar_xp(h, int(round(XP_COLETOR_SESSAO * fracao)))
        for g in guardas:
            rel["xp_frases"] += _H.ganhar_xp(g, int(round((10 + saida["ameaca"] / 10 + (5 if saida["ferido"] else 0))
                                                         * fracao)))
        rel["saidas"].append({"posto": area["nome"], "recurso": recurso, "qtd": qtd,
                              "poder": saida["poder"], "ameaca": saida["ameaca"],
                              "ferido": saida["ferido"]})
    return rel



def comprar_de_outras_aldeias(owner_id: int, recurso: str, quantidade: int) -> dict:
    """Compra madeira, couro ou ferro (material rank 1) de outras aldeias. Só
    o lado do CLÃ: soma no estoque e devolve o custo em ouro pra rota cobrar
    de `p`. Comida tem teto de celeiro e vai por `comprar_comida`."""
    from game.clan_equipes import PRECO_OUTRAS_ALDEIAS
    quantidade = max(0, int(quantidade))
    if recurso == "comida":
        return comprar_comida(owner_id, quantidade)
    if recurso not in ("madeira", "couro", "ferro"):
        return {"ok": False, "erro": "As outras aldeias não vendem isso."}
    if quantidade < 1:
        return {"ok": False, "erro": "Quantidade precisa ser maior que zero."}
    with _conn() as c:
        if recurso == "ferro":
            clan = carregar_clan(owner_id)
            mats = dict(clan["materiais"])
            mats[1] = int(mats.get(1, 0)) + quantidade
            c.execute("UPDATE clan SET materiais = ? WHERE owner_id = ?",
                      (json.dumps({str(k): v for k, v in mats.items()}), owner_id))
        else:
            c.execute(f"UPDATE clan SET {recurso} = {recurso} + ? WHERE owner_id = ?",
                      (quantidade, owner_id))
        c.commit()
    return {"ok": True, "comprado": quantidade,
            "custo_ouro": quantidade * PRECO_OUTRAS_ALDEIAS[recurso]}



# ------------------------------------------------------------------ ferreiro

def trabalho_dos_habitantes(owner_id: int) -> dict:
    """{habitante_id: função} — o que cada um está FAZENDO agora: guarda, ou
    a profissão que coleta o recurso do posto da equipe dele."""
    from game import clan_equipes as E
    areas = areas_do_cla(owner_id, 10 ** 6)
    trabalho = {}
    for pid, eq in equipes_do_cla(owner_id).items():
        area = areas.get(pid)
        recurso = E.RECURSO_DO_POSTO.get((area or {}).get("tipo"))
        prof = next((p for p, r in E.COLETA.items() if r == recurso), None)
        for hid in eq.get("guardas", []):
            trabalho[int(hid)] = "guarda"
        if prof:
            for hid in eq.get("coletores", []):
                trabalho[int(hid)] = prof
    return trabalho


def usar_ferreiro(owner_id: int, trilha: str) -> dict:
    """⚒️ Faz a ação da vez numa trilha (nivelar os novos ou evoluir o lote),
    cobrando o material do CLÃ. Confere o estoque inteiro antes de cobrar."""
    from game import clan_ferreiro as F
    if trilha not in F.TRILHAS:
        return {"ok": False, "erro": "Trilha desconhecida."}
    habitantes = listar_habitantes(owner_id)
    plano = F.plano(habitantes, trilha, trabalho_dos_habitantes(owner_id))
    if plano["acao"] in ("nada", "maximo"):
        return {"ok": False, "erro": plano.get("motivo") or "Já está no tier máximo."}
    # 🏺 Martelo Frio: o ferreiro cobra menos material
    from game import clan_reliquias as _R1
    _desc = _R1.fator(reliquias_do_cla(owner_id)["ativas"], "ferreiro_desconto")
    if _desc > 1.0:
        plano["custo"] = {r: max(1, int(round(q / _desc))) for r, q in plano["custo"].items()}
    clan = carregar_clan(owner_id)
    for rank, qtd in plano["custo"].items():
        if int(clan["materiais"].get(int(rank), 0)) < qtd:
            return {"ok": False, "erro": f"Falta material rank {rank}: precisa de {qtd}, "
                                         f"o clã tem {clan['materiais'].get(int(rank), 0)}."}
    mats = dict(clan["materiais"])
    for rank, qtd in plano["custo"].items():
        mats[int(rank)] = int(mats.get(int(rank), 0)) - int(qtd)
    por_id = {int(h["id"]): h for h in habitantes}
    with _conn() as c:
        c.execute("UPDATE clan SET materiais = ? WHERE owner_id = ?",
                  (json.dumps({str(k): v for k, v in mats.items()}), owner_id))
        for hid in plano["quem"]:
            h = por_id[int(hid)]
            tiers = {k: F.tier_de(h, k) for k in F.TRILHAS if F.tier_de(h, k) > 1}
            tiers[trilha] = int(plano["alvo"])
            c.execute("UPDATE clan_habitante SET tiers = ? WHERE id = ? AND owner_id = ?",
                      (json.dumps(tiers), int(hid), owner_id))
        c.commit()
    return {"ok": True, "acao": plano["acao"], "alvo": plano["alvo"], "quantos": len(plano["quem"]),
            "custo": plano["custo"]}



# ------------------------------------------------------------------ batalha
# ⚔️ Fase 3 (game/clan_batalha.py): a equipe do ponto contra a equipe do ponto.

def _perder_equipe_do_ponto(c, perdedor: int, vencedor: int, nome_ponto: str, agora: int) -> dict:
    """Os guardas da equipe do ponto de `perdedor` MORREM; os coletores
    passam pro clã de `vencedor` (roubados — voltam sem função nem equipe)."""
    equipes = equipes_do_cla(perdedor)
    eq = equipes.pop(EQUIPE_DO_PONTO, None) or {"coletores": [], "guardas": []}
    for hid in eq.get("guardas", []):
        c.execute("UPDATE clan_habitante SET vivo = 0, causa = ?, morreu_em = ?, funcao = NULL,"
                  " equipe = NULL WHERE id = ? AND owner_id = ?",
                  (f"morto defendendo {nome_ponto}", agora, int(hid), perdedor))
    for hid in eq.get("coletores", []):
        c.execute("UPDATE clan_habitante SET owner_id = ?, funcao = NULL, equipe = NULL,"
                  " parente_de = NULL, laco = NULL WHERE id = ? AND owner_id = ?",
                  (vencedor, int(hid), perdedor))
    _gravar_equipes(c, perdedor, equipes)
    return {"mortos": len(eq.get("guardas", [])), "roubados": len(eq.get("coletores", []))}


def batalha_pelo_ponto(atacante: int, defensor: int, alvo: dict, nome_do_cla: str,
                       custo: int, rng) -> dict:
    """Guardas da equipe do ponto do atacante contra os do defensor (mais o
    personagem dele, se estiver de guarda). O defensor configurado pra FUGIR
    entrega o ponto sem luta. Lutando, quem perde tem os guardas mortos e os
    coletores roubados — nos dois sentidos."""
    from game import clan_batalha as B
    ataque_eq = equipes_do_cla(atacante).get(EQUIPE_DO_PONTO)
    if not ataque_eq or not ataque_eq.get("guardas"):
        return {"ok": False, "erro": "Monte a equipe do ponto (com guardas) antes de marchar "
                                     "contra outro clã — é ela que luta."}
    habs_a = {int(h["id"]): h for h in listar_habitantes(atacante)}
    habs_d = {int(h["id"]): h for h in listar_habitantes(defensor)}
    defesa_eq = equipes_do_cla(defensor).get(EQUIPE_DO_PONTO) or {"coletores": [], "guardas": []}
    clan_d = carregar_clan(defensor)
    from game import clan_reliquias as _R3
    f_a = _R3.fator(reliquias_do_cla(atacante)["ativas"], "poder_guarda")
    f_d = _R3.fator(reliquias_do_cla(defensor)["ativas"], "poder_guarda")
    poder_a = int(B.poder_da_escolta([habs_a[i] for i in ataque_eq["guardas"] if i in habs_a]) * f_a)
    poder_d = int(B.poder_da_escolta([habs_d[i] for i in defesa_eq["guardas"] if i in habs_d],
                                     extra=int(clan_d.get("guarda_pessoal") or 0)) * f_d)
    r = B.resolver(poder_a, poder_d, clan_d.get("defesa") or "lutar", rng)
    agora = int(time.time())
    ponto_id = int(alvo["id"])
    with _conn() as c:
        c.execute("UPDATE clan SET comida = MAX(0, comida - ?) WHERE owner_id = ?", (custo, atacante))
        consequencia = {}
        if r["resultado"] == "defesa":
            consequencia = _perder_equipe_do_ponto(c, atacante, defensor, alvo["nome"], agora)
            texto = (f"⚔️ O ataque a {alvo['nome']} foi repelido ({poder_a} × {poder_d}): "
                     f"{consequencia['mortos']} guarda(s) mortos, {consequencia['roubados']} coletor(es) "
                     f"levados pelo inimigo.")
            _anotar(c, atacante, texto)
            _anotar(c, defensor, f"🛡️ Repelimos {nome_do_cla} em {alvo['nome']} e trouxemos "
                                 f"{consequencia['roubados']} coletor(es) deles.")
            c.commit()
            _sincronizar_funcoes(atacante, equipes_do_cla(atacante))
            dar_xp(defensor, defesa_eq.get("guardas", []), XP_BATALHA)
            return {"ok": True, "venceu": False, "batalha": r, **consequencia, "texto": texto}
        if r["resultado"] == "ataque":
            consequencia = _perder_equipe_do_ponto(c, defensor, atacante, alvo["nome"], agora)
        else:   # fuga: a equipe do defensor volta pra casa inteira
            eqs = equipes_do_cla(defensor)
            eqs.pop(EQUIPE_DO_PONTO, None)
            _gravar_equipes(c, defensor, eqs)
        anterior = carregar_clan(atacante).get("ponto_id")
        _largar(c, atacante, anterior)
        c.execute("UPDATE territorio SET dono_tipo = 'jogador', dono_id = ?, dono_nome = ?,"
                  " guarnicao = ?, integridade = 100, desde = ? WHERE id = ?",
                  (str(atacante), nome_do_cla, poder_a, agora, ponto_id))
        c.execute("UPDATE clan SET ponto_id = ? WHERE owner_id = ?", (ponto_id, atacante))
        c.execute("UPDATE clan SET ponto_id = NULL WHERE owner_id = ? AND ponto_id = ?", (defensor, ponto_id))
        if r["resultado"] == "fuga":
            texto = f"🏃 A equipe de {alvo['dono_nome']} fugiu: {alvo['nome']} é nosso."
            _anotar(c, defensor, f"🏃 Fugimos de {nome_do_cla} e entregamos {alvo['nome']} — ninguém morreu.")
        else:
            texto = (f"🚩 Tomamos {alvo['nome']} ({poder_a} × {poder_d}): {consequencia['mortos']} guarda(s) "
                     f"deles mortos, {consequencia['roubados']} coletor(es) trazidos pra nossa aldeia.")
            _anotar(c, defensor, f"🏴 {nome_do_cla} tomou {alvo['nome']}: perdemos "
                                 f"{consequencia['mortos']} guarda(s) e {consequencia['roubados']} coletor(es).")
        _anotar(c, atacante, texto)
        c.commit()
    _sincronizar_funcoes(defensor, equipes_do_cla(defensor))
    if r["resultado"] == "ataque":
        dar_xp(atacante, ataque_eq.get("guardas", []), XP_BATALHA)
    return {"ok": True, "venceu": True, "batalha": r, **consequencia, "texto": texto}


def definir_defesa(owner_id: int, defesa: str) -> dict:
    from game.clan_batalha import DEFESAS
    if defesa not in DEFESAS:
        return {"ok": False, "erro": "Escolha 'lutar' ou 'fugir'."}
    with _conn() as c:
        c.execute("UPDATE clan SET defesa = ? WHERE owner_id = ?", (defesa, owner_id))
        c.commit()
    return {"ok": True, "defesa": defesa}


def definir_guarda_pessoal(owner_id: int, poder: int) -> None:
    with _conn() as c:
        c.execute("UPDATE clan SET guarda_pessoal = ? WHERE owner_id = ?", (max(0, int(poder)), owner_id))
        c.commit()



# ------------------------------------------------------------------ fundação

def fundar_aldeia(owner_id: int, gente: list, extras: dict, rng=None) -> list:
    """👥 O clã inicial que a fundação decidiu: cria os habitantes com o
    talento mínimo que a resposta prometeu (o resto é sorteio normal) e
    soma madeira/couro/ferro. Devolve quem chegou, pra tela contar."""
    from game import clan_habitantes as H
    rng = rng or random.Random()
    em_uso = {h["nome"] for h in listar_habitantes(owner_id, incluir_mortos=True)}
    novos = []
    for g in gente or []:
        for _ in range(int(g.get("quantos", 1))):
            prof = g.get("funcao")
            h = H.novo_habitante(rng, em_uso, profissao=prof if prof != "guarda" else None)
            h["talentos"][prof] = max(int(h["talentos"].get(prof, 0)), int(g.get("min", 1)))
            if prof == "guarda":
                h["profissao"] = "guarda"
            em_uso.add(h["nome"])
            novos.append(h)
    clan = carregar_clan(owner_id)
    mats = dict(clan["materiais"])
    mats[1] = int(mats.get(1, 0)) + int((extras or {}).get("ferro", 0))
    with _conn() as c:
        _gravar_habitantes(c, owner_id, novos, int(time.time()))
        c.execute("UPDATE clan SET madeira = madeira + ?, couro = couro + ?, materiais = ? WHERE owner_id = ?",
                  (int((extras or {}).get("madeira", 0)), int((extras or {}).get("couro", 0)),
                   json.dumps({str(k): v for k, v in mats.items()}), owner_id))
        c.commit()
    return [{"nome": h["nome"], "talentos": {k: v for k, v in h["talentos"].items() if v}} for h in novos]



# ------------------------------------------------------------------ explorar
# 🔎 (dev, 20/09) Uma EQUIPE explora o andar: custa comida, pode ser
# emboscada, e volta com 5 achados (postos, pontos do mapa, cidades de
# outros clãs). Escolher leva a equipe pra lá. Ver game/clan_explorar.py.

def achados_do_cla(owner_id: int) -> dict:
    try:
        return json.loads(carregar_clan(owner_id).get("achados") or "{}") or {}
    except ValueError:
        return {}


def _gravar_achados(owner_id: int, achados: dict) -> None:
    with _conn() as c:
        c.execute("UPDATE clan SET achados = ? WHERE owner_id = ?", (json.dumps(achados), owner_id))
        c.commit()


def explorar_com_equipe(owner_id: int, equipe: str, tower_floor: int, rng=None) -> dict:
    from game import clan_explorar as X, clan_postos as P
    rng = rng or random.Random()
    eq = equipes_do_cla(owner_id).get(equipe)
    habs = {int(h["id"]): h for h in listar_habitantes(owner_id)}
    guardas = [habs[i] for i in (eq or {}).get("guardas", []) if i in habs]
    if not eq or not guardas:
        return {"ok": False, "erro": "Só uma equipe COM GUARDA pode explorar — é a escolta que aguenta o caminho."}
    clan = carregar_clan(owner_id)
    andar = andar_de_trabalho(clan, tower_floor)
    custo, lenha = X.custo_da_busca(andar), X.madeira_da_busca(andar)
    with _conn() as c:
        cur = c.execute("UPDATE clan SET comida = comida - ?, madeira = madeira - ?"
                        " WHERE owner_id = ? AND comida >= ? AND madeira >= ?",
                        (custo, lenha, owner_id, custo, lenha))
        c.commit()
        if cur.rowcount == 0:
            return {"ok": False, "erro": f"Explorar custa {custo} de comida e {lenha} de madeira."}
    # emboscada no caminho
    atacada = X.emboscada(guardas, andar, rng)
    from game import clan_reliquias as _R2
    _bonus_achar = _R2.fator(reliquias_do_cla(owner_id)["ativas"], "achar_melhor")
    if atacada and atacada["ferido"]:
        with _conn() as c:
            for hid in list(eq.get("guardas", [])) + list(eq.get("coletores", [])):
                c.execute("UPDATE clan_habitante SET fadiga = MIN(100, fadiga + ?) WHERE id = ? AND owner_id = ?",
                          (X.CANSACO_DA_EMBOSCADA, int(hid), owner_id))
            c.commit()
    # o que dá pra achar no andar
    descobertos = dict(postos_descobertos(owner_id))
    postos = []
    for _ in range(3 if _bonus_achar <= 1.0 else 4):    # 🏺 Mapa Rasgado: mais opções
        achado = P.explorar(andar, descobertos, rng, garantido=True)
        if not achado:
            break
        descobertos[achado["id"]] = achado
        postos.append(achado)
    pontos = [p for p in listar_mapa(andar) if not p["seguro"] and p["id"] != clan.get("ponto_id")]
    with _conn() as c:
        vizinhos = [dict(l) for l in c.execute(
            "SELECT owner_id, nome FROM clan WHERE andar = ? AND owner_id != ?", (andar, owner_id)).fetchall()]
    lista = []
    for a in X.montar_lista(postos, pontos, vizinhos, rng):
        d = a["dado"]
        if a["tipo"] == "posto":
            area = P.area_do_posto(d)
            lista.append({"tipo": "posto", "titulo": area["nome"], "posto": d,
                          "detalhe": f"rende {area['rende']} de {area['recurso']}"})
        elif a["tipo"] == "ponto":
            dono = d.get("dono_nome") or "sem dono"
            lista.append({"tipo": "ponto", "titulo": d["nome"], "ponto_id": d["id"],
                          "detalhe": f"{'🤖' if d.get('dono_tipo') == 'bot' else '🧑' if d.get('dono_tipo') else '·'} {dono}"})
        else:
            lista.append({"tipo": "cidade", "titulo": f"🏰 Cidade de {d.get('nome') or 'um clã'}",
                          "alvo": int(d["owner_id"]), "detalhe": "outro clã neste andar — dá pra saquear"})
    achados = {"equipe": equipe, "andar": andar, "lista": lista}
    _gravar_achados(owner_id, achados)
    if atacada:          # quem segurou (ou tentou segurar) a emboscada aprende
        dar_xp(owner_id, eq.get("guardas", []), XP_EMBOSCADA)
    return {"ok": True, "custo": custo, "madeira": lenha, "emboscada": atacada, **achados}


def _mover_equipe(owner_id: int, de: str, para: str) -> None:
    equipes = equipes_do_cla(owner_id)
    eq = equipes.pop(de, None)
    if eq is None:
        return
    equipes[para] = eq                     # quem estava no destino volta pra casa
    eq["desde"] = int(time.time())         # ⏳ lugar novo, estadia nova (12h)
    _sincronizar_funcoes(owner_id, equipes)


def escolher_achado(owner_id: int, indice: int, nome_do_cla: str, tower_floor: int, rng=None) -> dict:
    """Leva a equipe que explorou pro achado escolhido: posto (a equipe fica
    lá), ponto do mapa (marcha — batalha se tiver dono), cidade de outro clã
    (ataque: saque ou derrota)."""
    rng = rng or random.Random()
    ach = achados_do_cla(owner_id)
    lista = ach.get("lista") or []
    if not (0 <= int(indice) < len(lista)):
        return {"ok": False, "erro": "Esse achado não está mais na lista — explore de novo."}
    a, equipe = lista[int(indice)], ach.get("equipe")
    if equipe not in equipes_do_cla(owner_id):
        return {"ok": False, "erro": "A equipe que explorou não existe mais."}
    if int(ach.get("andar") or 0) != andar_de_trabalho(carregar_clan(owner_id), tower_floor):
        return {"ok": False, "erro": "O clã mudou de andar — explore de novo."}
    _gravar_achados(owner_id, {})          # a lista é consumida ao escolher
    if a["tipo"] == "posto":
        postos = postos_descobertos(owner_id)
        postos[a["posto"]["id"]] = a["posto"]
        _gravar_postos(owner_id, postos)
        _mover_equipe(owner_id, equipe, a["posto"]["id"])
        return {"ok": True, "texto": f"A equipe ficou em {a['titulo']}."}
    if a["tipo"] == "ponto":
        if equipe != EQUIPE_DO_PONTO:
            _mover_equipe(owner_id, equipe, EQUIPE_DO_PONTO)
        return conquistar_ponto(owner_id, a["ponto_id"], nome_do_cla, rng)
    return atacar_cidade(owner_id, int(a["alvo"]), equipe, nome_do_cla, rng)


def atacar_cidade(atacante: int, defensor: int, equipe: str, nome_do_cla: str, rng=None) -> dict:
    """🏰 Equipe contra a GUARNIÇÃO da cidade do outro clã (+ o personagem
    dele de guarda). Vencendo: a guarnição morre e o atacante leva 20% do
    estoque de lá. Perdendo: a regra de sempre — guardas do atacante mortos,
    coletores dele levados pelo defensor."""
    from game import clan_batalha as B, clan_explorar as X
    rng = rng or random.Random()
    habs_a = {int(h["id"]): h for h in listar_habitantes(atacante)}
    habs_d = {int(h["id"]): h for h in listar_habitantes(defensor)}
    eq_a = equipes_do_cla(atacante).get(equipe) or {}
    eq_d = equipes_do_cla(defensor).get(EQUIPE_DA_CIDADE) or {"guardas": []}
    clan_d = carregar_clan(defensor)
    from game import clan_reliquias as _R4
    poder_a = int(B.poder_da_escolta([habs_a[i] for i in eq_a.get("guardas", []) if i in habs_a])
                  * _R4.fator(reliquias_do_cla(atacante)["ativas"], "poder_guarda"))
    # 🏺 Sino da Vigia: a guarnição defende melhor a CIDADE
    poder_d = int(B.poder_da_escolta([habs_d[i] for i in eq_d.get("guardas", []) if i in habs_d],
                                     extra=int(clan_d.get("guarda_pessoal") or 0))
                  * _R4.fator(reliquias_do_cla(defensor)["ativas"], "poder_guarda")
                  * _R4.fator(reliquias_do_cla(defensor)["ativas"], "defesa_cidade"))
    r = B.resolver(poder_a, max(1, poder_d), "lutar", rng)
    agora = int(time.time())
    with _conn() as c:
        if r["resultado"] == "defesa":
            eqs = equipes_do_cla(atacante)
            perdida = eqs.pop(equipe, {"coletores": [], "guardas": []})
            for hid in perdida.get("guardas", []):
                c.execute("UPDATE clan_habitante SET vivo = 0, causa = ?, morreu_em = ?, funcao = NULL,"
                          " equipe = NULL WHERE id = ? AND owner_id = ?",
                          ("morto atacando uma cidade", agora, int(hid), atacante))
            for hid in perdida.get("coletores", []):
                c.execute("UPDATE clan_habitante SET owner_id = ?, funcao = NULL, equipe = NULL,"
                          " parente_de = NULL, laco = NULL WHERE id = ? AND owner_id = ?",
                          (defensor, int(hid), atacante))
            _gravar_equipes(c, atacante, eqs)
            texto = f"⚔️ A cidade resistiu ({poder_a} × {poder_d}): perdemos a equipe."
            _anotar(c, atacante, texto)
            _anotar(c, defensor, f"🛡️ A guarnição repeliu {nome_do_cla} e trouxe os coletores deles.")
            c.commit()
            _sincronizar_funcoes(atacante, equipes_do_cla(atacante))
            dar_xp(defensor, eq_d.get("guardas", []), XP_BATALHA)
            return {"ok": True, "venceu": False, "batalha": r, "texto": texto}
        # venceu: guarnição morre, 20% do estoque vem pro atacante
        for hid in eq_d.get("guardas", []):
            c.execute("UPDATE clan_habitante SET vivo = 0, causa = ?, morreu_em = ?, funcao = NULL,"
                      " equipe = NULL WHERE id = ? AND owner_id = ?",
                      ("morto defendendo a cidade", agora, int(hid), defensor))
        mats_d = dict(clan_d["materiais"])
        saque = {"comida": int(int(clan_d["comida"]) * X.SAQUE_DA_CIDADE),
                 "madeira": int(int(clan_d.get("madeira", 0)) * X.SAQUE_DA_CIDADE),
                 "couro": int(int(clan_d.get("couro", 0)) * X.SAQUE_DA_CIDADE),
                 "ferro": int(int(mats_d.get(1, 0)) * X.SAQUE_DA_CIDADE)}
        mats_d[1] = int(mats_d.get(1, 0)) - saque["ferro"]
        c.execute("UPDATE clan SET comida = comida - ?, madeira = madeira - ?, couro = couro - ?,"
                  " materiais = ? WHERE owner_id = ?",
                  (saque["comida"], saque["madeira"], saque["couro"],
                   json.dumps({str(k): v for k, v in mats_d.items()}), defensor))
        clan_a = carregar_clan(atacante)
        mats_a = dict(clan_a["materiais"])
        mats_a[1] = int(mats_a.get(1, 0)) + saque["ferro"]
        c.execute("UPDATE clan SET comida = comida + ?, madeira = madeira + ?, couro = couro + ?,"
                  " materiais = ? WHERE owner_id = ?",
                  (saque["comida"], saque["madeira"], saque["couro"],
                   json.dumps({str(k): v for k, v in mats_a.items()}), atacante))
        eqs_d = equipes_do_cla(defensor)
        eqs_d.pop(EQUIPE_DA_CIDADE, None)
        _gravar_equipes(c, defensor, eqs_d)
        texto = ("🏚️ Saqueamos a cidade (" + f"{poder_a} × {poder_d}): " +
                 ", ".join(f"{q} de {k}" for k, q in saque.items() if q) + ".")
        _anotar(c, atacante, texto)
        _anotar(c, defensor, f"🏚️ {nome_do_cla} passou pela guarnição e saqueou a cidade.")
        c.commit()
    _sincronizar_funcoes(defensor, equipes_do_cla(defensor))
    dar_xp(atacante, eq_a.get("guardas", []), XP_BATALHA)
    return {"ok": True, "venceu": True, "batalha": r, "saque": saque, "texto": texto}



# ---------------------------------------------------------------------- XP
# ⭐ (dev, 20/09) "os guardas também têm estrelas e níveis e ganham XP".
XP_COLETOR_SESSAO = 24      # = 1 por tick numa sessão cheia (o ritmo medido do coletor)
XP_VIGIA = 5                # guarnição da cidade, por sessão de vigia
XP_DEFESA = 30              # guarnição que repeliu um ataque (10 se não repeliu)
XP_EMBOSCADA = 15           # escolta que enfrentou emboscada explorando
XP_BATALHA = 50             # guarda que VENCEU uma batalha por ponto/cidade


def dar_xp(owner_id: int, ids: list, xp: int) -> list:
    """XP fora da sessão AFK (batalhas, emboscadas): aplica e grava."""
    from game import clan_habitantes as H
    from game import clan_reliquias as _R5      # 🏺 Diário do Fundador
    xp = int(round(int(xp) * _R5.fator(reliquias_do_cla(owner_id)["ativas"], "xp_npc")))
    alvo = {int(i) for i in (ids or [])}
    if not alvo or xp <= 0:
        return []
    habs = [h for h in listar_habitantes(owner_id) if int(h["id"]) in alvo]
    frases = []
    for h in habs:
        frases += H.ganhar_xp(h, int(xp))
    with _conn() as c:
        _gravar_habitantes(c, owner_id, habs, int(time.time()))
        c.commit()
    return frases



# --------------------------------------------------------------- relíquias
# 🏺 Achadas pelas equipes nos postos (~1% por equipe por sessão). Ver
# game/clan_reliquias.py.

def reliquias_do_cla(owner_id: int) -> dict:
    try:
        d = json.loads(carregar_clan(owner_id).get("reliquias") or "{}") or {}
    except ValueError:
        d = {}
    d.setdefault("acervo", [])
    d.setdefault("ativas", [])
    return d


def _gravar_reliquias(c, owner_id: int, d: dict) -> None:
    c.execute("UPDATE clan SET reliquias = ? WHERE owner_id = ?", (json.dumps(d), owner_id))


def ativar_reliquia(owner_id: int, chave: str, ativa: bool) -> dict:
    """Põe ou tira uma relíquia dos 3 slots. É a única decisão do sistema:
    o acervo cresce, os slots não."""
    from game.clan_reliquias import RELIQUIAS, SLOTS
    d = reliquias_do_cla(owner_id)
    if chave not in RELIQUIAS or chave not in d["acervo"]:
        return {"ok": False, "erro": "O clã não tem essa relíquia."}
    if ativa:
        if chave in d["ativas"]:
            return {"ok": False, "erro": "Essa já está ativa."}
        if len(d["ativas"]) >= SLOTS:
            return {"ok": False, "erro": f"O clã só sustenta {SLOTS} relíquias ativas — "
                                         "guarde uma antes."}
        d["ativas"].append(chave)
    else:
        if chave not in d["ativas"]:
            return {"ok": False, "erro": "Essa já está guardada."}
        d["ativas"].remove(chave)
    with _conn() as c:
        _gravar_reliquias(c, owner_id, d)
        c.commit()
    return {"ok": True, "ativas": d["ativas"]}


def sortear_reliquia(owner_id: int, qtd_equipes: int, fracao: float, rng) -> dict | None:
    """O sorteio da sessão. Devolve a relíquia achada (ou None)."""
    from game import clan_reliquias as R
    d = reliquias_do_cla(owner_id)
    achada = R.sortear(qtd_equipes, d["acervo"], rng, fracao)
    if not achada:
        return None
    d["acervo"].append(achada)
    if len(d["ativas"]) < R.SLOTS:      # a primeira leva já entra ativa
        d["ativas"].append(achada)
    with _conn() as c:
        _gravar_reliquias(c, owner_id, d)
        c.commit()
    return {"id": achada, **R.RELIQUIAS[achada]}



def compra_automatica_de_materiais(owner_id: int, ouro_disponivel: int, vizinhos: int = 50) -> dict:
    """🛒 (26/09/2026) Chamada no fim de uma sessão com a regra ligada: pra
    madeira, couro e ferro, o que não cobre a manutenção da PRÓXIMA sessão é
    comprado de outras aldeias até cobrir duas. Devolve o que comprou e o
    ouro gasto (quem chama desconta de p). Teto: `limite_ouro_materiais`."""
    from game import clan_habitantes as H
    from game.clan_equipes import manutencao_da_aldeia, preco_de_outra_aldeia
    clan = carregar_clan(owner_id)
    regras = {**H.REGRAS_PADRAO, **(clan.get("regras") or {})}
    if not regras.get("compra_materiais_auto"):
        return {"comprado": {}, "custo_ouro": 0}
    orcamento = min(int(ouro_disponivel), int(regras.get("limite_ouro_materiais", 300)))
    manut = manutencao_da_aldeia(listar_habitantes(owner_id))
    estoque = {"madeira": int(clan.get("madeira") or 0), "couro": int(clan.get("couro") or 0),
               "ferro": int(clan["materiais"].get(1, 0))}
    comprado, gasto = {}, 0
    # duas passadas: primeiro UMA sessão de cada (medido: numa passada só, a
    # madeira — lenha de 50 aldeões — comia o orçamento inteiro e os guardas
    # ficavam sem couro e ferro), depois completa até DUAS com o que sobrar
    precisa_de = {r: int(round(float(manut.get(r, 0)))) for r in ("madeira", "couro", "ferro")}
    if not any(estoque[r] < precisa_de[r] for r in precisa_de):
        return {"comprado": {}, "custo_ouro": 0}
    for sessoes in (1, 2):
        for r in ("couro", "ferro", "madeira"):
            precisa = precisa_de[r]
            alvo = sessoes * precisa
            tem = estoque[r] + comprado.get(r, 0)
            if precisa <= 0 or tem >= alvo:
                continue
            preco = max(1, int(preco_de_outra_aldeia(r, vizinhos)))
            qtd = min(alvo - tem, (orcamento - gasto) // preco)
            if qtd <= 0:
                continue
            rr = comprar_de_outras_aldeias(owner_id, r, qtd)
            if rr.get("ok"):
                comprado[r] = comprado.get(r, 0) + qtd
                gasto += qtd * preco
    return {"comprado": comprado, "custo_ouro": gasto}


# ═══════════════════════════════════════════════════════════════════════════
# ✨⚔️ (28/09, dev) DO ALDEÃO AO CAVALEIRO
# "O aldeão desperto vira personagem e, caso tenha muitos personagens, os
# personagens podem passar por um treinamento pra virar um cavaleiro — um
# tipo novo de aldeão, focado em guerra."
#
# O ciclo fecha a ideia do cenário: só usuário de aura pilota a Torre, e o
# clã é feito de gente sem aura. Quem desperta pode SAIR da aldeia e virar
# usuário de aura (um personagem da conta); e um usuário de aura pode largar
# a Torre e voltar pro clã como cavaleiro — guarda de elite, que custa caro
# pra manter e não serve pra outra coisa. Nas duas pontas é uma troca:
#   - promover tira da aldeia o bônus de aura dele (defesa e produção) e o
#     Mestre da Aura, se era ele;
#   - o cavaleiro custa um personagem jogável inteiro (equipamento e skills
#     vão com ele) + ferro e couro + 12h de treino.
# ═══════════════════════════════════════════════════════════════════════════
NIVEL_MIN_CAVALEIRO = 10
CUSTO_CAVALEIRO = {"ferro": 60, "couro": 40}
HORAS_TREINO_CAVALEIRO = 12
AURA_PADRAO_CAVALEIRO = 3        # personagem que não veio da aldeia


def _tirar_das_equipes(owner_id: int, hab_ids: set) -> None:
    eqs = equipes_do_cla(owner_id)
    for e in eqs.values():
        for papel in ("coletores", "guardas"):
            e[papel] = [x for x in (e.get(papel) or []) if int(x) not in hab_ids]
    _sincronizar_funcoes(owner_id, eqs)


def promover_a_personagem(owner_id: int, hab_id: int) -> dict:
    from game import clan_equipes as E
    from game.characters import criar_slot_de_aldeao, slots_livres
    h = next((x for x in listar_habitantes(owner_id) if int(x["id"]) == int(hab_id)), None)
    if not h:
        return {"ok": False, "erro": "Aldeão não encontrado."}
    if not int(h.get("aura") or 0):
        return {"ok": False, "erro": f"{h['nome']} não despertou a aura — só usuário de aura sobe a Torre."}
    if h.get("cavaleiro"):
        return {"ok": False, "erro": f"{h['nome']} já largou a Torre uma vez. Cavaleiro serve o clã."}
    if E.em_treino(h):
        return {"ok": False, "erro": f"{h['nome']} está no meio de um treinamento."}
    if not slots_livres(owner_id):
        return {"ok": False, "erro": "Todos os slots de personagem estão ocupados. "
                                     "Treine um personagem como cavaleiro pra abrir lugar."}
    ok, slot = criar_slot_de_aldeao(owner_id, h["nome"], int(h["aura"]), h.get("profissao"), int(h.get("nivel") or 1))
    if not ok:
        return {"ok": False, "erro": str(slot)}
    agora = int(time.time())
    h["vivo"] = 0
    h["causa"] = "despertou a aura e partiu pra Torre como usuário de aura"
    h["funcao"], h["equipe"] = None, None
    texto = (f"✨ {h['nome']} ({'★' * int(h['aura'])}) deixou a aldeia pra subir a Torre "
             f"como usuário de aura — agora é um dos seus personagens.")
    with _conn() as c:
        _gravar_habitantes(c, owner_id, [h], agora)
        _anotar(c, owner_id, texto, tipo="aura")
        c.commit()
    _tirar_das_equipes(owner_id, {int(h["id"])})
    return {"ok": True, "slot": slot, "texto": texto}


def ouro_do_treino() -> int:
    from game import clan_equipes as E
    return E.SOLDO_CAVALEIRO_DIA * E.DIAS_DE_SOLDO_NO_TREINO


def pode_treinar_cavaleiro(owner_id: int, pj: dict | None, slot: int,
                           ouro: int | None = None) -> tuple[bool, str]:
    """O motivo vai pra tela ANTES do botão (botão que existe pra recusar é
    pior que botão com o porquê)."""
    from game.characters import get_active_slot
    from game import cronicas as K
    if int(slot) == 0:
        return False, "O personagem principal é o cabeça do clã."
    if int(slot) == get_active_slot(owner_id):
        return False, "Troque pra outro personagem antes — este está sendo pilotado."
    if not pj:
        return False, "Ele ainda não nasceu: troque pra ele uma vez."
    if int(pj.get("level") or 1) < NIVEL_MIN_CAVALEIRO:
        return False, f"Precisa do nível {NIVEL_MIN_CAVALEIRO} (está no {int(pj.get('level') or 1)})."
    clan = carregar_clan(owner_id)
    if not K.fundado(clan):
        return False, "O clã ainda não foi fundado."
    ferro, couro = int(clan["materiais"].get(1, 0)), int(clan.get("couro") or 0)
    if ferro < CUSTO_CAVALEIRO["ferro"] or couro < CUSTO_CAVALEIRO["couro"]:
        return False, (f"O treino pede {CUSTO_CAVALEIRO['ferro']} de ferro e {CUSTO_CAVALEIRO['couro']} de couro "
                       f"(o clã tem {ferro} e {couro}).")
    # 💰 a 1ª semana de soldo é paga no treino, pelo personagem que você pilota
    if ouro is not None and int(ouro) < ouro_do_treino():
        return False, f"O treino paga a 1ª semana de soldo: {ouro_do_treino()} de ouro (você tem {int(ouro)})."
    return True, ""


def treinar_cavaleiro(owner_id: int, slot: int, ouro: int | None = None) -> dict:
    """Quem chama (a rota) desconta `custo_ouro` do personagem ativo SE der
    certo — o ouro mora no jogador, não no clã."""
    from game import clan_equipes as E
    from game import clan_habitantes as H
    from game.characters import _carregar_do_armario, jogador_do_armario, _remover_do_armario
    snap = _carregar_do_armario(owner_id, int(slot))
    pj = jogador_do_armario(snap) if snap and snap.get("player") else None
    ok, motivo = pode_treinar_cavaleiro(owner_id, pj, slot, ouro)
    if not ok:
        return {"ok": False, "erro": motivo}
    clan = carregar_clan(owner_id)
    # 🏙️ (28/09) cavaleiro mora na cidade do reino: não precisa de casa na aldeia
    origem = pj.get("origem_aldeao") or {}
    aura = int(origem.get("aura") or AURA_PADRAO_CAVALEIRO)
    nome = (pj.get("username") or "").strip() or f"Cavaleiro {int(slot)}"
    agora = int(time.time())
    cav = {"nome": nome, "profissao": "guarda", "xp": 0, "potencial": 5, "fadiga": 0, "descansando": 0,
           "aura": aura, "talentos": {"guarda": 5}, "funcao": "guarda", "equipe": EQUIPE_DA_CIDADE,
           "cavaleiro": str(pj.get("class_id") or "sem_classe"),
           "treino_ate": agora + HORAS_TREINO_CAVALEIRO * 3600}
    # 💰 soldo: a 1ª semana conta a partir do fim do treino
    cav["soldo_ate"] = cav["treino_ate"] + E.DIAS_DE_SOLDO_NO_TREINO * 86400
    cav["nivel"] = min(int(pj.get("level") or 1), E.nivel_maximo(cav))
    mats = dict(clan["materiais"])
    mats[1] = int(mats.get(1, 0)) - CUSTO_CAVALEIRO["ferro"]
    texto = (f"⚔️ {nome} largou a Torre e entrou no treino de cavaleiro (Nv.{cav['nivel']}, "
             f"aura {'★' * aura}). Fica pronto em {HORAS_TREINO_CAVALEIRO}h, mora na cidade do reino "
             f"e serve na guarnição — soldo pago por {E.DIAS_DE_SOLDO_NO_TREINO} dias.")
    with _conn() as c:
        c.execute("UPDATE clan SET materiais = ?, couro = couro - ? WHERE owner_id = ?",
                  (json.dumps({str(k): v for k, v in mats.items()}), CUSTO_CAVALEIRO["couro"], owner_id))
        _gravar_habitantes(c, owner_id, [cav], agora)
        c.execute("DELETE FROM clan_membro WHERE owner_id = ? AND slot = ?", (owner_id, int(slot)))
        _anotar(c, owner_id, texto, tipo="cavaleiro")
        c.commit()
        novo_id = c.execute("SELECT MAX(id) FROM clan_habitante WHERE owner_id = ? AND cavaleiro IS NOT NULL",
                            (owner_id,)).fetchone()[0]
    _remover_do_armario(owner_id, int(slot))
    # já entra na guarnição da cidade (ela é uma "equipe" só de guardas)
    eqs = equipes_do_cla(owner_id)
    gua = eqs.setdefault(EQUIPE_DA_CIDADE, {"coletores": [], "guardas": [], "desde": agora})
    gua.setdefault("guardas", []).append(int(novo_id))
    _sincronizar_funcoes(owner_id, eqs)
    return {"ok": True, "texto": texto, "habitante_id": int(novo_id), "nivel": cav["nivel"],
            "custo_ouro": ouro_do_treino()}


def pagar_soldo(owner_id: int, hab_id: int, dias: int) -> dict:
    """Estende o soldo do cavaleiro. Quem chama (a rota) desconta o ouro do
    personagem ativo se der certo. Soldo vencido recomeça de AGORA (não
    cobra os dias parados)."""
    from game import clan_equipes as E
    dias = int(dias)
    if dias not in (1, 7, 30):
        return {"ok": False, "erro": "Soldo se paga por 1, 7 ou 30 dias."}
    h = next((x for x in listar_habitantes(owner_id) if int(x["id"]) == int(hab_id)), None)
    if not h or not h.get("cavaleiro"):
        return {"ok": False, "erro": "Cavaleiro não encontrado."}
    agora = int(time.time())
    h["soldo_ate"] = max(agora, int(h.get("soldo_ate") or 0)) + dias * 86400
    with _conn() as c:
        _gravar_habitantes(c, owner_id, [h], agora)
        c.commit()
    return {"ok": True, "custo_ouro": dias * E.SOLDO_CAVALEIRO_DIA, "soldo_ate": h["soldo_ate"],
            "nome": h["nome"]}
