# game/monsters.py
from __future__ import annotations
import random

# ======================
# CONFIGURAÇÃO DE RAÇAS
# ======================

RAÇAS_POR_BLOCO = {
    (1, 5): {"nome": "Goblin", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Chefe Goblin", "Xamã Goblin", "Goblin Assassino"], "boss": "Rei Goblin"},
    (6, 10): {"nome": "Esqueleto", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Capitão Esqueleto", "Necromante", "Arqueiro Espectral"], "boss": "Esqueleto Gigante"},
    (11, 15): {"nome": "Formiga", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Formiga Guerreira", "Formiga Rainha Menor", "Formiga Soldado"], "boss": "Formiga General"},
    (16, 20): {"nome": "Kobold", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Kobold Trapeiro", "Kobold Fogo", "Kobold Sombra"], "boss": "Xamã Kobold das Cinzas"},
    (21, 25): {"nome": "Orc", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Orc Guerreiro", "Orc Xamã", "Orc Berserk"], "boss": "Chefe Orc Quebra-Osso"},
    (26, 30): {"nome": "Cultista", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Cultista Maldito", "Cultista Obscuro", "Cultista Supremo"], "boss": "Sumo-Cultista do Abismo"},
    (31, 35): {"nome": "Aranha", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Aranha Venenosa", "Aranha Gigante", "Aranha da Sombra"], "boss": "Aranha-Mãe Colossal"},
    (36, 40): {"nome": "Fada", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Fada Venenosa", "Fada Raizes", "Fada Luz"], "boss": "Fada Rainha"},
    (41, 45): {"nome": "Homem-Lagarto", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Lagarto Guerreiro", "Lagarto Xamã", "Lagarto Primordial"], "boss": "Xamã Escamado Ancião"},
    (46, 50): {"nome": "Gárgula", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Gárgula de Pedra", "Gárgula da Noite", "Gárgula Antiga"], "boss": "Gárgula-Guardião do Portão"},
    (51, 55): {"nome": "Elemental", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Elemental de Fogo", "Elemental de Gelo", "Elemental de Raio"], "boss": "Elemental Prisma (3 fases)"},
    (56, 60): {"nome": "Vampiro", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Vampiro Jovem", "Vampiro Ancestral", "Abominação Vampírica"], "boss": "Conde da Cripta"},
    (61, 65): {"nome": "Golem", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Golem de Argila", "Golem de Ferro", "Golem de Runa"], "boss": "Golem Rúnico de Obsidiana"},
    (66, 70): {"nome": "Demônio", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Demônio Menor", "Demônio Maior", "Demônio Primordial"], "boss": "Marechal Infernal"},
    (71, 75): {"nome": "Aberração", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Aberração Mutante", "Aberração Voraz", "Aberração Perfeita"], "boss": "Massa Devoradora"},
    (76, 80): {"nome": "Cavaleiro Maldito", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Cavaleiro Negro", "Cavaleiro Espectral", "Cavaleiro Arruinado"], "boss": "Paladino Caído do Juramento"},
    (81, 85): {"nome": "Drake", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Drake de Fogo", "Drake de Gelo", "Drake de Tempestade"], "boss": "Draco Guardião de Duas Cores"},
    (86, 90): {"nome": "Gigante", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Gigante da Montanha", "Gigante de Pedra", "Gigante do Caos"], "boss": "Titã das Ruínas"},
    (91, 95): {"nome": "Anjo Corrompido", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Anjo Decaído", "Anjo Sombrio", "Anjo Abominado"], "boss": "Serafim Decaído"},
    (96, 100): {"nome": "Entidade do Vazio", "tipos": ["tanker", "espadachim", "arqueiro"], "elite": ["Entidade Menor", "Entidade Maior", "Entidade Suprema"], "boss": "Núcleo do Vazio (4 fases + enrage)"},
}

MONSTRO_TIPOS = [
    ("tanker", ("str", "vit")),
    ("tanker", ("vit", "agi")),
    ("espadachim", ("vit", "dex")),
    ("espadachim", ("str", "agi")),
    ("arqueiro", ("str", "dex")),
    ("arqueiro", ("agi", "dex")),
]

# ======================
# MULTIPLICADORES E LÓGICA
# ======================

def get_tier(lvl: int) -> int:
    """Tier calculado por faixas de 20 níveis"""
    if lvl < 1: return 1
    return (lvl - 1) // 10 + 1

def mult_por_tipo(tipo):
    if tipo == "normal": return 0.7
    if tipo == "elite": return 1.7
    if tipo == "general": return 1.9
    if tipo == "boss": return 2.5
    return 1.0

def mult_por_andar(andar):
    return 1.0 + (andar // 3) * 0.15

def obter_raca_por_andar(andar: int) -> dict:
    andar = int(andar)
    for (inicio, fim), raca in RAÇAS_POR_BLOCO.items():
        if inicio <= andar <= fim: return raca
    return RAÇAS_POR_BLOCO[(96, 100)]

def pesos_do_andar(andar) -> dict:
    """Chance de cada tipo de monstro num andar comum (não múltiplo de 5).

    20/09/2026: saiu de dentro de `tipo_monstro_por_andar` pra ser a ÚNICA
    fonte da regra — o catálogo de imagens do /admin também precisa dela,
    pra saber que monstro NORMAL não nasce do andar 30 em diante e não
    cobrar arte que nunca vai aparecer."""
    if andar < 5: weights = [80, 15, 5]
    elif andar < 10: weights = [60, 30, 10]
    elif andar < 20: weights = [50, 35, 15]
    elif andar < 30: weights = [10, 40, 60]
    else: weights = [0, 45, 55]
    return dict(zip(["normal", "elite", "general"], weights))


def normal_possivel(andar) -> bool:
    """Um monstro NORMAL pode nascer neste andar?"""
    a = int(andar)
    return a % 5 != 0 and pesos_do_andar(a)["normal"] > 0


def tipo_monstro_por_andar(andar):
    if andar % 5 == 0: return "boss"
    pesos = pesos_do_andar(andar)
    return random.choices(list(pesos), list(pesos.values()))[0]

def gerar_nome_monstro(raca_nome, tipo_monstro, elite_lista, boss_name, arquetipo=None):
    """Gera nome e INCLUI A CLASSE SE FOR NORMAL"""
    if tipo_monstro == "boss": return boss_name
    if tipo_monstro == "general": return f"{random.choice(elite_lista)}"
    if tipo_monstro == "elite": return random.choice(elite_lista)
    
    # Se for normal, adiciona o arquétipo ao nome (ex: "Goblin Arqueiro")
    if arquetipo:
        return f"{raca_nome} {arquetipo.capitalize()}"
        
    return raca_nome

def get_bosses_no_andar(andar: int) -> int:
    """
    Define quantos bosses aparecem num andar.

    - Andar não múltiplo de 5: 0 bosses (andar normal)
    - 5, 10, 15: 1 boss
    - 20–39: 2 bosses (apenas nos múltiplos de 5: 20,25,30,35)
    - 40–59: 3 bosses (40,45,50,55)
    - 60–79: 4 bosses (60,65,70,75)
    - 80–100: 5 bosses (80,85,90,95,100)
    """
    a = int(andar)

    # Só andares múltiplos de 5 têm boss
    if a <= 0 or a % 5 != 0:
        return 0

    if a < 20:
        return 1
    elif a < 40:
        return 2
    elif a < 60:
        return 3
    elif a < 80:
        return 4
    else:
        return 5
# ======================
# STATUS E ATRIBUTOS
# ======================

def criar_status_inicial() -> dict:
    return {
        "hp_max": 100, "atk": 10, "def": 0, "spd": 20,
        "crit": 0, "acc": 0, "eva": 0, "reg": 0,
    }

def aplicar_atributos(status: dict, attrs: dict) -> dict:
    s = dict(status)
    s["atk"] += attrs.get("str", 1) * 2
    s["def"] += attrs.get("str", 1) * 2
    s["hp_max"] += attrs.get("vit", 1) * 20
    s["reg"] += attrs.get("vit", 1) * 2
    s["spd"] += attrs.get("agi", 1) * 2
    s["eva"] += attrs.get("agi", 1) * 2
    s["crit"] += attrs.get("dex", 1) * 2
    s["acc"] += attrs.get("dex", 1) * 2
    return s

def aplicar_mult_status(status, mult):
    return {
        k: int(round(v * mult)) if isinstance(v, (int, float)) else v
        for k, v in status.items()
    }
from game.skills import SKILL_DB
import random

from game.skills import SKILL_DB
import random

# =========================================================
# 🎁 SEPARADOR DE LOOT E SKILLS POR RARIDADE (Automático)
# =========================================================
CORES_BY_RARITY = {1: [], 2: [], 3: [], 4: [], 5: []}
ACTIVES_BY_RARITY = {1: [], 2: [], 3: [], 4: [], 5: []} # 🔥 O Livrão de Magias do Boss!

for core_id, data in SKILL_DB.items():
    sk = data.get("skill", {})
    rarity = sk.get("rarity", 1)

    # 🔥 REWORK DE SKILLS v2 (07/07/2026): passivas voltaram a ser equipáveis
    # (dividem os mesmos 5 slots com as ativas), então voltam a dropar normal.
    if rarity in CORES_BY_RARITY:
        CORES_BY_RARITY[rarity].append(core_id)

    # Guarda SÓ AS ATIVAS pra Inteligência Artificial usar
    if rarity in ACTIVES_BY_RARITY and sk.get("type") == "active":
        ACTIVES_BY_RARITY[rarity].append(core_id)

def dropar_core_monstro(tipo_monstro: str = "normal", is_raid: bool = False) -> str | None:
    """
    Define o drop do monstro com o novo sistema de Magias + Forja Antiga.
    Taxa de drop de magias fixada em 5% na Fonte (Torre e Raid).
    """
    # =========================================================
    # 🌟 1. DROP PREMIUM (SKILLS NOVAS) - 5% CHANCE GLOBAL
    # =========================================================
    if random.randint(1, 100) <= 5:
        target_rarity = 1
        
        if is_raid:
            # 🌋 RAID: Tier 5 (Lendária) se Boss, Tier 4 (Épica) se Normal
            target_rarity = 5 if tipo_monstro == "boss" else 4
        else:
            # 🗼 TORRE: Tier 2 ou 3 (Incomum/Rara) se Boss, Tier 1 (Comum) se Normal
            target_rarity = random.choice([2, 3]) if tipo_monstro == "boss" else 1

        if target_rarity in CORES_BY_RARITY and CORES_BY_RARITY[target_rarity]:
            return random.choice(CORES_BY_RARITY[target_rarity])

    # =========================================================
    # 🔨 2. DROP NORMAL (Forja/Status) - Se a Magia não veio (95%)
    # =========================================================
    r = random.random()
    
    if r < 0.07: return "wa_atk"   # Arma
    if r < 0.12: return "ar_def"   # Armadura
    if r < 0.16: return "ac_atk"   # Acessório (Atk)
    if r < 0.20: return "ac_def"   # Acessório (Def)
    if r < 0.25: return random.choice(["crit", "acc", "eva", "spd", "reg"])
        
    return None


def drop_core_roll(andar: int, tipo_monstro: str = "normal", is_raid: bool = False) -> str | None:
    """Wrapper para chamar o drop passando o tipo do monstro e se é Raid."""
    return dropar_core_monstro(tipo_monstro, is_raid)

# ======================
# FUNÇÃO PRINCIPAL
# ======================

def criar_monstro_por_andar(andar):
    """Cria monstro completo com tipos corretos"""
    lvl = max(1, int(andar))
    tipo = tipo_monstro_por_andar(lvl)
    tier = get_tier(lvl)

    raca_data = obter_raca_por_andar(andar)
    raca_nome = raca_data["nome"]

    tipos_permitidos = raca_data.get("tipos", ["tanker"])

    # attrs base
    attrs_base = {"str": 1, "vit": 1, "agi": 1, "dex": 1}
    ups = lvl 
    for k in attrs_base:
        attrs_base[k] += ups

    # ----------------------------
    # ARQUÉTIPO (normal vs boss)
    # ----------------------------
    if tipo == "boss":
        arquetipo_id = "boss"

        # +50% em tudo
        attrs = {k: max(1, int(round(v * 1.5))) for k, v in attrs_base.items()}

        # +100% em VIT (total 2.0x em cima do base, não 3.0x)
        attrs["vit"] = max(1, int(round((1 + ups) * 1.4)))
    else:
        tipo_escolhido_str = random.choice(tipos_permitidos)
        opcoes_stats = [m for m in MONSTRO_TIPOS if m[0] == tipo_escolhido_str]

        if not opcoes_stats:
            arquetipo_id, (a1, a2) = ("tanker", ("str", "vit"))
        else:
            arquetipo_id, (a1, a2) = random.choice(opcoes_stats)

        attrs = dict(attrs_base)
        attrs[a1] *= 2
        attrs[a2] *= 2

    st = aplicar_atributos(criar_status_inicial(), attrs)
    st = aplicar_mult_status(st, mult_por_tipo(tipo) * mult_por_andar(andar))

    st["hp_max"] = max(60, st["hp_max"])
    st["atk"] = max(1, st["atk"])
    st["def"] = max(0, st["def"])

    nome_final = gerar_nome_monstro(
        raca_nome, tipo, raca_data["elite"], raca_data["boss"], arquetipo_id
    )

        # Drop: rola 1x só (antes tu chamava 2x)
    cid = dropar_core_monstro(tipo)
    cores_drop = [cid] if cid else []
    
    # 🔥 A MÁGICA: O Boss agora tem acesso a TODAS as magias do jogo da raridade dele!
    if tipo == "boss":
        skills_monstro = ACTIVES_BY_RARITY[5] # Todas as Tier 5 (Lendárias)
    elif tipo in ["elite", "general"]:
        skills_monstro = ACTIVES_BY_RARITY[4] # Todas as Tier 4 (Épicas)
    else:
        skills_monstro = ACTIVES_BY_RARITY[2] # Monstros normais usam Incomuns (Tier 2)
        
    return {
        "nome": nome_final,
        # ... resto do código igual ...

        "lvl": lvl,
        "tipo": tipo,
        "tier": tier,
        "arquetipo": arquetipo_id,

        # IMPORTANTES pro teu startcombat/combate (ele lê hpmax/coresdrop/racanome) [file:10]
        "racanome": raca_nome,
        "hpmax": st["hp_max"],
        "coresdrop": cores_drop,

        # Mantém teus nomes antigos também (pra telas/compat)
        "raca_nome": raca_nome,
        "atributos": attrs,
        "status": st,
        "hp_max": st["hp_max"],
        "hp": st["hp_max"],
        "atk": st["atk"],
        "def": st["def"],
        "spd": st["spd"],
        "crit": st["crit"],
        "acc": st["acc"],
        "eva": st["eva"],
        "reg": st["reg"],
        "cores_drop": cores_drop,
        "skills": skills_monstro,
    }