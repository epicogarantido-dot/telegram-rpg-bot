from __future__ import annotations
import copy
import random
import time
import uuid
from typing import Tuple, List, Dict, Any
from game.specialties import SPECIALTIES_DB as SPECIALTIESDB

from game.trade_repo import trade_repo
from game.monsters import criar_monstro_por_andar, get_bosses_no_andar, get_tier, drop_core_roll
from game.items import core_sell_value, SLOTS, apply_bonus, core_bonus, CORES_DB, core_name

from game.craft import inv_add_stack
from game.premium_system import premium_repo
from game.skills import SKILL_DB, get_skill_by_id

from game.raid_repo import (
    create_room,
    get_room,
    save_room,
    delete_room,
    find_room_by_member
)

from game.monster_generator import criar_monstro, criar_monstros_para_raid

from game.raid_combat import (
    raid_init_combat,
    raid_player_attack,
    raid_finish_with_loot,
    raid_cleanup_room,
    raid_get_combat_view,
)

from game.sql_repo import load_player, save_player_sql




XP_PER_LEVEL = 100
MAX_MONSTERS = 5
TP_COST = 100
ATB_MAX = 100.0


def _pid(p: dict) -> str:
    """PlayerID estável compatível com saves antigos e novos."""
    pid = (
        p.get("playerid")
        or p.get("player_id")
        or p.get("userid")
        or p.get("user_id")
        or ""
    )
    pid = str(pid).strip()

    if pid:
        p["playerid"] = pid
        p["player_id"] = pid

    return pid
def raid_get_pid(p: dict) -> str:
    # USA user_id igual o ranking — simples, funciona sempre
    return str(p.get("user_id") or p.get("userid") or p.get("telegram_id") or 0)

def raid_create_or_get_room(p: dict) -> dict:
    raid_cleanup_buggy_state(p)
    pid = raid_get_pid(p)  # sua função
    room_id = p.get("raid_room_id")

    if room_id:
        room = get_room(room_id)
        if room:
            p["raid_room_id"] = room["id"]
            p["tower_mode"] = "RAID"
            p["state"] = "RAID_LOBBY"
            p["raid_ready"] = bool(room.get("ready_map", {}).get(pid, False))
            
            return room

    existing = find_room_by_member(pid)
    if existing:
        p["raid_room_id"] = existing["id"]
        p["tower_mode"] = "RAID"
        p["state"] = "RAID_LOBBY"
        p["raid_ready"] = bool(existing.get("ready_map", {}).get(pid, False))
        
        return existing

    room = create_room(pid, floor=int(p.get("raid_floor", 1)))
    p["raid_room_id"] = room["id"]
    p["tower_mode"] = "RAID"
    p["state"] = "RAID_LOBBY"
    p["raid_ready"] = False
    
    return room
def _nl(*parts) -> str:  
    """Join parts with newline between each"""  
    lines = []  
    for p in parts:  
        if not p:  
            continue  
        if isinstance(p, list):  
            lines.extend([str(x) for x in p if str(x)])  
        else:  
            lines.append(str(p))  
    return " ".join([x for x in lines if x])
    
def _cd_from_spd(spd: int) -> int:
    spd = max(1, int(spd))
    return max(1, int(100 / spd))
# logic.py


def raid_distribute_loot(room: dict, enemy: dict, logs: list[str]) -> None:
    """Reaproveita a lógica da torre para dar loot pra todos da sala, avisando quem ganhou o que.

    OBS (corrigido em 06/07/2026): antes usava `room["members"]`, mas quem
    morre durante a raid é removido dessa lista por `raid_handle_player_death`,
    então ficava sem loot mesmo tendo lutado. Agora usa o roster completo de
    `raid_state.players`, que mantém todo mundo que participou do combate.
    """
    rs = room.get("raid_state") or {}
    participantes = list(rs.get("players", {}).keys()) or list(room.get("members", []))

    for pid in participantes:
        try:
            pdata = load_player(int(pid))
        except Exception:
            pdata = None

        if not pdata:
            continue

        # monta um combate fake com 1 inimigo só
        pdata["combat"] = {
            "enemies": [copy.deepcopy(enemy)],
            "target": 0
        }

        # Gera o loot do jogador
        drop_logs = _on_enemy_killed(pdata, 0)
        
        # 🔥 UX UPGRADE: Coloca o nome do cara antes do loot dele no log!
        if drop_logs:
            nome = pdata.get("username", f"Jogador {pid}")
            logs.append(f"\n🎁 <b>Loot de {nome}:</b>")
            logs.extend(drop_logs)

        # Limpa o combate fake e salva
        pdata["combat"] = None
        save_player_sql(int(pid), pdata)

        # 🖼️ Guarda o tipo do drop desse jogador na própria sala, pra quem
        # desferiu o golpe final poder escolher a imagem certa depois
        # (o "pdata" aqui é uma cópia separada da que o main.py tem em
        # memória, então não dá pra só ler de volta em p["_last_drop_type"]).
        room.setdefault("_last_drop_types", {})[str(pid)] = pdata.get("_last_drop_type", "gold")

        # 🔥 Avisa o main.py que os dados deste jogador em memória (cache)
        # estão desatualizados, senão a próxima ação dele apaga esse loot.
        try:
            from infra.cache_bus import mark_dirty
            mark_dirty(int(pid))
        except Exception:
            pass


def _save_player_if_possible(p: dict):
    """Salva o player no SQLite se tiver telegram_id/user_id."""
    

    uid = int(
        p.get("telegram_id")
        or p.get("user_id")
        or p.get("userid")
        or 0
    )
    if uid:
        save_player_sql(uid, p)
        
def qtd_monstros_por_andar(andar: int) -> int:
    a = int(andar)
    if a < 6:
        return 1
    max_n = min(MAX_MONSTERS, 1 + (a - 6) // 4 + 1)
    return random.randint(1, max_n)

# ===== PROGRESSÃO =====

# 🔥 CORRIGIDO (07/07/2026): esse arquivo ainda importava `telebot` (a lib
# antiga, síncrona) só pra usar em duas funções `kb()`/`btn()` que NINGUÉM
# no projeto chama — nem daqui, nem de fora. É o mesmo import que já tinha
# derrubado o bot em produção antes (ModuleNotFoundError: telebot). Removido
# de vez; o resto do jogo já usa core/keyboards.py (baseado em aiogram).

ORDER_TTL_SECONDS = 12 * 60 * 60  # 12h

def _ensure_pending_orders(p: dict) -> list:
    """Garante que p tem lista de pedidos."""
    if "pending_orders" not in p or not isinstance(p["pending_orders"], list):
        p["pending_orders"] = []
    return p["pending_orders"]

def _cleanup_expired_orders(p: dict, now: int | None = None) -> int:
    """Remove pedidos waiting_payment expirados."""
    now = now or int(time.time())
    pending = _ensure_pending_orders(p)
    
    before = len(pending)
    kept = []
    for o in pending:
        status = str(o.get("status", "")).strip()
        # Só expira waiting_payment com expires_at antigo
        if (status == "waiting_payment" and 
            o.get("expires_at") and 
            o.get("expires_at") <= now):
            continue
        kept.append(o)
    
    p["pending_orders"] = kept
    return before - len(kept)



def raid_join_room(p: dict, room_id: int) -> str:
    room = get_room(room_id)
    if not room:
        return "❌ Sala não encontrada.\n"

    if not room.get("open", True) or room.get("state") != "LOBBY":
        return "❌ Essa sala já está em combate ou fechada.\n"

    pid = raid_get_pid(p)

    if pid in room.get("members", []):
        p["raid_room_id"] = room["id"]
        p["tower_mode"] = "RAID"
        p["state"] = "RAID_LOBBY"
        return "Você já está nessa sala.\n"

    if len(room.get("members", [])) >= int(room.get("max_members", 5)):
        return "❌ Sala cheia.\n"

    room["members"].append(pid)
    room["ready_map"][pid] = False
    save_room(room)

    p["raid_room_id"] = room["id"]
    p["tower_mode"] = "RAID"
    p["state"] = "RAID_LOBBY"
    p["raid_ready"] = False

    return f"✅ Você entrou na sala #{room['id']} (andar {room['floor']}).\n"

def raid_leave_room(p: dict) -> str:
    room_id = p.get("raid_room_id")
    if not room_id:
        return "Você não está em nenhuma sala.\n"

    room = get_room(room_id)
    pid = raid_get_pid(p)

    if room:
        members = room.get("members", [])

        if pid in members:
            members.remove(pid)

        room.get("ready_map", {}).pop(pid, None)

        if not members:
            delete_room(room_id)
        else:
            if room.get("leader_pid") == pid:
                room["leader_pid"] = members[0]

            save_room(room)

    p["raid_room_id"] = None
    p["tower_mode"] = "NORMAL"
    p["raid_floor"] = 1
    p["raid_ready"] = False
    p["state"] = "CITY"

    return "🚪 Você saiu da Torre Desafio.\n"
# ========================================================
# NOMES BONITOS PARA STATS (usado em views e tooltips)
# ========================================================
STAT_NAMES = {
    "atk": "⚔️ Ataque",
    "def": "🛡️ Defesa", 
    "hp_max": "❤️ Vida Máx",
    "hp": "❤️ Vida",
    "spd": "⚡ Velocidade",
    "reg": "🩸 Regeneração",
    "acc": "🎯 Precisão",
    "eva": "🌀 Esquiva",
    "crit": "💥 Crítico",
    "str": "💪 Força",
    "vit": "💚 Vitalidade",
    "agi": "🦵 Agilidade",
    "dex": "👁️ Destreza",
}
def raid_set_ready(p: dict, ready: bool) -> str:
    room_id = p.get("raid_room_id")
    if not room_id:
        p["tower_mode"] = "NORMAL"
        p["state"] = "CITY"
        return "❌ Sala não encontrada.\n"
        
    room = get_room(room_id)
    if not room:
        return "❌ Sala não encontrada.\n"
        
    pid = raid_get_pid(p)
    room.setdefault("ready_map", {})[pid] = ready
    save_room(room)
    
    if not ready:
        p["raid_ready"] = False
        return "❌ Você cancelou o estado de pronto.\n"
        
    p["raid_ready"] = True
    
    # Verifica se todos estão prontos para começar
    members = room.get("members", [])
    all_ready = all(room["ready_map"].get(m, False) for m in members)

    if all_ready and room.get("state") == "LOBBY":
        raid_init_combat_state(room) # <--- CHAMA A NOVA AQUI
        p["state"] = "RAID_COMBAT"
        return "⚔️ Todos prontos! A batalha começou!\n"
            
    return "✅ Você está pronto! Aguardando outros...\n"
def _get_active_order(p: dict, now: int | None = None) -> dict | None:
    """Pega o pedido mais recente waiting_payment ou proof_sent."""
    now = now or int(time.time())
    _cleanup_expired_orders(p, now)
    
    pending = _ensure_pending_orders(p)
    for o in reversed(pending):  # mais recente primeiro
        status = str(o.get("status", ""))
        if status in ("waiting_payment", "proof_sent"):
            return o
    return None

def _fmt_seconds(secs: int) -> str:
    """Formata segundos em HhMm."""
    secs = max(0, int(secs))
    h = secs // 3600
    m = (secs % 3600) // 60
    return f"{h}h{m:02d}m"
def xp_next(level: int) -> int:
    """Calcula o XP necessário para subir de nível com progressão linear."""
    # Base de 100 XP. A cada nível, aumenta 50 XP.
    return int(100 + (int(level) - 1) * 50)


def ensure_player(p: dict) -> dict:
    p.setdefault("msg_id", None)
    p.setdefault("asset_key", "CITY")
    p.setdefault("state", "CITY")
# Dentro da função ensure_player, junto com os outros status padrão
    if "pets" not in p:
        p["pets"] = {
            "owned": {}, # Dicionário de pets que ele tem e a quantidade
            "deck": [None, None, None, None, None] # Os 5 slots do esquadrão
        }
    p.setdefault("tower_choice", None)
    p.setdefault("level", 1)
    p.setdefault("xp", 0)
    p.setdefault("xp_next", xp_next(int(p["level"])))
    p.setdefault("gold", 0)
    p.setdefault("tower_floor", 1)
    # ===== NOVA TORRE (RAID) =====
    p.setdefault("tower_mode", "NORMAL")  # NORMAL ou RAID
    p.setdefault("raid_floor", 1)        # Andar da torre desafio
    p.setdefault("raid_ready", False)    
    p.setdefault("raid_room_id", None)
    p.setdefault("hp_max", 100)
    p.setdefault("hp", p["hp_max"])
    p.setdefault("atk", 5)
    p.setdefault("def", 0)
    p.setdefault("crit", 0)
    p.setdefault("eva", 0)
    p.setdefault("acc", 0)
    p.setdefault("spd", 20)
    p.setdefault("reg", 0)
    # Controle de Login Diário e Cultivo Passivo
    p.setdefault("last_daily", 0)
    p.setdefault("daily_streak", 0)
    p.setdefault("last_xp_tick", int(time.time())) # Relógio do XP por minuto
    p.setdefault("daily_login_date", "") # Guarda o dia do último login
       # Ofensiva de dias seguidos
    p.setdefault("last_free_revive", 0)  # Timestamp do último reviver grátis
    
    p.setdefault("attrs", {"str": 1, "vit": 1, "agi": 1, "dex": 1})
    p.setdefault("trail_points", 0)
    p.setdefault("trails", {})
    for k in ("str", "vit", "agi", "dex"):
        p["trails"].setdefault(k, {"step": 0, "cycles": 0, "sec": None})
        p["trails"][k].setdefault("step", 0)
        p["trails"][k].setdefault("cycles", 0)
        p["trails"][k].setdefault("sec", None)

    p.setdefault("class_id", None)
    p.setdefault("race_id", None)
    p.setdefault("specialty_id", None)
    if "inv" not in p:
        p["inv"] = {}
    p.setdefault("inv", {"potion": 0, "cores": {}, "items": {s: [] for s in SLOTS}})
    p["inv"].setdefault("potion", 0)
    p["inv"].setdefault("cores", {})
    p["inv"].setdefault("items", {s: [] for s in SLOTS})
    if not p["inv"]["cores"]:
        p["inv"]["cores"] = {
            
        }

    for s in SLOTS:
        p["inv"]["items"].setdefault(s, [])

    p.setdefault("equip", {s: None for s in SLOTS})
    for s in SLOTS:
        p["equip"].setdefault(s, None)

    p.setdefault("craft", {"slot": None, "rar": None, "sub": None, "sel": []})
    p.setdefault("socket", None)
    p.setdefault("combat", None)
    p.setdefault("vipuntil", 0)

    # 🔥 REWORK DE SKILLS v2 (07/07/2026): voltou a ter 5 slots — só que agora
    # é UM conjunto único de 5, e o jogador pode equipar QUALQUER mistura de
    # skills ativas e passivas nesses 5 slots (antes eram 5+5 separados).
    # Os Dons Passivos fixos foram removidos.
    p.setdefault("skill_slots", {"equipped": [None] * 5})
    if "equipped" not in p["skill_slots"]:
        # Migração de versões anteriores (actives/passives separados)
        antigo = None
        old_actives = p["skill_slots"].get("actives")
        if old_actives:
            antigo = next((s for s in old_actives if s), None)
        novo = [None] * 5
        if antigo:
            novo[0] = antigo
        p["skill_slots"]["equipped"] = novo
    p["skill_slots"].setdefault("equipped", [None] * 5)
    p["skill_slots"].pop("actives", None)
    p["skill_slots"].pop("passives", None)
    p.setdefault("skills_learned", {})
    p.pop("passive_gifts", None)

    p.setdefault("skills_learned", {})
    if p.get("chakra") is None:
        from game.chakras import roll_chakra
        p["chakra"] = roll_chakra()

    # 🔥 Se o campo não existe, é jogador ANTIGO (de antes do tutorial
    # existir) — não faz sentido mostrar do zero pra quem já joga. Jogadores
    # NOVOS já vêm com "tutorial_seen": False setado em create_player, então
    # esse setdefault não afeta eles.
    p.setdefault("tutorial_seen", True)
    p.setdefault("tut_seen", {})

    if "username" in p and p["username"]:
        p["username"] = p["username"].strip()
    return p
   

def barra(valor, maximo, tamanho=10):
    if maximo <= 0:
        return "----------"
    cheio = int((valor / maximo) * tamanho)
    vazio = tamanho - cheio
    return "█" * cheio + "░" * vazio

def create_player(user_id: int):
    p = {
        "user_id": user_id,
        "msg_id": None,
        "asset_key": "CITY",
        "state": "CITY",
        "level": 1,
        "xp": 0,
        "xp_next": xp_next(1),
        "gold": 1000,
        "tower_floor": 1,
        "tower_mode": "NORMAL",
        "raid_floor": 1,
        "raid_ready": False,
        "hp_max": 100,
        "hp": 100,
        "atk": 10,
        "def": 2,
        "crit": 0,
        "eva": 0,
        "acc": 0,
        "spd": 20,
        "reg": 0,
        "attrs": {"str": 1, "vit": 1, "agi": 1, "dex": 1},
        "trail_points": 0,
        "trails": {
            "str": {"step": 0, "cycles": 0, "sec": None},
            "vit": {"step": 0, "cycles": 0, "sec": None},
            "agi": {"step": 0, "cycles": 0, "sec": None},
            "dex": {"step": 0, "cycles": 0, "sec": None},
        },
        "class_id": None,
        "race_id": None,
        "specialty_id": None,
        "inv": {
            "potion": 2,
            # 🔨 (26/09/2026, dev) material pras PRIMEIRAS peças: uma peça comum
            # leva 4 cores (2 do tipo da peça + 2 quaisquer) e 25 de ferro do
            # clã (o clã novo ganha 100 de ferro de forja). Dá arma, armadura,
            # capacete e anel.
            "cores": {
                "wa_atk": 4,     # arma
                "ar_def": 8,     # armadura + capacete
                "ac_atk": 4,     # anel
            },
            "items": {s: [] for s in SLOTS},
        },
        "equip": {s: None for s in SLOTS},
        "craft": {"slot": None, "rar": None, "sub": None, "sel": []},
        "socket": None,
        "combat": None,
        "skill_slots": {
            "equipped": [None] * 5
        },
        "skills_learned": {
            
        },
        # 🔥 Tutorial cinematográfico pra novos jogadores (08/07/2026)
        "tutorial_seen": False,
    }
    p = ensure_player(p)
    recalc(p)
    p["hp"] = p["hp_max"]
    return p

# ===== BÔNUS E TRILHAS =====
# =========================================================
# CLASSES, RAÇAS E ESPECIALIDADES
# =========================================================

# Todas as porcentagens são multiplicadores em cima dos stats já calculados:
# 50%  ->  +0.50
# -30% ->  -0.30

ITEM_SLOT_MAIN_STAT = {
    "weapon": "atk",
    "armor": "def",
    "helmet": "hp_max",
    "gloves": "atk",
    "boots": "spd",
    "shield": "def",
    "belt": "hp_max",
    "necklace": "reg",
    "ring": "crit",
}

ITEM_RARITY_PCT = {
    "common": 0.04,
    "uncommon": 0.08,
    "rare": 0.12,
    "epic": 0.16,
    "legendary": 0.20,
    "mythic": 0.30,     # 26/09/2026 (dev): o mítico não tinha bônus nenhum (0%)
}

def bonus_de_raridade_do_item(item: dict | None, slot: str = "") -> dict | None:
    """📈 (26/09/2026) O bônus que o `recalc` aplica por RARIDADE, pra tela
    mostrar: +4% (comum) a +20% (lendária) no atributo principal da peça —
    ou, nos acessórios, no atributo SORTEADO na forja (`rnd_stat`)."""
    item = item or {}
    slot = slot or item.get("slot") or ""
    principal = ITEM_SLOT_MAIN_STAT.get(slot)
    if not principal:
        return None
    pct = ITEM_RARITY_PCT.get(_norm_rarity_item(item.get("rar", "common")), 0.0)
    if not pct:
        return None
    return {"stat": item.get("rnd_stat") or principal, "pct": int(round(pct * 100)),
            "sorteado": bool(item.get("rnd_stat"))}


def _norm_rarity_item(raw: str) -> str:
    r = str(raw or "common").strip().lower()
    if r in ("comum", "common"): return "common"
    if r in ("incomum", "uncommon"): return "uncommon"
    if r in ("raro", "rare"): return "rare"
    if r in ("épico", "epico", "epic"): return "epic"
    if r in ("lendário", "lendario", "legendary"): return "legendary"
    if r in ("mítico", "mitico", "mythic"): return "mythic"
    return r
    
CLASS_ORDER = [
    "guardiao",
    "mago",
    "arqueiro",
    "curandeiro",
    "guerreiro",
    "berserk",
    "assassino",
    #"invocador", # <--- A 8ª CLASSE OFICIAL AQUI
]

RACE_ORDER = [
    "humano",
    "elfo",
    "anao",
    "draconiano",
    "fera",
    "silfide",
    "dafhir",
    "Bárbaro",
]
CLASSESDB = {
    "guardiao": {
        "name": "🛡 Guardião",
        "desc": "Puro tanque, aguenta porrada.",
        "mods": {  # % em cima do stat final
            "def": 0.50,   # +50% DEF
            "reg": 0.50,   # +50% REGEN
            "spd": -0.30,  # -30% SPD
        },
    },
    "mago": {
        "name": "🔮 Mago",
        "desc": "Vidro ambulante, muito dano.",
        "mods": {
            "atk": 0.50,    # +50% ATK
            "spd": 0.50,    # +50% SPD
            "hp_max": -0.50 # -50% VIDA MÁX
        },
    },
    "arqueiro": {
        "name": "🏹 Arqueiro",
        "desc": "Rápido e esquiva muito.",
        "mods": {
            "spd": 0.50,   # +50% SPD
            "eva": 0.50,   # +50% ESQUIVA
            "def": -0.50,  # -50% DEF
        },
    },
    "curandeiro": {
        "name": "💚 Curandeiro",
        "desc": "Suporte que bate e cura.",
        "mods": {
            "atk": 0.50,    # +50% ATK (para skills de cura/dano híbrido)
            "hp_max": 0.50, # +50% VIDA
            "spd": -0.30,   # -30% SPD
        },
    },
    "guerreiro": {
        "name": "⚔ Guerreiro",
        "desc": "Equilíbrio entre acerto e mobilidade.",
        "mods": {
            "spd": 0.50,  # +50% SPD
            "acc": 0.50,  # +50% PRECISÃO
            "eva": -0.50, # -50% ESQUIVA
        },
    },
    "bezerk": {
        "name": "🩸 Bezerk",
        "desc": "Regen alta e dano absurdo.",
        "mods": {
            "reg": 0.50,   # +50% REGEN
            "atk": 0.50,   # +50% ATK
            "hp_max": -0.50, # -50% VIDA
        },
    },
    "assassino": {
        "name": "🗡 Assassino",
        "desc": "Crítico alto, muito frágil.",
        "mods": {
            "atk": 0.50,   # +50% ATK
            "crit": 0.50,  # +50% CRIT
            "def": -0.50,  # -50% DEF
        },
    },
    #"invocador": {
        #"name": "🐺 Invocador",
       # "desc": "Comanda criaturas em batalha. Rápido e evasivo, mas tem defesa baixa.",
        #"mods": {
            #"spd": 0.50,   # +50% Velocidade (Agem rápido para buffar os pets)
           # "eva": 0.50,   # +50% Esquiva (Fica recuado das linhas de frente)
            #"def": -0.50,  # -50% Defesa (Se o bicho chegar perto, ele derrete)
        #},
   # },

}

# Alias para compatibilidade com imports antigos, se existirem
WEAPON_TYPE_PCT = {
    "sword":  {"atk": 0.10},
    "spear":  {"acc": 0.10},
    "bow":    {"spd": 0.10},
    "dagger": {"crit": 0.10},
    "hammer": {"def": 0.10},
}

CLASSES_DB = CLASSESDB

RACESDB = {
    "humano": {
        "name": "Humano",
        "main_attr": "dex",  # +1 DEX
        "mods": {
            "acc": 0.35,     # +35% Precisão
            "crit": 0.35,    # +35% Crítico
            "hp_max": -0.35, # -35% Vida Máx
        },
    },
    "elfo": {
        "name": "Elfo",
        "main_attr": "agi",
        "mods": {
            "atk": 0.35,   # +35% ATK
            "eva": 0.35,   # +35% Esquiva
            "def": -0.35,  # -35% DEF
        },
    },
    "anao": {
        "name": "Anão",
        "main_attr": "str",
        "mods": {
            "def": 0.35,   # +35% DEF
            "hp_max": 0.35,# +35% Vida Máx
            "spd": -0.35,  # -35% SPD
        },
    },
    "draconiano": {
        "name": "Draconiano",
        "main_attr": "str",
        "mods": {
            "atk": 0.35,   # +35% ATK
            "def": 0.35,   # +35% DEF
            "acc": -0.35,  # -35% Precisão
        },
    },
    "fera": {
        "name": "Fera",
        "main_attr": "agi",
        "mods": {
            "eva": 0.35,   # +35% Esquiva
            "spd": 0.35,   # +35% SPD
            "reg": -0.35,  # -35% Regeneração
        },
    },
    "silfide": {
        "name": "Silfide",
        "main_attr": "vit",
        "mods": {
            "reg": 0.35,   # +35% Regen
            "def": 0.35,   # +35% DEF
            "atk": -0.35,  # -35% ATK
        },
    },
    "dafhir": {
        "name": "Dafhir",
        "main_attr": "dex",
        "mods": {
            "crit": 0.35,  # +35% Crítico
            "acc": 0.35,   # +35% Precisão
            "def": -0.35,  # -35% DEF
        },
    },
    "Bárbaro": {
        "name": "Bárbaro",
        "main_attr": "vit",
        "mods": {
            "hp_max": 0.35, # +35% Vida Máx
            "reg": 0.35,    # +35% Regen
            "crit": -0.35,  # -35% Crítico
        },
    },
}



TRAILS_DB = {
    "str": {"sec_opts": ["atk", "def"]},
    "vit": {"sec_opts": ["hp_max", "reg"]},
    "agi": {"sec_opts": ["spd", "eva"]},
    "dex": {"sec_opts": ["crit", "acc"]},
}
def _apply_percent_mods(stats: dict, mods: dict) -> None:
    """
    Aplica modificadores percentuais in-place.
    mods: {"atk": 0.5, "def": -0.3} => +50% atk, -30% def.
    """
    for k, pct in mods.items():
        if k in stats and pct != 0:
            base = stats[k]
            stats[k] = int(base * (1.0 + pct))
            
def class_attr_bonus(p: dict) -> int:
    if not p.get("class_id"): return 0
    return max(0, int(p["level"]) - 1)

def class_sec_bonus(p: dict) -> int:
    if not p.get("class_id"): return 0
    return ((max(1, int(p["level"])) - 1) // 2) * 2

def trails_bonus(p: dict):
    bonus_attr = {"str": 0, "vit": 0, "agi": 0, "dex": 0}
    bonus_sec: dict[str, int] = {}
    for k, t in p["trails"].items():
        cycles = int(t.get("cycles", 0))
        step = int(t.get("step", 0))
        sec = t.get("sec")
        bonus_attr[k] += cycles * 7
        if sec:
            bonus_sec[sec] = bonus_sec.get(sec, 0) + cycles * (16 + 12)
        bonus_attr[k] += min(step, 4) * 1
        if step >= 5: bonus_attr[k] += 3
        if sec and step >= 6:
            qtd_6a9 = min(step, 9) - 5
            bonus_sec[sec] = bonus_sec.get(sec, 0) + qtd_6a9 * 4
        if sec and step >= 10:
            bonus_sec[sec] = bonus_sec.get(sec, 0) + 12
    return bonus_attr, bonus_sec

def attrs_efetivos(p: dict) -> dict:
    """Atributos como o jogo os USA: base + trilhas + o +1/nível da raça.

    POR QUE EXISTE (20/09/2026): `recalc` já somava isso tudo, mas numa
    variável LOCAL — o total virava status (atk, def...) e desaparecia.
    `p["attrs"]` guarda só a base, e era ela que a ficha mostrava. Quem
    tinha 29 pontos de trilha em agilidade via "agi 1" na tela e não tinha
    como saber onde o investimento foi parar.

    É função derivada de propósito: gravar o total em `p` exigiria entrar
    em `_extra_fields` do sql_repo (armadilha nº 4) e, pior, correria o
    risco clássico de empilhar bônus a cada recalc.
    """
    base = dict(p.get("attrs", {}) or {})
    for k in ("str", "vit", "agi", "dex"):
        base.setdefault(k, 1)
    bonus_attr, _ = trails_bonus(p)
    total = {k: int(base.get(k, 0)) + int(bonus_attr.get(k, 0)) for k in base}

    race_id = p.get("race_id")
    if race_id in RACESDB:
        main_attr = RACESDB[race_id].get("main_attr")
        if main_attr and main_attr in total:
            total[main_attr] += int(p.get("level", 1))

    return {"base": {k: int(v) for k, v in base.items()},
            "trilha": {k: int(v) for k, v in bonus_attr.items()},
            "total": total}


def spend_trail_point(p: dict, trail_key: str, amount: int = 1, sec: str | None = None):
    if p.get("trail_points", 0) <= 0: return False, "Sem pontos de trilha.", False
    if trail_key not in p["trails"]: return False, "Trilha inválida.", False
    
    t = p["trails"][trail_key]
    
    # Garante que ele não vai gastar mais do que tem na carteira
    pontos_para_gastar = min(int(amount), p.get("trail_points", 0))
    
    # 1. Se estiver exatamente na barreira do Passo 5 e precisar escolher
    if t["step"] == 5 and not t.get("sec"):
        if sec is None: return True, "Escolha um atributo secundário.", True
        if sec not in TRAILS_DB[trail_key]["sec_opts"]: return False, "Secundário inválido.", True
        t["sec"] = sec
        # Gastou 1 ponto para quebrar a barreira
        p["trail_points"] -= 1
        t["step"] += 1
        pontos_para_gastar -= 1
        if t["step"] >= 10:
            t["cycles"] += 1
            t["step"] = 0

    # 2. O Loop de Gastos (A Mágica acontece aqui!)
    pontos_gastos = 0
    for _ in range(pontos_para_gastar):
        # 🔥 A BARREIRA: Se bater no Passo 5 e não tiver 'sec', freia o loop na hora!
        if t["step"] == 5 and not t.get("sec"):
            break
            
        p["trail_points"] -= 1
        t["step"] += 1
        pontos_gastos += 1
        
        if t["step"] >= 10:
            t["cycles"] += 1
            t["step"] = 0
            
    if pontos_gastos > 0:
        return True, f"✅ Trilha evoluída em {pontos_gastos} passo(s)!", False
    else:
        # Se caiu aqui é porque ele esbarrou no passo 5 e precisa do pop-up do secundário
        return True, "Escolha um secundário.", True



def pick_class(p: dict, class_id: str) -> str:
    if p.get("class_id"):
        return "❌ Você já escolheu uma classe inicial. Ela não pode ser trocada."

    if class_id not in CLASSESDB:
        return "❌ Classe inválida."

    p["class_id"] = class_id
    recalc(p)
    return f"✅ Classe escolhida: {CLASSESDB[class_id]['name']}"


def pick_race(p: dict, race_id: str) -> str:
    if p.get("race_id"):
        return "❌ Você já escolheu uma raça. Ela não pode ser trocada."

    if race_id not in RACESDB:
        return "❌ Raça inválida."

    p["race_id"] = race_id
    recalc(p)
    return f"✅ Raça escolhida: {RACESDB[race_id]['name']}"


def pick_specialty(p: dict, spec_id: str) -> str:
    if p.get("specialty_id"):
        return "❌ Você já escolheu uma especialidade."

    if spec_id not in SPECIALTIESDB:
        return "❌ Especialidade inválida."

    p["specialty_id"] = spec_id
    recalc(p)
    return f"✅ Especialidade escolhida: {SPECIALTIESDB[spec_id]['name']}"
    
def _after_floor_victory(p: dict) -> str:
    # 🛡️ LIMPEZA DE ESCUDO (A sua correção!)
    p.pop("shield", None)

    # 1. Limpa os debuffs (como já estava)
    combat_data = p.get("combat")
    if combat_data and "enemies" in combat_data:
        for enemy in combat_data["enemies"]:
            enemy.pop("dots", None)
            enemy.pop("stun", None)
            enemy.pop("frozen", None)
            
    # 🎁 o pacote da vitória, pra janela de recompensa (a resposta tira ele
    # do jogador ao montar a tela: aparece UMA vez)
    _g = (p.get("combat") or {}).get("ganhos")
    if _g and (_g.get("xp") or _g.get("cores") or _g.get("material") or _g.get("nivel") or _g.get("xp_travado")):
        p["_ultima_recompensa"] = {**_g, "id": f"{int(time.time() * 1000)}-{random.randint(0, 9999)}"}

    # 2. Encerra o combate
    p["combat"] = None
    p["state"] = "TOWER"
    p.pop("tower_choice", None)
    # 👑 (28/09) o chefe do andar caiu agora: o portal abre na tela da vitória
    if p.pop("_portal_do_chefe", False):
        p["tower_choice"] = "chefe"
    
    # 👻 A VACINA DUPLA: Arranca QUALQUER vestígio de Raid do save do jogador
    p.pop("tower_mode", None) 
    p.pop("raid_room_id", None) 
    
    return ""




def after_raid_floor_victory(p: dict) -> str:
    # 🛡️ LIMPEZA DE ESCUDO NA RAID
    p.pop("shield", None)

    p["combat"] = None
    cur = int(p.get("raid_floor", 1))
    p["raid_floor"] = cur + 1
    p["state"] = "RAID_LOBBY"
    p["raid_ready"] = False
    
    return ""



def level_up(p: dict):
    p["level"] += 1
    p["trail_points"] = p.get("trail_points", 0) + 4
    
    recalc(p)

def gain_xp(p: dict, amount: int) -> str:
    """Adiciona XP ao jogador, respeitando o limite de Level (Andar * 2)."""
    # 🔥 PETS: bônus de XP (antes só decorativo, agora ativo em TODO ganho de XP do jogo)
    from game.pets_db import get_pet_bonuses
    xp_bonus = get_pet_bonuses(p).get("xp", 0)
    if xp_bonus:
        amount = int(amount * (1.0 + xp_bonus))

    andar_atual = int(p.get("tower_floor", 1))
    limite_level = andar_atual * 2
    
    # 1. Se já está no limite ou acima dele, nem ganha o XP (trava a barra)
    if int(p.get("level", 1)) >= limite_level:
        p["xp"] = 0 # Zera a barra para não acumular XP fantasma
        # 🔥 CORRIGIDO (08/07/2026): antes essa trava zerava o XP e voltava
        # silenciosamente — quem chamava gain_xp (ex: o Cultivo de Aura AFK)
        # não tinha como saber que nada foi ganho, e mostrava "+X XP" mesmo
        # assim pro jogador. Essa flag deixa quem chamou saber a real.
        p["_last_xp_capped"] = True
        return ""

    p["_last_xp_capped"] = False
    p["xp"] += int(amount)
    ups = 0
    
    while p["xp"] >= p.get("xp_next", 100):
        # 2. A Trava de Segurança: Se bateu no limite DURANTE o ganho de muito XP
        if int(p.get("level", 1)) >= limite_level:
            p["xp"] = 0  # Zera o XP que sobrou
            break
            
        p["xp"] -= p["xp_next"]
        
        # Chama a sua função original de level_up
        from game.logic import level_up
        level_up(p)
        ups += 1
        
    if ups > 0: 
        msg = f"\n⬆️ Subiu {ups} nível(is)!\nAgora Lv {p['level']} (+{ups} pontos de trilha)."
        
        # Aviso visual para o jogador saber que bateu no teto
        if int(p.get("level", 1)) >= limite_level:
            msg += f"\n🛑 <b>Nível Máximo do Andar ({limite_level}) atingido!</b> Avance na Torre."
            
        return msg
        
    return ""


def can_learn_skill(p_data: dict, skill_data: dict) -> tuple[bool, str]:
    """Verifica os requisitos de Classe (Tiers 1-3) e Especialidade (Tiers 4-5)."""
    from game.logic import get_specialty_slots
    
    rarity = int(skill_data.get("rarity", 1))
    
    if rarity <= 3:
        req_class = skill_data.get("req_class")
        if req_class:
            p_class = str(p_data.get("class", p_data.get("class_id", ""))).lower()
            if req_class.lower() != p_class:
                return False, f"❌ Seu corpo rejeita esta energia. Requer a classe: [{req_class.capitalize()}]."
    else:
        req_spec = skill_data.get("req_spec")
        if req_spec:
            p_specs = get_specialty_slots(p_data)
            if req_spec not in p_specs:
                return False, f"❌ Conhecimento insuficiente! Requer a especialidade: [{req_spec}]."
                
    return True, ""


def learn_skill_from_core(p: dict, core_id: str) -> str:
    
    data = SKILL_DB.get(core_id)
    if not data:
        return '❌ Core inválido.'
        
    cores = p.setdefault('inv', {}).setdefault('cores', {})
    qnt_cores = cores.get(core_id, 0)
    
    if qnt_cores <= 0:
        return '❌ Sem <b>Core</b> no inventário\n'
        
    skill_data = data.get('skill')
    if not skill_data:
        return '❌ Core sem skill.'
        
    # =======================================================
    # 🔒 BARREIRA DE APRENDIZADO (Impede uso de classes erradas)
    # =======================================================
    pode_aprender, erro = can_learn_skill(p, skill_data)
    if not pode_aprender:
        return erro

    skill_id = skill_data.get('id') or core_id
    learned = p.setdefault('skills_learned', {})
    
    # -------------------------------------------------------------
    # Se já tem a skill, verifica custo para evoluir
    # -------------------------------------------------------------
    if skill_id in learned:
        current_skill = learned[skill_id]
        if not isinstance(current_skill, dict):
            current_skill = skill_data.copy()
            
        current_lvl = current_skill.get('level', 1)
        
        if current_lvl >= 10:
            return f"❌ A Magia <b>{skill_data.get('name')}</b> já está no Nível Máximo (Lv.10)!\n"
            
        cost = current_lvl + 1
        
        if qnt_cores < cost:
            return f"❌ Você precisa de <b>{cost}x Cores</b> para evoluir para o Nível {current_lvl + 1}.\n"
            
        # Consome os cores
        cores[core_id] -= cost
        if cores[core_id] <= 0:
            cores.pop(core_id)
            
        # =======================================================
        # 📈 EVOLUÇÃO DE STATUS (Escala todas as mecânicas em 10%)
        # =======================================================
        current_skill['level'] = current_lvl + 1
        
        keys_to_scale = ['mult', 'heal_percent', 'shield_pct', 'hot_pct', 'lifesteal_pct', 'dot_mult', 'execute_pct', 'pet_mult']
        for key in keys_to_scale:
            if key in current_skill:
                current_skill[key] = round(float(current_skill[key]) * 1.1, 2)
        
        learned[skill_id] = current_skill
        # recalc(p) # Descomente se a função recalc estiver importada e ativa
        return f"✨ <b>Evoluiu!</b> <b>{skill_data.get('name')}</b> atingiu o Nível {current_lvl + 1}!\n"
        
    # -------------------------------------------------------------
    # Se NÃO tem a skill, aprende no Lvl 1 (Custo 1)
    # -------------------------------------------------------------
    cores[core_id] -= 1
    if cores[core_id] <= 0:
        cores.pop(core_id)
        
    new_skill = skill_data.copy()
    new_skill['level'] = 1

    # 🎲 Sorteia o afixo extra (bônus de atributo, ou chance de algo raro
    # tipo Dano Duplo/Esquiva Perfeita) baseado na raridade da skill.
    from game.skills import roll_skill_affix, format_skill_affix
    afixo = roll_skill_affix(int(skill_data.get('rarity', 1)))
    new_skill['affix'] = afixo

    learned[skill_id] = new_skill
    
    # recalc(p) # Descomente se a função recalc estiver importada e ativa
    return (
        f"✨ <b>Aprendido!</b> <b>{skill_data.get('name')}</b> (Nível 1)\n"
        f"{format_skill_affix(afixo, int(skill_data.get('rarity', 1)), 1)}\n"
    )


def apply_passive_skill_bonuses(p: dict, s: dict) -> dict:
    """Lê os 5 slots de skills equipadas e aplica os bônus das que forem passivas."""

    slots = p.get("skill_slots", {})
    equipadas = slots.get("equipped", [])
    skills_aprendidas = p.get("skills_learned", {})

    def _e_passiva(sk_id):
        sk_info = get_skill_by_id(sk_id)
        return sk_info and sk_info.get("skill", {}).get("type") == "passive"

    passivas_equipadas = [sk_id for sk_id in equipadas if sk_id and _e_passiva(sk_id)]

    # 1. Aplicar Bônus Fixos primeiro
    for sk_id in passivas_equipadas:
        if not sk_id: continue
        sk_info = get_skill_by_id(sk_id)
        if not sk_info: continue
        
        sk = sk_info.get("skill", {})
        lvl = 1
        if isinstance(skills_aprendidas.get(sk_id), dict):
            lvl = int(skills_aprendidas[sk_id].get("level", 1))
            
        for stat, val in sk.get("bonuses", {}).items():
            bonus_real = int(val * (1 + (lvl - 1) * 0.10))
            s[stat] = s.get(stat, 0) + bonus_real
            
    # 2. Aplicar Bônus em Porcentagem
    for sk_id in passivas_equipadas:
        if not sk_id: continue
        sk_info = get_skill_by_id(sk_id)
        if not sk_info: continue
        
        sk = sk_info.get("skill", {})
        lvl = 1
        if isinstance(skills_aprendidas.get(sk_id), dict):
            lvl = int(skills_aprendidas[sk_id].get("level", 1))
            
        for stat, val in sk.get("bonus_pct", {}).items():
            pct_real = val + ((lvl - 1) * 0.01)
            # 🔧 25/09/2026: era int() — cortava a vírgula pra baixo, e em
            # atributo pequeno a passiva dava ZERO (medido: DEF 2 e ESQ 2
            # com +5% → +0; ATK 11 → +0). Agora arredonda, e passiva que
            # tem o atributo sempre dá pelo menos +1.
            atual = int(s.get(stat, 0))
            novo = int(round(atual * (1.0 + pct_real)))
            if atual > 0 and pct_real > 0:
                novo = max(novo, atual + 1)
            s[stat] = novo
            
    return s


REROLL_AFFIX_CUSTO_OURO = 500


def reroll_skill_affix(p: dict, skill_id: str) -> str:
    """🎲 REROLL (09/07/2026): re-rola os bônus de atributo de uma skill
    aprendida. Custa 500 de ouro + 1 core da própria skill. O jogador troca
    recursos por uma nova rolagem — pode sair melhor ou pior, é aposta."""
    from game.skills import get_skill_by_id, roll_skill_affix, format_skill_affix

    learned = p.get("skills_learned", {})
    entry = learned.get(skill_id)
    if not isinstance(entry, dict):
        return "❌ Você não tem essa skill aprendida."

    rarity = int(entry.get("rarity", 1))
    if rarity <= 1:
        return "❌ Skills Comuns não têm bônus pra re-rolar."

    # Descobre o core correspondente a essa skill (pra cobrar 1 unidade).
    base = get_skill_by_id(skill_id)
    core_id = None
    if base:
        # get_skill_by_id aceita tanto core_x quanto a_x; o core é a chave
        # externa. Varre o SKILL_DB pra achar a chave core cujo skill.id bate.
        from game.skills import SKILL_DB
        for cid, cdata in SKILL_DB.items():
            if (cdata.get("skill") or {}).get("id") == skill_id or cid == skill_id:
                core_id = cid
                break

    if not core_id:
        return "❌ Não encontrei o core dessa skill pra cobrar o reroll."

    cores = p.setdefault("inv", {}).setdefault("cores", {})
    gold = int(p.get("gold", 0))

    if gold < REROLL_AFFIX_CUSTO_OURO:
        return f"❌ Você precisa de {REROLL_AFFIX_CUSTO_OURO}g pra re-rolar (tem {gold}g)."
    if cores.get(core_id, 0) < 1:
        nome_core = (base.get("name") if base else core_id)
        return f"❌ Você precisa de 1 <b>{nome_core}</b> pra re-rolar (tem {cores.get(core_id, 0)})."

    # Cobra
    p["gold"] = gold - REROLL_AFFIX_CUSTO_OURO
    cores[core_id] -= 1
    if cores[core_id] <= 0:
        cores.pop(core_id, None)

    # Re-rola e aplica
    novo_afixo = roll_skill_affix(rarity)
    entry["affix"] = novo_afixo
    learned[skill_id] = entry
    recalc(p)

    return (
        f"🎲 <b>Bônus re-rolados!</b> (-{REROLL_AFFIX_CUSTO_OURO}g, -1 core)\n"
        f"{format_skill_affix(novo_afixo, rarity, int(entry.get('level', 1) or 1))}"
    )


def apply_skill_affix_bonuses(p: dict, s: dict) -> dict:
    """Aplica os bônus FLAT das 5 skills equipadas (ativas ou passivas).
    🔥 v2 (09/07/2026): cada skill carrega vários bônus flat (0-7 por
    atributo), com a quantidade definida pela raridade. Soma direta —
    diferente da versão antiga que multiplicava um único percentual.
    Os afixos são rolados ao aprender (roll_skill_affix) e podem ser
    re-rolados pagando ouro + core (reroll_skill_affix)."""
    slots = p.get("skill_slots", {}).get("equipped", [None] * 5)
    learned = p.get("skills_learned", {})

    for sk_id in slots:
        if not sk_id:
            continue
        entry = learned.get(sk_id)
        if not isinstance(entry, dict):
            continue
        affix = entry.get("affix")
        if not isinstance(affix, dict):
            continue
        # 📈 escala nova (25/09/2026): raridade × qualidade × nível da skill
        from game.skills import valor_do_afixo, get_skill_by_id as _gsk
        rarity = entry.get("rarity")
        if rarity is None:
            rarity = ((_gsk(sk_id) or {}).get("skill") or {}).get("rarity", 1)
        nivel = int(entry.get("level", 1) or 1)
        for b in (affix.get("bonuses") or []):
            stat = b.get("stat")
            val = valor_do_afixo(stat, b.get("value", 0), int(rarity or 1), nivel)
            if stat and val:
                s[stat] = int(s.get(stat, 0)) + val

    return s




# =============================================================================
# ⚡ PODER DE COMBATE (08/07/2026) — um número único pra dar noção rápida
# de o quão forte é alguém (jogador ou monstro), sem precisar comparar
# atributo por atributo.
# =============================================================================

def calc_power_level(stats: dict) -> int:
    """Combina os status principais num único valor de 'Poder'. Os pesos
    refletem o quanto cada status pesa na prática (ATK/DEF valem mais que
    ACC/EVA, HP é convertido pra uma escala compatível com o resto)."""
    atk = float(stats.get("atk", 0))
    deff = float(stats.get("def", 0))
    hp_max = float(stats.get("hp_max", 1))
    spd = float(stats.get("spd", 0))
    crit = float(stats.get("crit", 0))
    acc = float(stats.get("acc", 0))
    eva = float(stats.get("eva", 0))

    poder = (
        atk * 3.0 +
        deff * 2.0 +
        hp_max * 0.4 +
        spd * 1.2 +
        crit * 1.5 +
        acc * 0.8 +
        eva * 1.2
    )
    return max(1, int(round(poder)))


def comparar_poder(poder_jogador: int, poder_alvo: int) -> tuple[str, str]:
    """Descreve um alvo (monstro/oponente) em relação ao poder do jogador."""
    poder_jogador = max(1, poder_jogador)
    razao = poder_alvo / poder_jogador
    if razao < 0.5:
        return "🟢", "Muito mais fraco que você"
    elif razao < 0.85:
        return "🟢", "Mais fraco que você"
    elif razao < 1.15:
        return "🟡", "Nível parecido ao seu"
    elif razao < 2.0:
        return "🟠", "Mais forte que você"
    else:
        return "🔴", "MUITO mais forte — CUIDADO!"


BONUS_NASCIDO_NA_TORRE = 0.10


def recalc(p: dict) -> None:
    # --------------------------------------------------------------
    # BASE FIXA DOS STATS
    # trava uma base interna para não empilhar status a cada recalc
    # --------------------------------------------------------------
    if "_base_stats" not in p or not isinstance(p.get("_base_stats"), dict):
        p["_base_stats"] = {
            "atk": int(p.get("atk", 5)),
            "def": int(p.get("def", 0)),
            "hp_max": 100,
            "spd": int(p.get("spd", 20)),
            "reg": int(p.get("reg", 0)),
            "acc": int(p.get("acc", 0)),
            "eva": int(p.get("eva", 0)),
            "crit": int(p.get("crit", 0)),
        }

    base = p["_base_stats"]

    # base de stats
    s = {
        "atk": int(base.get("atk", 5)),
        "def": int(base.get("def", 0)),
        "hp_max": int(base.get("hp_max", 100)),
        "spd": int(base.get("spd", 20)),
        "reg": int(base.get("reg", 0)),
        "acc": int(base.get("acc", 0)),
        "eva": int(base.get("eva", 0)),
        "crit": int(base.get("crit", 0)),
        "str": int(p.get("attrs", {}).get("str", 1)),
        "vit": int(p.get("attrs", {}).get("vit", 1)),
        "agi": int(p.get("attrs", {}).get("agi", 1)),
        "dex": int(p.get("attrs", {}).get("dex", 1)),
    }

    # sempre inicializa attrs UMA vez
    attrs = dict(p.get("attrs", {"str": 1, "vit": 1, "agi": 1, "dex": 1}))

    # trilhas mexem primeiro no attrs
    bonus_attr, bonus_sec = trails_bonus(p)
    for k, v in bonus_attr.items():
        attrs[k] = attrs.get(k, 0) + v

    # +1 * level da raça no atributo principal
    race_id = p.get("race_id")
    if race_id in RACESDB:
        main_attr = RACESDB[race_id].get("main_attr")
        if main_attr and main_attr in attrs:
            level = int(p.get("level", 1))
            attrs[main_attr] = attrs.get(main_attr, 0) + level

    # attrs alimentam os stats base
    s["atk"] += attrs.get("str", 0) * 2
    s["def"] += attrs.get("str", 0) * 2
    s["hp_max"] += attrs.get("vit", 0) * 50
    s["reg"] += attrs.get("vit", 0) * 2
    s["spd"] += attrs.get("agi", 0) * 2
    s["eva"] += attrs.get("agi", 0) * 2
    s["acc"] += attrs.get("dex", 0) * 2
    s["crit"] += attrs.get("dex", 0) * 2

    # bônus secundário das trilhas
    for k, v in bonus_sec.items():
        s[k] = s.get(k, 0) + v

# ==========================================
    # 🐉 INJEÇÃO DE STATUS DOS PETS EQUIPADOS
    # ==========================================
    try:
        from game.pets_db import PETS_DB, derive_pet_combat_stats
        deck = p.get("pets", {}).get("deck", [None]*5)

        # 🔥 (09/07/2026): antes só o ATK contava (pet["bonus_stats"] só
        # tinha essa chave). Agora usa derive_pet_combat_stats — a MESMA
        # função que monta os stats do pet pra Arena — e injeta o valor
        # EXATO (sem redução) de todos os stats de combate no personagem.
        # É por isso que evoluir/nivelar um pet agora fortalece o jogador
        # em TUDO, não só em ataque — o número que aparece na tela do pet
        # é exatamente o que soma no personagem, igual ao pedido.
        PET_STAT_TO_PLAYER_STAT = {
            "atk": "atk", "def": "def", "hp_max": "hp_max", "spd": "spd",
            "acc": "acc", "eva": "eva", "crit": "crit",
        }

        for pet_id in deck:
            if not pet_id:
                continue
            pet = PETS_DB.get(pet_id)
            if not pet:
                continue
            stats_pet = derive_pet_combat_stats(p, pet_id)
            if not stats_pet:
                continue

            for stat_pet, stat_jogador in PET_STAT_TO_PLAYER_STAT.items():
                s[stat_jogador] = s.get(stat_jogador, 0) + int(stats_pet.get(stat_pet, 0))

    except ImportError:
        pass
    equip = p.get("equip", {}) or {}
    for slot, it in equip.items():
        if not it:
            continue

        s = apply_bonus(s, it.get("bonus", {}) or {})

        for cid in it.get("socked", []) or []:
            s = apply_bonus(s, core_bonus(cid))

        if slot == "weapon":
            weapon_sub = it.get("sub")
            mods_pct = WEAPON_TYPE_PCT.get(weapon_sub)
            if mods_pct:
                _apply_percent_mods(s, mods_pct)

        # ✅ INDENTAÇÃO CORRIGIDA AQUI!
        main_stat = ITEM_SLOT_MAIN_STAT.get(slot)
        if main_stat:
            stat_to_buff = it.get("rnd_stat", main_stat)
            
            rar_norm = _norm_rarity_item(it.get("rar", "common"))
            pct = ITEM_RARITY_PCT.get(rar_norm, 0.0)
            if pct:
                _apply_percent_mods(s, {stat_to_buff: pct})


    # 🔥 REWORK DE SKILLS v2: passivas equipadas (dentro dos 5 slots únicos)
    # voltam a dar bônus de status, igual antes.
    s = apply_passive_skill_bonuses(p, s)

    # 🎲 Afixos extras de TODAS as skills equipadas (ativas + passivas).
    s = apply_skill_affix_bonuses(p, s)

    # classe / raça
    # classe / raça
    class_id = p.get("class_id")
    if class_id in CLASSESDB:
        _apply_percent_mods(s, CLASSESDB[class_id].get("mods", {}))

    if race_id in RACESDB:
        _apply_percent_mods(s, RACESDB[race_id].get("mods", {}))

    # 🔥 A MÁGICA: SISTEMA MULTICLASSE CORRIGIDO
    # Usa a função get_specialty_slots para converter o texto do Banco de Dados em lista!
    specs = get_specialty_slots(p)
    
    for spec_id in specs:
        if spec_id and spec_id in SPECIALTIESDB:
            # Aplica os multiplicadores passivos da especialidade (ex: HP, DEF, ATK)
            _apply_percent_mods(s, SPECIALTIESDB[spec_id].get("passives", {}))

    # 🔥 CHAKRA: bônus permanente sorteado na criação do personagem
    chakra = p.get("chakra")
    if chakra and chakra.get("kind") == "stat" and chakra.get("stat"):
        _apply_percent_mods(s, {chakra["stat"]: chakra.get("pct", 0)})

    # 🔥 PETS: bônus de mechanic (antes só decorativo no card, agora ativo)
    # dmg_amp -> % de ATK | dmg_red -> % de DEF | eva_amp -> % de EVA
    from game.pets_db import get_pet_bonuses
    pet_bonuses = get_pet_bonuses(p)
    pet_stat_mods = {}
    if pet_bonuses.get("dmg_amp"):
        pet_stat_mods["atk"] = pet_bonuses["dmg_amp"]
    if pet_bonuses.get("dmg_red"):
        pet_stat_mods["def"] = pet_bonuses["dmg_red"]
    if pet_bonuses.get("eva_amp"):
        pet_stat_mods["eva"] = pet_bonuses["eva_amp"]
    if pet_stat_mods:
        _apply_percent_mods(s, pet_stat_mods)

    # 🔥 MONTARIA: bônus de status flat (soma direta, diferente dos pets que
    # são percentuais) — principalmente velocidade, já que é o tema dela.
    from game.mounts import get_equipped_mount_bonus
    mount = get_equipped_mount_bonus(p)
    for stat, val in (mount.get("bonus_stats") or {}).items():
        s[stat] = int(s.get(stat, 0)) + int(val)

    # 🌱 (28/09, dev) NASCIDO NA TORRE: o personagem que veio de um aldeão
    # desperto tem +10% em TODOS os status — é o que a Torre dá a quem nasceu
    # nela. O preço é não escolher: raça e profissão vêm sorteadas
    # (characters.trocar_personagem). Por último, depois de tudo, pra valer
    # 10% do status inteiro (montaria e pets inclusive).
    # Arredonda (e não trunca como os outros modificadores): truncando, um
    # ATK 6 do nível 1 continuava 6 e o bônus sumia no começo do jogo.
    if p.get("origem_aldeao"):
        for _k in ("hp_max", "atk", "def", "spd", "reg", "acc", "eva", "crit"):
            if _k in s:
                s[_k] = int(float(s[_k]) * (1.0 + BONUS_NASCIDO_NA_TORRE) + 0.5)

    # salva stats finais
    p["hp_max"] = max(1, int(s.get("hp_max", 100)))
    p["atk"] = max(0, int(s.get("atk", 0)))
    p["def"] = max(0, int(s.get("def", 0)))
    p["spd"] = max(1, int(s.get("spd", 20)))
    p["reg"] = int(s.get("reg", 0))
    p["acc"] = max(0, int(s.get("acc", 0)))
    p["eva"] = max(0, int(s.get("eva", 0)))
    p["crit"] = max(0, int(s.get("crit", 0)))

    if p.get("hp", 0) > p["hp_max"]:
        p["hp"] = p["hp_max"]

    # --------------------------------------------------------------
    # 🔮 RECALCULAR MULTIPLICADORES DE SKILL (LEVEL + SOCKETS)
    # --------------------------------------------------------------
    socket_counts = {}
    for _, it in p.get("equip", {}).items():
        if it:
            for socked_cid in it.get("socked", []):
                socket_counts[socked_cid] = socket_counts.get(socked_cid, 0) + 1

    learned = p.get("skills_learned", {})
    if isinstance(learned, dict):
        try:
            for sk_id, sk_data in learned.items():
                if not isinstance(sk_data, dict):
                    continue

                orig_core_id = None
                base_skill_data = {}

                for cid, cdata in SKILL_DB.items():
                    if cdata.get("skill", {}).get("id") == sk_id:
                        orig_core_id = cid
                        base_skill_data = cdata.get("skill", {})
                        break

                if orig_core_id and base_skill_data:
                    lvl = int(sk_data.get("level", 1))
                    sockets_eq = socket_counts.get(orig_core_id, 0)
                    buff_multiplier = 1.0 + ((lvl - 1) * 0.10) + (sockets_eq * 0.02)

                    if "mult" in base_skill_data:
                        sk_data["mult"] = round(float(base_skill_data["mult"]) * buff_multiplier, 3)
                    if "dmg_percent" in base_skill_data:
                        sk_data["dmg_percent"] = round(float(base_skill_data["dmg_percent"]) * buff_multiplier, 3)
                    if "dot_mult" in base_skill_data:
                        sk_data["dot_mult"] = round(float(base_skill_data["dot_mult"]) * buff_multiplier, 3)
                    if "heal_percent" in base_skill_data:
                        sk_data["heal_percent"] = round(float(base_skill_data["heal_percent"]) * buff_multiplier, 3)

        except ImportError:
            pass

def equip_skill(p: dict, skill_id: str, slot_type: str, slot_idx: int) -> str:
    """Equipa a skill e garante que ela vai para o slot certo, usando a chave correta."""
    # Garante a chave correta que foi criada no ensure_player
    if "skill_slots" not in p:
        p["skill_slots"] = {"equipped": [None] * 5}

    slots = p["skill_slots"].get(slot_type)
    if slots is None or slot_idx >= len(slots):
        return "❌ Slot inválido."

    # Se for para remover (Botão de limpar fantasma)
    if skill_id == "remove":
        slots[slot_idx] = None
        p["skill_slots"][slot_type] = slots
        return "🗑️ Slot liberado com sucesso!"

    # Verifica se a skill realmente está aprendida
    learned = p.get("skills_learned", {})
    if skill_id not in learned:
        return f"❌ Erro: Skill {skill_id} não encontrada na sua mente."

    # Remove a skill se ela já estiver equipada noutro slot (evita clones)
    for i in range(len(slots)):
        if slots[i] == skill_id:
            slots[i] = None
            
    # Coloca a skill no novo slot e salva
    slots[slot_idx] = skill_id
    p["skill_slots"][slot_type] = slots 
    
    return "✅ Habilidade equipada com sucesso!"
def unequip_item(p: dict, slot: str) -> str:
    """Remove o item do corpo e devolve para a mochila."""
    old_item = p["equip"].get(slot)
    if not old_item:
        return "❌ Nenhum item equipado neste slot."
    
    # Remove do corpo
    p["equip"][slot] = None
    
    # Garante que a mochila do slot existe e guarda o item
    p.setdefault("inv", {}).setdefault("items", {}).setdefault(slot, [])
    p["inv"]["items"][slot].append(old_item)
    
    # Recalcula os status sem o item
    recalc(p)
    
    return f"🔻 {old_item.get('name', 'Item')} desequipado com sucesso!"


    
def on_player_death(p: dict) -> tuple[bool, str]:
    """Gerencia a morte do jogador na Torre. Retorna (True) se morreu mesmo, ou (False) se reviveu."""
    
    # 1. Puxa os triggers da nossa Árvore de Especialidades
    triggers = get_combat_triggers(p)
    cmb = p.get("combat") or {}
    
    # 🩸 MILAGRE 1: Imortalidade (Berserker Colosso de Vitalidade)
    if triggers.get("immortal_1hp_once") and not cmb.get("used_immortal"):
        cmb["used_immortal"] = True
        p["hp"] = 1
        return False, "💢 RESILIÊNCIA INUMANA! Você sobreviveu ao golpe fatal com 1 de HP!\n"
        
    # ✨ MILAGRE 2: Auto-Reviver (Suporte Milagreiro / Necromante)
    if triggers.get("auto_revive_once") and not cmb.get("used_revive"):
        cmb["used_revive"] = True
        # Revive com 50% da Vida Máxima para ficar balanceado
        p["hp"] = max(1, int(p.get("hp_max", 100) * 0.5)) 
        return False, "✨ MILAGRE! Você ressuscitou das cinzas para continuar a luta!\n"
        
    # 💀 MORTE DEFINITIVA (Se não tem passiva ou já gastou)
    # 🔎 (28/09) guarda QUEM derrubou, pra tela de morte explicar o porquê
    # (antes era só "Você caiu em combate": no chefe do 5º andar o jogador
    # morria em 2 toques sem ter ideia do que faltava)
    vivos = [x for x in (cmb.get("enemies") or []) if int(x.get("hp", 0)) > 0]
    if vivos and not (p.get("tower_mode") == "RAID" or p.get("raid_room_id")):
        x = max(vivos, key=lambda y: int(y.get("atk", 0)))
        p["ultima_derrota"] = {"nome": x.get("name", "Monstro"), "tipo": x.get("tipo", "normal"),
                               "atk": int(x.get("atk", 0)), "def": int(x.get("def", 0)),
                               "spd": int(x.get("spd", 0)), "hp_max": int(x.get("hp_max", 0)),
                               "andar": int(p.get("tower_floor") or 1)}
    p["combat"] = None
    p["state"] = "DEAD"
    p["hp"] = 0

    # 🌍 EXPLORAR MUNDO: penalidade de morte é perder 1 item equipado
    # aleatório, e a expedição é encerrada ali mesmo (restaura o andar real
    # da torre, que tinha sido trocado temporariamente pra essa batalha).
    msg_extra = ""
    if p.get("explore_mode"):
        from game.explore import perder_item_aleatorio
        msg_extra = "\n\n" + perder_item_aleatorio(p)
        p["explore_mode"] = False
        saved_floor = p.get("explore_state", {}).get("saved_tower_floor")
        if saved_floor is not None:
            p["tower_floor"] = saved_floor
        p["explore_state"] = {"day": 0, "active": False}

    return True, "💀 VOCÊ MORREU!" + msg_extra


def combat_active_slots_equipped(p: dict) -> list[int]:
    slots = p.get("skill_slots", {}).get("equipped", [None] * 5)
    equipped_indexes = []
    
    for i, sk_id in enumerate(slots):
        if sk_id:
            sk_data = get_skill_by_id(sk_id)
            if sk_data and sk_data.get("skill", {}).get("type") == "active":
                equipped_indexes.append(i)
    
    return equipped_indexes   

def decrease_skill_cooldowns(p: dict) -> None:
    cooldowns = p.setdefault("skill_cooldowns", {})
    for sk_id in list(cooldowns): cooldowns[sk_id] = max(0, cooldowns[sk_id] - 1)

def tower_tp_paid(p: dict) -> tuple[bool, str]:
    from game.mounts import get_equipped_mount_bonus
    mount = get_equipped_mount_bonus(p)
    desconto = 0.0
    if mount.get("mechanic", {}).get("type") == "tp_discount":
        desconto = mount["mechanic"].get("value", 0)

    custo_final = max(1, int(TP_COST * (1.0 - desconto)))
    if p["gold"] < custo_final: return False, f"Ouro insuficiente para teleportar (custa {custo_final}g)."
    p["gold"] -= custo_final
    p["state"] = "CITY"
    tag_montaria = " 🐴 (desconto de montaria aplicado!)" if desconto else ""
    return True, f"Teleporte pago -{custo_final}g. Você voltou para a cidade.{tag_montaria}"

def use_potion(p: dict) -> str:
    inv = p.setdefault("inv", {})

    if inv.get("potion", 0) <= 0:
        return "Sem poções!"

    if p["hp"] >= p["hp_max"]:
        return "Vida cheia."

    inv["potion"] -= 1

    andar = int(p.get("tower_floor", 1))  # pega o andar atual
    heal_amount = 50 + (10 * andar)

    p["hp"] = min(p["hp_max"], p["hp"] + heal_amount)

    return f"Curou +{heal_amount} HP.\n"

def equip_from_inventory(p: dict, slot: str, idx: int) -> str:
    items = p["inv"]["items"].get(slot, [])
    if idx < 0 or idx >= len(items): return "Item inválido."
    new_item = items.pop(idx)
    old_item = p["equip"].get(slot)
    if old_item: items.append(old_item)
    p["equip"][slot] = new_item
    recalc(p)
    return f"Equipado: {new_item.get('name', 'Item')}"

# ===== COMBATE =====
def _tick_cooldowns_dict(cds: dict) -> None:
    for sk in list(cds.keys()):
        cds[sk] = max(0, int(cds.get(sk, 0)) - 1)
        if cds[sk] <= 0: cds.pop(sk, None)

def combat_consume_player_bar(p: dict) -> bool:
    cmb = p.get("combat")
    if not cmb or float(cmb.get("p_bar", 0.0)) < ATB_MAX: return False
    cmb["p_bar"] = max(0.0, float(cmb.get("p_bar", 0.0)) - ATB_MAX)
    return True

def combat_render_bars(p: dict) -> str:
    cmb = p.get("combat")
    if not cmb: return ""
    
    def fmt_bar(bar: float) -> str:
        progress = round(min(ATB_MAX, bar), 1)
        return f"{int(progress):>3}/{int(ATB_MAX)}"
        
    lines = [f"⏳ Você: {fmt_bar(float(cmb.get('p_bar', 0.0)))}"]
    
    # 🐺 A Barra de ATB e Vida do Pet aparecem na interface do combate!
    if cmb.get("pet"):
        pet = cmb["pet"]
        lines.append(f"🐺 {pet['name']} (HP {pet['hp']}): {fmt_bar(float(pet.get('bar', 0.0)))}")
        
    for i, e in enumerate(cmb.get("enemies", []), start=1):
        lines.append(f"⏳ {i}-{e.get('name','Inimigo')}: {fmt_bar(float(e.get('bar', 0.0)))}")
        
    # Usando o \n para manter o layout idêntico ao original, mas organizando tudo perfeitamente!
    return "\n".join(lines)
    
def combat_advance_until_player_ready(p: dict, max_events: int = 50) -> list[str]:
    import random

    cmb = p.get("combat")
    if not cmb or not cmb.get("enemies"):
        return []

    logs: list[str] = []
    
    # 🔥 Puxa os Triggers Mágicos!
    meus_triggers = get_combat_triggers(p)
    inimigo_triggers = {} 

    # =========================================================
    # 🐺 INVOCAÇÃO DO PET (IA INDEPENDENTE)
    # =========================================================
    pet = cmb.get("pet")
    if not pet and meus_triggers.get("start_with_pets") and not cmb.get("pet_summoned_once"):
        cmb["pet_summoned_once"] = True
        pet = {
            "name": "🐺 Espírito Guardião",
            "hp_max": max(1, int(p.get("hp_max", 100) * meus_triggers.get("pet_hp_inheritance", 1.0))),
            "atk": max(1, int(p.get("atk", 10) * meus_triggers.get("pet_atk_inheritance", 0.5))),
            "def": max(0, int(p.get("def", 0) * 0.5)),
            "spd": max(1, int(p.get("spd", 10) * meus_triggers.get("pet_spd_mult", 1.0))),
            "eva": int(p.get("eva", 0) * 0.5), # Pet tem metade da sua evasão
            "acc": int(p.get("acc", 0)),
            "crit": int(p.get("crit", 0)),
            "bar": 0.0
        }
        # Multiplicadores diretos (ex: Necromante)
        if "pet_atk_mult" in meus_triggers:
            pet["atk"] = int(pet["atk"] * meus_triggers["pet_atk_mult"])
            
        pet["hp"] = pet["hp_max"]
        cmb["pet"] = pet
        logs.append(f"✨ {pet['name']} (HP: {pet['hp']}) assumiu a linha de frente!\n")

    def _enemy_spd(e: dict) -> int:
        return max(1, int(e.get("spd", 1)))

    def _tick_enemy_dots(e: dict) -> tuple[int, str]:
        dots = e.get("dots") or []
        if not dots: return 0, ""

        total = 0
        newdots = []
        atordoou = False
        for d in dots:
            turns = int(d.get("turns", 0))
            if turns <= 0: continue
            dmg = max(0, int(d.get("dmg", 0)))
            total += dmg
            if not atordoou and d.get("stun_chance", 0) > random.randint(1, 100):
                atordoou = True
            turns -= 1
            if turns > 0:
                d["turns"] = turns
                newdots.append(d)

        e["dots"] = newdots if newdots else None
        if atordoou:
            e["stun"] = e.get("stun", 0) + 1
        if total <= 0:
            return 0, (f"🐍 O veneno atordoou {e.get('name', 'Inimigo')}!\n" if atordoou else "")
        msg = f"☠️ -{total}HP veneno/doT em {e.get('name', 'Inimigo')}\n"
        if atordoou:
            msg += f"🐍 O veneno atordoou {e.get('name', 'Inimigo')}!\n"
        return total, msg

    cmb["p_spd"] = max(1, int(p.get("spd", 1)))

    while max_events > 0 and cmb.get("enemies"):

        # =========================================================
        # 1️⃣ TURNO DOS INIMIGOS
        # =========================================================
        inimigos_prontos = [i for i, e in enumerate(cmb["enemies"]) if float(e.get("bar", 0.0)) >= ATB_MAX]

        if inimigos_prontos:
            ei = max(inimigos_prontos, key=lambda k: float(cmb["enemies"][k].get("bar", 0.0)))
            en = cmb["enemies"][ei]

            en.setdefault("cooldowns", {})
            _tick_cooldowns_dict(en["cooldowns"])
            en["bar"] = max(0.0, float(en.get("bar", 0.0)) - ATB_MAX)

            # Regen e DoT
            # 🫁 (28/09) FÔLEGO: cada regeneração vale 10% menos que a anterior
            # na mesma luta. Com a cura fixa, um elite que regenerava quase o
            # que o jogador tirava (e o jogador regenerando também) gerava luta
            # SEM FIM: medido, 5,7% das lutas do 2º andar no nível do andar
            # (Chefe Goblin: -21 por golpe, +18 por turno dele). A regra do dev
            # continua (no máximo 5% da vida por turno): só que o fôlego acaba,
            # e a regeneração inteira de uma luta fica em no máximo 10× a 1ª.
            m_regen = int(en.get("reg", 0))
            if m_regen > 0 and 0 < en.get("hp", 0) < int(en.get("hp_max", 1)):
                usos = int(en.get("regen_usos", 0))
                cura = int(m_regen * (FOLEGO_REGEN ** usos))
                if cura > 0:
                    en["hp"] = min(int(en["hp_max"]), en["hp"] + cura)
                    en["regen_usos"] = usos + 1
                    logs.append(f"👹 +{cura}HP regen {en.get('name')}\n")

            dot_dmg, dot_msg = _tick_enemy_dots(en)
            if dot_msg: logs.append(dot_msg)
            if dot_dmg > 0:
                en["hp"] -= dot_dmg
                if en["hp"] <= 0:
                    logs.extend(_on_enemy_killed(p, ei))
                    cmb = p.get("combat")
                    max_events -= 1
                    if not cmb or not cmb.get("enemies"): break
                    continue

            # Stun
            stun = int(en.get("stun", 0))
            if stun > 0:
                en["stun"] = stun - 1
                logs.append(f"💫 {en.get('name')} está atordoado!\n")
                max_events -= 1
                continue

            # 🎲 O Monstro escolhe o Alvo! (50% de chance de bater no Pet)
            alvo_nome = p.get("username", "Você")
            target_is_pet = False
            
            if cmb.get("pet") and cmb["pet"]["hp"] > 0:
                # 🎯 TAUNT (08/07/2026): as 5 skills de provocação do Guardião
                # não faziam nada no solo. Aqui elas ganham sentido: enquanto
                # a provocação estiver ativa, o inimigo é obrigado a bater em
                # VOCÊ e não no seu pet (que é bem mais frágil).
                if int(p.get("taunt_active", 0)) > 0:
                    target_is_pet = False
                elif random.choice([True, False]):
                    target_is_pet = True
                    alvo_nome = cmb["pet"]["name"]

            # 🔥 (08/07/2026): passa pelo _solo_effective_stat pra respeitar
            # os buffs temporários (buff_def/buff_eva). Antes lia o stat cru,
            # então mesmo se o buff fosse aplicado ele não surtia efeito.
            acc_alvo = cmb["pet"]["eva"] if target_is_pet else _solo_effective_stat(p, "eva", int(p.get("eva", 0)))
            def_alvo = cmb["pet"]["def"] if target_is_pet else _solo_effective_stat(p, "def", int(p.get("def", 0)))
            
            # =========================================================
            # 🔮 IA DO MONSTRO: MAGIA OU ATAQUE BÁSICO? (A partir do 51+)
            # =========================================================
            usou_skill = False
            andar_atual = int(p.get("tower_floor", 1))
            is_boss = (en.get("tipo") == "boss")
            
            # O monstro ganha permissão para usar magia se for Boss OU estiver no andar 51+
            pode_usar_magia = is_boss or (andar_atual >= 51)

            if pode_usar_magia:
                monster_skills = en.get("skills") or en.get("skills_monstro", [])
                
                if not monster_skills:
                    if is_boss: monster_skills = []
                    else: monster_skills = []

                # 30% pro monstro comum do 51+; boss: 10% a 50% conforme o andar
                chance_magia = chance_skill_do_boss(andar_atual) if is_boss else 0.30
                if monster_skills and random.random() < chance_magia:
                    sk_id = random.choice(monster_skills)
                    sk_data = get_skill_by_id(sk_id)
                    
                    if sk_data:
                        sk = sk_data.get("skill", {})
                        logs.append(f"✨ {en.get('name')} conjurou {sk.get('name', 'Magia')}!\n")
                        
                        # 🛡️ 1. O MONSTRO USA SUPORTE (Cura, Escudo, Cleanse, HoT)
                        if sk.get("cleanse"):
                            en["dots"] = []
                            en["stun"] = 0
                            en.setdefault("debuffs", {}).clear()
                            logs.append(f"✨ {en.get('name')} purificou os seus efeitos negativos!\n")

                        heal_pct = float(sk.get("heal_percent", 0))
                        if heal_pct > 0:
                            heal_amt = int(int(en.get("atk", 10)) * heal_pct)
                            en["hp"] = min(int(en.get("hp_max", 100)), int(en.get("hp", 1)) + heal_amt)
                            logs.append(f"💚 {en.get('name')} curou-se em {heal_amt} HP!\n")

                        shield_pct = float(sk.get("shield_pct", 0))
                        if shield_pct > 0:
                            shield_amt = int(int(en.get("atk", 10)) * shield_pct)
                            en["shield"] = en.get("shield", 0) + shield_amt
                            logs.append(f"🛡️ {en.get('name')} criou uma Barreira de {shield_amt} HP!\n")

                        hot_pct = float(sk.get("hot_pct", 0))
                        if hot_pct > 0:
                            hot_amt = int(int(en.get("atk", 10)) * hot_pct)
                            en.setdefault("hots", []).append({"heal": hot_amt, "turns": int(sk.get("hot_turns", 3))})
                            logs.append(f"🌿 {en.get('name')} regenera {hot_amt} HP por turno!\n")

                        # 🐺 2. O MONSTRO FAZ UMA INVOCAÇÃO (Necromante/Feras)
                        if sk.get("summon") and len(cmb["enemies"]) < 5: 
                            pet_mult = float(sk.get("pet_mult", 0.5))
                            new_enemy = {
                                "name": sk.get("summon_name", "Lacaio Sombrio"),
                                "hp_max": max(1, int(en.get("hp_max", 100) * pet_mult)),
                                "hp": max(1, int(en.get("hp_max", 100) * pet_mult)),
                                "atk": max(1, int(en.get("atk", 10) * pet_mult)),
                                "def": max(0, int(en.get("def", 0) * 0.5)),
                                "spd": int(en.get("spd", 10)),
                                "eva": 0, "acc": int(en.get("acc", 10)), "crit": 0,
                                "bar": 0.0,
                                "skills": ["core_fire_1"]
                            }
                            cmb["enemies"].append(new_enemy)
                            logs.append(f"💀 {en.get('name')} invocou um {new_enemy['name']} para a batalha!\n")

                        # ⚔️ 3. O MONSTRO ATACA O JOGADOR (Dano Mágico)
                        mult = float(sk.get("mult", 0))
                        if mult > 0 or sk.get("dmg_percent"):
                            _atk_en = _enemy_effective_atk(en)
                            base_dmg = int(_atk_en * mult) if mult > 0 else int(_atk_en * 1.5)
                            
                            acertou, log_hit, _ = check_hit_and_evasion(int(en.get("acc", 0)), int(acc_alvo), inimigo_triggers, meus_triggers if not target_is_pet else {}, en.get("name"), alvo_nome)
                            if log_hit: logs.append(log_hit)
                            
                            if acertou:
                                dano_final, logs_dano = calc_final_damage(base_dmg, int(def_alvo), int(en.get("crit", 0)), inimigo_triggers, meus_triggers if not target_is_pet else {}, int(cmb["pet"]["hp"] if target_is_pet else p.get("hp", 1)), int(cmb["pet"]["hp_max"] if target_is_pet else p.get("hp_max", 1)), eva_alvo=int(acc_alvo))
                                logs.extend(logs_dano)
                                
                                # 💥 Detonação
                                if sk.get("detonate"):
                                    alvo_dots = cmb["pet"].get("dots", []) if target_is_pet else p.get("dots", [])
                                    if alvo_dots:
                                        extra_dmg = sum(d.get("dmg", 0) * d.get("turns", 1) for d in alvo_dots)
                                        dano_final += extra_dmg
                                        if target_is_pet: cmb["pet"]["dots"] = []
                                        else: p["dots"] = []
                                        logs.append(f"💥 O Monstro DETONOU os teus efeitos! (+{extra_dmg} Dano)!\n")

                                # 🛡️ Bate no Escudo do Alvo!
                                if target_is_pet:
                                    escudo = cmb["pet"].get("shield", 0)
                                    if escudo > 0:
                                        if escudo >= dano_final:
                                            cmb["pet"]["shield"] -= dano_final
                                            logs.append(f"🛡️ O Escudo absorveu todo o dano ({dano_final})!\n")
                                            dano_final = 0
                                        else:
                                            logs.append(f"🛡️ O Escudo do Pet quebrou! (-{escudo})\n")
                                            dano_final -= escudo
                                            cmb["pet"]["shield"] = 0
                                            
                                    cmb["pet"]["hp"] -= dano_final
                                    if dano_final > 0: logs.append(f"💥 -{dano_final}HP no {alvo_nome}!\n")
                                    if cmb["pet"]["hp"] <= 0:
                                        logs.append(f"☠️ O teu {alvo_nome} foi destruído!\n")
                                        del cmb["pet"]
                                else:
                                    escudo = p.get("shield", 0)
                                    if escudo > 0:
                                        if escudo >= dano_final:
                                            p["shield"] -= dano_final
                                            logs.append(f"🛡️ O teu Escudo absorveu todo o dano ({dano_final})!\n")
                                            dano_final = 0
                                        else:
                                            logs.append(f"🛡️ O teu Escudo quebrou! (-{escudo})\n")
                                            dano_final -= escudo
                                            p["shield"] = 0
                                            # 🔥 Baluarte: chance do escudo se regenerar na hora
                                            if meus_triggers.get("shield_refresh_chance", 0) > random.randint(1, 100):
                                                novo_escudo = max(1, int(escudo * 0.5))
                                                p["shield"] = novo_escudo
                                                logs.append(f"🔄 O Escudo se regenerou instantaneamente! (+{novo_escudo})\n")
                                            
                                    p["hp"] -= dano_final
                                    if dano_final > 0: logs.append(f"💥 -{dano_final}HP em {alvo_nome}!\n")
                                    
                                # 🦇 Vampirismo do Monstro
                                lifesteal = float(sk.get("lifesteal_pct", 0))
                                if lifesteal > 0 and dano_final > 0:
                                    heal_vamp = int(dano_final * lifesteal)
                                    en["hp"] = min(int(en.get("hp_max", 100)), int(en.get("hp", 1)) + heal_vamp)
                                    logs.append(f"🦇 {en.get('name')} sugou {heal_vamp} da tua força vital!\n")

                                # ☠️ Aplica DoTs, Stun e Silêncio do monstro no Jogador
                                if not target_is_pet:
                                    dot_mult = float(sk.get("dot_mult", 0))
                                    if dot_mult > 0:
                                        dmg_dot = max(1, int(int(en.get("atk", 1)) * dot_mult))
                                        p.setdefault("dots", []).append({"name": sk.get("dot_name", "Maldição"), "dmg": dmg_dot, "turns": int(sk.get("dot_turns", 3))})
                                        logs.append(f"🧪 Foste infetado por {sk.get('dot_name', 'Maldição')}!\n")
                                    
                                    stun_turns = int(sk.get("stun", 0))
                                    if stun_turns > 0:
                                        # 🔥 TRAVA GLOBAL DE 35% DE CHANCE (Inimigo vs Jogador)
                                        if random.randint(1, 100) <= 35:
                                            p["stun"] = p.get("stun", 0) + stun_turns
                                            logs.append(f"💫 Foste atordoado por {stun_turns} turno(s)!\n")
                                        else:
                                            logs.append(f"🛡️ Resististe bravamente ao atordoamento!\n")

                                    silence_turns = int(sk.get("silence_turns", 0))
                                    if silence_turns > 0:
                                        p.setdefault("debuffs", {})["silence"] = silence_turns
                                        logs.append(f"🤫 Foste silenciado por {silence_turns} turno(s)!\n")

                        usou_skill = True

            # =========================================================
            # ⚔️ ATAQUE BÁSICO DO MONSTRO (Se não usou skill)
            # =========================================================
            if not usou_skill:
                # Motor de Esquiva
                acertou, log_hit, _ = check_hit_and_evasion(
                    int(en.get("acc", 0)), int(acc_alvo), 
                    inimigo_triggers, meus_triggers if not target_is_pet else {}, 
                    en.get("name", "Inimigo"), alvo_nome
                )
                
                if log_hit: logs.append(log_hit)

                if acertou:
                    edmg_bruto = int(en.get("atk", 1)) - int(def_alvo)
                    
                    # A Mecânica Nativa de Contragolpe quando a Defesa é Maior que o Ataque
                    if edmg_bruto <= 0:
                        contra = max(1, 1 + int(abs(edmg_bruto)))
                        en["hp"] -= contra
                        logs.append(f"👹 -{contra}HP {en.get('name')} tomou contragolpe de {alvo_nome}!\n")
                        if en["hp"] <= 0:
                            if meus_triggers.get("soul_harvest"):
                                p["almas"] = p.get("almas", 0) + 1
                                logs.append("👻 Alma ceifada pelo Contragolpe!\n")
                            logs.extend(_on_enemy_killed(p, ei))
                            cmb = p.get("combat")
                            max_events -= 1
                            if not cmb or not cmb.get("enemies"): break
                            continue
                    else:
                        # Motor de Dano
                        dano_final, logs_dano = calc_final_damage(
                            _enemy_effective_atk(en), int(def_alvo), int(en.get("crit", 0)), 
                            inimigo_triggers, meus_triggers if not target_is_pet else {}, 
                            int(cmb["pet"]["hp"] if target_is_pet else p.get("hp", 1)),
                            int(cmb["pet"]["hp_max"] if target_is_pet else p.get("hp_max", 1)),
                            eva_alvo=int(acc_alvo)
                        )
                        logs.extend(logs_dano)
                        
                        if target_is_pet:
                            # 🛡️ Aplicar Escudo no Pet
                            escudo_pet = cmb["pet"].get("shield", 0)
                            if escudo_pet > 0:
                                if escudo_pet >= dano_final:
                                    cmb["pet"]["shield"] -= dano_final
                                    logs.append(f"🛡️ O Escudo absorveu {dano_final} de dano!\n")
                                    dano_final = 0
                                else:
                                    logs.append(f"🛡️ O Escudo foi quebrado! (-{escudo_pet})\n")
                                    dano_final -= escudo_pet
                                    cmb["pet"]["shield"] = 0
                                    
                            cmb["pet"]["hp"] -= dano_final
                            if dano_final > 0:
                                logs.append(f"🐺 -{dano_final}HP no {alvo_nome}!\n")
                            if cmb["pet"]["hp"] <= 0:
                                logs.append(f"☠️ Seu {alvo_nome} foi esmagado!\n")
                                del cmb["pet"]
                        else:
                            # 🛡️ Aplicar Escudo no JOGADOR
                            escudo_jogador = p.get("shield", 0)
                            if escudo_jogador > 0:
                                if escudo_jogador >= dano_final:
                                    p["shield"] -= dano_final
                                    logs.append(f"🛡️ Seu Escudo absorveu {dano_final} de dano!\n")
                                    dano_final = 0
                                else:
                                    logs.append(f"🛡️ Seu Escudo foi quebrado! (-{escudo_jogador})\n")
                                    dano_final -= escudo_jogador
                                    p["shield"] = 0

                            p["hp"] -= dano_final
                            if dano_final > 0:
                                logs.append(f"👤 -{dano_final}HP em {alvo_nome}!\n")

                            # 🪨 CONTRA-STUN (08/07/2026): se o jogador estiver
                            # com o buff do Guardião ativo, quem bateu nele tem
                            # chance de ficar atordoado.
                            _cs = p.get("stun_on_hit") or {}
                            if dano_final > 0 and int(_cs.get("turns", 0)) > 0:
                                if random.randint(1, 100) <= float(_cs.get("chance", 0)):
                                    en["stun"] = int(en.get("stun", 0)) + 1
                                    logs.append(f"🪨 {en.get('name')} se estatelou na sua pele de pedra e ficou atordoado!\n")
                            
                            # Espinhos e Rebotes do Player contra o Inimigo!
                            rebote, logs_rebote, _ = calc_thorns_and_counters(dano_final, meus_triggers, int(p.get("def", 0)), int(en.get("atk", 1)))
                            if rebote > 0:
                                en["hp"] -= rebote
                                logs.extend(logs_rebote)
                                if en["hp"] <= 0:
                                    if meus_triggers.get("soul_harvest"):
                                        p["almas"] = p.get("almas", 0) + 1
                                        logs.append("👻 Alma ceifada pelo Rebote!\n")
                                    logs.extend(_on_enemy_killed(p, ei))
                                    cmb = p.get("combat")
                                    max_events -= 1
                                    if not cmb or not cmb.get("enemies"): break
                                    continue
                                    
            # Verifica morte do player (Com a chance de Milagre da classe!)
            if p.get("hp", 0) <= 0:
                success, msg = on_player_death(p)
                logs.append(msg)
                if success:
                    p["state"] = "DEAD"
                    return logs
                    
            max_events -= 1
            continue


        # =========================================================
        # 1.5️⃣ TURNO DO PET (IA DE ATAQUE)
        # =========================================================
        if cmb.get("pet") and float(cmb["pet"].get("bar", 0.0)) >= ATB_MAX:
            pet = cmb["pet"]
            pet["bar"] = max(0.0, float(pet.get("bar", 0.0)) - ATB_MAX)
            
            # Escolhe um inimigo aleatório
            ei = random.randint(0, len(cmb["enemies"]) - 1)
            en = cmb["enemies"][ei]
            
            acertou, log_hit, _ = check_hit_and_evasion(
                int(pet["acc"]), int(en.get("eva", 0)), 
                meus_triggers, inimigo_triggers, 
                pet["name"], en.get("name", "Inimigo")
            )
            if log_hit: logs.append(log_hit)
            
            if acertou:
                dano_final, logs_dano = calc_final_damage(
                    int(pet["atk"]), int(en.get("def", 0)), int(pet["crit"]), 
                    meus_triggers, inimigo_triggers, 
                    int(en.get("hp", 1)), int(en.get("hp_max", 1))
                )
                logs.extend(logs_dano)
                en["hp"] -= dano_final
                logs.append(f"🐾 {pet['name']} atacou! -{dano_final}HP em {en.get('name')}!\n")
                
                # Pet Bate Duas Vezes? (Mestre de Feras)
                if meus_triggers.get("pet_double_attack_chance", 0) > random.randint(1, 100):
                    dano_final2, logs_dano2 = calc_final_damage(
                        int(pet["atk"]), int(en.get("def", 0)), int(pet["crit"]), 
                        meus_triggers, inimigo_triggers, 
                        int(en.get("hp", 1)), int(en.get("hp_max", 1))
                    )
                    logs.extend(logs_dano2)
                    en["hp"] -= dano_final2
                    logs.append(f"🐾 FÚRIA ANIMAL! {pet['name']} atacou novamente! -{dano_final2}HP!\n")
                    
                # Pet Cura ao Bater? (Espiritualista)
                if meus_triggers.get("attack_heals_pets_chance", 0) > random.randint(1, 100):
                    cura = max(1, int(dano_final * 0.5))
                    pet["hp"] = min(int(pet.get("hp_max", 1)), pet["hp"] + cura)
                    logs.append(f"💚 {pet['name']} se curou em {cura} HP drenando o alvo!\n")
            
            # Matou o Monstro?
            if en["hp"] <= 0:
                if meus_triggers.get("soul_harvest"):
                    p["almas"] = p.get("almas", 0) + 1
                    logs.append("👻 Alma ceifada pelo Pet!\n")
                logs.extend(_on_enemy_killed(p, ei))
                cmb = p.get("combat")
                
            max_events -= 1
            if not cmb or not cmb.get("enemies"):
                break
            continue

        # =========================================================
        # 2️⃣ TURNO DO JOGADOR
        # =========================================================
        if float(cmb.get("p_bar", 0.0)) >= ATB_MAX:
            if not cmb.get("p_turno_iniciado", False):
                
                # 🌿 Processar Regeneração (HoT) do Jogador
                alive_hots = []
                for hot in p.get("hots", []):
                    cura = hot.get("heal", 0)
                    p["hp"] = min(int(p.get("hp_max", 100)), int(p.get("hp", 0)) + cura)
                    logs.append(f"🌿 Regeneração: +{cura} HP.\n")
                    hot["turns"] -= 1
                    if hot["turns"] > 0:
                        alive_hots.append(hot)
                p["hots"] = alive_hots

                # ☠️ Processar Veneno/Queimadura (DoT) no Jogador
                alive_dots = []
                for dot in p.get("dots", []):
                    dmg_veneno = dot.get("dmg", 0)
                    p["hp"] = max(0, int(p.get("hp", 0)) - dmg_veneno)
                    logs.append(f"☠️ Você sofreu {dmg_veneno} de dano ({dot.get('name', 'Efeito')})!\n")
                    dot["turns"] -= 1
                    if dot["turns"] > 0:
                        alive_dots.append(dot)
                p["dots"] = alive_dots

                # 🪨 Tick do contra-stun (08/07/2026) — some quando acaba
                _cs = p.get("stun_on_hit")
                if _cs:
                    _cs["turns"] = int(_cs.get("turns", 0)) - 1
                    if _cs["turns"] <= 0:
                        p.pop("stun_on_hit", None)
                        logs.append("🪨 Sua pele de pedra amoleceu.\n")

                # 💪 Tick dos buffs de atk/def/eva (08/07/2026)
                logs.extend(_solo_tick_buffs(p))

                # 🎯 Tick da provocação (08/07/2026)
                if int(p.get("taunt_active", 0)) > 0:
                    p["taunt_active"] = int(p["taunt_active"]) - 1

                # Verifica morte por DoT
                if p.get("hp", 0) <= 0:
                    success, msg = on_player_death(p)
                    logs.append(msg)
                    if success:
                        p["state"] = "DEAD"
                        return logs
                      
                # Regen natural (já existente)
                regen_amount = int(p.get("reg", 0))
                if regen_amount > 0 and 0 < p.get("hp", 0) < int(p.get("hp_max", 1)):
                    p["hp"] = min(int(p["hp_max"]), p["hp"] + regen_amount)

                # =========================================================
                # 🐉 A MÁGICA: O ESQUADRÃO ESPIRITUAL AGE AQUI!
                # =========================================================
                log_pets, inimigo_morto_idx = process_pets_start_of_turn(p, cmb)
                if log_pets:
                    logs.extend(log_pets)
                    
                if inimigo_morto_idx != -1:
                    # Se o pet matou, chamamos a função que você já tem para ceifar almas/dar loot
                    logs.extend(_on_enemy_killed(p, inimigo_morto_idx))
                    if not cmb.get("enemies"):
                        break # Se não sobrar inimigos, acaba a batalha antes de você agir!

                # =========================================================
                # ✨ ITENS MÍTICOS: a skill embutida no equipamento age aqui,
                # igual ao esquadrão de pets acima (mesmo motor, adaptado).
                # =========================================================
                log_mitico, inimigo_morto_mitico = process_mythic_items_start_of_turn(p, cmb)
                if log_mitico:
                    logs.extend(log_mitico)

                if inimigo_morto_mitico != -1:
                    logs.extend(_on_enemy_killed(p, inimigo_morto_mitico))
                    if not cmb.get("enemies"):
                        break

                cmb["p_turno_iniciado"] = True
            break
        # =========================================================
        # 3️⃣ AVANÇA O TEMPO (MOTOR DE VELOCIDADE)
        # =========================================================
        fighters = [("player", float(cmb.get("p_bar", 0.0)), cmb["p_spd"])]
        
        # O Pet entra na corrida de ATB!
        if cmb.get("pet"):
            fighters.append(("pet", float(cmb["pet"].get("bar", 0.0)), cmb["pet"]["spd"]))

        for i, e in enumerate(cmb["enemies"]):
            fighters.append((i, float(e.get("bar", 0.0)), _enemy_spd(e)))

        remaining = [(ATB_MAX - bar) / spd for _, bar, spd in fighters if bar < ATB_MAX]
        if not remaining: break

        dt = min(remaining)

        cmb["p_bar"] = min(ATB_MAX, round(float(cmb.get("p_bar", 0.0)) + cmb["p_spd"] * dt, 2))
        
        if cmb.get("pet"):
            cmb["pet"]["bar"] = min(ATB_MAX, round(float(cmb["pet"].get("bar", 0.0)) + cmb["pet"]["spd"] * dt, 2))

        for e in cmb["enemies"]:
            e["bar"] = min(ATB_MAX, round(float(e.get("bar", 0.0)) + _enemy_spd(e) * dt, 2))

    return logs



def continue_from_save(p: dict) -> tuple[bool, str]:
    # ✅ Player ID direto do player (já garantido no router!)
    player_id = p.get("player_id") or str(p.get("user_id", "0"))
    
    custo = 50
    
    # 🔍 Pega saldo ATUALIZADO do banco
    saldo_atual = premium_repo.get_premium(player_id) or 0
    
    if saldo_atual < custo:
        return False, f"💎 Saldo: {saldo_atual}. Precisa {custo}⭐."
    
    # 💎 GASTA NO BANCO (premium_repo SALVA!)
    ok, new_balance = premium_repo.spend_premium(player_id, custo, "Reviver")
    
    if not ok:
        return False, "❌ Erro no pagamento premium."
    
    # 💎 Cache atualizado
    p["premium"] = int(new_balance)
    
    # Revive!
    p["combat"] = None
    p["state"] = "CITY"
    p["hp"] = int(int(p.get("hp_max", 100)) * 0.5)
    p["tower_floor"] = max(1, int(p.get("tower_floor", 1)) - 1)
    
    return True, f"✅ Revivido! -{custo}⭐ (saldo: {p['premium']}⭐\n)"
# 🔥 REMOVIDO (08/07/2026): esta era uma cópia de process_passive_xp que
# nunca era chamada de lugar nenhum — a versão realmente usada é a que está
# dentro de claim_all_rewards, mais abaixo. Deixar as duas vivas só
# confundia (ambas mexiam no mesmo "last_xp_tick").

REGEN_TETO_PCT = 0.05          # regeneração do monstro: no máximo 5% da vida/turno
FOLEGO_REGEN = 0.90            # 🫁 cada regeneração na mesma luta vale 10% menos


def raridade_do_boss(andar: int) -> int:
    """1 (comum) até o andar 20, 2 até o 40, 3 até o 60, 4 até o 80, 5 depois."""
    return max(1, min(5, (max(1, int(andar)) - 1) // 20 + 1))


def skills_do_boss_no_andar(andar: int) -> list:
    from game.monsters import ACTIVES_BY_RARITY
    return list(ACTIVES_BY_RARITY.get(raridade_do_boss(andar)) or [])


def chance_skill_do_boss(andar: int) -> float:
    """10% no andar 1 até 50% no andar 100 (e fica em 50% depois)."""
    a = max(1, min(100, int(andar)))
    return 0.10 + 0.40 * (a - 1) / 99


# 👑 (28/09, dev) CHEFE DA FAIXA DO NOVATO — "destravar o 5º andar".
# O chefe levava ×1,5 nos atributos E ×2,5 em TODO status, velocidade
# inclusive. No 5º andar isso dava o Rei Goblin com VEL 109 contra 33 do
# jogador (3 turnos pra cada 1 dele) e regeneração igual ao dano do jogador:
# medido com o jogador NO PONTO (nível máximo do 4º andar, pontos gastos, as
# 4 peças do guia), 0 vitórias em 20 — em qualquer divisão de pontos (só
# ataque, só vida, só velocidade, equilibrado). O 10º andar, igual.
# Nos andares do novato (até ANDAR_DO_NOVATO) o chefe passa a ser:
#   atributos ×1,25 · vida ×2 · ataque/defesa ×1,2 · velocidade sem bônus
# (o multiplicador do andar continua valendo em tudo, e a regeneração segue
# a regra do dev: no máximo 5% da vida por turno). Medido na mesma bancada:
# o jogador no ponto vence, em lutas de 20 a 35 toques; quem chega fraco
# (sem gastar pontos, ou antes do nível) perde — o chefe continua sendo a
# prova do andar. Do 15º em diante NÃO mexi: ali quem pesa é o equipamento
# que o jogador já forjou, e não tenho como medir isso daqui.
# Só a Torre passa por aqui: Raid, Ondas e a travessia do clã chamam o
# gerador direto e ficam como estavam.
# 🫁 (28/09) recalibrado com o fôlego da regeneração (FOLEGO_REGEN): sem a
# regeneração empatando a luta, ofensa ×1,2 deixava o chefe fácil demais (2
# níveis abaixo do ponto vencia 95–100%). Com ×1,4, medido sem equipamento:
# no ponto vence 100% (~24 toques no 5º, ~18 no 10º); 2 níveis abaixo, 0% no
# 5º e 83% no 10º; sem gastar os pontos, 0%.
CHEFE_NOVATO = {"atributos": 1.25, "vida": 2.0, "ofensa": 1.4, "velocidade": 1.0}


def _chefe_do_novato(mon: dict, andar: int) -> dict:
    from game.monsters import aplicar_atributos, criar_status_inicial, mult_por_andar
    c = CHEFE_NOVATO
    attrs = {k: max(1, int(round((1 + int(andar)) * c["atributos"]))) for k in ("str", "vit", "agi", "dex")}
    st = aplicar_atributos(criar_status_inicial(), attrs)
    ma = mult_por_andar(andar)
    novo = {
        "hp_max": max(60, int(round(st["hp_max"] * c["vida"] * ma))),
        "reg": int(round(st["reg"] * c["vida"] * ma)),
        "atk": max(1, int(round(st["atk"] * c["ofensa"] * ma))),
        "def": max(0, int(round(st["def"] * c["ofensa"] * ma))),
        "spd": int(round(st["spd"] * c["velocidade"] * ma)),
    }
    for k in ("crit", "acc", "eva"):
        novo[k] = int(round(st[k] * ma))
    mon = dict(mon)
    mon["atributos"] = attrs
    mon["status"] = novo
    mon["hp_max"] = mon["hp"] = novo["hp_max"]
    return mon


# 🗡️ (28/09) CAPANGAS DO CHEFE. Com o portal preso ao chefe, o andar de
# chefe do novato virou beco: ele só tinha o chefe, e quem subiu rápido
# (nível baixo) não tinha onde ganhar XP — não dá pra descer. Medido: os 3
# jogadores "apressados" da simulação ficaram presos no 5º andar pra sempre.
# Agora, enquanto o chefe não cai, metade das lutas é com os capangas dele
# (monstros do andar de baixo); dá pra subir de nível ali e voltar ao chefe.
CHANCE_CAPANGAS = 0.5


def _luta_de_capangas(p: dict, floor: int) -> bool:
    return (floor % 5 == 0 and floor <= ANDAR_DO_NOVATO
            and not (p.get("explore_mode") or p.get("wave_mode"))
            and floor not in (p.get("chefes_vencidos") or [])
            and random.random() < CHANCE_CAPANGAS)


def start_combat(p: dict):
    floor = int(p["tower_floor"])
    bosses = get_bosses_no_andar(floor)
    enemies = []
    capangas = bosses > 0 and _luta_de_capangas(p, floor)
    if capangas:
        bosses = 0
    if bosses > 0:
        for i in range(bosses):
            mon = criar_monstro_por_andar(floor)
            if floor <= ANDAR_DO_NOVATO:
                mon = _chefe_do_novato(mon, floor)
            mon["tipo"] = "boss"
            # 🎯 skills do boss pela FAIXA do andar (25/09, dev): até o 20 só
            # comum, até o 40 incomum, ... do 81 ao 100 só lendária.
            mon["skills"] = skills_do_boss_no_andar(floor)
            st = mon.get("status", {})
            mhp_max = int(mon.get("hp_max", 60))
            mhp = int(mon.get("hp", mhp_max))
            enemies.append({
                "name": f"{mon.get('nome', 'BOSS')} #{i+1}" if bosses > 1 else mon.get("nome", "BOSS"),
                "tipo": "boss",
                "tier": int(mon.get("tier", get_tier(floor))),
                "hp": mhp,
                "hp_max": mhp_max,
                "atk": int(st.get("atk", 1)),
                "def": int(st.get("def", 0)),
                "spd": int(st.get("spd", 20)),
                # 🐛 25/09/2026: o gerador cria crit/precisão/esquiva e as
                # skills, mas o combate só copiava HP/ATK/DEF/VEL — o seu
                # acerto era sempre 95% (precisão não servia pra nada na
                # Torre) e boss nenhum conjurava (a IA lê en["skills"]).
                # A regeneração NÃO vem: é por turno e fixa (andar 100 =
                # +4.195/turno, ~10% da vida) — com dano = ATK − DEF ela
                # deixaria monstro impossível de matar.
                # mesma conta do JOGADOR (destreza×2 / agilidade×2), sem o
                # multiplicador do andar: medido, com o `status` cru o acerto
                # do jogador no andar 50 caía pra 5% e o monstro critava 100%.
                "crit": int((mon.get("atributos") or {}).get("dex", 1)) * 2,
                "acc": int((mon.get("atributos") or {}).get("dex", 1)) * 2,
                "eva": int((mon.get("atributos") or {}).get("agi", 1)) * 2,
                "skills": list(mon.get("skills") or []),
                # 💚 regeneração ligada (25/09, dev), com teto de 5% da vida
                # por turno: a crua passava de 9% no andar 100.
                # 💚 boss também regenera, no máximo 5%/turno (regra do dev).
                # ⚠️ medido 25/09: luta de boss dura ~120 rodadas; com regen
                # um jogador que vencia 30/30 no andar 25 passou a vencer 2/30.
                "reg": min(int(st.get("reg", 0)), int(mhp_max * REGEN_TETO_PCT)),
                "floor": int(mon.get("lvl", floor)),
                "berserk": False,
                "cores_drop": mon.get("cores_drop", []),
                "bar": 0.0,
                "cooldowns": {},
            })
    else:
        andar_mob = floor - 1 if capangas else floor
        n = qtd_monstros_por_andar(andar_mob)
        for _ in range(n):
            mon = criar_monstro_por_andar(andar_mob)
            st = mon.get("status", {})
            mhp_max = int(mon.get("hp_max", 60))
            mhp = int(mon.get("hp", mhp_max))
            enemies.append({
                "raca_nome": mon.get("raca_nome", ""),
                "especialidade_desc": mon.get("especialidade_desc", ""),
                "lvl": int(mon.get("lvl", floor)),
                "name": mon.get("nome", "MONSTRO"),
                "tipo": mon.get("tipo", "normal"),
                "tier": int(mon.get("tier", get_tier(floor))),
                "arquetipo": mon.get("arquetipo", "tanker"),
                "hp": mhp,
                "hp_max": mhp_max,
                "atk": int(st.get("atk", 1)),
                "def": int(st.get("def", 0)),
                "spd": int(st.get("spd", 20)),
                # 🐛 25/09/2026: o gerador cria crit/precisão/esquiva e as
                # skills, mas o combate só copiava HP/ATK/DEF/VEL — o seu
                # acerto era sempre 95% (precisão não servia pra nada na
                # Torre) e boss nenhum conjurava (a IA lê en["skills"]).
                # A regeneração NÃO vem: é por turno e fixa (andar 100 =
                # +4.195/turno, ~10% da vida) — com dano = ATK − DEF ela
                # deixaria monstro impossível de matar.
                # mesma conta do JOGADOR (destreza×2 / agilidade×2), sem o
                # multiplicador do andar: medido, com o `status` cru o acerto
                # do jogador no andar 50 caía pra 5% e o monstro critava 100%.
                "crit": int((mon.get("atributos") or {}).get("dex", 1)) * 2,
                "acc": int((mon.get("atributos") or {}).get("dex", 1)) * 2,
                "eva": int((mon.get("atributos") or {}).get("agi", 1)) * 2,
                "skills": list(mon.get("skills") or []),
                # 💚 regeneração ligada (25/09, dev), com teto de 5% da vida
                # por turno: a crua passava de 9% no andar 100.
                "reg": min(int(st.get("reg", 0)), int(mhp_max * REGEN_TETO_PCT)),
                "floor": int(mon.get("lvl", floor)),
                "berserk": False,
                "cores_drop": mon.get("cores_drop", []),
                "bar": 0.0,
                "cooldowns": {},
            })

    p["combat"] = {"p_bar": 0.0, "p_spd": int(p["spd"]), "enemies": enemies, "target": 0, "p_cooldowns": {}}
    p["state"] = "COMBAT"
    


def combat_target_shift(p: dict, delta: int) -> str:
    cmb = p.get("combat")
    if not cmb or not cmb.get("enemies"): 
        return "Sem inimigos."
    t = int(cmb.get("target", 0)) + int(delta)
    t = max(0, min(t, len(cmb["enemies"]) - 1))
    cmb["target"] = t
    uid = p.get("user_id") or p.get("telegram_id")
    if uid:
        save_player_sql(int(uid), p)  # ← persiste no DB (corrigido: usava chat_id por engano)
    e = cmb["enemies"][t]
    return f"🎯 Alvo: {t+1}/{len(cmb['enemies'])} ({e.get('name','Inimigo')}).\n"

LIMIAR_FURIA_MITICA = 0.50     # mesma vida-limite da especialidade Fúria Descontrolada
ESPINHOS_DA_DAMA_DE_FERRO = 0.20   # rebote base dos míticos da Dama de Ferro


def get_combat_triggers(p: dict) -> dict:
    """Lê todas as especialidades equipadas e junta os Triggers para o combate."""
    from game.specialties import SPECIALTIES_DB
    triggers = {}
    
    # 🔥 A MÁGICA DA OTIMIZAÇÃO: Usa o conversor para garantir que a String do BD vire Lista!
    specs = get_specialty_slots(p) 
    
    for s in specs:
        if s and s in SPECIALTIES_DB:
            for k, v in SPECIALTIES_DB[s].get("triggers", {}).items():
                # Se for booleano, fica True. Se for número (percentagem), soma para fazer combos!
                if isinstance(v, bool):
                    triggers[k] = v
                else:
                    triggers[k] = triggers.get(k, 0) + v

    # 🔥 CHAKRA: gatilhos de combate (ex: Defesa Absoluta)
    chakra = p.get("chakra")
    if chakra and chakra.get("kind") == "trigger" and chakra.get("trigger"):
        tk = chakra["trigger"]
        val = chakra.get("value", 0)
        if isinstance(triggers.get(tk), bool) or isinstance(val, bool):
            triggers[tk] = True
        else:
            triggers[tk] = triggers.get(tk, 0) + val

    # 🔥 PETS: lifesteal se junta ao mesmo trigger usado pelas especialidades,
    # e cooldown_red fica disponível pra quem consome ("pet_cooldown_red_pct")
    from game.pets_db import get_pet_bonuses
    pet_bonuses = get_pet_bonuses(p)
    if pet_bonuses.get("lifesteal"):
        triggers["lifesteal_pct"] = triggers.get("lifesteal_pct", 0) + pet_bonuses["lifesteal"]
    if pet_bonuses.get("cooldown_red"):
        triggers["pet_cooldown_red_pct"] = pet_bonuses["cooldown_red"]

    # ✨ ITENS MÍTICOS: o "atributo legal" do item — um gatilho de combate de
    # verdade (não só um bônus de status), igual especialidade/chakra dão.
    # 🐛 (28/09) Dois gatilhos são MULTIPLICADORES (a especialidade dá 2.0 =
    # dobro), mas o mítico guarda o BÔNUS (0.50 = +50%). Somados a partir de
    # zero, o "Cinturão do Avatar" deixava a cura em ×0,5 (cortava pela
    # metade) e a "Fúria Titânica" em ×1,0/×0,9 (nada, ou menos dano). Agora
    # partem de ×1. E a fúria só liga abaixo de um limiar de vida que só a
    # especialidade dava — sem ela, o mítico vale o mesmo limiar (50%). Por
    # isso este bloco veio pra ANTES da conta da fúria.
    MULTIPLICADORES = ("heal_mult", "berserk_dmg_mult")
    equip = p.get("equip", {}) or {}
    for item in equip.values():
        if isinstance(item, dict) and item.get("rar") == "mythic":
            trig = item.get("mythic_trigger")
            if isinstance(trig, dict) and trig.get("key"):
                chave = trig["key"]
                valor = float(trig.get("value", 0))
                if isinstance(triggers.get(chave), bool):
                    triggers[chave] = True
                elif chave in MULTIPLICADORES:
                    triggers[chave] = triggers.get(chave, 1.0) + valor
                else:
                    triggers[chave] = triggers.get(chave, 0) + valor
    if triggers.get("berserk_dmg_mult") and not triggers.get("berserk_threshold_pct"):
        triggers["berserk_threshold_pct"] = LIMIAR_FURIA_MITICA
    # 🐛 (28/09) A Dama de Ferro (armadura e broquel) tinha "chance de DOBRAR
    # o rebote de espinhos" — mas nada no jogo dava o rebote base
    # (thorns_pct), então o gatilho nunca disparava. Ela passa a devolver
    # 20% do dano recebido, e a chance dela dobra isso.
    if triggers.get("reflect_double_chance") and not triggers.get("thorns_pct"):
        triggers["thorns_pct"] = ESPINHOS_DA_DAMA_DE_FERRO

    # 🔥 CORRIGIDO (06/07/2026): "Fúria Descontrolada" (spec_furia) era só decoração —
    # o gatilho berserk_threshold_pct/berserk_dmg_mult existia na especialidade mas
    # nunca era checado em lugar nenhum. Agora, se o HP atual estiver abaixo do
    # limiar, o multiplicador de dano entra em jogo (consumido em calc_final_damage).
    threshold = triggers.get("berserk_threshold_pct", 0)
    mult = triggers.get("berserk_dmg_mult", 0)
    if threshold and mult:
        hp_atual = int(p.get("hp", 0))
        hp_max = max(1, int(p.get("hp_max", 1)))
        if (hp_atual / hp_max) <= threshold:
            triggers["dmg_mult_active"] = mult

    # 🔥 (09/07/2026): o sistema de afixos das skills virou bônus flat de
    # atributo (aplicado em apply_skill_affix_bonuses, dentro do recalc).
    # Não há mais afixo "rare" gerando gatilho de combate aqui.


    return triggers


import random

def check_hit_and_evasion(acc: int, eva: int, atk_triggers: dict, def_triggers: dict, attacker_name: str, defender_name: str) -> tuple[bool, str, dict]:
    """Retorna: (Acertou?, Log, Dicionário de Efeitos Secundários)"""
    updates = {}

    # 🌟 Afixo Raro (Esquiva Perfeita): ignora completamente o cálculo de
    # acerto e garante que o defensor esquiva, não importa a precisão.
    if def_triggers.get("perfect_dodge_chance", 0) > random.randint(1, 100):
        log_msg = f"✨ {defender_name} executou uma ESQUIVA PERFEITA!\n"
        if "dodge_atk_buff_pct" in def_triggers:
            updates["add_atk_buff"] = def_triggers["dodge_atk_buff_pct"]
            log_msg += "   (Ganhou Ímpeto de Ataque!)\n"
        return False, log_msg, updates

    # 🏹 Arqueiro (Caçador/Atirador): Ignorar Evasão
    if atk_triggers.get("ignore_evasion_chance", 0) > random.randint(1, 100):
        return True, f"🎯 {attacker_name} ignorou a evasão de {defender_name}!\n", updates
        
    chance = max(5, min(95, 100 + acc - eva))
    if random.randint(1, 100) > chance:
        log_msg = f"💨 {defender_name} esquivou com precisão!\n"
        
        # 🗡️ Assassino (Sombras): Ganha buff de ataque após esquivar
        if "dodge_atk_buff_pct" in def_triggers:
            updates["add_atk_buff"] = def_triggers["dodge_atk_buff_pct"]
            log_msg += "   (Ganhou Ímpeto de Ataque!)\n"
            
        return False, log_msg, updates
        
    return True, "", updates

# 🎯 CRÍTICO (25/09/2026, regra do dev): como acerto × esquiva, é "um menos
# o outro" — chance = crítico do atacante − esquiva do defensor (0 a 100%).
# O que passar de 100 vira DANO crítico: +10% de dano crítico a cada 100
# pontos de sobra, até +150% (×3,0 no total). Crit e esquiva vêm da mesma
# conta nos dois lados (destreza×2 e agilidade×2), então a escala se
# equilibra sozinha. `eva_alvo` = 0 mantém o crítico antigo (Arena/Raid/pet).
CRIT_SOBRA_POR_PASSO = 100
CRIT_BONUS_POR_PASSO = 0.10
CRIT_BONUS_TETO = 1.5


def chance_e_bonus_de_critico(crit: int, eva_alvo: int = 0) -> tuple[int, float]:
    efetivo = int(crit) - int(eva_alvo or 0)
    chance = max(0, min(100, efetivo))
    sobra = max(0, efetivo - 100)
    bonus = min(CRIT_BONUS_TETO, (sobra / CRIT_SOBRA_POR_PASSO) * CRIT_BONUS_POR_PASSO)
    return chance, bonus


def multiplicador_de_critico(crit: int, eva_alvo: int = 0) -> float:
    """0 = não critou; senão o multiplicador (1,5 + sobra). Pros lugares que
    sorteiam crítico por fora do calc_final_damage (ataques do boss da Raid)."""
    chance, bonus = chance_e_bonus_de_critico(crit, eva_alvo)
    if chance > 0 and random.randint(1, 100) <= chance:
        return 1.5 + bonus
    return 0.0


def calc_final_damage(base_atk: int, target_def: int, crit: int, atk_triggers: dict, def_triggers: dict, target_hp: int, target_max_hp: int, eva_alvo: int = 0) -> tuple[int, list[str]]:
    """Aplica toda a matemática de redução e amplificação de dano."""
    logs = []
    
    # 🛡️ Tanker/Suporte: Ignorar Dano Absoluto
    if def_triggers.get("ignore_damage_chance", 0) > random.randint(1, 100):
        logs.append("🛡️ Imaculado! O alvo ignorou 100% do dano!\n")
        return 0, logs
        
    # 🗡️ Assassino Fatal: Execução (Insta-kill)
    execute_pct = atk_triggers.get("execute_threshold_pct", 0)
    if execute_pct > 0 and target_hp > 0 and (target_hp / max(1, target_max_hp)) <= execute_pct:
        logs.append("☠️ EXECUÇÃO FATAL! O alvo foi obliterado.\n")
        return target_hp, logs # Retorna o HP total restante como dano
        
    # 🏹 Caçador: Ignorar Defesa Totalmente
    if atk_triggers.get("ignore_def_chance", 0) > random.randint(1, 100):
        target_def = 0
        logs.append("💔 Defesa totalmente perfurada!\n")
        
    dano_bruto = max(1, base_atk - target_def)
    dano_final = max(1, dano_bruto + random.randint(-1, 2))
    
    # 🔥 CORRIGIDO (07/07/2026): antes só UM desses valia por vez (elif em
    # cadeia) — se triplo estourasse, duplo e crítico eram ignorados. Agora
    # são 3 chances INDEPENDENTES: podem estourar sozinhas, juntas, ou nenhuma.
    if atk_triggers.get("triple_damage_chance", 0) > random.randint(1, 100):
        dano_final *= 3
        logs.append("💥💥 DANO TRIPLO CATASTRÓFICO!\n")

    if atk_triggers.get("double_damage_chance", 0) > random.randint(1, 100):
        dano_final *= 2
        logs.append("💥 Dano Duplo Perfeito!\n")

    chance_crit, bonus_sobra = chance_e_bonus_de_critico(crit, eva_alvo)
    if chance_crit > 0 and random.randint(1, 100) <= chance_crit:
        crit_mult = 1.5 + atk_triggers.get("crit_dmg_bonus_pct", 0) + bonus_sobra
        dano_final = int(dano_final * crit_mult)
        logs.append("🎯 Golpe Crítico!\n")

    # 🩸 Fúria Descontrolada (spec_furia): dano ampliado quando o HP está baixo
    if atk_triggers.get("dmg_mult_active"):
        dano_final = int(dano_final * atk_triggers["dmg_mult_active"])
        logs.append("🩸 FÚRIA DESCONTROLADA! O dano foi ampliado pela raiva!\n")

    return dano_final, logs

def calc_thorns_and_counters(damage_taken: int, def_triggers: dict, defender_def: int, attacker_atk: int) -> tuple[int, list[str], dict]:
    """Calcula Espinhos, Rebote e Atordoamento de quem atacou."""
    logs = []
    updates = {}
    dano_rebatido = 0
    
    # 🛡️ Tanker (Espinhos)
    if "thorns_pct" in def_triggers and damage_taken > 0:
        rebote = max(1, int(damage_taken * def_triggers["thorns_pct"]))
        if def_triggers.get("reflect_double_chance", 0) > random.randint(1, 100):
            rebote *= 2
            logs.append(f"🌵 Rebote Brutal! Devolveu {rebote} de dano!\n")
        else:
            logs.append(f"🌵 Rebote: Devolveu {rebote} de dano.\n")
        dano_rebatido += rebote
        
    # 🛡️ Tanker (Escamas de Ferro): ATK inimigo menor que a TUA DEF = Dano Dobrado no inimigo
    if def_triggers.get("thorns_def_scaling") and attacker_atk < defender_def:
        dano_extra = max(1, damage_taken * 2) 
        logs.append(f"🏔️ A defesa superou o ataque! O atacante sofreu {dano_extra} de dano colateral!\n")
        dano_rebatido += dano_extra
        
    # 🪨 Tanker (Coração de Pedra)
    if def_triggers.get("stun_attacker_chance", 0) > random.randint(1, 100):
        updates["stun_attacker"] = 1
        logs.append("🪨 O atacante bateu numa rocha e ficou Atordoado!\n")
        
    return dano_rebatido, logs, updates

def apply_lifesteal(damage_dealt: int, atk_triggers: dict) -> tuple[int, list[str], dict]:
    """Calcula quanto de HP o atacante recuperou batendo."""
    logs = []
    updates = {}
    cura = 0
    
    if "lifesteal_pct" in atk_triggers and damage_dealt > 0:
        cura = max(1, int(damage_dealt * atk_triggers["lifesteal_pct"]))
        # 🩸 Sanguinário Mestre: Cura o grupo todo na Raid
        if atk_triggers.get("lifesteal_double_party_chance", 0) > random.randint(1, 100):
            cura *= 2
            updates["heal_party"] = cura
            logs.append(f"🦇 Vampirismo Absoluto! Drenou {cura} HP e espalhou pela equipa!\n")
        else:
            logs.append(f"🦇 Drenou {cura} HP.\n")
            
    return cura, logs, updates

def check_free_turn(atk_triggers: dict) -> tuple[bool, str]:
    """Se retornar True, a barra de ATB não deve ser zerada."""
    if atk_triggers.get("free_turn_chance", 0) > random.randint(1, 100):
        return True, "🌪️ Passos de Vento! O ataque não consumiu a barra de turno!\n"
    return False, ""
def combat_attack(p: dict) -> str:
    cmb = p.get("combat")
    if not cmb or not cmb.get("enemies"):
        p["state"] = "TOWER"
        return "Fim do combate."
    
    pre_logs = combat_advance_until_player_ready(p)
    cmb = p.get("combat")
    if not cmb or not cmb.get("enemies"): 
        return "".join(pre_logs + [_after_any_victory(p)])
    
    if float(cmb.get("p_bar", 0.0)) < ATB_MAX: 
        return "".join(pre_logs + [combat_render_bars(p), "  ATB carregando..."])
        
    _tick_cooldowns_dict(cmb.setdefault("p_cooldowns", {}))
    
    # 🔥 Puxa os Triggers Mágicos!
    meus_triggers = get_combat_triggers(p)
    inimigo_triggers = {} # No futuro, monstros elites também poderão ter especialidades!
    
    # 🌪️ Checa o Andarilho do Vento (Turno Livre)
    free_turn, ft_log = check_free_turn(meus_triggers)
    if not free_turn:
        if not combat_consume_player_bar(p): 
            return "".join(pre_logs + [combat_render_bars(p), "⌛ ATB insuficiente."])
    else:
        pre_logs.append(ft_log)
    
    recalc(p)
    cmb["p_spd"] = int(p["spd"])
    t = int(cmb.get("target", 0))
    t = max(0, min(t, len(cmb["enemies"]) - 1))
    enemy = cmb["enemies"][t]
    
    logs = list(pre_logs)

    # =========================================================
    # 🎲 O NOVO MOTOR DE COMBATE
    # =========================================================
    p_name = p.get("username", "Você")
    e_name = enemy.get("name", "Inimigo")
    
    acertou, log_hit, def_updates = check_hit_and_evasion(
        int(p.get('acc', 0)), int(enemy.get('eva', 0)), 
        meus_triggers, inimigo_triggers, p_name, e_name
    )
    if log_hit: logs.append(log_hit)
    
    if acertou:
        # Calcula o dano absurdo
        # 🔥 (08/07/2026): ATK passa pelo _solo_effective_stat pra respeitar
        # o buff temporário (buff_atk) — antes o buff era ignorado aqui.
        dano_final, logs_dano = calc_final_damage(
            _solo_effective_stat(p, "atk", int(p.get('atk', 0))), int(enemy.get('def', 0)), int(p.get('crit', 0)),
            meus_triggers, inimigo_triggers, int(enemy.get('hp', 0)),
            # 🐛 era enemy.get('hpmax') — chave que o inimigo não tem: a vida
            # máxima virava 1 e a Execução (Assassino) nunca disparava
            int(enemy.get('hp_max', enemy.get('hpmax', 1))),
            eva_alvo=int(enemy.get('eva', 0))
        )
        logs.extend(logs_dano)
        
        # 🔥 CORREÇÃO: Trava blindada para impedir HP negativo!
        enemy['hp'] = max(0, enemy.get('hp', 0) - dano_final)
        
        # Mostra o dano real que o monstro tomou!
        logs.append(f"🗡️ {p_name} atacou! -{dano_final} HP em {e_name}.\n")

        # 🦇 Vampirismo
        cura, logs_cura, _ = apply_lifesteal(dano_final, meus_triggers)
        if cura > 0:
            p['hp'] = min(p.get('hp_max', 1), p.get('hp', 0) + cura)
            logs.extend(logs_cura)
            
        # 🌵 Espinhos (Caso o monstro tivesse a passiva)
        rebote, logs_rebote, _ = calc_thorns_and_counters(dano_final, inimigo_triggers, int(enemy.get('def', 0)), int(p.get('atk', 0)))
        if rebote > 0:
            p['hp'] = max(0, p.get('hp', 0) - rebote)
            logs.extend(logs_rebote)
            if p['hp'] <= 0:
                success, msg = on_player_death(p)
                logs.append(msg)
                if success: p['state'] = 'DEAD'
                return "".join(logs)
                
        # =========================================================
        # 💀 MOTOR DE MORTE (ESTAVA FALTANDO!) ZUMBIS NUNCA MAIS
        # =========================================================
        if enemy.get('hp', 0) <= 0:
            logs.extend(_on_enemy_killed(p, t))
            cmb = p.get("combat")
            if not cmb or not cmb.get("enemies"):
                logs.append(_after_any_victory(p))
                return "".join(logs)

    # ⏱️ Encerra a vez do Player e avança o tempo!
    cmb["p_turno_iniciado"] = False
    logs.extend(combat_advance_until_player_ready(p, max_events=50))
    return "".join(logs)








def execute_combat_skill(p: dict, sk_id: str) -> str:
    import random
    sk_id = str(sk_id)
    pre_logs = combat_advance_until_player_ready(p, max_events=50)
    cmb = p.get("combat")
    
    # Se não há inimigos, encerra
    if not cmb or not cmb.get("enemies"): 
        from game.logic import _after_any_victory
        return "".join(pre_logs + [_after_any_victory(p)])
    
    ATB_MAX = 100.0 
    if float(cmb.get("p_bar", 0.0)) < ATB_MAX: 
        return "".join(pre_logs + [combat_render_bars(p), "  ATB carregando..."])
    
    learned = p.get("skills_learned", {})
    sk_learned_data = learned.get(sk_id)
    
    if not sk_learned_data or not isinstance(sk_learned_data, dict):
        sk_base_data = get_skill_by_id(sk_id)
        if sk_base_data: sk = sk_base_data.get("skill") or sk_base_data
        else: return "❌ Skill não encontrada."
    else:
        sk = sk_learned_data
    
    if not sk or not isinstance(sk, dict) or sk.get("type") != "active": return "❌ Skill inválida\n"
    
    cds = cmb.setdefault("p_cooldowns", {})
    _tick_cooldowns_dict(cds)
    cd_now = int(cds.get(sk_id, 0))
    if cd_now > 0: return "".join(pre_logs) + f"\n⏳ [{sk.get('name', sk_id)}] em recarga ({cd_now} turnos).\n" + combat_render_bars(p)

    # 🔥 Puxa os Triggers Mágicos!
    meus_triggers = get_combat_triggers(p)
    inimigo_triggers = {} 
    
    # 🌪️ Andarilho do Vento (Pode soltar magia sem gastar turno!)
    free_turn, ft_log = check_free_turn(meus_triggers)
    if not free_turn:
        if not combat_consume_player_bar(p): return "".join(pre_logs) + "\n" + combat_render_bars(p) + "\n⏳ Erro ao consumir ATB."
    else:
        pre_logs.append(ft_log)

    recalc(p)
    logs = list(pre_logs)
    sk_evolved = sk_learned_data if isinstance(sk_learned_data, dict) else sk

    if sk.get("target") == "all": targets = list(range(len(cmb["enemies"])))
    else:
        t = max(0, min(int(cmb.get("target", 0)), len(cmb["enemies"]) - 1))
        targets = [t]

    p_atk = _solo_effective_stat(p, "atk", int(p.get("atk", 0)))

    # =========================================================
    # 🩸 MOTOR DE SACRIFÍCIO E CUSTO DE SANGUE
    # =========================================================
    hp_cost_pct = float(sk_evolved.get("hp_cost_pct", sk.get("hp_cost_pct", 0)))
    if hp_cost_pct > 0:
        cost = int(p.get("hp_max", 100) * hp_cost_pct)
        p["hp"] = max(1, int(p.get("hp", 1)) - cost)
        logs.append(f"🩸 Você sacrificou {cost} de HP para canalizar a magia!\n")

    temp_sac_dmg = 0
    sacrifice_pet = sk_evolved.get("sacrifice_pet", sk.get("sacrifice_pet", False))
    if sacrifice_pet:
        pet = cmb.get("pet", {}) 
        if pet and pet.get("hp", 0) > 0:
            sac_mult = float(sk_evolved.get("sacrifice_mult", sk.get("sacrifice_mult", 1.0)))
            temp_sac_dmg = int(pet["hp"] * sac_mult)
            pet["hp"] = 0
            logs.append(f"💀 O Pet foi sacrificado numa explosão macabra!\n")

    # =========================================================
    # ✨ MOTOR DE SUPORTE (CURA, CLEANSE, SHIELD, HoT)
    # =========================================================
    if sk_evolved.get("cleanse", sk.get("cleanse", False)):
        p["dots"] = []
        p["stun"] = 0
        p.setdefault("debuffs", {}).clear()
        logs.append("✨ Uma luz divina purificou todos os seus males!\n")

    shield_pct = float(sk_evolved.get("shield_pct", sk.get("shield_pct", 0)))
    if shield_pct > 0:
        shield_amt = int(p_atk * shield_pct)
        p["shield"] = p.get("shield", 0) + shield_amt
        logs.append(f"🛡️ Barreira Protetora de {shield_amt} HP ativada!\n")

    hot_pct = float(sk_evolved.get("hot_pct", sk.get("hot_pct", 0)))
    if hot_pct > 0:
        hot_amt = int(p_atk * hot_pct)
        hot_turns = int(sk_evolved.get("hot_turns", sk.get("hot_turns", 3)))
        p.setdefault("hots", []).append({"heal": hot_amt, "turns": hot_turns})
        logs.append(f"🌿 Regeneração de {hot_amt} HP/turno aplicada!\n")

    # =========================================================
    # 💪 BUFFS DO JOGADOR (buff_atk / buff_def / buff_eva)
    # 🔥 CORRIGIDO (08/07/2026): o motor solo NUNCA aplicava buff nenhum —
    # 21 skills (13 só de buff_def, a defesa inteira do Guardião) eram
    # cliques vazios na Torre. A raid já fazia isso; os dois motores
    # evoluíram separados e cada um implementou um pedaço diferente.
    # =========================================================
    _buff_turns = int(sk_evolved.get("buff_turns", sk.get("buff_turns", 3))) or 3
    for _chave, _stat, _nome, _emoji in (
        ("buff_atk", "atk", "Ataque", "⚔️"),
        ("buff_def", "def", "Defesa", "🛡️"),
        ("buff_eva", "eva", "Evasão", "💨"),
    ):
        _pct = float(sk_evolved.get(_chave, sk.get(_chave, 0)))
        if _pct > 0:
            _solo_apply_buff(p, _stat, _pct, _buff_turns)
            logs.append(f"{_emoji} {_nome} +{int(_pct*100)}% por {_buff_turns} turno(s)!\n")

    # 🎯 TAUNT / PROVOCAÇÃO (08/07/2026): no solo, força o inimigo a atacar
    # você em vez do seu pet. Antes não fazia nada aqui.
    _taunt = sk_evolved.get("taunt", sk.get("taunt"))
    if _taunt:
        _t_turns = int(sk_evolved.get("taunt_turns", sk.get("taunt_turns", 2))) or 2
        p["taunt_active"] = _t_turns
        logs.append(f"🎯 Você provocou os inimigos! Eles vão te atacar por {_t_turns} turno(s).\n")

    # =========================================================
    # 🪨 CONTRA-STUN (stun_on_hit_chance)
    # 🔥 CORRIGIDO (08/07/2026): 3 skills do Guardião (Pele de Granito 15%,
    # Armadura de Titã 30%, Colosso de Terra 50%) tinham essa mecânica no
    # banco de skills, mas o motor NUNCA lia — o efeito que era a assinatura
    # da classe simplesmente não existia. Elas só davam +DEF e nada mais.
    # Agora vira um buff temporário: enquanto ativo, quem te bater tem X%
    # de chance de ficar atordoado.
    # =========================================================
    stun_on_hit = float(sk_evolved.get("stun_on_hit_chance", sk.get("stun_on_hit_chance", 0)))
    if stun_on_hit > 0:
        dur_contra = int(sk_evolved.get("buff_turns", sk.get("buff_turns", 3)))
        p["stun_on_hit"] = {"chance": stun_on_hit, "turns": dur_contra}
        logs.append(f"🪨 Sua pele endureceu! ({int(stun_on_hit)}% de atordoar quem te atacar, {dur_contra} turnos)\n")

    heal_pct = float(sk_evolved.get("heal_percent", sk.get("heal_percent", 0)))
    if heal_pct > 0:
        heal_amount = int(p_atk * heal_pct)
        # Especialidade Milagreiro: Aumenta a cura e chance de dar o dobro!
        heal_amount = int(heal_amount * meus_triggers.get("heal_mult", 1.0))
        if meus_triggers.get("double_heal_chance", 0) > random.randint(1, 100):
            heal_amount *= 2
            logs.append("✨ MILAGRE! Efeito de cura duplicado!\n")
            
        p["hp"] = min(int(p.get("hp_max", 1)), int(p.get("hp", 0)) + heal_amount)
        logs.append(f"💚 Recuperou {heal_amount} HP com {sk.get('name', sk_id)}.\n")

        # 🔥 Mestre do Equilíbrio: chance da cura também gerar um Escudo equivalente
        if meus_triggers.get("heal_creates_shield_chance", 0) > random.randint(1, 100):
            p["shield"] = p.get("shield", 0) + heal_amount
            logs.append(f"🛡️ Equilíbrio Perfeito! A cura gerou {heal_amount} de Escudo!\n")

    # ATB Boost (Avança a barra do jogador)
    atb_boost = float(sk_evolved.get("atb_boost", sk.get("atb_boost", 0)))
    if atb_boost > 0:
        cmb["p_bar"] = min(ATB_MAX, cmb.get("p_bar", 0) + atb_boost)
        logs.append(f"⚡ Avanço de turno ativado (+{int(atb_boost)} ATB)!\n")

    # =========================================================
    # ⚔️ MOTOR DE DANO E STATUS MÁGICOS
    # =========================================================
    mult = float(sk_evolved.get("mult", sk.get("mult", 0)))
    dmg_pct = float(sk_evolved.get("dmg_percent", sk.get("dmg_percent", 0)))
    dot_mult = float(sk_evolved.get("dot_mult", sk.get("dot_mult", 0)))
    dot_turns = int(sk_evolved.get("dot_turns", sk.get("dot_turns", 0)))
    stun_turns = int(sk_evolved.get("stun", sk.get("stun", 0)))

    # Lifesteal Percentual
    lifesteal_val = float(sk_evolved.get("lifesteal_pct", sk.get("lifesteal_pct", 0)))
    if sk.get("lifesteal"): lifesteal_val = max(lifesteal_val, 1.0) 
    if lifesteal_val > 0: meus_triggers["lifesteal_pct"] = max(meus_triggers.get("lifesteal_pct", 0), lifesteal_val)

    p_name = p.get("username", "Você")
    p_acc, p_crit = int(p.get("acc", 0)), int(p.get("crit", 0))

    for t in sorted(targets, reverse=True):
        if t >= len(cmb["enemies"]): continue
        enemy = cmb["enemies"][t]
        e_name = enemy.get("name", "Inimigo")
        
        base_damage = 0
        if mult > 0: base_damage = int(p_atk * mult)
        elif dmg_pct > 0: base_damage = int(p_atk * (dmg_pct / 100.0))

        # Adiciona o dano da explosão do Pet se houve sacrifício
        base_damage += temp_sac_dmg

        if base_damage > 0 or dot_mult > 0 or stun_turns > 0:
            acertou, log_hit, def_upd = check_hit_and_evasion(p_acc, int(enemy.get("eva", 0)), meus_triggers, inimigo_triggers, p_name, e_name)
            if log_hit: logs.append(log_hit)
            
            if acertou:
                if base_damage > 0:
                    # 🎯 Marca de Vulnerabilidade
                    debuffs = enemy.get("debuffs", {})
                    if debuffs.get("mark_dmg_bonus"):
                        base_damage = int(base_damage * (1.0 + debuffs["mark_dmg_bonus"]))
                        logs.append("🎯 A Marca amplificou o dano!\n")

                    # 🩸 Execução Mágica
                    execute_pct = float(sk_evolved.get("execute_pct", sk.get("execute_pct", 0)))
                    if execute_pct > 0:
                        missing_hp_pct = 1.0 - (int(enemy.get("hp", 1)) / max(1, int(enemy.get("hpmax", 1))))
                        base_damage = int(base_damage * (1.0 + (missing_hp_pct * execute_pct)))
                        if missing_hp_pct > 0.5:
                            logs.append("⚖️ GOLPE DE MISERICÓRDIA!\n")

                    # 🔥 O NERF CIRÚRGICO
                    skill_crit = p_crit // 10 
                    
                    # RODA O MOTOR DE DANO ORIGINAL
                    dano_final, logs_dano = calc_final_damage(base_damage, int(enemy.get("def", 0)), skill_crit, meus_triggers, inimigo_triggers, int(enemy.get("hp", 0)), int(enemy.get("hp_max", enemy.get("hpmax", 1))), eva_alvo=int(enemy.get("eva", 0)) // 10)
                    logs.extend(logs_dano)

                    # 💥 Detonação de Status
                    detonate = sk_evolved.get("detonate", sk.get("detonate", False))
                    if detonate and enemy.get("dots"):
                        extra_dmg = sum(d.get("dmg", 0) * d.get("turns", 1) for d in enemy["dots"])
                        dano_final += extra_dmg
                        enemy["dots"] = []
                        logs.append(f"💥 DETONAÇÃO! Todos os efeitos explodiram (+{extra_dmg} Dano)!\n")
                    
                    # 🛡️ Aplicar Dano contra Escudo do Inimigo (se houver)
                    enemy_shield = enemy.get("shield", 0)
                    if enemy_shield > 0:
                        if enemy_shield >= dano_final:
                            enemy["shield"] -= dano_final
                            logs.append(f"🛡️ O Escudo absorveu {dano_final} de dano.\n")
                            dano_final = 0
                        else:
                            logs.append(f"🛡️ O Escudo foi quebrado! (-{enemy_shield})\n")
                            dano_final -= enemy_shield
                            enemy["shield"] = 0

                    # 🔥 CORREÇÃO DO HP NA SKILL
                    enemy["hp"] = max(0, enemy.get("hp", 0) - dano_final)
                    if dano_final > 0:
                        logs.append(f"💥 {sk.get('name', sk_id)}! -{dano_final} HP em {e_name}.\n")
                    
                    # RODA O VAMPIRISMO
                    cura, logs_cura, _ = apply_lifesteal(dano_final, meus_triggers)
                    if cura > 0:
                        p["hp"] = min(int(p.get("hp_max", 1)), int(p.get("hp", 0)) + cura)
                        logs.extend(logs_cura)
                        
                    # RODA O ESPINHOS DO INIMIGO
                    rebote, logs_rebote, _ = calc_thorns_and_counters(dano_final, inimigo_triggers, int(enemy.get("def", 0)), base_damage)
                    if rebote > 0:
                        p["hp"] = max(0, int(p.get("hp", 0)) - rebote)
                        logs.extend(logs_rebote)
                        if p["hp"] <= 0:
                            success, msg = on_player_death(p)
                            logs.append(msg)
                            if success: p["state"] = "DEAD"
                            return "".join(logs)

               # =========================================================
                # ☠️ APLICAÇÃO DE EFEITOS NEGATIVOS NO ALVO
                # =========================================================
                if dot_mult > 0 and dot_turns > 0:
                    dmg_dot_final = max(1, int(p_atk * dot_mult))
                    if meus_triggers.get("dot_dmg_pct"):
                        dmg_dot_final = max(1, int(dmg_dot_final * (1.0 + meus_triggers["dot_dmg_pct"])))
                    novo_dot = {"name": sk.get("dot_name", "DoT"), "dmg": dmg_dot_final, "turns": dot_turns}
                    if meus_triggers.get("venom_stun_chance"):
                        novo_dot["stun_chance"] = meus_triggers["venom_stun_chance"]
                    enemy.setdefault("dots", []).append(novo_dot)
                    logs.append(f"☠️ {e_name} sofreu {sk.get('dot_name', 'DoT')}!\n")

                if stun_turns > 0:
                    # 🔥 TRAVA GLOBAL DE 35% DE CHANCE
                    if random.randint(1, 100) <= 35:
                        enemy["stun"] = enemy.get("stun", 0) + stun_turns
                        logs.append(f"💫 {e_name} atordoado por {stun_turns} turno(s)!\n")
                    else:
                        logs.append(f"🛡️ {e_name} resistiu ao atordoamento!\n")

                # Silenciamento
                silence_turns = int(sk_evolved.get("silence_turns", sk.get("silence_turns", 0)))
                if silence_turns > 0:
                    enemy.setdefault("debuffs", {})["silence"] = silence_turns
                    logs.append(f"🤫 {e_name} silenciado por {silence_turns} turno(s)!\n")

                # Marca de Vulnerabilidade
                mark_bonus = float(sk_evolved.get("mark_dmg_bonus", sk.get("mark_dmg_bonus", 0)))
                if mark_bonus > 0:
                    enemy.setdefault("debuffs", {})["mark_dmg_bonus"] = mark_bonus
                    enemy.setdefault("debuffs", {})["mark_turns"] = int(sk_evolved.get("buff_turns", sk.get("buff_turns", 3)))
                    logs.append(f"🎯 {e_name} foi marcado como presa!\n")

                # Quebra de Armadura
                debuff_def = float(sk_evolved.get("debuff_def", sk.get("debuff_def", 0)))
                if debuff_def > 0:
                    enemy.setdefault("debuffs", {})["def_pct"] = debuff_def
                    enemy.setdefault("debuffs", {})["def_turns"] = int(sk_evolved.get("debuff_turns", sk.get("debuff_turns", 3)))
                    logs.append(f"📉 A Defesa de {e_name} foi comprometida!\n")

                # Atraso de Turno (Lentidão)
                # 🔥 CORRIGIDO (08/07/2026): escrevia em enemy["atb"], uma
                # chave que NINGUÉM lê — a barra de turno do inimigo é
                # enemy["bar"]. Ou seja, o "slow" do gelo (4 skills do Mago)
                # nunca atrasou ninguém: gravava o número num campo morto.
                atb_drain = float(sk_evolved.get("atb_drain", sk.get("atb_drain", 0)))
                if atb_drain > 0:
                    enemy["bar"] = max(0.0, float(enemy.get("bar", 0.0)) - atb_drain)
                    logs.append(f"⏳ O turno de {e_name} foi atrasado!\n")

                # 📉 Redução de ATK (debuff_atk)
                # 🔥 CORRIGIDO (08/07/2026): era a única mecânica que não
                # funcionava em motor NENHUM (nem solo nem raid).
                debuff_atk = float(sk_evolved.get("debuff_atk", sk.get("debuff_atk", 0)))
                if debuff_atk > 0:
                    enemy.setdefault("debuffs", {})["atk_pct"] = debuff_atk
                    enemy.setdefault("debuffs", {})["atk_turns"] = int(sk_evolved.get("debuff_turns", sk.get("debuff_turns", 3)))
                    logs.append(f"📉 O Ataque de {e_name} foi enfraquecido em {int(debuff_atk*100)}%!\n")

        # Checa Morte do Inimigo
        if enemy.get("hp", 0) <= 0:
            from game.logic import _on_enemy_killed
            logs.extend(_on_enemy_killed(p, t))
            cmb = p.get("combat")
            if not cmb or not cmb.get("enemies"):
                from game.logic import _after_any_victory
                logs.append(_after_any_victory(p))
                return "".join(logs)

    cmb["p_turno_iniciado"] = False
    cd_base = int(sk.get("cooldown", 2))
    cd_red = meus_triggers.get("pet_cooldown_red_pct", 0)
    cds[sk_id] = max(1, int(cd_base * (1.0 - cd_red))) if cd_red else cd_base
    logs.extend(combat_advance_until_player_ready(p, max_events=50))
    return "".join(logs)


    

def _after_any_victory(p: dict) -> str:
    """
    Decide automaticamente qual pós-vitória usar:
    - Torre normal: _after_floor_victory
    - Torre Desafio (RAID): after_raid_floor_victory
    """
    if p.get("tower_mode") == "RAID":
        return after_raid_floor_victory(p)
    return _after_floor_victory(p)
    
    try:
        cid = random.choice(pool) if pool else drop_core_roll(int(p.get('tower_floor', 1)), tipo_do_monstro)
    except ImportError:
        cid = random.choice(pool) if pool else None

    # ========================================================
    # 🎯 FILTRO DE CLASSE (Molde Inteligente do Drop)
    # ========================================================
    if cid:
        try:
            from game.logic import get_specialty_slots
            
            # Se o drop que veio da fonte for uma magia
            if cid in SKILL_DB:
                raridade_sorteada = SKILL_DB[cid].get("skill", {}).get("rarity", 1)
                p_class = str(p.get("class", p.get("class_id", ""))).lower()
                p_specs = get_specialty_slots(p)
                
                skills_validas = []
                
                # Varre o banco mantendo a raridade que o monstros.py decidiu!
                for k_id, k_data in SKILL_DB.items():
                    sk = k_data.get("skill", {})
                    if sk.get("rarity", 1) == raridade_sorteada:
                        r_class = sk.get("req_class")
                        r_spec = sk.get("req_spec")
                        
                        if r_class and r_class.lower() == p_class:
                            skills_validas.append(k_id)
                        elif r_spec and r_spec in p_specs:
                            skills_validas.append(k_id)
                            
                # Se achou uma magia da classe dele, substitui a original!
                if skills_validas:
                    cid = random.choice(skills_validas)
                    
        except ImportError:
            pass


def _combat_potion_atb(p: dict) -> str:
    pre = combat_advance_until_player_ready(p)
    cmb = p.get("combat") or {}
    if not cmb.get("enemies"): return _nl(pre, "🏁 O combate já terminou.")
    inv = p.setdefault("inv", {})
    if inv.get("potion", 0) <= 0: return _nl(pre, combat_render_bars(p), "❌ Você não tem poções!")
    if float(cmb.get("p_bar", 0.0)) < ATB_MAX: return _nl(pre, combat_render_bars(p), "⌛ Aguarde sua vez (ATB carregando...)")
    _tick_cooldowns_dict(cmb.setdefault("p_cooldowns", {}))
    if not combat_consume_player_bar(p): return _nl(pre, combat_render_bars(p), "⚠️ Erro ao consumir ATB.")
    inv["potion"] -= 1
    andar = int(p.get("tower_floor", 1))   # pega o andar atual
    heal_amount = 50 + (10 * andar)
    p["hp"] = min(p["hp_max"], p["hp"] + heal_amount)
    post = combat_advance_until_player_ready(p)
    return _nl(
        pre,
    f"💊  {heal_amount} HP!\n",
    post)

def combat_flee(p: dict) -> str:
    """🏃 FUGIR - 100% Funciona"""
    # 🛡️ LIMPEZA DE ESCUDO NA FUGA
    p.pop("shield", None)
    
    p["combat"] = None
    p["state"] = "TOWER"
    
    penalty = min(10, int(p.get("gold", 0)))
    p["gold"] -= penalty
    
    return f"🏃‍♂️ <b>FUGIU com sucesso!</b>-{penalty}g\n"

    
def raid_flee(p: dict) -> str:
    """
    Fuga da Torre Desafio no lobby.
    Sai da sala, volta pra cidade e reseta modo via raid_leave_room.
    """
    if p.get("state") != "RAID_LOBBY":
        return "❌ Você só pode sair da Torre Desafio no lobby, após a batalha.\n"

    return raid_leave_room(p)
    

# ===== SOCKET / HOSPITAL / SHOP =====
def socket_begin(p: dict, slot: str, idx: int) -> str:
    it = p["inv"]["items"][slot][idx]
    if len(it.get("socked", [])) >= int(it.get("sock_max", 0)): return "Slots cheios."
    p["socket"] = {"slot": slot, "idx": idx}
    return f"Selecione core para {it.get('name', 'item')}."

def socket_apply(p: dict, cid: str) -> str:
    """
    Aplica um core num item. Lógica Hardcore:
    Sobrescrever um slot ocupado DESTRÓI a gema antiga.
    """
    temp = p.get('socket_temp')
    if not temp:
        return '❌ Erro de sessão. Tente de novo.'
    
    target_str = temp['target']
    slot_idx = int(temp['slot_idx'])
    parts = target_str.split(':')
    loc = parts[0]
    slot_name = parts[1]
    item = None
    
    # 1. Encontra onde o item está (equipado ou guardado)
    if loc == 'equip':
        item = p.get('equip', {}).get(slot_name)
    elif loc == 'inv':
        idx = int(parts[2])
        try:
            item = p.get('inv', {}).get('items', {})[slot_name][idx]
        except:
            return '❌ Item não encontrado no inventário.'
            
    if not item:
        return '❌ Item sumiu.'
        
    # 2. Confirma se o jogador ainda tem a pedra (Core)
    cores_inv = p.setdefault('inv', {}).setdefault('cores', {})
    if cores_inv.get(cid, 0) <= 0:
        return '❌ Você não tem essa core.'
        
    # 3. Prepara a lista de slots do item
    socked_list = item.setdefault('socked', [])
    max_slots = int(item.get('sock_max', 0))
    
    if slot_idx >= max_slots:
        return '❌ Esse slot está bloqueado neste item.'
        
    # Preenche com None até chegar no tamanho do slot escolhido
    while len(socked_list) <= slot_idx:
        socked_list.append(None)
        
    # 4. Consome do inventário
    cores_inv[cid] -= 1
    if cores_inv[cid] <= 0:
        cores_inv.pop(cid, None)
        
    # 5. Sobrescreve (A Mecânica Hardcore de perder o antigo acontece aqui)
    old_core = socked_list[slot_idx]
    socked_list[slot_idx] = cid
    item['socked'] = [x for x in socked_list if x is not None]
    
    # Atualiza os status do player
    recalc(p)
    
    # Limpa a memória temporária do forjador
    p['socket_temp'] = None
    
    # Gera a mensagem de retorno
    msg = f'✅ Sucesso! Core <b>{cid.upper()}</b> fundida no Slot {slot_idx + 1}.'
    if old_core:
        msg += f' 🗑️ A core antiga ({old_core.upper()}) foi destruída no processo.'
        
    return msg

def hospital_heal(p: dict) -> str:
    cost = 10 + (int(p["level"]) // 5)
    if p["gold"] < cost: return f"Ouro insuficiente. Precisa de {cost}g."
    if p["hp"] >= p["hp_max"]: return "Você já está com vida cheia."
    p["gold"] -= cost
    p["hp"] = p["hp_max"]
    return f"Tratamento completo! Curou tudo por {cost}g."

def shop_buy_potion(p: dict) -> str:
    cost = 25
    inv = p.setdefault("inv", {})
    qtd = int(inv.get("potion", 0))
    ouro = int(p.get("gold", 0))
    if qtd >= 10: return "❌ Limite de 10 poções atingido!"
    if ouro < cost: return f"❌ Você precisa de {cost}g para comprar uma poção."
    p["gold"] = ouro - cost
    inv["potion"] = qtd + 1
    return f"✅ Poção comprada! Total: {inv['potion']} poções\n"

def _ensure_pending_orders(p: dict) -> list:
    """Garante lista de pedidos pendentes no player."""
    if "pending_orders" not in p or not isinstance(p["pending_orders"], list):
        p["pending_orders"] = []
    return p["pending_orders"]

def shop_buy_stars(p: dict, amount: int) -> str:
    amount = int(amount)
    now = int(time.time())

    active = _get_active_order(p, now)
    if active:
        status = active.get("status", "?")
        oid = active.get("id", "???")
        a = active.get("amount", "?")
        
        if status == "waiting_payment":
            expires = int(active.get("expires_at", 0))
            remaining = expires - now if expires else ORDER_TTL_SECONDS
            return (
                f"⏳ <b>Pedido pendente!</b>\n\n"
                f"🧾 Pedido: `{oid}` ({a}⭐)\n"
                f"📌 Status: <b>Aguardando comprovante</b>\n"
                f"⌛ Expira em: `{_fmt_seconds(remaining)}`\n\n"
                f"<b>Envie a foto do comprovante!</b>"
            )

        elif status == "proof_sent":
            return (
                f"✅ <b>Comprovante recebido!</b>\n\n"
                f"🧾 Pedido: `{oid}` ({a}⭐)\n"
                f"📌 Status: <b>Aguardando liberação do admin</b>\n\n"
                f"<b>Seu pedido foi enviado. Aguarde!</b>"
            )

    # Novo pedido
    order_id = f"ORD{uuid.uuid4().hex[:6].upper()}"
    expires_at = now + ORDER_TTL_SECONDS

    pending = _ensure_pending_orders(p)
    pending.append({
        "id": order_id,
        "amount": amount,
        "status": "waiting_payment",
        "created_at": now,
        "expires_at": expires_at,
    })

    return (
        f"🧾 <b>Pedido #{order_id} criado!</b>\n\n"
        f"🌟 <b>{amount}⭐</b>\n"
        f"💳 Pix: <b>55996184362</b>\n"
        f"Leandro Moraes Machado\n\n"
        f"📸 <b>Envie comprovante como foto!</b>\n"
        f"⌛ <b>Você tem 12h</b> (expira {_fmt_seconds(ORDER_TTL_SECONDS)})"
    )

def shop_sell_core(p: dict, core_id: str, all_qty: bool = False) -> str:
    cores = p.setdefault("inv", {}).setdefault("cores", {})
    if core_id not in cores or cores[core_id] <= 0:
        return "❌ Você não tem essa core.\n"

    qty_total = int(cores[core_id])
    if all_qty:
        qty_to_sell = qty_total
    else:
        qty_to_sell = 1

    if qty_to_sell <= 0:
        return "❌ Quantidade inválida.\n"

    price_unit = core_sell_value(core_id, 1)  # tier base
    total = price_unit * qty_to_sell

    cores[core_id] = qty_total - qty_to_sell
    if cores[core_id] <= 0:
        cores.pop(core_id, None)

    p["gold"] = int(p.get("gold", 0)) + total

    _save_player_if_possible(p)

    if all_qty:
        return (
            f"✅ Vendeu {core_id} x{qty_to_sell} por {total}g.\n"
            f"Total: {p['gold']}g\n"
        )
    else:
        return (
            f"✅ Vendeu {core_id} x1 por {price_unit}g.\n"
            f"Total: {p['gold']}g\n"
        )

def sell_item(p: dict, slot: str, idx: int) -> str:
    try:
        idx = int(idx)
        items = p.setdefault("inv", {}).setdefault("items", {}).get(slot, [])
        if idx < 0 or idx >= len(items):
            return "❌ Item não encontrado"
        item = items[idx]
        rar = item.get("rar", "common")
        prices = {
            "common": 50,
            "uncommon": 150,
            "rare": 400,
            "epic": 1200,
            "legendary": 3000
        }
        price = prices.get(rar, 50)
        items.pop(idx)
        p["gold"] = p.get("gold", 0) + price

        _save_player_if_possible(p)

        return f"✅ Vendeu {item.get('name', 'Item')} ({rar}) por {price}g. Total: {p['gold']}g"
    except Exception as e:
        return f"❌ Erro ao vender: {str(e)}"
def vip_active(p: dict) -> bool:
    try:
        vip_until = p.get("vipuntil", p.get("vip_until", 0))
        return int(vip_until or 0) > int(time.time())
    except:
        return False

def vip_mult(p: dict) -> int:
    return 2 if vip_active(p) else 1

def shop_buy_vip(p: dict, days: int = 28, cost: int = 500) -> str:
    """Compra VIP usando estrelas e SALVA no SQLite. Não compra se já tem VIP ativo."""

    pid = p.get("player_id") or p.get("playerid")
    if not pid:
        return "❌ Erro: player_id inválido.\n"

    now = int(time.time())
    vip_until = int(p.get("vipuntil", 0))

    if vip_until > now:
        dias = int((vip_until - now) / 86400) + 1
        return f"⏳ Você já tem VIP ativo ({dias} dias restantes).\n"

    days = int(days)
    cost = int(cost)

    ok, new_balance = premium_repo.spend_premium(pid, cost, f"VIP {days} dias")
    if not ok:
        saldo_atual = premium_repo.get_premium(pid)
        return f"❌ Você precisa de {cost}⭐. Saldo: {saldo_atual}⭐.\n"

    p["vipuntil"] = now + days * 86400
    p["premium"] = int(new_balance)

    uid = int(p.get("telegram_id") or p.get("user_id") or p.get("userid") or 0)
    if uid:
        save_player_sql(uid, p)

    return f"✅ VIP ativado por {days} dias! 2x XP e 2x Drops.\n"


def shop_buy_autobattle(p: dict, days: int = 28, cost: int = 250) -> str:
    """🤖 Compra o acesso à Autobatalha usando estrelas — mesmo esquema do
    VIP (08/07/2026). Não vende mais de graça: virou benefício pago."""
    pid = p.get("player_id") or p.get("playerid")
    if not pid:
        return "❌ Erro: player_id inválido.\n"

    now = int(time.time())
    ate = autobattle_da_conta(p)            # da conta (26/09)

    if ate > now:
        dias = int((ate - now) / 86400) + 1
        return f"⏳ Você já tem Autobatalha ativa ({dias} dias restantes).\n"

    days = int(days)
    cost = int(cost)

    ok, new_balance = premium_repo.spend_premium(pid, cost, f"Autobatalha {days} dias")
    if not ok:
        saldo_atual = premium_repo.get_premium(pid)
        return f"❌ Você precisa de {cost}⭐. Saldo: {saldo_atual}⭐.\n"

    definir_autobattle_da_conta(p, now + days * 86400)
    p["premium"] = int(new_balance)

    uid = int(p.get("telegram_id") or p.get("user_id") or p.get("userid") or 0)
    if uid:
        save_player_sql(uid, p)

    return f"✅ Autobatalha ativada por {days} dias!\n"


# 🤖 26/09/2026 (dev): "o modo autobatalha é da CONTA, não do personagem".
# Era p["autobattle_until"] — por personagem: comprava com as ⭐ da conta e,
# ao trocar de personagem, o botão sumia. Agora mora na tabela `conta`
# (uma linha por conta); a compra que já estava num personagem sobe pra
# conta na primeira checagem (nenhum dia se perde).
def _conta_conn():
    import sqlite3 as _sq
    from game.sql_repo import DB_PATH
    from game.sql_repo import _SQL_CONTA
    c = _sq.connect(DB_PATH)
    c.execute(_SQL_CONTA)           # a tabela mora no sql_repo (migração na subida)
    return c


def autobattle_da_conta(p: dict) -> int:
    tid = int(p.get("telegram_id") or p.get("user_id") or 0)
    do_personagem = int(p.get("autobattle_until", 0) or 0)
    if not tid:
        return do_personagem
    with _conta_conn() as c:
        linha = c.execute("SELECT autobattle_until FROM conta WHERE telegram_id = ?", (tid,)).fetchone()
        da_conta = int(linha[0]) if linha else 0
        if do_personagem > da_conta:          # migra a compra antiga pra conta
            c.execute("INSERT OR REPLACE INTO conta (telegram_id, autobattle_until) VALUES (?, ?)",
                      (tid, do_personagem))
            c.commit()
            da_conta = do_personagem
    return da_conta


def definir_autobattle_da_conta(p: dict, ate: int) -> None:
    tid = int(p.get("telegram_id") or p.get("user_id") or 0)
    p["autobattle_until"] = int(ate)
    if tid:
        with _conta_conn() as c:
            c.execute("INSERT OR REPLACE INTO conta (telegram_id, autobattle_until) VALUES (?, ?)", (tid, int(ate)))
            c.commit()


def tem_autobattle_ativa(p: dict) -> bool:
    return autobattle_da_conta(p) > int(time.time())

def find_skill_by_id(skill_id: str):
    for core_id, cdata in SKILL_DB.items():
        sk = (cdata or {}).get("skill") or {}
        if sk.get("id") == skill_id:
            return core_id, sk
    return None, None

def marketplace_list_item(p: dict, slot: str, inv_idx: int, price: int = 50) -> str:
    """Jogador lista um item pra venda (custa 50⭐)"""
    inv = p.get("inv", {}).get("items", {})
    if slot not in inv or inv_idx >= len(inv.get(slot, [])):
        return "❌ Item não encontrado.\n"

    item = inv[slot][inv_idx]
    rarity = item.get("rar", "comum")

    # Pega IDs
    pid = p.get("player_id") or p.get("playerid")
    username = p.get("username", "Jogador")
    chat_id = int(p.get("chat_id", 0)) or int(p.get("chatid", 0)) or 0

    if not pid:
        return "❌ Erro: player_id inválido."

    # Verifica premium (50⭐ fee)
    ok, balance = premium_repo.spend_premium(pid, 50, "Listar item no marketplace\n")
    if not ok:
        return f"❌ Precisa de 50⭐ pra listar. Você tem {balance}⭐\n"
    # ⚠️ A CARTEIRA MUDOU, O p["premium"] NÃO.
    #
    # A carteira de ⭐ vive no premium.db; p["premium"] é só uma CÓPIA que a
    # tela lê. spend_premium/add_premium mexem no banco e não tocam na
    # cópia, então a rota devolvia o saldo velho e o jogador jurava que o
    # mercado não estava cobrando nada — medido: a taxa era debitada
    # certinho (100⭐ -> 50⭐), só não aparecia.
    p["premium"] = int(balance)

    # Remove do inventário (memória)
    inv[slot].pop(inv_idx)
    if not inv[slot]:
        del inv[slot]

    # Lista no banco (marketplace)
    ok, msg = trade_repo.list_item(pid, chat_id, username, item, slot, rarity, price)

    if ok:
        _save_player_if_possible(p)
        return f"✅ Item listado! {msg}\n"
    else:
        # Volta o premium se falhar
        premium_repo.add_premium(pid, 50, "Falha ao listar - reembolso\n")
        p["premium"] = int(premium_repo.get_premium(pid))
        return msg


def marketplace_buy_item(p: dict, item_id: int) -> Tuple[bool, str]:
    """Jogador compra um item do marketplace"""
    buyer_pid = p.get("player_id") or p.get("playerid")
    if not buyer_pid:
        return False, "❌ Erro: player_id inválido.\n"

    # Pega item
    market_item = trade_repo.get_item_by_id(item_id)
    if not market_item:
        return False, "❌ Item não encontrado ou expirou.\n"

    seller_pid = market_item["seller_pid"]
    price = market_item["price"]
    item = market_item["item"]
    slot = market_item["slot"]

    # Verifica saldo do comprador
    ok, balance = premium_repo.spend_premium(buyer_pid, price, "Compra item marketplace\n")
    if not ok:
        return False, f"❌ Saldo insuficiente: {balance}⭐. Custo: {price}⭐\n"
    # A cópia que a tela lê. Ver a nota em marketplace_list_item.
    p["premium"] = int(balance)

    # Adiciona premium pro vendedor. O saldo dele é corrigido quando ELE
    # carregar (ensure_premium_player resincroniza) — aqui só temos o dict
    # do comprador na mão.
    premium_repo.add_premium(seller_pid, price, "Venda no marketplace\n")

    # Remove do marketplace (DB)
    trade_repo.buy_item(item_id)

    # Adiciona item ao inventário do comprador (memória)
    inv = p.setdefault("inv", {})
    if "items" not in inv:
        inv["items"] = {}
    if slot not in inv["items"]:
        inv["items"][slot] = []

    inv["items"][slot].append(item)

    _save_player_if_possible(p)

    return True, f"✅ Item comprado!\nRecebido: {item.get('name', 'Item')}\n"
# ===== ADICIONE ESTA FUNÇÃO NO FINAL do logic.py =====
# Explorar não pode ser só "monstro ou portal". A Torre é habitada: gente
# que nasceu aqui, gente que foi mandada pra cá e não tem como descer, e
# clãs inteiros já formados. É desse encontro que saem os aldeões, e é por
# ele que o jogo se desenvolve fora do combate.
#
# 18% é o número escolhido pra o encontro ser lembrado sem virar rotina:
# a ~7 explorações por sessão, dá pouco mais de um por sessão. Abaixo de
# 10% o jogador não associa explorar a encontrar gente; acima de 25% o
# combate — que é o outro pilar — vira o evento raro.
CHANCE_ENCONTRO_TORRE = 0.18


# 🚪 (28/09, dev) Até o andar do novato morrer não custa nada — e o portal
# (10% por exploração) aparecia mesmo no andar de chefe. Medido: morrendo de
# graça até o portal sair, um jogador afoito chegava ao 11º andar no nível 3,
# morria de novo e ficava 5 h trancado. Nos andares de chefe do novato o
# portal agora só abre VENCENDO o chefe (e abre na hora, na tela da vitória).
# Do 11º em diante a morte já custa caro, então lá fica como era.
def portal_preso_ao_chefe(p: dict) -> bool:
    andar = int(p.get("tower_floor") or 1)
    if p.get("explore_mode") or p.get("wave_mode"):
        return False
    return (andar % 5 == 0 and andar <= ANDAR_DO_NOVATO
            and andar not in (p.get("chefes_vencidos") or []))


def tower_explore(p: dict):
    """Explorar torre: encontro com gente, portal, ou combate."""
    if random.random() < CHANCE_ENCONTRO_TORRE:
        # 👣 (26/09) os encontros vêm das CRÔNICAS (gatilho "torre"):
        # efeitos reais no jogador e no clã (game/cronicas.py)
        try:
            from game.cronicas import sortear_encontro_torre
            enc = sortear_encontro_torre(p)
        except Exception:
            enc = None
        if enc:
            # ⚠️ torre_encontro TEM que estar em _extra_fields do sql_repo,
            # senão some no save e a tela de encontro nunca acha nada.
            p["torre_encontro"] = enc
            return "👣 Você não está sozinho neste andar."

    if not portal_preso_ao_chefe(p) and random.random() < 0.10:
        p["tower_choice"] = True
        return "🌀 Portal encontrado! Escolha: Avançar ou Ficar."
    start_combat(p)
    p["state"] = "COMBAT"
    return "⚔️ Um inimigo apareceu!"

# 🔥 ANTI-FARM (06/07/2026): limite diário de drops por andar da torre.
# Bots/scripts que ficam 24h no mesmo andar continuam ganhando ouro/XP
# normalmente, mas param de receber cores/skills depois de N drops
# naquele andar específico no mesmo dia. Sobe de andar (ou espera o dia
# virar) pra voltar a dropar ali.
MAX_DROPS_PER_FLOOR_PER_DAY = 100


def _check_and_consume_daily_drop_limit(p: dict, floor: int) -> bool:
    """Retorna True se ainda houver 'cota' de drop pra esse andar hoje —
    e, se retornar True, já consome 1 unidade dessa cota."""
    import datetime
    hoje = datetime.date.today().isoformat()

    registro = p.setdefault("daily_drop_limit", {"date": hoje, "floors": {}})
    if registro.get("date") != hoje:
        registro["date"] = hoje
        registro["floors"] = {}

    floor_key = str(floor)
    usados = registro["floors"].get(floor_key, 0)
    if usados >= MAX_DROPS_PER_FLOOR_PER_DAY:
        return False

    registro["floors"][floor_key] = usados + 1
    return True


def xp_por_monstro(andar: int, tipo: str = "normal", na_raid: bool = False) -> int:
    """XP de um monstro morto. Uma função só, pra que a auditoria meça o
    MESMO número que o combate paga.

    ✨ 20/09/2026: era `base_xp = 10` FIXO, do andar 1 ao 100 — enquanto o
    custo do nível sobe (`xp_next = 100 + 50*(nível-1)`) e o teto de nível
    é `andar*2`, o que OBRIGA a subir. Medido no pior caso (nível no teto):
        andar 1 → 15 kills por nível
        andar 25 → 255 kills
        andar 50 → 505 kills
        andar 100 → 1.005 kills
    A Torre ficava exponencialmente mais lenta conforme o jogador subia,
    que é o contrário do que o teto pede. Com `10 + andar*4` o ritmo fica
    CONSTANTE em ~11 a 25 kills por nível do andar 1 ao 100: o andar segue
    mandando no poder, e deixa de mandar no tempo de farm.

    Elite e boss valem o que custam pra matar — antes valiam igual a um
    monstro comum, então parar pra lutar com eles era prejuízo de tempo.
    """
    # 🎯 26/09/2026 (dev): monstro COMUM vale 10 FIXO em toda a Torre; só
    # elite, general e boss crescem com o andar. Medido: do andar 20 em
    # diante quase não há comum (9% no 20, 0% do 30 em diante — pesos_do_andar),
    # então a mudança pesa só no começo: andar 5 foi de ~13 pra ~18 kills por
    # nível, andar 10 de ~14 pra ~19; do 30 ao 100 fica igual (~12).
    escala = 10 + max(1, int(andar)) * 4
    t = str(tipo or "normal").lower()
    if t == "boss":
        base = escala * 5
    elif t in ("elite", "general"):
        base = escala * 2
    else:
        base = 10                     # comum: fixo em toda a Torre
    if na_raid:
        base *= 10   # a raid continua valendo 10x
    return int(base)


def _on_enemy_killed(p: dict, ei: int) -> list[str]:
    cmb = p.get('combat')
    if not cmb:
        return []

    e = cmb['enemies'].pop(ei)
    cmb['target'] = min(cmb.get('target', 0), max(0, len(cmb['enemies']) - 1))
    # 👑 chefe da Torre vencido: registra (é o que abre o portal do andar)
    if str(e.get("tipo")) == "boss" and not (p.get("explore_mode") or p.get("wave_mode")
                                             or p.get("tower_mode") == "RAID" or p.get("raid_room_id")):
        andar_chefe = int(p.get("tower_floor") or 1)
        vencidos = p.setdefault("chefes_vencidos", [])
        if andar_chefe not in vencidos:
            vencidos.append(andar_chefe)
            p["_portal_do_chefe"] = True

    # --- CHECA O VIP ---
    mult = vip_mult(p)
    vip_tag = " 👑(VIP)" if mult > 1 else ""

    # 🪙 20/09/2026 (dev): monstro da Torre e da Raid NÃO dropa mais ouro —
    # ouro vem só do que o reino paga (login, diárias...). O cálculo de
    # bônus de pet/montaria abaixo segue rodando sobre 0 (inofensivo); o que
    # sobrou do abate é XP, cores e material. A morte conta pra DIÁRIA.
    reward_gold = 0
    try:
        from game import diarias as _D
        _D.contar(p, "raid" if (p.get("tower_mode") == "RAID" or p.get("raid_room_id")) else "torre")
    except Exception:
        pass

    # 🔥 PETS: bônus de ouro e de chance de drop (antes só decorativos)
    from game.pets_db import get_pet_bonuses
    _pet_eco = get_pet_bonuses(p)
    if _pet_eco.get("gold"):
        reward_gold = int(reward_gold * (1.0 + _pet_eco["gold"]))

    # 🔥 MONTARIA: bônus de ouro/XP só na exploração solo da torre (não na
    # raid, pra não empilhar com o bônus dos pets que já vale lá)
    em_raid_reward = bool(p.get("tower_mode") == "RAID" or p.get("raid_room_id"))
    _mount_bonus_gold_pct = 0.0
    _mount_bonus_xp_pct = 0.0
    if not em_raid_reward:
        from game.mounts import get_equipped_mount_bonus
        _mount = get_equipped_mount_bonus(p)
        _mech = _mount.get("mechanic", {})
        if _mech.get("type") == "explore_gold_pct":
            _mount_bonus_gold_pct = _mech.get("value", 0)
        elif _mech.get("type") == "explore_xp_pct":
            _mount_bonus_xp_pct = _mech.get("value", 0)
        if _mount_bonus_gold_pct:
            reward_gold = int(reward_gold * (1.0 + _mount_bonus_gold_pct))

    andar_do_mob = max(1, int(e.get("floor", p.get("tower_floor", 1)) or 1))
    na_raid = bool(p.get("tower_mode") == "RAID" or p.get("raid_room_id"))
    base_xp = xp_por_monstro(andar_do_mob, e.get("tipo", "normal"), na_raid)

    reward_xp = base_xp * mult  # Aplica o multiplicador do VIP no XP final
    if _mount_bonus_xp_pct:
        reward_xp = int(reward_xp * (1.0 + _mount_bonus_xp_pct))

    _nivel_antes = int(p.get("level") or 1)
    msg_xp = gain_xp(p, reward_xp)
    # 🎁 (28/09, dev) janela de recompensa no fim da luta: os ganhos de cada
    # abate se somam DENTRO do combate (que é salvo entre um toque e outro)
    # e viram um pacote só na vitória (_after_floor_victory).
    _ganhos = (p.get("combat") or {}).setdefault("ganhos", {"xp": 0, "cores": {}, "material": {}})
    if p.get("_last_xp_capped"):
        _ganhos["xp_travado"] = True
    else:
        _ganhos["xp"] = int(_ganhos.get("xp", 0)) + int(reward_xp)
    if int(p.get("level") or 1) > _nivel_antes:
        _ganhos["nivel"] = int(p["level"])

    # ⛏️ 20/09/2026: MATERIAL DA TORRE. O monstro deixa material do rank do
    # andar dele, que vai pra mochila do personagem e é o que a Forja gasta
    # primeiro. Ver `clan_materiais.material_do_monstro`.
    _msg_material = ""
    try:
        from game.clan_materiais import material_do_monstro, RANKS as _RANKS
        _rank, _qtd = material_do_monstro(andar_do_mob, e.get("tipo", "normal"), random)
        if _qtd:
            _mochila = p.setdefault("materiais_torre", {})
            _mochila[str(_rank)] = int(_mochila.get(str(_rank), 0)) + _qtd
            _msg_material = f"⛏️ +{_qtd} material {_RANKS[_rank]['nome']} (rank {_rank})\n"
            _nm = _RANKS[_rank]["nome"]
            _ganhos["material"][_nm] = int(_ganhos["material"].get(_nm, 0)) + int(_qtd)
    except Exception:
        _msg_material = ""
    pool = e.get('cores_drop') or []
    tipo_do_monstro = str(e.get('tipo', 'normal')).lower()
    
    try:
        cid = random.choice(pool) if pool else drop_core_roll(int(p.get('tower_floor', 1)), tipo_do_monstro)
    except ImportError:
        cid = random.choice(pool) if pool else None

    # ========================================================
    # 🔒 SISTEMA DE DROP DE SKILLS (Focado na Classe/Especialidade)
    # ========================================================
    if cid:
        try:
            from game.logic import get_specialty_slots
            
            # Verifica se o drop sorteado é uma SKILL (ignora itens de forja como wa_atk)
            if cid in SKILL_DB:
                
                # 1. TAXA DE DROP RARA
                chance_drop_skill = 15 # 15% de chance de realmente dropar a magia
                if _pet_eco.get("drop"):
                    chance_drop_skill += _pet_eco["drop"] * 100  # bônus dos pets em pontos percentuais
                
                if random.randint(1, 100) > chance_drop_skill:
                    cid = None # Falhou na chance, a magia vira pó (não dropa nada)
                else:
                    # 2. OBRIGA a magia a ser da Classe ou Especialidade do jogador
                    p_class = str(p.get("class", p.get("class_id", ""))).lower()
                    p_specs = get_specialty_slots(p)
                    
                    skills_validas = []

                    # 🌟 SEM CLASSE AINDA (08/07/2026): antes, o jogador sem
                    # classe NUNCA recebia drop de skill — a lista ficava vazia
                    # e o drop virava pó. Agora ele dropa a skill inicial
                    # "Golpe Firme" (a única sem req_class), que é o que a
                    # missão inicial pede. Core repetido evolui ela.
                    if not p_class or p_class in ("none", "null"):
                        skills_validas = ["core_starter_1"]
                    else:
                        # Varre o banco de skills procurando as que servem pra ele
                        for k_id, k_data in SKILL_DB.items():
                            sk = k_data.get("skill", {})
                            r_class = sk.get("req_class")
                            r_spec = sk.get("req_spec")

                            # Se a magia pede a classe dele
                            if r_class and r_class.lower() == p_class:
                                skills_validas.append(k_id)
                            # Se a magia pede a especialidade e ele tem ela equipada
                            elif r_spec and r_spec in p_specs:
                                skills_validas.append(k_id)
                            
                    # Se achou magias compatíveis, sorteia uma delas pra ele!
                    if skills_validas:
                        cid = random.choice(skills_validas)
                    else:
                        cid = None # Se não tiver nenhuma magia pro cara, não dropa lixo no inventário
                        
        except ImportError:
            pass

    # ========================================================
    # 🌟 SKILL INICIAL (08/07/2026) — chance PRÓPRIA, DEPOIS do funil acima
    # ========================================================
    # Precisa ficar AQUI, e não junto do sorteio lá em cima: o filtro de
    # skill acima aplica 15% de "vira pó" em qualquer core de skill, e
    # anularia esse drop em 85% das vezes.
    # Motivo de existir: o caminho normal é 5% (sortear skill) x 15% (não
    # virar pó) = 0,75% efetivo, ~133 batalhas em média. Pior: onde o
    # monstro tem pool fixo (o Goblin do Andar 1 só dropa 'wa_atk') seria
    # 0% pra sempre. Como aprender essa skill é MISSÃO INICIAL obrigatória,
    # ela precisa de um caminho próprio e generoso — senão o jogador novo
    # trava logo na entrada do jogo. Só vale pra quem ainda não tem classe.
    _sem_classe = not str(p.get("class", p.get("class_id", "")) or "").strip()
    if _sem_classe and random.randint(1, 100) <= 20:
        cid = "core_starter_1"

    # ------------------------------
    # Converte para core tierizada
    # ------------------------------
    tier = int(e.get('tier', 1))
    if cid:
        # só tieriza cores de forja / status (não mexe em core_fire, etc.)
        forge_ids = {"wa_atk", "ar_def", "ac_atk", "ac_def", "crit", "acc", "eva", "spd", "reg"}
        if tier > 1 and cid in forge_ids:
            cid = f"{cid}_t{tier}"

    # Adiciona a tag visual se o XP veio em dobro
    # 🐛 (28/09) no teto de nível do andar o gain_xp não dá nada, mas a
    # vitória dizia "+10 XP" do mesmo jeito — o jogador lutava de graça sem
    # saber que precisava subir de andar.
    if p.get("_last_xp_capped"):
        teto = int(p.get("tower_floor", 1)) * 2
        res = [f"\n🔒 XP travado: nível {teto} é o máximo deste andar — suba de andar pra continuar evoluindo.\n"]
    else:
        res = [f"\n+{reward_xp} XP{vip_tag}.\n"]
    if _msg_material:
        res.append(_msg_material)

    # 🔥 ANTI-FARM: limite diário de drop por andar (só na torre solo — a
    # raid já é naturalmente limitada e cooperativa, então fica de fora)
    em_raid = bool(p.get("tower_mode") == "RAID" or p.get("raid_room_id"))
    if cid and not em_raid:
        andar_atual = int(p.get("tower_floor", 1))
        if not _check_and_consume_daily_drop_limit(p, andar_atual):
            cid = None
            res.append(
                f"🔒 Você já atingiu o limite de drops de hoje no Andar {andar_atual} "
                f"({MAX_DROPS_PER_FLOOR_PER_DAY}/dia). Suba de andar pra continuar dropando!\n"
            )

    # 🖼️ Marca o tipo do drop pra escolher a imagem genérica certa na tela
    # de "saiu da batalha" (só ouro/XP, core de skill, ou core de forja).
    if not cid:
        p["_last_drop_type"] = "gold"
    elif cid in SKILL_DB:
        p["_last_drop_type"] = "skill"
    else:
        p["_last_drop_type"] = "craft"

    # -------------------------------------------------------------
    # 2. SE CAIU UM CORE, COLOCA NA MOCHILA E BUSCA O NOME BONITO
    # -------------------------------------------------------------
    if cid:
        qtd_drop = 1 * mult  # Aplica o multiplicador do VIP no Drop
        
        # Salva na mochila de forma segura
        try:
            inv_add_stack(p['inv'], cid, qtd_drop)
        except ImportError:
            cores_inv = p.setdefault('inv', {}).setdefault('cores', {})
            cores_inv[cid] = cores_inv.get(cid, 0) + qtd_drop

        # Tenta buscar o nome bonito formatado no Items.py ou Skills.py
        try:
            nome_bonito = core_name(cid)
            
            # Se a função retornou o próprio ID, procura no SKILL_DB
            if nome_bonito == cid:
                try:
                    # Correção: O nome da skill costuma ficar dentro de ["skill"]["name"]
                    nome_bonito = SKILL_DB.get(cid, {}).get("skill", {}).get("name", cid)
                except ImportError:
                    pass
        except ImportError:
            nome_bonito = cid
            
        # Limpa o texto se mesmo assim ele ficar feio
        if nome_bonito == cid:
            nome_bonito = f"Core de {cid.replace('core_', '').replace('_', ' ').title()}"

        # Mostra o x2 no log caso seja VIP
        res.append(f"\n💎 Drop: <b>{nome_bonito}</b> x{qtd_drop} (Tier {tier})💎{vip_tag}\n")
        _c = _ganhos["cores"].setdefault(cid, {"nome": nome_bonito, "qtd": 0, "tier": tier,
                                               "skill": cid in SKILL_DB})
        _c["qtd"] = int(_c["qtd"]) + int(qtd_drop)

    if msg_xp:
        res.append(msg_xp)

    return res




# ==============================================================
# NOVOS HANDLERS DE COMBATE E RAID (SEPARAÇÃO DE CONTEXTOS)
# ==============================================================

def handle_normal_combat(p: dict, data: str) -> tuple:
    """Trata combate da torre SOLO, ignorando se estiver em RAID."""
    # Retorna tupla: (mensagem/view, estado)
    
    if p.get("tower_mode") == "RAID":
        return view_city(p, "❌ Use os botões da RAID, não da torre!"), "CITY"

    cmb = p.get("combat")
    if not cmb or not cmb.get("enemies"):  
        return view_tower(p, "⚠️ O combate já terminou!"), "TOWER"

    # Força o estado correto se tiver combate ativo
    p["state"] = "COMBAT"
    msg = ""

    # Executa a ação
    if data == "combatattack" or data == "combat:attack":
        msg = combat_attack(p)
    elif data == "combatpotion" or data == "combat:potion":
        msg = _combat_potion_atb(p)
    elif data.startswith("combatskill:") or data.startswith("combat:skill:"):
        skill_id = data.split(":")[-1]
        msg = execute_combat_skill(p, skill_id)
    elif data.startswith("combattarget") or data.startswith("combat:target:"):
        delta = int(data.split(":")[-1])
        msg = combat_target_shift(p, delta)
    elif data == "combatflee" or data == "combat:flee":
        msg = combat_flee(p)
        p["state"] = "TOWER"
        
        return view_tower(p, msg), "TOWER"
    else:
        msg = "Ação inválida no combate."

    # Checa morte
    if p.get("state") == "DEAD" or p.get("hp", 0) <= 0:
        on_player_death(p)
        
        return view_dead_screen(p, msg), "DEAD"
        
    # Checa vitória local
    combat = p.get("combat")
    if not combat or "enemies" not in combat or all(e.get("hp", 0) <= 0 for e in combat["enemies"]):
        p["state"] = "TOWER"
        
        return view_tower(p, msg), "TOWER"

    # Se ainda tá lutando
    
    return view_combat(p, msg), "COMBAT"


def handle_raid_lobby(p: dict, data: str) -> tuple:
    """Trata lobby da raid: pronto, poção, sair."""

    room_id = p.get("raid_room_id")
    room = get_room(room_id) if room_id else None

    if not room:
        raid_cleanup_player_state(p)
        return view_city(p, "❌ Sala de raid não encontrada. Você foi devolvido à cidade."), "CITY"

    msg = ""
    # Trata as variações antigas e novas de callback
    if data in ["raidready", "raid:ready"]:
        msg = raid_set_ready(p, True)
    elif data in ["raidnotready", "raid:not_ready"]:
        msg = raid_set_ready(p, False)
    elif data in ["raidusepotion", "raid:use_potion"]:
        msg = use_potion(p)
    elif data in ["raidflee", "raid:flee"]:
        msg = raid_flee(p)
        if "abandonou" in msg.lower() or "saiu" in msg.lower():
            return view_city(p, msg), "CITY"
    else:
        msg = "Ação inválida no lobby da raid."

    # Se ao dar 'ready' a batalha começou
    if "batalha começou" in msg.lower():
        p["state"] = "RAID_COMBAT"

        return view_raid_combat(p, msg), "RAID_COMBAT"

    return view_raid_lobby(p, msg), "RAID_LOBBY"





def raid_cleanup_player_state(p: dict):
    """Limpa sobras de estado do jogador se ele for ejetado da raid ou sala acabar."""
    p["raid_room_id"] = None
    p["tower_mode"] = "NORMAL"
    p["raid_floor"] = 1
    p["raid_ready"] = False
    p["combat"] = None
    p["state"] = "CITY"


def raid_finish_floor(room: dict):
    """Centraliza a vitória: limpa combate, avança andar, devolve a sala pro lobby."""
   
    room["state"] = "LOBBY"
    room["combat"] = None
    room["floor"] += 1
    
    if "ready_map" in room:
        for m in room["members"]: 
            room["ready_map"][m] = False
            
    save_room(room)
# ===== RAID: FUNÇÕES CRÍTICAS AUSENTES =====


def raid_toggle_open(p: dict, open_flag: bool) -> str:
    room_id = p.get("raid_room_id")
    if not room_id:
        return "❌ Sala não encontrada.\n"

    room = get_room(room_id)
    if not room:
        return "❌ Sala não encontrada.\n"

    pid = raid_get_pid(p)
    if str(room.get("leader_pid")) != pid:
        return "❌ Só o líder pode abrir/fechar a sala.\n"

    room["open"] = bool(open_flag)
    save_room(room)

    if open_flag:
        return "✅ Sala aberta. Agora aparece em 'Entrar em Party'.\n"
    else:
        return "✅ Sala fechada. Ninguém novo entra pela lista.\n"
        

# =========================
# NOVO COMBATE RAID (JSON)
# =========================

import threading

def _force_afk_attack(room_id: int, pid: str, expected_turn: int) -> None:
    """Disparado após 20 segundos. Se o turno não mudou, força ataque."""
    
    room = get_room(room_id)
    if not room or room.get("state") != "RAID_COMBAT": return
    rs = room.get("raid_state")
    if not rs or rs.get("turn_count", 0) != expected_turn: return
    
    p = load_player(int(pid))
    if p:
        p["raid_room_id"] = room_id
        raid_player_attack(p, is_afk=True)


def _raid_end_of_turn(room: dict) -> str:
    from game.logic import raid_distribute_loot, raid_handle_player_death, _raid_enemy_turn, _raid_fill_atb, try_raid_revive
    import time
    
    rs = room["raid_state"]
    # 🔥 AQUI ESTÁ A CHAVE CERTA: Agora puxamos a lista de 5 "enemies", e não mais o "boss"!
    enemies = rs.get("enemies", [])
    logs = rs.setdefault("logs", [])
    
    def check_enemies_death():
        if all(e["hp"] <= 0 for e in enemies):
            logs.append("🏆 Todos os monstros foram derrotados!")

            # =========================================================
            # 🗡️ TRAIÇÃO (08/07/2026): se alguém declarou traição durante o
            # combate, em vez de ir direto pro loot/lobby, os sobreviventes
            # entram numa fase de PvP entre eles. Quem morre aqui perde
            # TODOS os itens equipados, divididos entre os traidores vivos.
            # =========================================================
            traidores = set(rs.get("traidores", []))
            vivos_pids = [pid for pid, pl in rs.get("players", {}).items()
                          if pl.get("hp", 0) > 0 and not pl.get("dead")]
            traidores_vivos = traidores & set(vivos_pids)

            if traidores_vivos and len(vivos_pids) >= 2:
                logs.append("🗡️💀 <b>TRAIÇÃO!</b> Uma ou mais lâminas se voltam contra a própria party...")
                _raid_start_pvp_phase(room, rs, logs)
                rs["_betrayal_triggered"] = True
                return True

            if enemies:
                raid_distribute_loot(room, enemies[0], logs) # Usa o primeiro inimigo como base do loot

            # 🩸 (08/07/2026): a batalha acabou — quem ficou caído e não foi
            # ressuscitado a tempo agora morre de verdade (perde o ouro e sai
            # da raid). Tem que rodar ANTES de zerar o raid_state, senão a
            # função não acha mais os jogadores.
            _raid_finalizar_caidos(room)

            room["last_combat_log"] = "\n".join(logs)
            room["raid_state"] = None
            room["combat"] = None
            room["state"] = "LOBBY"
            room["floor"] = int(room.get("floor", 1)) + 1
            
            if "ready_map" in room:
                for m_id in room.get("members", []):
                    room["ready_map"][m_id] = False
                    try:
                        pdata = load_player(int(m_id))
                        if pdata:
                            pdata["state"] = "RAID_LOBBY"
                            pdata["combat"] = None
                            save_player_sql(int(m_id), pdata)
                    except:
                        pass
            return True
        return False

    if check_enemies_death():
        save_room(room)
        if rs.get("_betrayal_triggered"):
            return "🗡️💀 TRAIÇÃO! A luta agora é entre vocês..."
        return "🏆 Vitória! A sala foi limpa!"

    while True:
        tipo, alvo_pid = _raid_fill_atb(room)
        if not tipo: break 

        # --- TURNO DOS INIMIGOS ---
        if tipo == "enemy":
            idx = int(alvo_pid.split("_")[1])
            enemy = enemies[idx]
            
            dots = enemy.get("dots", [])
            if dots:
                novos_dots = []
                atordoou = False
                for d in dots:
                    turns = d.get("turns", 0)
                    if turns > 0:
                        dmg = d.get("dmg", 0)
                        enemy["hp"] -= dmg
                        logs.append(f"🔥 {enemy['name']} sofreu {dmg} de {d.get('name', 'efeito')}.")
                        if not atordoou and d.get("stun_chance", 0) > random.randint(1, 100):
                            atordoou = True
                        turns -= 1
                        if turns > 0:
                            d["turns"] = turns
                            novos_dots.append(d)
                enemy["dots"] = novos_dots
                if atordoou:
                    enemy["stun"] = enemy.get("stun", 0) + 1
                    logs.append(f"🐍 O veneno atordoou {enemy['name']}!")

                if check_enemies_death():
                    save_room(room)
                    if rs.get("_betrayal_triggered"):
                        return "🗡️💀 TRAIÇÃO! A luta agora é entre vocês..."
                    return "🏆 Vitória!"
                    
                if enemy["hp"] <= 0:
                    rs["atb"][alvo_pid] = 0.0
                    continue

            if enemy.get("stun", 0) > 0:
                enemy["stun"] -= 1
                logs.append(f"💫 {enemy['name']} está atordoado e perdeu a vez!")
                rs["atb"][alvo_pid] = 0.0
                continue
                
            _raid_enemy_turn(room, idx)
            
            vivos = [pid for pid, pl in rs.get("players", {}).items() if pl.get("hp", 0) > 0 and not pl.get("dead")]
            if not vivos:
                # 🩸 (08/07/2026): ninguém de pé = ninguém pra ressuscitar.
                # Quem estava caído esperando agora morre de verdade.
                _raid_finalizar_caidos(room)
                room["state"] = "WIPE"
                save_room(room)
                return "💀 WIPE! A party foi aniquilada."
        
        # --- TURNO DOS JOGADORES ---
        elif tipo == "player" and alvo_pid:
            pl = rs["players"].get(alvo_pid)
            if not pl or pl.get("hp", 0) <= 0 or pl.get("dead", False):
                rs["atb"][alvo_pid] = 0.0 
                continue

            dots = pl.get("dots", [])
            if dots:
                novos_dots = []
                for d in dots:
                    turns = d.get("turns", 0)
                    if turns > 0:
                        dmg = d.get("dmg", 0)
                        pl["hp"] -= dmg
                        logs.append(f"🤢 {pl['name']} sofreu {dmg} de {d.get('name', 'efeito')}.")
                        turns -= 1
                        if turns > 0:
                            d["turns"] = turns
                            novos_dots.append(d)
                pl["dots"] = novos_dots
                
                # =========================================================
                # 🔥 O INTERCEPTADOR DE MORTE POR VENENO
                # =========================================================
                if pl["hp"] <= 0:
                    # Se ele reviver, a gente simplesmente foge desse bloco e ele continua vivo!
                    if try_raid_revive(pl, alvo_pid, logs):
                        continue
                        
                    pl["hp"] = 0
                    pl["dead"] = True
                    logs.append(f"💀 {pl['name']} caiu devido a veneno!")
                    rs["atb"][alvo_pid] = 0.0 
                    
                    raid_handle_player_death(room, alvo_pid)
                    
                    vivos_restantes = [p_id for p_id, p_data in rs.get("players", {}).items() if p_data.get("hp", 0) > 0 and not p_data.get("dead")]
                    if not vivos_restantes:
                        # 🩸 (08/07/2026): sem ninguém de pé, os caídos morrem
                        _raid_finalizar_caidos(room)
                        room["state"] = "WIPE"
                        save_room(room)
                        return "💀 WIPE! A party foi aniquilada pelo veneno."
                    continue 

            # 🔥 Regeneração ao longo do tempo (HoT) e contagem regressiva
            # dos buffs (buff_atk/def/eva) — mesmo esquema dos DoTs, só que
            # bom em vez de ruim.
            _raid_tick_buffs_and_hots(pl, logs)

            if pl.get("stun", 0) > 0:
                pl["stun"] -= 1
                logs.append(f"💫 {pl['name']} está atordoado e perdeu a vez!")
                rs["atb"][alvo_pid] = 0.0 
                continue 

            turn = rs.setdefault("turn_count", 0) + 1
            rs["turn_count"] = turn
            rs["turn_start_time"] = int(time.time())
            rs["awaiting_pid"] = alvo_pid
            break 

    save_room(room)
    return "⚔️ Atualizado!"


def try_raid_revive(pl: dict, pid: str, logs: list) -> bool:
    """A MÁGICA: Intercepta a morte ANTES de acionar o handle_dead."""
    from game.logic import get_combat_triggers, get_specialty_slots
    
    p_data = load_player(int(pid))
    if not p_data: return False
    
    # Força a leitura das especialidades no banco!
    get_specialty_slots(p_data)
    trigs = get_combat_triggers(p_data)
    
    if trigs.get("immortal_1hp_once") and not pl.get("used_immortal"):
        pl["used_immortal"] = True
        pl["hp"] = 1
        logs.append(f"💢 RESILIÊNCIA INUMANA! {pl['name']} sobreviveu ao golpe fatal com 1 de HP!\n")
        return True
        
    if trigs.get("auto_revive_once") and not pl.get("used_revive"):
        pl["used_revive"] = True
        pl["hp"] = max(1, int(pl.get("hp_max", 100) * 0.5))
        logs.append(f"✨ MILAGRE! {pl['name']} ressuscitou das cinzas para continuar a luta!\n")
        return True
        
    return False
    
def _raid_enemy_turn(room: dict, enemy_idx: int) -> None:
    from game.logic import raid_handle_player_death, try_raid_revive
    import random

    rs = room.get("raid_state") or {}
    enemy = rs["enemies"][enemy_idx]
    players = rs.get("players") or {}
    atb = rs.get("atb") or {}
    logs = rs.setdefault("logs", [])

    # =========================================================
    # ☠️ PROCESSAR DoTs NO BOSS (Antes dele agir)
    # =========================================================
    alive_dots = []
    for dot in enemy.get("dots", []):
        dmg_veneno = dot.get("dmg", 0)
        enemy["hp"] = max(0, enemy.get("hp", 0) - dmg_veneno)
        logs.append(f"☠️ {enemy['name']} sofreu {dmg_veneno} de dano ({dot.get('name', 'Efeito')})!")
        dot["turns"] -= 1
        if dot["turns"] > 0:
            alive_dots.append(dot)
    enemy["dots"] = alive_dots

    vivos = [pid for pid, pl in players.items() if pl.get("hp", 0) > 0 and not pl.get("dead")]
    
    # Se todos morreram ou o Boss sucumbiu ao veneno:
    if not vivos or enemy.get("hp", 0) <= 0: return

    # 🛡️ TAUNT: se alguém provocou, o alvo de ataque ÚNICO (não em área) é
    # forçado nele — protege o resto do grupo enquanto durar.
    vivos_provocando = [pid for pid in vivos if players[pid].get("taunt_active", 0) > 0]
    pool_alvo_unico = vivos_provocando if vivos_provocando else vivos

    atk = int(enemy.get("atk", 10))
    acc_boss = int(enemy.get("acc", 10))
    crit_boss = int(enemy.get("crit", 5))
    
    # 💚 regeneração do boss da Raid (25/09): mesmo teto de 5%/turno da Torre
    _reg = int(enemy.get("reg", 0))
    if _reg > 0 and 0 < int(enemy.get("hp", 0)) < int(enemy.get("hp_max", 1)):
        enemy["hp"] = min(int(enemy["hp_max"]), int(enemy["hp"]) + _reg)
        logs.append(f"👹 {enemy.get('name', 'Boss')} regenerou +{_reg} HP")

    boss_skills = enemy.get("skills", [])
    usou_skill = False
    
    # =========================================================
    # 💥 BOSS USA UMA MAGIA / HABILIDADE
    # =========================================================
    if boss_skills and random.random() < chance_skill_do_boss(int(enemy.get("floor", 1))):
        skill_id = random.choice(boss_skills)
        sk_data = get_skill_by_id(skill_id)
        
        if sk_data:
            sk = sk_data.get("skill", {})
            nome_magia = sk.get("name", "Magia")
            mult = float(sk.get("mult", 0))
            dmg_pct = float(sk.get("dmg_percent", 0) or sk.get("dmgpercent", 0))
            
            base_dmg = int(atk * mult) if mult else int(atk * dmg_pct / 100.0) if dmg_pct else atk
            target_type = sk.get("target", "single")
            dot_mult = float(sk.get("dotmult", 0) or sk.get("dot_mult", 0))
            dot_turns = int(sk.get("dotturns", 0) or sk.get("dot_turns", 0))
            stun_turns = int(sk.get("stun", 0))
            
            logs.append(f"✨ {enemy['name']} conjurou {nome_magia}!")
            alvos = vivos if target_type == "all" else [random.choice(pool_alvo_unico)]
            
            for pid in alvos:
                pl = players[pid]
                dano_bruto = max(1, base_dmg - _raid_effective_stat(pl, "def", int(pl.get("def", 0))))
                dano_final = max(1, dano_bruto + random.randint(-1, 2))
                
                is_crit = False
                _mcrit = multiplicador_de_critico(crit_boss, _raid_effective_stat(pl, "eva", int(pl.get("eva", 0))))
                if _mcrit:
                    dano_final = int(dano_final * _mcrit)
                    is_crit = True
                
                # 🛡️ Aplicar Dano no Escudo do Jogador Primeiro!
                escudo = pl.get("shield", 0)
                if escudo > 0:
                    if escudo >= dano_final:
                        pl["shield"] -= dano_final
                        logs.append(f" 🛡️ O Escudo de {pl['name']} absorveu todo o dano ({dano_final})!")
                        dano_final = 0
                    else:
                        logs.append(f" 🛡️ O Escudo de {pl['name']} foi destruído! (-{escudo})")
                        dano_final -= escudo
                        pl["shield"] = 0
                        # 🔥 Baluarte: chance do escudo se regenerar na hora
                        try:
                            p_data_shield = load_player(int(pid))
                            trigs_shield = get_combat_triggers(p_data_shield) if p_data_shield else {}
                        except Exception:
                            trigs_shield = {}
                        if trigs_shield.get("shield_refresh_chance", 0) > random.randint(1, 100):
                            novo_escudo = max(1, int(escudo * 0.5))
                            pl["shield"] = novo_escudo
                            logs.append(f" 🔄 O Escudo de {pl['name']} se regenerou! (+{novo_escudo})")

                if dano_final > 0:
                    if is_crit:
                        logs.append(f" 💥 CRÍTICO MAGICO! {pl['name']} recebeu {dano_final} de dano.")
                    else:
                        logs.append(f" 💥 {pl['name']} recebeu {dano_final} de dano.")
                        
                    pl["hp"] = max(0, pl.get("hp", 0) - dano_final)
                    _raid_check_stun_on_hit(pl, enemy, dano_final, logs)

                if dot_mult > 0 and dot_turns > 0:
                    dmg_dot = max(1, int(atk * dot_mult))
                    pl.setdefault("dots", []).append({"name": sk.get("dotname", "efeito"), "dmg": dmg_dot, "turns": dot_turns})
                    logs.append(f" 🧪 {pl['name']} sofreu {sk.get('dotname', 'efeito')}!")
                    
                if stun_turns > 0:
                    pl["stun"] = pl.get("stun", 0) + stun_turns
                    logs.append(f" 💫 {pl['name']} foi atordoado!")
                    
                if pl["hp"] <= 0:
                    # O INTERCEPTADOR (SEGURANÇA)
                    if not try_raid_revive(pl, pid, logs):
                        raid_handle_player_death(room, pid)
                        atb[pid] = 0.0

            usou_skill = True

    # =========================================================
    # ⚔️ BOSS USA UM ATAQUE FÍSICO BÁSICO
    # =========================================================
    if not usou_skill:
        is_aoe = random.random() < 0.3
        alvos = vivos if is_aoe else [random.choice(pool_alvo_unico)]
        if is_aoe: logs.append(f"🌪️ {enemy['name']} lançou um ataque bruto em área!")
        
        for pid in alvos:
            pl = players[pid]
            eva_pl = _raid_effective_stat(pl, "eva", int(pl.get("eva", 5)))
            chance_acerto = max(20, min(100, 100 + acc_boss - eva_pl))
            
            if random.randint(1, 100) > chance_acerto:
                logs.append(f"💨 {pl['name']} esquivou do ataque de {enemy['name']}!")
            else:
                dano_bruto = max(1, atk - int(pl.get("def", 0)))
                dano_final = max(1, dano_bruto + random.randint(-1, 2))
                
                is_crit = False
                _mcrit = multiplicador_de_critico(crit_boss, _raid_effective_stat(pl, "eva", int(pl.get("eva", 0))))
                if _mcrit:
                    dano_final = int(dano_final * _mcrit)
                    is_crit = True

                # 🛡️ Aplicar Dano no Escudo do Jogador Primeiro!
                escudo = pl.get("shield", 0)
                if escudo > 0:
                    if escudo >= dano_final:
                        pl["shield"] -= dano_final
                        logs.append(f" 🛡️ O Escudo de {pl['name']} absorveu todo o dano ({dano_final})!")
                        dano_final = 0
                    else:
                        logs.append(f" 🛡️ O Escudo de {pl['name']} quebrou! (-{escudo})")
                        dano_final -= escudo
                        pl["shield"] = 0

                if dano_final > 0:
                    if is_crit:
                        logs.append(f"⚔️ CRÍTICO! {pl['name']} sofreu {dano_final} de dano{' (AoE)' if is_aoe else ''}.")
                    else:
                        logs.append(f"⚔️ {pl['name']} recebeu {dano_final} de dano{' (AoE)' if is_aoe else ''}.")
                
                pl["hp"] = max(0, pl.get("hp", 0) - dano_final)
                _raid_check_stun_on_hit(pl, enemy, dano_final, logs)
                
                if pl["hp"] <= 0:
                    # O INTERCEPTADOR (SEGURANÇA)
                    if not try_raid_revive(pl, pid, logs):
                        raid_handle_player_death(room, pid)
                        atb[pid] = 0.0

    atb[f"enemy_{enemy_idx}"] = max(0.0, float(atb.get(f"enemy_{enemy_idx}", 0.0)) - 100.0)



def raid_handle_player_death(room: dict, pid: str) -> None:
    """🩸 O jogador CAIU (08/07/2026) — mas ainda NÃO morreu de verdade.

    Antes, esta função matava na hora: cortava o ouro, marcava DEAD no
    banco, limpava o raid_room_id e removia o cara da sala. Com isso, a
    skill de Ressurreição do Curandeiro era inútil — quando ela rodasse,
    o alvo já tinha saído da raid.

    Agora ele fica "caído" na sala, esperando: ou um Curandeiro o revive,
    ou ele mesmo desiste (botão Seguir), ou a batalha acaba sem ninguém
    revivê-lo. Só nesses dois últimos casos a morte vira definitiva
    (ver raid_finalizar_morte).
    """
    rs = room.get("raid_state") or {}
    players = rs.get("players") or {}

    if pid not in players:
        return
    pl = players[pid]

    pl["hp"] = 0
    pl["dead"] = True
    pl["awaiting_revive"] = True

    logs = rs.setdefault("logs", [])
    logs.append(f"🩸 {pl.get('name', 'Um herói')} caiu! Pode ser ressuscitado enquanto a batalha durar.")

    # Marca o estado dele como CAÍDO (não DEAD) — sem penalidade nenhuma
    # ainda, e SEM tirar da sala: ele precisa continuar lá pra poder ser
    # alvo da ressurreição.
    try:
        pdata = load_player(int(pid))
        if pdata:
            pdata["state"] = "RAID_DOWN"
            pdata["hp"] = 0
            save_player_sql(int(pid), pdata)
    except Exception as e:
        print(f"ERRO AO MARCAR CAÍDO NA RAID: {e}")

    try:
        from infra.cache_bus import mark_dirty
        mark_dirty(int(pid))
    except Exception:
        pass

    rs["players"] = players
    save_room(room)


def _raid_finalizar_caidos(room: dict) -> None:
    """🩸 (08/07/2026): chamado quando a batalha acaba (wipe OU vitória).
    Quem estava caído esperando ressurreição e não foi revivido a tempo
    agora morre de verdade — segue o fluxo normal de morte (perde metade
    do ouro e sai da raid).

    Sem isso, o jogador ficaria preso pra sempre no estado RAID_DOWN,
    esperando uma ressurreição que nunca viria, numa batalha que já acabou.
    """
    rs = room.get("raid_state") or {}
    players = rs.get("players") or {}
    caidos = [pid for pid, pl in players.items() if pl.get("awaiting_revive")]
    for pid in caidos:
        raid_finalizar_morte(room, pid)


def raid_finalizar_morte(room: dict, pid: str) -> None:
    """☠️ O Ceifador. Morte ABSOLUTA — chamado quando o jogador desiste de
    esperar (botão Seguir) ou quando a batalha acaba e ninguém o reviveu.
    É o comportamento antigo de raid_handle_player_death."""
    rs = room.get("raid_state") or {}
    players = rs.get("players") or {}
    
    if pid not in players: return
    pl = players[pid]
    
    # 1. Mata o avatar dentro da sala
    pl["hp"] = 0
    pl["dead"] = True
    pl.pop("awaiting_revive", None)
    
    # 2. Fotografa o massacre para mostrar na tela de morte
    # 🔥 CORRIGIDO (08/07/2026): usava as últimas 10 linhas de log, o que
    # frequentemente passava de 1000 caracteres — aí o renderizador trocava
    # de "mensagem com foto" pra "texto puro", e essa troca o Telegram NÃO
    # deixa editar (só apagar e mandar outra). Reduzindo pra 4 linhas + um
    # corte de segurança, a mensagem quase sempre cabe e continua editável.
    logs = rs.get("logs", [])
    ultimos_logs = "\n".join(logs[-4:]) if logs else "Você foi esmagado impiedosamente."
    if len(ultimos_logs) > 500:
        ultimos_logs = ultimos_logs[:497] + "..."
    
    # 3. Morte absoluta no Banco de Dados
    try:
        pdata = load_player(int(pid))
        if pdata:
            pdata["gold"] = max(0, int(pdata.get("gold", 0) * 0.5))
            pdata["state"] = "DEAD"          
            pdata["hp"] = 0  # 🔥 GARANTIA DE HP ZERADO NO BANCO!
            pdata["raid_room_id"] = None
            pdata["combat"] = {
                "death_log": f"\n💀 <b>Últimos momentos na Raid:</b>\n<i>{ultimos_logs}</i>"
            }
            save_player_sql(int(pid), pdata)
    except Exception as e:
        print(f"ERRO MORTE RAID: {e}")

    try:
        from infra.cache_bus import mark_dirty
        mark_dirty(int(pid))
    except Exception:
        pass
    
    # 4. Remove o corpo da party e desmarca o "pronto"
    if "members" in room and pid in room["members"]:
        room["members"].remove(pid)
    if "ready_map" in room:
        room["ready_map"].pop(pid, None)
        
    rs["players"] = players
    room["raid_state"] = rs

import threading

def _force_afk_attack(room_id: int, pid: str, expected_turn: int) -> None:
    """Disparado após 20 segundos. Se o turno não mudou, força ataque."""
    
    room = get_room(room_id)
    if not room or room.get("state") != "RAID_COMBAT": return
    rs = room.get("raid_state")
    # Se o turn_count mudou, significa que o jogador (ou outro) já agiu
    if not rs or rs.get("turn_count", 0) != expected_turn: return
    
    p = load_player(int(pid))
    if p:
        p["raid_room_id"] = room_id
        raid_player_attack(p, is_afk=True) # Força o ataque básico

def _enemy_effective_atk(en: dict) -> int:
    """ATK do inimigo já com o debuff_atk aplicado, se houver.

    🔥 Corrigido (08/07/2026): 'debuff_atk' (Carapaça de Espinhos e Manto
    de Agonia, do Guardião) era a ÚNICA mecânica que não funcionava em
    motor nenhum — nem solo, nem raid. Estava no banco de skills e nunca
    foi lida em lugar algum.
    """
    base = int(en.get("atk", 1))
    debuffs = en.get("debuffs") or {}
    pct = float(debuffs.get("atk_pct", 0) or 0)
    if pct > 0 and int(debuffs.get("atk_turns", 0)) > 0:
        return max(1, int(base * (1.0 - pct)))
    return base


def _solo_effective_stat(p: dict, stat: str, base_value: int) -> int:
    """Aplica buff temporário (buff_atk/buff_def/buff_eva) por cima do stat
    base do jogador no combate SOLO (Torre).

    🔥 Corrigido (08/07/2026): a raid já tinha isso (_raid_effective_stat),
    mas o motor solo NUNCA aplicava buff nenhum — as 21 skills de buff
    (13 só de buff_def, a defesa inteira do Guardião) não faziam nada na
    Torre, que é o conteúdo principal do jogo. Os dois motores evoluíram
    separados e cada um implementava um pedaço diferente das mecânicas.
    """
    buffs = p.get("buffs") or {}
    b = buffs.get(stat)
    if b and int(b.get("turns", 0)) > 0:
        return max(0, int(base_value * (1.0 + float(b.get("pct", 0)))))
    return base_value


def _solo_apply_buff(p: dict, stat: str, pct: float, turns: int) -> None:
    """Guarda/renova um buff temporário do jogador no combate solo."""
    buffs = p.setdefault("buffs", {})
    buffs[stat] = {"pct": pct, "turns": turns}


def _solo_tick_buffs(p: dict) -> list:
    """Conta o tempo dos buffs do jogador no solo; devolve as mensagens de
    quem expirou."""
    msgs = []
    buffs = p.get("buffs") or {}
    for stat in list(buffs.keys()):
        b = buffs[stat]
        b["turns"] = int(b.get("turns", 0)) - 1
        if b["turns"] <= 0:
            buffs.pop(stat, None)
            nome = {"atk": "Ataque", "def": "Defesa", "eva": "Evasão"}.get(stat, stat.upper())
            msgs.append(f"⌛ Seu bônus de {nome} acabou.\n")
    return msgs


def _raid_effective_stat(pl: dict, stat: str, base_value: int) -> int:
    """Aplica um buff temporário (buff_atk/buff_def/buff_eva) por cima do
    stat base de um jogador dentro da raid, se ele tiver um ativo.
    🔥 Corrigido (08/07/2026): essas skills de suporte (Bênção do Campeão,
    Muralha Imortal, Falange de Cristal, etc) existiam no banco de skills
    mas NUNCA eram lidas em lugar nenhum do motor de combate — clicar
    nelas não fazia literalmente nada além de gastar o cooldown."""
    buffs = pl.get("buffs") or {}
    b = buffs.get(stat)
    if b and b.get("turns", 0) > 0:
        return max(0, int(base_value * (1.0 + b.get("pct", 0))))
    return base_value


def _raid_check_stun_on_hit(pl: dict, enemy: dict, dano: int, logs: list) -> None:
    """🪨 CONTRA-STUN na raid (08/07/2026): se o jogador tem o buff do
    Guardião ativo, quem bater nele pode ficar atordoado.
    Mesma correção do combate solo — a mecânica existia no banco de skills
    (Pele de Granito 15%, Armadura de Titã 30%, Colosso de Terra 50%) mas
    o motor nunca lia, então nunca acontecia nada."""
    import random
    if dano <= 0:
        return
    cs = pl.get("stun_on_hit") or {}
    if int(cs.get("turns", 0)) <= 0:
        return
    if random.randint(1, 100) <= float(cs.get("chance", 0)):
        enemy["stun"] = int(enemy.get("stun", 0)) + 1
        logs.append(f"🪨 {enemy.get('name', 'O inimigo')} se estatelou na pele de pedra de {pl.get('name', 'um herói')} e ficou atordoado!")


def _raid_tick_buffs_and_hots(pl: dict, logs: list) -> None:
    """Processa a regeneração ao longo do tempo (HoT) e decrementa a
    duração dos buffs ativos de um jogador — chame no início do turno dele."""
    hots = pl.get("hots") or []
    novos_hots = []
    for hot in hots:
        turns = int(hot.get("turns", 0))
        if turns <= 0:
            continue
        cura = max(0, int(hot.get("heal", 0)))
        if cura:
            pl["hp"] = min(int(pl.get("hp_max", 1)), int(pl.get("hp", 0)) + cura)
            logs.append(f"💚 {pl.get('name', 'Jogador')} regenerou {cura} HP.")
        turns -= 1
        if turns > 0:
            hot["turns"] = turns
            novos_hots.append(hot)
    pl["hots"] = novos_hots

    buffs = pl.get("buffs") or {}
    for stat_key in list(buffs.keys()):
        b = buffs[stat_key]
        b["turns"] = int(b.get("turns", 0)) - 1
        if b["turns"] <= 0:
            del buffs[stat_key]
    pl["buffs"] = buffs

    if pl.get("taunt_active", 0) > 0:
        pl["taunt_active"] -= 1

    # 🪨 Tick do contra-stun (08/07/2026)
    cs = pl.get("stun_on_hit")
    if cs:
        cs["turns"] = int(cs.get("turns", 0)) - 1
        if cs["turns"] <= 0:
            pl.pop("stun_on_hit", None)


# =============================================================================
# 🗡️ TRAIÇÃO NA RAID (08/07/2026) — sistema novo e isolado.
#
# Durante o combate normal contra os monstros, qualquer jogador pode
# declarar traição em segredo (ninguém mais sabe). Se a party vencer os
# monstros e existir pelo menos 1 traidor entre os sobreviventes, em vez
# de ir direto pro loot, todo mundo entra numa fase de PvP entre si. Quem
# morre nessa fase perde TODOS os itens equipados, divididos entre os
# traidores que continuarem vivos.
# =============================================================================

def raid_declare_betrayal(p: dict) -> str:
    """Declara traição pra ESSA batalha (a escolha é feita no início de cada
    luta contra os monstros, não fica valendo pra raid toda)."""
    room_id = p.get("raid_room_id")
    if not room_id:
        return "❌ Você não está em nenhuma raid."
    room = get_room(room_id)
    if not room or room.get("state") != "RAID_COMBAT":
        return "❌ Só dá pra escolher no início do combate contra os monstros."

    rs = room.get("raid_state") or {}
    pid = str(p.get("user_id") or p.get("userid") or p.get("player_id") or p.get("telegram_id"))
    traidores = rs.setdefault("traidores", [])
    if pid not in traidores:
        traidores.append(pid)
    rs.setdefault("betrayal_choices", {})[pid] = True
    room["raid_state"] = rs
    save_room(room)
    return "🗡️ <b>Traição selada em segredo...</b> Ninguém vai saber até o fim da luta contra os monstros."


def raid_decline_betrayal(p: dict) -> str:
    """Escolhe NÃO trair nessa batalha."""
    room_id = p.get("raid_room_id")
    if not room_id:
        return "❌ Você não está em nenhuma raid."
    room = get_room(room_id)
    if not room or room.get("state") != "RAID_COMBAT":
        return "❌ Só dá pra escolher no início do combate contra os monstros."

    rs = room.get("raid_state") or {}
    pid = str(p.get("user_id") or p.get("userid") or p.get("player_id") or p.get("telegram_id"))
    traidores = rs.setdefault("traidores", [])
    if pid in traidores:
        traidores.remove(pid)
    rs.setdefault("betrayal_choices", {})[pid] = False
    room["raid_state"] = rs
    save_room(room)
    return "🤝 Você decide lutar de boa fé, lado a lado com sua party."


def _raid_start_pvp_phase(room: dict, rs: dict, logs: list) -> None:
    """Prepara a fase de PvP entre os sobreviventes, logo depois dos
    monstros serem derrotados — só roda se houver traidor(es) vivo(s)."""
    import random
    players = rs.get("players", {})
    atb = rs.setdefault("atb", {})
    for pid, pl in players.items():
        if pl.get("hp", 0) > 0 and not pl.get("dead"):
            atb[pid] = 100.0 * random.uniform(0.5, 1.0)  # ordem semi-embaralhada, ninguém garantido primeiro
            pl["dots"] = []
            pl["stun"] = 0
    room["state"] = "RAID_PVP"
    logs.append("⚔️ Escolham seus alvos... só um lado sai vivo dessa.")


def raid_pvp_attack(p: dict, target_pid: str = None) -> str:
    """Ataque básico na fase de PvP da traição — mesma mecânica do ataque
    normal de raid, só que o alvo é outro jogador."""
    room_id = p.get("raid_room_id")
    if not room_id: return "❌ Você não está em nenhuma raid."
    room = get_room(room_id)
    if not room or room.get("state") != "RAID_PVP": return "❌ Não é fase de traição."

    rs = room.get("raid_state")
    if not rs: return "❌ Estado de combate não encontrado."

    pid = str(p.get("user_id") or p.get("userid") or p.get("player_id") or p.get("telegram_id"))
    players = rs.get("players") or {}
    atb = rs.get("atb") or {}
    logs = rs.setdefault("logs", [])

    if pid not in players: return "❌ Você não faz parte desta raid."
    atacante = players[pid]
    if atacante.get("hp", 0) <= 0 or atacante.get("dead"): return "💀 Você já caiu em combate."
    if atb.get(pid, 0.0) < 100.0: return "⏳ Sua barra de ação ainda não está cheia."

    if not target_pid or target_pid not in players or players[target_pid].get("hp", 0) <= 0 or players[target_pid].get("dead") or target_pid == pid:
        vivos = [p2 for p2 in players if p2 != pid and players[p2].get("hp", 0) > 0 and not players[p2].get("dead")]
        if not vivos: return "🏁 Não há mais ninguém pra lutar."
        target_pid = vivos[0]
    defensor = players[target_pid]

    atk = _raid_effective_stat(atacante, "atk", int(atacante.get("atk", 5)))
    acc = int(atacante.get("acc", 0))
    crit = int(atacante.get("crit", 0))
    eva_def = _raid_effective_stat(defensor, "eva", int(defensor.get("eva", 5)))
    def_def = _raid_effective_stat(defensor, "def", int(defensor.get("def", 0)))

    atb[pid] = max(0.0, atb.get(pid, 0.0) - 100.0)
    rs["atb"] = atb

    a_name, d_name = atacante.get("name", "Jogador"), defensor.get("name", "Jogador")

    acertou, log_hit, _ = check_hit_and_evasion(acc, eva_def, {}, {}, a_name, d_name)
    if log_hit: logs.append(log_hit)

    if acertou:
        dano_final, logs_dano = calc_final_damage(atk, def_def, crit, {}, {}, defensor.get("hp", 0), defensor.get("hp_max", 1), eva_alvo=int(eva_def))
        logs.extend(logs_dano)

        escudo = defensor.get("shield", 0)
        if escudo > 0:
            if escudo >= dano_final:
                defensor["shield"] -= dano_final
                logs.append(f"🛡️ O escudo de {d_name} absorveu {dano_final} de dano!")
                dano_final = 0
            else:
                dano_final -= escudo
                defensor["shield"] = 0
                logs.append(f"🛡️ O escudo de {d_name} se estilhaçou!")

        defensor["hp"] = max(0, defensor.get("hp", 0) - dano_final)
        if dano_final > 0:
            logs.append(f"🗡️ {a_name} atacou {d_name}! -{dano_final} HP.")

        if defensor["hp"] <= 0:
            defensor["dead"] = True
            logs.append(f"☠️ {d_name} caiu na traição!")
            _raid_pvp_handle_death(room, rs, target_pid, logs)

    room["raid_state"] = rs
    return _raid_pvp_end_of_turn(room)


def _raid_pvp_handle_death(room: dict, rs: dict, pid: str, logs: list) -> None:
    """Quando alguém morre na fase de PvP, perde TODOS os itens equipados
    — divididos entre os traidores que continuarem vivos."""
    players = rs.get("players", {})
    traidores_vivos = [
        t for t in rs.get("traidores", [])
        if t in players and players[t].get("hp", 0) > 0 and not players[t].get("dead")
    ]

    try:
        pdata = load_player(int(pid))
    except Exception:
        pdata = None
    if not pdata:
        return

    itens_perdidos = []
    equip = pdata.get("equip", {})
    for slot, item in list(equip.items()):
        if item:
            itens_perdidos.append((slot, item))
            equip[slot] = None

    # =========================================================
    # 💥 QUEBRA DE EQUIPAMENTO (08/07/2026)
    # =========================================================
    # Cada item tem 50% de chance de se DESTRUIR na briga em vez de ir
    # parar na mão do traidor. A vítima perde tudo do mesmo jeito (o
    # equipamento sai dela de qualquer forma), mas o traidor só leva o que
    # sobrou inteiro — ou seja, trair rende bem menos do que o número de
    # itens sugere. É o preço de apunhalar o grupo pelas costas.
    itens_intactos = []
    itens_quebrados = []
    for slot, item in itens_perdidos:
        if random.randint(1, 100) <= 50:
            itens_quebrados.append((slot, item))
        else:
            itens_intactos.append((slot, item))

    pdata["state"] = "DEAD"
    pdata["hp"] = 0
    pdata["raid_room_id"] = None
    pdata["combat"] = {
        "death_log": (
            f"🗡️ <b>Você foi traído na Raid!</b>\n"
            f"Perdeu {len(itens_perdidos)} equipamento(s): "
            f"{len(itens_quebrados)} se despedaçaram na luta e "
            f"{len(itens_intactos)} ficaram com os traidores."
        )
    }
    save_player_sql(int(pid), pdata)

    try:
        from infra.cache_bus import mark_dirty
        mark_dirty(int(pid))
    except Exception:
        pass

    nome_vitima = players.get(pid, {}).get("name", "?")

    if itens_quebrados:
        nomes_quebrados = ", ".join(
            (it.get("name", "um item") if isinstance(it, dict) else "um item")
            for _, it in itens_quebrados[:3]
        )
        extra = f" (+{len(itens_quebrados) - 3})" if len(itens_quebrados) > 3 else ""
        logs.append(f"💥 Na briga, {len(itens_quebrados)} equipamento(s) de {nome_vitima} se despedaçaram e viraram pó: {nomes_quebrados}{extra}")

    if itens_intactos and traidores_vivos:
        for i, (slot, item) in enumerate(itens_intactos):
            traidor_pid = traidores_vivos[i % len(traidores_vivos)]
            try:
                t_data = load_player(int(traidor_pid))
                if t_data:
                    # 🔥 CORRIGIDO: usa o inventário de verdade (mochila),
                    # que é persistido de verdade — uma chave "stolen_items"
                    # inventada seria silenciosamente descartada no save,
                    # já que o sistema só reconhece os slots reais.
                    inv_items = t_data.setdefault("inv", {}).setdefault("items", {})
                    inv_items.setdefault(slot, []).append(item)
                    save_player_sql(int(traidor_pid), t_data)
                    from infra.cache_bus import mark_dirty
                    mark_dirty(int(traidor_pid))
            except Exception:
                pass
        logs.append(f"💰 {len(itens_intactos)} item(ns) de {nome_vitima} sobreviveram inteiros e foram divididos entre os traidores!")
    elif itens_perdidos and not itens_intactos:
        logs.append(f"💀 Ironia: TUDO de {nome_vitima} quebrou. Os traidores não levaram nada.")


def _raid_pvp_end_of_turn(room: dict) -> str:
    """Avança a fase de PvP até alguém ficar pronto de novo, ou até só
    sobrar um lado (fim da traição)."""
    rs = room["raid_state"]
    players = rs.get("players", {})
    atb = rs.setdefault("atb", {})
    logs = rs.setdefault("logs", [])
    traidores = set(rs.get("traidores", []))

    def checar_fim():
        vivos = [pid for pid, pl in players.items() if pl.get("hp", 0) > 0 and not pl.get("dead")]
        traidores_vivos = [pid for pid in vivos if pid in traidores]
        leais_vivos = [pid for pid in vivos if pid not in traidores]
        return len(vivos) <= 1 or not traidores_vivos or not leais_vivos

    if checar_fim():
        _raid_finish_pvp_phase(room, rs, logs)
        save_room(room)
        return "🏁 A traição chegou ao fim!"

    seguranca = 0
    while seguranca < 200:
        seguranca += 1
        prontos = [pid for pid, val in atb.items() if val >= 100.0 and pid in players
                   and players[pid].get("hp", 0) > 0 and not players[pid].get("dead")]
        if prontos:
            break
        for pid, pl in players.items():
            if pl.get("hp", 0) > 0 and not pl.get("dead"):
                atb[pid] = min(100.0, atb.get(pid, 0.0) + max(5.0, float(pl.get("spd", 20)) * 0.5))

    room["raid_state"] = rs
    save_room(room)
    return ""


def _raid_finish_pvp_phase(room: dict, rs: dict, logs: list) -> None:
    """Fecha a fase de traição: quem sobreviveu ainda recebe o loot normal
    dos monstros (a punição de morrer aqui é perder o equipamento, não o
    loot da própria raid), e todo mundo volta pro lobby."""
    logs.append("🏁 A poeira baixa. A traição chegou ao fim.")
    enemies = rs.get("enemies", [])
    if enemies:
        raid_distribute_loot(room, enemies[0], logs)

    room["last_combat_log"] = "\n".join(logs[-15:])
    room["raid_state"] = None
    room["combat"] = None
    room["state"] = "LOBBY"
    room["floor"] = int(room.get("floor", 1)) + 1

    if "ready_map" in room:
        for m_id in room.get("members", []):
            room["ready_map"][m_id] = False

    for pid, pl in rs.get("players", {}).items():
        if pl.get("hp", 0) > 0 and not pl.get("dead"):
            try:
                pdata = load_player(int(pid))
                if pdata:
                    pdata["state"] = "RAID_LOBBY"
                    pdata["combat"] = None
                    save_player_sql(int(pid), pdata)
                    from infra.cache_bus import mark_dirty
                    mark_dirty(int(pid))
            except Exception:
                pass


def raid_init_combat_state(room: dict) -> None:
    from game.logic import recalc, _raid_end_of_turn
    import time
    import random

    floor = int(room.get("floor", 1))
    members = list(room.get("members", []))
    floor_calc = floor  # Monstros Elite

    # 1. CRIA OS 5 MONSTROS (Frankenstein Bufado)
    enemies = []
    for i in range(5):
        # 🔥 MUDA DE floor_calc PARA floor! Pega a Identidade (Nome e Magias) e Status Base do ANDAR 1!
        mon = criar_monstro_por_andar(floor)
        
        # 🔥 A SUA MATEMÁTICA PERFEITA: Pega a vida base do andar 1, soma +1000 e multiplica por 12!
        base_hp = int(mon.get("hpmax", mon.get("hp_max", 100))) # Vida base baixa do Andar 1
        mhp_max = int(base_hp + 1000) * 12                     # O buff absurdo
        
        enemies.append({
            "id": i,
            "name": f"{mon.get('nome', 'Elite')} #{i+1}",
            "base_name": mon.get("nome", "Elite"),
            # 🔥 CORREÇÃO DE IMAGEM: Salva a chave real de imagem do bicho
            "img": mon.get("img", mon.get("imagem", mon.get("asset", mon.get("nome")))), 
            "tipo": "boss", 
            "hp": mhp_max,
            "hp_max": mhp_max,
            # 🔥 Mantemos os buffs fixos que combinamos!
            "atk": int(mon.get("atk", 10)) + 200,       # Dano bombado
            "def": int(mon.get("def", 1)) + 100,        # Defesa bombada
            "spd": int(mon.get("spd", 20)) + 50 + random.randint(-5, 5), # Velocidade bombada
            "acc": int(mon.get("acc", 10)) + 100,
            "eva": int(mon.get("eva", 5)) + 100,
            "crit": int(mon.get("crit", 5)) + 100,
            # 🎯 mesma regra dos bosses da Torre (25/09): skills só da
            # raridade da faixa do andar, chance 10–50% conforme o andar
            "skills": skills_do_boss_no_andar(floor),
            "floor": floor,
            "reg": min(int((mon.get("status") or {}).get("reg", 0)), int(mhp_max * REGEN_TETO_PCT)),
            "dots": [],
            "stun": 0
        })


    # 2. CARREGA JOGADORES
    players: dict[str, dict] = {}
    for pid in members:
        try: pdata = load_player(int(pid))
        except Exception: pdata = None
        if not pdata: continue

        recalc(pdata)
        hp_real = int(pdata.get("hp_max", pdata.get("hpmax", 100)))
        pdata["hp"] = hp_real
        pdata["state"] = "RAID_COMBAT"
        pdata["raid_room_id"] = room.get("id")
        save_player_sql(int(pid), pdata)

        players[str(pid)] = {
            "name": pdata.get("username") or f"Jogador {pid}",
            "hp": hp_real, "hp_max": hp_real,
            "atk": int(pdata.get("atk", 5)), "def": int(pdata.get("def", 0)),
            "spd": int(pdata.get("spd", 20)), "acc": int(pdata.get("acc", 0)),
            "eva": int(pdata.get("eva", 0)), "crit": int(pdata.get("crit", 0)),
            "bar": 0.0, "dead": False, "buffs": {}, "hots": [],
        }

    # 3. CRIA AS BARRAS DE TURNO PARA GERAL
    # 🔥 INICIATIVA: Jogadores começam com 100% de ATB para o jogo pausar e mostrar a tela antes dos monstros atacarem!
    atb = {pid: 100.0 for pid in players.keys()} 
    
    for i in range(5):
        atb[f"enemy_{i}"] = 0.0


    # 4. SALVA NA SALA (Usando a chave "enemies"!)
    room["raid_state"] = {
        "enemies": enemies,
        "players": players,
        "atb": atb,
        "turn_count": 0,
        "turn_start_time": int(time.time()),
        "logs": [f"⚔️ O portão se abre e 5 Elites atacam!"],
        "traidores": [],           # 🗡️ resetado a cada batalha nova (a escolha é por batalha, não pra raid toda)
        "betrayal_choices": {},    # pid -> True/False, quem já decidiu nessa batalha
    }
    room["state"] = "RAID_COMBAT"
    
    _raid_end_of_turn(room)




def _raid_fill_atb(room: dict) -> tuple[str, str]:
    rs = room["raid_state"]
    atb = rs["atb"]
    players = rs.get("players", {})
    enemies = rs.get("enemies", [])

    # 🔥 Failsafe Supremo: Evita que o combate congele num loop infinito se todo mundo morrer
    alguem_vivo = False
    for e in enemies:
        if e["hp"] > 0: alguem_vivo = True
    for pl in players.values():
        if pl.get("hp", 0) > 0 and not pl.get("dead"): alguem_vivo = True
        
    if not alguem_vivo:
        return None, None

    while True:
        prontos = []
        for pid, val in atb.items():
            if val >= 100.0:
                if pid.startswith("enemy_"):
                    idx = int(pid.split("_")[1])
                    if enemies[idx]["hp"] > 0: prontos.append(("enemy", pid))
                else:
                    if pid in players and players[pid]["hp"] > 0 and not players[pid].get("dead"):
                        prontos.append(("player", pid))

        if prontos:
            prontos.sort(key=lambda x: atb[x[1]], reverse=True)
            return prontos[0][0], prontos[0][1]

        # 🔥 A MÁGICA DO ATB BLINDADO: Avança o tempo de forma controlada
        for pid in atb.keys():
            if pid.startswith("enemy_"):
                idx = int(pid.split("_")[1])
                if enemies[idx]["hp"] > 0: 
                    speed = float(enemies[idx].get("spd", 20))
                    atb[pid] = min(100.0, atb[pid] + max(5.0, speed * 0.5))
            else:
                if pid in players and players[pid].get("hp", 0) > 0 and not players[pid].get("dead"):
                    speed = float(players[pid].get("spd", 20))
                    atb[pid] = min(100.0, atb[pid] + max(5.0, speed * 0.5))


def _raid_boss_turn(room: dict) -> None:
    from game.logic import raid_handle_player_death 
    import random

    rs = room.get("raid_state") or {}
    boss = rs.get("boss") or {}
    players = rs.get("players") or {}
    atb = rs.get("atb") or {}
    logs = rs.setdefault("logs", [])

    vivos = [pid for pid, pl in players.items() if pl.get("hp", 0) > 0]
    if not vivos or boss.get("hp", 0) <= 0: return

    atk = int(boss.get("atk", 10))
    acc_boss = int(boss.get("acc", 10))
    crit_boss = int(boss.get("crit", 5))
    
    boss_skills = boss.get("skills", [])
    usou_skill = False
    
    if boss_skills and random.random() < chance_skill_do_boss(int(boss.get("floor", 1))):
        skill_id = random.choice(boss_skills)
        sk_data = get_skill_by_id(skill_id)
        
        if sk_data:
            sk = sk_data.get("skill", {})
            nome_magia = sk.get("name", "Magia")
            mult = float(sk.get("mult", 0))
            dmg_pct = float(sk.get("dmg_percent", 0) or sk.get("dmgpercent", 0))
            
            if mult: base_dmg = int(atk * mult)
            elif dmg_pct: base_dmg = int(atk * dmg_pct / 100.0)
            else: base_dmg = atk

            target_type = sk.get("target", "single")
            dot_mult = float(sk.get("dotmult", 0) or sk.get("dot_mult", 0))
            dot_turns = int(sk.get("dotturns", 0) or sk.get("dot_turns", 0))
            stun_turns = int(sk.get("stun", 0))
            
            logs.append(f"✨ O Boss conjurou {nome_magia}!")
            alvos = vivos if target_type == "all" else [random.choice(vivos)]
            
            for pid in alvos:
                pl = players[pid]
                
                dano_bruto = max(1, base_dmg - _raid_effective_stat(pl, "def", int(pl.get("def", 0))))
                dano_final = max(1, dano_bruto + random.randint(-1, 2))
                
                _mcrit = multiplicador_de_critico(crit_boss, _raid_effective_stat(pl, "eva", int(pl.get("eva", 0))))
                if _mcrit:
                    dano_final = int(dano_final * _mcrit)
                    logs.append(f" 💥 CRÍTICO MAGICO! {pl['name']} recebeu {dano_final} de dano.")
                else:
                    logs.append(f" 💥 {pl['name']} recebeu {dano_final} de dano.")
                    
                pl["hp"] = max(0, pl.get("hp", 0) - dano_final)
                
                if dot_mult > 0 and dot_turns > 0:
                    dmg_dot = max(1, int(atk * dot_mult))
                    pl.setdefault("dots", []).append({
                        "name": sk.get("dotname", "efeito contínuo"), "dmg": dmg_dot, "turns": dot_turns,
                    })
                    logs.append(f" 🧪 {pl['name']} sofreu {sk.get('dotname', 'efeito')}!")
                    
                if stun_turns > 0:
                    # 🔥 TRAVA GLOBAL DE 35% DE CHANCE (Inimigo vs Jogador)
                    if random.randint(1, 100) <= 35:
                        p["stun"] = p.get("stun", 0) + stun_turns
                        logs.append(f"💫 Foste atordoado por {stun_turns} turno(s)!\n")
                    else:
                        logs.append(f"🛡️ Resististe bravamente ao atordoamento!\n")
                    
                if pl["hp"] <= 0:
                    raid_handle_player_death(room, pid)
                    atb[pid] = 0.0

            usou_skill = True

    if not usou_skill:
        is_aoe = random.random() < 0.3
        alvos = vivos if is_aoe else [random.choice(vivos)]
        if is_aoe: logs.append("🌪️ O Boss lançou um ataque bruto em área!")
        
        for pid in alvos:
            pl = players[pid]
            eva_pl = _raid_effective_stat(pl, "eva", int(pl.get("eva", 5)))
            
            chance_acerto = 100 + acc_boss - eva_pl
            chance_acerto = max(20, min(100, chance_acerto))
            
            if random.randint(1, 100) > chance_acerto:
                logs.append(f"💨 {pl['name']} esquivou do ataque do Boss!")
            else:
                dano_bruto = max(1, atk - int(pl.get("def", 0)))
                dano_final = max(1, dano_bruto + random.randint(-1, 2))
                
                _mcrit = multiplicador_de_critico(crit_boss, _raid_effective_stat(pl, "eva", int(pl.get("eva", 0))))
                if _mcrit:
                    dano_final = int(dano_final * _mcrit)
                    logs.append(f"⚔️ CRÍTICO! {pl['name']} sofreu {dano_final} de dano{' (AoE)' if is_aoe else ''}.")
                else:
                    logs.append(f"⚔️ {pl['name']} recebeu {dano_final} de dano{' (AoE)' if is_aoe else ''}.")
                    
                pl["hp"] = max(0, pl.get("hp", 0) - dano_final)
                
            if pl["hp"] <= 0:
                raid_handle_player_death(room, pid)
                atb[pid] = 0.0

    atb["boss"] = max(0.0, float(atb.get("boss", 0.0)) - 100.0)
    
    rs["boss"] = boss
    rs["players"] = players
    rs["atb"] = atb
    room["raid_state"] = rs



def raid_player_attack(p: dict, is_afk: bool = False) -> str:
    room_id = p.get("raid_room_id")
    if not room_id: return "❌ Você não está em nenhuma raid."

    room = get_room(room_id)
    if not room or room.get("state") != "RAID_COMBAT": return "❌ A raid não está em combate."

    rs = room.get("raid_state")
    if not rs: return "❌ Estado de combate não encontrado."

    pid = str(p.get("user_id") or p.get("userid") or p.get("player_id") or p.get("telegram_id"))
    players = rs.get("players") or {}
    enemies = rs.get("enemies") or []
    atb = rs.get("atb") or {}
    logs = rs.setdefault("logs", [])
    my_cds = rs.setdefault("cooldowns", {}).setdefault(pid, {})

    if pid not in players: return "❌ Você não faz parte desta raid."
    pl = players[pid]
    if pl.get("hp", 0) <= 0 or pl.get("dead"): return "💀 Você já caiu em combate."
    if atb.get(pid, 0.0) < 100.0: return "⏳ Sua barra de ação ainda não está cheia."

    atk  = _raid_effective_stat(pl, "atk", int(p.get("atk",  pl.get("atk",  5))))
    acc  = int(p.get("acc",  pl.get("acc",  0)))
    crit = int(p.get("crit", pl.get("crit", 0)))

    target_idx = p.get("raid_target", 0)
    alive_indices = [i for i, e in enumerate(enemies) if e["hp"] > 0]
    if not alive_indices: return "🏁 Todos os inimigos já foram derrotados."
    if target_idx not in alive_indices: target_idx = alive_indices[0]
    alvo = enemies[target_idx]

    # 🔥 Puxa os Triggers do Jogador!
    meus_triggers = get_combat_triggers(p)
    inimigo_triggers = {}

    for cd_id in list(my_cds.keys()): my_cds[cd_id] = max(0, my_cds[cd_id] - 1)

    # 🌪️ Andarilho do Vento na Raid!
    free_turn, ft_log = check_free_turn(meus_triggers)
    if not free_turn:
        atb[pid] = max(0.0, atb.get(pid, 0.0) - 100.0)
    else:
        logs.append(ft_log)
        
    rs["atb"] = atb
    rs["turn_count"] = rs.get("turn_count", 0) + 1

    p_name = pl.get("name", "Jogador")
    e_name = alvo.get("name", "Elite")

    # =========================================================
    # 🎲 O NOVO MOTOR DE COMBATE (RAID ATAQUE BÁSICO)
    # =========================================================
    acertou, log_hit, def_updates = check_hit_and_evasion(acc, int(alvo.get("eva", 5)), meus_triggers, inimigo_triggers, p_name, e_name)
    if log_hit: logs.append(log_hit)

    if acertou:
        # Puxa o HP Máximo de forma segura para não dar erro invisível!
        hp_max_inimigo = int(alvo.get("hpmax", alvo.get("hp_max", 1)))
        
        dano_final, logs_dano = calc_final_damage(atk, int(alvo.get("def", 0)), crit, meus_triggers, inimigo_triggers, int(alvo.get("hp", 0)), hp_max_inimigo, eva_alvo=int(alvo.get("eva", 5)))
        logs.extend(logs_dano)
        
        # 🔥 CORREÇÃO: Trava o HP em 0 e mostra o dano numérico no log!
        alvo["hp"] = max(0, alvo.get("hp", 0) - dano_final)
        logs.append(f"🗡️ {p_name} atacou! -{dano_final} HP em {e_name}.\n")
        
        # 🦇 Vampirismo Multiplayer! (Sanguinário)
        cura, logs_cura, updates = apply_lifesteal(dano_final, meus_triggers)
        if cura > 0:
            pl['hp'] = min(int(pl.get('hp_max', 1)), int(pl.get('hp', 0)) + cura)
            p['hp'] = pl['hp']
            logs.extend(logs_cura)
            
            # Se procou a chance de curar a party toda!
            if "heal_party" in updates:
                cura_party = updates["heal_party"]
                for p_id, p_data in players.items():
                    if p_data.get("hp", 0) > 0 and not p_data.get("dead"):
                        p_data["hp"] = min(int(p_data.get("hp_max", 1)), int(p_data.get("hp", 0)) + cura_party)

    # =========================================================
    # ⏳ FINALIZA O TURNO E SALVA A SALA (ESTAVA FALTANDO!)
    # =========================================================
    room["raid_state"] = rs
    return _raid_end_of_turn(room)



    
def skill_precisa_escolher_aliado(sk_data: dict) -> bool:
    """True se a skill é de suporte E mira em um único alvo — ou seja, faz
    sentido perguntar em QUEM usar (curar/buffar um companheiro específico).
    Skills 'all' atingem o grupo todo, e ofensivas miram no inimigo, então
    nenhuma das duas precisa de seleção de aliado."""
    if not sk_data:
        return False
    alvo = sk_data.get("target", "single")
    if alvo == "all":
        return False
    eh_suporte = (
        float(sk_data.get("heal_percent", 0) or 0) > 0
        or float(sk_data.get("shield_pct", 0) or 0) > 0
        or float(sk_data.get("hot_pct", 0) or 0) > 0
        or float(sk_data.get("buff_atk", 0) or 0) > 0
        or float(sk_data.get("buff_def", 0) or 0) > 0
        or float(sk_data.get("buff_eva", 0) or 0) > 0
        or bool(sk_data.get("cleanse"))
    )
    return eh_suporte


def raid_player_skill(p: dict, sk_id: str, is_afk: bool = False, ally_target_pid: str = None) -> str:
    import random

    room_id = p.get("raid_room_id")
    if not room_id: return "❌ Não estás numa raid."

    room = get_room(room_id)
    if not room or room.get("state") != "RAID_COMBAT": return "❌ A raid não está em combate."

    rs = room.get("raid_state")
    if not rs: return "❌ Estado de combate não encontrado."

    pid = str(p.get("user_id") or p.get("userid") or p.get("player_id") or p.get("telegram_id"))
    players = rs.get("players") or {}
    enemies = rs.get("enemies") or []
    atb = rs.get("atb") or {}
    logs = rs.setdefault("logs", [])
    my_cds = rs.setdefault("cooldowns", {}).setdefault(pid, {})

    if pid not in players: return "❌ Não fazes parte desta raid."
    pl = players[pid]
    if pl.get("hp", 0) <= 0 or pl.get("dead"): return "💀 Já caíste em combate."
    if atb.get(pid, 0.0) < 100.0: return "⏳ A tua barra de ação ainda não está cheia."

    # 1. Busca a habilidade
    learned = p.get("skills_learned", {})
    sk_learned_data = learned.get(sk_id)

    if not sk_learned_data or not isinstance(sk_learned_data, dict):
        sk_base_data = get_skill_by_id(sk_id)
        if sk_base_data: sk = sk_base_data.get("skill") or sk_base_data
        else: return "❌ Habilidade não encontrada."
    else:
        sk = sk_learned_data

    if not sk or not isinstance(sk, dict) or sk.get("type") != "active": return "❌ Habilidade inválida."

    # 2. Checa Cooldown
    cd_now = int(my_cds.get(sk_id, 0))
    if cd_now > 0: return f"⏳ [{sk.get('name', sk_id)}] em recarga ({cd_now} turnos)."

    # 🔥 Puxa os Triggers Mágicos!
    meus_triggers = get_combat_triggers(p)
    inimigo_triggers = {}

    # 🌪️ Andarilho do Vento na Raid (Magia grátis!)
    free_turn, ft_log = check_free_turn(meus_triggers)
    if not free_turn:
        atb[pid] = max(0.0, atb.get(pid, 0.0) - 100.0)
    else:
        logs.append(ft_log)

    # Avança os outros cooldowns em 1
    for cd_key in list(my_cds.keys()): my_cds[cd_key] = max(0, my_cds[cd_key] - 1)

    rs["atb"] = atb
    rs["turn_count"] = rs.get("turn_count", 0) + 1

    p_name = pl.get("name", "Jogador")
    
    # 🌟 CORREÇÃO: RECALCULAR STATUS ANTES DO ATAQUE NA RAID!
    from game.logic import recalc
    recalc(p) 
    
    atk = _raid_effective_stat(pl, "atk", int(p.get("atk", pl.get("atk", 5))))
    acc = int(p.get("acc", pl.get("acc", 0)))
    crit = int(p.get("crit", pl.get("crit", 0)))

    sk_evolved = sk_learned_data if isinstance(sk_learned_data, dict) else sk

    # =========================================================
    # 🎯 SELETOR DE ALVOS (DANO EM ÁREA OU ÚNICO)
    # =========================================================
    target_idx = p.get("raid_target", 0)
    alive_indices = [i for i, e in enumerate(enemies) if e["hp"] > 0]
    
    if not alive_indices: return "🏁 Todos os inimigos já foram derrotados."
    if target_idx not in alive_indices: target_idx = alive_indices[0]
    
    target_type = sk_evolved.get("target", sk.get("target", "single"))
    alvos_para_bater = []
    
    if target_type == "all":
        alvos_para_bater = [e for e in enemies if e["hp"] > 0]
        logs.append(f"🌪️ {p_name} conjurou magia em ÁREA contra todos os inimigos!\n")
    else:
        alvos_para_bater = [enemies[target_idx]]

    # =========================================================
    # ✨ MOTOR DE SUPORTE (CURA EM RAID)
    # =========================================================
    heal_pct = float(sk_evolved.get("heal_percent", sk.get("heal_percent", 0)))
    if heal_pct > 0:
        heal_amount = int(atk * heal_pct)
        heal_amount = int(heal_amount * meus_triggers.get("heal_mult", 1.0))
        if meus_triggers.get("double_heal_chance", 0) > random.randint(1, 100):
            heal_amount *= 2
            logs.append("✨ MILAGRE! Efeito de cura duplicado!\n")

        # 🎯 ALVO DA CURA (08/07/2026): se o jogador escolheu um aliado
        # (ally_target_pid), cura ELE. Senão, cai no comportamento antigo
        # (cura o próprio conjurador). Antes, uma cura single-target sempre
        # curava você mesmo, mesmo com um aliado morrendo do lado.
        alvo_cura_pid = ally_target_pid if (ally_target_pid and ally_target_pid in players) else pid
        alvo_cura = players.get(alvo_cura_pid, pl)

        alvo_cura["hp"] = min(int(alvo_cura.get("hp_max", 1)), int(alvo_cura.get("hp", 0)) + heal_amount)
        if alvo_cura_pid == pid:
            p["hp"] = alvo_cura["hp"]
        nome_alvo_cura = alvo_cura.get("name", "aliado")
        logs.append(f"💚 {nome_alvo_cura} recuperou {heal_amount} HP com {sk.get('name', sk_id)}.\n")

        # 🔥 Mestre do Equilíbrio: chance da cura também gerar um Escudo equivalente
        if meus_triggers.get("heal_creates_shield_chance", 0) > random.randint(1, 100):
            alvo_cura["shield"] = alvo_cura.get("shield", 0) + heal_amount
            logs.append(f"🛡️ Equilíbrio Perfeito! A cura gerou {heal_amount} de Escudo!\n")

    # =========================================================
    # 🛡️ MOTOR DE SUPORTE (BUFF / ESCUDO / REGENERAÇÃO)
    # 🔥 CORRIGIDO (08/07/2026): buff_atk, buff_def, buff_eva, shield_pct e
    # hot_pct existiam em ~25 skills (principalmente da classe Suporte) mas
    # nunca eram processados — as skills de suporte não faziam NADA além de
    # entrar em cooldown. Agora aplicam de verdade, em você mesmo (target
    # "self"), num aliado (target "single" — por enquanto sempre você
    # mesmo, ainda não dá pra escolher aliado) ou no grupo todo (target "all").
    # =========================================================
    buff_atk = float(sk_evolved.get("buff_atk", sk.get("buff_atk", 0)))
    buff_def = float(sk_evolved.get("buff_def", sk.get("buff_def", 0)))
    buff_eva = float(sk_evolved.get("buff_eva", sk.get("buff_eva", 0)))
    buff_turns_dur = int(sk_evolved.get("buff_turns", sk.get("buff_turns", 0)))
    shield_pct = float(sk_evolved.get("shield_pct", sk.get("shield_pct", 0)))
    hot_pct = float(sk_evolved.get("hot_pct", sk.get("hot_pct", 0)))
    hot_turns_dur = int(sk_evolved.get("hot_turns", sk.get("hot_turns", 0)))

    # 🪨 CONTRA-STUN (08/07/2026): mesma correção do solo — as 3 skills de
    # pedra do Guardião tinham a mecânica no banco mas o motor não lia.
    _stun_on_hit = float(sk_evolved.get("stun_on_hit_chance", sk.get("stun_on_hit_chance", 0)))
    if _stun_on_hit > 0:
        me_pl = players.get(pid)
        if me_pl:
            _dur = buff_turns_dur or 3
            me_pl["stun_on_hit"] = {"chance": _stun_on_hit, "turns": _dur}
            logs.append(f"🪨 {me_pl.get('name', 'Você')} endureceu a pele! ({int(_stun_on_hit)}% de atordoar quem atacar, {_dur} turnos)\n")

    # =========================================================
    # ✝️ RESSURREIÇÃO (revive_target)
    # 🔥 CORRIGIDO (08/07/2026): "Ressurreição Divina" (core_heal_5) é a
    # ultimate do Curandeiro — tier 5, cooldown 8 — e a mecânica de reviver
    # existia no banco de skills mas o motor NUNCA lia. Na prática ela só
    # curava, e curar quem já está morto não faz nada: a skill inteira era
    # inútil justamente na hora pra qual foi feita.
    # =========================================================
    if sk_evolved.get("revive_target", sk.get("revive_target")):
        revividos = []
        for alvo_pid, alvo_pl in players.items():
            if alvo_pl.get("dead") or int(alvo_pl.get("hp", 0)) <= 0:
                hp_volta = max(1, int(int(alvo_pl.get("hp_max", 1)) * 0.5))
                alvo_pl["hp"] = hp_volta
                alvo_pl["dead"] = False
                # 🩸 tira o marcador de "caído esperando" — sem isso, o
                # jogador seria morto no fim da batalha mesmo tendo sido
                # ressuscitado (o _raid_finalizar_caidos varre por essa flag).
                alvo_pl.pop("awaiting_revive", None)
                # zera os marcadores de morte pra ele poder agir de novo
                alvo_pl.pop("used_immortal", None)
                alvo_pl.pop("used_revive", None)
                atb_rs = rs.get("atb") or {}
                atb_rs[alvo_pid] = 0.0
                # devolve o estado dele pra combate (estava em RAID_DOWN)
                try:
                    pdata_rev = load_player(int(alvo_pid))
                    if pdata_rev:
                        pdata_rev["state"] = "RAID_COMBAT"
                        pdata_rev["hp"] = hp_volta
                        save_player_sql(int(alvo_pid), pdata_rev)
                        from infra.cache_bus import mark_dirty
                        mark_dirty(int(alvo_pid))
                except Exception as e:
                    print(f"ERRO AO RESSUSCITAR {alvo_pid}: {e}")
                revividos.append(f"{alvo_pl.get('name', 'Aliado')} ({hp_volta} HP)")
        if revividos:
            logs.append(f"✝️ <b>RESSURREIÇÃO DIVINA!</b> De volta à luta: {', '.join(revividos)}!\n")
        else:
            logs.append("✝️ A luz divina brilhou, mas ninguém precisava ser trazido de volta.\n")

    # =========================================================
    # 🔥 MAIS EFEITOS QUE FALTAVAM NA RAID (08/07/2026)
    # =========================================================
    # ⚡ Avanço de turno (atb_boost) — acelera o próprio conjurador
    _boost = float(sk_evolved.get("atb_boost", sk.get("atb_boost", 0)))
    if _boost > 0:
        _atb_rs = rs.setdefault("atb", {})
        _atb_rs[pid] = min(100.0, float(_atb_rs.get(pid, 0.0)) + _boost)
        logs.append(f"⚡ Avanço de turno ativado (+{int(_boost)} ATB)!\n")

    # 🩸 Custo de HP (hp_cost_pct) — skills do Bezerk que cobram sangue
    _hp_cost = float(sk_evolved.get("hp_cost_pct", sk.get("hp_cost_pct", 0)))
    if _hp_cost > 0:
        me_pl_c = players.get(pid)
        if me_pl_c:
            _custo = max(1, int(int(me_pl_c.get("hp_max", 1)) * _hp_cost))
            me_pl_c["hp"] = max(1, int(me_pl_c.get("hp", 1)) - _custo)
            p["hp"] = me_pl_c["hp"]
            logs.append(f"🩸 Você pagou {_custo} de HP pelo poder!\n")

    # ✨ Limpar efeitos ruins (cleanse)
    if sk_evolved.get("cleanse", sk.get("cleanse")):
        _alvos_limpar = (
            [pd for pd in players.values() if not pd.get("dead")]
            if target_type == "all" else [players.get(pid)]
        )
        _limpos = 0
        for _pl_c in _alvos_limpar:
            if not _pl_c:
                continue
            if _pl_c.get("dots"):
                _pl_c["dots"] = []
                _limpos += 1
            if int(_pl_c.get("stun", 0)) > 0:
                _pl_c["stun"] = 0
                _limpos += 1
            if (_pl_c.get("debuffs") or {}):
                _pl_c["debuffs"] = {}
                _limpos += 1
        if _limpos:
            logs.append("✨ Efeitos negativos purificados!\n")

    if buff_atk or buff_def or buff_eva or shield_pct or hot_pct:
        if target_type == "all":
            alvos_suporte = [p_id for p_id, p_data in players.items() if p_data.get("hp", 0) > 0 and not p_data.get("dead")]
        else:
            # 🎯 "single" (08/07/2026): se o jogador escolheu um aliado, mira
            # nele; senão, em si mesmo. Antes era sempre o próprio conjurador.
            if ally_target_pid and ally_target_pid in players:
                alvos_suporte = [ally_target_pid]
            else:
                alvos_suporte = [pid]

        for alvo_pid in alvos_suporte:
            alvo_pl = players.get(alvo_pid)
            if not alvo_pl:
                continue

            if buff_atk or buff_def or buff_eva:
                buffs_alvo = alvo_pl.setdefault("buffs", {})
                if buff_atk:
                    buffs_alvo["atk"] = {"pct": buff_atk, "turns": buff_turns_dur}
                if buff_def:
                    buffs_alvo["def"] = {"pct": buff_def, "turns": buff_turns_dur}
                if buff_eva:
                    buffs_alvo["eva"] = {"pct": buff_eva, "turns": buff_turns_dur}
                logs.append(f"✨ {alvo_pl.get('name', 'Aliado')} foi fortalecido por {sk.get('name', sk_id)}!\n")

            if shield_pct:
                shield_amt = int(atk * shield_pct)
                alvo_pl["shield"] = alvo_pl.get("shield", 0) + shield_amt
                logs.append(f"🛡️ {alvo_pl.get('name', 'Aliado')} recebeu {shield_amt} de Escudo!\n")

            if hot_pct and hot_turns_dur:
                hot_amt = max(1, int(atk * hot_pct))
                alvo_pl.setdefault("hots", []).append({"heal": hot_amt, "turns": hot_turns_dur})
                logs.append(f"💚 {alvo_pl.get('name', 'Aliado')} ganhou regeneração ao longo do tempo!\n")

    # =========================================================
    # 🛡️ TAUNT / PROVOCAR (08/07/2026) — skills de Tanker (família Escudo)
    # forçam os monstros a atacar QUEM USOU a skill, protegendo o resto do
    # grupo por alguns turnos. Sempre no próprio conjurador, não segue o
    # 'target' da skill (que é sobre buff/cura, não sobre provocação).
    # =========================================================
    if sk_evolved.get("taunt", sk.get("taunt", False)):
        taunt_turns = int(sk_evolved.get("taunt_turns", sk.get("taunt_turns", 2)))
        pl["taunt_active"] = taunt_turns
        logs.append(f"🛡️ {pl.get('name', 'Você')} provocou os inimigos! Eles vão mirar em você por {taunt_turns} turno(s).\n")

    # =========================================================
    # ⚔️ MOTOR DE DANO E STATUS MÁGICOS
    # =========================================================
    mult = float(sk_evolved.get("mult", sk.get("mult", 0)))
    dmg_pct = float(sk_evolved.get("dmg_percent", sk.get("dmg_percent", 0)))
    dot_mult = float(sk_evolved.get("dot_mult", sk.get("dot_mult", 0)))
    dot_turns = int(sk_evolved.get("dot_turns", sk.get("dot_turns", 0)))
    stun_turns = int(sk_evolved.get("stun", sk.get("stun", 0)))

    if sk.get("lifesteal"): meus_triggers["lifesteal_pct"] = max(meus_triggers.get("lifesteal_pct", 0), 1.0)

    base_damage = 0
    if mult > 0: base_damage = int(atk * mult)
    elif dmg_pct > 0: base_damage = int(atk * (dmg_pct / 100.0))

    # 🔥 O LOOP DESTRUTIVO: Passa o rodo em todos os alvos selecionados
    for alvo in alvos_para_bater:
        e_name = alvo.get("name", "Elite")

        if base_damage > 0 or dot_mult > 0 or stun_turns > 0:
            acertou, log_hit, def_upd = check_hit_and_evasion(acc, int(alvo.get("eva", 0)), meus_triggers, inimigo_triggers, p_name, e_name)
            if log_hit: logs.append(log_hit)

            if acertou:
                if base_damage > 0:
                    # 🔥 O NERF CIRÚRGICO DA RAID: Crítico dividido por 10!
                    skill_crit = crit // 10

                    dano_final, logs_dano = calc_final_damage(base_damage, int(alvo.get("def", 0)), skill_crit, meus_triggers, inimigo_triggers, int(alvo.get("hp", 0)), int(alvo.get("hp_max", 1)), eva_alvo=int(alvo.get("eva", 0)) // 10)
                    logs.extend(logs_dano)
                    alvo["hp"] = max(0, alvo.get("hp", 0) - dano_final)
                    logs.append(f"💥 {sk.get('name', sk_id)}! -{dano_final} HP em {e_name}.\n")

                    # 🦇 Vampirismo Multiplayer! (A Especialidade Sanguinário brilha aqui)
                    cura, logs_cura, updates = apply_lifesteal(dano_final, meus_triggers)
                    if cura > 0:
                        pl['hp'] = min(int(pl.get('hp_max', 1)), int(pl.get('hp', 0)) + cura)
                        p['hp'] = pl['hp']
                        logs.extend(logs_cura)

                        # Se ativou a passiva de curar a equipa inteira!
                        if "heal_party" in updates:
                            cura_party = updates["heal_party"]
                            for p_id, p_data in players.items():
                                if p_data.get("hp", 0) > 0 and not p_data.get("dead"):
                                    p_data["hp"] = min(int(p_data.get("hp_max", 1)), int(p_data.get("hp", 0)) + cura_party)

                # Aplica DoTs e Stuns no Boss
                if dot_mult > 0 and dot_turns > 0:
                    dmg_dot_final = max(1, int(atk * dot_mult))
                    if meus_triggers.get("dot_dmg_pct"):
                        dmg_dot_final = max(1, int(dmg_dot_final * (1.0 + meus_triggers["dot_dmg_pct"])))
                    novo_dot = {"name": sk.get("dot_name", "DoT"), "dmg": dmg_dot_final, "turns": dot_turns}
                    if meus_triggers.get("venom_stun_chance"):
                        novo_dot["stun_chance"] = meus_triggers["venom_stun_chance"]
                    alvo.setdefault("dots", []).append(novo_dot)
                    logs.append(f"☠️ {e_name} sofreu {sk.get('dot_name', 'DoT')}!\n")

                if stun_turns > 0:
                    alvo["stun"] = alvo.get("stun", 0) + stun_turns
                    logs.append(f"💫 {e_name} atordoado por {stun_turns} turno(s)!\n")

                # =========================================================
                # 🔥 EFEITOS QUE FALTAVAM NA RAID (08/07/2026)
                # =========================================================
                # Estes existiam só no motor SOLO. Os dois motores evoluíram
                # separados e cada um implementou um pedaço das mecânicas, o
                # que fazia a MESMA skill se comportar diferente conforme
                # onde o jogador estivesse lutando — sem nenhum aviso.

                # 📉 Reduz DEF do alvo
                _deb_def = float(sk_evolved.get("debuff_def", sk.get("debuff_def", 0)))
                if _deb_def > 0:
                    _d = alvo.setdefault("debuffs", {})
                    _d["def_pct"] = _deb_def
                    _d["def_turns"] = int(sk_evolved.get("debuff_turns", sk.get("debuff_turns", 3)))
                    logs.append(f"📉 A Defesa de {e_name} foi comprometida!\n")

                # 📉 Reduz ATK do alvo
                _deb_atk = float(sk_evolved.get("debuff_atk", sk.get("debuff_atk", 0)))
                if _deb_atk > 0:
                    _d = alvo.setdefault("debuffs", {})
                    _d["atk_pct"] = _deb_atk
                    _d["atk_turns"] = int(sk_evolved.get("debuff_turns", sk.get("debuff_turns", 3)))
                    logs.append(f"📉 O Ataque de {e_name} foi enfraquecido em {int(_deb_atk*100)}%!\n")

                # 🔇 Silenciar (impede o inimigo de usar magia)
                _sil = int(sk_evolved.get("silence_turns", sk.get("silence_turns", 0)))
                if _sil > 0:
                    alvo.setdefault("debuffs", {})["silence"] = _sil
                    logs.append(f"🔇 {e_name} foi silenciado por {_sil} turno(s)!\n")

                # 🎯 Marcar alvo (aumenta o dano que ele recebe)
                _mark = float(sk_evolved.get("mark_dmg_bonus", sk.get("mark_dmg_bonus", 0)))
                if _mark > 0:
                    _d = alvo.setdefault("debuffs", {})
                    _d["mark_dmg_bonus"] = _mark
                    _d["mark_turns"] = int(sk_evolved.get("buff_turns", sk.get("buff_turns", 3)))
                    logs.append(f"🎯 {e_name} foi marcado! (+{int(_mark*100)}% de dano recebido)\n")

                # ⏳ Atrasar o turno do alvo (o "slow" do gelo)
                _drain = float(sk_evolved.get("atb_drain", sk.get("atb_drain", 0)))
                if _drain > 0:
                    # o ATB da raid é indexado por "enemy_N" — preciso achar
                    # a posição desse alvo na lista de inimigos
                    try:
                        _idx_alvo = next(i for i, _e in enumerate(enemies) if _e is alvo)
                        _chave_atb = f"enemy_{_idx_alvo}"
                        _atb_rs = rs.setdefault("atb", {})
                        if _chave_atb in _atb_rs:
                            _atb_rs[_chave_atb] = max(0.0, float(_atb_rs[_chave_atb]) - _drain)
                            logs.append(f"⏳ O turno de {e_name} foi atrasado!\n")
                    except StopIteration:
                        pass

                # 💥 Detonar o DoT (estoura a queimadura/veneno de uma vez)
                if sk_evolved.get("detonate", sk.get("detonate")):
                    _dots_alvo = alvo.get("dots") or []
                    if _dots_alvo:
                        _total = sum(int(d.get("dmg", 0)) * int(d.get("turns", 0)) for d in _dots_alvo)
                        if _total > 0:
                            alvo["hp"] = max(0, int(alvo.get("hp", 0)) - _total)
                            alvo["dots"] = []
                            logs.append(f"💥 DETONAÇÃO! Os efeitos em {e_name} explodiram de uma vez: -{_total} HP!\n")

                # ☠️ Execução (mata direto se o alvo estiver com pouco HP)
                _exec = float(sk_evolved.get("execute_pct", sk.get("execute_pct", 0)))
                if _exec > 0 and int(alvo.get("hp", 0)) > 0:
                    _hp_pct = int(alvo.get("hp", 0)) / max(1, int(alvo.get("hp_max", 1)))
                    if _hp_pct <= _exec:
                        alvo["hp"] = 0
                        logs.append(f"☠️ <b>EXECUÇÃO!</b> {e_name} estava fraco demais e foi finalizado!\n")

    # Coloca a habilidade em recarga
    cd_base = int(sk.get("cooldown", 2))
    cd_red = meus_triggers.get("pet_cooldown_red_pct", 0)
    my_cds[sk_id] = max(1, int(cd_base * (1.0 - cd_red))) if cd_red else cd_base
    
    room["raid_state"] = rs
    return _raid_end_of_turn(room)



def raid_cleanup_buggy_state(p: dict) -> None:
    """Limpa estados de raid antigos ou bugados automaticamente."""
    room_id = p.get("raid_room_id")
    if room_id:
        room = get_room(room_id)
        if not room or room.get("state") != "RAID_COMBAT":
            # Sala sumiu ou não está em combate → limpa!
            p["raid_room_id"] = None
            p["raid_floor"] = 1
            p["raid_ready"] = False
            p["state"] = "CITY"
            p["hp"] = int(p.get("hpmax", 100))

def raid_force_exit(p: dict) -> str:
    """
    Comando de emergência: limpa TODO estado de raid bugado.
    - Remove raid_room_id
    - Sai da sala (se existir)
    - Reseta HP e estado
    - Salva no banco
    """
    
    room_id = p.get("raid_room_id")
    pid = str(p.get("user_id") or p.get("userid") or p.get("telegram_id"))
    
    if not room_id:
        return "✅ Você não está em nenhuma raid ativa."
    
    # Tenta remover da sala se ela existir
    try:
        room = get_room(room_id)
        if room:
            members = room.get("members", [])
            if pid in members:
                members.remove(pid)
                if "ready_map" in room:
                    room["ready_map"].pop(pid, None)
                
                # Se era o único ou líder, deleta a sala
                if len(members) == 0 or room.get("leader") == pid:
                    delete_room(room_id)
                    msg_sala = "🗑️ Sala deletada (era a última pessoa)."
                else:
                    save_room(room)
                    msg_sala = "✅ Removido da sala."
            else:
                msg_sala = "✅ Não estava mais na sala."
    except Exception as e:
        msg_sala = "⚠️ Erro na sala (já foi deletada)."
    
    # Limpa estado do player
    p["raid_room_id"] = None
    p["raid_floor"] = 1
    p["raid_ready"] = False
    p["hp"] = int(p.get("hpmax", 100))  # Vida cheia
    p["state"] = "CITY"
    
    # Salva no banco
    save_player_sql(int(pid), p)
    
    return f"🚪 **RAID EXIT FORÇADO**\n{msg_sala}\n✅ Estado limpo. Volte à cidade!"
def get_specialty_slots(p: dict) -> list:
    """Garante que o jogador sempre tenha 3 slots de especialidade na memória."""
    if "specialties" not in p:
        sid = p.get("specialty_id")
        if sid and isinstance(sid, str):
            # Converte a string antiga "spec_fogo,spec_sombras" em lista
            p["specialties"] = [x for x in sid.split(",") if x]
        else:
            p["specialties"] = []
            
    specs = p.get("specialties", [])
    while len(specs) < 3:
        specs.append(None)
        
    p["specialties"] = specs[:3]
    return p["specialties"]

def equip_specialty(p: dict, spec_id: str, slot_idx: int) -> str:
    """Equipa uma especialidade e salva no formato compatível com o SQLite."""
    from game.specialties import SPECIALTIES_DB
    if spec_id not in SPECIALTIES_DB: return "❌ Especialidade inválida."

    specs = get_specialty_slots(p)
    
    # Trava: Não deixa equipar a mesma duas vezes
    if spec_id in specs:
        return "⚠️ Você já equipou essa especialidade em outro slot!"
    
    # 🔒 Trava de Nível (A Ideia A!) - Hoje tudo 1, depois mude para 25, 50, 75
    reqs = [1, 1, 1] 
    lvl = int(p.get("level", 1))
    if lvl < reqs[slot_idx]:
        return f"🔒 O Slot {slot_idx+1} requer Nível {reqs[slot_idx]}!"
    
    specs[slot_idx] = spec_id
    # Salva no banco disfarçado de texto (ex: "spec_fogo,spec_vento")
    p["specialty_id"] = ",".join([s for s in specs if s]) 
    recalc(p)
    
    nome = SPECIALTIES_DB[spec_id]['name']
    return f"✅ {nome} equipada no Slot {slot_idx+1}!"

def unequip_specialty(p: dict, slot_idx: int) -> str:
    """Remove a especialidade do slot."""
    specs = get_specialty_slots(p)
    if not specs[slot_idx]: return "⚠️ O slot já está vazio."
    
    specs[slot_idx] = None
    p["specialty_id"] = ",".join([s for s in specs if s])
    recalc(p)
    return "🗑️ Especialidade removida."

def can_learn_skill(p_data: dict, skill_data: dict) -> tuple[bool, str]:
    """
    Tiers 1 a 3: Exige apenas a Classe.
    Tiers 4 e 5: Exige apenas a Especialidade.
    """
    from game.logic import get_specialty_slots
    
    rarity = int(skill_data.get("rarity", 1))
    
    # 🔵 Tiers 1, 2 e 3: Cobra SOMENTE a Classe
    if rarity <= 3:
        req_class = skill_data.get("req_class")
        if req_class:
            p_class = str(p_data.get("class", p_data.get("class_id", ""))).lower()
            if req_class.lower() != p_class:
                return False, f"❌ Seu corpo rejeita esta energia. Requer a classe: [{req_class.capitalize()}]."
                
    # 🟡 Tiers 4 e 5: Cobra SOMENTE a Especialidade
    else:
        req_spec = skill_data.get("req_spec")
        if req_spec:
            p_specs = get_specialty_slots(p_data) # Puxa as especialidades ativas do jogador
            if req_spec not in p_specs:
                return False, f"❌ Conhecimento insuficiente! Requer a especialidade: [{req_spec}]."
                
    # Se passou pela verificação do seu Tier, caminho livre!
    return True, ""
def process_skill_costs(caster: dict, skill: dict, pet: dict = None) -> str:
    """Processa custos de HP e sacrifício de Pets antes da magia sair."""
    log = ""
    
    # 🩸 Custo de Sangue (Berserker)
    hp_cost_pct = skill.get("hp_cost_pct", 0)
    if hp_cost_pct > 0:
        cost = int(caster["hp"] * hp_cost_pct)
        caster["hp"] = max(1, caster["hp"] - cost) # Nunca morre pro próprio custo, fica com 1 HP
        log += f"🩸 {caster['name']} sacrificou {cost} de HP para canalizar a magia!\n"
        
    # 💀 Sacrifício de Pet (Necromante)
    if skill.get("sacrifice_pet") and pet and pet.get("hp", 0) > 0:
        pet_hp = pet["hp"]
        pet["hp"] = 0 # Mata o Pet
        # Salva o dano base do sacrifício na magia temporariamente para o cálculo de dano
        skill["_temp_sac_dmg"] = int(pet_hp * skill.get("sacrifice_mult", 1.0))
        log += f"💀 {caster['name']} detonou {pet['name']}! Uma explosão de ossos se aproxima!\n"
        
    return log
def process_support_effects(caster: dict, target: dict, skill: dict) -> str:
    """Aplica Escudos, Cleanse e Curas por Turno (HoT) no alvo aliado."""
    log = ""
    
    # 🧼 Purificação (Cleanse - Suporte e Espiritualista)
    if skill.get("cleanse"):
        target["dots"] = [] # Limpa venenos/queimaduras
        target["stun"] = 0  # Remove atordoamento
        target["debuffs"] = {} # Limpa quebras de armadura
        log += f"✨ Uma luz divina purificou {target['name']} de todos os males!\n"
        
    # 🛡️ Escudo de Vida Temporária (Tanker e Apoio)
    shield_pct = skill.get("shield_pct", 0)
    if shield_pct > 0:
        # O escudo escala com o Ataque (ou Poder Mágico) do conjurador
        shield_amt = int(caster.get("atk", 10) * shield_pct)
        target["shield"] = target.get("shield", 0) + shield_amt
        log += f"🛡️ {target['name']} recebeu uma barreira de {shield_amt} HP!\n"
        
    # 🌿 Heal over Time (Cura por Turno - Equilíbrio)
    hot_pct = skill.get("hot_pct", 0)
    if hot_pct > 0:
        hot_amt = int(caster.get("atk", 10) * hot_pct)
        target.setdefault("hots", []).append({
            "heal": hot_amt,
            "turns": skill.get("hot_turns", 3)
        })
        log += f"🌿 {target['name']} foi abençoado e vai curar {hot_amt} HP por turno!\n"
        
    return log
def calculate_tactical_damage(caster: dict, target: dict, skill: dict, base_damage: int) -> tuple[int, str]:
    """Modifica o dano final baseado nas mecânicas especiais e aplica Lifesteal/Detonação."""
    log = ""
    final_damage = base_damage
    
    # 💀 Somar Dano do Sacrifício (Necromante)
    if "_temp_sac_dmg" in skill:
        final_damage += skill["_temp_sac_dmg"]
        del skill["_temp_sac_dmg"] # Limpa a variável
        
    # 🎯 Marca de Vulnerabilidade (Caçador)
    # Se o Boss tiver o debuff "mark", ele toma mais dano de qualquer um!
    if target.get("debuffs", {}).get("mark_dmg_bonus"):
        bonus = target["debuffs"]["mark_dmg_bonus"]
        final_damage = int(final_damage * (1.0 + bonus))
        log += f"🎯 A Marca da Presa brilhou! (+{int(bonus*100)}% Dano)\n"

    # 🩸 Execução Mágica (Assassino Fatal / Guerreiro Espada)
    execute_pct = skill.get("execute_pct", 0)
    if execute_pct > 0:
        # Calcula quanta vida FALTA no alvo (Ex: se tem 20% de vida, faltam 80%)
        missing_hp_pct = 1.0 - (target["hp"] / target["hp_max"])
        # Multiplicador extra = Dano Base * (Porcentagem de Vida Faltando * Multiplicador de Execução)
        exec_bonus = 1.0 + (missing_hp_pct * execute_pct)
        final_damage = int(final_damage * exec_bonus)
        if missing_hp_pct > 0.5:
            log += f"⚖️ GOLPE DE MISERICÓRDIA! O dano foi amplificado pela fraqueza do alvo!\n"
            
    # 💥 Detonação de Status (Mago Fogo / Assassino Veneno)
    if skill.get("detonate") and target.get("dots"):
        detonation_dmg = 0
        for dot in target["dots"]:
            # Dano do veneno * turnos restantes
            detonation_dmg += dot["damage"] * dot["turns_left"]
        
        final_damage += detonation_dmg
        target["dots"] = [] # Remove todos os DoTs do Boss
        log += f"💥 DETONAÇÃO! Todos os efeitos no alvo explodiram causando {detonation_dmg} de dano extra!\n"

    # 🦇 Lifesteal (Roubo de Vida - Berserker Sanguinário)
    lifesteal_pct = skill.get("lifesteal_pct", 0)
    if lifesteal_pct > 0:
        heal_amt = int(final_damage * lifesteal_pct)
        caster["hp"] = min(caster["hp_max"], caster["hp"] + heal_amt)
        log += f"🦇 {caster['name']} sugou {heal_amt} de HP do ataque!\n"
        
    return final_damage, log
import random

# =====================================================================
# ⚔️ MOTOR DE COMBATE: PROCESSAMENTO DE MAGIAS E ATAQUES
# =====================================================================
def apply_damage_with_shield(target: dict, raw_damage: int) -> tuple[int, int]:
    """Aplica o dano primeiro no Escudo, e o resto no HP. Retorna (Dano no Escudo, Dano no HP)"""
    shield = target.get("shield", 0)
    if shield >= raw_damage:
        target["shield"] -= raw_damage
        return raw_damage, 0 # Escudo absorveu tudo
    else:
        damage_to_hp = raw_damage - shield
        target["shield"] = 0
        target["hp"] = max(0, target.get("hp", 0) - damage_to_hp)
        return shield, damage_to_hp


# =====================================================================
# ⏳ MOTOR DE TURNOS: PROCESSAR FINAIS DE TURNO (Veneno, Cura e Escudo)
# =====================================================================
def process_end_of_turn(entity: dict) -> str:
    """Roda no final do turno da entidade (Jogador ou Boss) para dar dano de veneno, curar HoT, etc."""
    log = ""
    
    # 1. Processar Cura por Turno (HoT)
    hots = entity.get("hots", [])
    alive_hots = []
    for hot in hots:
        heal = hot["heal"]
        entity["hp"] = min(entity.get("hp_max", 100), entity.get("hp", 1) + heal)
        log += f"🌿 Regenerou {heal} HP.\n"
        hot["turns_left"] -= 1
        if hot["turns_left"] > 0:
            alive_hots.append(hot)
    entity["hots"] = alive_hots

    # 2. Processar Dano por Turno (DoT - Veneno/Fogo)
    dots = entity.get("dots", [])
    alive_dots = []
    for dot in dots:
        dmg = dot["damage"]
        # DoT ignora escudo e vai direto no HP!
        entity["hp"] = max(0, entity.get("hp", 1) - dmg)
        log += f"☠️ Sofreu {dmg} de dano de {dot['name']}.\n"
        dot["turns_left"] -= 1
        if dot["turns_left"] > 0:
            alive_dots.append(dot)
    entity["dots"] = alive_dots

    # 3. Reduzir duração de Stun e Silêncio
    if entity.get("stun", 0) > 0:
        entity["stun"] -= 1
        
    debuffs = entity.setdefault("debuffs", {})
    if debuffs.get("silence", 0) > 0:
        debuffs["silence"] -= 1
        if debuffs["silence"] <= 0:
            del debuffs["silence"]
            
    if debuffs.get("mark_turns", 0) > 0:
        debuffs["mark_turns"] -= 1
        if debuffs["mark_turns"] <= 0:
            if "mark_dmg_bonus" in debuffs: del debuffs["mark_dmg_bonus"]
            del debuffs["mark_turns"]

    # 🔥 (08/07/2026): DEF e ATK reduzidos também precisam expirar.
    # O def_turns já era GRAVADO pelo debuff_def, mas ninguém contava —
    # na prática o debuff durava a batalha inteira. O atk_turns é da
    # correção nova do debuff_atk.
    if debuffs.get("def_turns", 0) > 0:
        debuffs["def_turns"] -= 1
        if debuffs["def_turns"] <= 0:
            debuffs.pop("def_pct", None)
            debuffs.pop("def_turns", None)

    if debuffs.get("atk_turns", 0) > 0:
        debuffs["atk_turns"] -= 1
        if debuffs["atk_turns"] <= 0:
            debuffs.pop("atk_pct", None)
            debuffs.pop("atk_turns", None)

    return log
def roll_pet_gacha(p: dict, amount: int) -> tuple[bool, str, list]:
    """Realiza a evocação de espíritos. Amount pode ser 1 ou 11."""
    from game.pets_db import PETS_DB
    
    # Prepara o custo e quantidade real
    cost = 1000 if amount == 1 else 10000
    actual_amount = 1 if amount == 1 else 11

    if p.get("gold", 0) < cost:
        return False, f"❌ Ouro insuficiente. Você precisa de {cost}g.", []

    # Desconta o ouro
    p["gold"] -= cost

    # Separa os IDs por raridade (Otimização para não fazer isso hardcoded)
    pool = {"comum": [], "incomum": [], "raro": [], "epico": [], "lendario": []}
    for pet_id, pet_data in PETS_DB.items():
        pool[pet_data["rarity"]].append(pet_id)

    rolled = []
    # Roleta Russa!
    for _ in range(actual_amount):
        rng = random.uniform(0, 100)
        
        if rng <= 0.1:
            rarity = "lendario"
        elif rng <= 2.0: # 1.9%
            rarity = "epico"
        elif rng <= 12.0: # 10%
            rarity = "raro"
        elif rng <= 40.0: # 28%
            rarity = "incomum"
        else: # 60%
            rarity = "comum"
        
        # Sorteia um pet aleatório dentro daquela raridade
        chosen_pet = random.choice(pool[rarity])
        rolled.append(chosen_pet)
        
        # Adiciona à mochila do jogador
        p_pets = p.setdefault("pets", {}).setdefault("owned", {})
        if chosen_pet not in p_pets:
            p_pets[chosen_pet] = 0
        p_pets[chosen_pet] += 1

    return True, "✅ Evocação realizada com sucesso!", rolled
def pet_slots_liberados(p: dict) -> int:
    """Quantos slots de pet o jogador já pode usar, com base no andar da
    Torre. 🔥 (09/07/2026): antes o sistema abria os 5 de uma vez no Andar
    10. Agora é progressivo — dá um objetivo de longo prazo:
    Andar 10 → 1 slot, 20 → 2, 30 → 3, 40 → 4, 50 → 5."""
    floor = int(p.get("tower_floor", 1))
    if floor < 10:
        return 0
    return min(5, floor // 10)


def equip_pet(p: dict, pet_id: str, slot_idx: int) -> str:
    """Equipa um espírito num slot específico e impede duplicações."""
    p_pets = p.setdefault("pets", {}).setdefault("owned", {})
    deck = p["pets"].setdefault("deck", [None]*5)
    
    if pet_id == "remove":
        deck[slot_idx] = None
        recalc(p)
        return "🗑️ Slot de espírito esvaziado."

    # 🔒 (09/07/2026): trava progressiva por andar
    liberados = pet_slots_liberados(p)
    if slot_idx >= liberados:
        andar_necessario = (slot_idx + 1) * 10
        return f"🔒 O {slot_idx + 1}º slot de espírito libera no Andar {andar_necessario} da Torre."

    if p_pets.get(pet_id, 0) <= 0:
        return "❌ Não possuis este espírito."

    # Remove o pet se ele já estiver noutro slot (para evitar clones)
    for i in range(len(deck)):
        if deck[i] == pet_id:
            deck[i] = None
            
    deck[slot_idx] = pet_id
    recalc(p) # Recalcula imediatamente os bónus!
    return "✅ Espírito invocado para o teu esquadrão!"

import copy

def process_pets_start_of_turn(p: dict, cmb: dict) -> tuple[list[str], int]:
    """Processa o turno dos Espíritos de forma 100% isolada, sem afetar o core do jogo."""
    logs = []
    morto_idx = -1
    
    try:
        from game.pets_db import PETS_DB
        
        deck = p.get("pets", {}).get("deck", [None]*5)
        enemies = cmb.get("enemies", [])
        
        if not enemies: return logs, morto_idx
        
        alvo_idx = p.get("combat_target", 0)
        if alvo_idx >= len(enemies) or enemies[alvo_idx].get("hp", 0) <= 0:
            alvo_idx = 0
            
        en = enemies[alvo_idx]
        nome_inimigo = en.get("name", "Inimigo")
        
        # 🧠 O SEGREDO: Criamos uma memória de recarga só para os pets nesta batalha
        pet_cds = cmb.setdefault("pet_cooldowns", {})
        
        for i, pet_id in enumerate(deck):
            # Ignora slots vazios ou se o inimigo alvo já está morto
            # 🔥 CORRIGIDO: antes só pulava enquanto "morto_idx == -1", então
            # assim que UM pet matava o alvo no mesmo turno, os pets seguintes
            # continuavam batendo/logando no cadáver (dano e "aniquilou"
            # duplicados). Agora, uma vez morto, ninguém mais age nele.
            if not pet_id: continue
            if en.get("hp", 0) <= 0: continue
            
            pet = PETS_DB.get(pet_id)
            auto_sk = pet.get("auto_skill") if pet else None
            
            if auto_sk:
                sk_id = auto_sk.get("skill_id", "a_fire_1")
                cd_max = int(auto_sk.get("cooldown", 5))
                cd_key = f"slot_{i}_{pet_id}"
                
                # 🔥 A CORREÇÃO MÁGICA: Se é o primeiro turno, o pet entra "carregando" o ataque!
                if cd_key not in pet_cds:
                    pet_cds[cd_key] = cd_max
                
                # 1. Tira 1 turno de recarga deste pet logo no início
                if pet_cds[cd_key] > 0:
                    pet_cds[cd_key] -= 1
                
                # 2. Se a recarga ainda for maior que zero, ele pula o turno e não bate
                if pet_cds[cd_key] > 0:
                    continue
                
                # 3. SE CHEGOU AQUI: O COOLDOWN ZEROU! HORA DO SHOW!
                skill_base = get_skill_by_id(sk_id)
                
                # Proteção: Avisa no Telegram se esqueceste de criar a skill
                if not skill_base:
                    logs.append(f"⚠️ [DEV] Skill '{sk_id}' do {pet['name']} não existe!\n")
                    continue
                    
                sk_data = skill_base.get("skill", {})
                nome_skill = sk_data.get("name", "Magia")
                tipo_skill = sk_data.get("type", "active")
                
                # Calcula o Efeito com o nerf do pet
                base_atk = int(p.get("atk", 10))
                mult = float(sk_data.get("mult", 1.0))
                power = float(auto_sk.get("power_mult", 0.3))
                efeito_total = max(1, int(base_atk * mult * power))
                
 # ==========================================
                # ✨ IA MESTRE DO PET (Suporte vs Dano)
                # ==========================================
                is_support = sk_data.get("heal_percent", 0) > 0 or sk_data.get("shield_pct", 0) > 0 or sk_data.get("cleanse") or tipo_skill == "heal" or sk_data.get("target") in ["ally", "self"]

                if is_support:
 # Lógica de Cura
# Lógica de Cura (Escalando com o ATK do Jogador)
                    if sk_data.get("heal_percent", 0) > 0:
                        # Puxa a % de cura da magia e multiplica pelo poder do pet (ex: 0.7)
                        pct_cura = float(sk_data["heal_percent"]) * power
                        
                        # 🔥 A CURA AGORA ESCALA COM O ATAQUE!
                        cura_base = int(base_atk * pct_cura)
                        
                        # Garante que cure no mínimo 1 e não ultrapasse o HP Máximo
                        cura_real = min(p.get("hp_max", 100) - p.get("hp", 0), max(1, cura_base))
                        
                        if cura_real > 0:
                            p["hp"] += cura_real
                            logs.append(f"✨ 🧚 <b>{pet['name']}</b> conjurou <i>{nome_skill}</i> e curou <b>{cura_real}</b> de HP!\n")
                    if sk_data.get("shield_pct", 0) > 0:
                        shield_amt = int(base_atk * float(sk_data["shield_pct"]) * power)
                        p["shield"] = p.get("shield", 0) + shield_amt
                        logs.append(f"🛡️ 🧚 <b>{pet['name']}</b> concedeu <b>{shield_amt}</b> de Escudo com <i>{nome_skill}</i>!\n")
                
                # ==========================================
                # ⚔️ LÓGICA DE DANO E STATUS (Ex: Lobo/Javali)
                # ==========================================
                else:
                    novo_hp = max(0, en.get("hp", 1) - efeito_total)
                    en["hp"] = novo_hp
                    logs.append(f"✨ 🐉 <b>{pet['name']}</b> conjurou <i>{nome_skill}</i> e causou <b>{efeito_total}</b> de dano em {nome_inimigo}!\n")
                    
                    # Aplica Stun do Pet (Adicionado!)
                    if sk_data.get("stun", 0) > 0:
                        if random.randint(1, 100) <= 35:
                            en["stun"] = en.get("stun", 0) + int(sk_data["stun"])
                            logs.append(f"💫 {nome_inimigo} foi atordoado pelo Pet!\n")
                        else:
                            logs.append(f"🛡️ {nome_inimigo} resistiu ao atordoamento do Pet!\n")

                    # Aplica DoTs se houver
                    if "dot_mult" in sk_data and novo_hp > 0:
                        dot_dmg = max(1, int(base_atk * float(sk_data["dot_mult"]) * power))
                        en.setdefault("dots", []).append({
                            "name": sk_data.get("dot_name", "Efeito"),
                            "dmg": dot_dmg,
                            "turns": int(sk_data.get("dot_turns", 2))
                        })
                        logs.append(f"🧪 {nome_inimigo} foi afligido por {sk_data.get('dot_name', 'Efeito')}!\n")
                        
                    # Verifica Kill
                    if novo_hp <= 0:
                        morto_idx = alvo_idx
                        logs.append(f"💀 <b>{pet['name']} aniquilou {nome_inimigo}!</b>\n")
                
                # 4. RESETA A RECARGA APÓS O USO
                # Se tu colocaste cooldown: 1 no DB, ele vai setar como 1. 
                # No próximo turno o código lá em cima tira 1 (fica 0) e ele bate de novo!
                pet_cds[cd_key] = cd_max

    except Exception as e:
        logs.append(f"⚠️ [DEV ERRO PETS]: {e}\n")
        
    return logs, morto_idx


# =============================================================================
# ✨ ITENS MÍTICOS (08/07/2026) — item equipado age SOZINHO em combate, com
# skill e cooldown próprios, sem ocupar nenhum dos 5 slots de skill normais.
# Mesmo motor confiável dos pets (process_pets_start_of_turn), só que lendo
# de `p["equip"][slot]["mythic_skill"]` em vez do deck de pets.
# =============================================================================
def process_mythic_items_start_of_turn(p: dict, cmb: dict) -> tuple[list[str], int]:
    logs = []
    morto_idx = -1

    try:
        alvo_idx = p.get("combat_target", 0)
        enemies = cmb.get("enemies") or []
        if not enemies:
            return logs, -1
        if alvo_idx >= len(enemies) or enemies[alvo_idx].get("hp", 0) <= 0:
            alvo_idx = 0
        en = enemies[alvo_idx]
        nome_inimigo = en.get("name", "Inimigo")

        mitico_cds = cmb.setdefault("mythic_cooldowns", {})
        equip = p.get("equip", {}) or {}

        for slot, item in equip.items():
            if not item or not isinstance(item, dict):
                continue
            if item.get("rar") != "mythic":
                continue
            auto_sk = item.get("mythic_skill")
            if not auto_sk:
                continue
            if en.get("hp", 0) <= 0:
                continue

            sk_id = auto_sk.get("skill_id", "a_fire_1")
            cd_max = int(auto_sk.get("cooldown", 4))
            cd_key = f"mythic_{slot}_{item.get('id', sk_id)}"

            if cd_key not in mitico_cds:
                mitico_cds[cd_key] = cd_max
            if mitico_cds[cd_key] > 0:
                mitico_cds[cd_key] -= 1
            if mitico_cds[cd_key] > 0:
                continue

            skill_base = get_skill_by_id(sk_id)
            if not skill_base:
                logs.append(f"⚠️ [DEV] Skill mítica '{sk_id}' não existe!\n")
                continue

            sk_data = skill_base.get("skill", {})
            nome_skill = sk_data.get("name", "Poder Mítico")
            nome_item = item.get("name", "Item Mítico")

            base_atk = int(p.get("atk", 10))
            mult = float(sk_data.get("mult", 1.0))
            power = float(auto_sk.get("power_mult", 0.6))  # itens míticos batem mais forte que pets
            efeito_total = max(1, int(base_atk * mult * power))

            is_support = (
                sk_data.get("heal_percent", 0) > 0 or sk_data.get("shield_pct", 0) > 0
                or sk_data.get("target") in ("self", "ally")
            )

            if is_support:
                if sk_data.get("heal_percent", 0) > 0:
                    pct_cura = float(sk_data["heal_percent"]) * power
                    cura_base = int(base_atk * pct_cura)
                    cura_real = min(p.get("hp_max", 100) - p.get("hp", 0), max(1, cura_base))
                    if cura_real > 0:
                        p["hp"] += cura_real
                        logs.append(f"✨ 💠 <b>{nome_item}</b> conjurou <i>{nome_skill}</i> e curou <b>{cura_real}</b> de HP!\n")
                if sk_data.get("shield_pct", 0) > 0:
                    shield_amt = int(base_atk * float(sk_data["shield_pct"]) * power)
                    p["shield"] = p.get("shield", 0) + shield_amt
                    logs.append(f"🛡️ 💠 <b>{nome_item}</b> concedeu <b>{shield_amt}</b> de Escudo com <i>{nome_skill}</i>!\n")
            else:
                novo_hp = max(0, en.get("hp", 1) - efeito_total)
                en["hp"] = novo_hp
                logs.append(f"✨ 💠 <b>{nome_item}</b> conjurou <i>{nome_skill}</i> e causou <b>{efeito_total}</b> de dano em {nome_inimigo}!\n")

                if sk_data.get("stun", 0) > 0 and random.randint(1, 100) <= 35:
                    en["stun"] = en.get("stun", 0) + int(sk_data["stun"])
                    logs.append(f"💫 {nome_inimigo} foi atordoado pelo poder mítico!\n")

                if "dot_mult" in sk_data and novo_hp > 0:
                    dot_dmg = max(1, int(base_atk * float(sk_data["dot_mult"]) * power))
                    en.setdefault("dots", []).append({
                        "name": sk_data.get("dot_name", "Efeito"),
                        "dmg": dot_dmg,
                        "turns": int(sk_data.get("dot_turns", 2))
                    })
                    logs.append(f"🧪 {nome_inimigo} foi afligido por {sk_data.get('dot_name', 'Efeito')}!\n")

                if novo_hp <= 0:
                    morto_idx = alvo_idx
                    logs.append(f"💀 <b>{nome_item} aniquilou {nome_inimigo}!</b>\n")

            mitico_cds[cd_key] = cd_max

    except Exception as e:
        logs.append(f"⚠️ [DEV ERRO MÍTICO]: {e}\n")

    return logs, morto_idx


def auto_battle(p: dict, max_turns: int = 30) -> str:
    """🤖 AUTOBATALHA (08/07/2026): resolve o resto do combate sozinho —
    usa skill pronta quando tem (senão ataque básico) — até vencer, morrer,
    ou estourar o limite de segurança de turnos. Reaproveita 100% o motor
    de combate normal (combat_attack/execute_combat_skill), só automatiza
    a escolha da ação."""
    turnos = 0
    while turnos < max_turns:
        cmb = p.get("combat")
        if not cmb or not cmb.get("enemies"):
            break  # vitória
        if p.get("hp", 0) <= 0:
            break  # morreu

        turnos += 1

        # Escolhe a melhor ação disponível: 1ª skill pronta > ataque básico
        skill_escolhida = None
        equipped = (p.get("skill_slots") or {}).get("equipped", [])
        cooldowns = cmb.get("p_cooldowns", {})
        for sk_id in equipped:
            if sk_id and cooldowns.get(sk_id, 0) <= 0:
                base = get_skill_by_id(sk_id)
                if base and base.get("skill", {}).get("type") == "active":
                    skill_escolhida = sk_id
                    break

        if skill_escolhida:
            msg = execute_combat_skill(p, skill_escolhida)
        else:
            msg = combat_attack(p)

        if msg and isinstance(p.get("combat"), dict):
            p["combat"].setdefault("history", []).append(msg)

        # 🔥 (09/07/2026): guarda a última mensagem — é ela que carrega o
        # resultado da vitória (drops de item/core/ouro/xp de
        # _on_enemy_killed). Antes a autobatalha só devolvia "resolveu N
        # turnos" e o jogador nunca via o que dropou.
        ultima_msg = msg

        if p.get("hp", 0) <= 0:
            break

    # Monta o resultado final incluindo o que dropou no último golpe.
    venceu = not (isinstance(p.get("combat"), dict) and p["combat"].get("enemies"))
    morreu = p.get("hp", 0) <= 0

    cabecalho = f"🤖 <b>Autobatalha:</b> {turnos} turno(s) resolvido(s)."
    if morreu:
        cabecalho = f"🤖 <b>Autobatalha:</b> você caiu após {turnos} turno(s)."
    elif venceu:
        cabecalho = f"🤖 <b>Autobatalha concluída!</b> ({turnos} turnos)"

    # Anexa o log da última ação, que traz drops/recompensas
    if 'ultima_msg' in dir() and ultima_msg:
        # tira linhas de barra de vida repetitiva pra não poluir; mantém o
        # que interessa (drop de core/item, ouro, xp, level up, vitória)
        linhas_uteis = [
            l for l in str(ultima_msg).split("\n")
            if any(k in l for k in [
                "💎", "🎁", "💰", "✨", "📦", "⭐", "🏆", "🔒",
                "XP", "Drop", "drop", "VITÓRIA", "venceu",
                "Level", "LEVEL", "Nível", "subiu", "g +",
            ])
        ]
        # remove linhas vazias ou só com espaços
        linhas_uteis = [l for l in linhas_uteis if l.strip()]
        if linhas_uteis:
            cabecalho += "\n\n<b>Resultado:</b>\n" + "\n".join(linhas_uteis)

    return cabecalho


def claim_all_rewards(p: dict) -> str:
    """Processa o resgate do Cultivo Passivo (XP por minuto offline).

    OBS: o login diário NÃO é mais processado aqui — foi unificado em
    `claim_daily_reward()` para evitar dois sistemas de streak conflitando
    entre si (bug corrigido em 06/07/2026: havia duas fontes de verdade
    para `daily_streak`, uma baseada em timestamp e outra em data).
    """
    import time

    now = int(time.time())
    msg_parts = []

    # ==========================================
    # ⏳ 1. XP POR MINUTO (Cultivo de Aura)
    # ==========================================
    last_tick = p.get("last_xp_tick", now)
    delta = now - last_tick
    minutos = delta // 60
    
    if minutos > 0:
        # Cap máximo de 24 horas (1440 minutos)
        minutos_reais = min(minutos, 1440)
        andar = int(p.get("tower_floor", 1))
        
        # Fórmula: Andar 1-9 (1XP), 10-19 (1XP), 20-29 (2XP)... Max 10.
        xp_por_minuto = max(1, min(10, andar // 10))
        
        xp_ganho = minutos_reais * xp_por_minuto
        
        # Avança o relógio salvando os "segundos residuais" pra não roubar o jogador
        p["last_xp_tick"] += minutos * 60
        
        msg_up_passivo = gain_xp(p, xp_ganho)

        # 🔥 CORRIGIDO (08/07/2026): antes essa mensagem sempre dizia "+X XP",
        # mesmo quando a trava de nível (nível >= andar×2) zerava o ganho por
        # completo — por isso parecia que "o XP AFK não soma": ele realmente
        # não somava, só que o jogo dizia que tinha somado.
        if p.get("_last_xp_capped"):
            limite_level = andar * 2
            msg_parts.append(
                f"⏳ <b>CULTIVO DE AURA:</b> {minutos_reais} minutos se passaram, mas você já "
                f"está no nível máximo pro Andar {andar} (Lv {limite_level}). "
                f"Suba de andar pra voltar a ganhar XP passivo!"
            )
        else:
            msg_parts.append(f"⏳ <b>CULTIVO DE AURA:</b> +{xp_ganho} XP ({minutos_reais} min).{msg_up_passivo}")

    # ==========================================
    # 🏁 3. RETORNO DA AÇÃO
    # ==========================================
    if not msg_parts:
        return "❌ <b>Nada para coletar ainda!</b>\nVocê precisa esperar pelo menos 1 minuto de cultivo passivo. Para a recompensa diária, use o botão 🎁 Diária."
        
    return "\n\n".join(msg_parts)
import datetime

# ==========================================
# 🎁 SISTEMA DE RECOMPENSA DIÁRIA
# ==========================================
def claim_daily_reward(p: dict) -> tuple[bool, str]:
    """Resgata o login diário, calculando ofensiva (streak) de dias seguidos."""
    hoje = datetime.datetime.now().strftime("%Y-%m-%d")
    ontem = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
    
    ultimo_login = p.get("daily_login_date", "")
    
    if ultimo_login == hoje:
        return False, "❌ <b>Você já pegou sua recompensa hoje!</b>\nOs deuses descansam. Volte amanhã!"
        
    streak = int(p.get("daily_streak", 0))
    
    # Checa se ele entrou ontem para manter o Streak (ofensiva)
    if ultimo_login == ontem:
        streak += 1
    else:
        streak = 1 # Perdeu a ofensiva ou é o primeiro dia
        
    if streak > 7:
        streak = 7 # Limita o bônus máximo a 7 dias
        
    p["daily_streak"] = streak
    p["daily_login_date"] = hoje
    
    # 💰 Multiplicadores Base (Aumente como quiser)
    ouro_ganho = 500 * streak
    xp_ganho = 100 * streak
    
    p["gold"] = int(p.get("gold", 0)) + ouro_ganho
    
    # Reutiliza sua função nativa de XP para ver se ele sobe de level
    from game.logic import gain_xp
    msg_xp = gain_xp(p, xp_ganho)
    
    msg = f"🎁 <b>RECOMPENSA DIÁRIA RESGATADA!</b>\n"
    msg += f"🔥 Ofensiva: <b>{streak} dia(s) seguidos!</b>\n\n"
    msg += f"💰 +{ouro_ganho} Ouro\n"
    msg += f"✨ +{xp_ganho} XP\n"
    
    if msg_xp:
        msg += msg_xp
        
    # Bônus Master pro dia 7!
    if streak == 7:
        inv = p.setdefault("inv", {})
        inv["potion"] = inv.get("potion", 0) + 3
        msg += "\n💊 <b>Bônus de 7 Dias:</b> +3 Poções!"
        
    return True, msg

# ==========================================
# 👼 SISTEMA DE REVIVER GRÁTIS (5 HORAS)
# ==========================================
# 🛡️ 20/09/2026 (dev): PRIVILÉGIO DO NOVATO. Até o andar 10 a morte não
# cobra nada: o portal divino abre sempre, sem cooldown e sem ouro. É a
# faixa em que o jogador ainda está aprendendo o que mata — e perder a
# conta ali é perder o jogador.
ANDAR_DO_NOVATO = 10
# 💰 Reviver na hora (fora da faixa do novato, com o portal fechado):
# 20.000 de ouro — ~3 dias de diárias, caro o bastante pra doer.
CUSTO_REVIVER_OURO = 20_000


def e_novato(p: dict) -> bool:
    return int(p.get("tower_floor") or 1) <= ANDAR_DO_NOVATO


def get_free_revive_cooldown(p: dict) -> int:
    import time
    agora = int(time.time())
    
    # 🔥 O "or 0" impede crash se a chave for nula ou vazia no banco!
    ultimo_revive = int(p.get("last_free_revive") or 0) 
    cooldown = 5 * 3600
    
    tempo_passado = agora - ultimo_revive
    if tempo_passado >= cooldown:
        return 0
    return cooldown - tempo_passado

def free_revive_player(p: dict) -> tuple[bool, str]:
    import time
    
    falta = 0 if e_novato(p) else get_free_revive_cooldown(p)
    if falta > 0:
        h = falta // 3600
        m = (falta % 3600) // 60
        return False, f"⏳ <b>Ainda não!</b> O portal divino está fechado.\nVolte em {h}h{m:02d}m."
        
    if not e_novato(p):
        p["last_free_revive"] = int(time.time())
    p["combat"] = None
    p["state"] = "CITY"
    
    # 🔥 Blindagem contra erros de valor nulo no HP e Andar!
    hp_maximo = int(p.get("hp_max") or 100)
    p["hp"] = max(1, int(hp_maximo * 0.5))
    
    andar_atual = int(p.get("tower_floor") or 1)
    # O novato não perde nem o andar: até o 10, morrer é só um susto.
    p["tower_floor"] = andar_atual if e_novato(p) else max(1, andar_atual - 1)

    if e_novato(p):
        msg = ("👼 <b>PROTEÇÃO DO NOVATO!</b>\n"
               f"Até o andar {ANDAR_DO_NOVATO} a morte não cobra nada: você voltou à cidade "
               "com metade da vida, sem perder o andar e sem esperar.\n\n"
               f"<i>Do andar {ANDAR_DO_NOVATO + 1} em diante, o portal divino fecha por 5 horas.</i>")
    else:
        msg = ("👼 <b>MILAGRE DIVINO!</b>\n"
               "Uma Valquíria desceu dos céus e puxou sua alma do submundo!\n"
               "Sua vida foi restaurada pela metade e você voltou à cidade.\n\n"
               "<i>⏳ O portal divino se fechou por 5 horas.</i>")
    return True, msg


def revive_pago(p: dict) -> tuple[bool, str]:
    """💰 Reviver na hora pagando OURO, com o portal divino fechado. Não mexe
    no cooldown: é o atalho de quem tem ouro e não quer esperar."""
    if p.get("state") != "DEAD":
        return False, "Você não está morto."
    if int(p.get("gold", 0)) < CUSTO_REVIVER_OURO:
        return False, (f"💰 Reviver na hora custa {CUSTO_REVIVER_OURO:,}".replace(",", ".")
                       + f" de ouro; você tem {int(p.get('gold', 0)):,}".replace(",", ".") + ".")
    p["gold"] = int(p.get("gold", 0)) - CUSTO_REVIVER_OURO
    p["combat"] = None
    p["state"] = "CITY"
    p["hp"] = max(1, int(int(p.get("hp_max") or 100) * 0.5))
    p["tower_floor"] = max(1, int(p.get("tower_floor") or 1) - 1)
    return True, (f"💰 Você pagou {CUSTO_REVIVER_OURO:,}".replace(",", ".")
                  + " de ouro e voltou à cidade com metade da vida.")

