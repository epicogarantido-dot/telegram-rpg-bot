# game/craft.py
from __future__ import annotations

import random
import string

from game.items import (
    RARITIES,
    REQ_CRAFT,
    WEAPON_TYPES,
    core_bonus,
    core_name,
    apply_bonus,
    INV_ITEMS_PER_SLOT,
    core_base_and_tier,
)

# --- CUSTO EM GOLD POR RARIDADE ---
COST_CRAFT = {
    "common": 100,
    "uncommon": 200,
    "rare": 400,
    "epic": 800,
    "legendary": 1600,
}

# Apenas texto informativo para mostrar no resumo do craft
RARITY_BONUS_TEXT = {
    "common": "+4% no atributo principal do item",
    "uncommon": "+8% no atributo principal do item",
    "rare": "+12% no atributo principal do item",
    "epic": "+16% no atributo principal do item",
    "legendary": "+20% no atributo principal do item",
}


NOME_DA_PECA = {"weapon": "Arma", "armor": "Armadura", "helmet": "Elmo", "gloves": "Luvas",
                "boots": "Botas", "shield": "Escudo", "belt": "Cinto", "necklace": "Colar", "ring": "Anel"}


def nome_bonito_do_item(nome: str) -> str:
    """Peça forjada antes da correção tem o nome cru ("armor Comum"): na tela,
    troca a primeira palavra pelo nome da peça."""
    partes = str(nome or "").split(" ", 1)
    if partes and partes[0] in NOME_DA_PECA:
        return " ".join([NOME_DA_PECA[partes[0]]] + partes[1:])
    return nome


def gen_item_id() -> str:
    """Gera ID único para item."""
    return "".join(random.choices(string.ascii_uppercase + string.digits, k=8))


def inv_add_stack(d: dict, key: str, qty: int = 1) -> None:
    """
    Adiciona o core diretamente na categoria certa (cores) se for um core.
    """
    base_id, _ = core_base_and_tier(key)

    forge_ids = ["wa_atk", "ar_def", "ac_atk", "ac_def", "crit", "acc", "eva", "spd", "reg"]

    if base_id in forge_ids or base_id.startswith("core_"):
        if "cores" not in d:
            d["cores"] = {}
        d["cores"][key] = int(d["cores"].get(key, 0)) + int(qty)
    else:
        d[key] = int(d.get(key, 0)) + int(qty)


def inv_remove_stack(d: dict, key: str, qty: int = 1) -> bool:
    if int(d.get(key, 0)) < int(qty):
        return False
    d[key] = int(d.get(key, 0)) - int(qty)
    if d[key] <= 0:
        d.pop(key, None)
    return True


def can_store_item(p: dict, slot: str) -> bool:
    return len(p["inv"]["items"].get(slot, [])) < int(INV_ITEMS_PER_SLOT)


def store_item(p: dict, slot: str, item: dict) -> bool:
    if not can_store_item(p, slot):
        return False
    p["inv"]["items"].setdefault(slot, []).append(item)
    return True


def craft_reset(p: dict) -> None:
    p["craft"] = {"slot": None, "rar": None, "sub": None, "sel": []}


def craft_toggle_core(p: dict, cid: str) -> None:
    inv = p["inv"]["cores"]
    if int(inv.get(cid, 0)) <= 0:
        return

    base_id, _ = core_base_and_tier(cid)
    craftable_ids = ["wa_atk", "ar_def", "ac_atk", "ac_def", "crit", "acc", "eva", "spd", "reg"]
    if base_id not in craftable_ids:
        return

    rar = p["craft"].get("rar")
    if rar not in RARITIES:
        return

    need = int(RARITIES[rar]["cores"])
    sel = p["craft"]["sel"]

    sel_count = sel.count(cid)
    inv_count = int(inv.get(cid, 0))

    if len(sel) < need and sel_count < inv_count:
        sel.append(cid)
        return

    if sel_count > 0:
        sel.remove(cid)


def material_disponivel(p: dict, rank: int, owner_id: int | None = None) -> dict:
    """Quanto material de um rank existe pra forja: a mochila do personagem
    (o que ele ganhou na Torre) e o estoque do clã. As duas contam."""
    mochila = int((p.get("materiais_torre") or {}).get(str(int(rank)), 0))
    cla = 0
    if owner_id is not None:
        try:
            from game.clan_repo import carregar_clan
            cla = int((carregar_clan(int(owner_id))["materiais"] or {}).get(int(rank), 0))
        except Exception:
            cla = 0
    return {"mochila": mochila, "cla": cla, "total": mochila + cla}


def custo_material(rar: str, sel: list) -> dict | None:
    """Rank e quantidade de material pra forjar `rar` com os cores `sel`:
    o piso da raridade + `MATERIAL_POR_TIER` por tier acima do 1 de cada
    core. Uma função só — a Forja, a rota e a tela usam a mesma conta."""
    from game.items import REQ_MATERIAL_CRAFT, MATERIAL_POR_TIER
    req = REQ_MATERIAL_CRAFT.get(rar)
    if not req:
        return None
    extra = sum(max(0, core_base_and_tier(cid)[1] - 1) for cid in (sel or []))
    return {"rank": int(req["rank"]), "base": int(req["qtd"]),
            "extra_tier": extra * MATERIAL_POR_TIER,
            "qtd": int(req["qtd"]) + extra * MATERIAL_POR_TIER}


def craft_confirm(p: dict, owner_id: int | None = None) -> tuple[bool, str]:
    slot = p["craft"].get("slot")
    rar = p["craft"].get("rar")
    sub = p["craft"].get("sub")
    sel = list(p["craft"].get("sel", []) or [])

    if rar not in RARITIES or not slot:
        return False, "Selecione slot e raridade."

    if slot == "weapon" and sub not in WEAPON_TYPES:
        return False, "Escolha o tipo da arma."

    need = int(RARITIES[rar]["cores"])
    if len(sel) != need:
        return False, f"Selecione exatamente {need} cores."

    # requisitos obrigatórios por slot
    reqs = REQ_CRAFT.get(slot, {})
    for req_base, req_qty in reqs.items():
        count = 0
        for cid in sel:
            base_cid, _ = core_base_and_tier(cid)
            if base_cid == req_base:
                count += 1
        if count < int(req_qty):
            return False, f"Faltou {core_name(req_base)} x{req_qty} (qualquer tier)"

    inv = p["inv"]["cores"]
    for cid in sel:
        if int(inv.get(cid, 0)) <= 0:
            return False, f"Você não tem: {core_name(cid)}"

    # === CUSTO EM GOLD POR RARIDADE ===
    cost = COST_CRAFT.get(rar, 0)
    if p.get("gold", 0) < cost:
        return False, f"Você precisa de {cost} gold para craftar um item {RARITIES[rar]['name']}."

    # === ⛏️ MATERIAL DA TORRE (20/09/2026) ===
    # Confere ANTES de qualquer débito — a mesma lição da construção do clã:
    # descontar o ouro e só então descobrir que falta material cobraria por
    # uma forja que não aconteceu.
    from game.clan_materiais import RANKS
    req_mat = custo_material(rar, sel)
    usa_da_mochila = usa_do_cla = 0
    if req_mat:
        rank, precisa = int(req_mat["rank"]), int(req_mat["qtd"])
        tem = material_disponivel(p, rank, owner_id)
        if tem["total"] < precisa:
            from game.clan_materiais import onde_cai
            return False, (f"Falta material {RANKS[rank]['nome']} (rank {rank}): precisa de "
                           f"{precisa}, você tem {tem['total']} ({tem['mochila']} na mochila + "
                           f"{tem['cla']} no clã). Ele sai nos {onde_cai(rank)}.")
        usa_da_mochila = min(tem["mochila"], precisa)
        usa_do_cla = precisa - usa_da_mochila
        # O estoque do clã é o ÚNICO débito que pode falhar por fora (outra
        # requisição gastando junto), então vai primeiro: se falhar, nada
        # mais foi descontado.
        if usa_do_cla:
            from game.clan_repo import gastar_material
            if owner_id is None or not gastar_material(int(owner_id), rank, usa_do_cla):
                return False, "O material do clã acabou de ser usado. Tente de novo."
        if usa_da_mochila:
            mochila = p.setdefault("materiais_torre", {})
            mochila[str(rank)] = int(mochila.get(str(rank), 0)) - usa_da_mochila

    # Debita o custo
    p["gold"] = int(p.get("gold", 0)) - cost

    # consome cores
    for cid in sel:
        inv_remove_stack(inv, cid, 1)

    # chance de sucesso
    # 🔥 PETS: bônus de chance de craft por raridade (antes só decorativo)
    from game.pets_db import get_pet_bonuses
    _rar_pt = {
        "common": "craft_comum", "uncommon": "craft_incomum", "rare": "craft_raro",
        "epic": "craft_epico", "legendary": "craft_lendario",
    }
    craft_bonus = get_pet_bonuses(p).get(_rar_pt.get(rar, ""), 0)
    chance_final = float(RARITIES[rar]["chance"]) + craft_bonus
    if random.random() > chance_final:
        craft_reset(p)
        p["state"] = "CITY"
        return False, "❌ Craft falhou (cores consumidas). Voltando à cidade..."

    # monta bônus somando os cores
    bonus: dict[str, int] = {}
    for cid in sel:
        bonus = apply_bonus(bonus, core_bonus(cid))

    # 🐛 26/09/2026: era `name_slot = slot` — "armor Comum", "ring Comum"
    name_slot = NOME_DA_PECA.get(slot, slot)
    if slot == "weapon":
        name_slot = WEAPON_TYPES[sub]["name"]

    # Em craft.py, dentro de craft_confirm(p):

    # === GERAÇÃO DO ITEM ===
    item = {
        "id": gen_item_id(),
        "slot": slot,
        "rar": rar,
        "name": f"{name_slot} {RARITIES[rar]['name']}",
        "bonus": bonus,
        "cores": list(sel),
        "sub": sub,
        "sock_max": {"common": 0, "uncommon": 1, "rare": 2, "epic": 3, "legendary": 4, "mythic": 16}.get(rar, 2),
        "socked": [],
    }

    # === NOVO: BÔNUS ALEATÓRIO PARA ACESSÓRIOS ===
    is_accessory = slot in ["belt", "necklace", "ring"]
    if is_accessory:
        possible_stats = ["atk", "def", "hp_max", "spd", "reg", "acc", "eva", "crit"]
        item["rnd_stat"] = random.choice(possible_stats)

    if not store_item(p, slot, item):
        return False, f"Inventário do slot {slot} cheio.\n"

    from game.logic import recalc  # import local pra evitar ciclos
    recalc(p)

    # === MENSAGEM DE SUCESSO DINÂMICA ===
    stats_msg = f"✨ {item['name']} criado!\n"
    stats_msg += f"📦 Slot: {item['slot'].upper()}\n"
    stats_msg += f"⭐ Raridade: {item['rar'].capitalize()}\n"
    stats_msg += f"🔌 Slots socket: {item['sock_max']}\n"

    # Define a porcentagem do bônus baseada na raridade
    pct_val = {"common": 4, "uncommon": 8, "rare": 12, "epic": 16, "legendary": 20}.get(rar, 4)

    if is_accessory:
        stats_msg += f"🎲 Bônus de Raridade: +{pct_val}% em {item['rnd_stat'].upper()} (Aleatório!)\n"
    else:
        # Pega o status fixo da arma/armadura
        main_stats = {"weapon": "atk", "armor": "def", "helmet": "hp_max", "gloves": "atk", "boots": "spd", "shield": "def"}
        m_stat = main_stats.get(slot, "atk").upper()
        stats_msg += f"📈 Bônus de Raridade: +{pct_val}% em {m_stat} (Fixo)\n"

    bonus_fixo = item.get("bonus", {})
    cores_used = ", ".join([core_name(c) for c in item.get("cores", [])])

    if bonus_fixo:
        stats_msg += "\nBônus Fixo dos Cores:"
        for stat, valor in bonus_fixo.items():
            stats_msg += f"• +{valor} {stat.upper()}\n"

    stats_msg += f"\nCores consumidas: {cores_used}\n"

    craft_reset(p)
    return True, stats_msg


# =============================================================================
# ✨ ITEM MÍTICO (08/07/2026) — gerador genérico. Ainda não tem fonte de
# drop decidida; existe pra qualquer sistema futuro (chefe final, fusão
# suprema, etc) poder chamar e receber um item pronto e correto.
#
# Design: ZERO atributo base (nada de +ATK/+DEF fixo) — todo o poder vem
# da skill própria (auto_skill, dispara sozinha em combate, não ocupa
# nenhum dos 5 slots normais) + 1 gatilho de combate exclusivo ("o
# atributo legal") + 16 sockets pra você mesmo montar o resto da build.
# =============================================================================
def criar_item_mitico(nome: str, slot: str, skill_id: str, trigger_key: str, trigger_value: float,
                       skill_cooldown: int = 4, skill_power_mult: float = 0.6) -> dict:
    """Monta um item Mítico pronto pra ir direto no inventário do jogador
    (`p['inv']['items'][slot].append(item)`)."""
    return {
        "id": gen_item_id(),
        "name": nome,
        "slot": slot,
        "rar": "mythic",
        "bonus": {},              # 🔥 de propósito: zero atributo base
        "sock_max": 16,
        "socked": [],
        "mythic_skill": {
            "skill_id": skill_id,
            "cooldown": skill_cooldown,
            "power_mult": skill_power_mult,
        },
        "mythic_trigger": {
            "key": trigger_key,
            "value": trigger_value,
        },
    }
