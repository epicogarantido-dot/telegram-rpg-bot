# game/wave_mode.py
"""
🌊 ONDA DE BOSSES (08/07/2026) — v2: agora os 5 chefes ficam vivos AO
MESMO TEMPO na mesma batalha, igual a Raid (que também é vários inimigos
juntos) — não é mais 1 de cada vez.

Vencendo os 5 juntos, a próxima onda já começa na hora — mais forte que
a anterior — e assim por diante, sem fim, até você morrer. Só 1
tentativa por dia. Tudo que você ganha pelo caminho (ouro, XP, drops) é
seu de verdade, mesmo se cair no meio.
"""
from datetime import date

BOSSES_POR_ONDA = 5
ANDAR_POR_ONDA = 5   # onda 1 = andar 5 (chefe), onda 2 = andar 10, ...
ANDAR_MAXIMO = 100

# 💰 20/09/2026 — PRÊMIO CORTADO PRA 1% (era 50.000 e 250.000).
# Medido no valor antigo: chegar na onda 6 numa tentativa dava
# 300.000g + 500.000g = 800.000g num dia. Uma conta comum tem ~5.000g,
# e o ouro por monstro vai de 12g (andar 1) a 210g (andar 100). Ou seja,
# UM dia de Onda pagava mais que a vida inteira de Torre — e a decisão
# "Torre ou aldeia", que é o eixo do jogo, simplesmente sumia.
# A 1%, a mesma corrida de 6 ondas rende 3.000 + 5.000 = 8.000g: continua
# sendo o melhor dia da semana, sem apagar o resto do jogo.
BONUS_OURO_POR_ONDA = 500
BONUS_OURO_EXTRA_A_CADA_N_ONDAS = 3
BONUS_OURO_EXTRA_VALOR = 2_500


def _andar_boss_da_onda(onda: int) -> int:
    return min(ANDAR_MAXIMO, onda * ANDAR_POR_ONDA)


def pode_jogar_hoje(p: dict) -> bool:
    return p.get("wave_last_played") != date.today().isoformat()


def iniciar_onda(p: dict) -> str:
    """Começa a tentativa do dia — só libera de novo amanhã."""
    if not pode_jogar_hoje(p):
        return "❌ Você já tentou a Onda de Bosses hoje. Volte amanhã!"

    p["wave_last_played"] = date.today().isoformat()
    p["wave_state"] = {
        "active": True, "onda_atual": 1,
        "saved_tower_floor": p.get("tower_floor", 1),
    }
    spawn_onda_completa(p)
    return (
        "🌊 <b>A ONDA DE BOSSES COMEÇA!</b>\n"
        f"{BOSSES_POR_ONDA} chefes vivos AO MESMO TEMPO nessa batalha — "
        "vencendo todos, a próxima onda já começa na hora, sempre mais "
        "forte. Não tem fim, só acaba quando você cair. Só 1 tentativa "
        "por dia — capriche!"
    )


def spawn_onda_completa(p: dict) -> None:
    """Monta a onda inteira como 1 combate só, com os 5 chefes vivos ao
    mesmo tempo — mesmo motor de combate da Torre, só que montado na mão
    (não pelo start_combat normal) pra garantir sempre exatamente 5
    chefes, na dificuldade certa da onda atual."""
    from game.monsters import criar_monstro_por_andar, get_tier

    st = p.get("wave_state", {})
    andar = _andar_boss_da_onda(st.get("onda_atual", 1))

    enemies = []
    for i in range(BOSSES_POR_ONDA):
        mon = criar_monstro_por_andar(andar)
        mon_status = mon.get("status", {})
        mhp_max = int(mon.get("hp_max", 60))
        mhp = int(mon.get("hp", mhp_max))
        enemies.append({
            "name": f"{mon.get('nome', 'BOSS')} #{i + 1}",
            "tipo": "boss",
            "tier": int(mon.get("tier", get_tier(andar))),
            "hp": mhp,
            "hp_max": mhp_max,
            "atk": int(mon_status.get("atk", 1)),
            "def": int(mon_status.get("def", 0)),
            "spd": int(mon_status.get("spd", 20)),
            "floor": int(mon.get("lvl", andar)),
            "berserk": False,
            "cores_drop": mon.get("cores_drop", []),
            "bar": 0.0,
            "cooldowns": {},
        })

    p["combat"] = {"p_bar": 0.0, "p_spd": int(p.get("spd", 20)), "enemies": enemies, "target": 0, "p_cooldowns": {}}
    p["state"] = "COMBAT"
    p["wave_mode"] = True


def avancar_onda(p: dict) -> tuple:
    """Chame depois de vencer OS 5 chefes da onda (todos juntos). É
    praticamente sem fim — só acaba quando o jogador morre (ver
    finalizar_onda). Retorna (terminou=False sempre, msg) — mantido em
    tupla por consistência com o Explorar Mundo."""
    st = p.setdefault("wave_state", {"active": True, "onda_atual": 1})
    onda_concluida = int(st.get("onda_atual", 1))
    st["onda_atual"] = onda_concluida + 1

    p["gold"] = int(p.get("gold", 0)) + BONUS_OURO_POR_ONDA
    msg = f"🏆 <b>Onda {onda_concluida} completa!</b> Os {BOSSES_POR_ONDA} chefes caíram! +{BONUS_OURO_POR_ONDA:,}g de bônus.\n"

    if onda_concluida % BONUS_OURO_EXTRA_A_CADA_N_ONDAS == 0:
        p["gold"] = int(p.get("gold", 0)) + BONUS_OURO_EXTRA_VALOR
        msg += f"💰 +{BONUS_OURO_EXTRA_VALOR:,}g de bônus extra (a cada {BONUS_OURO_EXTRA_A_CADA_N_ONDAS} ondas)!\n"

    msg += f"Avançando pra Onda {st['onda_atual']} — {BOSSES_POR_ONDA} novos chefes, mais fortes..."
    spawn_onda_completa(p)
    return False, msg


def finalizar_onda(p: dict) -> str:
    """Chamado quando o jogador morre — único jeito da onda acabar de
    verdade. Restaura o andar real da Torre."""
    st = p.get("wave_state", {})
    onda_atual = int(st.get("onda_atual", 1))
    saved_floor = st.get("saved_tower_floor")

    p["wave_mode"] = False
    if saved_floor is not None:
        p["tower_floor"] = saved_floor
    p["wave_state"] = {"active": False, "onda_atual": 1}

    # 🏅 recorde pessoal — o texto sempre convidou a "ir mais longe", mas
    # não existia nada guardando até onde o jogador tinha chegado antes.
    recorde_antigo = int(p.get("wave_recorde", 0))
    bateu_recorde = onda_atual > recorde_antigo
    if bateu_recorde:
        p["wave_recorde"] = onda_atual

    msg = (
        f"💀 A Onda de Bosses terminou na <b>Onda {onda_atual}</b> — os "
        f"{BOSSES_POR_ONDA} chefes dessa onda te derrubaram.\n"
    )
    if bateu_recorde:
        msg += f"🏅 <b>Novo recorde!</b> (antes: Onda {recorde_antigo or 1})\n"
    else:
        msg += f"🏅 Seu recorde continua sendo a Onda {recorde_antigo}.\n"
    msg += "Volte amanhã pra tentar ir mais longe!"
    return msg
