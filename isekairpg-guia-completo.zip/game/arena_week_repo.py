# game/arena_week_repo.py
"""
📅 Estado da semana da Arena — repositório singleton, mesmo padrão do
Boss Global. Guarda só quando a semana atual começou.
"""
import json
import time

from game.sql_repo import get_connection

from infra.migracao import garantir_colunas, garantir_colunas_async

# 🧱 20/09/2026 — os CREATE deste arquivo viraram constantes pra que a
# MESMA string crie a tabela e migre banco velho (infra/migracao.py).
# Coluna nova entra aqui e chega sozinha em quem já tinha a tabela.
_SQL_ARENA_WEEK = """
            CREATE TABLE IF NOT EXISTS arena_week (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                data TEXT,
                updated_at INTEGER
            );
            """



def init_tables() -> None:
    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            _SQL_ARENA_WEEK
        )
        garantir_colunas(c, _SQL_ARENA_WEEK)  # 🧱 migra o que o CREATE tem e o disco não
        conn.commit()


init_tables()


def get_week_state() -> dict | None:
    with get_connection() as conn:
        c = conn.cursor()
        c.execute("SELECT data FROM arena_week WHERE id = 1")
        row = c.fetchone()
        if not row or not row[0]:
            return None
        try:
            return json.loads(row[0])
        except Exception:
            return None


def save_week_state(state: dict) -> None:
    with get_connection() as conn:
        c = conn.cursor()
        c.execute(
            """
            INSERT INTO arena_week (id, data, updated_at) VALUES (1, ?, ?)
            ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at
            """,
            (json.dumps(state), int(time.time())),
        )
        conn.commit()
