# game/monster_generator.py
"""
Gerador otimizado de monstros para Raid RPG.
Separado de logic.py para melhor manutenção.
"""

import random
from typing import Dict, Any, Optional

# ============ CONFIGURAÇÃO DE RAÇAS ============

RAÇAS_POR_BLOCO = {
    (1, 5): {"nome": "Goblin", "elite": ["Chefe Goblin", "Xamã Goblin", "Goblin Assassino"], "boss": "Rei Goblin"},
    (6, 10): {"nome": "Esqueleto", "elite": ["Capitão Esqueleto", "Necromante", "Arqueiro Espectral"], "boss": "Esqueleto Gigante"},
    (11, 15): {"nome": "Formiga", "elite": ["Formiga Guerreira", "Formiga Rainha", "Formiga Soldado"], "boss": "Formiga General"},
    (16, 20): {"nome": "Kobold", "elite": ["Kobold Trapeiro", "Kobold Fogo", "Kobold Sombra"], "boss": "Xamã Kobold"},
    (21, 25): {"nome": "Orc", "elite": ["Orc Guerreiro", "Orc Xamã", "Orc Berserk"], "boss": "Chefe Orc"},
    (26, 30): {"nome": "Cultista", "elite": ["Cultista Maldito", "Cultista Obscuro", "Cultista Supremo"], "boss": "Sumo-Cultista"},
    (31, 35): {"nome": "Aranha", "elite": ["Aranha Venenosa", "Aranha Gigante", "Aranha Sombra"], "boss": "Aranha-Mãe"},
    (36, 40): {"nome": "Fada", "elite": ["Fada Venenosa", "Fada Raízes", "Fada Luz"], "boss": "Fada Rainha"},
    (41, 45): {"nome": "Lagarto", "elite": ["Lagarto Guerreiro", "Lagarto Xamã", "Lagarto Primordial"], "boss": "Xamã Escamado"},
    (46, 50): {"nome": "Gárgula", "elite": ["Gárgula Pedra", "Gárgula Noite", "Gárgula Antiga"], "boss": "Gárgula Guardião"},
    (51, 55): {"nome": "Elemental", "elite": ["Elemental Fogo", "Elemental Gelo", "Elemental Raio"], "boss": "Elemental Prisma"},
    (56, 60): {"nome": "Vampiro", "elite": ["Vampiro Jovem", "Vampiro Ancestral", "Abominação"], "boss": "Conde Cripta"},
    (61, 65): {"nome": "Golem", "elite": ["Golem Argila", "Golem Ferro", "Golem Runa"], "boss": "Golem Obsidiana"},
    (66, 70): {"nome": "Demônio", "elite": ["Demônio Menor", "Demônio Maior", "Demônio Primordial"], "boss": "Marechal Infernal"},
    (71, 75): {"nome": "Aberração", "elite": ["Aberração Mutante", "Aberração Voraz", "Aberração Perfeita"], "boss": "Massa Devoradora"},
    (76, 80): {"nome": "Cavaleiro", "elite": ["Cavaleiro Negro", "Cavaleiro Espectral", "Cavaleiro Arruinado"], "boss": "Paladino Caído"},
    (81, 85): {"nome": "Drake", "elite": ["Drake Fogo", "Drake Gelo", "Drake Tempestade"], "boss": "Draco Guardião"},
    (86, 90): {"nome": "Gigante", "elite": ["Gigante Montanha", "Gigante Pedra", "Gigante Caos"], "boss": "Titã Ruínas"},
    (91, 95): {"nome": "Anjo Corrompido", "elite": ["Anjo Decaído", "Anjo Sombrio", "Anjo Abominado"], "boss": "Serafim Decaído"},
    (96, 100): {"nome": "Entidade Vazio", "elite": ["Entidade Menor", "Entidade Maior", "Entidade Suprema"], "boss": "Núcleo Vazio"},
}

ARQUÉTIPOS = ["tanker", "espadachim", "arqueiro"]
ARQUÉTIPO_ATTRS = {
    "tanker": ("vit", "str"),
    "espadachim": ("str", "dex"),
    "arqueiro": ("dex", "agi"),
}

# ============ MULTIPLICADORES ============

def mult_tipo(tipo: str) -> float:
    """Multiplicador base por tipo de monstro."""
    mults = {
        "normal": 0.7,
        "elite": 1.5,
        "general": 1.8,
        "boss": 2.3,
    }
    return mults.get(tipo, 1.0)


def mult_andar(andar: int) -> float:
    """Multiplicador progressivo por andar."""
    return 1.0 + (max(0, andar - 1) // 3) * 0.12


def obter_raca(andar: int) -> Dict[str, Any]:
    """Retorna dados da raça para um andar."""
    andar = int(andar)
    for (inicio, fim), raca in RAÇAS_POR_BLOCO.items():
        if inicio <= andar <= fim:
            return raca
    return RAÇAS_POR_BLOCO[(96, 100)]


def tipo_monstro(andar: int) -> str:
    """Define tipo do monstro baseado no andar."""
    andar = int(andar)

    if andar % 5 == 0:
        return "boss"

    # Progressão de dificuldade
    if andar < 10:
        return random.choices(["normal", "elite"], weights=[75, 25])[0]
    elif andar < 10:
        return random.choices(["normal", "elite"], weights=[60, 40])[0]
    elif andar < 15:
        return random.choices(["normal", "elite", "general"], weights=[45, 40, 15])[0]
    else:
        return random.choices(["elite", "general"], weights=[55, 45])[0]


# ============ GERAÇÃO DE ATRIBUTOS ============

def gerar_atributos_base(andar: int) -> Dict[str, int]:
    """Gera atributos base escalados pelo andar."""
    base = 1
    escala = 1 + (andar - 1) 

    return {
        "str": base + escala,
        "vit": base + escala,
        "agi": base + escala,
        "dex": base + escala,
    }


def aplicar_focus_atributos(attrs: Dict[str, int], focus1: str, focus2: str) -> Dict[str, int]:
    """Aumenta 2 atributos principais."""
    result = dict(attrs)
    result[focus1] *= 2
    result[focus2] *= 1.5
    return result


def atributos_para_status(attrs: Dict[str, int]) -> Dict[str, int]:
    """Converte atributos em status (hp, atk, def, etc)."""
    return {
        "hp_max": 80 + attrs["vit"] * 25,
        "atk": 5 + attrs["str"] * 2 + attrs["dex"] * 1,
        "def": 2 + attrs["vit"] * 1,
        "spd": 15 + attrs["agi"] * 2,
        "crit": attrs["dex"] * 2,
        "acc": attrs["dex"],
        "eva": attrs["agi"],
        "reg": attrs["vit"],
    }


# ============ NOME DO MONSTRO ============

def gerar_nome(raca: Dict[str, Any], tipo: str, arquetipo: Optional[str] = None) -> str:
    """Gera nome baseado na raça e tipo."""
    raca_nome = raca["nome"]

    if tipo == "boss":
        return raca["boss"]
    elif tipo == "general":
        return random.choice(raca["elite"])
    elif tipo == "elite":
        return random.choice(raca["elite"])
    else:
        if arquetipo and arquetipo != "boss":
            return f"{raca_nome} {arquetipo.title()}"
        return raca_nome


# ============ DROPS ============

CORES_PREMIUM = [
    "core_fire", "core_ice", "core_thunder", "core_nature",
    "core_dark", "core_life", "core_meteor", "core_blizzard",
    "core_venom", "core_quake", "core_holy", "core_spiral",
]

CORES_FORJA = ["wa_atk", "ar_def", "ac_atk", "ac_def"]


def obter_drop(tipo: str) -> Optional[str]:
    """Retorna core que o monstro droppa."""
    if tipo == "boss":
        if random.random() < 0.25:
            return random.choice(CORES_PREMIUM)

    rand = random.random()
    if rand < 0.08:
        return "wa_atk"
    elif rand < 0.15:
        return "ar_def"
    elif rand < 0.20:
        return random.choice(["crit", "acc", "eva", "spd", "reg"])

    return None


# ============ FUNÇÃO PRINCIPAL ============

def criar_monstro(andar: int) -> Dict[str, Any]:
    """Cria um monstro completo para um andar específico."""
    andar = int(andar)
    lvl = max(1, andar)

    tipo_m = tipo_monstro(andar)
    raca = obter_raca(andar)

    if tipo_m == "boss":
        arquetipo = "boss"
        attrs = gerar_atributos_base(andar)
        attrs = {k: int(v * 1.5) for k, v in attrs.items()}
        attrs["vit"] = int(attrs["vit"] * 1.3)
    else:
        arquetipo = random.choice(ARQUÉTIPOS)
        attrs = gerar_atributos_base(andar)
        focus1, focus2 = ARQUÉTIPO_ATTRS[arquetipo]
        attrs = aplicar_focus_atributos(attrs, focus1, focus2)

    status = atributos_para_status(attrs)
    mult_t = mult_tipo(tipo_m)
    mult_a = mult_andar(andar)
    mult_final = mult_t * mult_a

    for key in status:
        if key != "hp_max":
            status[key] = max(1, int(status[key] * mult_final))

    status["hp_max"] = max(50, int(status["hp_max"] * mult_final))

    nome = gerar_nome(raca, tipo_m, arquetipo)
    drop = obter_drop(tipo_m)
    drops = [drop] if drop else []

    return {
        "nome": nome,
        "lvl": lvl,
        "tipo": tipo_m,
        "arquetipo": arquetipo,
        "raca": raca["nome"],
        "hp_max": status["hp_max"],
        "hp": status["hp_max"],
        "atk": status["atk"],
        "def": status["def"],
        "spd": status["spd"],
        "crit": status["crit"],
        "acc": status["acc"],
        "eva": status["eva"],
        "reg": status["reg"],
        "cores_drop": drops,
        "atributos": attrs,
    }


def criar_monstros_para_raid(andar: int, qtd: int = 3) -> list:
    """Cria múltiplos monstros para uma raid."""
    return [criar_monstro(andar) for _ in range(qtd)]


if __name__ == "__main__":
    # Teste rápido
    for andar in [1, 10, 20, 50, 100]:
        m = criar_monstro(andar)
        print(f"Andar {andar}: {m['nome']} (HP: {m['hp_max']}, ATK: {m['atk']}, Tipo: {m['tipo']})")