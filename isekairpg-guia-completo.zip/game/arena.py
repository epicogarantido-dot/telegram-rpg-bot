# game/arena.py
"""
Arena PvP — por cadastro, snapshot diário, e combate INTERATIVO.

1. O jogador se CADASTRA (`arena:register`): cria uma cópia (snapshot) com
   status atuais + as skills ativas equipadas. Só atualiza de novo depois
   de 24h.
2. As lutas acontecem contra a CÓPIA de outro jogador, mas agora turno a
   turno: você escolhe Atacar ou usar uma das SUAS skills equipadas, e a
   cópia do oponente também ataca ou usa as skills QUE ELA tinha
   equipadas no momento do cadastro — igual um "boss" de raid, só que
   pilotando o kit de skills de uma pessoa de verdade.
3. Pontuação: vitória = +0.2, derrota = -0.4 (nunca fica negativo).
4. Matchmaking: só entra na lista quem tem pontuação entre -1 e +1 da sua.
   Se ninguém se encaixar, cai pra lutar contra a própria cópia.
"""
import random
import time

VITORIA_PONTOS = 0.2
DERROTA_PONTOS = 0.4
REFRESH_SECONDS = 24 * 60 * 60  # 1 dia
MAX_TURNS_SAFETY = 60  # trava de segurança (evita loop infinito)


# =============================================================================
# 📸 SNAPSHOT (cadastro + atualização diária)
# =============================================================================

def _get_equipped_active_skills(p: dict) -> list[dict]:
    """Extrai as skills ATIVAS equipadas do jogador, prontas pra guardar no
    snapshot (a cópia vai poder usá-las contra quem a desafiar)."""
    from game.skills import get_skill_by_id

    equipped = p.get("skill_slots", {}).get("equipped", [])
    learned = p.get("skills_learned", {})
    resultado = []

    for sk_id in equipped:
        if not sk_id:
            continue
        base = get_skill_by_id(sk_id)
        if not base:
            continue
        sk = dict(base.get("skill", {}))
        if sk.get("type") != "active":
            continue
        sk["id"] = sk_id
        sk_data = learned.get(sk_id, {})
        sk["level"] = sk_data.get("level", 1)
        resultado.append(sk)

    return resultado


def build_snapshot_data(p: dict) -> dict:
    """Monta o dicionário de snapshot a partir do jogador AO VIVO (recalcula
    antes). Usado tanto no cadastro quanto na atualização diária."""
    from game.logic import recalc, get_combat_triggers

    recalc(p)
    triggers = get_combat_triggers(p)
    skills = _get_equipped_active_skills(p)

    return {
        "username": p.get("username") or "Guerreiro Desconhecido",
        "level": int(p.get("level", 1)),
        "atk": int(p.get("atk", 5)),
        "def": int(p.get("def", 0)),
        "hp_max": int(p.get("hp_max", 100)),
        "crit": int(p.get("crit", 0)),
        "eva": int(p.get("eva", 0)),
        "acc": int(p.get("acc", 0)),
        "spd": max(1, int(p.get("spd", 20))),
        "triggers": triggers,
        "skills": skills,
        "updated_at": int(time.time()),
    }


def register_in_arena(p: dict) -> str:
    """Cadastra o jogador na Arena pela primeira vez (ou atualiza na hora)."""
    from game.sql_repo import save_arena_snapshot_sync

    uid = int(p.get("user_id") or p.get("telegram_id"))
    dados = build_snapshot_data(p)
    save_arena_snapshot_sync(uid, dados)
    n_skills = len(dados["skills"])
    extra = f" (com {n_skills} skill(s) ativa(s))" if n_skills else " (sem skills ativas equipadas — só ataques básicos)"
    return f"✅ Você se cadastrou na Arena! Sua cópia de combate foi criada{extra}."


def ensure_daily_refresh(p: dict) -> None:
    """Chame sempre que o jogador abre o menu da Arena: se fizer mais de 24h
    desde a última atualização da cópia dele, atualiza sozinho (sem mexer
    em pontos/vitórias/derrotas, só nos status e skills de combate)."""
    from game.sql_repo import get_arena_snapshot_sync, save_arena_snapshot_sync

    uid = int(p.get("user_id") or p.get("telegram_id"))
    snap = get_arena_snapshot_sync(uid)
    if not snap:
        return

    agora = int(time.time())
    if agora - int(snap.get("updated_at", 0)) >= REFRESH_SECONDS:
        dados = build_snapshot_data(p)
        save_arena_snapshot_sync(uid, dados)


# =============================================================================
# ⚔️ COMBATE INTERATIVO
# =============================================================================

def _arte_do_jogador(race_id, sexo) -> str:
    """A chave da arte de quem luta. Uma função só, usada pelos dois lados,
    pra que o retrato do adversário siga a mesma regra do seu (raça e sexo,
    com queda pra arte da raça e pro STATUS genérico)."""
    try:
        from game.assets import resolver_asset_key_jogador
        return resolver_asset_key_jogador(race_id, sexo)
    except Exception:
        return "STATUS"


def _entity_from_live_player(p: dict) -> dict:
    return {
        "img_key": _arte_do_jogador(p.get("race_id"), p.get("sexo")),
        "name": p.get("username") or "Desafiante",
        "hp": int(p.get("hp_max", 100)), "hp_max": int(p.get("hp_max", 100)),
        "atk": int(p.get("atk", 5)), "def": int(p.get("def", 0)),
        "spd": max(1, int(p.get("spd", 20))), "acc": int(p.get("acc", 0)),
        "eva": int(p.get("eva", 0)), "crit": int(p.get("crit", 0)),
        "shield": 0, "bar": 100.0, "cooldowns": {}, "dots": [], "stun": 0,
    }


def _arte_do_oponente(telegram_id) -> str:
    """Retrato do adversário.

    A tabela `arena_snapshots` não guarda raça nem sexo, e acrescentar
    coluna lá exigiria migração — a armadilha nº 14 deste projeto, que já
    estourou em produção com `no such column`. Como o adversário é um
    jogador REAL do mesmo banco, dá pra ler o personagem dele na hora de
    montar a luta: uma leitura por combate, nenhuma mudança de schema.
    """
    try:
        from game.sql_repo import load_player
        alvo = load_player(int(telegram_id)) or {}
        return _arte_do_jogador(alvo.get("race_id"), alvo.get("sexo"))
    except Exception:
        return "STATUS"


def _entity_from_snapshot(snap: dict) -> dict:
    import json
    skills_raw = snap.get("skills_json") or snap.get("skills") or "[]"
    skills = skills_raw if isinstance(skills_raw, list) else json.loads(skills_raw)
    return {
        "img_key": _arte_do_oponente(snap.get("telegram_id")),
        "name": snap.get("username") or "Cópia de Combate",
        "hp": int(snap.get("hp_max", 100)), "hp_max": int(snap.get("hp_max", 100)),
        "atk": int(snap.get("atk", 5)), "def": int(snap.get("def", 0)),
        "spd": max(1, int(snap.get("spd", 20))), "acc": int(snap.get("acc", 0)),
        "eva": int(snap.get("eva", 0)), "crit": int(snap.get("crit", 0)),
        "shield": 0, "bar": 0.0, "cooldowns": {}, "dots": [], "stun": 0,
        "skills": skills,
    }


def skills_da_luta(p: dict) -> list:
    """As skills ativas do jogador nesta luta: as guardadas no estado da luta
    (que é salvo); luta começada antes da correção recalcula do equipado."""
    cmb = p.get("arena_combat") or {}
    salvas = cmb.get("minhas_skills")
    if salvas is None:
        salvas = p.get("_arena_my_skills") or _get_equipped_active_skills(p)
        if cmb:
            cmb["minhas_skills"] = salvas
    return salvas or []


def start_arena_combat(p: dict, opponent_telegram_id: int) -> dict:
    """Prepara o estado de combate (p['arena_combat']) e retorna {"ok": True}
    ou {"erro": msg} se não puder começar."""
    import json
    from game.logic import recalc, get_combat_triggers
    from game.sql_repo import get_arena_snapshot_sync

    uid = int(p.get("user_id") or p.get("telegram_id"))
    meu_snapshot = get_arena_snapshot_sync(uid)
    if not meu_snapshot:
        return {"erro": "❌ Você precisa se cadastrar na Arena antes de lutar."}

    oponente_snap = get_arena_snapshot_sync(int(opponent_telegram_id))
    if not oponente_snap:
        return {"erro": "❌ Esse oponente não está mais cadastrado na Arena."}

    recalc(p)
    trig_a = get_combat_triggers(p)

    triggers_raw = oponente_snap.get("triggers_json") or "{}"
    trig_d = triggers_raw if isinstance(triggers_raw, dict) else json.loads(triggers_raw)

    a = _entity_from_live_player(p)
    d = _entity_from_snapshot(oponente_snap)

    p["arena_combat"] = {
        "opponent_id": int(opponent_telegram_id),
        "a": a, "d": d,
        "trig_a": trig_a, "trig_d": trig_d,
        "logs": [f"⚔️ {a['name']} desafia a cópia de {d['name']} na Arena!"],
        "turn_count": 0,
        "finalizado": None,
    }
    # 🐛 (25/09) as skills da luta moram DENTRO do estado salvo: o antigo
    # p["_arena_my_skills"] não é gravado no banco (não está em
    # CAMPOS_EXTRAS), sumia na 1ª ação e toda skill dava "não equipada".
    p["arena_combat"]["minhas_skills"] = _get_equipped_active_skills(p)
    return {"ok": True}


def _tick_dots(entity: dict, logs: list[str]) -> None:
    dots = entity.get("dots") or []
    novos = []
    for dot in dots:
        turns = int(dot.get("turns", 0))
        if turns <= 0:
            continue
        dmg = max(0, int(dot.get("dmg", 0)))
        entity["hp"] = max(0, entity["hp"] - dmg)
        if dmg:
            logs.append(f"☠️ {entity['name']} sofreu {dmg} de {dot.get('name', 'veneno')}.")
        turns -= 1
        if turns > 0:
            dot["turns"] = turns
            novos.append(dot)
    entity["dots"] = novos


def _use_action(atacante: dict, defensor: dict, t_atk: dict, t_def: dict,
                 skill, logs: list) -> None:
    """Executa um ataque básico ou uma skill (dano/cura/dot/stun/execução),
    reaproveitando o motor de combate já existente no jogo."""
    from game.logic import calc_final_damage, check_hit_and_evasion, calc_thorns_and_counters, apply_lifesteal

    # --- Skill de cura (não tem alvo inimigo) ---
    if skill and float(skill.get("heal_percent", 0)) > 0:
        heal_pct = float(skill.get("heal_percent", 0))
        cura = max(1, int(atacante["atk"] * heal_pct))
        atacante["hp"] = min(atacante["hp_max"], atacante["hp"] + cura)
        logs.append(f"💚 {atacante['name']} usou {skill.get('name', 'Cura')} e recuperou {cura} HP!")
        return

    # --- Acerto ou erro ---
    acertou, log_hit, _ = check_hit_and_evasion(
        atacante["acc"], defensor["eva"], t_atk, t_def, atacante["name"], defensor["name"]
    )
    if log_hit:
        logs.append(log_hit.strip())
    if not acertou:
        return

    mult = float(skill.get("mult", 1.0)) if skill else 1.0
    nome_acao = skill.get("name", "ataque") if skill else "ataque básico"

    atk_efetivo = int(atacante["atk"] * mult)
    dano, log_dmg = calc_final_damage(
        atk_efetivo, defensor["def"], atacante["crit"], t_atk, t_def,
        defensor["hp"], defensor["hp_max"],
        eva_alvo=int(defensor.get("eva", 0))   # crítico: um menos o outro (25/09)
    )
    logs.extend(x.strip() for x in log_dmg if x.strip())

    # Escudo absorve primeiro
    if defensor.get("shield", 0) > 0:
        if defensor["shield"] >= dano:
            defensor["shield"] -= dano
            logs.append(f"🛡️ O escudo de {defensor['name']} absorveu {dano} de dano!")
            dano = 0
        else:
            dano -= defensor["shield"]
            logs.append(f"🛡️ O escudo de {defensor['name']} quebrou!")
            defensor["shield"] = 0

    defensor["hp"] = max(0, defensor["hp"] - dano)
    logs.append(f"💢 {atacante['name']} usou {nome_acao} e causou {dano} de dano em {defensor['name']}! ({defensor['hp']}/{defensor['hp_max']} HP)")

    # DoT (veneno/queimadura)
    if skill and float(skill.get("dot_mult", 0)) > 0 and int(skill.get("dot_turns", 0)) > 0:
        dmg_dot = max(1, int(atacante["atk"] * float(skill["dot_mult"])))
        defensor.setdefault("dots", []).append({
            "name": skill.get("dot_name", "DoT"), "dmg": dmg_dot, "turns": int(skill["dot_turns"])
        })
        logs.append(f"☠️ {defensor['name']} foi afetado por {skill.get('dot_name', 'um veneno')}!")

    # Atordoamento
    if skill and int(skill.get("stun", 0)) > 0:
        defensor["stun"] = defensor.get("stun", 0) + int(skill["stun"])
        logs.append(f"💫 {defensor['name']} foi atordoado!")

    # Redução de defesa
    if skill and float(skill.get("debuff_def", 0)) > 0:
        reducao = float(skill["debuff_def"])
        defensor["def"] = max(0, int(defensor["def"] * (1.0 - reducao)))
        logs.append(f"🔻 A defesa de {defensor['name']} foi reduzida!")

    # Execução (finalizar quem está com HP baixo)
    execute_pct = float(skill.get("execute_pct", 0)) if skill else 0
    if execute_pct and defensor["hp"] > 0 and (defensor["hp"] / defensor["hp_max"]) <= execute_pct:
        defensor["hp"] = 0
        logs.append(f"⚡ EXECUÇÃO! {defensor['name']} foi finalizado!")

    if dano <= 0:
        return

    # Espinhos / rebote
    dano_rebatido, log_thorns, _ = calc_thorns_and_counters(dano, t_def, defensor["def"], atacante["atk"])
    if dano_rebatido:
        atacante["hp"] = max(0, atacante["hp"] - dano_rebatido)
        logs.extend(x.strip() for x in log_thorns if x.strip())

    # Roubo de vida
    cura, log_life, _ = apply_lifesteal(dano, t_atk)
    if cura:
        atacante["hp"] = min(atacante["hp_max"], atacante["hp"] + cura)
        logs.extend(x.strip() for x in log_life if x.strip())


def _ai_choose_skill(entity: dict):
    """A cópia escolhe uma skill pronta (fora de cooldown) com 60% de chance;
    senão, ataque básico."""
    skills = entity.get("skills") or []
    prontas = [s for s in skills if entity["cooldowns"].get(s["id"], 0) <= 0]
    if prontas and random.random() < 0.6:
        escolhida = random.choice(prontas)
        entity["cooldowns"][escolhida["id"]] = int(escolhida.get("cooldown", 3))
        return escolhida
    return None


def _advance_until_player_ready(state: dict) -> None:
    """Resolve os turnos automáticos (do oponente, e o preenchimento de
    barra) até ser a vez do jogador de novo, ou até a luta acabar."""
    a, d = state["a"], state["d"]
    logs = state["logs"]

    turnos_processados = 0
    while a["hp"] > 0 and d["hp"] > 0 and turnos_processados < MAX_TURNS_SAFETY:
        if a["bar"] >= 100:
            return  # jogador pronto pra agir — devolve o controle

        seguranca = 0
        while a["bar"] < 100 and d["bar"] < 100 and seguranca < 400:
            a["bar"] += max(4.0, a["spd"] * 0.4)
            d["bar"] += max(4.0, d["spd"] * 0.4)
            seguranca += 1

        if d["bar"] < 100:
            continue

        turnos_processados += 1
        d["bar"] = 0.0

        for sk_id in list(d["cooldowns"].keys()):
            d["cooldowns"][sk_id] = max(0, d["cooldowns"][sk_id] - 1)

        if d.get("stun", 0) > 0:
            d["stun"] -= 1
            logs.append(f"💫 {d['name']} está atordoado e perdeu o turno!")
            continue

        _tick_dots(d, logs)
        if d["hp"] <= 0:
            break

        skill = _ai_choose_skill(d)
        _use_action(d, a, state["trig_d"], state["trig_a"], skill, logs)

        if a["hp"] <= 0:
            break


def arena_combat_action(p: dict, skill_id) -> str:
    """Executa a ação do jogador (ataque básico se skill_id=None, ou a skill
    correspondente), depois resolve os turnos automáticos do oponente."""
    state = p.get("arena_combat")
    if not state:
        return "❌ Não há luta em andamento."

    a, d = state["a"], state["d"]
    if a["hp"] <= 0 or d["hp"] <= 0:
        return "❌ Essa luta já terminou."
    if a["bar"] < 100:
        return "⏳ Sua barra de ação ainda não está cheia."

    skill = None
    if skill_id:
        skills_do_jogador = skills_da_luta(p)
        skill = next((s for s in skills_do_jogador if s.get("id") == skill_id), None)
        if not skill:
            return "❌ Você não tem essa skill equipada."
        cd_atual = a["cooldowns"].get(skill_id, 0)
        if cd_atual > 0:
            return f"⏳ Essa skill ainda está em recarga ({cd_atual} turno(s))."

    a["bar"] = 0.0
    if a.get("stun", 0) > 0:
        a["stun"] -= 1
        state["logs"].append(f"💫 {a['name']} está atordoado e perdeu o turno!")
    else:
        _tick_dots(a, state["logs"])
        if a["hp"] > 0:
            if skill:
                a["cooldowns"][skill_id] = int(skill.get("cooldown", 3))
            _use_action(a, d, state["trig_a"], state["trig_d"], skill, state["logs"])

    if a["hp"] > 0 and d["hp"] > 0:
        _advance_until_player_ready(state)

    return ""


def is_combat_over(p: dict):
    """Retorna 'atacante', 'defensor' ou None (ainda rolando)."""
    state = p.get("arena_combat")
    if not state:
        return None
    a, d = state["a"], state["d"]
    if a["hp"] <= 0 and d["hp"] <= 0:
        return "defensor"
    if d["hp"] <= 0:
        return "atacante"
    if a["hp"] <= 0:
        return "defensor"
    if state.get("turn_count", 0) >= MAX_TURNS_SAFETY:
        return "atacante" if (a["hp"] / a["hp_max"]) >= (d["hp"] / d["hp_max"]) else "defensor"
    return None


def finalize_arena_combat(p: dict) -> dict:
    """Chame quando is_combat_over() não for None. Atualiza pontos, ouro,
    e limpa o estado de combate."""
    from game.sql_repo import get_arena_snapshot_sync, update_arena_score_sync, save_arena_snapshot_sync

    state = p.get("arena_combat")
    if not state:
        return {"erro": "❌ Não havia luta em andamento."}

    vencedor = is_combat_over(p)
    venceu = vencedor == "atacante"
    uid = int(p.get("user_id") or p.get("telegram_id"))

    meu_snapshot = get_arena_snapshot_sync(uid) or {"arena_points": 0}
    meus_pontos = float(meu_snapshot.get("arena_points", 0) or 0)

    resultado = {
        "logs": state["logs"], "venceu": venceu,
        "atacante_nome": state["a"]["name"], "defensor_nome": state["d"]["name"],
    }

    if venceu:
        novos_pontos = meus_pontos + VITORIA_PONTOS
        oponente_snap = get_arena_snapshot_sync(state["opponent_id"]) or {}
        ouro_ganho = 50 + int(oponente_snap.get("level", 1)) * 2
        p["gold"] = int(p.get("gold", 0)) + ouro_ganho      # prêmio do reino
        try:
            from game import diarias as _D
            _D.contar(p, "arena")          # 📅 vitória conta pra diária
        except Exception:
            pass
        resultado["ouro_ganho"] = ouro_ganho
        resultado["estrelas_ganhas"] = 0  # 🔥 estrelas da arena agora vêm do ranking semanal, não por vitória avulsa
    else:
        novos_pontos = max(0.0, meus_pontos - DERROTA_PONTOS)
        resultado["ouro_ganho"] = 0
        resultado["estrelas_ganhas"] = 0

    novos_pontos = round(novos_pontos, 1)
    update_arena_score_sync(uid, novos_pontos, venceu)

    try:
        save_arena_snapshot_sync(uid, build_snapshot_data(p))
    except Exception:
        pass

    resultado["pontos_novos"] = novos_pontos
    resultado["pontos_delta"] = round(novos_pontos - meus_pontos, 1)

    p["arena_combat"] = None
    p.pop("_arena_my_skills", None)

    return resultado
