# game/clan_jornada.py
"""
🧭 TRAVESSIA DO CLÃ — batalhas de verdade, contra o relógio (20/09/2026)

O QUE É
-------
O clã atravessa de UM andar pro PRÓXIMO (do andar em que ele está pro
seguinte) — e só pra um andar que o jogador já alcançou na Torre. A
travessia tem um TEMPO (em turnos). Nele, o clã luta em sequência contra os
monstros do caminho:

- cada batalha tem um LIMITE de turnos. Venceu dentro dele: a próxima
  batalha começa. Não venceu: chega REFORÇO — mais um monstro entra na
  mesma batalha e o limite recomeça. Enrolar é deixar o bando crescer;
- quando o tempo da travessia acaba com alguém de pé, o clã CHEGOU;
- se todos caem, a travessia falhou.

Travessia pra um andar de chefe (5, 10, 15...) termina com o CHEFE: ele
entra quando 60% do tempo passou, e o limite dele também chama reforço.

POR QUE ASSIM (pedido do dev, depois da 1ª versão)
--------------------------------------------------
A versão anterior resolvia cada perigo com UM sorteio ("lutar: 70%") e
deixava escolher qualquer andar de 5 a 50. O dev achou irreal: travessia é
batalha atrás de batalha, com o tempo correndo, e o clã só anda pro andar
seguinte, depois de o jogador ter chegado lá. Os números aqui vêm do MESMO
lugar do resto do jogo:
- os monstros são os da Torre (`monsters.criar_monstro_por_andar`);
- o lutador usa os atributos da ficha dele recalculados pelo motor
  (`logic.recalc`) — o mesmo modelo com que o AFK mede a fronteira;
- o dano é o da Torre: `max(1, ataque − defesa)`, com variação.
Então quem não aguenta um andar no AFK também não o atravessa.

QUEM CAI NÃO MORRE
------------------
Volta ferido grave (ferimento no máximo). A morte definitiva continua
sendo do AFK, onde a chance aparece antes.

REGRA DESTE ARQUIVO: cálculo puro, sem banco. É o que deixa
`testes/auditar_jornada.py` jogar milhares de travessias e medir.
"""
from __future__ import annotations

import random

LIMITE_BATALHA = 6          # turnos pra vencer uma batalha antes do reforço
FOLGA_ENTRE_BATALHAS = 1    # turnos de respiro depois de vencer
CHEFE_ENTRA_EM = 0.6        # fração do tempo em que o chefe aparece
RACAO_A_CADA = 4            # turnos entre refeições (1 por lutador de pé)
CURA_DA_REFEICAO = 0.25     # "Comer": cura 25% da vida de quem está de pé
CUSTO_REFEICAO = 2          # comida por lutador de pé, por refeição extra

# 📐 A RÉGUA DOS INIMIGOS.
# Os monstros vêm do gerador da Torre (nome, raça, tipo do andar), mas os
# números de combate NÃO podem ser os da Torre crua: eles foram feitos pro
# personagem inteiro do jogador (pontos distribuídos, equipamento, classe,
# skills, pets). O lutador do clã é o modelo simplificado do AFK (atributos
# = nível + forja). Medido com os números crus: a defesa dos monstros cresce
# mais rápido que o ataque do modelo, e do andar 20 em diante o clã não
# vencia UMA batalha sequer — sobrevivia no relógio, o oposto do pedido.
#
# Então a régua é a do próprio AFK: um lutador "no ponto" pro andar d tem
# nível 2d (a mesma convenção da fronteira). Os inimigos são medidos contra
# ELE, e a dificuldade fica igual em todo andar:
#   - um bando comum cai em ~3 turnos pro grupo no ponto;
#   - cada golpe de monstro comum tira ~7,5% da vida de quem está no ponto;
#   - elite/general dobram a vida e batem 30% mais; o chefe é outra conversa.
# Quem está abaixo do ponto bate menos (a defesa é do andar) e apanha mais.
# (vida, ataque, defesa) relativos ao inimigo comum. Do andar 30 em diante a
# Torre só gera elite e general — por isso eles não podem ser o dobro do
# comum: com 2×, nenhuma batalha funda terminava dentro do limite (medido).
MULT_TIPO = {"normal": (1.0, 1.0, 0.60), "elite": (1.4, 1.2, 0.65),
             "general": (1.5, 1.25, 0.65), "boss": (3.5, 1.4, 0.70)}


def stats_do_inimigo(andar: int, tipo: str) -> tuple[int, int, int]:
    """(vida, ataque, defesa) de um inimigo do andar, na régua do clã."""
    L = 2 * max(1, int(andar))                  # o lutador "no ponto"
    atk_ref, def_ref, hp_ref = 2 * L + 5, 2 * L, 50 * L + 100
    mv, ma, md = MULT_TIPO.get(tipo, MULT_TIPO["normal"])
    dano_do_grupo = 5 * 0.9 * (atk_ref * 0.4) * 1.15
    vida = int(3 * dano_do_grupo * mv)
    ataque = int((def_ref + 0.075 * hp_ref) * ma)
    defesa = int(atk_ref * md)
    return max(1, vida), max(1, ataque), max(0, defesa)


TATICAS = {
    "normal":    {"nome": "⚖️ Normal",    "dado": 1.00, "recebido": 1.00},
    "ofensiva":  {"nome": "⚔️ Ofensiva",  "dado": 1.25, "recebido": 1.25},
    "defensiva": {"nome": "🛡️ Defensiva", "dado": 0.80, "recebido": 0.65},
}


def tempo_da_travessia(destino: int) -> int:
    """Andar mais fundo, caminho mais longo: 16 turnos no começo da Torre,
    26 no andar 50."""
    return 16 + 2 * (int(destino) // 10)


def racoes_necessarias(destino: int, lutadores: int) -> int:
    return max(1, int(lutadores)) * -(-tempo_da_travessia(destino) // RACAO_A_CADA)


def comida_maxima(destino: int, lutadores: int) -> int:
    """A carroça: as rações do caminho + o mesmo tanto de reserva pra comer
    no meio da luta. Sem teto, levar comida sobrando resolveria tudo."""
    return 2 * racoes_necessarias(destino, lutadores)


def andar_permitido(andar_do_cla: int, andar_max_jogador: int) -> int | None:
    """O ÚNICO destino possível: o andar seguinte ao do clã — e só se o
    jogador já chegou nele na Torre. None = não há travessia disponível."""
    destino = int(andar_do_cla) + 1
    return destino if destino <= int(andar_max_jogador) else None


# ─────────────────────────────────────────────────────── combatentes ──
def lutador(slot: int, nome: str, ficha: dict) -> dict:
    """Um lutador a partir da ficha recalculada (`logic.recalc`)."""
    hp = max(1, int(ficha.get("hp_max", 100)))
    return {"slot": int(slot), "nome": nome, "hp": hp, "hp_max": hp,
            "atk": int(ficha.get("atk", 10)), "def": int(ficha.get("def", 0)),
            "acc": int(ficha.get("acc", 0)), "eva": int(ficha.get("eva", 0)),
            "crit": int(ficha.get("crit", 0))}


def _monstro(andar: int, rng: random.Random, gerar=None) -> dict:
    """Um monstro do andar, gerado pelo MESMO gerador da Torre."""
    if gerar is None:
        from game.monsters import criar_monstro_por_andar as gerar
    estado = random.getstate()
    random.seed(rng.random())        # o gerador usa o `random` global
    m = gerar(int(andar))
    random.setstate(estado)
    tipo = m.get("tipo", "normal")
    hp, atk, defesa = stats_do_inimigo(int(andar), tipo)
    # Precisão e esquiva também na régua do clã: a esquiva crua da Torre
    # cresce tanto que, do andar 20 em diante, o lutador acertava 5% dos
    # golpes (o piso) — medido: nenhuma batalha funda terminava.
    L = 2 * max(1, int(andar))
    return {"nome": m.get("nome", "Monstro"), "tipo": tipo,
            "andar": int(andar), "hp": hp, "hp_max": hp, "atk": atk, "def": defesa,
            "acc": 2 * L, "eva": L // 2, "crit": 10}


def _golpe(atacante: dict, alvo: dict, mult: float, rng: random.Random) -> int:
    """Um golpe com as REGRAS da Torre (`logic.check_hit_and_evasion` e
    `logic.calc_final_damage`, sem os gatilhos de classe):
      acerto = 100 + precisão − esquiva, entre 5% e 95%;
      dano   = max(1, ataque − defesa) + (−1 a +2);
      crítico: chance = crit%, dano ×1,5.
    Devolve 0 quando erra."""
    chance = max(5, min(95, 100 + int(atacante.get("acc", 0)) - int(alvo.get("eva", 0))))
    if rng.randint(1, 100) > chance:
        return 0
    dano = max(1, max(1, int(atacante["atk"]) - int(alvo["def"])) + rng.randint(-1, 2))
    if rng.randint(1, 100) <= int(atacante.get("crit", 0)):
        dano = int(dano * 1.5)
    return max(1, int(dano * mult))


# ──────────────────────────────────────────────────────────── estado ──
def nova_travessia(origem: int, destino: int, lutadores: list, comida: int,
                   rng: random.Random, gerar=None) -> dict:
    t = {"origem": int(origem), "destino": int(destino),
         "tempo": tempo_da_travessia(destino), "turno": 0,
         "comida": int(comida), "comida_levada": int(comida),
         "tatica": "normal", "grupo": [dict(l) for l in lutadores],
         "inimigos": [], "turno_da_batalha": 0, "batalhas_vencidas": 0,
         "reforcos": 0, "chefe_apareceu": False, "espolio_material": {}, "espolio_couro": 0,
         "abatidos": 0, "log": [f"🧭 O clã deixou o Andar {origem} rumo ao Andar {destino}."],
         "fim": None}
    _nova_batalha(t, rng, gerar)
    return t


def de_pe(t: dict) -> list:
    return [m for m in t["grupo"] if m["hp"] > 0]


def _andar_das_ondas(t: dict) -> int:
    # Andar de chefe só tem chefe: as ondas do caminho vêm do andar anterior
    # (é o fim da subida), e o chefe entra no fim.
    d = t["destino"]
    return d - 1 if d % 5 == 0 and d > 1 else d


def _nova_batalha(t: dict, rng: random.Random, gerar=None) -> None:
    andar = _andar_das_ondas(t)
    primeiro = _monstro(andar, rng, gerar)
    t["inimigos"] = [primeiro]
    # bicho comum anda em bando; elite e general vêm sozinhos
    if primeiro["tipo"] == "normal" and rng.random() < 0.5:
        t["inimigos"].append(_monstro(andar, rng, gerar))
    t["turno_da_batalha"] = 0
    t["reforcos_da_batalha"] = 0
    nomes = ", ".join(m["nome"] for m in t["inimigos"])
    t["log"].append(f"⚔️ Batalha {t['batalhas_vencidas'] + 1}: {nomes}.")


def _entrar_chefe(t: dict, rng: random.Random, gerar=None) -> None:
    chefe = _monstro(t["destino"], rng, gerar)
    t["inimigos"].append(chefe)
    t["chefe_apareceu"] = True
    t["turno_da_batalha"] = 0
    t["log"].append(f"👹 {chefe['nome']}, o senhor do Andar {t['destino']}, entrou na luta!")


def _creditar_abate(t: dict, m: dict, rng: random.Random) -> None:
    from game.clan_materiais import material_do_monstro
    rank, qtd = material_do_monstro(m["andar"], m["tipo"], rng)
    if qtd:
        t["espolio_material"][str(rank)] = t["espolio_material"].get(str(rank), 0) + qtd
    # 🪙 20/09 (dev): a Travessia não dá mais ouro (ouro é só do que o reino
    # paga). O bicho abatido deixa COURO: 1 do comum, 2 da elite/general, 3
    # do chefe.
    t["espolio_couro"] = int(t.get("espolio_couro", 0)) + (3 if m["tipo"] == "boss" else 2 if m["tipo"] != "normal" else 1)
    t["abatidos"] += 1


def turno(t: dict, rng: random.Random, gerar=None) -> None:
    """Um turno da travessia: o grupo bate, os monstros batem, o relógio anda."""
    if t["fim"]:
        return
    tat = TATICAS[t.get("tatica", "normal")]
    t["turno"] += 1

    if t["inimigos"]:
        t["turno_da_batalha"] += 1
        # o grupo concentra no primeiro inimigo vivo — derrubar um a um é o
        # que abre caminho antes do reforço
        for m in de_pe(t):
            vivos = [e for e in t["inimigos"] if e["hp"] > 0]
            if not vivos:
                break
            alvo = vivos[0]
            alvo["hp"] -= _golpe(m, alvo, tat["dado"], rng)
            if alvo["hp"] <= 0:
                _creditar_abate(t, alvo, rng)
        t["inimigos"] = [e for e in t["inimigos"] if e["hp"] > 0]
        for e in t["inimigos"]:
            alvos = de_pe(t)
            if not alvos:
                break
            vitima = rng.choice(alvos)
            vitima["hp"] -= _golpe(e, vitima, tat["recebido"], rng)
            if vitima["hp"] <= 0:
                vitima["hp"] = 0
                t["log"].append(f"🩸 {vitima['nome']} caiu.")

        if not t["inimigos"]:
            t["batalhas_vencidas"] += 1
            t["log"].append(f"✅ Batalha vencida em {t['turno_da_batalha']} turno(s).")
            t["folga"] = FOLGA_ENTRE_BATALHAS
        elif t["turno_da_batalha"] >= LIMITE_BATALHA:
            # Não venceu a tempo: o bando cresce — e cresce MAIS a cada vez
            # que o limite estoura na mesma batalha (1, depois 2, depois 3).
            # Medido com reforço fixo de 1: um grupo fraco sobrevivia ao
            # relógio sem vencer batalha nenhuma, só apanhando devagar.
            t["reforcos_da_batalha"] = int(t.get("reforcos_da_batalha", 0)) + 1
            chegam = [_monstro(_andar_das_ondas(t), rng, gerar)
                      for _ in range(t["reforcos_da_batalha"])]
            t["inimigos"].extend(chegam)
            t["reforcos"] += len(chegam)
            t["turno_da_batalha"] = 0
            t["log"].append(f"📯 Demorou demais: chegaram {len(chegam)} de reforço "
                            f"({', '.join(m['nome'] for m in chegam)}).")
    else:
        t["folga"] = max(0, int(t.get("folga", 0)) - 1)
        if t["folga"] == 0 and t["turno"] < t["tempo"]:
            _nova_batalha(t, rng, gerar)

    # o chefe do andar de chefe entra no fim da subida, junto de quem estiver lutando
    if (t["destino"] % 5 == 0 and not t["chefe_apareceu"]
            and t["turno"] >= int(t["tempo"] * CHEFE_ENTRA_EM)):
        _entrar_chefe(t, rng, gerar)

    # ração: o caminho come
    if t["turno"] % RACAO_A_CADA == 0:
        precisa = len(de_pe(t))
        if t["comida"] >= precisa:
            t["comida"] -= precisa
        else:
            t["comida"] = 0
            for m in de_pe(t):
                m["hp"] = max(1, m["hp"] - m["hp_max"] // 10)
            t["log"].append("🍖 A comida acabou: a fome tira 10% da vida de todos.")

    _conferir_fim(t)


def _conferir_fim(t: dict) -> None:
    if not de_pe(t):
        t["fim"] = "fracasso"
        t["log"].append("💀 Todos caíram. A travessia falhou.")
    elif t["turno"] >= t["tempo"]:
        chefe_vivo = any(e["tipo"] == "boss" for e in t["inimigos"])
        if chefe_vivo:
            # O chefe bloqueia a saída: o tempo acabou, mas não dá pra passar
            # por ele — a travessia só termina quando ele cair (ou o grupo).
            return
        t["fim"] = "sucesso"
        t["log"].append(f"🏁 O clã chegou ao Andar {t['destino']}!")


def avancar(t: dict, rng: random.Random, max_turnos: int = 1, gerar=None,
            parar_em_evento: bool = True) -> None:
    """Anda até `max_turnos`, parando antes se algo pedir atenção (alguém
    caiu, reforço, batalha vencida, chefe) — o jogador decide nessas horas."""
    for _ in range(int(max_turnos)):
        if t["fim"]:
            return
        antes = (len(de_pe(t)), t["reforcos"], t["batalhas_vencidas"], t["chefe_apareceu"])
        turno(t, rng, gerar)
        depois = (len(de_pe(t)), t["reforcos"], t["batalhas_vencidas"], t["chefe_apareceu"])
        if parar_em_evento and antes != depois:
            return
        # teto de segurança: chefe que não cai e grupo que não cai
        if t["turno"] > t["tempo"] * 4:
            t["fim"] = "fracasso"
            t["log"].append("🏳️ O grupo não conseguiu passar pelo chefe e desistiu.")
            return


def mudar_tatica(t: dict, tatica: str) -> None:
    if tatica not in TATICAS:
        raise ValueError("Tática desconhecida.")
    t["tatica"] = tatica


def comer(t: dict) -> bool:
    """Refeição extra no meio da luta: cura quem está de pé. Gasta a reserva
    da carroça — é a decisão de quando parar pra respirar."""
    custo = CUSTO_REFEICAO * len(de_pe(t))
    if t["fim"] or t["comida"] < custo:
        return False
    t["comida"] -= custo
    for m in de_pe(t):
        m["hp"] = min(m["hp_max"], m["hp"] + int(m["hp_max"] * CURA_DA_REFEICAO))
    t["log"].append(f"🍖 O grupo comeu no meio da luta (−{custo} de comida).")
    return True


def recuar(t: dict) -> None:
    if not t["fim"]:
        t["fim"] = "recuou"
        t["log"].append("↩️ O clã voltou pro Andar de onde saiu.")


def resultado_final(t: dict) -> dict:
    """Chegou: o clã muda de andar e traz tudo. Recuou: metade. Caiu: nada.
    Quem caiu volta ferido grave; quem se machucou, ferimento pela vida que
    perdeu. A comida que sobrou volta ao celeiro."""
    fim = t["fim"]
    mult = {"sucesso": 1.0, "recuou": 0.5}.get(fim, 0.0)
    material = {int(k): int(v * mult) for k, v in t["espolio_material"].items() if int(v * mult)}
    ferimentos = {}
    for m in t["grupo"]:
        perdido = 1 - m["hp"] / max(1, m["hp_max"])
        if m["hp"] <= 0:
            ferimentos[m["slot"]] = 5
        elif perdido >= 0.2:
            ferimentos[m["slot"]] = max(1, round(perdido * 4))
    return {"fim": fim, "chegou": fim == "sucesso", "destino": t["destino"],
            "material": material, "couro": int(int(t.get("espolio_couro", 0)) * mult),
            "comida_volta": int(t["comida"]), "ferimentos": ferimentos,
            "batalhas": t["batalhas_vencidas"], "abatidos": t["abatidos"], "reforcos": t["reforcos"]}
