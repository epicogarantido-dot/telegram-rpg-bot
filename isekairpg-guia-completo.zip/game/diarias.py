# game/diarias.py
"""
📅 MISSÕES DIÁRIAS (20/09/2026 — pedido do dev)

Desde 20/09, OURO vem só do que "o reino paga": monstro da Torre e da Raid
não dropa ouro, e a Travessia e as decisões do clã dão outros recursos. As
diárias são o pagamento do reino pelo trabalho do dia — ~4.000 de ouro se
fizer todas (as quatro + o bônus de completar tudo).

O dia vira à meia-noite do servidor (mesma data do login diário). O
progresso e o que foi resgatado ficam em `p["diarias"]` (CAMPOS_EXTRAS).
"""
from __future__ import annotations

import datetime

DIARIAS = [
    {"id": "d_torre", "nome": "Caçada na Torre", "desc": "Mate 30 monstros na Torre.",
     "contador": "torre", "meta": 30, "ouro": 1200},
    {"id": "d_raid", "nome": "Raid do dia", "desc": "Mate 10 monstros numa Raid.",
     "contador": "raid", "meta": 10, "ouro": 1200},
    {"id": "d_arena", "nome": "Duelo na Arena", "desc": "Vença 1 luta na Arena.",
     "contador": "arena", "meta": 1, "ouro": 600},
    {"id": "d_clan", "nome": "Batedores do clã", "desc": "Explore o andar com uma equipe do clã.",
     "contador": "clan_explorar", "meta": 1, "ouro": 400},
]
BONUS_TODAS = 600          # 1200 + 1200 + 600 + 400 + 600 = 4000
TOTAL_DO_DIA = sum(d["ouro"] for d in DIARIAS) + BONUS_TODAS


def _hoje() -> str:
    return datetime.date.today().isoformat()


def estado(p: dict) -> dict:
    """O estado de hoje — zera quando o dia muda."""
    st = p.get("diarias") or {}
    if st.get("dia") != _hoje():
        st = {"dia": _hoje(), "progresso": {}, "resgatadas": []}
        p["diarias"] = st
    return st


def contar(p: dict, contador: str, n: int = 1) -> None:
    st = estado(p)
    st["progresso"][contador] = int(st["progresso"].get(contador, 0)) + int(n)


def status(p: dict) -> dict:
    st = estado(p)
    lista = []
    for d in DIARIAS:
        feito = int(st["progresso"].get(d["contador"], 0))
        lista.append({**{k: d[k] for k in ("id", "nome", "desc", "meta", "ouro")},
                      "progresso": min(feito, d["meta"]), "pronta": feito >= d["meta"],
                      "resgatada": d["id"] in st["resgatadas"]})
    todas = all(x["resgatada"] for x in lista)
    return {"dia": st["dia"], "diarias": lista, "bonus": BONUS_TODAS,
            "bonus_pronto": todas and "bonus" not in st["resgatadas"],
            "bonus_resgatado": "bonus" in st["resgatadas"], "total": TOTAL_DO_DIA}


def resgatar(p: dict, missao_id: str) -> tuple[bool, str, int]:
    """(ok, mensagem, ouro). `missao_id == "bonus"` resgata o bônus de tudo."""
    st = estado(p)
    if missao_id in st["resgatadas"]:
        return False, "Já resgatada hoje.", 0
    if missao_id == "bonus":
        if not all(d["id"] in st["resgatadas"] for d in DIARIAS):
            return False, "Resgate as quatro diárias primeiro.", 0
        ouro = BONUS_TODAS
    else:
        d = next((x for x in DIARIAS if x["id"] == missao_id), None)
        if not d:
            return False, "Diária desconhecida.", 0
        if int(st["progresso"].get(d["contador"], 0)) < d["meta"]:
            return False, "Ainda não terminou essa diária.", 0
        ouro = d["ouro"]
    st["resgatadas"].append(missao_id)
    p["gold"] = int(p.get("gold", 0)) + ouro
    return True, f"+{ouro} de ouro pago pelo reino.", ouro
