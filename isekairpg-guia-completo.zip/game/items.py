# game/items.py

# Slots de equipamento
SLOTS = ["weapon", "armor", "helmet", "gloves", "boots", "shield", "belt", "necklace", "ring"]
INV_ITEMS_PER_SLOT = 10

# Database de Cores Consolidadas (Crafts, Elementos e Premium)
CORES_DB = {
    # === ARMA/ARMADURA (Básicos para Craft) ===
    "wa_atk": {"name": "Core de Arma ATK", "bonus": {"atk": 2}, "sell": 12},
    "ar_def": {"name": "Core de Armadura DEF", "bonus": {"def": 2}, "sell": 12},
    "ac_atk": {"name": "Core de Acessório ATK", "bonus": {"atk": 2}, "sell": 12},
    "ac_def": {"name": "Core de Acessório DEF", "bonus": {"def": 2}, "sell": 12},


    
    # === ATRIBUTOS SECUNDÁRIOS ===
    "crit": {"name": "Core Crítico", "bonus": {"crit": 2}, "sell": 25},
    "acc": {"name": "Core Precisão", "bonus": {"acc": 2}, "sell": 25},
    "eva": {"name": "Core Esquiva", "bonus": {"eva": 2}, "sell": 25},
    "spd": {"name": "Core Velocidade", "bonus": {"spd": 2}, "sell": 25},
    "reg": {"name": "Core Regen", "bonus": {"reg": 2}, "sell": 25},

    # === CORES DE SKILLS / ELEMENTAIS (Se socketar, dão +2% de buff para a própria skill no logic.py) ===
    "core_fire": {"name": "Core de Queimada", "bonus_pct": {}, "sell": 80},
    "core_ice": {"name": "Core de Congelamento", "bonus_pct": {}, "sell": 80},
    "core_thunder": {"name": "Core de Raio", "bonus_pct": {}, "sell": 80},
    "core_nature": {"name": "Core da Natureza", "bonus_pct": {}, "sell": 80},
    "core_dark": {"name": "Core Escuro", "bonus_pct": {}, "sell": 120},
    "core_life": {"name": "Core de Vampirismo", "bonus_pct": {}, "sell": 200},
    
    # === NOVAS: MAGIAS EM ÁREA E SUPORTE ===
    "core_meteor": {"name": "Core de Meteoro", "bonus_pct": {}, "sell": 250},
    "core_blizzard": {"name": "Core de Nevasca", "bonus_pct": {}, "sell": 250},
    "core_venom": {"name": "Core de Nuvem Tóxica", "bonus_pct": {}, "sell": 200},
    "core_quake": {"name": "Core de Terremoto", "bonus_pct": {}, "sell": 200},
    "core_holy": {"name": "Core de Luz Divina", "bonus_pct": {}, "sell": 180},

    # === NOVAS: ARTES MARCIAIS E LÂMINAS ===
    "core_spiral": {"name": "Core do Ataque Espiral", "bonus_pct": {}, "sell": 150},
    "core_gale": {"name": "Core do Corte Vendaval", "bonus_pct": {}, "sell": 180},
    "core_shatter": {"name": "Core do Golpe Estilhaçador", "bonus_pct": {}, "sell": 160},
    "core_shadow_dance": {"name": "Core da Dança das Sombras", "bonus_pct": {}, "sell": 300},
    "core_seven_blades": {"name": "Core das 7 Lâminas do Juízo", "bonus_pct": {}, "sell": 500},

    # === PASSIVAS PREMIUM (Se socketar, dão o bônus fixo bruto direto no item) ===
    "core_atk": {"name": "Core de Ataque", "bonus": {"atk": 10}, "sell": 50},
    "core_def": {"name": "Core de Defesa", "bonus": {"def": 10}, "sell": 50},
    "core_hp": {"name": "Core de Vida Máxima", "bonus": {"hp_max": 50}, "sell": 50},
    "core_spd": {"name": "Core de Velocidade", "bonus": {"spd": 5}, "sell": 50},
    "core_reg": {"name": "Core de Regeneração", "bonus": {"reg": 5}, "sell": 50},
    "core_crit": {"name": "Core de Crítico", "bonus": {"crit": 5}, "sell": 50},
    "core_acc": {"name": "Core de Precisão", "bonus": {"acc": 5}, "sell": 50},
    "core_eva": {"name": "Core de Esquiva", "bonus": {"eva": 5}, "sell": 50},

    # === NOVAS: CULTIVAÇÃO / TREINAMENTO CORPORAL (Socketar dá status brutal defensivo) ===
    "core_iron_body": {"name": "Core do Corpo de Ferro", "bonus": {"hp_max": 30, "def": 5}, "sell": 150},
    "core_qi_refine": {"name": "Core de Refinamento de Qi", "bonus": {"atk": 5, "reg": 2}, "sell": 180},
    "core_lightning_veins": {"name": "Core das Veias de Relâmpago", "bonus": {"spd": 5, "eva": 2}, "sell": 160},
    "core_jade_bones": {"name": "Core dos Ossos de Jade", "bonus": {"def": 10, "hp_max": 20}, "sell": 200},

    # === NOVAS: DOMÍNIO E AURA (Socketar dá Porcentagem Global no seu boneco) ===
    "core_void_sword": {"name": "Core da Espada Vazia", "bonus_pct": {"atk": 0.03, "crit": 0.02}, "sell": 250},
    "core_phantom_step": {"name": "Core dos Passos Fantasmas", "bonus_pct": {"spd": 0.05, "eva": 0.03}, "sell": 220},
    "core_asura_blood": {"name": "Core do Sangue de Asura", "bonus_pct": {"atk": 0.05, "hp_max": 0.05}, "sell": 400},
}

def core_base_and_tier(cid):
    """
    Converte 'wa_atk_t3' -> ('wa_atk', 3).
    Se não tiver sufixo, assume tier 1.
    """
    if "_t" in cid:
        base, suf = cid.rsplit("_t", 1)
        if suf.isdigit():
            t = max(1, min(20, int(suf)))
            return base, t
    return cid, 1
# Raridades e Chances
RARITIES = {
    "common": {"name": "Comum", "cores": 4, "chance": 1},
    "uncommon": {"name": "Incomum", "cores": 5, "chance": 0.80},
    "rare": {"name": "Raro", "cores": 6, "chance": 0.60},
    "epic": {"name": "Épico", "cores": 7, "chance": 0.40},
    "legendary": {"name": "Lendário", "cores": 8, "chance": 0.20},
}

# ⛏️ 20/09/2026 — MATERIAL POR RARIDADE NA FORJA.
# Forjar peça pessoal passou a pedir material da Torre, além de cores e
# ouro. O rank acompanha a raridade escolhida: peça lendária pede o
# material Primordial dos andares 41–50 — o topo do equipamento passa a
# depender de chegar fundo, não só de acumular ouro.
# Quantidades medidas contra a renda de um posto dedicado (clan_afk): cada
# forja custa ~1/4 de sessão de farm no rank dela (91/sessão no rank 1,
# 400 no rank 5). Com a chance de sucesso, uma lendária sai em média por
# ~1,25 sessão de material Primordial.
#
# 20/09 (2ª rodada, pedido do dev): o lendário caiu pra 10 — ele tem só 20%
# de chance de sair, e cobrar 100 de Primordial por uma TENTATIVA fazia o
# material falhar junto com a forja. E o custo passou a subir com o TIER dos
# cores usados (`MATERIAL_POR_TIER`): core melhor pede mais material, então
# a peça de ponta custa mais que a peça montada com core de andar raso.
#
# 20/09 (3ª rodada): a mesma lógica do lendário estendida às outras. O que
# o jogador sente é o custo POR PEÇA QUE SAI, não por tentativa — então o
# piso agora é "~50 de material por sucesso, em média": piso × chance ≈ 50.
#   incomum 40 × 80%  → 50 por peça     raro  30 × 60% → 50
#   épico   20 × 40%  → 50 por peça     lend. 10 × 20% → 50
# O comum fica em 25 (100% de chance): é a peça de começo, feita de
# material Bruto que sobra — cobrar 50 ali só atrasaria o primeiro item.
REQ_MATERIAL_CRAFT = {
    # ⚔️ 20/09 (regra do dev): o rank vem do MONSTRO — comum e incomum usam o
    # rank 1 (bicho comum), raro e épico o rank 2 (elite/general), lendário
    # o rank 3 (chefe). As quantidades seguem "~50 por peça que sai".
    "common":    {"rank": 1, "qtd": 25},
    "uncommon":  {"rank": 1, "qtd": 40},
    "rare":      {"rank": 2, "qtd": 30},
    "epic":      {"rank": 2, "qtd": 20},
    "legendary": {"rank": 3, "qtd": 10},
}
# +1 de material por tier ACIMA do 1, em cada core usado. Um lendário com os
# 8 cores Tier 5 (andares 41–50) sai por 10 + 8×4 = 42 de Primordial; com
# cores Tier 1, pelos 10 do piso.
MATERIAL_POR_TIER = 1

# Requisitos de cores por slot (craft)
REQ_CRAFT = {
    "weapon": {"wa_atk": 2},
    "armor": {"ar_def": 2},
    "helmet": {"ar_def": 2},
    "gloves": {"ar_def": 2},
    "boots": {"ar_def": 2},
    "shield": {"ar_def": 2},
    "belt": {"ac_def": 2},
    "necklace": {"ac_def": 2},
    "ring": {"ac_atk": 2},
}

# Tipos de arma
WEAPON_TYPES = {
    "sword":  {"name": "Espada"},
    "spear":  {"name": "Lança"},
    "bow":    {"name": "Arco"},
    "dagger": {"name": "Adaga"},
    "hammer": {"name": "Martelo"},
}

# Classes
CLASSES_DB = {
    "guerreiro": {"name": "Guerreiro", "attr": "str", "sec": "atk"},
    "guardiao": {"name": "Guardião", "attr": "vit", "sec": "def"},
    "assassino": {"name": "Assassino", "attr": "dex", "sec": "crit"},
    "explorador": {"name": "Explorador", "attr": "agi", "sec": "eva"},
    "duelista": {"name": "Duelista", "attr": "str", "sec": "acc"},
    "barbaro": {"name": "Bárbaro", "attr": "vit", "sec": "hp_max"},
    "cacador": {"name": "Caçador", "attr": "dex", "sec": "spd"},
    "andarilho": {"name": "Andarilho", "attr": "agi", "sec": "reg"},
    "mercenario": {"name": "Mercenário", "attr": "str", "sec": "acc"},
    "estrategista": {"name": "Estrategista", "attr": "dex", "sec": "spd"},
}

# Trilhas
TRAILS_DB = {
    "str": {"sec_opts": ["atk", "def"]},
    "vit": {"sec_opts": ["hp_max", "reg"]},
    "agi": {"sec_opts": ["spd", "eva"]},
    "dex": {"sec_opts": ["crit", "acc"]},
}

# === FUNÇÕES ===

def core_name(cid: str) -> str:
    """Busca o nome formatado do core (incluindo tier se tiver)."""
    base_id, tier = core_base_and_tier(cid)
    base_name = CORES_DB.get(base_id, {}).get("name", base_id)

    if tier > 1:
        return f"{base_name} [T{tier}]"
    return base_name

def core_bonus(cid: str) -> dict:
    """Retorna os bônus fixos, escalando com tier se existir no ID."""
    base_id, tier = core_base_and_tier(cid)
    bonus = CORES_DB.get(base_id, {}).get("bonus", {}) or {}

    if tier <= 1 or not bonus:
        return dict(bonus)

    scaled = {}
    for k, v in bonus.items():
        scaled[k] = int(v * tier)  # T2 = 2x, T3 = 3x...
    return scaled

def core_bonus_pct(cid: str) -> dict:
    """Retorna bônus percentuais globais, escalando com tier se existir."""
    base_id, tier = core_base_and_tier(cid)
    bonus_pct = CORES_DB.get(base_id, {}).get("bonus_pct", {}) or {}

    if tier <= 1 or not bonus_pct:
        return dict(bonus_pct)

    scaled = {}
    for k, v in bonus_pct.items():
        scaled[k] = float(v) * tier
    return scaled
    

def core_sell_value(cid: str, tier: int = 1) -> int:
    """
    Valor de venda ajustado por tier (1-5).
    Se o ID já tiver sufixo (_t2), usa o tier do ID.
    """
    base_id, t_from_id = core_base_and_tier(cid)
    base = int(CORES_DB.get(base_id, {}).get("sell", 5))

    # Prioriza tier embutido no ID
    t = t_from_id if t_from_id > 1 else max(1, min(5, tier))
    return base * t

def apply_bonus(s: dict, bonus: dict) -> dict:
    """Aplica bônus fixos de item/core ao status do jogador."""
    for k, v in bonus.items():
        s[k] = s.get(k, 0) + v
    return s