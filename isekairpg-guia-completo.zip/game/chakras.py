# game/chakras.py
"""
Sistema de Chakras.

Ao criar o personagem, o jogador recebe um Chakra aleatório: um bônus
permanente em UM status (ATK, DEF, Crítico ou Evasão), ou a rara
"Defesa Absoluta" (chance de anular 100% do dano recebido).

O chakra é sorteado uma única vez (na criação do personagem) e nunca muda.
"""
import random

# Cada chakra é ou um bônus percentual direto num stat ("kind": "stat"),
# ou um gatilho de combate ("kind": "trigger") que se integra ao mesmo
# dicionário usado pelas especialidades (get_combat_triggers).
CHAKRAS_DB = {
    "chakra_atk": {
        "name": "🔥 Chakra do Punho Flamejante",
        "kind": "stat",
        "stat": "atk",
        "label": "ATK",
    },
    "chakra_def": {
        "name": "🪨 Chakra da Muralha de Pedra",
        "kind": "stat",
        "stat": "def",
        "label": "DEF",
    },
    "chakra_crit": {
        "name": "⚡ Chakra da Lâmina Relâmpago",
        "kind": "stat",
        "stat": "crit",
        "label": "CRÍTICO",
    },
    "chakra_eva": {
        "name": "🌪️ Chakra do Vento Fantasma",
        "kind": "stat",
        "stat": "eva",
        "label": "EVASÃO",
    },
    "chakra_defesa_absoluta": {
        "name": "🛡️ Chakra da Defesa Absoluta",
        "kind": "trigger",
        "trigger": "ignore_damage_chance",
        "label": "DEFESA ABSOLUTA",
    },
}

# Faixa de bônus percentual pra chakras de stat (ex: +10% a +25% de ATK)
STAT_PCT_MIN = 0.10
STAT_PCT_MAX = 0.25

# Faixa de chance (em pontos percentuais) pra chakras de gatilho
# (ex: 5% a 15% de chance de anular o dano)
TRIGGER_MIN = 5
TRIGGER_MAX = 15


def roll_chakra() -> dict:
    """Sorteia um chakra aleatório pra um personagem novo."""
    chakra_id = random.choice(list(CHAKRAS_DB.keys()))
    info = CHAKRAS_DB[chakra_id]

    if info["kind"] == "stat":
        pct = round(random.uniform(STAT_PCT_MIN, STAT_PCT_MAX), 2)
        return {"id": chakra_id, "kind": "stat", "stat": info["stat"], "pct": pct}

    value = random.randint(TRIGGER_MIN, TRIGGER_MAX)
    return {"id": chakra_id, "kind": "trigger", "trigger": info["trigger"], "value": value}


def chakra_label(chakra: dict | None) -> str:
    """Retorna uma linha de texto pronta pra exibir no status do jogador."""
    if not chakra or not chakra.get("id"):
        return "Nenhum"

    info = CHAKRAS_DB.get(chakra["id"])
    if not info:
        return "Desconhecido"

    if chakra.get("kind") == "stat":
        pct = int(round(chakra.get("pct", 0) * 100))
        return f"{info['name']} (+{pct}% {info['label']})"

    value = chakra.get("value", 0)
    return f"{info['name']} ({value}% de chance de {info['label']})"
