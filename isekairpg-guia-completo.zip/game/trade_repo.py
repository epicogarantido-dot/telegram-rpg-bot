import sqlite3
import json
import os
import time
from typing import Optional, List, Tuple, Dict, Any

from infra.migracao import garantir_colunas, garantir_colunas_async

# 🧱 20/09/2026 — os CREATE deste arquivo viraram constantes pra que a
# MESMA string crie a tabela e migre banco velho (infra/migracao.py).
# Coluna nova entra aqui e chega sozinha em quem já tinha a tabela.
_SQL_MARKETPLACE = """
                CREATE TABLE IF NOT EXISTS marketplace (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    seller_pid TEXT NOT NULL,
                    seller_chat_id INTEGER,
                    seller_name TEXT,
                    item_json TEXT NOT NULL,
                    slot TEXT NOT NULL,
                    rarity TEXT NOT NULL,
                    price INTEGER DEFAULT 50,
                    listed_at INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL
                );
                """


DB_PATH = "data/game.db"
# 🔥 Corrigido (07/07/2026): esse módulo cria a conexão com o banco assim que
# é importado (TradeRepo() no fim do arquivo), ANTES de qualquer init_db()
# do resto do jogo rodar. Se a pasta "data/" não existisse ainda (ex: deploy
# novo, zip sem a pasta), dava "unable to open database file" e o bot nem
# subia. Garantimos a pasta aqui, no import, pra nunca mais acontecer.
os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)


def _norm_rarity(r: Optional[str]) -> Optional[str]:
    """Normaliza nomes de raridade para inglês, usados no banco."""
    if not r:
        return None
    r = str(r).strip().lower()
    MAP = {
        "comum": "common",
        "incomum": "uncommon",
        "raro": "rare",
        "épico": "epic",
        "epico": "epic",
        "lendário": "legendary",
        "lendario": "legendary",
    }
    return MAP.get(r, r)


class TradeRepo:
    """Sistema P2P de troca de itens."""

    def __init__(self) -> None:
        self.init_tables()

    def init_tables(self) -> None:
        """Cria tabela se não existir."""
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute(
                _SQL_MARKETPLACE
            )
            garantir_colunas(c, _SQL_MARKETPLACE)  # 🧱 migra o que o CREATE tem e o disco não
            conn.commit()

    def _row_to_item(self, row) -> Dict[str, Any]:
        """Converte linha do banco no dicionário que o resto do jogo espera."""
        return {
            "id": row[0],
            "seller_pid": row[1],
            "seller_chat_id": row[2],
            "seller_name": row[3],
            "item": json.loads(row[4]),
            "slot": row[5],
            "rarity": row[6],
            "price": row[7],
            "listed_at": row[8],
            "expires_at": row[9],
        }

    def list_item(
        self,
        seller_pid: str,
        seller_chat_id: int,
        seller_name: str,
        item: dict,
        slot: str,
        rarity: str,
        price: int = 50,
        ttl_days: int = 10,
    ) -> Tuple[bool, str]:
        """Lista um item no marketplace."""
        try:
            now = int(time.time())
            expires_at = now + ttl_days * 86400
            rarity_db = _norm_rarity(rarity)

            with sqlite3.connect(DB_PATH) as conn:
                c = conn.cursor()
                c.execute(
                    """
                    INSERT INTO marketplace
                    (seller_pid, seller_chat_id, seller_name, item_json, slot,
                     rarity, price, listed_at, expires_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        seller_pid,
                        seller_chat_id,
                        seller_name,
                        json.dumps(item),
                        slot,
                        rarity_db,
                        price,
                        now,
                        expires_at,
                    ),
                )
                conn.commit()
            return True, f"✅ Item listado por {price}⭐ por {ttl_days} dias!"
        except Exception as e:
            return False, f"❌ Erro ao listar: {str(e)}"

    # Ordens que o SQL resolve sozinho. Atributo NÃO entra aqui: os bônus
    # moram num JSON dentro da coluna `item`, e ordenar por eles no banco
    # exigiria json_extract — que depende de o SQLite ter sido compilado
    # com JSON1. Não vale apostar a tela do mercado nisso.
    ORDENS_SQL = {
        "recentes": "listed_at DESC",
        "antigos": "listed_at ASC",
        "preco_asc": "price ASC",
        "preco_desc": "price DESC",
    }
    # Teto de linhas lidas quando a ordem é por atributo. O mercado é
    # naturalmente pequeno (anúncio custa 50⭐ e expira em 10 dias), mas um
    # teto impede que um dia ele vire uma leitura de tabela inteira.
    TETO_ORDEM_PYTHON = 500

    def get_items_by_filter(
        self,
        slot: Optional[str] = None,
        rarity: Optional[str] = None,
        page: int = 0,
        per_page: int = 10,
        ordem: str = "recentes",
    ) -> Tuple[List[dict], int]:
        """Busca items com filtros opcionais, ordenação e paginação."""
        now = int(time.time())
        base = "FROM marketplace WHERE expires_at > ?"
        params: List[Any] = [now]

        if slot:
            base += " AND slot = ?"
            params.append(slot)

        if rarity:
            rarity_db = _norm_rarity(rarity)
            base += " AND rarity = ?"
            params.append(rarity_db)

        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute(f"SELECT COUNT(*) {base}", params)
            total = c.fetchone()[0]

            offset = page * per_page
            atributo = ordem if ordem in ("atk", "def", "hp", "spd", "crit", "eva") else None

            if atributo:
                # Lê o lote (com teto), ordena pelo bônus em Python e só
                # então pagina. Ordenar depois de paginar ordenaria só a
                # página — que é o bug óbvio dessa funcionalidade.
                c.execute(f"SELECT * {base} ORDER BY listed_at DESC LIMIT ?",
                          params + [self.TETO_ORDEM_PYTHON])
            else:
                c.execute(
                    f"SELECT * {base} ORDER BY "
                    f"{self.ORDENS_SQL.get(ordem, self.ORDENS_SQL['recentes'])} "
                    f"LIMIT ? OFFSET ?",
                    params + [per_page, offset],
                )
            rows = c.fetchall()

        items = [self._row_to_item(r) for r in rows]

        if atributo:
            items.sort(key=lambda it: int((it.get("item") or {}).get("bonus", {})
                                          .get(atributo, 0) or 0), reverse=True)
            items = items[offset:offset + per_page]
            # `total` vem do COUNT e continua certo pra paginação; o que o
            # teto limita é quantos entram na ordenação, não a contagem.

        return items, total

    def get_items_recent(
        self, page: int = 0, per_page: int = 10
    ) -> Tuple[List[dict], int]:
        """Itens recentes para o MARKET GERAL."""
        now = int(time.time())
        base = "FROM marketplace WHERE expires_at > ?"
        params: List[Any] = [now]

        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute(f"SELECT COUNT(*) {base}", params)
            total = c.fetchone()[0]

            offset = page * per_page
            atributo = ordem if ordem in ("atk", "def", "hp", "spd", "crit", "eva") else None

            if atributo:
                # Lê o lote (com teto), ordena pelo bônus em Python e só
                # então pagina. Ordenar depois de paginar ordenaria só a
                # página — que é o bug óbvio dessa funcionalidade.
                c.execute(f"SELECT * {base} ORDER BY listed_at DESC LIMIT ?",
                          params + [self.TETO_ORDEM_PYTHON])
            else:
                c.execute(
                    f"SELECT * {base} ORDER BY "
                    f"{self.ORDENS_SQL.get(ordem, self.ORDENS_SQL['recentes'])} "
                    f"LIMIT ? OFFSET ?",
                    params + [per_page, offset],
                )
            rows = c.fetchall()

        items = [self._row_to_item(r) for r in rows]
        return items, total

    def get_item_by_id(self, item_id: int) -> Optional[dict]:
        """Pega item específico (não expirado)."""
        now = int(time.time())
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute(
                """
                SELECT * FROM marketplace
                WHERE id = ? AND expires_at > ?
                """,
                (item_id, now),
            )
            row = c.fetchone()

        if not row:
            return None
        return self._row_to_item(row)

    def buy_item(self, item_id: int) -> Tuple[bool, str]:
        """Compra um item (remove do marketplace)."""
        try:
            with sqlite3.connect(DB_PATH) as conn:
                c = conn.cursor()
                c.execute("DELETE FROM marketplace WHERE id = ?", (item_id,))
                conn.commit()
            return True, "✅ Item comprado!"
        except Exception as e:
            return False, f"❌ Erro: {str(e)}"

    def remove_expired(self) -> None:
        """Remove items expirados (pode chamar periodicamente)."""
        try:
            now = int(time.time())
            with sqlite3.connect(DB_PATH) as conn:
                c = conn.cursor()
                c.execute(
                    "DELETE FROM marketplace WHERE expires_at <= ?", (now,)
                )
                conn.commit()
        except Exception:
            pass

    def get_items_by_seller(self, seller_pid: str) -> List[dict]:
        """Retorna todos os itens listados pelo vendedor."""
        now = int(time.time())
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute(
                """
                SELECT * FROM marketplace
                WHERE seller_pid = ? AND expires_at > ?
                ORDER BY id DESC
                """,
                (seller_pid, now),
            )
            rows = c.fetchall()
        return [self._row_to_item(r) for r in rows]

    def cancel_item(self, item_id: int, seller_pid: str) -> Tuple[bool, Any]:
        """
        Cancela um anúncio e devolve o item.
        Retorna (True, dict_item) ou (False, msg_erro).
        """
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute(
                "SELECT * FROM marketplace WHERE id = ? AND seller_pid = ?",
                (item_id, seller_pid),
            )
            row = c.fetchone()
            if not row:
                return False, "❌ Item não encontrado ou não é seu."

            c.execute("DELETE FROM marketplace WHERE id = ?", (item_id,))
            conn.commit()

        return True, self._row_to_item(row)

    # Adicione no traderepo.py (ou game/traderepo.py)

    # === SUBSTITUA ESTAS FUNÇÕES NO FINAL DO SEU trade_repo.py ===

    def get_items_recent(self, page: int = 0, per_page: int = 10) -> Tuple[List[dict], int]:
        """Pega itens recentes do marketplace ordenados por listed_at"""
        now = int(time.time())
        # Mantemos a lógica original do banco que checa expiração em vez de 'status = listed'
        base = "FROM marketplace WHERE expires_at > ?"
        params: List[Any] = [now]

        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            
            # Conta o total
            c.execute(f"SELECT COUNT(*) {base}", params)
            total = c.fetchone()[0]

            # Pega a página atual
            offset = page * per_page
            atributo = ordem if ordem in ("atk", "def", "hp", "spd", "crit", "eva") else None

            if atributo:
                # Lê o lote (com teto), ordena pelo bônus em Python e só
                # então pagina. Ordenar depois de paginar ordenaria só a
                # página — que é o bug óbvio dessa funcionalidade.
                c.execute(f"SELECT * {base} ORDER BY listed_at DESC LIMIT ?",
                          params + [self.TETO_ORDEM_PYTHON])
            else:
                c.execute(
                    f"SELECT * {base} ORDER BY "
                    f"{self.ORDENS_SQL.get(ordem, self.ORDENS_SQL['recentes'])} "
                    f"LIMIT ? OFFSET ?",
                    params + [per_page, offset],
                )
            rows = c.fetchall()

        # Converte pro dicionário padrão do jogo
        items = [self._row_to_item(r) for r in rows]
        return items, total

    def get_all_items(self) -> List[dict]:
        """Fallback: todos itens listados que não expiraram"""
        now = int(time.time())
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute(
                "SELECT * FROM marketplace WHERE expires_at > ? ORDER BY listed_at DESC", 
                (now,)
            )
            rows = c.fetchall()
            
        return [self._row_to_item(r) for r in rows]

# Cria a instância global no final do arquivo
trade_repo = TradeRepo()
