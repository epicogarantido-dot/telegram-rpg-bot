# game/sql_repo.py - V5 (Assíncrono de Alta Performance)

import aiosqlite
import json
import os
import random
from game.items import SLOTS

from infra.migracao import garantir_colunas, garantir_colunas_async

# 🧱 20/09/2026 — os CREATE deste arquivo viraram constantes pra que a
# MESMA string crie a tabela e migre banco velho (infra/migracao.py).
# Coluna nova entra aqui e chega sozinha em quem já tinha a tabela.
_SQL_SKILLS = """
        CREATE TABLE IF NOT EXISTS skills (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER NOT NULL,
            skill_id TEXT NOT NULL,
            level INTEGER DEFAULT 1,
            skill_data TEXT,
            is_equipped BOOLEAN DEFAULT 0,
            equip_type TEXT,
            equip_index INTEGER,
            FOREIGN KEY(telegram_id) REFERENCES players(telegram_id) ON DELETE CASCADE
        )
        """
_SQL_ITEMS = """
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER NOT NULL,
            item_key TEXT NOT NULL,
            quantity INTEGER DEFAULT 1,
            item_type TEXT NOT NULL,
            is_equipped BOOLEAN DEFAULT 0,
            equip_slot TEXT,
            item_data TEXT,
            FOREIGN KEY(telegram_id) REFERENCES players(telegram_id) ON DELETE CASCADE
        )
        """
_SQL_PET_ARENA_SNAPSHOTS = """
        CREATE TABLE IF NOT EXISTS pet_arena_snapshots (
            telegram_id INTEGER PRIMARY KEY,
            username TEXT DEFAULT '',
            team_json TEXT DEFAULT '[]',
            arena_points REAL DEFAULT 0,
            wins INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0,
            updated_at INTEGER DEFAULT 0,
            FOREIGN KEY(telegram_id) REFERENCES players(telegram_id) ON DELETE CASCADE
        )
        """
_SQL_ARENA_SNAPSHOTS = """
        CREATE TABLE IF NOT EXISTS arena_snapshots (
            telegram_id INTEGER PRIMARY KEY,
            username TEXT DEFAULT '',
            level INTEGER DEFAULT 1,
            atk INTEGER DEFAULT 5,
            def INTEGER DEFAULT 0,
            hp_max INTEGER DEFAULT 100,
            crit INTEGER DEFAULT 0,
            eva INTEGER DEFAULT 0,
            acc INTEGER DEFAULT 0,
            spd INTEGER DEFAULT 20,
            triggers_json TEXT DEFAULT '{}',
            skills_json TEXT DEFAULT '[]',
            arena_points REAL DEFAULT 0,
            wins INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0,
            updated_at INTEGER DEFAULT 0,
            FOREIGN KEY(telegram_id) REFERENCES players(telegram_id) ON DELETE CASCADE
        )
        """
# 🤖 (26/09/2026) coisas da CONTA (não do personagem): a Autobatalha
_SQL_CONTA = """
CREATE TABLE IF NOT EXISTS conta (
    telegram_id INTEGER PRIMARY KEY,
    autobattle_until INTEGER DEFAULT 0
)
"""

_SQL_PLAYERS = """
        CREATE TABLE IF NOT EXISTS players (
            telegram_id INTEGER PRIMARY KEY,
            short_id INTEGER UNIQUE,
            username TEXT DEFAULT '',
            premium INTEGER DEFAULT 0,
            state TEXT DEFAULT 'CITY',
            level INTEGER DEFAULT 1,
            xp INTEGER DEFAULT 0,
            xp_next INTEGER DEFAULT 100,
            gold INTEGER DEFAULT 1000,
            tower_floor INTEGER DEFAULT 1,
            hp INTEGER DEFAULT 100,
            hp_max INTEGER DEFAULT 100,
            trail_points INTEGER DEFAULT 0,
            class_id TEXT,
            race_id TEXT,
            specialty_id TEXT,
            attrs TEXT,
            trails TEXT,
            combat TEXT,
            vip_until INTEGER DEFAULT 0,
            last_update INTEGER DEFAULT 0,
            raid_room_id TEXT
        )
        """


DB_PATH = "data/game.db"

async def init_db():
    os.makedirs("data", exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON;")
        await db.execute("PRAGMA journal_mode=WAL;")
        
        # Tabela Players
        await db.execute(_SQL_PLAYERS)
        await garantir_colunas_async(db, _SQL_PLAYERS)  # 🧱 migra o que o CREATE tem e o disco não
        await db.execute(_SQL_CONTA)
        await garantir_colunas_async(db, _SQL_CONTA)

        # SISTEMA DE MIGRAÇÃO AUTOMÁTICA
        async with db.execute("PRAGMA table_info(players)") as cursor:
            rows = await cursor.fetchall()
            cols = [r['name'] for r in rows]

        migrations = {
            'vip_until': "ALTER TABLE players ADD COLUMN vip_until INTEGER DEFAULT 0",
            'race_id': "ALTER TABLE players ADD COLUMN race_id TEXT",
            'specialty_id': "ALTER TABLE players ADD COLUMN specialty_id TEXT",
            'raid_room_id': "ALTER TABLE players ADD COLUMN raid_room_id TEXT",
            'pets': "ALTER TABLE players ADD COLUMN pets TEXT DEFAULT '{}'", # <--- NOVO AQUI
            # 🔥 Corrigido (07/07/2026): chakra, limite de drop diário e outros
            # campos "soltos" do dicionário do jogador nunca eram salvos no banco
            # (só existiam em memória) — a cada load fresco do banco, sumiam e
            # o ensure_player sorteava um chakra NOVO sem querer. Agora tudo
            # isso vai dentro de extra_data.
            'extra_data': "ALTER TABLE players ADD COLUMN extra_data TEXT DEFAULT '{}'",
        }

        for col, sql in migrations.items():
            if col not in cols:
                try:
                    await db.execute(sql)
                except Exception as e:
                    print(f"Erro migração {col}: {e}")

        # 🔥 Tabela da Arena PvP: guarda uma "cópia" (snapshot) de cada jogador
        # cadastrado, atualizada no máximo 1x por dia. As lutas acontecem
        # contra essa cópia (não contra o jogador ao vivo).
        await db.execute(_SQL_ARENA_SNAPSHOTS)
        await garantir_colunas_async(db, _SQL_ARENA_SNAPSHOTS)  # 🧱 migra o que o CREATE tem e o disco não

        # 🔥 Migração pra quem já tinha arena_snapshots sem a coluna skills_json
        # (Arena virou combate interativo com skills — 08/07/2026)
        async with db.execute("PRAGMA table_info(arena_snapshots)") as cursor:
            arena_cols = [r['name'] for r in await cursor.fetchall()]
        if 'skills_json' not in arena_cols:
            try:
                await db.execute("ALTER TABLE arena_snapshots ADD COLUMN skills_json TEXT DEFAULT '[]'")
            except Exception as e:
                print(f"Erro migração skills_json (arena): {e}")

        # 🐾 Tabela Arena dos Pets (09/07/2026): guarda o time de 5 pets
        # (já com stats derivados) como snapshot, igual a arena de
        # personagens — atualiza no cadastro e a cada 24h.
        await db.execute(_SQL_PET_ARENA_SNAPSHOTS)
        await garantir_colunas_async(db, _SQL_PET_ARENA_SNAPSHOTS)  # 🧱 migra o que o CREATE tem e o disco não

        # Tabela Itens
        await db.execute(_SQL_ITEMS)
        await garantir_colunas_async(db, _SQL_ITEMS)  # 🧱 migra o que o CREATE tem e o disco não
        
        # Tabela Skills
        await db.execute(_SQL_SKILLS)
        await garantir_colunas_async(db, _SQL_SKILLS)  # 🧱 migra o que o CREATE tem e o disco não

        # 🚀 ÍNDICES (11/09/2026): 'items' e 'skills' são consultadas E apagadas
        # por telegram_id em TODO load_player e TODO save_player_sql. Sem índice,
        # cada uma dessas chamadas varria a tabela inteira — ou seja, o custo
        # crescia com o total de itens do JOGO, não com os itens do jogador.
        # Medido com 1.500 jogadores / 57.350 linhas em items:
        #     load_player      7,01 ms -> 0,51 ms  (13,5x)
        #     save_player_sql  8,18 ms -> 1,63 ms  (5,0x)
        # E, o que mais importa: com índice o custo para de crescer.
        # As outras tabelas já têm telegram_id como PRIMARY KEY (índice implícito).
        await db.execute("CREATE INDEX IF NOT EXISTS idx_items_telegram_id ON items(telegram_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_skills_telegram_id ON skills(telegram_id)")

        await db.commit()

async def load_player_async(telegram_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM players WHERE telegram_id = ?", (telegram_id,)) as cursor:
            row = await cursor.fetchone()
            
        if not row: return None
        
        p = dict(row)
        # Converte JSONs de volta para dicts
        for field in ["attrs", "trails", "combat", "pets"]: # <--- ADICIONAMOS PETS AQUI
            try:
                p[field] = json.loads(row[field]) if row[field] else {}
            except:
                p[field] = {} if field != "combat" else None

        # 🔥 extra_data: campos soltos que não têm coluna própria (chakra, limite
        # diário de drop, etc). Sem isso eles sumiam a cada load fresco do banco.
        try:
            row_keys = row.keys()
            extra = json.loads(row["extra_data"]) if "extra_data" in row_keys and row["extra_data"] else {}
        except Exception:
            extra = {}
        for k, v in extra.items():
            p[k] = v

        # Garante a estrutura base dos pets caso seja um player novo ou antigo
        if not p.get("pets") or not isinstance(p.get("pets"), dict):
            p["pets"] = {"owned": {}, "deck": [None]*5}
        elif "deck" not in p["pets"]:
            p["pets"]["deck"] = [None]*5

        # Estrutura de inventário para o motor do jogo
        p["inv"] = {"potion": 0, "cores": {}, "items": {s: [] for s in SLOTS}}
        p["equip"] = {s: None for s in SLOTS}
        
        # Carrega itens
        async with db.execute("SELECT * FROM items WHERE telegram_id = ?", (telegram_id,)) as cursor:
            items_rows = await cursor.fetchall()
            for it in items_rows:
                if it["item_type"] == "potion": p["inv"]["potion"] = it["quantity"]
                elif it["item_type"] == "core": p["inv"]["cores"][it["item_key"]] = it["quantity"]
                elif it["item_type"] == "equipment":
                    data = json.loads(it["item_data"])
                    if it["is_equipped"]: p["equip"][it["equip_slot"]] = data
                    else: p["inv"]["items"][it["equip_slot"]].append(data)
        # --- (Adicione este bloco logo antes do 'return p' no load_player_async) ---
        
        # 5. Carregar Skills
        p["skills_learned"] = {}
        p["skill_slots"] = {"equipped": [None] * 5}
        
        async with db.execute("SELECT * FROM skills WHERE telegram_id = ?", (telegram_id,)) as cursor:
            skills_rows = await cursor.fetchall()
            for sk in skills_rows:
                skid = sk["skill_id"]
                sk_data = json.loads(sk["skill_data"]) if sk["skill_data"] else {}
                sk_data["level"] = sk["level"]
                p["skills_learned"][skid] = sk_data
                
                if sk["is_equipped"]:
                    eq_type = sk["equip_type"]
                    eq_idx = sk["equip_index"]
                    if eq_type in p["skill_slots"] and 0 <= eq_idx < 5:
                        p["skill_slots"][eq_type][eq_idx] = skid
                        
        return p # (O return p já deve estar aí, é só pra você se guiar)
        
        
        
        return p

# =============================================================================
# 🗃️ O QUE O SAVE GRAVA ALÉM DAS COLUNAS
# =============================================================================
# Campo do jogador que não tem coluna própria só sobrevive se estiver AQUI.
# Fora desta lista, save_player_sql descarta em silêncio: sem erro, sem
# aviso, e o jogo funciona até o próximo carregamento.
#
# ⚠️ Esta lista existia DUAS VEZES, copiada no save síncrono e no
# assíncrono. Duas cópias mantidas à mão é a quinta mordida esperando
# acontecer — bastava alguém acrescentar num lado. Agora é uma só.
#
# Ela já mordeu quatro vezes:
#   - pending_orders / conta_em_analise: o pedido de ⭐ sumia e o comprovante
#     não achava pedido nenhum;
#   - conta_bloqueada: o admin bloqueava e o bloqueio evaporava no reinício;
#   - daily_login_date: recompensa diária infinita, porque nunca era "hoje";
#   - tower_choice: subir andar não fazia nada, porque /api/tower/advance
#     recarrega do banco pra decidir.
#
# testar_estado_jogador.py grava e relê de verdade. Ler o código não pega
# este bug: o código parece certo dos dois lados.
CAMPOS_EXTRAS = {"origem_aldeao",   # ✨ 28/09: personagem que nasceu de um aldeão desperto
                 "skill_inicial",   # ✨ 28/09: habilidade escolhida na criação (uma vez só)
                 "chefes_vencidos", "ultima_derrota",   # 👑🔎 28/09: portal do chefe do novato e tela de morte
                 "chakra", "daily_drop_limit", "mount_equipped", "mounts_owned", "tutorial_seen", "tut_seen", "msg_id", "autobattle_until", "wave_last_played", "missions_claimed", "last_free_revive", "arena_combat", "pet_arena_combat",
                         # 🧾 11/09/2026 — ESTES DOIS NUNCA ERAM GRAVADOS.
                         # Não têm coluna própria e não estavam nesta lista, então
                         # save_player_sql os descartava em silêncio. Só existiam no
                         # cache em memória — e a Square Cloud reinicia o processo a
                         # cada commit. Efeitos reais:
                         #   - o pedido de ⭐ sumia, e ao mandar o comprovante o
                         #     jogador ouvia "você não tem pedido pendente";
                         #   - conta_em_analise, que bloqueia Arena/Raid/Mercado até
                         #     o admin conferir o Pix, se DESFAZIA sozinho no
                         #     reinício — pagamento não confirmado, trava liberada.
                         # Achado ao migrar o Pix pro site: sem persistir isso, não
                         # existe painel de admin possível.
                         "pending_orders", "conta_em_analise",
                         # conta_bloqueada tinha o MESMO problema: o admin
                         # bloqueava a conta e o bloqueio evaporava no reinício.
                         "conta_bloqueada",
                         # 📜 storylets: turno, qualidades, flags, cooldowns,
                         # agenda e log de causa vivem num campo só. Fora desta
                         # lista, some a cada reinício — exatamente o que
                         # aconteceu com pending_orders e conta_bloqueada.
                         "storylets",
                         # 🕳️ 18/09/2026 — A QUARTA VEZ que esta lista morde, e a
                         # que causou dois bugs relatados de uma vez:
                         #
                         #   - RECOMPENSA DIÁRIA INFINITA. claim_daily_reward
                         #     grava daily_login_date e recusa se for hoje. Só
                         #     que o campo era descartado no save: todo reload o
                         #     jogador voltava sem data e podia pegar de novo,
                         #     pra sempre, acumulando ouro e XP.
                         #   - SUBIR ANDAR NÃO FUNCIONAVA. A vitória marca
                         #     tower_choice, o front mostra "Avançar ou ficar",
                         #     e /api/tower/advance recarrega do banco pra
                         #     decidir. Sem o campo, o `if` falhava em silêncio:
                         #     o botão respondia e o andar não subia.
                         #
                         # A varredura que achou esses dois achou o resto junto.
                         # Todos são lidos por p.get() em OUTRA requisição, que
                         # é a definição de estado que precisa sobreviver:
                         "daily_login_date", "daily_streak", "last_daily",
                         "tower_choice", "tower_mode", "torre_encontro",
                         # explore_state guarda saved_tower_floor — é a
                         # armadilha nº 5 do projeto, e ela dependia de um campo
                         # que não era gravado.
                         "explore_mode", "explore_state",
                         # wave_recorde é RECORDE: sumia a cada save.
                         "wave_mode", "wave_state", "wave_recorde",
                         "raid_floor", "raid_ready", "raid_target",
                         "global_boss_session",
                         "specialties", "almas", "skill_cooldowns",
                         # do bot: engaste de gema acontece em duas mensagens,
                         # e o alvo escolhido na primeira sumia antes da segunda.
                         "socket_temp", "craft",
                         # 🧍 20/09/2026 — o sexo do personagem, que escolhe a
                         # arte da ficha junto com a raça. Entra AQUI porque
                         # fora desta lista o save descarta em silêncio e o
                         # jogador voltaria pra arte genérica a cada reinício
                         # (armadilha nº 4, quinta vez que ela morde).
                         "sexo",
                         # ⛏️ 20/09/2026 — material que o PERSONAGEM ganha
                         # matando monstro na Torre ({rank: qtd}). A Forja
                         # gasta daqui primeiro e depois do estoque do clã.
                         # Fora desta lista, o save descartaria em silêncio
                         # (armadilha nº 4).
                         "materiais_torre",
                         # 🧭 o andar mais fundo que o jogador já alcançou na
                         # Torre: a travessia do clã só vai até onde ele chegou.
                         "andar_max",
                         # ⚔️ personagem de guarda no clã (sem Torre enquanto isso)
                         "de_guarda",
                         "ultima_acao",   # (26/09) p/ o idle automático (20 min sem jogar)
                         # 📅 missões diárias (progresso e resgates de hoje)
                         "diarias"}

async def save_player_sql_async(telegram_id: int, p: dict) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        # 🚀 (08/07/2026): esta é a escrita mais quente do jogo — roda a cada
        # ação de cada jogador. synchronous=NORMAL corta o fsync por commit
        # (o maior custo), e é o modo recomendado junto do WAL: no pior caso
        # perde só a última transação num corte de energia, nunca corrompe.
        await db.execute("PRAGMA synchronous=NORMAL;")
        await db.execute("PRAGMA busy_timeout=5000;")
        _extra_fields = CAMPOS_EXTRAS
        extra_data = {k: p[k] for k in _extra_fields if k in p}

        sql = """
        INSERT INTO players (
            telegram_id, short_id, username, premium, state, level, xp, xp_next, gold, 
            tower_floor, hp, hp_max, trail_points, class_id, race_id, specialty_id, 
            attrs, trails, combat, last_update, vip_until, raid_room_id, pets,
            extra_data
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(telegram_id) DO UPDATE SET 
            username=excluded.username, premium=excluded.premium, state=excluded.state, 
            level=excluded.level, xp=excluded.xp, xp_next=excluded.xp_next, gold=excluded.gold, 
            tower_floor=excluded.tower_floor, hp=excluded.hp, hp_max=excluded.hp_max, 
            trail_points=excluded.trail_points, class_id=excluded.class_id, 
            race_id=excluded.race_id, specialty_id=excluded.specialty_id,
            attrs=excluded.attrs, trails=excluded.trails, combat=excluded.combat, 
            last_update=excluded.last_update, vip_until=excluded.vip_until,
            raid_room_id=excluded.raid_room_id, pets=excluded.pets,
            extra_data=excluded.extra_data
        """
        
        await db.execute(sql, (
            telegram_id, p.get('short_id'), p.get('username', ''),
            p.get('premium', 0), p.get('state', 'CITY'), p.get('level', 1),
            p.get('xp', 0), p.get('xp_next', 100), p.get('gold', 0),
            p.get('tower_floor', 1), p.get('hp', 100), p.get('hp_max', 100),
            p.get('trail_points', 0), p.get('class_id'), p.get('race_id'), p.get('specialty_id'),
            json.dumps(p.get('attrs', {})), json.dumps(p.get('trails', {})),
            json.dumps(p.get('combat')), p.get('last_update', 0), p.get('vip_until', 0),
            p.get('raid_room_id'), json.dumps(p.get('pets', {})), # <--- DUMPS DOS PETS AQUI NO FINAL
            json.dumps(extra_data)
        ))

        # Limpa os itens antigos do banco para regravar o inventário atualizado
        await db.execute("DELETE FROM items WHERE telegram_id = ?", (telegram_id,))
        
        # 1. Salvar Poções
        potion_qty = p.get("inv", {}).get("potion", 0)
        if potion_qty > 0:
            await db.execute("INSERT INTO items (telegram_id, item_key, quantity, item_type) VALUES (?, ?, ?, ?)",
                      (telegram_id, "potion", potion_qty, "potion"))
                      
        # 2. Salvar Cores (Gemas)
        cores = p.get("inv", {}).get("cores", {})
        for cid, qty in cores.items():
            if qty > 0:
                await db.execute("INSERT INTO items (telegram_id, item_key, quantity, item_type) VALUES (?, ?, ?, ?)",
                          (telegram_id, cid, qty, "core"))
                          
        # 3. Salvar Equipamentos Equipados
        equip = p.get("equip", {})
        for slot, item_data in equip.items():
            if item_data:
                await db.execute("INSERT INTO items (telegram_id, item_key, quantity, item_type, is_equipped, equip_slot, item_data) VALUES (?, ?, ?, ?, ?, ?, ?)",
                          (telegram_id, item_data.get("id", "eq"), 1, "equipment", 1, slot, json.dumps(item_data)))
                          
        # 4. Salvar Equipamentos na Mochila
        inv_items = p.get("inv", {}).get("items", {})
        for slot, items_list in inv_items.items():
            for item_data in items_list:
                await db.execute("INSERT INTO items (telegram_id, item_key, quantity, item_type, is_equipped, equip_slot, item_data) VALUES (?, ?, ?, ?, ?, ?, ?)",
                          (telegram_id, item_data.get("id", "inv"), 1, "equipment", 0, slot, json.dumps(item_data)))
                          
        # --- (Adicione este bloco antes do 'await db.commit()' no save_player_sql_async) ---

        # 5. Salvar Skills
        await db.execute("DELETE FROM skills WHERE telegram_id = ?", (telegram_id,))
        
        learned = p.get("skills_learned", {})
        slots = p.get("skill_slots", {"equipped": [None] * 5})
        
        # Cria um mapa de slots para saber qual skill está equipada
        equipped_map = {}
        for stype in ["equipped"]:
            for idx, skid in enumerate(slots.get(stype, [])):
                if skid:
                    equipped_map[skid] = (stype, idx)
                    
        for skid, skdata in learned.items():
            lvl = skdata.get("level", 1)
            is_eq = 1 if skid in equipped_map else 0
            eq_type = equipped_map.get(skid, (None, None))[0]
            eq_idx = equipped_map.get(skid, (None, None))[1]
            
            await db.execute("""
                INSERT INTO skills (telegram_id, skill_id, level, skill_data, is_equipped, equip_type, equip_index)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (telegram_id, skid, lvl, json.dumps(skdata), is_eq, eq_type, eq_idx))

        await db.commit() # (O db.commit já deve estar aí)
        return True        
        
        await db.commit()
        return True

async def save_player_raid(p: dict):
    tid = p.get("telegram_id")
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            UPDATE players SET
                username = ?, level = ?, xp = ?, 
                hp = ?, hp_max = ?, gold = ?, 
                tower_floor = ?, state = ?, raid_room_id = ?
            WHERE telegram_id = ?
        """, (
            p.get("username"), p.get("level", 1), p.get("xp", 0),
            p.get("hp", 100), p.get("hp_max", 100), p.get("gold", 0),
            p.get("tower_floor", 1), p.get("state", "CITY"), 
            p.get("raid_room_id"), tid
        ))
        await db.commit()

async def get_ranking_floors(limit: int = 10):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT telegram_id, username, tower_floor
            FROM players
            WHERE tower_floor IS NOT NULL AND tower_floor > 0
            ORDER BY tower_floor DESC, telegram_id ASC
            LIMIT ?
        """, (int(limit),)) as cursor:
            rows = await cursor.fetchall()
            return [
                (str(r["telegram_id"]), int(r["telegram_id"]), r["username"] or "Jogador", int(r["tower_floor"]))
                for r in rows
            ]

async def generate_unique_id() -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        while True:
            nid = random.randint(100000, 999999)
            async with db.execute("SELECT 1 FROM players WHERE short_id = ?", (nid,)) as cursor:
                if not await cursor.fetchone():
                    return nid

async def get_real_premium(telegram_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT premium FROM players WHERE telegram_id = ?", (telegram_id,)) as cursor:
            res = await cursor.fetchone()
            return res[0] if res else 0

async def add_real_premium(telegram_id: int, amount: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE players SET premium = premium + ? WHERE telegram_id = ?", (amount, telegram_id))
        await db.commit()

async def get_floors_count() -> dict[int, int]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT tower_floor, COUNT(*) as count
            FROM players 
            WHERE tower_floor IS NOT NULL AND tower_floor > 0
            GROUP BY tower_floor
            ORDER BY tower_floor DESC
        """) as cursor:
            rows = await cursor.fetchall()
            return {int(r["tower_floor"]): r["count"] for r in rows}




# ==========================================================
# 🌉 PONTE SÍNCRONA (LEGACY) PARA RAID, TRADE E PREMIUM
# ==========================================================
import sqlite3

# ⚠️ 11/09/2026 — havia DUAS cópias idênticas de DBConnectionSync +
# get_connection neste arquivo. Em Python a segunda definição apaga a
# primeira, então esta aqui nunca rodava: qualquer ajuste feito nela
# não teria efeito nenhum, e ninguém perceberia. Removida.
# ==========================================================
# 🌉 PONTE SÍNCRONA (LEGACY) PARA ROUTER, LOGIC, RAID E TRADE
# ==========================================================
import sqlite3

class DBConnectionSync:
    def __init__(self):
        self.conn = None
    
    def __enter__(self):
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=10)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON;")
        self.conn.execute("PRAGMA journal_mode=WAL;")
        # 🚀 (08/07/2026): PRAGMAs de performance. synchronous=NORMAL é o
        # par recomendado do WAL — some com o fsync a cada commit (o maior
        # custo de escrita), arriscando no MÁXIMO perder a última transação
        # num corte de energia, nunca corromper o banco. busy_timeout evita
        # "database is locked" quando várias escritas concorrem.
        self.conn.execute("PRAGMA synchronous=NORMAL;")
        self.conn.execute("PRAGMA busy_timeout=5000;")
        self.conn.execute("PRAGMA cache_size=-8000;")  # ~8MB de cache de páginas
        return self.conn
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.conn:
            self.conn.close()
        return False

def get_connection():
    return DBConnectionSync()

def load_player(telegram_id: int):
    """Versão Síncrona para uso no router.py e logic.py"""
    with get_connection() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM players WHERE telegram_id = ?", (telegram_id,))
        row = c.fetchone()
        
        if not row: return None
        
        p = dict(row)
        for field in ["attrs", "trails", "combat", "pets"]: # <--- ADICIONAMOS PETS AQUI
            try:
                p[field] = json.loads(row[field]) if row[field] else {}
            except:
                p[field] = {} if field != "combat" else None

        # 🔥 extra_data: campos soltos que não têm coluna própria (chakra, limite
        # diário de drop, etc). Sem isso eles sumiam a cada load fresco do banco.
        try:
            row_keys = row.keys()
            extra = json.loads(row["extra_data"]) if "extra_data" in row_keys and row["extra_data"] else {}
        except Exception:
            extra = {}
        for k, v in extra.items():
            p[k] = v

        # Garante a estrutura base dos pets
        if not p.get("pets") or not isinstance(p.get("pets"), dict):
            p["pets"] = {"owned": {}, "deck": [None]*5}
        elif "deck" not in p["pets"]:
            p["pets"]["deck"] = [None]*5
        p["inv"] = {"potion": 0, "cores": {}, "items": {s: [] for s in SLOTS}}
        p["equip"] = {s: None for s in SLOTS}
        
        c.execute("SELECT * FROM items WHERE telegram_id = ?", (telegram_id,))
        for it in c.fetchall():
            if it["item_type"] == "potion": p["inv"]["potion"] = it["quantity"]
            elif it["item_type"] == "core": p["inv"]["cores"][it["item_key"]] = it["quantity"]
            elif it["item_type"] == "equipment":
                data = json.loads(it["item_data"])
                if it["is_equipped"]: p["equip"][it["equip_slot"]] = data
                else: p["inv"]["items"][it["equip_slot"]].append(data)

        # 🔥 CORRIGIDO (09/07/2026): faltava esse bloco aqui também — o
        # mesmo bug do lado da escrita (save_player_sql) existia na leitura.
        # Sem isso, load_player devolvia o jogador SEM skills_learned nem
        # skill_slots nenhum, mesmo que estivessem salvos no banco.
        p["skills_learned"] = {}
        p["skill_slots"] = {"equipped": [None] * 5}

        c.execute("SELECT * FROM skills WHERE telegram_id = ?", (telegram_id,))
        for sk in c.fetchall():
            skid = sk["skill_id"]
            sk_data = json.loads(sk["skill_data"]) if sk["skill_data"] else {}
            sk_data["level"] = sk["level"]
            p["skills_learned"][skid] = sk_data

            if sk["is_equipped"]:
                eq_type = sk["equip_type"]
                eq_idx = sk["equip_index"]
                if eq_type in p["skill_slots"] and eq_idx is not None and 0 <= eq_idx < 5:
                    p["skill_slots"][eq_type][eq_idx] = skid

        return p

def save_player_sql(telegram_id: int, p: dict) -> bool:
    """Versão Síncrona para uso no router.py e logic.py"""
    with get_connection() as conn:
        c = conn.cursor()
        # 🔥 Campos soltos que não têm coluna própria (chakra, limite diário de
        # drop, etc) — tudo isso ia embora a cada save antes dessa correção.
        _extra_fields = CAMPOS_EXTRAS
        extra_data = {k: p[k] for k in _extra_fields if k in p}

        sql = """
        INSERT INTO players (
            telegram_id, short_id, username, premium, state, level, xp, xp_next, gold, 
            tower_floor, hp, hp_max, trail_points, class_id, race_id, specialty_id, 
            attrs, trails, combat, last_update, vip_until, raid_room_id, pets,
            extra_data
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(telegram_id) DO UPDATE SET 
            username=excluded.username, premium=excluded.premium, state=excluded.state, 
            level=excluded.level, xp=excluded.xp, xp_next=excluded.xp_next, gold=excluded.gold, 
            tower_floor=excluded.tower_floor, hp=excluded.hp, hp_max=excluded.hp_max, 
            trail_points=excluded.trail_points, class_id=excluded.class_id, 
            race_id=excluded.race_id, specialty_id=excluded.specialty_id,
            attrs=excluded.attrs, trails=excluded.trails, combat=excluded.combat, 
            last_update=excluded.last_update, vip_until=excluded.vip_until,
            raid_room_id=excluded.raid_room_id, pets=excluded.pets,
            extra_data=excluded.extra_data
        """
        c.execute(sql, (
            telegram_id, p.get('short_id'), p.get('username', ''),
            p.get('premium', 0), p.get('state', 'CITY'), p.get('level', 1),
            p.get('xp', 0), p.get('xp_next', 100), p.get('gold', 0),
            p.get('tower_floor', 1), p.get('hp', 100), p.get('hp_max', 100),
            p.get('trail_points', 0), p.get('class_id'), p.get('race_id'), p.get('specialty_id'),
            json.dumps(p.get('attrs', {})), json.dumps(p.get('trails', {})),
            json.dumps(p.get('combat')), p.get('last_update', 0), p.get('vip_until', 0),
            p.get('raid_room_id'), json.dumps(p.get('pets', {})), # <--- DUMPS DOS PETS AQUI NO FINAL
            json.dumps(extra_data)
        ))

        c.execute("DELETE FROM items WHERE telegram_id = ?", (telegram_id,))
        
        potion_qty = p.get("inv", {}).get("potion", 0)
        if potion_qty > 0:
            c.execute("INSERT INTO items (telegram_id, item_key, quantity, item_type) VALUES (?, ?, ?, ?)",
                      (telegram_id, "potion", potion_qty, "potion"))
                      
        cores = p.get("inv", {}).get("cores", {})
        for cid, qty in cores.items():
            if qty > 0:
                c.execute("INSERT INTO items (telegram_id, item_key, quantity, item_type) VALUES (?, ?, ?, ?)",
                          (telegram_id, cid, qty, "core"))
                          
        equip = p.get("equip", {})
        for slot, item_data in equip.items():
            if item_data:
                c.execute("INSERT INTO items (telegram_id, item_key, quantity, item_type, is_equipped, equip_slot, item_data) VALUES (?, ?, ?, ?, ?, ?, ?)",
                          (telegram_id, item_data.get("id", "eq"), 1, "equipment", 1, slot, json.dumps(item_data)))
                          
        inv_items = p.get("inv", {}).get("items", {})
        for slot, items_list in inv_items.items():
            for item_data in items_list:
                c.execute("INSERT INTO items (telegram_id, item_key, quantity, item_type, is_equipped, equip_slot, item_data) VALUES (?, ?, ?, ?, ?, ?, ?)",
                          (telegram_id, item_data.get("id", "inv"), 1, "equipment", 0, slot, json.dumps(item_data)))

        # 🔥 CORRIGIDO (09/07/2026): faltava esse bloco aqui — a versão
        # ASSÍNCRONA (save_player_sql_async) já salvava skills corretamente,
        # mas essa versão SÍNCRONA nunca teve o bloco equivalente. Skills
        # aprendidas/equipadas eram silenciosamente perdidas em qualquer
        # fluxo que salvasse por aqui (21 pontos no jogo, incluindo salvar
        # outros jogadores numa raid) — o mesmo padrão de "duas funções
        # gêmeas divergindo" que já apareceu antes no projeto.
        c.execute("DELETE FROM skills WHERE telegram_id = ?", (telegram_id,))

        learned = p.get("skills_learned", {})
        slots_sk = p.get("skill_slots", {"equipped": [None] * 5})

        equipped_map = {}
        for stype in ["equipped"]:
            for idx, skid in enumerate(slots_sk.get(stype, [])):
                if skid:
                    equipped_map[skid] = (stype, idx)

        for skid, skdata in learned.items():
            lvl = skdata.get("level", 1)
            is_eq = 1 if skid in equipped_map else 0
            eq_type = equipped_map.get(skid, (None, None))[0]
            eq_idx = equipped_map.get(skid, (None, None))[1]
            c.execute("""
                INSERT INTO skills (telegram_id, skill_id, level, skill_data, is_equipped, equip_type, equip_index)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (telegram_id, skid, lvl, json.dumps(skdata), is_eq, eq_type, eq_idx))

        conn.commit()
        return True
def get_floors_count() -> dict[int, int]:
    """Versão Síncrona para o Ranking no views.py"""
    with get_connection() as conn:
        c = conn.cursor()
        c.execute("""
            SELECT tower_floor, COUNT(*) as count
            FROM players 
            WHERE tower_floor IS NOT NULL AND tower_floor > 0
            GROUP BY tower_floor
            ORDER BY tower_floor DESC
        """)
        rows = c.fetchall()
        return {int(r["tower_floor"]): r["count"] for r in rows}
def get_ranking_floors_sync(limit: int = 10):
    """Versão síncrona para ser usada dentro das views.py"""
    import sqlite3
    
    # 🔥 Aponta para o banco de dados REAL do seu bot
    # Se o DB_PATH lá em cima for outro, substitua aqui. O padrão do seu código é "data/game.db"
    conn = sqlite3.connect("data/game.db") 
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    try:
        # Usa 'tower_floor' que é a coluna certa da sua tabela players!
        c.execute("""
            SELECT telegram_id, username, tower_floor 
            FROM players 
            WHERE tower_floor IS NOT NULL AND tower_floor > 0
            ORDER BY tower_floor DESC 
            LIMIT ?
        """, (limit,))
        
        rows = c.fetchall()
        
        # Monta a lista formatada para a View
        ranking = []
        for r in rows:
            ranking.append({
                "telegram_id": r["telegram_id"],
                "username": r["username"] or "Guerreiro Desconhecido",
                "floor": r["tower_floor"]
            })
            
        return ranking
    except Exception as e:
        print(f"Erro no ranking: {e}")
        return []
    finally:
        conn.close()
def get_ranking_gold_sync(limit: int = 10):
    """Busca os jogadores mais ricos do servidor."""
    import sqlite3
    
    # Mantendo o seu padrão de conexão direta
    conn = sqlite3.connect("data/game.db") 
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    try:
        # Filtra quem tem mais de 0 de ouro e ordena do maior pro menor
        c.execute("""
            SELECT telegram_id, username, gold 
            FROM players 
            WHERE gold IS NOT NULL AND gold > 0
            ORDER BY gold DESC 
            LIMIT ?
        """, (limit,))
        
        rows = c.fetchall()
        
        ranking = []
        for r in rows:
            ranking.append({
                "telegram_id": r["telegram_id"],
                "username": r["username"] or "Guerreiro Desconhecido",
                "gold": r["gold"]
            })
            
        return ranking
    except Exception as e:
        print(f"Erro no ranking de ouro: {e}")
        return []
    finally:
        conn.close()
def get_ranking_level_sync(limit: int = 10):
    """Busca os jogadores com maior nível (desempata por XP)."""
    import sqlite3
    
    conn = sqlite3.connect("data/game.db") 
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    try:
        # Ordena pelo nível e, em caso de empate, por XP
        c.execute("""
            SELECT telegram_id, username, level, xp 
            FROM players 
            WHERE level IS NOT NULL AND level > 0
            ORDER BY level DESC, xp DESC 
            LIMIT ?
        """, (limit,))
        
        rows = c.fetchall()
        
        ranking = []
        for r in rows:
            ranking.append({
                "telegram_id": r["telegram_id"],
                "username": r["username"] or "Guerreiro Desconhecido",
                "level": r["level"]
            })
            
        return ranking
    except Exception as e:
        print(f"Erro no ranking de nível: {e}")
        return []
    finally:
        conn.close()


def get_arena_snapshot_sync(telegram_id: int):
    """Busca a cópia (snapshot) cadastrada de um jogador na arena, se existir."""
    import sqlite3

    conn = sqlite3.connect("data/game.db")
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    try:
        c.execute("SELECT * FROM arena_snapshots WHERE telegram_id = ?", (telegram_id,))
        row = c.fetchone()
        return dict(row) if row else None
    except Exception as e:
        print(f"Erro ao buscar snapshot da arena: {e}")
        return None
    finally:
        conn.close()


def save_arena_snapshot_sync(telegram_id: int, dados: dict) -> None:
    """Cria ou atualiza (registro OU atualização diária) a cópia do jogador na arena.

    `dados` deve conter: username, level, atk, def, hp_max, crit, eva, acc, spd,
    triggers, skills, updated_at. Pontos/vitórias/derrotas só são setados se vier
    explicitamente (senão preserva o que já existia, via COALESCE)."""
    import sqlite3, json as _json

    conn = sqlite3.connect("data/game.db")
    c = conn.cursor()
    try:
        c.execute("""
            INSERT INTO arena_snapshots (
                telegram_id, username, level, atk, def, hp_max, crit, eva, acc, spd,
                triggers_json, skills_json, arena_points, wins, losses, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(telegram_id) DO UPDATE SET
                username=excluded.username, level=excluded.level, atk=excluded.atk,
                def=excluded.def, hp_max=excluded.hp_max, crit=excluded.crit,
                eva=excluded.eva, acc=excluded.acc, spd=excluded.spd,
                triggers_json=excluded.triggers_json, skills_json=excluded.skills_json,
                updated_at=excluded.updated_at
        """, (
            telegram_id, dados.get("username", ""), dados.get("level", 1),
            dados.get("atk", 5), dados.get("def", 0), dados.get("hp_max", 100),
            dados.get("crit", 0), dados.get("eva", 0), dados.get("acc", 0), dados.get("spd", 20),
            _json.dumps(dados.get("triggers", {})), _json.dumps(dados.get("skills", [])),
            0, 0, 0, dados.get("updated_at", 0)
        ))
        conn.commit()
    except Exception as e:
        print(f"Erro ao salvar snapshot da arena: {e}")
    finally:
        conn.close()


def update_arena_score_sync(telegram_id: int, novo_pontos: float, venceu: bool) -> None:
    import sqlite3

    conn = sqlite3.connect("data/game.db")
    c = conn.cursor()
    try:
        if venceu:
            c.execute("UPDATE arena_snapshots SET arena_points=?, wins=wins+1 WHERE telegram_id=?", (novo_pontos, telegram_id))
        else:
            c.execute("UPDATE arena_snapshots SET arena_points=?, losses=losses+1 WHERE telegram_id=?", (novo_pontos, telegram_id))
        conn.commit()
    except Exception as e:
        print(f"Erro ao atualizar pontuação da arena: {e}")
    finally:
        conn.close()


def get_arena_opponents_sync(telegram_id: int, my_points: float, limit: int = 3):
    """Busca oponentes cadastrados na Arena com pontuação entre
    (meus_pontos - 1) e (meus_pontos + 1). Se não achar ninguém (ex: primeiro
    jogador do servidor), o próprio chamador decide o que fazer (cai pra
    lutar contra si mesmo, conforme pedido)."""
    import sqlite3

    conn = sqlite3.connect("data/game.db")
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    try:
        c.execute("""
            SELECT * FROM arena_snapshots
            WHERE telegram_id != ? AND arena_points BETWEEN ? AND ?
            ORDER BY RANDOM()
            LIMIT ?
        """, (telegram_id, my_points - 1.0, my_points + 1.0, limit))
        return [dict(r) for r in c.fetchall()]
    except Exception as e:
        print(f"Erro ao buscar oponentes da arena: {e}")
        return []
    finally:
        conn.close()


def get_pet_arena_snapshot_sync(telegram_id: int):
    """Busca o time de pets cadastrado na Arena dos Pets, se existir."""
    import sqlite3

    conn = sqlite3.connect("data/game.db")
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    try:
        c.execute("SELECT * FROM pet_arena_snapshots WHERE telegram_id = ?", (telegram_id,))
        row = c.fetchone()
        return dict(row) if row else None
    except Exception as e:
        print(f"Erro ao buscar snapshot da arena de pets: {e}")
        return None
    finally:
        conn.close()


def save_pet_arena_snapshot_sync(telegram_id: int, username: str, team: list, updated_at: int) -> None:
    """Cria ou atualiza (cadastro OU refresh diário) o time de pets do
    jogador na Arena dos Pets. Pontos/vitórias/derrotas só são setados na
    criação (na atualização, preserva o que já existia)."""
    import sqlite3, json as _json

    conn = sqlite3.connect("data/game.db")
    c = conn.cursor()
    try:
        c.execute("""
            INSERT INTO pet_arena_snapshots (
                telegram_id, username, team_json, arena_points, wins, losses, updated_at
            ) VALUES (?, ?, ?, 0, 0, 0, ?)
            ON CONFLICT(telegram_id) DO UPDATE SET
                username=excluded.username, team_json=excluded.team_json,
                updated_at=excluded.updated_at
        """, (telegram_id, username, _json.dumps(team), updated_at))
        conn.commit()
    except Exception as e:
        print(f"Erro ao salvar snapshot da arena de pets: {e}")
    finally:
        conn.close()


def update_pet_arena_score_sync(telegram_id: int, delta_pontos: float, venceu: bool) -> None:
    """Atualiza pontos/vitórias/derrotas do jogador na Arena dos Pets."""
    import sqlite3

    conn = sqlite3.connect("data/game.db")
    c = conn.cursor()
    try:
        c.execute("""
            UPDATE pet_arena_snapshots
            SET arena_points = MAX(0, arena_points + ?),
                wins = wins + ?,
                losses = losses + ?
            WHERE telegram_id = ?
        """, (delta_pontos, 1 if venceu else 0, 0 if venceu else 1, telegram_id))
        conn.commit()
    except Exception as e:
        print(f"Erro ao atualizar pontuação da arena de pets: {e}")
    finally:
        conn.close()


def get_pet_arena_opponents_sync(telegram_id: int, my_points: float, limit: int = 3):
    """Busca oponentes cadastrados na Arena dos Pets com pontuação parecida
    com a minha (mesmo critério da arena de personagens)."""
    import sqlite3

    conn = sqlite3.connect("data/game.db")
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    try:
        c.execute("""
            SELECT * FROM pet_arena_snapshots
            WHERE telegram_id != ? AND arena_points BETWEEN ? AND ?
            ORDER BY RANDOM()
            LIMIT ?
        """, (telegram_id, my_points - 1.0, my_points + 1.0, limit))
        return [dict(r) for r in c.fetchall()]
    except Exception as e:
        print(f"Erro ao buscar oponentes da arena de pets: {e}")
        return []
    finally:
        conn.close()


def get_ranking_arena_sync(limit: int = 10):
    """Ranking da Arena por pontos (desempata por vitórias)."""
    import sqlite3

    conn = sqlite3.connect("data/game.db")
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    try:
        c.execute("""
            SELECT telegram_id, username, arena_points, wins, losses
            FROM arena_snapshots
            WHERE telegram_id NOT BETWEEN -999999 AND -900000   -- 🤖 bots fora do ranking/prêmio
            ORDER BY arena_points DESC, wins DESC
            LIMIT ?
        """, (limit,))
        return [dict(r) for r in c.fetchall()]
    except Exception as e:
        print(f"Erro no ranking da arena: {e}")
        return []
    finally:
        conn.close()


def reset_all_arena_points_sync() -> None:
    """Zera a pontuação (e vitórias/derrotas) de TODO MUNDO na Arena — usado
    no fechamento do ranking semanal, pra começar a semana seguinte do zero."""
    import sqlite3

    conn = sqlite3.connect("data/game.db")
    c = conn.cursor()
    try:
        # 🤖 os bots (faixa -999999..-900000) NÃO zeram: ficam espalhados
        # pelos pontos pra sempre ter adversário em toda faixa
        c.execute("UPDATE arena_snapshots SET arena_points=0, wins=0, losses=0"
                  " WHERE telegram_id NOT BETWEEN -999999 AND -900000")
        conn.commit()
    except Exception as e:
        print(f"Erro ao resetar pontos da arena: {e}")
    finally:
        conn.close()
