"""
Motor do AFK — o que acontece enquanto o jogador não está.

A IDEIA QUE FAZ ISSO SER BARATO
-------------------------------
Não se simula combate a cada tick. Simula-se UMA VEZ por (membro, área),
contra cada tipo de inimigo que sai lá, e guarda-se quem ele vence e quem
não vence. Depois disso o tick só rola dado contra a tabela.

E aí vem a parte que também deixa o número legível pro jogador:

    se ele só perde pro chefe, a chance de morrer É a chance de achar o chefe.

Não é uma porcentagem abstrata saída de uma fórmula — é a soma dos pesos de
encontro dos inimigos que ele não aguenta. Dá pra mostrar assim na tela:
"vence tudo menos o chefe; 8% de chance de esbarrar nele".

POR QUE O PERFIL PODE SER CALCULADO UMA VEZ SÓ
----------------------------------------------
Medido: o mesmo confronto dá o mesmo resultado em 8 de 8 sementes. O
combate da Torre é praticamente determinístico — se o ATK não passa da DEF,
ele nunca vence; se passa, quase nunca perde. Isso me atrapalhou quando
tentei tirar uma curva de risco dele, e aqui é justamente o que faz o
perfil valer: resultado estável é tabela confiável.

Custo medido: 38 a 188 ms pro perfil inteiro de uma área. Uma vez por
membro, refeito só quando ele sobe de nível, troca de equipamento ou muda
de área.

OS TRÊS RESULTADOS, NÃO DOIS
----------------------------
A simulação devolveu muito "empate" — luta que não resolve em 400 turnos,
por causa da zona morta de 1 de dano. Em vez de tratar como erro, virou
resultado: ele não conseguiu matar, mas também não morreu, então **recua**.
Volta de mãos vazias e talvez ferido. Sai de graça e é mais verdadeiro que
forçar vitória ou derrota.

E ELE NÃO ESTÁ SOZINHO
----------------------
Vários membros no mesmo posto lutam juntos. A regra: o grupo perde só se
NINGUÉM do grupo vence aquele inimigo. E quem cai é o mais fraco — que é o
que acontece de verdade, e dá ao jogador uma razão pra não mandar o
novato junto com os veteranos só pra "aproveitar carona".
"""
from __future__ import annotations

import random

# Teto de turnos por luta simulada. Acima disso é a zona morta de 1 de
# dano — não vale gastar CPU pra descobrir que ninguém mata ninguém.
TETO_TURNOS = 400

# Quantos tipos de inimigo amostrar por área. Cinco cobre a variedade que
# um andar produz sem transformar o perfil em trabalho pesado.
AMOSTRAS_POR_AREA = 5

VENCE, RECUA, MORRE = "vence", "recua", "morre"


# ------------------------------------------------------------------ perfil

def _duelar(membro_modelo: dict, andar: int, semente: int) -> str:
    """Uma luta simulada. Devolve VENCE, RECUA ou MORRE."""
    import copy
    import game.logic as L

    random.seed(semente)
    p = copy.deepcopy(membro_modelo)
    p["tower_floor"] = andar
    L.recalc(p)
    p["hp"] = p.get("hp_max", 100)
    try:
        L.start_combat(p)
    except Exception:
        return RECUA
    giros = 0
    while p.get("combat") and giros < TETO_TURNOS:
        giros += 1
        try:
            L.combat_attack(p)
        except Exception:
            return RECUA
        if int(p.get("hp", 0)) <= 0:
            return MORRE
    if int(p.get("hp", 0)) <= 0:
        return MORRE
    return VENCE if not p.get("combat") else RECUA


def montar_perfil(membro_modelo: dict, area: dict) -> dict:
    """Simula uma vez contra cada inimigo da área e devolve a tabela.

    Guarde o resultado. Refazer a cada tick seria jogar fora a única coisa
    que torna este sistema barato.
    """
    andar_base = int(area.get("andar", 1))
    encontros = []
    for i in range(AMOSTRAS_POR_AREA):
        andar = andar_base + i
        resultado = _duelar(membro_modelo, andar, 9000 + andar)
        # O peso de encontro cai com a raridade: o chefe do andar múltiplo
        # de 5 aparece menos que o bicho comum.
        peso = 4 if andar % 5 else 1
        encontros.append({"andar": andar, "resultado": resultado, "peso": peso,
                          "chefe": andar % 5 == 0})
    total = sum(e["peso"] for e in encontros) or 1
    mortais = [e for e in encontros if e["resultado"] == MORRE]
    return {
        "area": area.get("id"),
        "encontros": encontros,
        "chance_morte": round(sum(e["peso"] for e in mortais) / total * 100, 1),
        "chance_vitoria": round(
            sum(e["peso"] for e in encontros if e["resultado"] == VENCE) / total * 100, 1),
        # A frase que a tela mostra. É o ponto do sistema inteiro: o jogador
        # entende "morro se esbarrar no chefe" de um jeito que ele nunca
        # entenderia "3,2% de risco".
        "resumo": _frase(encontros, mortais),
    }


def _frase(encontros: list, mortais: list) -> str:
    if not mortais:
        return "Aguenta tudo que aparece por aqui."
    if len(mortais) == len(encontros):
        return "Não aguenta nada nesta área. Mandar é perder o cavaleiro."
    so_chefes = all(e["chefe"] for e in mortais)
    if so_chefes:
        return "Vence os comuns. Morre se esbarrar no chefe."
    return f"Perde para {len(mortais)} dos {len(encontros)} tipos que aparecem aqui."


def perfil_do_grupo(perfis: list) -> dict:
    """Junta os perfis de quem está no mesmo posto.

    O grupo só perde um confronto se NINGUÉM vence aquele inimigo — e nesse
    caso quem cai é o mais fraco, não um sorteado. Mandar o novato com os
    veteranos protege ele, mas é ele que morre se a coisa desandar.
    """
    if not perfis:
        return {"encontros": [], "chance_morte": 100.0, "resumo": "Ninguém neste posto."}
    por_andar = {}
    for i, perfil in enumerate(perfis):
        for e in perfil["encontros"]:
            atual = por_andar.setdefault(e["andar"], dict(e, resultado=MORRE, por=None))
            # Basta UM vencer pra o grupo vencer.
            if e["resultado"] == VENCE:
                atual["resultado"] = VENCE
                atual["por"] = i
            elif e["resultado"] == RECUA and atual["resultado"] == MORRE:
                atual["resultado"] = RECUA
    encontros = list(por_andar.values())
    total = sum(e["peso"] for e in encontros) or 1
    mortais = [e for e in encontros if e["resultado"] == MORRE]
    return {"encontros": encontros,
            "chance_morte": round(sum(e["peso"] for e in mortais) / total * 100, 1),
            "resumo": _frase(encontros, mortais)}


# -------------------------------------------------------------------- tick

# O que pode sair num tick. Sorteio por peso, igual ao saco de storylets —
# um motor só, duas aplicações.
SITUACOES = [
    {"tipo": "recurso",  "peso": 45},
    {"tipo": "monstro",  "peso": 30},
    {"tipo": "storylet", "peso": 18},
    {"tipo": "membro",   "peso": 4},
    {"tipo": "nada",     "peso": 3},
]


def sortear_situacao(area: dict, rng: random.Random | None = None) -> str:
    rng = rng or random
    pesos = dict(area.get("pesos") or {})
    opcoes = [(s["tipo"], pesos.get(s["tipo"], s["peso"])) for s in SITUACOES]
    total = sum(p for _, p in opcoes)
    corte = rng.uniform(0, total)
    acumulado = 0
    for tipo, peso in opcoes:
        acumulado += peso
        if corte <= acumulado:
            return tipo
    return "nada"


def rodar_tick(grupo: dict, area: dict, rng: random.Random | None = None) -> dict:
    """Um tick de AFK. **Não simula combate** — consulta o perfil.

    Devolve o que aconteceu, com a conta aberta. Com morte permanente, "ele
    morreu" sem o porquê é arbitrário; com o encontro nomeado e o peso dele
    na mesa, é a aposta que o jogador fez ao escolher a área.
    """
    rng = rng or random
    tipo = sortear_situacao(area, rng)
    evento = {"tipo": tipo, "area": area.get("id")}

    if tipo == "recurso":
        base = int(area.get("rende", 10))
        evento["recurso"] = max(1, int(base * rng.uniform(0.7, 1.3)))
        evento["motivo"] = f"coleta comum em {area.get('nome', area.get('id'))}"
        return evento

    if tipo == "membro":
        evento["motivo"] = "encontrou alguém disposto a seguir o clã"
        return evento

    if tipo == "storylet":
        # Guardado pra quando o jogador logar. É o pilar 1 alimentando o 3.
        evento["motivo"] = "situação que precisa de decisão"
        return evento

    if tipo == "nada":
        evento["motivo"] = "turno sem novidade"
        return evento

    # monstro: sorteia QUEM apareceu, e o resultado já está no perfil
    encontros = grupo.get("encontros") or []
    if not encontros:
        evento["tipo"] = "nada"
        evento["motivo"] = "sem perfil de combate para esta área"
        return evento
    total = sum(e["peso"] for e in encontros)
    corte = rng.uniform(0, total)
    acumulado = 0
    escolhido = encontros[-1]
    for e in encontros:
        acumulado += e["peso"]
        if corte <= acumulado:
            escolhido = e
            break

    evento["encontro"] = {"andar": escolhido["andar"], "chefe": escolhido["chefe"]}
    evento["resultado"] = escolhido["resultado"]
    nome = "o chefe do andar" if escolhido["chefe"] else "um monstro comum"
    chance = round(escolhido["peso"] / total * 100, 1)

    if escolhido["resultado"] == VENCE:
        evento["recurso"] = max(1, int(int(area.get("rende", 10)) *
                                       (1.8 if escolhido["chefe"] else 1.0)))
        evento["motivo"] = f"encontrou {nome} e venceu"
    elif escolhido["resultado"] == RECUA:
        evento["ferimento"] = 1
        evento["motivo"] = f"encontrou {nome}, não conseguiu vencer e recuou ferido"
    else:
        evento["morte"] = True
        evento["motivo"] = (f"encontrou {nome} — e era justamente o que ele não aguenta. "
                            f"A chance de esbarrar nele aqui era {chance}%.")
    return evento
