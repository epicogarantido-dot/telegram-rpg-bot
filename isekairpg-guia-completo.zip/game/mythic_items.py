# game/mythic_items.py
"""
✨ ITENS MÍTICOS — banco de dados (08/07/2026)

5 itens por categoria de equipamento (9 categorias = 45 itens no total).
Cada um: zero atributo base, 16 sockets, 1 skill própria (dispara sozinha
em combate, não ocupa slot normal) + 1 gatilho de combate exclusivo.

Como conseguir: fundindo 5 itens Lendários da MESMA categoria (chance de
sucesso, ver fuse_legendary_items() mais abaixo) — mesmo espírito da fusão
de pets/montarias que já existe.
"""
import random

FUSION_COST = 5
FUSION_SUCCESS_CHANCE = 0.15  # um pouco mais raro que a fusão de pets/montarias (20%), de propósito


# Cada entrada: (id, nome, skill_id, trigger_key, trigger_value)
MYTHIC_ITEMS_DB = {
    "weapon": [
        ("mit_weapon_1", "🗡️ Excalibur Mítica", "core_sword_5", "double_damage_chance", 25),
        ("mit_weapon_2", "🔥 Cetro do Ifrit Ancião", "core_fire_5", "crit_dmg_bonus_pct", 0.60),
        ("mit_weapon_3", "🐉 Lança da Queda Dracônica", "core_spear_5", "execute_threshold_pct", 0.18),
        ("mit_weapon_4", "☠️ Foice da Marca Mortal", "core_fatal_5", "ignore_def_chance", 30),
        ("mit_weapon_5", "🌩️ Fúria de Zeus Encarnada", "core_thunder_5", "free_turn_chance", 15),
    ],
    "armor": [
        ("mit_armor_1", "🛡️ Couraça do Baluarte Absoluto", "core_shield_5", "ignore_damage_chance", 20),
        ("mit_armor_2", "🗿 Placas do Colosso de Terra", "core_stone_5", "thorns_def_scaling", 0.50),
        ("mit_armor_3", "⚙️ Armadura da Dama de Ferro", "core_thorns_5", "reflect_double_chance", 20),
        ("mit_armor_4", "🌪️ Manto da Tempestade Eterna", "core_wind_5", "perfect_dodge_chance", 18),
        ("mit_armor_5", "💠 Égide do Equilíbrio Perfeito", "core_balance_5", "shield_refresh_chance", 40),
    ],
    "helmet": [
        ("mit_helmet_1", "👑 Coroa do Pesadelo Infinito", "core_shadow_5", "stun_attacker_chance", 25),
        ("mit_helmet_2", "🧠 Elmo do Avatar do Equilíbrio", "core_balance_5", "double_heal_chance", 30),
        ("mit_helmet_3", "❄️ Diadema do Zero Absoluto", "core_ice_5", "ignore_evasion_chance", 25),
        ("mit_helmet_4", "🏹 Visor do Predador", "core_hunter_5", "crit_dmg_bonus_pct", 0.45),
        ("mit_helmet_5", "✝️ Auréola da Ressurreição Divina", "core_heal_5", "auto_revive_once", True),
    ],
    "gloves": [
        ("mit_gloves_1", "👊 Manoplas do Impacto Meteórico", "core_glove_5", "double_damage_chance", 22),
        ("mit_gloves_2", "🩸 Luvas de Devorar Almas", "core_blood_5", "lifesteal_pct", 0.25),
        ("mit_gloves_3", "🏹 Braçadeiras da Flecha do Destino", "core_arrow_5", "free_turn_chance", 18),
        ("mit_gloves_4", "☣️ Garras da Epidemia Mortal", "core_venom_5", "dot_dmg_pct", 0.80),
        ("mit_gloves_5", "💢 Punhos da Fúria Titânica", "core_fury_5", "berserk_dmg_mult", 1.0),
    ],
    "boots": [
        ("mit_boots_1", "🌪️ Botas da Tempestade de Vento", "core_wind_5", "perfect_dodge_chance", 22),
        ("mit_boots_2", "⚡ Grevas da Ira de Zeus", "core_thunder_5", "free_turn_chance", 20),
        ("mit_boots_3", "🐺 Sandálias do Predador", "core_hunter_5", "stun_attacker_chance", 20),
        ("mit_boots_4", "🌋 Botas do Colosso de Terra", "core_stone_5", "ignore_evasion_chance", 20),
        ("mit_boots_5", "🩸 Passos de Devorar Almas", "core_blood_5", "lifesteal_double_party_chance", 25),
    ],
    "shield": [
        ("mit_shield_1", "🛡️ Baluarte Absoluto Verdadeiro", "core_shield_5", "ignore_damage_chance", 25),
        ("mit_shield_2", "🗿 Escudo do Colosso Eterno", "core_stone_5", "thorns_def_scaling", 0.60),
        ("mit_shield_3", "⚙️ Broquel da Dama de Ferro", "core_thorns_5", "reflect_double_chance", 25),
        ("mit_shield_4", "✝️ Égide da Ressurreição", "core_heal_5", "immortal_1hp_once", True),
        ("mit_shield_5", "💠 Anteparo do Equilíbrio", "core_balance_5", "shield_refresh_chance", 45),
    ],
    "belt": [
        ("mit_belt_1", "🔥 Cinturão do Ifrit Ancião", "core_fire_5", "dot_dmg_pct", 0.70),
        ("mit_belt_2", "💢 Faixa da Fúria Titânica", "core_fury_5", "berserk_dmg_mult", 0.90),
        ("mit_belt_3", "☣️ Cinto da Epidemia Mortal", "core_venom_5", "venom_stun_chance", 25),
        ("mit_belt_4", "🩸 Talabarte de Devorar Almas", "core_blood_5", "lifesteal_pct", 0.22),
        ("mit_belt_5", "💠 Cinturão do Avatar do Equilíbrio", "core_balance_5", "heal_mult", 0.50),
    ],
    "necklace": [
        ("mit_necklace_1", "❄️ Colar do Zero Absoluto", "core_ice_5", "ignore_def_chance", 25),
        ("mit_necklace_2", "🏹 Pingente da Flecha do Destino", "core_arrow_5", "crit_dmg_bonus_pct", 0.55),
        ("mit_necklace_3", "✝️ Relicário da Ressurreição Divina", "core_heal_5", "double_heal_chance", 35),
        ("mit_necklace_4", "🌩️ Amuleto da Ira de Zeus", "core_thunder_5", "stun_attacker_chance", 22),
        ("mit_necklace_5", "🐉 Joia da Queda Dracônica", "core_spear_5", "execute_threshold_pct", 0.15),
    ],
    "ring": [
        ("mit_ring_1", "🗡️ Anel de Excalibur", "core_sword_5", "double_damage_chance", 20),
        ("mit_ring_2", "☠️ Selo da Marca Mortal", "core_fatal_5", "ignore_def_chance", 28),
        ("mit_ring_3", "🌪️ Anel da Tempestade Eterna", "core_wind_5", "free_turn_chance", 16),
        ("mit_ring_4", "🩸 Aliança de Devorar Almas", "core_blood_5", "lifesteal_pct", 0.20),
        ("mit_ring_5", "💠 Anel do Equilíbrio Absoluto", "core_balance_5", "shield_refresh_chance", 35),
    ],
}


def get_mythic_variants(slot: str) -> list:
    return MYTHIC_ITEMS_DB.get(slot, [])


def criar_item_mitico_do_banco(slot: str, mit_id: str | None = None):
    """Monta um item Mítico pronto a partir do banco. Se mit_id for None,
    sorteia um dos 5 da categoria."""
    from game.craft import criar_item_mitico

    variantes = get_mythic_variants(slot)
    if not variantes:
        return None

    if mit_id:
        escolhida = next((v for v in variantes if v[0] == mit_id), None)
        if not escolhida:
            return None
    else:
        escolhida = random.choice(variantes)

    mit_id, nome, skill_id, trigger_key, trigger_value = escolhida
    item = criar_item_mitico(
        nome=nome, slot=slot, skill_id=skill_id,
        trigger_key=trigger_key, trigger_value=trigger_value,
        skill_cooldown=4, skill_power_mult=0.65,
    )
    item["mit_id"] = mit_id        # 🖼️ (26/09) a arte própria sai daqui (MITICO_...)
    return item


def get_fusable_legendary_items(p: dict, slot: str) -> list:
    """Itens Lendários daquela categoria que o jogador tem (índices no
    inventário) — candidatos a fusão pro Mítico."""
    items = p.get("inv", {}).get("items", {}).get(slot, [])
    return [i for i, it in enumerate(items) if isinstance(it, dict) and it.get("rar") == "legendary"]


def fuse_legendary_items(p: dict, slot: str) -> tuple:
    """Funde 5 itens Lendários da MESMA categoria (sempre consumidos) por
    15% de chance de ganhar 1 item Mítico aleatório daquela categoria."""
    inv_items = p.get("inv", {}).get("items", {}).get(slot, [])
    candidatos_idx = get_fusable_legendary_items(p, slot)

    if len(candidatos_idx) < FUSION_COST:
        return False, f"❌ Você precisa de {FUSION_COST} itens Lendários de {slot} (tem {len(candidatos_idx)})."

    # Remove os 5 mais recentes (índices mais altos primeiro, pra não bagunçar a lista ao remover)
    for idx in sorted(candidatos_idx[:FUSION_COST], reverse=True):
        inv_items.pop(idx)

    if random.random() < FUSION_SUCCESS_CHANCE:
        novo_item = criar_item_mitico_do_banco(slot)
        if novo_item:
            inv_items.append(novo_item)
            return True, (
                f"✨ <b>FUSÃO MÍTICA BEM-SUCEDIDA!</b>\n"
                f"5 itens Lendários se fundiram em <b>{novo_item['name']}</b> "
                f"(💠 MÍTICO)! Confira no seu inventário."
            )

    return False, (
        "💨 A fusão falhou...\n"
        "5 itens Lendários foram consumidos, mas nenhum item Mítico surgiu. "
        "Tente de novo!"
    )


# =============================================================================
# ✨ FUSÃO MÍTICA POR COMPOSIÇÃO (18/09/2026)
# =============================================================================
# Antes a fusão exigia 5 Lendários da MESMA categoria e devolvia um mítico
# daquela categoria. Na prática isso travava o sistema: quem tinha 4 armas e
# 1 bota não podia fundir nada, e o lendário avulso não servia pra coisa
# alguma.
#
# Agora aceita 5 Lendários QUAISQUER, e a composição decide o tipo:
# cada um dos 9 slots começa com peso 1 (o piso aleatório, que é o que
# permite misturar) e cada item soma PESO_DO_ITEM ao slot dele.
#
# O peso foi DERIVADO do alvo de 50% com 5 iguais, não chutado:
#     (1 + 5w) / (9 + 5w) = 1/2   ->   w = 7/5 = 1.4
#
# Como sempre se colocam 5 itens, o peso total é sempre 9 + 5*1.4 = 16 —
# denominador constante, então a chance é LINEAR no número de iguais:
#
#     iguais   0      1      2      3      4      5
#     chance   6,2%   15%    23,8%  32,5%  41,2%  50%
#
# (Conferido contra 200.000 fusões simuladas: 50,1% / 32,6% / 14,9%.)
#
# ⚠️ Isto decide só o TIPO. A chance de a fusão DAR CERTO continua sendo
# FUSION_SUCCESS_CHANCE, e as duas se multiplicam: 5 iguais dão 15% de sair
# mítico e, desses, 50% do tipo escolhido — 7,5% de sair exatamente o que
# você queria. O texto da tela diz isso, porque esconder a multiplicação é
# o que faz o jogador achar que foi roubado.
SLOTS_MITICOS = ["weapon", "armor", "helmet", "gloves", "boots",
                 "shield", "belt", "necklace", "ring"]
PESO_DO_ITEM = 7 / 5


def chance_por_tipo(composicao: list) -> dict:
    """Chance de cada slot sair, dada a lista de slots colocados."""
    pesos = {s: 1.0 for s in SLOTS_MITICOS}
    for slot in composicao:
        if slot in pesos:
            pesos[slot] += PESO_DO_ITEM
    total = sum(pesos.values())
    return {s: peso / total for s, peso in pesos.items()}


def sortear_tipo(composicao: list, rng=None) -> str:
    rng = rng or random
    chances = chance_por_tipo(composicao)
    r = rng.random()
    acumulado = 0.0
    for slot, ch in chances.items():
        acumulado += ch
        if r <= acumulado:
            return slot
    return SLOTS_MITICOS[-1]


def lendarios_do_jogador(p: dict) -> list:
    """Todo Lendário do inventário, de qualquer slot, como (slot, idx, item)."""
    itens = (p.get("inv") or {}).get("items") or {}
    saida = []
    for slot in SLOTS_MITICOS:
        for idx, it in enumerate(itens.get(slot, [])):
            if isinstance(it, dict) and it.get("rar") == "legendary":
                saida.append({"slot": slot, "idx": idx,
                              "nome": it.get("name", "?"),
                              "bonus": it.get("bonus", {})})
    return saida


def fundir_composicao(p: dict, escolhidos: list, rng=None) -> tuple:
    """Funde 5 Lendários quaisquer. `escolhidos` é [{slot, idx}, ...].

    Os itens são SEMPRE consumidos, dê certo ou não — é o que faz a fusão
    ser aposta e não moedinha de troca.
    """
    rng = rng or random
    itens = (p.get("inv") or {}).get("items") or {}

    if len(escolhidos) != FUSION_COST:
        return False, f"❌ A fusão precisa de exatamente {FUSION_COST} itens Lendários."

    # Valida ANTES de remover qualquer coisa: remover metade e então
    # descobrir que o quinto não existia comeria os itens do jogador.
    vistos = set()
    composicao = []
    for esc in escolhidos:
        slot, idx = esc.get("slot"), int(esc.get("idx", -1))
        chave = (slot, idx)
        if chave in vistos:
            return False, "❌ O mesmo item foi escolhido duas vezes."
        vistos.add(chave)
        lista = itens.get(slot) or []
        if idx < 0 or idx >= len(lista):
            return False, "❌ Um dos itens não existe mais no inventário."
        it = lista[idx]
        if not isinstance(it, dict) or it.get("rar") != "legendary":
            return False, "❌ Só itens Lendários entram na fusão."
        composicao.append(slot)

    # Remove de trás pra frente dentro de cada slot, senão os índices
    # seguintes escorregam e some o item errado.
    por_slot = {}
    for slot, idx in vistos:
        por_slot.setdefault(slot, []).append(idx)
    for slot, indices in por_slot.items():
        for idx in sorted(indices, reverse=True):
            itens[slot].pop(idx)

    if rng.random() >= FUSION_SUCCESS_CHANCE:
        return False, ("💨 A fusão falhou...\n"
                       f"{FUSION_COST} itens Lendários foram consumidos e nenhum "
                       "Mítico surgiu.")

    slot_saida = sortear_tipo(composicao, rng)
    novo_item = criar_item_mitico_do_banco(slot_saida)
    if not novo_item:
        return False, "💨 A fusão falhou e os itens se perderam."

    itens.setdefault(slot_saida, []).append(novo_item)
    iguais = composicao.count(slot_saida)
    return True, (f"✨ <b>FUSÃO MÍTICA BEM-SUCEDIDA!</b>\n"
                  f"Saiu <b>{novo_item['name']}</b> (💠 MÍTICO)."
                  + (f"\nVocê tinha colocado {iguais} peça(s) desse tipo."
                     if iguais else "\nNenhuma das peças era desse tipo — sorte pura."))


# =============================================================================
# 📖 (28/09, dev) CATÁLOGO — "um carrossel só mostrando os itens míticos, as
# imagens e os status deles". O texto de cada gatilho diz o que o COMBATE
# faz com ele (conferido em logic.py), não o nome da chave.
# =============================================================================
def descrever_gatilho(chave: str, valor) -> str:
    v = float(valor) if not isinstance(valor, bool) else 0.0
    pct = f"{round(v * 100)}%"           # valores guardados como fração (0.25)
    n = f"{int(v)}%"                     # chances guardadas como número (25)
    textos = {
        "double_damage_chance": f"{n} de chance de causar dano dobrado",
        "crit_dmg_bonus_pct": f"Crítico causa +{pct} de dano",
        "execute_threshold_pct": f"Executa na hora o inimigo com {pct} da vida ou menos",
        "ignore_def_chance": f"{n} de chance de ignorar toda a defesa do alvo",
        "free_turn_chance": f"{n} de chance de ganhar um turno extra",
        "ignore_damage_chance": f"{n} de chance de não sofrer nenhum dano de um golpe",
        "thorns_def_scaling": "Quem te bate com ataque menor que a sua defesa leva o dobro do dano de volta",
        "reflect_double_chance": f"Devolve 20% do dano recebido, com {n} de chance de devolver o dobro",
        "perfect_dodge_chance": f"{n} de chance de esquiva perfeita",
        "shield_refresh_chance": f"{n} de chance de o seu escudo se refazer (pela metade) quando quebra",
        "stun_attacker_chance": f"{n} de chance de atordoar quem te ataca",
        "double_heal_chance": f"{n} de chance de dobrar uma cura",
        "ignore_evasion_chance": f"{n} de chance de acertar ignorando a esquiva do alvo",
        "auto_revive_once": "Uma vez por luta, revive com 50% da vida",
        "immortal_1hp_once": "Uma vez por luta, sobrevive a um golpe fatal com 1 de vida",
        "lifesteal_pct": f"Rouba {pct} do dano causado como vida",
        "dot_dmg_pct": f"Dano contínuo (veneno, queimadura, sangramento) +{pct}",
        "berserk_dmg_mult": f"Com a vida abaixo de 50%, causa +{pct} de dano",
        "lifesteal_double_party_chance": f"{n} de chance de dobrar o roubo de vida e curar o grupo (precisa de roubo de vida)",
        "venom_stun_chance": f"Os venenos que você aplica têm {n} de chance de atordoar",
        "heal_mult": f"Suas curas rendem +{pct}",
    }
    return textos.get(chave, f"{chave.replace('_', ' ')}: {valor}")


def descrever_skill_mitica(sk: dict, poder: float) -> list:
    """O que a habilidade FAZ quando dispara pelo mítico — que não é a skill
    normal: `process_mythic_items_start_of_turn` usa só dano (num alvo),
    atordoamento (35% de chance), dano contínuo, cura e escudo, tudo × o
    poder do item (0,65). Mostrar os números da skill normal (400%, recarga
    7, "em todos") seria prometer o que não acontece."""
    pct = lambda v: f"{round(float(v) * poder * 100)}%"
    suporte = (float(sk.get("heal_percent") or 0) > 0 or float(sk.get("shield_pct") or 0) > 0
               or sk.get("target") in ("self", "ally"))
    linhas = []
    if suporte:
        if float(sk.get("heal_percent") or 0) > 0:
            linhas.append(f"Cura {pct(sk['heal_percent'])} do seu ataque em vida")
        if float(sk.get("shield_pct") or 0) > 0:
            linhas.append(f"Barreira de {pct(sk['shield_pct'])} do seu ataque")
    else:
        linhas.append(f"Dano de {pct(sk.get('mult', 1.0))} do seu ataque no alvo")
        if int(sk.get("stun") or 0) > 0:
            linhas.append(f"35% de chance de atordoar por {int(sk['stun'])} turno(s)")
        if float(sk.get("dot_mult") or 0) > 0:
            linhas.append(f"{sk.get('dot_name', 'Dano contínuo')}: {pct(sk['dot_mult'])} do ataque por turno, "
                          f"{int(sk.get('dot_turns', 2))} turnos")
    return linhas


def catalogo_miticos() -> list:
    """Os 45 míticos, na ordem dos slots, com o que a tela precisa."""
    from game.assets import chave_mitico
    from game.skills import SKILL_DB
    from game.logic import ITEM_SLOT_MAIN_STAT, ITEM_RARITY_PCT
    saida = []
    for slot in SLOTS_MITICOS:
        for mit_id, nome, skill_id, chave, valor in MYTHIC_ITEMS_DB.get(slot, []):
            sk = (SKILL_DB.get(skill_id) or {}).get("skill") or {}
            saida.append({
                "mit_id": mit_id, "nome": nome, "slot": slot, "img_key": chave_mitico(mit_id),
                "skill": {"core": skill_id, "id": sk.get("id"), "nome": sk.get("name", skill_id),
                          "efeitos": descrever_skill_mitica(sk, 0.65)},
                "skill_recarga": 4, "skill_poder": 65,
                "gatilho": descrever_gatilho(chave, valor),
                "sockets": 16,
                "bonus_raridade": {"stat": ITEM_SLOT_MAIN_STAT.get(slot), "pct": int(round(ITEM_RARITY_PCT["mythic"] * 100))},
            })
    return saida
