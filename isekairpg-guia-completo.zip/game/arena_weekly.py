# game/arena_weekly.py
"""
📅 RANKING SEMANAL DA ARENA (08/07/2026) — as ⭐ estrelas não vêm mais de
vitória avulsa. Uma vez por semana, o ranking fecha, todo mundo que
pontuou recebe estrelas de acordo com a POSIÇÃO final, e a pontuação
zera pra semana seguinte começar do zero.

Como não tem agendador de tarefas rodando sozinho, a checagem é "lazy":
toda vez que alguém abre a Arena, verifica se já passou 1 semana desde o
último fechamento — se sim, fecha ali mesmo, na hora.
"""
import time

SEMANA_SEGUNDOS = 7 * 24 * 60 * 60

FAIXAS_PREMIACAO = [
    (1, 100_000),
    (2, 60_000),
    (3, 40_000),
    (10, 20_000),
    (25, 10_000),
    (50, 4_000),
    (100, 2_000),
]
PREMIO_PARTICIPACAO = 1_000


def _premio_por_posicao(posicao: int) -> int:
    for limite, estrelas in FAIXAS_PREMIACAO:
        if posicao <= limite:
            return estrelas
    return PREMIO_PARTICIPACAO


def verificar_e_fechar_semana() -> str | None:
    """Chame sempre que alguém abrir a Arena. Se a semana já virou, fecha o
    ranking, premia todo mundo e reseta — retorna um resumo (ou None se
    ainda não é hora)."""
    from game.arena_week_repo import get_week_state, save_week_state
    from game.sql_repo import get_ranking_arena_sync, reset_all_arena_points_sync, load_player, save_player_sql
    from infra.cache_bus import mark_dirty

    state = get_week_state()
    agora = int(time.time())

    if not state:
        save_week_state({"week_start": agora})
        return None

    inicio = int(state.get("week_start", agora))
    if agora - inicio < SEMANA_SEGUNDOS:
        return None

    ranking = get_ranking_arena_sync(limit=1000)
    ranking = [r for r in ranking if float(r.get("arena_points", 0) or 0) > 0]

    if not ranking:
        save_week_state({"week_start": agora})
        return None

    premiados = []
    for i, entrada in enumerate(ranking):
        posicao = i + 1
        ouro = _premio_por_posicao(posicao)
        pid = entrada["telegram_id"]
        try:
            pdata = load_player(int(pid))
            if pdata:
                pdata["gold"] = int(pdata.get("gold", 0)) + ouro
                save_player_sql(int(pid), pdata)
                mark_dirty(int(pid))
                premiados.append((posicao, entrada.get("username") or f"Jogador {pid}", ouro))
        except Exception:
            continue

    reset_all_arena_points_sync()
    save_week_state({"week_start": agora})

    linhas = [f"📅 <b>RANKING SEMANAL DA ARENA FECHOU!</b>\n{len(premiados)} jogador(es) premiado(s):\n"]
    for posicao, nome, ouro in premiados[:10]:
        medalha = {1: "🥇", 2: "🥈", 3: "🥉"}.get(posicao, "🔹")
        linhas.append(f"{medalha} #{posicao} {nome}: +{ouro:,}g")
    if len(premiados) > 10:
        linhas.append(f"... e mais {len(premiados) - 10} jogador(es).")
    linhas.append("\n🔄 A pontuação de todos foi zerada — a semana nova já começou!")

    return "\n".join(linhas)


def tempo_restante_semana() -> int:
    from game.arena_week_repo import get_week_state

    state = get_week_state()
    if not state:
        return SEMANA_SEGUNDOS
    inicio = int(state.get("week_start", int(time.time())))
    restante = SEMANA_SEGUNDOS - (int(time.time()) - inicio)
    return max(0, restante)
