# game/clan_explorar.py
"""
🔎 EXPLORAR O ANDAR (20/09/2026 — pedido do dev)

"Explorar é onde se acham coisas pra fazer — postos, pontos, outras aldeias.
O jogador escolhe de uma lista de 5 ou explora de novo, mas sempre que
explora tem chance de ser atacado. Depois de escolher, a equipe fica lá; se
tiver gente, é batalha pra ficar. E aí acontece o que já acontecia: o bônus
e a chance de ser atacado. Assim se procura coisa e se pode atacar outros
jogadores que estejam no andar."

COMO FUNCIONA
-------------
- Quem explora é uma EQUIPE (precisa de guarda: é a escolta que aguenta a
  emboscada). Cada busca custa comida.
- EMBOSCADA: 25% das buscas; a escolta enfrenta a ameaça do andar
  (`clan_equipes.resultado_da_saida`). Aguentou: nada. Não aguentou: a
  equipe volta cansada (+25 de cansaço em todos) — a lista vem mesmo assim.
- A busca devolve 5 ACHADOS do andar, misturando:
    posto (um posto escondido do andar — o tipo e a ★ são sorte),
    ponto do mapa (livre, de bot ou de outro jogador),
    cidade de outro clã que está no mesmo andar.
- Escolher leva a equipe pra lá (quem cobra, move e briga é o clan_repo).

Puro: sem banco.
"""
from __future__ import annotations

import random

TAMANHO_DA_LISTA = 5
CHANCE_DE_EMBOSCADA = 0.25
CANSACO_DA_EMBOSCADA = 25
SAQUE_DA_CIDADE = 0.20          # o mesmo que um ataque de monstros leva


def custo_da_busca(andar: int) -> int:
    """Comida da busca (a ração de quem sai)."""
    return 4 + int(andar) // 2


def madeira_da_busca(andar: int) -> int:
    """(dev, 20/09) explorar gasta outro recurso além de comida: lenha pra
    tocha e fogueira — mais longe da luz, mais lenha."""
    return 2 + int(andar) // 5


def emboscada(guardas: list, andar: int, rng: random.Random) -> dict | None:
    """None = passou sem ser atacada. Senão, o resultado da escolta."""
    if rng.random() >= CHANCE_DE_EMBOSCADA:
        return None
    from game.clan_equipes import resultado_da_saida
    return resultado_da_saida(guardas, andar, rng)


def montar_lista(postos_escondidos: list, pontos_do_andar: list, cidades: list,
                 rng: random.Random) -> list:
    """Os 5 achados. Cada fonte entra com peso, sem repetir; se uma fonte
    secar, as outras completam. `postos_escondidos` são dicts já sorteados
    (tipo e ★), `pontos_do_andar` linhas do mapa, `cidades` clãs vizinhos."""
    fontes = {"posto": list(postos_escondidos), "ponto": list(pontos_do_andar), "cidade": list(cidades)}
    for lista in fontes.values():
        rng.shuffle(lista)
    pesos = {"posto": 3, "ponto": 4, "cidade": 2}
    achados = []
    while len(achados) < TAMANHO_DA_LISTA and any(fontes.values()):
        vivas = [(k, p) for k, p in pesos.items() if fontes[k]]
        corte, acc, escolha = rng.uniform(0, sum(p for _, p in vivas)), 0.0, vivas[-1][0]
        for k, p in vivas:
            acc += p
            if corte <= acc:
                escolha = k
                break
        achados.append({"tipo": escolha, "dado": fontes[escolha].pop()})
    return achados
