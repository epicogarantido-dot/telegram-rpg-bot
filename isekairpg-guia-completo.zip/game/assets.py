# game/assets.py
from __future__ import annotations

# Use CHAVES LÓGICAS (CITY, TOWER, BOSS_5...) -> file_id como VALOR.
# file_id é o que você reaproveita pra reenviar a foto pelo bot. [web:40][web:42]

ASSETS = {
    # Cenários
    "HOSPITAL":  "AgACAgEAAxkBAAIEUmmlbD1q-oSs7R3fnfXBf3BLTx54AALJC2sbQgkpRTARzXDU3aH6AQADAgADeAADOgQ",
            "RAID":  "AgACAgEAAxkBAAIEUmmlbD1q-oSs7R3fnfXBf3BLTx54AALJC2sbQgkpRTARzXDU3aH6AQADAgADeAADOgQ",
        "RAID_COMBAT":  "AgACAgEAAxkBAAIEUmmlbD1q-oSs7R3fnfXBf3BLTx54AALJC2sbQgkpRTARzXDU3aH6AQADAgADeAADOgQ",
    "CITY":  "AgACAgEAAxkBAAIEUmmlbD1q-oSs7R3fnfXBf3BLTx54AALJC2sbQgkpRTARzXDU3aH6AQADAgADeAADOgQ",
    "TOWER": "AgACAgEAAxkBAAIEUWmlbD0LpRCh_Iai3vE6fctlQOJ9AALIC2sbQgkpRbeq5PBS0ddUAQADAgADeAADOgQ",
    "LOJA":  "AgACAgEAAxkBAAIEUGmlbD3N1Lj-gFo6CCcDQdyvu5MPAALHC2sbQgkpRXVtcMdj0T9OAQADAgADeAADOgQ",
    "CLASSE":  "AgACAgEAAxkBAAIET2mlbD3_ucf_97YWD8jfF59E8w5CAALGC2sbQgkpRftGl_mSCKS4AQADAgADeAADOgQ",
    "TRILHAS":  "AgACAgEAAxkBAAIETWmlbD2HQA9XigtOKeqUOyS9JEpmAALEC2sbQgkpRSYAAZh7qg-h0AEAAwIAA3gAAzoE",
    "APRENDER":  "AgACAgEAAxkBAAIES2mlbD1rVorISi4kf9k4553-NFQvAALCC2sbQgkpRant9CeFilChAQADAgADeAADOgQ",
    "TROCAS":  "AgACAgEAAxkBAAIESmmlbD0AAQ74i5fg_wABnlJNnxVXDC4AAsELaxtCCSlF-AS9Xbk1-BABAAMCAAN4AAM6BA",
    "RANKING":  "AgACAgEAAxkBAAIESWmlbD2NQl4eGQQ83gQD8kY-BTNcAALAC2sbQgkpRbVmnpeLlb_SAQADAgADeAADOgQ",
    "SOCKETS":  "AgACAgEAAxkBAAIETGmlbD0tG8spHiKUH9OofTXUzsjEAALDC2sbQgkpRVfrCzqZ8qAKAQADAgADeAADOgQ",
    "SKILL":  "AgACAgEAAxkBAAIETmmlbD1EPjgVVcAEbrvI9bXmEoGtAALFC2sbQgkpRegPhI98-R2LAQADAgADeAADOgQ",
    "CRAFT":  "AgACAgEAAxkBAAIESGmlbD1QcdkAARH4p7YdUexeaP9BIwACygtrG0IJKUUHY1eJOAxD9AEAAwIAA3gAAzoE",
    "INVENTARIO":  "AgACAgEAAxkBAAIEkWmlrBTULPUffL2dKg5CRkbWFD-tAAK-C2sbaGUxRUnLBE1OimdbAQADAgADeQADOgQ",
    "DEAD":  "AgACAgEAAxkBAAIEi2mlpikqYesGMrFqV9vuQ5Lid1UCAAK6C2sbaGUxRYwFxbvNhV2DAQADAgADeQADOgQ",
    "VIP":  "AgACAgEAAxkBAAIEj2mlq5D2qu0f5SeBO_1mT2JixXMxAAK9C2sbaGUxRV_LB8qPXjseAQADAgADeQADOgQ",
    "STATUS":  "AgACAgEAAxkBAAIEiGmlpiac4jVbCAGllVIWtmc2Uu1WAAK5C2sbaGUxRVfQ64D_2_mcAQADAgADeQADOgQ",



    # Combate / mobs
    "MOB_DEFAULT": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",

    # Bosses (você pode ir adicionando conforme cria artes)
    "BOSS_5":  "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",
    "BOSS_10": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",
    "BOSS_15": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",
 #espada
"WEAPON_SWORD_COMMON": "AgACAgEAAxkBAAIBkml9REAvRjN6xJFyWpowwVGXdt7eAAI8DGsbFc7oR1C7L6GaKzv9AQADAgADeQADOAQ",
"WEAPON_SWORD_UNCOMMON": "AgACAgEAAxkBAAIBk2l9REBJj3KEWFaBulzRum6w8pSNAAI9DGsbFc7oR7qTUnXf3GUUAQADAgADeQADOAQ", 
"WEAPON_SWORD_RARE": "AgACAgEAAxkBAAIBlGl9REBhbFHZnQABBg1_eeEK0-YO-QACPgxrGxXO6Ec0Lexzd11w0gEAAwIAA3kAAzgE",
"WEAPON_SWORD_EPIC": "AgACAgEAAxkBAAIBlWl9RECl8n-k7ghMdnZIJzk_fD2JAAI_DGsbFc7oR1BIX_0aYysWAQADAgADeQADOAQ",
"WEAPON_SWORD_LEGENDARY": "AgACAgEAAxkBAAIBlml9REDcnVQ68le7IeVVN60266sPAAJADGsbFc7oR_OevPJbCV94AQADAgADeQADOAQ",

# Arco
"WEAPON_BOW_COMMON": "AgACAgEAAxkBAAIBpml9REagWy5ndMxwELpkArTzqKomAAJGDGsbFc7oR6VF1PeFcpH_AQADAgADeQADOAQ",
"WEAPON_BOW_UNCOMMON": "AgACAgEAAxkBAAIBp2l9REYvjFLDWDW7qtZp1VZyXHjfAAJIDGsbFc7oR7wvrR1r3nIzAQADAgADeQADOAQ",
"WEAPON_BOW_RARE": "AgACAgEAAxkBAAIBqGl9REZ3EPPASgsI6l9fDShnY6tcAAJHDGsbFc7oR3qNuSRA5uEhAQADAgADeQADOAQ",
"WEAPON_BOW_EPIC": "AgACAgEAAxkBAAIBqWl9REaKutGZ8rqiEgolZtoGJkVDAAJJDGsbFc7oR07F2_bYdbcCAQADAgADeQADOAQ",
"WEAPON_BOW_LEGENDARY": "AgACAgEAAxkBAAIBqml9REZmTGMB1fCeMXV_jMOW9AEmAAJKDGsbFc7oR93cief1HgbLAQADAgADeQADOAQ",

# Adaga
"WEAPON_DAGGER_COMMON": "AgACAgEAAxkBAAIBfml9RD3ZUG2-w35bO5n_Oioun8TkAAIyDGsbFc7oRyKJa3haQa2XAQADAgADeQADOAQ",
"WEAPON_DAGGER_UNCOMMON": "AgACAgEAAxkBAAIBf2l9RD0d-pENDYnowY28Ri8EA0xVAAIzDGsbFc7oRwtmgbNKUTJoAQADAgADeQADOAQ",
"WEAPON_DAGGER_RARE": "AgACAgEAAxkBAAIBgGl9RD3x4aKCkLtGJhKOehW0y5n6AAI0DGsbFc7oR2NhVpMf4dGMAQADAgADeQADOAQ",
"WEAPON_DAGGER_EPIC": "AgACAgEAAxkBAAIBgWl9RD1LCxLpKBXP3KEBMqZeaTOPAAI1DGsbFc7oR8Hwj4MTnu4SAQADAgADeQADOAQ",
"WEAPON_DAGGER_LEGENDARY": "AgACAgEAAxkBAAIBgml9RD0ol1J02SG5AAEb47RHtw1_PgACNgxrGxXO6EccO_2xDM9G8wEAAwIAA3kAAzgE",

# Lança
"WEAPON_SPEAR_COMMON": "AgACAgEAAxkBAAIBg2l9RD0EoBWsOZzKw83Qfx402Be-AAI3DGsbFc7oR0sbP2opnSnCAQADAgADeQADOAQ",
"WEAPON_SPEAR_UNCOMMON": "AgACAgEAAxkBAAIBhGl9RD0StebffTD4UxwFTRj4aZYBAAI4DGsbFc7oR-jPgkBouJTeAQADAgADeQADOAQ",
"WEAPON_SPEAR_RARE": "AgACAgEAAxkBAAIBhWl9RD28DhYWm1MbARvgtQErGKH5AAI5DGsbFc7oR6FSICouES7EAQADAgADeQADOAQ",
"WEAPON_SPEAR_EPIC": "AgACAgEAAxkBAAIBhml9RD0fk0eixH73MMQNs2HHNWYnAAI6DGsbFc7oR0msAAHtR9vjGgEAAwIAA3kAAzgE",
"WEAPON_SPEAR_LEGENDARY": "AgACAgEAAxkBAAIBh2l9RD3M5-uWmi-d2ifyUBovPoC3AAI7DGsbFc7oRwx9v6f6sQvqAQADAgADeQADOAQ",

# Martelo
"WEAPON_HAMMER_COMMON": "AgACAgEAAxkBAAIBl2l9REAKFQ9hc7v8mT5Ol7Xe6OcMAAJBDGsbFc7oR9tZAAGePxrgHAEAAwIAA3kAAzgE",
"WEAPON_HAMMER_UNCOMMON": "AgACAgEAAxkBAAIBmGl9REAmjsp3bsj_haOQh2T6eH_sAAJCDGsbFc7oRwzgwe9Krre1AQADAgADeQADOAQ",
"WEAPON_HAMMER_RARE": "AgACAgEAAxkBAAIBmWl9REA-2jUyxHDGK326rWtHtWEIAAJDDGsbFc7oR3eK-HP2CQhRAQADAgADeQADOAQ",
"WEAPON_HAMMER_EPIC": "AgACAgEAAxkBAAIBmml9RECpBCvfuCNZb3JxHza3VTvFAAJEDGsbFc7oR2WAaMF3IyO9AQADAgADeQADOAQ",
"WEAPON_HAMMER_LEGENDARY": "AgACAgEAAxkBAAIBm2l9REA0tHN_UsuxIEM2-Vm97Tu7AAJFDGsbFc7oR438V9CaQhNiAQADAgADeQADOAQ",

# ========= CRAFT: ARMADURAS =========
"ARMOR_COMMON": "AgACAgEAAxkBAAIBq2l9REbP4ZTLzvMIuUqI5MtOVlj_AAJLDGsbFc7oRyjY2fNwdB6xAQADAgADeQADOAQ",
"ARMOR_UNCOMMON": "AgACAgEAAxkBAAIBrGl9REaeHFAHoWXgYNr047Fwny-CAAJMDGsbFc7oR1gp18hGD6FMAQADAgADeQADOAQ",
"ARMOR_RARE": "AgACAgEAAxkBAAIBrWl9REZtOYXlAtjai-U_HSZJeZ0UAAJNDGsbFc7oR8nFN4vzSkKVAQADAgADeQADOAQ",
"ARMOR_EPIC": "AgACAgEAAxkBAAIBrml9REZ3P36vtSLWAp2ZjwSCQj93AAJODGsbFc7oR_m8BpV72EhkAQADAgADeQADOAQ",
"ARMOR_LEGENDARY": "AgACAgEAAxkBAAIBr2l9REYLTWewWkzYHk67M5K7_bgaAAJPDGsbFc7oR5v7Im5iKUAgAQADAgADeQADOAQ",

# ========= CRAFT: CAPACETE =========
"HELMET_COMMON": "AgACAgEAAxkBAAIBuWl9REcJV7bul11tl3ud8oU1z63PAAJVDGsbFc7oR8fIcVUOe5SIAQADAgADeQADOAQ",
"HELMET_UNCOMMON": "AgACAgEAAxkBAAIBuml9REdt8G-P4fFjBh6geC7btRncAAJYDGsbFc7oR0Ihjj8IIN4KAQADAgADeQADOAQ",
"HELMET_RARE": "AgACAgEAAxkBAAIBu2l9REcYtG5194Y4dzU0mHjZ6M6DAAJXDGsbFc7oRyMdYXW2ad3lAQADAgADeQADOAQ",
"HELMET_EPIC": "AgACAgEAAxkBAAIBvGl9REccXAnYnD8O8ip4MIiCLHUlAAJZDGsbFc7oRwONU8IzbSRaAQADAgADeQADOAQ",
"HELMET_LEGENDARY": "AgACAgEAAxkBAAIBvWl9REfQmy0e2UlZZwABxiJfcJV_YgACVgxrGxXO6EeiHs6wd79shgEAAwIAA3kAAzgE",

# ========= CRAFT: LUVAS =========
"GLOVES_COMMON": "AgACAgEAAxkBAAPmaXgfTf90cqxXFucNeOqE8p_dU4YAAikNaxtKeMBH_oBcHDZxJY4BAAMCAAN5AAM4BA",
"GLOVES_UNCOMMON": "AgACAgEAAxkBAAPnaXgfTZLQDNpGnjNZ6wz41uS6U1EAAioNaxtKeMBH-d7JqtAIc44BAAMCAAN5AAM4BA",
"GLOVES_RARE": "AgACAgEAAxkBAAPoaXgfTccIzISpH4rLMESE--GwqLUAAisNaxtKeMBH5JkXhiBBjIwBAAMCAAN5AAM4BA",
"GLOVES_EPIC": "AgACAgEAAxkBAAPpaXgfTRgLcIe6MdCKlT9ubDelaUYAAiwNaxtKeMBHk0yewWWYOVsBAAMCAAN5AAM4BA",
"GLOVES_LEGENDARY": "AgACAgEAAxkBAAPqaXgfTeQK78KGg89Yh7yA1ju95IsAAi0NaxtKeMBHOeos1u8b5HQBAAMCAAN5AAM4BA",

# ========= CRAFT: BOTAS =========
"BOOTS_COMMON": "AgACAgEAAxkBAAIBHWl44bJQzmsAAdNdFv6u18KtKqvNfgACwTRrG0p4wEcWJdK0MGABHgEAAwIAA3kAAzgE",
"BOOTS_UNCOMMON": "AgACAgEAAxkBAAIBHml44bLwM5N0UcGm_AsHvUwxAT9bAALCNGsbSnjAR1QnQq5jkwOWAQADAgADeQADOAQ",
"BOOTS_RARE": "AgACAgEAAxkBAAIBH2l44bLIbx_kp8NCIcy381x8-ZOnAALDNGsbSnjAR-DSojSEMz0OAQADAgADeQADOAQ",
"BOOTS_EPIC": "AgACAgEAAxkBAAIBHGl44bL7_d4EGR41MpD-PBVhSXJcAALANGsbSnjAR4_5n8QRYqIsAQADAgADeQADOAQ",
"BOOTS_LEGENDARY": "AgACAgEAAxkBAAIBG2l44bILDBhxIO8NhZXUtTX7aV94AAK_NGsbSnjAR3Ky739j1mfWAQADAgADeQADOAQ",

# ========= CRAFT: ESCUDO =========
"SHIELD_COMMON": "AgACAgEAAxkBAAIBtGl9REdI8snAmJHGrO1duZW-2fFhAAJQDGsbFc7oR9hlOsTOODcSAQADAgADeQADOAQ",
"SHIELD_UNCOMMON": "AgACAgEAAxkBAAIBtWl9REfL10s_kA36lqcWs6Jk4EocAAJUDGsbFc7oR3X_q1LYeEGYAQADAgADeQADOAQ",
"SHIELD_RARE": "AgACAgEAAxkBAAIBtml9REfvr6GvtkyrIowvCLMSfrJkAAJRDGsbFc7oR4nCdsu0OvbhAQADAgADeQADOAQ",
"SHIELD_EPIC": "AgACAgEAAxkBAAIBt2l9REcKvkZR5qcNjNEod1g0Ug-JAAJTDGsbFc7oR667sxHfQIXPAQADAgADeQADOAQ",
"SHIELD_LEGENDARY": "AgACAgEAAxkBAAIBuGl9REenTp7Dne-OfKeG5ru2S1UfAAJSDGsbFc7oR5OZ13mN8X6uAQADAgADeQADOAQ",

# ========= CRAFT: CINTURA =========
"BELT_COMMON": "AgACAgEAAxkBAAIBB2l44bAx8HfnvSosLkBW5Q04-WClAAKyNGsbSnjAR5l1ddwqYPpPAQADAgADeQADOAQ",
"BELT_UNCOMMON": "AgACAgEAAxkBAAIBCGl44bB3DEJerrZ7A2jDlM52WBuTAAKzNGsbSnjAR7RK6hFbOguFAQADAgADeQADOAQ",
"BELT_RARE": "AgACAgEAAxkBAAIBBml44bBvDVYZFYKg_Oz-ikOyZGODAAKxNGsbSnjAR0uDmReHvjCjAQADAgADeQADOAQ",
"BELT_EPIC": "AgACAgEAAxkBAAIBBWl44bCA-_qbUk7ntXXi3kXlG9BXAAKwNGsbSnjARxmLAsTWG6H9AQADAgADeQADOAQ",
"BELT_LEGENDARY": "AgACAgEAAxkBAAIBBGl44bA-4RrLojBXvtlS2qnCxXvrAAKvNGsbSnjAR5hO35IgDbeyAQADAgADeQADOAQ",

# ========= CRAFT: COLAR =========
"NECKLACE_COMMON": "AgACAgEAAxkBAAIBCWl44bCID1uqAxQw2lWgJUdY8UTFAAK0NGsbSnjAR4vrjKSI5mZYAQADAgADeQADOAQ",
"NECKLACE_UNCOMMON": "AgACAgEAAxkBAAIBCml44bBoe17WhGhoeWKZAfI_PcWXAAK1NGsbSnjAR9yGa6gl-UYQAQADAgADeQADOAQ",
"NECKLACE_RARE": "AgACAgEAAxkBAAIBC2l44bA5qWqkN_MvvyQoZrnBhAABIAACtjRrG0p4wEfI87iZP3p1ngEAAwIAA3kAAzgE",
"NECKLACE_EPIC": "AgACAgEAAxkBAAIBDGl44bA_2p9tgDUlCHP5WgMNyHncAAK3NGsbSnjAR2SNcO_heqh4AQADAgADeQADOAQ",
"NECKLACE_LEGENDARY": "AgACAgEAAxkBAAIBDWl44bD67JVNODsLRxlkkIol_JNlAAK4NGsbSnjARwy8XIhZ6eGGAQADAgADeQADOAQ",

# ========= CRAFT: ANEL =========
"RING_COMMON": "AgACAgEAAxkBAAIBFml44bIrsKKtE8Jzxeym2D_3GCxMAAK5NGsbSnjAR81X3Ziwbp4IAQADAgADeAADOAQ",
"RING_UNCOMMON": "AgACAgEAAxkBAAIBF2l44bLYXNnODxTr0vn46K8Fq2nZAAK6NGsbSnjAR3pciL-Vts-gAQADAgADeAADOAQ",
"RING_RARE": "AgACAgEAAxkBAAIBGGl44bLTY1QFB-tNd2xp_dqHUNh5AAK7NGsbSnjAR2zvjonnk_AlAQADAgADeAADOAQ",
"RING_EPIC": "AgACAgEAAxkBAAIBGWl44bLW0U8soBD6IyA4F78DTyPuAAK9NGsbSnjAR8aE-8-OsbUHAQADAgADeAADOAQ",
"RING_LEGENDARY": "AgACAgEAAxkBAAIBGml44bLnCm2Ae39tJXoiFbe3tlYeAAK-NGsbSnjARxyw6wpe5TFFAQADAgADeAADOAQ",

# ========= CRAFT: FALHA =========
"CRAFT_FAIL": "AgACAgEAAxkBAAIB5Wl-jr-_F0mw83P-Yp59xBAa41W0AAKFC2sbN3rwRy51nkdwxY8MAQADAgADeQADOAQ",
    # =========================================
    # 👹 MONSTROS (1-100) - GERADO AUTOMATICAMENTE
    # =========================================
    
    # --- (1-5) Goblins ---
    "MOB_GOBLIN_TANKER": "AgACAgEAAxkBAAIDEWmM0ux0IQ6zc8YOAAGO5eF3jwUupQACrQtrG2dgaERO6c3UnKIvTQEAAwIAA3kAAzoE",
    "MOB_GOBLIN_ESPADACHIM": "AgACAgEAAxkBAAIDEGmM0uzTWBtTCtXmfLxj0eJe_n6xAAKsC2sbZ2BoRMC9o96yzFudAQADAgADeQADOgQ",
    "MOB_GOBLIN_ARQUEIRO": "AgACAgEAAxkBAAIDD2mM0uxOUt6fGd3nQHAnvCmuqHrrAAKrC2sbZ2BoRNJcUXy9i4KDAQADAgADeQADOgQ",
    "MOB_CHEFE_GOBLIN": "AgACAgEAAxkBAAIDDmmM0uy8-fE3uOFznNKkKGoW9QloAAKqC2sbZ2BoREV9u9NzCr0cAQADAgADeQADOgQ",
    "MOB_XAMÃ_GOBLIN": "AgACAgEAAxkBAAIDDWmM0uyVHjwC0DUf2TQLBJMWhnHrAAKpC2sbZ2BoRFeOamBvVvbwAQADAgADeQADOgQ",
    "MOB_GOBLIN_ASSASSINO": "AgACAgEAAxkBAAIDDGmM0uwyD7xSNmTX5u8eX1-yMFrqAAKoC2sbZ2BoRHoVFbUEyT6oAQADAgADeQADOgQ",
    "MOB_REI_GOBLIN": "AgACAgEAAxkBAAIDC2mM0ux5xffXOJYNaDG_DyyP5VhIAAKnC2sbZ2BoRBp0d0HuXhBTAQADAgADeQADOgQ",

    # --- (6-10) Esqueletos ---
    "MOB_ESQUELETO_TANKER": "AgACAgEAAxkBAAIDP2mRvFl0N6G6Jnsuih05yCgd7KtcAAJwC2sbcfKIRLUwN7IIYquOAQADAgADeQADOgQ",
    "MOB_ESQUELETO_ESPADACHIM": "AgACAgEAAxkBAAIDPWmRvFlBRy_Yc6FY2Jhe1m0JteHtAAJuC2sbcfKIRK7yLCe2p-FhAQADAgADeQADOgQ",
    "MOB_ESQUELETO_ARQUEIRO": "AgACAgEAAxkBAAIDPmmRvFmNaO_HK9LnEQ1b-h1M0Hf1AAJvC2sbcfKIRPu50GRYDUQ-AQADAgADeQADOgQ",
    "MOB_CAPITÃO_ESQUELETO": "AgACAgEAAxkBAAIDOmmRvFmjGrKojGjQPQS-A8rhmHB1AAJrC2sbcfKIRK6JI_QK_bEcAQADAgADeQADOgQ",
    "MOB_NECROMANTE": "AgACAgEAAxkBAAIDO2mRvFkhDyU9u1lb_VRUdKENXVEiAAJsC2sbcfKIRDmn-gEl4hdjAQADAgADeQADOgQ",
    "MOB_ARQUEIRO_ESPECTRAL": "AgACAgEAAxkBAAIDPGmRvFkf9YQSSgspEd2z9k7YPNRKAAJtC2sbcfKIRP7Q4aMUnzeaAQADAgADeQADOgQ",
    "MOB_ESQUELETO_GIGANTE": "AgACAgEAAxkBAAIDOWmRvFlw67G7eH2-3cxaGhfiA1VYAAJqC2sbcfKIRLzWTmT7ozBMAQADAgADeQADOgQ",

    # --- (11-15) Formigas ---
    "MOB_FORMIGA_TANKER": "AgACAgEAAxkBAAIE7Gmlu7qYG0ReBCDxK61RpUg3jFZBAALbC2sbaGUxRUOCAAGVkJA4ZQEAAwIAA3kAAzoE",
    "MOB_FORMIGA_ESPADACHIM": "AgACAgEAAxkBAAIE62mlu7o9uO6lr03MFb3l_oPcCbVVAALaC2sbaGUxRUmEjYSZAUXjAQADAgADeQADOgQ",
    "MOB_FORMIGA_ARQUEIRO": "AgACAgEAAxkBAAIE6mmlu7qlse5ufF1_0OnMVjTr2WHjAALZC2sbaGUxRUfpl1mVD-YNAQADAgADeQADOgQ",
    "MOB_FORMIGA_GUERREIRA": "AgACAgEAAxkBAAIEzmmlu7HPUsBMMkT8GBoq6HTXw8hAAALcC2sbaGUxRQzA2NIbfLpUAQADAgADeAADOgQ",
    "MOB_FORMIGA_RAINHA_MENOR": "AgACAgEAAxkBAAIEz2mlu7EAAXKELoDVuhjcwdJNRU0FnAAC3QtrG2hlMUWD7HhsLPuzYQEAAwIAA3gAAzoE",
    "MOB_FORMIGA_SOLDADO": "AgACAgEAAxkBAAIE0Gmlu7HJA7dBrlIRAiR8iMD76hZvAALeC2sbaGUxRcy0Q9sPXLqgAQADAgADeAADOgQ",
    "MOB_FORMIGA_GENERAL": "AgACAgEAAxkBAAIE0Wmlu7HRi3x46a99HcxNG3mR7tb8AALfC2sbaGUxRYhLxl5KbK-ZAQADAgADeAADOgQ",

    # --- (16-20) Kobolds ---
     "MOB_KOBOLD_TANKER": "AgACAgEAAxkBAAIE12mlu7G3QWfdhcH3YhqZTywnjrE1AALlC2sbaGUxRaPJm8Bblj-8AQADAgADeQADOgQ",
    "MOB_KOBOLD_ESPADACHIM": "AgACAgEAAxkBAAIE1mmlu7G7G6sU-a4FIc1rzsr0ps91AALkC2sbaGUxRYxfwrLpyoGrAQADAgADeQADOgQ",
    "MOB_KOBOLD_ARQUEIRO": "AgACAgEAAxkBAAIE1Wmlu7H1VN8KJCvQnNRTl4A1Hs_OAALjC2sbaGUxRVovkWUmOTw3AQADAgADeQADOgQ",
    "MOB_KOBOLD_TRAPEIRO": "AgACAgEAAxkBAAIE02mlu7FzQsdUT3sbVcU0Y_T5XPulAALhC2sbaGUxRbSlEhLDOVvyAQADAgADeQADOgQ",
    "MOB_KOBOLD_FOGO": "AgACAgEAAxkBAAIE0mmlu7Fa8mYzMrwdtkSh2qUgsF9yAALgC2sbaGUxRbZ6DdHXxcpQAQADAgADeQADOgQ",
    "MOB_KOBOLD_SOMBRA": "AgACAgEAAxkBAAIE1Gmlu7GIe0r89GUoMGExhU7P2qIMAALiC2sbaGUxRQVhu0YfUyUqAQADAgADeQADOgQ",
    "MOB_XAMÃ_KOBOLD_DAS_CINZAS": "AgACAgEAAxkBAAIEzWmlu7HBhoDLLnUlA_-H2VOWpcv2AALnC2sbaGUxRbFhNdWrGgo7AQADAgADeQADOgQ",

    # --- (21-25) Orcs ---
     "MOB_ORC_TANKER": "AgACAgEAAxkBAAIEsWmlu1xXBdHPfYprHlABfFRvGr7wAALYC2sbaGUxRUPYAm8qz38ZAQADAgADeAADOgQ",
    "MOB_ORC_ESPADACHIM": "AgACAgEAAxkBAAIEvGmlu1yCHx6mCLBCFjCD_OSVHlrCAALXC2sbaGUxRSm5mjfc3MpQAQADAgADeAADOgQ",
    "MOB_ORC_ARQUEIRO": "AgACAgEAAxkBAAIEu2mlu1zk99WYASwXwYNy0dSSev5lAALWC2sbaGUxRYg1TdA65UyrAQADAgADeAADOgQ",
    "MOB_ORC_GUERREIRO": "AgACAgEAAxkBAAIEt2mlu1xOCeIIjolGojEcpxjdTrgEAALTC2sbaGUxRUNP1UuIIagvAQADAgADeAADOgQ",
    "MOB_ORC_XAMÃ": "AgACAgEAAxkBAAIEuGmlu1wg7WCR9_J2gK2Fngy9dv1cAALUC2sbaGUxRTe_vYZkggSAAQADAgADeAADOgQ",
    "MOB_ORC_BERSERK": "AgACAgEAAxkBAAIEuWmlu1xC2dxOk_bmgq-NDFRIaLY9AALVC2sbaGUxRYUE5CgowsF4AQADAgADeAADOgQ",
    "MOB_CHEFE_ORC_QUEBRA-OSSO": "AgACAgEAAxkBAAIEtmmlu1wdDCuOgpPCwxDoyitbb5TRAALSC2sbaGUxRVT6h8uDJdprAQADAgADeAADOgQ",

    # --- (26-30) Cultistas ---
    "MOB_CULTISTA_TANKER": "AgACAgEAAxkBAAIEsmmlu1y29g8MafMuNdf_1B8w-D6qAALOC2sbaGUxRdpc7ci10zxeAQADAgADeAADOgQ",
    "MOB_CULTISTA_ESPADACHIM": "AgACAgEAAxkBAAIEq2mlu1q3z9P_lcHYZ_WH07YoF92oAALMC2sbaGUxRUtDotvXSk93AQADAgADeAADOgQ",
    "MOB_CULTISTA_ARQUEIRO": "AgACAgEAAxkBAAIEqmmlu1oHaiCwV83vVOANePdqtz4aAALLC2sbaGUxRWyi9q01kblRAQADAgADeAADOgQ",
    "MOB_CULTISTA_MALDITO": "AgACAgEAAxkBAAIErGmlu1reThWmb12JyYP0yNkI08QrAALNC2sbaGUxRcevqORte4jDAQADAgADeAADOgQ",
    "MOB_CULTISTA_OBSCURO": "AgACAgEAAxkBAAIEtWmlu1zrQ-pmmyUaqsA7bnJIAVX1AALRC2sbaGUxRQtb_l9Q6TaOAQADAgADeAADOgQ",
    "MOB_CULTISTA_SUPREMO": "AgACAgEAAxkBAAIEtGmlu1xEGbFnGXJrhzeTNvlqJeW2AALQC2sbaGUxRT5KYIgcgmbzAQADAgADeAADOgQ",
    "MOB_SUMO-CULTISTA_DO_ABISMO": "AgACAgEAAxkBAAIEs2mlu1xcE18Ta5cNXpG6_0uAQIXxAALPC2sbaGUxRe1qa-lDWzHgAQADAgADeAADOgQ",

    # --- (31-35) Aranhas ---
     "MOB_ARANHA_TANKER": "AgACAgEAAxkBAAIEpWmlu1pHRcpANd8-L1NYmQq-vmNkAALHC2sbaGUxRU_qwDGvGuWfAQADAgADeAADOgQ",
    "MOB_ARANHA_ESPADACHIM": "AgACAgEAAxkBAAIEo2mlu1oQxAdjIKd-rzaSU-a36weJAALEC2sbaGUxReJCbxIPmPmiAQADAgADeAADOgQ",
    "MOB_ARANHA_ARQUEIRO": "AgACAgEAAxkBAAIEpmmlu1og0ukXbKUpenYQqGMLYMz1AALGC2sbaGUxRZnslbk1QbHeAQADAgADeAADOgQ",
    "MOB_ARANHA_VENENOSA": "AgACAgEAAxkBAAIEpGmlu1o3sSXfDfF9Qp2ruhp5q52RAALFC2sbaGUxRYFYbST2ewt7AQADAgADeAADOgQ",
    "MOB_ARANHA_GIGANTE": "AgACAgEAAxkBAAIEp2mlu1pGaZ8KYp5bjksB29e-RHmEAALIC2sbaGUxRV14Zqcd-z02AQADAgADeAADOgQ",
    "MOB_ARANHA_DA_SOMBRA": "AgACAgEAAxkBAAIEqWmlu1q3YPO3I8iXT63Lu4VKLLb_AALKC2sbaGUxRTgqPS6W6dVuAQADAgADeAADOgQ",
    "MOB_ARANHA-MÃE_COLOSSAL": "AgACAgEAAxkBAAIEqGmlu1pejZFbP-dpYEXCPNn_X8IFAALJC2sbaGUxRYbWavgkQvZAAQADAgADeAADOgQ",

    # --- (36-40) FADAS ---
     "MOB_FADA_TANKER": "AgACAgEAAxkBAAIHAAFpqNbr2LCmYN_xDr1wvFHgfBSnNwAChAtrG01XSUXxRnDofiqPxAEAAwIAA3gAAzoE",
    "MOB_FADA_ESPADACHIM": "AgACAgEAAxkBAAIHAWmo1utaMtrM9W_5IJ0K9_IWbFyZAAKFC2sbTVdJRcC0cK5xD--MAQADAgADeAADOgQ",
    "MOB_FADA_ARQUEIRO": "AgACAgEAAxkBAAIHAmmo1ushR5TrvHTy8mP8OV_0PRmAAAKGC2sbTVdJRd-xoTgJ2MWeAQADAgADeAADOgQ",
    "MOB_FADA_VENENOSA": "AgACAgEAAxkBAAIHA2mo1uvem0hhO-Aad3lrDcyRIry1AAKHC2sbTVdJRVRpsJWoRGPOAQADAgADeAADOgQ",
    "MOB_FADA_RAIZES": "AgACAgEAAxkBAAIHBWmo1uu80xV2ENDCTSdeLSLkOSvCAAKJC2sbTVdJRX0CPsGiGrdcAQADAgADeAADOgQ",
    "MOB_FADA_LUZ": "AgACAgEAAxkBAAIHBGmo1usxqD7nFfIfP5i7PTgQAAGghwACiAtrG01XSUUk2LWbDjSpFgEAAwIAA3gAAzoE",
    "MOB_FADA_RAINHA": "AgACAgEAAxkBAAIG-2mo1uvjo-OxFPKcbqZSDG8AARx9agACigtrG01XSUWtGfxPK_NfxQEAAwIAA3gAAzoE",

    # --- (41-45) Homens-Lagarto ---
     "MOB_LAGARTO_TANKER": "AgACAgEAAxkBAAIG82mo1unY7ebsPvLtTKs7zz290fp3AAJ3C2sbTVdJRYegglcu0ySAAQADAgADeAADOgQ",
    "MOB_LAGARTO_ESPADACHIM": "AgACAgEAAxkBAAIG8Wmo1ukRUq0Iabi4DiEL6n0I_sg8AAJ2C2sbTVdJRSVKZ_KHxOFYAQADAgADeAADOgQ",
    "MOB_LAGARTO_ARQUEIRO": "AgACAgEAAxkBAAIG8mmo1ulJ83xox2zxvx1SlFMvoN2OAAJ4C2sbTVdJRZMFWRefS4KZAQADAgADeAADOgQ",
    "MOB_LAGARTO_GUERREIRO": "AgACAgEAAxkBAAIG9Gmo1um_ZvSlmxluM17pvjnCyprsAAJ5C2sbTVdJRXdjjH4BC1abAQADAgADeAADOgQ",
    "MOB_LAGARTO_XAMÃ": "AgACAgEAAxkBAAIG9mmo1und69RAathTZfoKqPqwfXq_AAJ7C2sbTVdJRfRfn7dbBmQJAQADAgADeAADOgQ",
    "MOB_LAGARTO_PRIMORDIAL": "AgACAgEAAxkBAAIG9Wmo1ulF0ycvTnq8F140X1tfjtkRAAJ6C2sbTVdJRUkqQPHx0Kc1AQADAgADeAADOgQ",
    "MOB_XAMÃ_ESCAMADO_ANCIÃO": "AgACAgEAAxkBAAIG92mo1umHpA0KsRZMpCAkz1zdLUVjAAJ8C2sbTVdJReOb_DMH1FxIAQADAgADeAADOgQ",

    # --- (46-50) Gárgulas ---
     "MOB_GÁRGULA_TANKER": "AgACAgEAAxkBAAIG-mmo1ulkKCRtRk5ZB4FFEczESGQIAAJ_C2sbTVdJReSVwEX3D_SZAQADAgADeAADOgQ",
    "MOB_GÁRGULA_ESPADACHIM": "AgACAgEAAxkBAAIG-Gmo1umb4-ZgJ8ElYYmKZuT8poTOAAJ9C2sbTVdJRd0nLaa9EnxgAQADAgADeAADOgQ",
    "MOB_GÁRGULA_ARQUEIRO": "AgACAgEAAxkBAAIG-Wmo1ukP0U7QnIGVtKeZbu2eiqhCAAJ-C2sbTVdJRaSPEbBfGm8-AQADAgADeAADOgQ",
    "MOB_GÁRGULA_DE_PEDRA": "AgACAgEAAxkBAAIG_Gmo1usOizCX7z5lobTQI8kkUd6HAAKAC2sbTVdJRYZqp1zCf9JEAQADAgADeAADOgQ",
    "MOB_GÁRGULA_DA_NOITE": "AgACAgEAAxkBAAIG_mmo1uutRZfHlXJufTgXVbEsKjKUAAKCC2sbTVdJRSFeKlIwYlbbAQADAgADeAADOgQ",
    "MOB_GÁRGULA_ANTIGA": "AgACAgEAAxkBAAIG_Wmo1uv8I9yqF0Zv3qjQ02ISZA1dAAKBC2sbTVdJRWpE0n1o9_SqAQADAgADeAADOgQ",
    "MOB_GÁRGULA-GUARDIÃO_DO_PORTÃO": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",

    # --- (51-55) Elementais ---
    "MOB_ELEMENTAL": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE",
    "MOB_ELEMENTAL_DE_FOGO": "AgACAgEAAxkBAAIYZ2m0nK5FkeMPqwVJyZBJaOsIAhZ0AAKNC2sbdgapRexILFllIiMVAQADAgADeQADOgQ",
    "MOB_ELEMENTAL_DE_GELO": "AgACAgEAAxkBAAIYZWm0nK5zPPJdXK03sgrcPm2-SmjIAAKLC2sbdgapRXUGpJLMwokjAQADAgADeQADOgQ",
    "MOB_ELEMENTAL_DE_RAIO": "AgACAgEAAxkBAAIYZmm0nK4QOBdjYP4WaCVxQdA4Gl44AAKMC2sbdgapReOvmHOpz7YEAQADAgADeQADOgQ",
    "MOB_ELEMENTAL_PRISMA_(3_FASES)": "AgACAgEAAxkBAAIYaGm0nK6SQUS8zXCjTideo0kRIuQTAAKOC2sbdgapRWFWSctM1fOwAQADAgADeQADOgQ",

    # --- (56-60) Vampiros ---
    "MOB_VAMPIRO": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",
    "MOB_VAMPIRO_JOVEM": "AgACAgEAAxkBAAIYaWm0nK7x8def3MlZru7U1C4EEhN0AAKPC2sbdgapRempYuBKuomhAQADAgADeQADOgQ",
    "MOB_VAMPIRO_ANCESTRAL": "AgACAgEAAxkBAAIYamm0nK6lWUWeTYBq2neKnCtBIBhBAAKQC2sbdgapRe4cQbA5l5y7AQADAgADeQADOgQ",
    "MOB_ABOMINAÇÃO_VAMPÍRICA": "AgACAgEAAxkBAAIYa2m0nK72vW1BGf53SjG3ZwSoo0e7AAKRC2sbdgapRcXBH5Rq8mR7AQADAgADeQADOgQ",
    "MOB_CONDE_DA_CRIPTA": "AgACAgEAAxkBAAIYbGm0nK7ZzHC1eJ6-mIpJHd52GCt1AAKSC2sbdgapRSh1Ibw4VlcKAQADAgADeQADOgQ",

    # --- (61-65) Golems ---
    "MOB_GOLEM": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",
    "MOB_GOLEM_DE_ARGILA": "AgACAgEAAxkBAAJI6GnQc0cHIrSN-_y6D4PHWRwFQRe1AAJlDGsbQpOJRkjhTyG_sy6iAQADAgADeQADOwQ",
    "MOB_GOLEM_DE_FERRO": "AgACAgEAAxkBAAJI6mnQc3WKgu-PJAgUzTbf3OxCtzwCAAJmDGsbQpOJRozLHi8O6PYXAQADAgADeQADOwQ",
    "MOB_GOLEM_DE_RUNA": "AgACAgEAAxkBAAJI7GnQdF3P4cWFPxpj79V-m95KOGj0AAJnDGsbQpOJRiLSshi5egyqAQADAgADeQADOwQ",
    "MOB_GOLEM_RÚNICO_DE_OBSIDIANA": "AgACAgEAAxkBAAJI7mnQdWypmIpyCS8OqgsHsgUoNFOMAAJoDGsbQpOJRmB9-XKUJHh3AQADAgADeQADOwQ",

    # --- (66-70) Demônios ---
    "MOB_DEMÔNIO": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",
    "MOB_DEMÔNIO_MENOR": "AgACAgEAAxkBAAJI4GnQbp67tO47BAHfqVsg_3MInwzmAAJaDGsbQpOJRq5AmxgINa9eAQADAgADeQADOwQ",
    "MOB_DEMÔNIO_MAIOR": "AgACAgEAAxkBAAJI4mnQbxP2TfX5VjduspuIYeSaDt9FAAJdDGsbQpOJRvNc3NFmE6cxAQADAgADeQADOwQ",
    "MOB_DEMÔNIO_PRIMORDIAL": "AgACAgEAAxkBAAJI5mnQb8Eeu2B1Ow-m4IR43e_h_KYPAAJfDGsbQpOJRnFl6J0aqQ_dAQADAgADeQADOwQ",
    "MOB_MARECHAL_INFERNAL": "AgACAgEAAxkBAAJI5GnQb3wVjwFcu9qWkK2u8U-djixQAAJeDGsbQpOJRmpEJmjtX3o6AQADAgADeQADOwQ",

    # --- (71-75) Aberrações ---
    "MOB_ABERRAÇÃO": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",
    "MOB_ABERRAÇÃO_MUTANTE": "AgACAgEAAxkBAAJI3GnQbZrnB_Lkul7jscZrUEL00UCzAAJYDGsbQpOJRjQWM-Q7gMFrAQADAgADeQADOwQ",
    "MOB_ABERRAÇÃO_VORAZ": "AgACAgEAAxkBAAJI2mnQbWwoijoPZAaJSr0hj4XhD_5MAAJXDGsbQpOJRmv_lNrjUXfBAQADAgADeQADOwQ",
    "MOB_ABERRAÇÃO_PERFEITA": "AgACAgEAAxkBAAJI2GnQbTlGi2PKYbHO5tD3zacUqDCRAAJWDGsbQpOJRk-qwjgDPoPmAQADAgADeQADOwQ",
    "MOB_MASSA_DEVORADORA": "AgACAgEAAxkBAAJI1mnQbM1jESo20rgSFiR7c-uxs8kpAAJVDGsbQpOJRvETq4y3Aq3IAQADAgADeQADOwQ",

    # --- (76-80) Cavaleiros Malditos ---
    "MOB_CAVALEIRO_MALDITO": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",
    "MOB_CAVALEIRO_NEGRO": "AgACAgEAAxkBAAJI0GnQalpXHUXR3IZwBu6r4HyHO9UUAAJSDGsbQpOJRrvoUKZOUAnkAQADAgADeQADOwQ",
    "MOB_CAVALEIRO_ESPECTRAL": "AgACAgEAAxkBAAJI0mnQa0BVeSdpi0wL3wU9yKr4Um96AAJTDGsbQpOJRuExVf4i2cB3AQADAgADeQADOwQ",
    "MOB_CAVALEIRO_ARRUINADO": "AgACAgEAAxkBAAJIzmnQafacMirRjZK0WNiSI4FwIPaNAAJRDGsbQpOJRrCi-vrbkvY-AQADAgADeQADOwQ",
    "MOB_PALADINO_CAÍDO_DO_JURAMENTO": "AgACAgEAAxkBAAJI1GnQbDve9UxXCupFjG_L8zRSQzgnAAJUDGsbQpOJRpFwtAj6zcKtAQADAgADeQADOwQ",

    # --- (81-85) Drakes ---
    "MOB_DRAKE": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",
    "MOB_DRAKE_DE_FOGO": "AgACAgEAAxkBAAJIymnQaSX5OezAfh7NJ8xlY1PSZk60AAJPDGsbQpOJRtHEcins_-dqAQADAgADeQADOwQ",
    "MOB_DRAKE_DE_GELO": "AgACAgEAAxkBAAJIzGnQaWhWnRYY_FhaK-ckM1J7xmTwAAJQDGsbQpOJRpVf4wYLr6t2AQADAgADeQADOwQ",
    "MOB_DRAKE_DE_TEMPESTADE": "AgACAgEAAxkBAAJIyGnQaMtZrWboRJXsUBLtd3FPJ9LkAAJODGsbQpOJRvSE8xPrRP97AQADAgADeQADOwQ",
    "MOB_DRACO_GUARDIÃO_DE_DUAS_CORES": "AgACAgEAAxkBAAJI3mnQbeLQB4EeOI86creroT8g0DQgAAJZDGsbQpOJRi-2jXzUqIe7AQADAgADeQADOwQ",

    # --- (86-90) Gigantes ---
    "MOB_GIGANTE": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",
    "MOB_GIGANTE_DA_MONTANHA": "AgACAgEAAxkBAAJIxmnQaHdS6l8r02ErXQYglDY9WJk9AAJNDGsbQpOJRq9BxT4tkTmqAQADAgADeQADOwQ",
    "MOB_GIGANTE_DE_PEDRA": "AgACAgEAAxkBAAJIxGnQaDU4HXp1X_vUdZLwJh4xPoRFAAJMDGsbQpOJRs_cdpjsHTxWAQADAgADeQADOwQ",
    "MOB_GIGANTE_DO_CAOS": "AgACAgEAAxkBAAJIwGnQZ7mF0nYxl-JZyd1A1GzVOW4AA0oMaxtCk4lGIrZ_cxRM9R0BAAMCAAN5AAM7BA",
    "MOB_TITÃ_DAS_RUÍNAS": "AgACAgEAAxkBAAJIwmnQZ_9HqnAakn_oCe_7khi8WyH-AAJLDGsbQpOJRnK-dZB2gYMPAQADAgADeQADOwQ",

    # --- (91-95) Anjos Corrompidos ---
    "MOB_ANJO_CORROMPIDO": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",
    "MOB_ANJO_DECAÍDO": "AgACAgEAAxkBAAJIumnQZv6Bhj0ZEdCpnIMMSjZ95UTxAAJHDGsbQpOJRtiT-KV4Iqd4AQADAgADeQADOwQ",
    "MOB_ANJO_SOMBRIO": "AgACAgEAAxkBAAJIvGnQZyeKb0qEjyl7KIhnUZtmE49bAAJIDGsbQpOJRgNyeGX56FCzAQADAgADeQADOwQ",
    "MOB_ANJO_ABOMINADO": "AgACAgEAAxkBAAJIvmnQZ1O5xHSP_7k1tLAZNyi3AsNdAAJJDGsbQpOJRl3ktznGjke5AQADAgADeQADOwQ",
    "MOB_SERAFIM_DECAÍDO": "AgACAgEAAxkBAAJIuGnQZsiteXgI3v-jbiWUfDxIXnWrAAJGDGsbQpOJRk6IqB4rEsQQAQADAgADeQADOwQ",

    # --- (96-100) Entidades do Vazio ---
    "MOB_ENTIDADE_DO_VAZIO": "AgACAgEAAxkBAAIG_2mo1utk9QSr-N4wqmXcUfRmAAHKTwACgwtrG01XSUXhVCKTXMHwegEAAwIAA3gAAzoE0",
    "MOB_ENTIDADE_MENOR": "AgACAgEAAxkBAAJIs2nQZZfKYNlgCLouPHkSnVgYaPiVAAJEDGsbQpOJRrrd6ZFlE3zRAQADAgADeQADOwQ",
    "MOB_ENTIDADE_MAIOR": "AgACAgEAAxkBAAJItmnQZhew3Wy_hfnb4aiXq2t3QtjSAAJFDGsbQpOJRjSB_HHDXPXSAQADAgADeQADOwQ",
    "MOB_ENTIDADE_SUPREMA": "AgACAgEAAxkBAAJIsWnQZVdyHb_08uQRpv7UUo7qjL0ZAAJDDGsbQpOJRszA1jki4U1FAQADAgADeQADOwQ",
    "MOB_NÚCLEO_DO_VAZIO_(4_FASES_+_ENRAGE)": "AgACAgEAAxkBAAJIr2nQZQe85Bs1dVuj_w9B-Jx5aUnGAAJCDGsbQpOJRhBF9XjPLZQVAQADAgADeQADOwQ",
   
 #⚪ COMUNS
    "PET_PET_C_LOBO": "AgACAgEAAxkBAAJIHmnPttumW3GnuZbJToyaIhJKmmlYAALDC2sbQpOBRkfdK3RrbtxaAQADAgADeQADOgQ",
    "PET_PET_C_JAVALI": "AgACAgEAAxkBAAJIJGnPuJ_bdjVHLCGrdQjzGCy6It-LAALFC2sbQpOBRvmeqK3AFkjkAQADAgADeQADOgQ",
    "PET_PET_C_FADA": "AgACAgEAAxkBAAJIJmnPuL0ZQGO2tO0XH172NJU086PUAALGC2sbQpOBRjwFLIsAAcKLeQEAAwIAA3kAAzoE",
    "PET_PET_C_MORCEGO": "AgACAgEAAxkBAAJIKGnPuNgxxLYoebXBdahgIO_AXu6rAALHC2sbQpOBRoLjrCTnYvRWAQADAgADeQADOgQ",
    "PET_PET_C_WISP": "AgACAgEAAxkBAAJIHGnPtimmh0bJw419RysLa4mvUnkHAALCC2sbQpOBRrz0HdF26uSnAQADAgADeQADOgQ",
    #🟢 INCOMUNS
    "PET_PET_U_PANTERA": "AgACAgEAAxkBAAJILGnPuSDe7tFOJZ9zEnzQ-A4DiTBNAALIC2sbQpOBRpmTzg7i8vKKAQADAgADeQADOgQ",
    "PET_PET_U_GOLEM_BARRO": "AgACAgEAAxkBAAJILmnPuYn9jg_YwRIVOG4hYoBwNMBSAALJC2sbQpOBRljEEdfFZge4AQADAgADeQADOgQ",
    "PET_PET_U_NINFA": "AgACAgEAAxkBAAJIMGnPuaOptnjq5CeccfRCu2awlKfkAALKC2sbQpOBRlq1OdzebGaLAQADAgADeQADOgQ",
    "PET_PET_U_RAPOSA": "AgACAgEAAxkBAAJIMmnPucOHFCz2VQ4i9UAqTdojkinVAALLC2sbQpOBRi05VSyZmx8aAQADAgADeQADOgQ",
    "PET_PET_U_ESPIRITO_FOGO": "AgACAgEAAxkBAAJINGnPudrFwZ5o5NlMyBfN1vfEktXxAALMC2sbQpOBRuGfsT9LP4tIAQADAgADeQADOgQ",
    #🔵 RAROS
    "PET_PET_R_TIGRE": "AgACAgEAAxkBAAJINmnPugSmfRLl6vdzeuftyooNFTIUAALNC2sbQpOBRrOyNV_AsmjrAQADAgADeQADOgQ",
    "PET_PET_R_GOLEM_PEDRA": "AgACAgEAAxkBAAJIOGnPuiEsBvZjCPR2gzZMKX49lntkAALOC2sbQpOBRpQ5icp5_m5vAQADAgADeQADOgQ",
    "PET_PET_R_SIRENA": "AgACAgEAAxkBAAJIOmnPukRfinpYoDF0Jdx85wbavA5cAALPC2sbQpOBRvUXdjyNSVoVAQADAgADeQADOgQ",
    "PET_PET_R_GRIFO": "AgACAgEAAxkBAAJIPGnPul95Ll3kG3QxtnKAWp2GrncEAALQC2sbQpOBRrl-61md9eDqAQADAgADeQADOgQ",
    "PET_PET_R_ORACULO": "AgACAgEAAxkBAAJIPmnPunbxoJ3oudLI94xg7PLQZLUcAALRC2sbQpOBRh5mvlCRxkoaAQADAgADeQADOgQ",
    #🟣 ÉPICOS
    "PET_PET_E_LEAO_GUERRA": "AgACAgEAAxkBAAJISGnPuyFthNOT2DCfMFd1JlB0Q1SdAALWC2sbQpOBRsB5dI7BhTS6AQADAgADeQADOgQ",
    "PET_PET_E_URSO_CORUJA": "AgACAgEAAxkBAAJIQGnPuqmeSokZAnQik3IwrLJv-cBWAALSC2sbQpOBRmxUAXJTPeAzAQADAgADeQADOgQ",
    "PET_PET_E_TARTARUGA": "AgACAgEAAxkBAAJIQmnPurWGqz14dhmeMEBYzq0B3-QHAALTC2sbQpOBRsTRPx_92XFWAQADAgADeQADOgQ",
    "PET_PET_E_RINOCERONTE": "AgACAgEAAxkBAAJIRGnPutT1p3oO8jUqtIPod7KYnj9rAALUC2sbQpOBRiDTVpwaE-lYAQADAgADeQADOgQ",
    "PET_PET_E_UNICORNIO": "AgACAgEAAxkBAAJIRmnPut9wnjKq8vm_vWW3NOdhKcB3AALVC2sbQpOBRpCUbBcMTclOAQADAgADeQADOgQ",
    "PET_PET_E_TREANT": "AgACAgEAAxkBAAJISmnPuzbSbGxbLpOqL1F4DbNMFoy0AALXC2sbQpOBRow7mI1iikBkAQADAgADeQADOgQ",
    "PET_PET_E_CORVO": "AgACAgEAAxkBAAJITGnPu4Fi3c5LOqf3j_LUm3QGWPvpAALYC2sbQpOBRmIY1qCrmUpvAQADAgADeQADOgQ",
    "PET_PET_E_FALCAO": "AgACAgEAAxkBAAJITmnPu46TvAPHtBRve7NgpZ15Fn9cAALZC2sbQpOBRucGk4n_cRxEAQADAgADeQADOgQ",
    "PET_PET_E_FADA_RAINHA": "AgACAgEAAxkBAAJIUGnPu5wPD05_jWXiF4ndupZ0XRoZAALaC2sbQpOBRs3W6yhqdwHTAQADAgADeQADOgQ",
    "PET_PET_E_SAPO": "AgACAgEAAxkBAAJIWGnPvIzfVZa3sR9glP4djaSQDSqcAALeC2sbQpOBRjVMoEy9CJk-AQADAgADeQADOgQ",
    #⭐ LENDÁRIOS
    #🐲 Família dos Dragões:
    "PET_PET_L_DRAGAO_FOGO": "AgACAgEAAxkBAAJIUmnPu6yh5KJrCI074TOL0ee1LVLcAALbC2sbQpOBRt6mFGESr3TJAQADAgADeQADOgQ",
    "PET_PET_L_DRAGAO_GELO": "AgACAgEAAxkBAAJIWmnPvLDchBbmfNtNhftu8x3TidLBAALfC2sbQpOBRuCj3S3YhYKjAQADAgADeQADOgQ",
    "PET_PET_L_DRAGAO_TROVAO": "AgACAgEAAxkBAAJIVGnPvDGwlMfL7pghKt026dlTdoDoAALcC2sbQpOBRhVqI89YeXjRAQADAgADeQADOgQ",
    "PET_PET_L_DRAGAO_VENENO": "AgACAgEAAxkBAAJIVmnPvD4L4MTS6YXeI8NLn4H6eAVHAALdC2sbQpOBRutVUV7YYbmdAQADAgADeQADOgQ",
    "PET_PET_L_DRAGAO_REI": "AgACAgEAAxkBAAJIXGnPvMyMfYISOU6fTbv8HtVeIsZiAALgC2sbQpOBRsy7ndTPpMAOAQADAgADeQADOgQ",
    #🏰 Família dos Titãs:
    "PET_PET_L_TITA_FERRO": "AgACAgEAAxkBAAJIXmnPvQVckKQIdWPpqPzBTMu5KRWxAALhC2sbQpOBRn7oGVwMJFE1AQADAgADeQADOgQ",
    "PET_PET_L_TITA_MAGMA": "AgACAgEAAxkBAAJIYGnPvRUksGOWWke-z4vfuOii2fVzAALiC2sbQpOBRmG7Br31NkQAAQEAAwIAA3kAAzoE",
    "PET_PET_L_TITA_GELO": "AgACAgEAAxkBAAJIYmnPvTgMW_qbnPX22kUwCLbUFY-tAALjC2sbQpOBRpJkVGkiR-XZAQADAgADeQADOgQ",
    "PET_PET_L_TITA_CRISTAL": "AgACAgEAAxkBAAJIZGnPvVCtXiu0aBox3egI5oCnEpHgAALkC2sbQpOBRr92wgcWnL35AQADAgADeQADOgQ",
    "PET_PET_L_TITA_COLOSSAL": "AgACAgEAAxkBAAJIZmnPvXQ-3zWnicjUF5B0hFChjUDHAALlC2sbQpOBRkdQa81XOdHXAQADAgADeQADOgQ",
    #🧚 Família das Fadas:
    "PET_PET_L_FADA_VENTO": "AgACAgEAAxkBAAJIaGnPvZcyicqRGav5g-MhzUmy9GphAALmC2sbQpOBRigvEnKbQS3kAQADAgADeQADOgQ",
    "PET_PET_L_FADA_LUA": "AgACAgEAAxkBAAJIamnPvaMVJlNcSyvYIMSYgPdLFxxbAALnC2sbQpOBRsDZSm1CUgiqAQADAgADeQADOgQ",
    "PET_PET_L_FADA_SOL": "AgACAgEAAxkBAAJIbGnPvdEXwM_crYwzROB3dAzWv4NKAALoC2sbQpOBRlTI5PrfYV8xAQADAgADeQADOgQ",
    "PET_PET_L_FADA_ASTRAL": "AgACAgEAAxkBAAJIbmnPveIGnFr6aeBmvNXIjqy_Tp16AALpC2sbQpOBRpoe5djZq9UXAQADAgADeQADOgQ",
    "PET_PET_L_TITANIA": "AgACAgEAAxkBAAJIdGnPvp3575Wov7WT_2R4oJcftpOgAALrC2sbQpOBRupbTGygW8WcAQADAgADeQADOgQ",
    #🦇 Família dos Vampiros:
    "PET_PET_L_VAMPIRO_NOBRE": "AgACAgEAAxkBAAJIcmnPvi-JPX-qImRXrDOYvUhSw_cfAALqC2sbQpOBRoWmmqr6WB6RAQADAgADeQADOgQ",
    "PET_PET_L_SUCUBUS": "AgACAgEAAxkBAAJIgGnPwDk3vKYptXy1OVpkcZMqoIMxAALxC2sbQpOBRquQiaNrUFZuAQADAgADeQADOgQ",
    "PET_PET_L_GARGULA": "AgACAgEAAxkBAAJIgmnPwJ8MYaOxhTUgYktOlsoz3h6kAALyC2sbQpOBRg-D8S6_iP6qAQADAgADeQADOgQ",
    "PET_PET_L_CAVALEIRO_MORTE": "AgACAgEAAxkBAAJIhGnPwsDtmQi9exAW4GBkgD9_PIuAAALzC2sbQpOBRj5yOPJc1gI4AQADAgADeQADOgQ",
    "PET_PET_L_DRACULA": "AgACAgEAAxkBAAJIhmnPwt1Qkw7IUouiBg_LCmDfXwiGAAL0C2sbQpOBRkACLYMcwqj8AQADAgADeQADOgQ",
    #👑 Família Divina / Anjos:
    "PET_PET_L_ANJO_FORTUNA": "AgACAgEAAxkBAAJIdmnPvtUka9KTRnGnxAG1888b-VE1AALsC2sbQpOBRhaMzeephb79AQADAgADeQADOgQ",
    "PET_PET_L_ANJO_CONHECIMENTO": "AgACAgEAAxkBAAJIeGnPvv-XhVLP9hgubB1Fxr8lO0-RAALtC2sbQpOBRs49le799GBoAQADAgADeQADOgQ",
    "PET_PET_L_ANJO_FORJA": "AgACAgEAAxkBAAJIemnPvx64qnmpDF6pmgc1IPwYkWNAAALuC2sbQpOBRqWX8K9n7LPAAQADAgADeQADOgQ",
    "PET_PET_L_ANJO_TEMPO": "AgACAgEAAxkBAAJIfGnPv0lZEaQjGXKem2w06nyZMXnvAALvC2sbQpOBRlC_UjaVoYKaAQADAgADeQADOgQ",
    "PET_PET_L_ARCANJO_SUPREMO": "AgACAgEAAxkBAAJIfmnPv2rJT4YDVP4TZgI25yiAwnSuAALwC2sbQpOBRikF252mL9pfAQADAgADeQADOgQ",




}

# 🖼️ Imagens genéricas pra tela de "saiu da batalha" (08/07/2026), trocadas
# conforme o que dropou. Por enquanto apontam pra imagem da cidade (não
# quebra nada) — quando tiver a arte, é só mandar a foto pro bot (ele
# devolve o file_id) e colar aqui:
#   ASSETS["DROP_GOLD"] = "AgACAgEAAxk..."
ASSETS["DROP_GOLD"] = ASSETS["CITY"]    # só ganhou ouro/XP, sem core nenhum
ASSETS["DROP_SKILL"] = ASSETS["CITY"]   # dropou um core de SKILL (mágica)
ASSETS["DROP_CRAFT"] = ASSETS["CITY"]   # dropou um core de FORJA (craft)

DEFAULT_ASSET_KEY = "CITY"





# ... aqui fica o dicionário ASSETS enorme que você já tem ...

DEFAULT_ASSET_KEY = "CITY"


import json as _json
import os as _os

# Arquivo onde os file_ids enviados pelo admin ficam salvos. Fica em data/
# (mesma pasta do banco), que persiste entre reinícios no SquareCloud.
_ASSETS_CACHE_PATH = _os.path.join("data", "assets_cache.json")


def _carregar_assets_salvos() -> None:
    """Na inicialização, sobrepõe o ASSETS do código com os file_ids que o
    admin enviou pelo bot (salvos em disco). 🔥 (09/07/2026): antes, imagens
    enviadas pelo bot só viviam na memória e SUMIAM quando o SquareCloud
    reiniciava. Agora elas persistem."""
    try:
        if _os.path.exists(_ASSETS_CACHE_PATH):
            with open(_ASSETS_CACHE_PATH, "r", encoding="utf-8") as f:
                salvos = _json.load(f)
            if isinstance(salvos, dict):
                # Normaliza o que veio do disco: o cache de produção foi
                # escrito antes desta regra e tem chave acentuada dentro.
                ASSETS.update({(normalizar_chave(k) or k): v
                               for k, v in salvos.items()})
                print(f"🖼️ [ASSETS] {len(salvos)} imagem(ns) carregada(s) do disco.")
    except Exception as e:
        print(f"⚠️ [ASSETS] Falha ao carregar imagens salvas: {e}")


import unicodedata as _ud
import re as _re

_RE_LIXO = _re.compile(r"[^A-Za-z0-9_]+")


def normalizar_chave(chave: str) -> str:
    """Tira acento e pontuação da chave de asset.

    POR QUE (20/09/2026): a chave é o NOME DO ARQUIVO no espelho local, e
    `webapp/imagens.chave_valida` só aceita `[A-Za-z0-9_-]`. Chave com
    acento nunca foi baixada pro disco e `/api/imagem` devolvia 400 nela —
    ou seja, toda raça acentuada (Gárgula, Demônio, Aberração...) ficava
    sem arte no site, sem erro visível.

    E havia o lado gêmeo: `resolver_asset_key_inimigo` trocava SÓ alguns
    acentos (Ã Á É Í Ó Ú Ç) e só no caminho de elite/boss. Então 24 artes
    existiam gravadas com acento (`MOB_XAMÃ_GOBLIN`) e o jogo pedia outra
    chave (`MOB_XAMA_GOBLIN`): arte no disco, invisível pra sempre.

    Uma função só resolve os dois lados — desde que TODO mundo passe por
    ela, tanto quem pede quanto quem grava. É o que `_normalizar_assets()`
    garante no import.
    """
    plano = _ud.normalize("NFD", str(chave or ""))
    plano = "".join(c for c in plano if _ud.category(c) != "Mn")
    plano = plano.upper().replace(" ", "_").replace("-", "_")
    plano = _RE_LIXO.sub("_", plano)
    return _re.sub(r"_+", "_", plano).strip("_")


def _normalizar_assets() -> None:
    """Renomeia, no import, toda chave acentuada do ASSETS pra forma
    normalizada — sem duplicar: a chave velha SAI.

    Renomear em vez de criar apelido é de propósito. Apelido deixaria duas
    chaves com o mesmo file_id, e aí o catálogo do /admin passaria a dizer
    'divide arte' pra dezenas de monstros que na verdade têm arte própria:
    o painel que existe pra medir o buraco começaria a mentir sobre ele.
    """
    for chave in list(ASSETS):
        plano = normalizar_chave(chave)
        if plano and plano != chave:
            # Chave já normalizada no código ganha: quem foi escrito à mão
            # com o nome certo não pode ser sobrescrito pelo acentuado.
            ASSETS.setdefault(plano, ASSETS[chave])
            del ASSETS[chave]


_normalizar_assets()


def get_asset(key: str) -> str:
    """Pega o file_id salvo para a key. Normaliza antes: chamador antigo
    que ainda passe a chave acentuada continua achando a arte."""
    if key in ASSETS:
        return ASSETS[key]
    return ASSETS.get(normalizar_chave(key), ASSETS.get(DEFAULT_ASSET_KEY))


# 🖼️ (09/07/2026): extraído do que já existia (duplicado) em
# view_combat e na resolução de imagem do inventário/craft. Agora é UMA
# função só, reaproveitada pelo bot E pelo Mini App — evita o mesmo tipo
# de divergência silenciosa que já pegamos algumas vezes neste projeto
# (duas cópias da mesma lógica que vão se desatualizando com o tempo).

def resolver_asset_key_inimigo(target_mob: dict) -> str:
    """Monta a chave de asset (ex: MOB_FORMIGA_GENERAL) pro inimigo em foco
    num combate — mesma lógica que já existia dentro de view_combat."""
    if not target_mob:
        return "COMBAT"

    # 20/09/2026: a limpeza do nome agora é `normalizar_chave` pros DOIS
    # caminhos. Antes o caminho normal (`raca`) não tirava acento nenhum e
    # o de elite/boss tirava só sete letras — era essa metade de regra que
    # deixava a arte gravada num nome e pedida noutro.
    raca = normalizar_chave(target_mob.get("raca_nome", "MOB"))
    arq_raw = target_mob.get("arquetipo")
    tipo = target_mob.get("tipo", "normal")

    if tipo in ("boss", "elite", "general"):
        name_clean = normalizar_chave(str(target_mob.get("name", "mob")).split(" #")[0])
        return f"MOB_{name_clean}"

    arq = "TANKER"
    if arq_raw:
        arq = str(arq_raw).split("_")[0].upper()
    else:
        nome_upper = str(target_mob.get("nome", "")).upper()
        if "ARQUEIRO" in nome_upper:
            arq = "ARQUEIRO"
        elif "ESPADACHIM" in nome_upper:
            arq = "ESPADACHIM"
    return f"MOB_{raca}_{arq}"


SEXOS = {"m": "Masculino", "f": "Feminino"}


def resolver_asset_key_jogador(race_id: str | None = None, sexo: str | None = None) -> str:
    """Chave da arte do JOGADOR na ficha, no topo e no combate.

    Era `STATUS` fixo: a mesma imagem pra todo mundo, em todas as telas.
    Agora cada combinação de raça e sexo tem a sua — `STATUS_ELFO_F` — e
    quem não tiver arte própria cai, nesta ordem, em `STATUS_<RAÇA>` e
    depois no `STATUS` de sempre. Ou seja: pode subir a arte de uma raça
    de cada vez, e ninguém fica sem retrato no meio do caminho.

    A chave passa por `normalizar_chave` como todas as outras, então raça
    acentuada (Anão, Meio-Elfo) não recria o buraco de 20/09.
    """
    if not race_id:
        return "STATUS"
    base = normalizar_chave(f"STATUS_{race_id}")
    s = str(sexo or "").strip().lower()[:1]
    if s in SEXOS:
        com_sexo = f"{base}_{s.upper()}"
        if tem_arte(com_sexo):
            return com_sexo
    if tem_arte(base):
        return base
    return "STATUS"


def tem_arte(chave: str) -> bool:
    """🐛 (26/09/2026) a arte existe se está no ASSETS antigo OU foi enviada
    pelo /admin (arquivo em disco). Antes só olhava o ASSETS: retrato de
    raça enviado pelo admin nunca era achado e a ficha mostrava sempre o
    STATUS padrão."""
    if ASSETS.get(chave):
        return True
    try:
        from webapp.imagens import tem_local, chave_valida
        return bool(chave_valida(chave) and tem_local(chave))
    except Exception:
        return False


def resolver_asset_key_item(slot: str, rar: str, sub: str = "") -> str:
    """Monta a chave de asset (ex: WEAPON_SWORD_LEGENDARY) pra um item —
    mesma lógica que já existia dentro do carrossel de inventário."""
    rar_raw = str(rar or "common").strip().lower()
    mapa_raridade = {
        "comum": "COMMON", "common": "COMMON",
        "incomum": "UNCOMMON", "uncommon": "UNCOMMON",
        "raro": "RARE", "rare": "RARE",
        "épico": "EPIC", "epico": "EPIC", "epic": "EPIC",
        "lendário": "LEGENDARY", "lendario": "LEGENDARY", "legendary": "LEGENDARY",
    }
    safe_rar = mapa_raridade.get(rar_raw, rar_raw.upper())
    safe_slot = str(slot or "").upper()

    if sub:
        return f"{safe_slot}_{str(sub).upper()}_{safe_rar}"
    return f"{safe_slot}_{safe_rar}"


def asset_faltando(key: str) -> bool:
    """True se o asset ainda NÃO tem imagem própria — ou seja, está caindo
    no fallback (aponta pro mesmo file_id do DEFAULT/CITY, ou não existe).
    É isso que o botão 'enviar imagem' usa pra saber o que falta."""
    fid = ASSETS.get(key)
    if not fid:
        return True
    # se aponta pro mesmo file_id do fallback padrão, é imagem emprestada
    return fid == ASSETS.get(DEFAULT_ASSET_KEY) and key != DEFAULT_ASSET_KEY


# ==== NOVO: helpers para fallback de file_id inválido ====


def get_local_path(key: str) -> str:
    """
    Retorna o caminho local da imagem para esse asset.
    Ajuste os caminhos conforme sua estrutura de arquivos.
    Exemplo: assets/CITY.jpg, assets/mobs/MOB_NECROMANTE.png, etc.
    """
    # Exemplo simples: todas as artes .jpg numa pasta assets/
    # se você usa .png, troque a extensão.
    # Você pode personalizar por prefixo (CITY/TOWER/HOSPITAL vs MOB_...)
    base = "assets"

    # Se você tiver subpastas, pode tratar aqui:
    if key.startswith("MOB_") or key.startswith("BOSS_"):
        return f"{base}/mobs/{key}.jpg"
    elif key.startswith("WEAPON_") or key.startswith("ARMOR_"):
        return f"{base}/items/{key}.jpg"
    else:
        return f"{base}/{key}.jpg"


def save_asset(key: str, file_id: str) -> None:
    """Atualiza o file_id em memória E persiste em disco, pra sobreviver aos
    reinícios do servidor. 🔥 (09/07/2026): antes só salvava em memória (o
    json.dump estava comentado), então toda imagem enviada pelo bot sumia
    quando o SquareCloud reiniciava.

    20/09/2026: a chave é normalizada antes de gravar. Sem isso, arte nova
    mandada pelo bot com nome acentuado voltaria a cair no mesmo buraco —
    gravada num nome, pedida noutro."""
    key = normalizar_chave(key) or key
    ASSETS[key] = file_id

    # Persiste SÓ as imagens enviadas pelo admin (não o dict inteiro do
    # código), lendo o que já tem no disco e mesclando a nova.
    try:
        _os.makedirs(_os.path.dirname(_ASSETS_CACHE_PATH), exist_ok=True)
        salvos = {}
        if _os.path.exists(_ASSETS_CACHE_PATH):
            with open(_ASSETS_CACHE_PATH, "r", encoding="utf-8") as f:
                salvos = _json.load(f)
                if not isinstance(salvos, dict):
                    salvos = {}
        salvos[key] = file_id
        with open(_ASSETS_CACHE_PATH, "w", encoding="utf-8") as f:
            _json.dump(salvos, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"⚠️ [ASSETS] Falha ao salvar imagem no disco: {e}")


# 🖼️ (26/09/2026) chave de imagem de UM item — o mítico tem arte própria
# (MITICO_WEAPON_1 ... um por item do banco), os outros seguem o
# slot × raridade de `resolver_asset_key_item`. Mítico de antes de o item
# guardar o `mit_id` é achado pelo nome no banco.
def chave_mitico(mit_id: str) -> str:
    return "MITICO_" + str(mit_id or "").upper().removeprefix("MIT_")


def chave_de_imagem_do_item(item: dict | None, slot: str = "") -> str:
    item = item or {}
    slot = slot or item.get("slot") or ""
    if str(item.get("rar") or "").lower() == "mythic":
        mid = item.get("mit_id")
        if not mid:
            from game.mythic_items import MYTHIC_ITEMS_DB
            for variantes in MYTHIC_ITEMS_DB.values():
                for v in variantes:
                    if v[1] == item.get("name"):
                        mid = v[0]
                        break
                if mid:
                    break
        if mid:
            return chave_mitico(mid)
    return resolver_asset_key_item(slot, item.get("rar", "comum"), item.get("sub", ""))
