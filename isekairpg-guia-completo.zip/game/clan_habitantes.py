# game/clan_habitantes.py
"""
🏘️ HABITANTES DA ALDEIA (20/09/2026)

QUEM SÃO
--------
O cenário sempre teve dois tipos de gente dentro da Torre: os **usuários
de aura** (os personagens do jogador — os 5 slots, que lutam nos postos)
e os que **não usam aura**: quem nasceu lá dentro ou foi mandado pra lá e
não tem como voltar. Esses segundos existiam só no texto. Este módulo dá
corpo a eles: cada habitante é um indivíduo com nome, profissão, nível,
potencial ★, fadiga — e uma chance pequena de **despertar Aura**.

A DIVISÃO DE TRABALHO É A DECISÃO
---------------------------------
Os lutadores continuam indo aos postos da Torre, que é de onde vem
material de rank e o risco. Os habitantes trabalham NA ALDEIA: comida,
madeira, couro e um pouco de material rank 1. Eles não substituem o posto — um
agricultor Nv1 rende ~24 de comida por sessão, contra ~85 de um lutador
no Andar 5 — mas liberam o lutador pra ir mais fundo. É a pergunta "Torre
ou aldeia" ganhando uma terceira resposta, e não sumindo.

REGRA DESTE ARQUIVO
-------------------
Tudo aqui é CÁLCULO PURO: recebe dicionários, devolve dicionários, não
toca em banco. Quem grava é `clan_repo`. É o que permite medir o laço
inteiro em simulação (`testes/auditar_aldeia.py`) sem montar banco — e foi
simulação que pegou praticamente todos os achados grandes deste projeto.
"""
from __future__ import annotations

import random

# ─────────────────────────────────────────────────────────── profissões ──
#
# Toda profissão aqui é LIDA por `trabalhar_tick`. Profissão que não produz
# nem faz nada seria enfeite com nome bonito (armadilha nº 10) — o teste
# de auditoria confere uma por uma.
PROFISSOES = {
    "agricultor": {"nome": "Agricultor", "icone": "🌾", "produz": "comida", "base": 1.0,
                   "especial": "Mestre Agricultor"},
    "lenhador":   {"nome": "Lenhador", "icone": "🪓", "produz": "madeira", "base": 0.6,
                   "especial": "Mestre Lenhador"},
    "cacador":    {"nome": "Caçador", "icone": "🏹", "produz": "couro", "base": 0.45,
                   "especial": "Rastreador"},
    # 🥇 20/09/2026: produzia bronze (moeda que saiu do jogo). Agora
    # produz MATERIAL rank 1 — o mesmo pote da Torre, que a Forja usa.
    # Sempre rank 1: quem minera perto da aldeia não chega no veio fundo;
    # rank alto continua vindo de posto na Torre e de mina funda no mapa.
    "minerador":  {"nome": "Minerador", "icone": "⛏️", "produz": "material_r1", "base": 0.3,
                   "especial": "Geólogo"},
    # Curandeiro não produz recurso: reduz a fadiga de TODOS os habitantes
    # e trata o ferimento dos lutadores. É a Enfermaria do documento.
    "curandeiro": {"nome": "Curandeiro", "icone": "🩺", "produz": None, "base": 0.0,
                   "especial": "Médico"},
    # Guarda não produz: segura a aldeia quando ela é atacada.
    "guarda":     {"nome": "Guarda", "icone": "🛡️", "produz": None, "base": 0.0,
                   "especial": "Capitão"},
}

# Nível em que a profissão vira especialização (Minerador → Geólogo). Só
# quem tem potencial ★3 ou mais chega lá — é o que faz o ★ importar.
NIVEL_ESPECIALIZACAO = 10
BONUS_ESPECIALIZACAO = 1.25

# O teto de nível é o POTENCIAL: ★1 para no 4, ★5 vai ao 20. "Dois
# habitantes podem ter o mesmo nível e serem completamente diferentes" —
# a diferença aparece quando um trava e o outro continua.
NIVEIS_POR_ESTRELA = 4

# Chance de cada potencial ao nascer. ★5 é raro de propósito: se fosse
# comum, procurar e valorizar um habitante deixaria de ser uma decisão.
PESO_POTENCIAL = {1: 35, 2: 30, 3: 20, 4: 11, 5: 4}

XP_POR_TICK = 1
XP_POR_NIVEL = 12            # custo do próximo nível = 12 × nível atual
# ⏩ (dev, 20/09: "muito tempo, divide por 20") todo XP ganho vale 20×. Um
# lugar só (`ganhar_xp`), então coletor, escolta, vigia, emboscada e batalha
# aceleram juntos e a proporção entre eles fica a mesma. Medido antes: guarda
# 5★ do Nv60 ao 100 no andar 40 levava ~507 sessões (~4 meses a 4/dia);
# agora ~25 sessões (~6 dias).
RITMO_XP = 20

# ───────────────────────────────────────────────────────────── fadiga ──
#
# Descansado → Cansado → Exausto. Trabalhando direto, o habitante fica
# cansado no fim da 1ª sessão e exausto na 2ª: rodízio é decisão, não
# enfeite. Descansar recupera o dobro do que trabalhar gasta, então uma
# sessão parado conserta duas de trabalho.
FADIGA_MAX = 100
FADIGA_TRABALHO = 2
FADIGA_DESCANSO = 4
FADIGA_CURANDEIRO = 1        # cada curandeiro tira +1 de todo mundo por tick
FAIXAS_FADIGA = [            # (a partir de, nome, fator de produção)
    (0, "Descansado", 1.00),
    (40, "Cansado", 0.70),
    # Medido com 0,40 aqui: trabalhar sem parar rendia só 8% menos que
    # fazer rodízio — o descanso quase não valia a sessão parada, e a
    # fadiga virava enfeite. Com 0,25 o rodízio passa a pagar de verdade.
    (80, "Exausto", 0.25),
]

# ─────────────────────────────────────────────────────────────── aura ──
#
# A chance é MUITO pequena no dia a dia e alta no perigo, que é o que o
# documento pede: "treinar não garante; um habitante pode despertar num
# momento crítico — vendo a família em perigo".
#
# Medido na primeira versão (0,0004 por tick e ×40 no perigo): 1 despertar
# a cada 20 sessões, e ZERO deles num ataque — o momento de crise, que é o
# coração da ideia, nunca acontecia. Agora a chance do perigo é escrita
# direto (5% por habitante num ataque que a defesa não segura, ~1 em 3 de
# alguém despertar numa aldeia de 8) e a do dia a dia caiu pra quase nada.
CHANCE_AURA_TICK = 0.00015
CHANCE_AURA_PERIGO = 0.05
PESO_AURA = {1: 45, 2: 28, 3: 16, 4: 8, 5: 3}
BONUS_AURA_PRODUCAO = 0.25   # por estrela
BONUS_AURA_DEFESA = 6        # por estrela

# ──────────────────────────────────────────────────────────── estágios ──
#
# Derivado, NUNCA gravado: população viva e comodidades construídas.
# Guardar o estágio num campo seria criar um número que pode discordar da
# aldeia de verdade. O único campo gravado é `estagio_registrado`, que
# serve só pra saber se ele SUBIU desde a última sessão (e escrever isso
# nas Memórias do Clã).
# 25/09/2026 (dev): "limite inicial de 8 é muito pouco, tem que ser 200, e
# o jogador já começa com no mínimo 50". Os estágios cresceram na mesma
# proporção (população mínima ×10; comodidades como eram).
ESTAGIOS = [
    # (nome, habitantes mínimos, comodidades mínimas, capacidade)
    ("Acampamento", 0, 0, 200),
    ("Aldeia", 40, 0, 250),
    ("Vila", 80, 1, 300),
    ("Fortaleza", 120, 2, 400),
    ("Cidade", 160, 4, 500),
    ("Capital do Clã", 200, 6, 600),
]
POPULACAO_INICIAL = 50

CUSTO_ACOLHER = 15                   # comida pra receber alguém
CHANCE_CHEGADA_SESSAO = 0.12         # refugiado que aparece sozinho
CHANCE_ATAQUE_SESSAO = 0.15
CHANCE_MORTE_NO_ATAQUE = 0.20
RACAO_HABITANTE_TICKS = 4            # come como o lutador: 1 a cada 4 ticks

# ────────────────────────────────────────────────────────── comandantes ──
#
# Um chefe por cargo. O bônus cresce com o NÍVEL do chefe (1% por nível na
# produção), então escolher o chefe é escolher quem tem potencial: um ★5
# Nv.20 vale +20%, um ★1 travado no Nv.4 vale +4%. O chefe continua
# trabalhando — o cargo é dele, não o tira do campo.
#
# Todo cargo aqui é LIDO pela sessão (armadilha nº 10): produtivos entram
# em `producao_do_tick`, o capitão em `defesa_da_aldeia` e o mestre da Aura
# em `tentar_despertar`. O teste confere cargo por cargo.
CARGOS = {
    "agricultor": {"nome": "Chefe da Lavoura", "exige": "agricultor", "por_nivel": 0.01},
    "lenhador":   {"nome": "Chefe dos Lenhadores", "exige": "lenhador", "por_nivel": 0.01},
    "cacador":    {"nome": "Chefe da Caça", "exige": "cacador", "por_nivel": 0.01},
    "minerador":  {"nome": "Chefe da Mineração", "exige": "minerador", "por_nivel": 0.01},
    "guarda":     {"nome": "Capitão", "exige": "guarda", "por_nivel": 0.0125},
    # O Mestre da Aura não exige profissão: exige TER aura. É o único cargo
    # que um curandeiro ou um agricultor desperto pode ocupar.
    "aura":       {"nome": "Mestre da Aura", "exige": None, "por_nivel": 0.0},
}
MULT_MESTRE_AURA = 2.0       # dobra a chance calma de despertar da aldeia

# ─────────────────────────────────────────────── especialização do clã ──
#
# A identidade da aldeia. Libera no estágio Vila (1 escolha) e ganha uma
# segunda na Cidade — o documento pede que dê pra combinar. Trocar custa
# ouro: identidade de graça viraria só um botão que se aperta antes de
# cada sessão.
ESPECIALIZACOES = {
    "mineradora": {"nome": "Mineradora", "icone": "⛏️", "efeito": "+20% de material dos mineradores",
                   "producao": {"material_r1": 1.20}},
    "agricola":   {"nome": "Agrícola", "icone": "🌾", "efeito": "+20% de comida e +2 de capacidade",
                   "producao": {"comida": 1.20}, "capacidade": 2},
    "militar":    {"nome": "Militar", "icone": "⚔️", "efeito": "+25% de defesa da aldeia",
                   "defesa": 1.25},
    "aura":       {"nome": "Da Aura", "icone": "🔮", "efeito": "despertar de Aura 2× mais provável",
                   "aura": 2.0},
    "artesa":     {"nome": "Artesã", "icone": "🪓", "efeito": "+20% de madeira e couro",
                   "producao": {"madeira": 1.20, "couro": 1.20}},
}
ESTAGIO_1A_ESPECIALIZACAO = 2        # Vila
ESTAGIO_2A_ESPECIALIZACAO = 4        # Cidade
# Em OURO desde 20/09 (era 60 de bronze, ~20% da renda de bronze de uma
# sessão). 500g é da mesma ordem: uma troca custa algumas sessões de Torre,
# o bastante pra identidade ser decisão e não botão.
CUSTO_TROCAR_ESPECIALIZACAO = 500    # ouro

# ────────────────────────────────────────────────────────────── família ──
#
# Parte de quem chega é PARENTE de alguém que já mora na aldeia. Isso não
# é enfeite de nome: o parente reage à morte (o cansaço dispara — luto
# derruba o trabalho, como o documento pede) e, num ataque, quem vê a
# família em perigo tem o dobro de chance de despertar. É o exemplo do
# próprio documento, virando regra.
CHANCE_PARENTE = 0.30
FADIGA_LUTO = 40
MULT_AURA_FAMILIA = 2.0
LACOS = ["irmão", "irmã", "filho", "filha", "primo", "prima"]

# ─────────────────────────────────────────────────────────── automação ──
#
# A regra que mais se repete no celular é o rodízio: "descansa quando
# cansar, volta quando recuperar". Deixar isso à mão numa aldeia de 15 é
# trabalho de planilha; a regra faz sozinha, tick a tick, enquanto você
# está na Torre — que é o ponto de um jogo idle.
REGRAS_PADRAO = {
    "descanso_auto": False, "limite": 80, "volta": 20,
    # 🌾 20/09/2026: compra automática de comida, pagando o ouro do
    # personagem. Só age quando a sessão terminou com gente faminta — não
    # todo tick, e não só porque o celeiro não está cheio — e nunca gasta
    # mais que `limite_ouro_comida` numa sessão só, pra uma noite ruim de
    # AFK não esvaziar a carteira sozinha.
    "compra_comida_auto": False, "limite_ouro_comida": 300,
    # 🛒 26/09/2026 (dev): a mesma compra automática pros MATERIAIS
    # (madeira, couro, ferro): no fim da sessão, o que não cobre a
    # manutenção da próxima é comprado de outras aldeias (até 2 sessões),
    # nunca passando de `limite_ouro_materiais` numa sessão, somando os três.
    "compra_materiais_auto": False, "limite_ouro_materiais": 300,
}

NOMES = [
    "Kael", "Mira", "Tobias", "Lena", "Oren", "Ida", "Bram", "Sela", "Doran", "Ayla",
    "Fenn", "Rhea", "Joran", "Nia", "Caius", "Wren", "Iris", "Hugo", "Talia", "Emrys",
    "Nara", "Vito", "Esme", "Goran", "Lior", "Maren", "Pim", "Ysolde", "Arlo", "Brisa",
    "Tomé", "Juno", "Silas", "Catarina", "Otto", "Liora", "Dante", "Hana", "Ravi", "Selma",
]


# ═════════════════════════════════════════════════════════ construção ══

def sortear_ponderado(pesos: dict, rng: random.Random) -> int:
    total = sum(pesos.values())
    alvo = rng.uniform(0, total)
    acumulado = 0.0
    for chave, peso in pesos.items():
        acumulado += peso
        if alvo <= acumulado:
            return chave
    return list(pesos)[-1]


def novo_habitante(rng: random.Random, nomes_em_uso: set | None = None,
                   profissao: str | None = None) -> dict:
    """Um habitante recém-chegado. Nome não repete dentro da aldeia: duas
    'Mira' no relatório de morte é o tipo de confusão que apaga a história."""
    em_uso = nomes_em_uso or set()
    livres = [n for n in NOMES if n not in em_uso]
    if not livres:
        # 40 nomes não bastam pra uma aldeia de 200: acabou, vira "Mira II"
        romanos = ["II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
        livres = [f"{n} {r}" for r in romanos for n in NOMES if f"{n} {r}" not in em_uso] \
            or [f"{n} {len(em_uso)}" for n in NOMES]
    from game.clan_equipes import sortear_talentos, COLETA
    talentos = sortear_talentos(rng)
    if profissao and talentos.get(profissao, 0) < 1:
        talentos[profissao] = 1          # quem foi chamado PRA algo sabe fazer
    # a profissão antiga vira "o melhor talento de coleta" (compatibilidade)
    melhor = max(COLETA, key=lambda p: talentos.get(p, 0))
    return {
        "parente_de": None,
        "laco": None,
        "talentos": talentos,
        "funcao": None,
        "nome": rng.choice(livres),
        "profissao": profissao or melhor,
        "nivel": 1,
        "xp": 0,
        "potencial": sortear_ponderado(PESO_POTENCIAL, rng),
        "fadiga": 0,
        "descansando": 0,
        "aura": 0,
        "vivo": 1,
    }


def ligar_parente(novo: dict, vivos: list, rng: random.Random) -> str | None:
    """Às vezes quem chega é da família de alguém que já mora aqui.
    Devolve a frase ("irmã de Kael") ou None. Só liga a quem tem id, ou
    seja, a quem já está gravado — parente de fantasma não reage a nada."""
    candidatos = [h for h in vivos if h.get("id")]
    if not candidatos or rng.random() >= CHANCE_PARENTE:
        return None
    alvo = rng.choice(candidatos)
    novo["parente_de"] = int(alvo["id"])
    novo["laco"] = rng.choice(LACOS)
    return f"{novo['laco']} de {alvo['nome']}"


def nivel_maximo(hab: dict) -> int:
    """20/09/2026: o teto é o das EQUIPES (`clan_equipes.nivel_maximo`) —
    coletor para no 20; guarda vai a 20 × estrelas de guarda (5★ = 100); só
    aura passa do 100. Habitante antigo sem talentos: vale o potencial na
    profissão que ele já tinha."""
    from game.clan_equipes import nivel_maximo as teto
    if not hab.get("talentos"):
        hab = dict(hab, talentos={hab.get("profissao", "agricultor"): int(hab.get("potencial") or 1)},
                   funcao="guarda" if hab.get("profissao") == "guarda" else hab.get("funcao"))
    return teto(hab)


def faixa_de_fadiga(fadiga: int) -> tuple[str, float]:
    nome, fator = FAIXAS_FADIGA[0][1], FAIXAS_FADIGA[0][2]
    for limite, n, f in FAIXAS_FADIGA:
        if int(fadiga) >= limite:
            nome, fator = n, f
    return nome, fator


def titulo_da_profissao(hab: dict) -> str:
    prof = PROFISSOES.get(hab.get("profissao"), {})
    if int(hab.get("nivel") or 1) >= NIVEL_ESPECIALIZACAO:
        return prof.get("especial") or prof.get("nome", "?")
    return prof.get("nome", "?")


def moradores(vivos: list) -> list:
    """🏙️ (28/09, dev) Quem MORA na aldeia. Cavaleiro é usuário de aura: mora
    na cidade do reino e recebe soldo em ouro — não ocupa casa, não come da
    panela da aldeia e não conta pro estágio nem pra atrair ataque. Ele
    continua servindo o clã (escolta, guarnição, batalha)."""
    return [h for h in vivos if not h.get("cavaleiro")]


def estagio_da_aldeia(vivos: int, comodidades) -> dict:
    """O maior estágio que a aldeia CUMPRE — população e construção juntas.
    Só gente não basta pra virar Fortaleza: sem muralha nem oficina, é só
    um acampamento grande.
    `comodidades`: a CONTAGEM (int) ou o dict do clã — com o dict, as
    Moradias (por níveis) somam no limite (25/09/2026)."""
    extra = 0
    if isinstance(comodidades, dict):
        from game.clan_materiais import capacidade_das_construcoes
        extra = capacidade_das_construcoes(comodidades)
        comodidades = len([k for k, v in comodidades.items() if v])
    idx = 0
    for i, (_nome, minimo, comod, _cap) in enumerate(ESTAGIOS):
        if vivos >= minimo and comodidades >= comod:
            idx = i
    nome, _m, _c, cap = ESTAGIOS[idx]
    proximo = ESTAGIOS[idx + 1] if idx + 1 < len(ESTAGIOS) else None
    return {
        "indice": idx, "nome": nome, "capacidade": cap + extra,
        "proximo": ({"nome": proximo[0], "habitantes": proximo[1],
                     "comodidades": proximo[2]} if proximo else None),
    }


# ═══════════════════════════════════════════════════════════ trabalho ══

def producao_do_tick(hab: dict, mods: dict | None = None) -> float:
    """Quanto um habitante produz num tick, já com tudo que pesa nele.

    `mods` vem de `modificadores_da_aldeia` (chefes e especialização).
    Sem ele, o cálculo é o do habitante sozinho — que é o que a tela usa
    pra dizer quanto ELE rende, antes dos bônus coletivos."""
    prof = PROFISSOES.get(hab.get("profissao"), {})
    if not prof.get("produz") or int(hab.get("descansando") or 0):
        return 0.0
    nivel = int(hab.get("nivel") or 1)
    _nome, fator_fadiga = faixa_de_fadiga(int(hab.get("fadiga") or 0))
    valor = prof["base"] * (1.0 + 0.08 * (nivel - 1)) * fator_fadiga
    if nivel >= NIVEL_ESPECIALIZACAO:
        valor *= BONUS_ESPECIALIZACAO
    valor *= 1.0 + BONUS_AURA_PRODUCAO * int(hab.get("aura") or 0)
    if mods:
        valor *= mods.get("producao", {}).get(prof["produz"], 1.0)
    return valor


def ganhar_xp(hab: dict, xp: int) -> list[str]:
    """Sobe de nível respeitando o teto do potencial. Devolve as frases pro
    relatório — subir de nível sem ninguém ver é progresso invisível."""
    frases = []
    teto = nivel_maximo(hab)
    if int(hab["nivel"]) >= teto:
        return frases
    hab["xp"] = int(hab.get("xp") or 0) + int(xp) * RITMO_XP
    while int(hab["nivel"]) < teto and hab["xp"] >= XP_POR_NIVEL * int(hab["nivel"]):
        hab["xp"] -= XP_POR_NIVEL * int(hab["nivel"])
        hab["nivel"] = int(hab["nivel"]) + 1
        if hab["nivel"] == NIVEL_ESPECIALIZACAO:
            frases.append(f"⭐ {hab['nome']} virou {titulo_da_profissao(hab)}.")
        else:
            frases.append(f"📈 {hab['nome']} chegou a {titulo_da_profissao(hab)} Nv.{hab['nivel']}.")
        if hab["nivel"] >= teto:
            if hab.get("funcao") == "guarda":
                estrelas_g = int((hab.get("talentos") or {}).get("guarda", 0))
                frases.append(f"🔒 {hab['nome']} chegou ao teto de guarda {'★' * estrelas_g} (Nv.{teto})"
                              + (" — só a aura leva além." if teto >= 100 else "."))
            else:
                frases.append(f"🔒 {hab['nome']} chegou ao nível máximo de coletor (Nv.{teto}).")
            hab["xp"] = 0
    return frases


def tentar_despertar(hab: dict, rng: random.Random, perigo: bool = False,
                     mult: float = 1.0) -> bool:
    """Um sorteio de despertar. Quem já tem aura não desperta de novo.
    `mult` junta o que empurra a chance: Mestre da Aura, especialização e
    — no perigo — ver a própria família sendo atacada."""
    if int(hab.get("aura") or 0) or not int(hab.get("vivo", 1)):
        return False
    chance = (CHANCE_AURA_PERIGO if perigo else CHANCE_AURA_TICK) * float(mult)
    if rng.random() < chance:
        hab["aura"] = sortear_ponderado(PESO_AURA, rng)
        return True
    return False


def defesa_da_aldeia(habitantes: list, estagio_idx: int, mods: dict | None = None) -> int:
    """Guardas + quem tem aura + o que a própria aldeia já é. Uma Fortaleza
    se defende melhor que um Acampamento com a mesma gente dentro."""
    from game.clan_equipes import em_treino, sem_soldo, MULT_CAVALEIRO_GUARNICAO
    total = 4 + 4 * int(estagio_idx)
    for h in habitantes:
        if not int(h.get("vivo", 1)):
            continue
        # 🏰 (20/09) quem defende a cidade é a GUARNIÇÃO (guardas que ficaram
        # em casa); guarda que saiu com uma equipe está lá fora. Habitante
        # antigo, sem função gravada, conta pela profissão.
        em_casa = (h.get("funcao") == "guarda" and h.get("equipe") == "cidade") or (
            not h.get("funcao") and h.get("profissao") == "guarda")
        if em_treino(h) or sem_soldo(h):
            continue                   # ⚔️ cavaleiro treinando ou sem soldo: não defende
        if em_casa and not int(h.get("descansando") or 0):
            _n, fator = faixa_de_fadiga(int(h.get("fadiga") or 0))
            valor = (3 + int(h.get("nivel") or 1)) * fator
            if h.get("cavaleiro"):
                valor *= MULT_CAVALEIRO_GUARNICAO    # ⚔️ na guarnição vale 10 guardas
            total += int(valor)
        total += BONUS_AURA_DEFESA * int(h.get("aura") or 0)
    if mods:
        total = int(total * mods.get("defesa", 1.0))
    return total


def modificadores_da_aldeia(habitantes: list, cfg: dict | None) -> dict:
    """Junta chefes e especialização num dicionário só, que a sessão aplica.

    Chefe só vale se estiver VIVO e ainda for da profissão do cargo —
    quem morreu ou trocou de ofício perde o posto sem ninguém precisar
    lembrar de tirar. Cargo vago não quebra nada: só não soma.
    """
    cfg = cfg or {}
    por_id = {int(h["id"]): h for h in habitantes if h.get("id") and int(h.get("vivo", 1))}
    mods = {"producao": {}, "defesa": 1.0, "aura": 1.0, "capacidade": 0, "chefes": {}}

    for cargo, hab_id in (cfg.get("comandantes") or {}).items():
        regra = CARGOS.get(cargo)
        chefe = por_id.get(int(hab_id)) if hab_id is not None else None
        if not regra or not chefe:
            continue
        if regra["exige"] and chefe.get("profissao") != regra["exige"]:
            continue
        if cargo == "aura":
            if not int(chefe.get("aura") or 0):
                continue
            mods["aura"] *= MULT_MESTRE_AURA
        elif cargo == "guarda":
            mods["defesa"] *= 1.0 + regra["por_nivel"] * int(chefe.get("nivel") or 1)
        else:
            recurso = PROFISSOES[cargo]["produz"]
            mods["producao"][recurso] = mods["producao"].get(recurso, 1.0) * (
                1.0 + regra["por_nivel"] * int(chefe.get("nivel") or 1))
        mods["chefes"][cargo] = chefe["nome"]

    for esp in (cfg.get("especializacoes") or []):
        e = ESPECIALIZACOES.get(esp)
        if not e:
            continue
        for recurso, m in (e.get("producao") or {}).items():
            mods["producao"][recurso] = mods["producao"].get(recurso, 1.0) * m
        mods["defesa"] *= e.get("defesa", 1.0)
        mods["aura"] *= e.get("aura", 1.0)
        mods["capacidade"] += int(e.get("capacidade", 0))
    return mods


def vagas_de_especializacao(estagio_idx: int) -> int:
    if estagio_idx >= ESTAGIO_2A_ESPECIALIZACAO:
        return 2
    if estagio_idx >= ESTAGIO_1A_ESPECIALIZACAO:
        return 1
    return 0


def ameaca_do_ataque(vivos: int, rng: random.Random) -> int:
    """Aldeia maior chama mais atenção. A variação existe pra que a mesma
    defesa às vezes baste e às vezes não — senão o ataque seria só uma
    conta que o jogador resolve uma vez e esquece."""
    return int(6 + 1.5 * vivos + rng.randint(0, 8))


def sessao_da_aldeia(habitantes: list, ticks: int, comida_disponivel: int,
                     comodidades: int, rng: random.Random, cfg: dict | None = None) -> dict:
    """Uma sessão inteira de AFK da aldeia. MUTA os dicionários dos
    habitantes (é quem chama que grava) e devolve o que aconteceu.

    A ordem importa e está escrita: primeiro o trabalho (cada tick), depois
    a comida da sessão, depois o ataque, e por último a chegada de gente
    nova. O ataque vem depois do trabalho porque ele acontece à noite, com
    todo mundo cansado — é o momento em que a fadiga mais pesa.
    """
    vivos = [h for h in habitantes if int(h.get("vivo", 1))]
    producao = {"comida": 0.0, "madeira": 0.0, "couro": 0.0, "material_r1": 0.0}
    frases: list[str] = []
    memorias: list[dict] = []
    despertaram: list[str] = []

    curandeiros = sum(1 for h in vivos
                      if h.get("profissao") == "curandeiro" and not int(h.get("descansando") or 0))
    mods = modificadores_da_aldeia(habitantes, cfg)
    regras = {**REGRAS_PADRAO, **((cfg or {}).get("regras") or {})}
    auto = bool(regras.get("descanso_auto"))
    mandados_descansar: set = set()

    for _ in range(max(0, int(ticks))):
        for h in vivos:
            prof = PROFISSOES.get(h.get("profissao"), {})
            if auto:
                # A regra da aldeia: descansa ao passar do limite, volta ao
                # recuperar. Roda TICK A TICK, não por sessão — senão quem
                # cansou no tick 5 passaria 19 ticks exausto esperando a
                # próxima sessão pra alguém decidir por ele.
                if not int(h.get("descansando") or 0) and int(h["fadiga"]) >= int(regras["limite"]):
                    h["descansando"] = 1
                    mandados_descansar.add(h["nome"])
                elif int(h.get("descansando") or 0) and int(h["fadiga"]) <= int(regras["volta"]):
                    h["descansando"] = 0
            if int(h.get("descansando") or 0):
                h["fadiga"] = max(0, int(h["fadiga"]) - FADIGA_DESCANSO - FADIGA_CURANDEIRO * curandeiros)
            else:
                qtd = producao_do_tick(h, mods)
                if prof.get("produz"):
                    producao[prof["produz"]] += qtd
                h["fadiga"] = min(FADIGA_MAX, max(0, int(h["fadiga"]) + FADIGA_TRABALHO
                                                  - FADIGA_CURANDEIRO * curandeiros))
                # 👥 (20/09) XP vem do TRABALHO de verdade: coletor ganha
                # coletando e guarda ganha escoltando/lutando — as duas coisas
                # acontecem fora (clan_repo.sessao_das_equipes e as batalhas).
                # Aqui dentro só o curandeiro, que trabalha em casa.
                if h.get("profissao") == "curandeiro" and not h.get("funcao"):
                    frases.extend(ganhar_xp(h, XP_POR_TICK))
            if tentar_despertar(h, rng, mult=mods["aura"]):
                despertaram.append(h["nome"])

    # ── comida: habitante come como lutador, e come DEPOIS do que plantou
    refeicoes = int(ticks) // RACAO_HABITANTE_TICKS
    da_aldeia = moradores(vivos)                 # 🏙️ cavaleiro come na cidade
    precisa = refeicoes * len(da_aldeia)
    disponivel = int(comida_disponivel) + int(producao["comida"])
    comido = min(precisa, disponivel)
    sem_comida = 0
    if precisa > 0 and comido < precisa:
        # Quem fica sem é quem chegou por último na fila da panela: os de
        # menor nível. Mesmo raciocínio da ração dos lutadores — dividir
        # pouco igual não salva ninguém.
        faltam = (precisa - comido) // max(1, refeicoes) + (1 if (precisa - comido) % max(1, refeicoes) else 0)
        fila = sorted(da_aldeia, key=lambda h: int(h.get("nivel") or 1))
        for h in fila[:faltam]:
            h["fadiga"] = min(FADIGA_MAX, int(h["fadiga"]) + 15)
            sem_comida += 1
        frases.append(f"🍖 Faltou comida pra {sem_comida} habitante(s): o cansaço deles subiu.")

    # ── ataque
    estagio = estagio_da_aldeia(len(da_aldeia), comodidades)
    estagio["capacidade"] += mods["capacidade"]
    ataque = None
    # ⚔️ (26/09) guerra com clã NPC (Crônicas) soma na chance de ataque
    if vivos and rng.random() < CHANCE_ATAQUE_SESSAO + float((cfg or {}).get("chance_ataque_extra", 0)):
        ameaca = ameaca_do_ataque(len(da_aldeia), rng)
        defesa = defesa_da_aldeia(vivos, estagio["indice"], mods)
        heroi = None
        # Quem os monstros alcançam é decidido ANTES de alguém despertar:
        # é assim que a família dele pode vê-lo em perigo.
        alvos = [h for h in vivos if h.get("profissao") != "guarda"] or vivos
        vitima = rng.choice(alvos)
        familia = {int(x) for x in (vitima.get("id"), vitima.get("parente_de")) if x}
        if defesa < ameaca:
            # O momento de perigo: é aqui que alguém pode despertar. Quem
            # desperta vira a defesa que faltava.
            for h in rng.sample(vivos, len(vivos)):
                parente_em_perigo = h is not vitima and (
                    (h.get("id") and int(h["id"]) in familia) or
                    (h.get("parente_de") and int(h["parente_de"]) in familia))
                mult = mods["aura"] * (MULT_AURA_FAMILIA if parente_em_perigo else 1.0)
                if tentar_despertar(h, rng, perigo=True, mult=mult):
                    heroi = h
                    despertaram.append(h["nome"])
                    defesa += BONUS_AURA_DEFESA * int(h["aura"])
                    if parente_em_perigo:
                        h["_protegeu"] = vitima["nome"]
                    break
        repelido = defesa >= ameaca
        ataque = {"ameaca": ameaca, "defesa": defesa, "repelido": repelido,
                  "heroi": heroi["nome"] if heroi else None, "ferido": None, "morto": None}
        if heroi:
            quem = heroi.pop("_protegeu", None)
            motivo = f"protegendo {quem}, da própria família" if quem else "defendendo os outros"
            texto = (f"✨ Monstros invadiram a aldeia e {heroi['nome']} DESPERTOU A AURA "
                     f"({'★' * int(heroi['aura'])}) {motivo}.")
            frases.append(texto)
            memorias.append({"tipo": "aura", "texto": texto})
        elif repelido:
            frases.append(f"🛡️ Um ataque à aldeia foi repelido (defesa {defesa} × ameaça {ameaca}).")
        else:
            if rng.random() < CHANCE_MORTE_NO_ATAQUE:
                vitima["vivo"] = 0
                vitima["causa"] = "morreu num ataque de monstros à aldeia"
                ataque["morto"] = vitima["nome"]
                texto = f"⚰️ {vitima['nome']} morreu num ataque de monstros à aldeia."
                frases.append(texto)
                memorias.append({"tipo": "morte", "texto": texto})
                # Luto: quem era da família para de render. É o preço que
                # faz a morte pesar além de "um a menos".
                for h in vivos:
                    if h is vitima or not int(h.get("vivo", 1)):
                        continue
                    if (h.get("id") and int(h["id"]) in familia) or \
                            (h.get("parente_de") and int(h["parente_de"]) in familia):
                        h["fadiga"] = min(FADIGA_MAX, int(h["fadiga"]) + FADIGA_LUTO)
                        texto = f"🕯️ {h['nome']} chorou a morte de {vitima['nome']}."
                        frases.append(texto)
                        memorias.append({"tipo": "luto", "texto": texto})
            else:
                vitima["fadiga"] = FADIGA_MAX
                ataque["ferido"] = vitima["nome"]
                frases.append(f"🩸 Um ataque passou pela defesa ({defesa} × {ameaca}): "
                              f"{vitima['nome']} ficou ferido e exausto.")

    for nome in despertaram:
        if not ataque or ataque.get("heroi") != nome:
            texto = f"✨ {nome} despertou a Aura durante o trabalho."
            frases.append(texto)
            memorias.append({"tipo": "aura", "texto": texto})

    # ── chegada de refugiado, se houver lugar
    vivos_agora = [h for h in habitantes if int(h.get("vivo", 1))]
    chegou = None
    if len(vivos_agora) < estagio["capacidade"] and rng.random() < CHANCE_CHEGADA_SESSAO:
        chegou = novo_habitante(rng, {h["nome"] for h in habitantes})
        laco = ligar_parente(chegou, vivos_agora, rng)
        habitantes.append(chegou)
        texto = (f"🚶 {chegou['nome']} chegou à aldeia pedindo abrigo "
                 f"({PROFISSOES[chegou['profissao']]['nome']}, {'★' * chegou['potencial']})"
                 + (f" — é {laco}." if laco else "."))
        frases.append(texto)
        memorias.append({"tipo": "chegada", "texto": texto})

    return {
        "producao": {k: int(v) for k, v in producao.items()},
        "comida_consumida": int(comido),
        "sem_comida": sem_comida,
        "ataque": ataque,
        "despertaram": despertaram,
        "chegou": chegou["nome"] if chegou else None,
        "curandeiros": curandeiros,
        "chefes": mods["chefes"],
        "descanso_auto": sorted(mandados_descansar),
        "frases": frases,
        "memorias": memorias,
    }
