"""
Textos dos tutoriais de primeira vez.

🌐 11/09/2026 — Estes textos moravam em game/views.py, que importa
core.keyboards, que importa aiogram. Ou seja: a API do site não conseguia
ler um tutorial sem carregar a camada de interface do BOT inteira — e no
dia em que o bot sair, os 13 tutoriais sairiam junto.

São conteúdo de jogo, não interface de bot. Ficam aqui, sem dependência
nenhuma. O views.py importa daqui, então o bot continua igual e não existe
segunda cópia pra divergir.

A formatação HTML (<b>, <i>) é do parse_mode do Telegram; a API limpa
antes de mandar pro site.
"""

HOWTO_TEXTS = {
    # 👆 (26/09/2026) os guias de clique usam o registro de "tutorial visto"
    # daqui (o texto de verdade está no roteiro do front: GUIA_INICIO/CLAN)
    "guia_inicio": "Guia inicial: a Torre, a ficha, a Cidade, as Missões e a primeira luta.",
    "guia_clan": "Guia do clã: recursos, membros, XP parado, equipes e Crônicas.",

    # 🏰 (26/09/2026) o clã inteiro, na ordem em que o jogador precisa
    "clan": (
        "🏰 <b>O SEU CLÃ</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "O clã é a sua aldeia na Torre. Ele trabalha <b>enquanto você não está</b>: "
        "cada vez que você volta, a sessão que passou é contada (até ~6h por vez).\n\n"
        "🔥 <b>1. Funde o clã</b> — no 1º andar, em <b>Crônicas</b>. Sem isso o portal "
        "pro 2º andar não abre.\n"
        "🧭 <b>2. Monte equipes</b> — em <b>Explorar andar</b>: cada equipe precisa de "
        "coletores e de pelo menos 1 guarda. Ela pode coletar qualquer recurso; no posto "
        "do tipo certo ganha o bônus dele. Cada equipe fica 12h e volta.\n"
        "🌾 <b>3. Alimente a aldeia</b> — todo aldeão come e queima lenha. Se faltar "
        "manutenção, as equipes rendem só metade.\n"
        "🏠 <b>4. Cresça</b> — Moradias (na Forja do Ferreiro) aumentam o limite de "
        "aldeões; Crônicas e recrutas trazem gente nova.\n"
        "⚔️ <b>5. Batalha no andar</b> — no Resumo, deixe seus personagens lutando: "
        "ganham XP a cada 5 min, mas podem morrer.\n"
        "📖 <b>Crônicas</b> — histórias da aldeia que esperam sua decisão. Se você não "
        "decidir a tempo, a aldeia decide sozinha.\n\n"
        "Cuidado com os clãs vizinhos: acolher quem fugiu deles pode começar uma guerra."
    ),

    "battle": (
        "⚔️ <b>COMO FUNCIONA A BATALHA</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🗡️ <b>Atacar:</b> golpe básico, sempre disponível.\n"
        "🔮 <b>Skill:</b> gasta cooldown, mas causa mais dano ou tem efeitos "
        "especiais (cura, veneno, atordoar...).\n"
        "🎯 <b>Acerto/Esquiva:</b> sua Precisão (ACC) compete com a Evasão (EVA) "
        "do inimigo — nem todo golpe acerta.\n"
        "💥 <b>Crítico:</b> chance de causar dano extra a cada golpe.\n"
        "🧪 <b>Poção:</b> cura HP no meio da luta, mas seu estoque é limitado.\n\n"
        "Se seu HP chegar a 0, você desmaia e perde progresso — cuidado!"
    ),
    "tower": (
        "🗼 <b>A TORRE DO FIM</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "100 andares, cada um mais difícil que o anterior.\n\n"
        "📈 Suba andares derrotando os monstros de cada um. Andares mais altos "
        "dão mais XP, ouro e cores melhores.\n"
        "🚪 Alguns andares têm <b>Chefes</b> — mais fortes, mas com recompensas "
        "maiores.\n"
        "🌀 Ficou sem HP ou quer voltar? Use o <b>Teleporte</b> (pago) pra "
        "escapar pra cidade na hora.\n\n"
        "<i>Não tenha pressa: subir rápido demais sem se preparar é o motivo #1 "
        "de morte na Torre.</i>"
    ),
    "trails": (
        "🌟 <b>TRILHAS (SEUS ATRIBUTOS)</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Toda vez que sobe de nível, você ganha <b>Pontos de Trilha</b>. "
        "Gaste-os em 4 caminhos:\n\n"
        "💪 <b>Força:</b> ATK e DEF.\n"
        "❤️ <b>Vitalidade:</b> HP Máximo e Regeneração.\n"
        "🌪️ <b>Agilidade:</b> Velocidade e Evasão.\n"
        "🎯 <b>Destreza:</b> Crítico e Precisão.\n\n"
        "Cada ponto investido também escolhe um atributo secundário — pense "
        "bem, porque isso define o estilo de combate do seu personagem."
    ),
    "skills": (
        "🔮 <b>SKILLS (HABILIDADES)</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Monstros dropam <b>Cores</b> — use-as pra aprender novas Skills.\n\n"
        "⚔️ <b>Ativas:</b> aparecem como botão na batalha. Causam dano, curam, "
        "aplicam veneno, atordoam... cada uma com seu próprio cooldown.\n"
        "🛡️ <b>Passivas:</b> ficam sempre ligadas, dando bônus permanente de "
        "status enquanto equipadas.\n\n"
        "Você pode equipar até <b>5 Skills ao mesmo tempo</b> — misture ativas "
        "e passivas do jeito que fizer sentido pra sua build."
    ),
    "craft": (
        "🛠️ <b>FORJA E SOCKETS</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Monstros dropam <b>Cores de Forja</b> (materiais brutos de Aura).\n\n"
        "Com Cores e Ouro, você cria armaduras e armas aqui — quanto mais rara "
        "a peça, mais forte, mas também mais cores custa e menor a chance de "
        "sucesso.\n\n"
        "Depois de forjar, use os <b>Sockets</b> do item pra embutir Pedras "
        "Preciosas e ganhar status extras, sem precisar trocar o equipamento."
    ),
    "city_center": (
        "🏛️ <b>CENTRO DA CIDADE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Aqui fica tudo que não é a Torre em si:\n\n"
        "🏥 <b>Hospital</b> recupera seu HP. 🏪 <b>Loja/Trocas</b> é o mercado "
        "P2P pra vender seus drops. 🛠️ <b>Forja</b> cria equipamentos.\n\n"
        "🔮 <b>Chakra:</b> desde a criação, você já tem um bônus único e "
        "permanente (confira no Status).\n"
        "🐉 <b>Pets</b> e 🐴 <b>Montarias:</b> aliados e bônus de exploração.\n"
        "⚔️ <b>Arena PvP:</b> desafie cópias de outros jogadores, mesmo sem "
        "eles estarem online."
    ),
    "raid": (
        "🗼 <b>RAID</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "A Raid é uma versão cooperativa da Torre — você entra numa sala "
        "(sozinho ou em grupo) e enfrenta inimigos bem mais fortes do que os "
        "da Torre normal, com loot melhor.\n\n"
        "🏰 Entrando aqui, você cria (ou volta pra) sua própria sala.\n"
        "👥 Pra jogar com outras pessoas, use <b>'Entrar em Party'</b> no "
        "menu principal pra entrar na sala de alguém.\n"
        "⚔️ O combate roda por turnos, com barra de ação — sua vez chega "
        "conforme sua Velocidade."
    ),
    "raid_rooms": (
        "👥 <b>ENTRAR EM PARTY</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Aqui você vê as salas de Raid abertas de outros jogadores e pode "
        "entrar pra jogar em grupo.\n\n"
        "🚪 Escolha uma sala com vaga e entre no lobby.\n"
        "✅ Quando todo mundo estiver pronto, o líder da sala inicia a "
        "batalha — e você é avisado automaticamente quando ela começa, sem "
        "precisar ficar atualizando a tela."
    ),
    "socket": (
        "💎 <b>SOCKETS</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Seus equipamentos forjados têm espaços vazios (sockets) — encaixe "
        "Cores neles pra ganhar status extras, sem precisar trocar de item.\n\n"
        "🔧 Escolha o item, depois a core que quer encaixar.\n"
        "♻️ Dá pra trocar a core encaixada depois, se conseguir uma melhor."
    ),
    "shop": (
        "🏪 <b>LOJA</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Aqui você compra itens básicos com ouro — poções, cores simples, "
        "e outros consumíveis pra sua jornada.\n\n"
        "💰 Preços sobem com a raridade do item.\n"
        "🏪 Pra vender/comprar itens de OUTROS jogadores, use 'Trocas' em "
        "vez da Loja — são sistemas diferentes."
    ),
    "explore": (
        "🌍 <b>MUNDO EXTERIOR</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Uma vez a cada 7 dias, a cidade abre os portões pro mundo além dos "
        "muros. É uma área bem mais arriscada que a Torre — <b>não existe "
        "fuga</b> até completar 7 explorações.\n\n"
        "🗺️ A área que você explora acompanha seu andar atual na Torre "
        "(cada 20 andares é uma faixa de perigo diferente).\n\n"
        "🎲 <b>A cada exploração pode rolar:</b>\n"
        "⚔️ Batalha comum — 👹 Chefe poderoso — 💰 Muito ouro\n"
        "🔮 Skill rara — 🐉 Pet raro — 🐴 Montaria rara\n\n"
        "⚠️ <b>Risco real:</b> se você morrer aqui, perde 1 item equipado "
        "aleatório. As recompensas são melhores que a Torre normal, mas o "
        "risco também é maior."
    ),
    "global_boss": (
        "🐲 <b>BOSS GLOBAL</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Um único boss, compartilhado por TODOS os jogadores do servidor ao "
        "mesmo tempo. Todo mundo ataca o mesmo bicho.\n\n"
        "🌋 Ele fica mais forte conforme perde HP — a cada 10% de HP "
        "perdido, o ATK e a DEF dele DOBRAM. Perto do fim, ele fica "
        "absurdamente perigoso. Ele também revida na hora.\n\n"
        "⏳ Você pode atacar a cada 10 minutos.\n\n"
        "🏆 Quando ele cai, o ouro é dividido entre "
        "todos que participaram, proporcional ao dano que cada um causou — "
        "quanto mais dano, maior sua fatia. Depois, um boss novo (mais "
        "forte ainda) aparece na hora."
    ),
    "wave": (
        "🌊 <b>ONDA DE BOSSES</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "5 chefes vivos AO MESMO TEMPO na mesma batalha — igual a Raid, "
        "não é mais um de cada vez. Vencendo todos, a próxima onda já "
        "começa na hora — sempre mais forte. Não tem fim, só acaba "
        "quando você morrer.\n\n"
        "✅ Tudo que você ganha ao longo do caminho (ouro, XP, drops) é "
        "seu de verdade, mesmo se cair no meio.\n\n"
        "🏆 Cada onda completa dá um bônus de ouro, e a cada 3 ondas rola "
        "um bônus extra bem gordo de ouro.\n\n"
        "⚠️ <b>Só 1 tentativa por dia</b> — pense bem antes de entrar."
    ),
}
