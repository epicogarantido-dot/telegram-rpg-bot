# game/stats.py
from __future__ import annotations

from typing import Dict, Any


def criar_status_inicial() -> Dict[str, int]:
    # Status “base” (antes de atributos/equip/skills)
    return {
        "atk": 10,
        "def": 0,
        "hp_max": 100,
        "reg": 0,
        "spd": 20,
        "eva": 0,
        "crit": 0,
        "acc": 0,
        # Elementos (opcional)
        "atk_fogo": 0, "atk_agua": 0, "atk_terra": 0, "atk_ar": 0,
        "def_fogo": 0, "def_agua": 0, "def_terra": 0, "def_ar": 0,
    }


def _to_int(x: Any) -> int:
    try:
        return int(x)
    except Exception:
        return 0


def aplicar_atributos(status_base: Dict[str, int], atributos: Dict[str, Any]) -> Dict[str, int]:
    """
    atributos esperado (exemplo):
      {"forca": 0, "vitalidade": 0, "agilidade": 0, "destreza": 0}
    """
    s = dict(status_base)

    forca = _to_int(atributos.get("forca", 0))
    vit = _to_int(atributos.get("vitalidade", 0))
    agi = _to_int(atributos.get("agilidade", 0))
    des = _to_int(atributos.get("destreza", 0))

    s["atk"] = _to_int(s.get("atk", 0)) + forca * 2
    s["def"] = _to_int(s.get("def", 0)) + forca * 2
    s["hp_max"] = _to_int(s.get("hp_max", 0)) + vit * 20
    s["reg"] = _to_int(s.get("reg", 0)) + vit * 2
    s["spd"] = _to_int(s.get("spd", 0)) + agi * 2
    s["eva"] = _to_int(s.get("eva", 0)) + agi * 2
    s["crit"] = _to_int(s.get("crit", 0)) + des * 2
    s["acc"] = _to_int(s.get("acc", 0)) + des * 2

    # sanidade mínima
    if s["hp_max"] < 1:
        s["hp_max"] = 1

    return s


def aplicar_bonus(status: Dict[str, Any], bonus: Dict[str, Any]) -> Dict[str, int]:
    """
    Soma bônus flat: {"atk": +5, "hp_max": +20, ...}
    """
    out: Dict[str, int] = {k: _to_int(v) for k, v in status.items()}

    for k, v in (bonus or {}).items():
        out[k] = out.get(k, 0) + _to_int(v)

    if out.get("hp_max", 1) < 1:
        out["hp_max"] = 1

    return out