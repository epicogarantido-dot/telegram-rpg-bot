"""
A aldeia — serviços que se pagam em ouro.

🥇 20/09/2026 — SÓ OURO
------------------------
Bronze e prata saíram do jogo inteiro. O clã tinha moeda própria de
propósito ("Torre ou aldeia" não pode ser a mesma escolha duas vezes),
mas o dev pediu uma economia só: OURO, o mesmo que o personagem já ganha
na Torre. Os serviços abaixo agora custam ouro — e ouro é do JOGADOR
(`p["gold"]`), não do clã, então quem cobra é sempre a rota que já tem
`p` carregado, nunca este módulo.

O QUE SAIU JUNTO
-----------------
- **"Trocar bronze por prata"**: não existe mais o que trocar.
- **Vender material por moeda**: o material agora é ingrediente da forja
  pessoal (ver `game/items.py`, `REQ_MATERIAL_CRAFT`) e do equipamento do
  clã — vendê-lo por umas moedas era quase sempre erro mesmo quando
  bronze existia ("vender material que sobra... é quase sempre erro").
  Com o material tendo mais um uso, vender ficou ainda pior ideia, então
  a opção saiu da loja em vez de continuar existindo em ouro.
- **"Contratar mão de obra"** VOLTOU em 20/09, agora com leitor (ver abaixo).
- **"Reparar o arsenal"** (e, antes, a mão de obra): achados ao mexer
  aqui, não pedidos. Os efeitos `desconto_construcao` e `repara_arsenal`
  nunca tiveram leitor nenhum — nem em `/api/clan/construir` nem em
  lugar algum (mesma classe da fome, do `teto_comida`, do `ferimento`:
  campo que nada lê é enfeite, armadilha nº 10). "Reparar" é mais fundo
  ainda: o jogo nunca teve desgaste de equipamento pra reparar — a peça
  guardada em `clan.arsenal` não tem nem campo pra isso. Os dois serviços
  já cobravam moeda por nada antes de bronze sair; cobrar em ouro seria
  pior, não melhor, então saíram da lista. Fica anotado no CONTEXTO pra
  decidir depois: construir os mecanismos de verdade, ou deixar de fora.

FONTE E RALO
------------
Todo custo aqui é um RALO de ouro puro — nenhum serviço gera ouro (o que
"trocar" fazia antes não existe mais). A fonte de ouro do clã é o mapa
(Cristais e Ruínas, ver `game/territorio.py`) e o "achado raro" do AFK
em `clan_repo.rodar_afk`.
"""
from __future__ import annotations

SERVICOS = {
    "curandeiro": {
        "nome": "Chamar o curandeiro", "ouro": 150,
        "efeito": "cura_todos", "valor": 2,
        "porque": "Ferimento derruba o poder de quem está ferido — e poder "
                  "derrubado encolhe a fronteira dele.",
    },
    # 🐛 26/09/2026: este serviço criava um PERSONAGEM JOGÁVEL novo (um slot
    # do armário) por 900 de ouro — contra a regra de que personagem novo é
    # raro e vem da Torre. Agora traz um ALDEÃO de verdade (respeita o limite
    # da aldeia) e, a pedido do dev, custa a metade. O "acolher" por comida
    # saiu: este é o único jeito de recrutar.
    "recrutar": {
        "nome": "Recrutar um aldeão", "ouro": 450,
        "efeito": "aldeao", "valor": 1,
        "porque": "Mais gente é mais equipe na rua — e repõe quem morreu.",
    },
    # 👷 Voltou em 20/09 COM mecanismo: `clan.mao_de_obra` guarda o desconto
    # e `/api/clan/construir` lê e consome. Antes o efeito não tinha leitor.
    "mao_de_obra": {
        "nome": "Contratar mão de obra", "ouro": 500,
        "efeito": "desconto_construcao", "valor": 0.3,
        "porque": "A próxima construção gasta 30% menos metal e madeira. Vale "
                  "quando falta material — é a forma de trocar ouro por construção.",
    },
}

# De onde o ouro do clã vem, pro auditor conferir que existe fonte — um
# serviço sem fonte nenhuma seria preço que ninguém nunca paga de verdade.
FONTES_OURO = ["Cristais no mapa (Território)", "Ruínas no mapa (Território)",
               "achado raro em andar fundo do AFK"]
