# game/clan_ferreiro.py
"""
⚒️ O FERREIRO DA ALDEIA (20/09/2026 — fase 2 do redesenho do dev)

O pedido: uma página onde se gasta material pra evoluir as FERRAMENTAS dos
coletores e o EQUIPAMENTO dos guardas, em LOTE ("25 coletores com
ferramenta tier 1 → pra ir pro tier 2 custa tanto"), com o MESMO material
da forja dos personagens (rank 1/2/3), 5 tiers, mais caro quanto mais gente,
e quem chega novo precisa ser NIVELADO primeiro ao tier dos outros — mesma
mecânica, custo maior. Equipamento de guarda custa mais que ferramenta.

AS REGRAS
---------
- Duas trilhas: `ferramenta` (todo habitante — todo mundo coleta alguma
  coisa) e `equipamento` (quem tem talento de guarda ≥1★).
- Cada habitante guarda o próprio tier (1–5) em cada trilha. O "tier do
  lote" é o maior tier da trilha.
- Ação do ferreiro numa trilha:
    * há gente ABAIXO do tier do lote → NIVELAR: sobe todos esses até o
      lote, pagando cada degrau × 1,5 (é o "custo maior" do recém-chegado);
    * todos no tier do lote → EVOLUIR: sobe todo mundo um tier, pagando o
      degrau × quantidade de gente (mais gente, mais caro).
- O tier multiplica o resultado: ferramenta → produção do coletor;
  equipamento → poder do guarda.

Puro: sem banco. `clan_repo.usar_ferreiro` cobra e grava.
"""
from __future__ import annotations

import math

TIER_MAX = 5
# 20/09 (2ª rodada, dev: "separar conforme o que faz"): uma trilha POR FUNÇÃO.
# A ferramenta do lenhador não serve pro minerador — cada um tem o seu tier
# em cada função (`clan_habitante.tiers`), e quem MUDA de função chega nela
# como novato (Tier 1) e precisa ser nivelado. A trilha só conta quem está
# FAZENDO aquilo agora (numa equipe coletando o recurso, ou de guarda).
TRILHAS = ("agricultor", "lenhador", "cacador", "minerador", "guarda")
NOME_TRILHA = {"agricultor": "🌾 Ferramentas dos agricultores", "lenhador": "🪵 Ferramentas dos lenhadores",
               "cacador": "🦌 Ferramentas dos caçadores", "minerador": "⛏️ Ferramentas dos mineradores",
               "guarda": "🛡️ Equipamento dos guardas"}

# degrau (tier que se ALCANÇA) → (rank do material, quantidade por cabeça).
# O rank sobe com o tier: o fim da escada pede material de chefe (rank 3),
# o que casa com a escassez que o dev escolheu manter.
DEGRAU_FERRAMENTA = {2: (1, 3), 3: (2, 2), 4: (2, 4), 5: (3, 1)}
MULT_EQUIPAMENTO = 2          # equipamento de guarda custa o dobro
MULT_NIVELAR = 1.5            # nivelar quem chegou depois custa 50% a mais

_BONUS_FERRAMENTA = {1: 1.00, 2: 1.15, 3: 1.30, 4: 1.50, 5: 1.75}    # produção
_BONUS_EQUIPAMENTO = {1: 1.00, 2: 1.20, 3: 1.45, 4: 1.75, 5: 2.10}   # poder do guarda
BONUS = {t: (_BONUS_EQUIPAMENTO if t == "guarda" else _BONUS_FERRAMENTA) for t in TRILHAS}


def tier_de(hab: dict, trilha: str) -> int:
    """Tier do habitante NAQUELA função. Banco de antes desta rodada tinha um
    tier só pra ferramenta e outro pro equipamento — valem como ponto de
    partida."""
    tiers = hab.get("tiers") or {}
    if isinstance(tiers, str):
        import json
        try:
            tiers = json.loads(tiers or "{}")
        except ValueError:
            tiers = {}
    legado = hab.get("tier_equipamento") if trilha == "guarda" else hab.get("tier_ferramenta")
    return max(1, min(TIER_MAX, int(tiers.get(trilha) or legado or 1)))


def bonus_de(hab: dict, trilha: str) -> float:
    return BONUS[trilha][tier_de(hab, trilha)]


def membros_da_trilha(habitantes: list, trilha: str, trabalho: dict) -> list:
    """Quem está FAZENDO essa função agora (`trabalho` = {id: função})."""
    return [h for h in habitantes if int(h.get("vivo", 1)) and trabalho.get(h.get("id")) == trilha]


def custo_do_degrau(trilha: str, tier_alvo: int) -> tuple[int, int]:
    """(rank, quantidade POR CABEÇA) pra subir pro `tier_alvo`."""
    rank, qtd = DEGRAU_FERRAMENTA[int(tier_alvo)]
    return rank, qtd * (MULT_EQUIPAMENTO if trilha == "guarda" else 1)


def plano(habitantes: list, trilha: str, trabalho: dict) -> dict:
    """O que o ferreiro faz AGORA nessa trilha, e quanto custa. Não cobra."""
    grupo = membros_da_trilha(habitantes, trilha, trabalho)
    if not grupo:
        return {"acao": "nada", "motivo": "Ninguém fazendo isso agora.", "custo": {}, "quem": [],
                "tier_lote": 1, "total": 0}
    lote = max(tier_de(h, trilha) for h in grupo)
    atrasados = [h for h in grupo if tier_de(h, trilha) < lote]
    custo: dict[int, int] = {}
    if atrasados:
        for h in atrasados:
            for alvo in range(tier_de(h, trilha) + 1, lote + 1):
                rank, qtd = custo_do_degrau(trilha, alvo)
                # arredonda pra CIMA: round() do Python faz 4,5 → 4, e o
                # "custo maior" do novato viraria custo MENOR que 1,5×
                custo[rank] = custo.get(rank, 0) + math.ceil(qtd * MULT_NIVELAR)
        return {"acao": "nivelar", "tier_lote": lote, "alvo": lote, "custo": custo,
                "quem": [h.get("id") for h in atrasados], "total": len(grupo)}
    if lote >= TIER_MAX:
        return {"acao": "maximo", "tier_lote": lote, "custo": {}, "quem": [], "total": len(grupo)}
    rank, qtd = custo_do_degrau(trilha, lote + 1)
    return {"acao": "evoluir", "tier_lote": lote, "alvo": lote + 1, "custo": {rank: qtd * len(grupo)},
            "quem": [h.get("id") for h in grupo], "total": len(grupo)}
