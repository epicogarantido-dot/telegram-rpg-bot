# game/global_boss.py
"""
🐲 BOSS GLOBAL (08/07/2026) — um único boss compartilhado por TODOS os
jogadores do servidor ao mesmo tempo. Ganha fases conforme perde HP,
ficando mais forte a cada uma. Quando cai, todo mundo que participou
ganha uma fatia do ouro, proporcional ao dano que causou.
"""
import random
import time

ATTACK_COOLDOWN_SECONDS = 10 * 60  # 10 minutos entre ataques por jogador

# 🔥 CORRIGIDO/REDESENHADO (08/07/2026): antes eram 5 fases fixas com
# multiplicadores pré-definidos. Agora é contínuo: o boss DOBRA de ATK/DEF
# a cada 10% de HP perdido — extremamente punitivo perto do fim, de propósito.
PCT_POR_TIER = 0.10   # a cada 10% de HP perdido...
MULT_POR_TIER = 2.0   # ...dobra ATK/DEF

# Escala por geração (a cada boss derrotado, o próximo nasce mais forte)
BASE_HP = 5_000_000     # 🔥 HP bem maior — é um projeto coletivo de verdade
BASE_ATK = 350
BASE_DEF = 120
GERACAO_SCALING = 0.25  # +25% de tudo por geração

BASE_OURO_POOL = 2_000_000  # 🔥 (08/07/2026): estrelas trocadas por MUITO ouro, por questão de monetização
POOL_SCALING = 0.20  # a recompensa também cresce por geração


def _gerar_novo_boss(geracao: int) -> dict:
    mult = (1 + GERACAO_SCALING) ** max(0, geracao - 1)
    hp = int(BASE_HP * mult)
    nomes = ["Wyrm do Abismo", "Titã Cinzento", "Devorador de Mundos", "Leviatã Ancestral", "Arauto do Fim"]
    return {
        "geracao": geracao,
        "nome": random.choice(nomes),
        "hp": hp,
        "hp_max": hp,
        "atk": int(BASE_ATK * mult),
        "def": int(BASE_DEF * mult),
        "contributors": {},
        "attack_log": {},
        "spawned_at": int(time.time()),
        "logs": [],
        "fase_anunciada": 0,
    }


def get_or_create_boss() -> dict:
    from game.global_boss_repo import get_boss_state, save_boss_state

    state = get_boss_state()
    if not state or state.get("hp", 0) <= 0:
        geracao_anterior = state.get("geracao", 0) if state else 0
        novo = _gerar_novo_boss(geracao_anterior + 1)
        save_boss_state(novo)
        return novo
    return state


def get_current_phase_idx(state: dict) -> int:
    """Quantos tiers de 10% de HP já foram perdidos — cada um dobra o
    ATK/DEF do boss. 0 = ainda no HP cheio (100%-91%), 1 = perdeu o
    primeiro 10%, e assim por diante até 9 (HP crítico, quase morto)."""
    pct = state.get("hp", 0) / max(1, state.get("hp_max", 1))
    perdido = 1.0 - pct
    tier = int(perdido / PCT_POR_TIER)
    return min(9, tier)


def get_phase_multiplier(fase_idx: int) -> float:
    """2x por tier, composto — fase 0 = 1x, fase 1 = 2x, fase 2 = 4x, ... fase 9 = 512x."""
    return MULT_POR_TIER ** fase_idx


def get_phase_name(fase_idx: int) -> str:
    if fase_idx <= 0:
        return "Fase 1 — Desperto"
    if fase_idx >= 9:
        return f"Fase {fase_idx + 1} — CATACLISMA"
    nomes_intermediarios = ["Irritado", "Furioso", "Enfurecido", "Descontrolado", "Devastador", "Apocalíptico", "Aniquilador", "Cataclísmico"]
    return f"Fase {fase_idx + 1} — {nomes_intermediarios[fase_idx - 1]}"


def pode_atacar(p: dict, state: dict) -> tuple:
    pid = str(p.get("user_id") or p.get("telegram_id"))
    ultimo = state.get("attack_log", {}).get(pid, 0)
    passou = int(time.time()) - int(ultimo)
    if passou >= ATTACK_COOLDOWN_SECONDS:
        return True, 0
    return False, ATTACK_COOLDOWN_SECONDS - passou


def attack_global_boss(p: dict) -> str:
    """🐲 v2 (09/07/2026): antes era 1 golpe a cada 10 minutos — agora é uma
    BATALHA de verdade. Cada clique em Atacar troca golpes com o boss, e o
    dano vai sendo acumulado numa sessão local. O dano só é aplicado no
    boss global de verdade quando o jogador FOGE (botão Fugir) ou MORRE —
    ver flee_global_boss / _aplicar_dano_sessao. Isso deixa a luta contínua
    e divertida, em vez de um clique isolado com espera longa."""
    from game.logic import recalc, get_combat_triggers, calc_final_damage, check_hit_and_evasion

    recalc(p)
    state = get_or_create_boss()
    pid = str(p.get("user_id") or p.get("telegram_id"))

    # Sessão local de batalha (guardada no próprio jogador)
    sessao = p.setdefault("global_boss_session", {"dano_acumulado": 0, "turnos": 0, "boss_geracao": state.get("geracao", 1)})

    # Se a geração mudou (o boss anterior morreu e nasceu outro), zera a sessão
    if sessao.get("boss_geracao") != state.get("geracao", 1):
        sessao = {"dano_acumulado": 0, "turnos": 0, "boss_geracao": state.get("geracao", 1)}
        p["global_boss_session"] = sessao

    fase_idx = get_current_phase_idx(state)
    mult_fase = get_phase_multiplier(fase_idx)

    p_atk = int(p.get("atk", 5))
    p_def = int(p.get("def", 0))
    p_crit = int(p.get("crit", 0))
    p_acc = int(p.get("acc", 0))
    p_eva = int(p.get("eva", 0))
    trig = get_combat_triggers(p)

    boss_def_efetiva = int(state["def"] * mult_fase)
    boss_atk_efetivo = int(state["atk"] * mult_fase)

    logs = []
    sessao["turnos"] = int(sessao.get("turnos", 0)) + 1

    # HP restante do boss considerando o dano já acumulado nesta sessão
    hp_boss_visivel = max(0, int(state["hp"]) - int(sessao.get("dano_acumulado", 0)))

    acertou, log_hit, _ = check_hit_and_evasion(p_acc, 5, trig, {}, p.get("username", "Você"), state["nome"])
    if log_hit:
        logs.append(log_hit.strip())

    if acertou:
        dano_causado, log_dmg = calc_final_damage(p_atk, boss_def_efetiva, p_crit, trig, {}, hp_boss_visivel, state["hp_max"])
        logs.extend(x.strip() for x in log_dmg if x.strip())
        sessao["dano_acumulado"] = int(sessao.get("dano_acumulado", 0)) + dano_causado
        hp_boss_visivel = max(0, hp_boss_visivel - dano_causado)
        logs.append(f"⚔️ Você causou {dano_causado} de dano! (total nesta luta: {sessao['dano_acumulado']})")

    # Boss revida (se ainda estiver vivo)
    if hp_boss_visivel > 0:
        acertou_boss, _lhb, _ = check_hit_and_evasion(boss_atk_efetivo // 10, p_eva, {}, trig, state["nome"], p.get("username", "Você"))
        if acertou_boss:
            dano_recebido, _ldb = calc_final_damage(boss_atk_efetivo, p_def, 10, {}, trig, p.get("hp", 1), p.get("hp_max", 1))
            p["hp"] = max(0, int(p.get("hp", 1)) - dano_recebido)
            logs.append(f"💥 {state['nome']} revidou: -{dano_recebido} HP em você!")

    # Barra de HP do boss
    pct_boss = int(hp_boss_visivel / max(1, state["hp_max"]) * 100)
    logs.append(f"\n🐲 {state['nome']}: {hp_boss_visivel:,}/{state['hp_max']:,} HP ({pct_boss}%)")

    # O jogador morreu? aplica o dano e encerra a sessão
    if p.get("hp", 0) <= 0:
        resumo = _aplicar_dano_sessao(p, motivo="morte")
        logs.append("\n💀 Você caiu na luta contra o boss!")
        logs.append(resumo)
        return "\n".join(logs)

    # O boss morreu com o dano acumulado? aplica e finaliza
    if hp_boss_visivel <= 0:
        resumo = _aplicar_dano_sessao(p, motivo="kill")
        logs.append(resumo)
        return "\n".join(logs)

    return "\n".join(logs)


def _aplicar_dano_sessao(p: dict, motivo: str = "flee") -> str:
    """Aplica o dano acumulado da sessão local no boss global de verdade,
    credita a contribuição do jogador e encerra a sessão. Chamado quando o
    jogador foge, morre, ou mata o boss."""
    from game.global_boss_repo import save_boss_state

    state = get_or_create_boss()
    pid = str(p.get("user_id") or p.get("telegram_id"))
    sessao = p.get("global_boss_session") or {}
    dano = int(sessao.get("dano_acumulado", 0))

    if dano <= 0:
        p["global_boss_session"] = {"dano_acumulado": 0, "turnos": 0, "boss_geracao": state.get("geracao", 1)}
        return "Nenhum dano causado nesta sessão."

    # Aplica no boss e credita contribuição
    state["hp"] = max(0, int(state["hp"]) - dano)
    contrib = state.setdefault("contributors", {})
    contrib[pid] = contrib.get(pid, 0) + dano

    msg = f"📊 <b>Dano total aplicado no boss: {dano:,}</b>"

    # Zera a sessão
    p["global_boss_session"] = {"dano_acumulado": 0, "turnos": 0, "boss_geracao": state.get("geracao", 1)}

    # Boss morreu?
    if state["hp"] <= 0:
        msg += "\n\n" + _finalizar_boss(state)
    else:
        save_boss_state(state)

    return msg


# ⚙️ 25/09/2026 (dev): "boss global faz uma batalha inteira automática".
# Em vez de um clique por troca de golpes, um toque roda a luta toda: troca
# golpes até VOCÊ cair ou o BOSS cair (o dano vai pro boss nos dois casos,
# pelo mesmo `_aplicar_dano_sessao`). O teto de trocas existe pra quem tem
# defesa tão alta que o boss não o derruba: ao bater no teto, a luta encerra
# e o dano é aplicado do mesmo jeito. Sessão antiga de clique, se sobrou, é
# aplicada antes — nenhum dano se perde na troca de sistema.
TETO_TROCAS_AUTO = 150


def batalha_automatica(p: dict) -> dict:
    from game.logic import recalc
    recalc(p)
    pid = str(p.get("user_id") or p.get("telegram_id"))
    if int((p.get("global_boss_session") or {}).get("dano_acumulado", 0)) > 0:
        _aplicar_dano_sessao(p, motivo="flee")
    if int(p.get("hp", 0)) <= 0:
        return {"ok": False, "erro": "Você está sem vida — cure-se antes de enfrentar o boss."}
    estado = get_or_create_boss()
    geracao = estado.get("geracao", 1)
    contrib_antes = int((estado.get("contributors") or {}).get(pid, 0))
    hp_inicio = int(p.get("hp", 0))
    trocas, linhas, fim = 0, [], "teto"
    while trocas < TETO_TROCAS_AUTO:
        linhas.append(attack_global_boss(p))
        trocas += 1
        if int(p.get("hp", 0)) <= 0:
            fim = "morreu"          # attack_global_boss já aplicou o dano
            break
        agora = get_or_create_boss()
        if agora.get("geracao", 1) != geracao or int(agora.get("hp", 1)) <= 0:
            fim = "matou"           # o boss caiu (e renasceu na próxima geração)
            break
    if fim == "teto":
        _aplicar_dano_sessao(p, motivo="flee")
    depois = get_or_create_boss()
    if depois.get("geracao", 1) == geracao:
        dano = int((depois.get("contributors") or {}).get(pid, 0)) - contrib_antes
    else:
        dano = None                 # boss novo: a contribuição do velho foi premiada
    return {"ok": True, "fim": fim, "trocas": trocas, "dano": dano,
            "hp_inicio": hp_inicio, "hp_fim": int(p.get("hp", 0)),
            "log": "\n\n".join(linhas[-3:])}


def flee_global_boss(p: dict) -> str:
    """🏃 Fugir da luta contra o Boss Global: encerra a sessão e aplica o
    dano acumulado no boss de verdade. Foi o que o usuário pediu — sair a
    qualquer momento sem perder o progresso do dano."""
    resumo = _aplicar_dano_sessao(p, motivo="flee")
    return f"🏃 <b>Você recuou da batalha!</b>\n{resumo}"


def _attack_global_boss_legacy(p: dict) -> str:
    from game.logic import recalc, get_combat_triggers, calc_final_damage, check_hit_and_evasion
    from game.global_boss_repo import save_boss_state

    recalc(p)
    state = get_or_create_boss()
    pid = str(p.get("user_id") or p.get("telegram_id"))

    pode, restante = pode_atacar(p, state)
    if not pode:
        minutos = restante // 60
        segundos = restante % 60
        return f"⏳ Você já atacou recentemente. Espere mais {minutos}m{segundos}s pra atacar de novo."

    fase_idx = get_current_phase_idx(state)
    mult_fase = get_phase_multiplier(fase_idx)
    nome_fase = get_phase_name(fase_idx)

    p_atk = int(p.get("atk", 5))
    p_def = int(p.get("def", 0))
    p_crit = int(p.get("crit", 0))
    p_acc = int(p.get("acc", 0))
    p_eva = int(p.get("eva", 0))
    trig = get_combat_triggers(p)

    boss_def_efetiva = int(state["def"] * mult_fase)
    boss_atk_efetivo = int(state["atk"] * mult_fase)

    logs = []

    acertou, log_hit, _ = check_hit_and_evasion(p_acc, 5, trig, {}, p.get("username", "Você"), state["nome"])
    if log_hit:
        logs.append(log_hit.strip())

    dano_causado = 0
    if acertou:
        dano_causado, log_dmg = calc_final_damage(p_atk, boss_def_efetiva, p_crit, trig, {}, state["hp"], state["hp_max"])
        logs.extend(x.strip() for x in log_dmg if x.strip())
        state["hp"] = max(0, state["hp"] - dano_causado)

        contrib = state.setdefault("contributors", {})
        contrib[pid] = contrib.get(pid, 0) + dano_causado
        logs.append(f"⚔️ Você causou {dano_causado} de dano no {state['nome']}!")

    if state["hp"] > 0:
        acertou_boss, log_hit_b, _ = check_hit_and_evasion(boss_atk_efetivo // 10, p_eva, {}, trig, state["nome"], p.get("username", "Você"))
        if acertou_boss:
            dano_recebido, log_dmg_b = calc_final_damage(boss_atk_efetivo, p_def, 10, {}, trig, p.get("hp", 1), p.get("hp_max", 1))
            p["hp"] = max(0, int(p.get("hp", 1)) - dano_recebido)
            logs.append(f"💥 {state['nome']} revidou e causou {dano_recebido} de dano em você!")

    state.setdefault("attack_log", {})[pid] = int(time.time())

    nova_fase_idx = get_current_phase_idx(state)
    if nova_fase_idx > state.get("fase_anunciada", 0) and state["hp"] > 0:
        state["fase_anunciada"] = nova_fase_idx
        nome_nova_fase = get_phase_name(nova_fase_idx)
        logs.append(f"🌋 <b>O BOSS EVOLUIU! {nome_nova_fase}!</b> Ele está mais forte agora.")

    resultado_msg = "\n".join(logs)

    if state["hp"] <= 0:
        resultado_msg += "\n\n" + _finalizar_boss(state)
    else:
        save_boss_state(state)

    return resultado_msg


def _finalizar_boss(state: dict) -> str:
    from game.sql_repo import load_player, save_player_sql
    from game.global_boss_repo import save_boss_state
    from infra.cache_bus import mark_dirty

    geracao = state.get("geracao", 1)
    mult = (1 + POOL_SCALING) ** max(0, geracao - 1)
    ouro_pool = int(BASE_OURO_POOL * mult)

    contributors = state.get("contributors", {})
    dano_total = sum(contributors.values()) or 1

    resumo = [f"🏆 <b>{state['nome']} FOI DERROTADO!</b> (Geração {geracao})\n"]
    resumo.append(f"💰 Pool: {ouro_pool:,}g dividido entre {len(contributors)} participante(s):\n")

    ranking = sorted(contributors.items(), key=lambda x: x[1], reverse=True)
    for i, (pid, dano) in enumerate(ranking[:10]):
        pct = dano / dano_total
        ouro_ganho = int(ouro_pool * pct)
        try:
            pdata = load_player(int(pid))
            if pdata:
                pdata["gold"] = int(pdata.get("gold", 0)) + ouro_ganho
                save_player_sql(int(pid), pdata)
                mark_dirty(int(pid))
                nome = pdata.get("username") or f"Jogador {pid}"
                medalha = ["🥇", "🥈", "🥉"][i] if i < 3 else "🔹"
                resumo.append(f"{medalha} {nome}: {int(pct*100)}% do dano → +{ouro_ganho:,}g")
        except Exception:
            continue

    if len(ranking) > 10:
        resumo.append(f"... e mais {len(ranking) - 10} participante(s).")

    novo_boss = _gerar_novo_boss(geracao + 1)
    save_boss_state(novo_boss)
    resumo.append(f"\n🐲 Um novo boss (Geração {geracao + 1}) já apareceu, mais forte que o anterior!")

    return "\n".join(resumo)
