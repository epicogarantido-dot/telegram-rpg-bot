"""
Motor de storylets (narrativa por qualidades).

O CICLO, a cada turno:
    1. FILTRA  — tira o que não bate com o estado e o que está em cooldown
    2. PESA    — cada sobrevivente tem um "tamanho" no saco
    3. SORTEIA — um, proporcional ao peso
    4. APLICA  — a escolha muda as qualidades, o que muda o saco do próximo

O efeito que faz isso valer a pena: eventos de um arco recebem peso alto e
dominam o saco enquanto o arco durar. Não é preciso encadear 600 eventos —
bastam uns 30 com memória visível no meio de 200 neutros, porque no momento
em que o jogador percebe que um evento lembrou da escolha dele, o jogo
inteiro passa a parecer autoral.

TRÊS COISAS QUE SEPARAM ISSO DE UM MENU DE BOTÕES
-------------------------------------------------
- A escolha certa PODE FALHAR. Cada opção é um teste de atributo, e o
  tamanho da aposta mexe na dificuldade: apostar alto paga mais e erra mais.
- CONSEQUÊNCIA ATRASADA. Uma opção agenda um evento pra 5–30 turnos à
  frente. O jogador esquece; o jogo não.
- CONSELHEIROS COM VIÉS opinam antes — e têm agenda própria. Informação
  vira recurso, e informação enviesada vira decisão de verdade.

POR QUE O AUDITOR VEM JUNTO E NÃO DEPOIS
----------------------------------------
Este sistema é a fábrica do bug recorrente deste projeto: conteúdo que
existe e ninguém alcança. Com 200 storylets condicionais, um evento
inalcançável não quebra nada — o jogo continua rodando e ninguém percebe.
Por isso `auditor.py` nasce no mesmo dia que o motor, e não depois do
conteúdo: contagem zero é bug, e só uma simulação em massa encontra.

ONDE O ESTADO MORA
------------------
Tudo dentro de `p["storylets"]`, que é um campo só. Precisa estar em
`_extra_fields` do sql_repo — senão vira o mesmo bug de `pending_orders` e
`conta_bloqueada`, que gravavam em lugar nenhum e sumiam a cada reinício.
"""
from __future__ import annotations

import json
import os
import random
import re

# Quantas entradas do log de causa guardar por jogador. O log é a resposta
# pra "por que isso apareceu?" — sem teto, ele vira o maior campo do banco.
LIMITE_LOG = 60

# Tamanho do dado do teste de atributo. d20 dá granularidade suficiente pra
# dificuldade 8 e 12 serem sensivelmente diferentes, sem virar planilha.
DADO = 20

_RE_COMPARACAO = re.compile(r"^(>=|<=|==|!=|>|<)?\s*(-?\d+)$")


class ErroStorylet(Exception):
    pass


# ---------------------------------------------------------------- estado

def estado_inicial() -> dict:
    return {"turno": 0, "qualidades": {}, "flags": [], "cooldowns": {},
            "agenda": [], "log": [], "atual": None}


def _estado(p: dict) -> dict:
    st = p.get("storylets")
    if not isinstance(st, dict):
        st = estado_inicial()
        p["storylets"] = st
    for chave, padrao in estado_inicial().items():
        st.setdefault(chave, padrao)
    # 🤝 a relação com as aldeias vizinhas começa NEUTRA (50), não em zero —
    # zero seria "odiados por todos" desde o primeiro dia (e os storylets de
    # vizinhança que pedem relação boa nunca sairiam). Uma fonte só.
    st["qualidades"].setdefault("vizinhos", 50)
    return st


def qualidade(p: dict, nome: str, padrao: int = 0) -> int:
    return int(_estado(p)["qualidades"].get(nome, padrao))


def tem_flag(p: dict, flag: str) -> bool:
    return flag in _estado(p)["flags"]


# ------------------------------------------------------------- condições

def _compara(valor: int, expressao) -> bool:
    """Aceita 12, "12", ">=3", "<40". Número solto significa igualdade."""
    if isinstance(expressao, bool):
        return bool(valor) == expressao
    if isinstance(expressao, int):
        return valor == expressao
    m = _RE_COMPARACAO.match(str(expressao).strip())
    if not m:
        raise ErroStorylet(f"Condição inválida: {expressao!r}")
    op, alvo = m.group(1) or "==", int(m.group(2))
    return {">=": valor >= alvo, "<=": valor <= alvo, "==": valor == alvo,
            "!=": valor != alvo, ">": valor > alvo, "<": valor < alvo}[op]


def condicoes_batem(p: dict, condicoes: dict) -> tuple[bool, str]:
    """Devolve (passou, motivo_da_recusa). O motivo é o que alimenta o
    auditor: sem ele, "esse evento nunca aparece" não vem com explicação."""
    st = _estado(p)
    for chave, esperado in (condicoes or {}).items():
        if chave == "flag":
            faltando = [f for f in _lista(esperado) if f not in st["flags"]]
            if faltando:
                return False, f"falta a flag {faltando[0]}"
        elif chave == "flag_ausente":
            presentes = [f for f in _lista(esperado) if f in st["flags"]]
            if presentes:
                return False, f"a flag {presentes[0]} está presente"
        elif chave == "turno":
            if not _compara(int(st["turno"]), esperado):
                return False, f"turno {st['turno']} não satisfaz {esperado}"
        else:
            valor = int(st["qualidades"].get(chave, 0))
            if not _compara(valor, esperado):
                return False, f"{chave}={valor} não satisfaz {esperado}"
    return True, ""


def _lista(x):
    return x if isinstance(x, (list, tuple)) else [x]


# ------------------------------------------------- montar e sortear o saco

# Onde o storylet pode sair. O clã é o contexto padrão — é onde o motor
# nasceu —, e "torre" é o que a exploração sorteia: gente presa lá dentro,
# nativa ou mandada pra lá, que é de onde saem os aldeões e os outros
# usuários de aura.
#
# Um storylet sem `contexto` é do clã: assim os 31 que já existem continuam
# valendo sem precisar editar arquivo nenhum.
CONTEXTO_PADRAO = "cla"


def contexto_do(ev: dict) -> str:
    return str(ev.get("contexto") or CONTEXTO_PADRAO)


def montar_saco(p: dict, catalogo: dict, contexto: str | None = None) -> tuple[list, dict]:
    """Devolve (elegíveis, recusados_por_motivo).

    `contexto` separa os sacos: sem ele, o storylet de encontro na Torre
    poderia sair na tela de Decisões do clã e vice-versa — e o auditor
    marcaria os dois como alcançáveis mesmo assim, porque estariam todos no
    mesmo saco.

    O segundo valor existe pro auditor e pro log de causa. Descartar em
    silêncio é como um storylet fica inalcançável sem ninguém notar.
    """
    st = _estado(p)
    turno = int(st["turno"])
    elegiveis, recusados = [], {}

    for sid, ev in catalogo.items():
        if contexto is not None and contexto_do(ev) != contexto:
            recusados[sid] = f"contexto {contexto_do(ev)}, pedido {contexto}"
            continue
        venceu_em = st["cooldowns"].get(sid)
        if venceu_em is not None and turno < int(venceu_em):
            recusados[sid] = f"cooldown até o turno {venceu_em}"
            continue
        passou, motivo = condicoes_batem(p, ev.get("condicoes"))
        if not passou:
            recusados[sid] = motivo
            continue
        peso = int(ev.get("peso", 10))
        if peso <= 0:
            recusados[sid] = "peso zero"
            continue
        elegiveis.append((sid, peso))
    return elegiveis, recusados


def sortear(p: dict, catalogo: dict, rng: random.Random | None = None,
            contexto: str | None = None) -> tuple[str | None, dict]:
    """Escolhe o próximo storylet. A agenda tem prioridade: consequência
    atrasada que chegou a hora não disputa sorteio, senão ela poderia nunca
    sair e a promessa feita ao jogador ficaria sem cumprir."""
    rng = rng or random
    st = _estado(p)
    turno = int(st["turno"])

    vencidos = [a for a in st["agenda"] if int(a.get("turno", 0)) <= turno]
    for agendado in vencidos:
        sid = agendado.get("evento")
        if sid in catalogo:
            st["agenda"].remove(agendado)
            _registrar(st, sid, f"agendado no turno {agendado.get('origem', '?')}")
            st["atual"] = sid
            return sid, {"origem": "agenda"}
        st["agenda"].remove(agendado)   # evento agendado que não existe mais

    elegiveis, recusados = montar_saco(p, catalogo, contexto)
    if not elegiveis:
        st["atual"] = None
        return None, {"origem": "vazio", "recusados": recusados}

    total = sum(peso for _, peso in elegiveis)
    corte = rng.uniform(0, total)
    acumulado = 0
    for sid, peso in elegiveis:
        acumulado += peso
        if corte <= acumulado:
            _registrar(st, sid, f"sorteado entre {len(elegiveis)} (peso {peso}/{total})")
            st["atual"] = sid
            return sid, {"origem": "saco", "elegiveis": len(elegiveis),
                         "peso": peso, "total": total}
    sid = elegiveis[-1][0]
    st["atual"] = sid
    return sid, {"origem": "saco"}


# ------------------------------------------------------- aplicar a escolha

def _dificuldade_efetiva(teste: dict, aposta: int) -> int:
    """A aposta mexe na dificuldade: apostar alto paga mais e erra mais.
    É o que faz o tamanho do gesto ser uma decisão, não um número solto."""
    base = int(teste.get("dificuldade", 10))
    por_aposta = float(teste.get("por_aposta", 0))
    return int(round(base + por_aposta * max(0, aposta)))


def escolher(p: dict, catalogo: dict, indice: int, aposta: int = 0,
             rng: random.Random | None = None, executor: dict | None = None) -> dict:
    """Aplica a opção `indice` do storylet atual.

    Devolve o que aconteceu, com o suficiente pra a tela contar a história
    e pro auditor contabilizar: se houve teste, o que rolou, qual lado do
    resultado foi aplicado, e o que ficou agendado.
    """
    rng = rng or random
    st = _estado(p)
    sid = st.get("atual")
    if not sid or sid not in catalogo:
        raise ErroStorylet("Nenhum evento em aberto.")
    ev = catalogo[sid]
    opcoes = ev.get("opcoes") or []
    if not (0 <= indice < len(opcoes)):
        raise ErroStorylet(f"Opção {indice} não existe neste evento.")
    opcao = opcoes[indice]

    # Uma opção pode estar visível e indisponível (falta recurso). Isso é
    # diferente de estar escondida, e a diferença importa: opção cinza com
    # motivo ensina o jogo; opção ausente não ensina nada.
    passou, motivo = condicoes_batem(p, opcao.get("condicoes"))
    if not passou:
        raise ErroStorylet(f"Essa escolha não está disponível: {motivo}.")

    resultado = {"storylet": sid, "opcao": indice,
                 "label": opcao.get("label", ""), "teste": None, "sucesso": True}

    teste = opcao.get("teste")
    if teste:
        # 🎲 QUEM EXECUTA IMPORTA (mecânica central do Six Ages / King of
        # Dragon Pass): o conselheiro não só opina, a PERÍCIA DELE é testada.
        # É isso que transforma "quem senta no conselho" numa decisão de
        # verdade em vez de sabor. Sem executor, cai na qualidade do clã.
        pericia = teste.get("pericia") or teste.get("atributo", "")
        if executor and pericia in (executor.get("pericias") or {}):
            valor = int(executor["pericias"][pericia])
            de_quem = executor.get("nome", executor.get("id"))
        else:
            valor = int(st["qualidades"].get(pericia, 0))
            de_quem = None
        dificuldade = _dificuldade_efetiva(teste, aposta)
        rolagem = rng.randint(1, DADO)
        total = rolagem + valor
        resultado["sucesso"] = total >= dificuldade
        resultado["teste"] = {"atributo": pericia, "valor": valor,
                              "rolagem": rolagem, "total": total,
                              "dificuldade": dificuldade, "executor": de_quem}

    lado = "sucesso" if resultado["sucesso"] else "falha"
    efeitos = opcao.get(lado) or opcao.get("efeitos") or {}
    resultado["efeitos"] = _aplicar_efeitos(p, efeitos, aposta)

    agenda = opcao.get("agenda") or (efeitos.get("agenda") if isinstance(efeitos, dict) else None)
    if agenda:
        for item in _lista(agenda):
            quando = int(st["turno"]) + int(item.get("em_turnos", 10))
            st["agenda"].append({"evento": item.get("evento"), "turno": quando,
                                 "origem": st["turno"]})
            resultado.setdefault("agendado", []).append(
                {"evento": item.get("evento"), "turno": quando})

    cooldown = int(ev.get("cooldown", 0))
    if cooldown > 0:
        st["cooldowns"][sid] = int(st["turno"]) + cooldown

    quem = (resultado.get("teste") or {}).get("executor")
    _registrar(st, sid, f"escolheu '{opcao.get('label','')}'"
                        + (f", executado por {quem}" if quem else "") + f" -> {lado}")
    st["atual"] = None
    st["turno"] = int(st["turno"]) + 1
    return resultado


def _aplicar_efeitos(p: dict, efeitos: dict, aposta: int = 0) -> dict:
    st = _estado(p)
    aplicados = {}
    for chave, valor in (efeitos or {}).items():
        if chave == "agenda":
            continue
        if chave == "flag":
            for f in _lista(valor):
                if f not in st["flags"]:
                    st["flags"].append(f)
            aplicados["flag"] = _lista(valor)
        elif chave == "flag_remover":
            for f in _lista(valor):
                if f in st["flags"]:
                    st["flags"].remove(f)
            aplicados["flag_remover"] = _lista(valor)
        else:
            delta = int(valor)
            if isinstance(valor, str) and valor.endswith("*aposta"):
                delta = int(valor[:-7]) * max(0, aposta)
            antes = int(st["qualidades"].get(chave, 0))
            st["qualidades"][chave] = antes + delta
            aplicados[chave] = delta
    return aplicados


def _registrar(st: dict, sid: str, motivo: str) -> None:
    """Log de causa: responde 'por que isso apareceu?'. Sem ele, um arco
    que dá errado vira adivinhação."""
    st["log"].append({"turno": int(st["turno"]), "storylet": sid, "motivo": motivo})
    if len(st["log"]) > LIMITE_LOG:
        del st["log"][:-LIMITE_LOG]


# ------------------------------------------------------------ conselheiros

def conselhos(p: dict, catalogo: dict, conselheiros: list) -> list:
    """O que cada conselheiro diz sobre o evento atual.

    O viés é o ponto: o conselheiro pontua as opções pelas qualidades que
    ELE valoriza, não pelo que é melhor pro jogador. Conselho honesto seria
    só uma dica; conselho enviesado é informação que precisa ser pesada.
    """
    st = _estado(p)
    sid = st.get("atual")
    if not sid or sid not in catalogo:
        return []
    opcoes = catalogo[sid].get("opcoes") or []
    saida = []
    for c in conselheiros or []:
        pesos = c.get("valoriza") or {}
        melhor, nota_melhor = None, None
        for i, opcao in enumerate(opcoes):
            efeitos = opcao.get("sucesso") or opcao.get("efeitos") or {}
            nota = sum(int(efeitos.get(q, 0)) * float(peso) for q, peso in pesos.items())
            if nota_melhor is None or nota > nota_melhor:
                melhor, nota_melhor = i, nota
        if melhor is None:
            continue
        # A perícia dele no teste da opção que ele recomenda. É o número que
        # o jogador pesa: um conselheiro pode estar certo e ser incapaz de
        # executar — e seguir o conselho dele é apostar nas duas coisas.
        teste = (opcoes[melhor].get("teste") or {})
        pericia = teste.get("pericia") or teste.get("atributo")
        saida.append({"conselheiro": c.get("id"), "nome": c.get("nome", c.get("id")),
                      "recomenda": melhor,
                      "pericia": pericia,
                      "valor_pericia": int((c.get("pericias") or {}).get(pericia, 0)) if pericia else None, "fala": (c.get("falas") or {}).get(
                          opcoes[melhor].get("label", ""), c.get("fala_padrao", "")),
                      # Confiança é quão forte ele defende — não quão certo ele está.
                      "conviccao": round(float(nota_melhor or 0), 1)})
    return saida


# ---------------------------------------------------------------- catálogo

def carregar_catalogo(caminho: str) -> dict:
    """Lê os storylets de um .json ou de uma pasta de .json."""
    catalogo = {}
    if os.path.isdir(caminho):
        arquivos = [os.path.join(caminho, f) for f in sorted(os.listdir(caminho))
                    if f.endswith(".json")]
    else:
        arquivos = [caminho]
    for arq in arquivos:
        with open(arq, encoding="utf-8") as f:
            dados = json.load(f)
        for ev in (dados if isinstance(dados, list) else dados.get("storylets", [])):
            sid = ev.get("id")
            if not sid:
                raise ErroStorylet(f"Storylet sem id em {arq}")
            if sid in catalogo:
                raise ErroStorylet(f"Storylet duplicado: {sid}")
            catalogo[sid] = ev
    return catalogo


def validar_catalogo(catalogo: dict) -> list[str]:
    """Erros que o auditor não pega porque impedem a simulação de rodar:
    opção sem label, agenda apontando pra evento inexistente, condição mal
    escrita. Checagem estática, barata, roda antes de tudo."""
    problemas = []
    for sid, ev in catalogo.items():
        if not ev.get("texto"):
            problemas.append(f"{sid}: sem texto")
        opcoes = ev.get("opcoes") or []
        if not opcoes:
            problemas.append(f"{sid}: sem opções — evento sem saída")
        for i, o in enumerate(opcoes):
            if not o.get("label"):
                problemas.append(f"{sid}[{i}]: opção sem label")
            if o.get("teste") and not o.get("falha"):
                problemas.append(f"{sid}[{i}]: tem teste mas não define 'falha' — "
                                 f"falhar não faria nada, e aí o teste é enfeite")
            for item in _lista(o.get("agenda") or []):
                alvo = item.get("evento")
                if alvo and alvo not in catalogo:
                    problemas.append(f"{sid}[{i}]: agenda aponta pra '{alvo}', que não existe")
        for cond in (ev.get("condicoes") or {}).items():
            chave, expr = cond
            if chave in ("flag", "flag_ausente"):
                continue
            try:
                _compara(0, expr)
            except ErroStorylet as e:
                problemas.append(f"{sid}: {e}")
    return problemas


# ------------------------------------------------------------------ saga

def saga(p: dict, limite: int = 40) -> list:
    """O log de causa vira história legível.

    Copiado do King of Dragon Pass, onde "a saga escreve a história pra
    você". Aqui ela sai de graça: o log já existia como ferramenta de
    diagnóstico ("por que este evento apareceu?"). Virar texto que o jogador
    lê é a mesma informação com outro público.

    É o que faz a memória do jogo ficar VISÍVEL. Sem isso, um arco de oito
    turnos acontece e ninguém percebe que foi um arco.
    """
    st = _estado(p)
    linhas = []
    for entrada in st["log"][-limite:]:
        motivo = entrada.get("motivo", "")
        if motivo.startswith("escolheu"):
            linhas.append({"turno": entrada["turno"], "tipo": "escolha", "texto": motivo})
        elif motivo.startswith("agendado"):
            # Consequência atrasada chegando: é o momento em que o jogador
            # descobre que o jogo lembrou.
            linhas.append({"turno": entrada["turno"], "tipo": "consequencia",
                           "texto": f"veio a consequência de uma escolha anterior ({motivo})"})
        else:
            linhas.append({"turno": entrada["turno"], "tipo": "evento", "texto": motivo})
    return linhas
