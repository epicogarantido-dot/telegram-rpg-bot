# game/mounts.py
"""
Sistema de Montarias.

Diferente dos Pets (que formam um esquadrão de 5 e dão bônus de combate),
a Montaria é UMA só por vez, focada em VELOCIDADE e EXPLORAÇÃO da Torre:
- Bônus de status (principalmente SPD)
- Desconto no Teleporte pago (fuga de emergência da torre)
- Bônus de ouro/XP só quando você está EXPLORANDO a Torre sozinho (não vale
  na Raid, pra não empilhar com o bônus dos pets ali)

Adquiridas no Estábulo (gacha próprio, separado do Templo de Evocação dos pets).
"""
import random

MOUNTS_DB = {
    # ===== COMUNS =====
    "mount_c_ponei": {"id": "mount_c_ponei", "name": "Pônei Cinzento", "rarity": "comum",
                       "bonus_stats": {"spd": 15, "hp_max": 50},
                       "mechanic": {"type": "tp_discount", "value": 0.05}},
    "mount_c_burro": {"id": "mount_c_burro", "name": "Burro de Carga", "rarity": "comum",
                       "bonus_stats": {"spd": 10, "hp_max": 100},
                       "mechanic": {"type": "explore_gold_pct", "value": 0.03}},
    "mount_c_cabra": {"id": "mount_c_cabra", "name": "Cabra Montanhesa", "rarity": "comum",
                       "bonus_stats": {"spd": 18, "eva": 5},
                       "mechanic": {"type": "explore_xp_pct", "value": 0.03}},

    # ===== INCOMUNS =====
    "mount_u_cavalo": {"id": "mount_u_cavalo", "name": "Cavalo de Guerra", "rarity": "incomum",
                        "bonus_stats": {"spd": 35, "hp_max": 200, "atk": 10},
                        "mechanic": {"type": "tp_discount", "value": 0.10}},
    "mount_u_javali": {"id": "mount_u_javali", "name": "Javali Selvagem", "rarity": "incomum",
                        "bonus_stats": {"spd": 25, "def": 15},
                        "mechanic": {"type": "explore_gold_pct", "value": 0.06}},
    "mount_u_lobo": {"id": "mount_u_lobo", "name": "Lobo das Neves", "rarity": "incomum",
                      "bonus_stats": {"spd": 40, "eva": 8},
                      "mechanic": {"type": "explore_xp_pct", "value": 0.06}},

    # ===== RAROS =====
    "mount_r_grifo": {"id": "mount_r_grifo", "name": "Grifo Menor", "rarity": "raro",
                       "bonus_stats": {"spd": 60, "hp_max": 400, "eva": 10},
                       "mechanic": {"type": "tp_discount", "value": 0.20}},
    "mount_r_urso": {"id": "mount_r_urso", "name": "Urso Blindado", "rarity": "raro",
                      "bonus_stats": {"spd": 45, "def": 40, "hp_max": 500},
                      "mechanic": {"type": "explore_gold_pct", "value": 0.10}},
    "mount_r_tigre": {"id": "mount_r_tigre", "name": "Tigre Espectral", "rarity": "raro",
                       "bonus_stats": {"spd": 70, "atk": 25},
                       "mechanic": {"type": "explore_xp_pct", "value": 0.10}},

    # ===== ÉPICOS =====
    "mount_e_wyvern": {"id": "mount_e_wyvern", "name": "Wyvern Jovem", "rarity": "epico",
                        "bonus_stats": {"spd": 100, "hp_max": 800, "atk": 40},
                        "mechanic": {"type": "tp_discount", "value": 0.35}},
    "mount_e_fenix": {"id": "mount_e_fenix", "name": "Filhote de Fênix", "rarity": "epico",
                       "bonus_stats": {"spd": 90, "hp_max": 1000, "reg": 20},
                       "mechanic": {"type": "explore_gold_pct", "value": 0.15}},
    "mount_e_lich_horse": {"id": "mount_e_lich_horse", "name": "Corcel Espectral", "rarity": "epico",
                            "bonus_stats": {"spd": 110, "eva": 20},
                            "mechanic": {"type": "explore_xp_pct", "value": 0.15}},

    # ===== LENDÁRIAS =====
    "mount_l_dragao": {"id": "mount_l_dragao", "name": "Dragão Ancião", "rarity": "lendario",
                        "bonus_stats": {"spd": 180, "hp_max": 2500, "atk": 100, "def": 60},
                        "mechanic": {"type": "tp_discount", "value": 0.60}},
    "mount_l_fenix_adulta": {"id": "mount_l_fenix_adulta", "name": "Fênix Suprema", "rarity": "lendario",
                              "bonus_stats": {"spd": 160, "hp_max": 3000, "reg": 50},
                              "mechanic": {"type": "explore_gold_pct", "value": 0.30}},
    "mount_l_unicornio": {"id": "mount_l_unicornio", "name": "Unicórnio Celestial", "rarity": "lendario",
                           "bonus_stats": {"spd": 200, "eva": 40, "crit": 20},
                           "mechanic": {"type": "explore_xp_pct", "value": 0.30}},
}


def get_equipped_mount_bonus(p: dict) -> dict:
    """Retorna o dict completo (bonus_stats + mechanic) da montaria equipada,
    ou vazio se não tiver nenhuma."""
    mount_id = p.get("mount_equipped")
    if not mount_id:
        return {}
    return MOUNTS_DB.get(mount_id, {})


def roll_mount_gacha(p: dict, amount: int) -> tuple[bool, str, list]:
    """Invoca montarias no Estábulo. amount pode ser 1 ou 11 (custo reduzido)."""
    cost = 800 if amount == 1 else 8000
    actual_amount = 1 if amount == 1 else 11

    if p.get("gold", 0) < cost:
        return False, f"❌ Ouro insuficiente. Você precisa de {cost}g.", []

    p["gold"] -= cost

    pool = {"comum": [], "incomum": [], "raro": [], "epico": [], "lendario": []}
    for mid, mdata in MOUNTS_DB.items():
        pool[mdata["rarity"]].append(mid)

    rolled = []
    for _ in range(actual_amount):
        rng = random.uniform(0, 100)
        if rng <= 0.5:
            rarity = "lendario"
        elif rng <= 3.0:
            rarity = "epico"
        elif rng <= 15.0:
            rarity = "raro"
        elif rng <= 50.0:
            rarity = "incomum"
        else:
            rarity = "comum"

        chosen = random.choice(pool[rarity])
        rolled.append(chosen)

        owned = p.setdefault("mounts_owned", {})
        owned[chosen] = owned.get(chosen, 0) + 1

    return True, "✅ Invocação no Estábulo realizada!", rolled


def equip_mount(p: dict, mount_id: str) -> str:
    owned = p.get("mounts_owned", {})
    if mount_id == "remove":
        p["mount_equipped"] = None
        return "🐴 Montaria removida."
    if mount_id not in owned or owned[mount_id] <= 0:
        return "❌ Você não possui essa montaria."
    p["mount_equipped"] = mount_id
    nome = MOUNTS_DB.get(mount_id, {}).get("name", mount_id)
    return f"🐴 {nome} equipado(a)!"


# =============================================================================
# 🔀 FUSÃO — mesma mecânica dos pets: 5 cópias repetidas da mesma raridade
# por 20% de chance de uma montaria aleatória de raridade superior (08/07/2026)
# =============================================================================
RARITY_ORDER = ["comum", "incomum", "raro", "epico", "lendario"]
FUSION_COST = 5
FUSION_SUCCESS_CHANCE = 0.20


def get_mounts_by_rarity(rarity: str) -> list:
    return [mid for mid, data in MOUNTS_DB.items() if data.get("rarity") == rarity]


def get_fusable_mounts(p: dict, rarity: str) -> list:
    owned = p.get("mounts_owned", {})
    return [mid for mid in get_mounts_by_rarity(rarity) if owned.get(mid, 0) > 1]


def fuse_mounts(p: dict, mount_id: str) -> tuple:
    import random

    owned = p.setdefault("mounts_owned", {})
    mount = MOUNTS_DB.get(mount_id)
    if not mount:
        return False, "❌ Montaria inválida."

    atual = owned.get(mount_id, 0)
    if atual < FUSION_COST:
        return False, f"❌ Você precisa de {FUSION_COST} cópias de {mount['name']} (tem {atual})."

    rarity = mount.get("rarity")
    if rarity not in RARITY_ORDER or RARITY_ORDER.index(rarity) >= len(RARITY_ORDER) - 1:
        return False, "❌ Essa já é a raridade máxima — não dá pra fundir pra cima."

    owned[mount_id] -= FUSION_COST

    proxima = RARITY_ORDER[RARITY_ORDER.index(rarity) + 1]
    candidatos = get_mounts_by_rarity(proxima)

    if candidatos and random.random() < FUSION_SUCCESS_CHANCE:
        ganho_id = random.choice(candidatos)
        owned[ganho_id] = owned.get(ganho_id, 0) + 1
        nome_ganho = MOUNTS_DB[ganho_id]["name"]
        return True, (
            f"✨ <b>FUSÃO BEM-SUCEDIDA!</b>\n"
            f"Consumiu 5x {mount['name']} e ganhou <b>1x {nome_ganho}</b> "
            f"({proxima.upper()})!"
        )
    else:
        return False, (
            f"💨 A fusão falhou...\n"
            f"5x {mount['name']} foram consumidos, mas nenhuma montaria superior surgiu. "
            f"Tente de novo!"
        )
