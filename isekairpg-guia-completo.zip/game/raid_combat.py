# game/raid_combat.py
"""
Sistema de combate para raids - limpo, eficiente e separado.
Lida com: turnos, ATB, distribuição de loot e morte.
"""

import copy
import random
import time
from typing import Dict, Any, List, Optional, Tuple

# ============ CONSTANTES ============

ATB_MAX = 100.0
MAX_ATB_LOOP = 500  # Previne loop infinito


# ============ INICIALIZAÇÃO ============

def raid_init_combat(room: Dict[str, Any], enemy_andar: int) -> None:
    """Inicia combate da raid com estrutura limpa."""
    from game.monster_generator import criar_monstro

    boss = criar_monstro(enemy_andar)

    # Estrutura de combate
    players = []
    for pid in room.get("members", []):
        from game.sql_repo import load_player
        try:
            pdata = load_player(int(pid))
            players.append({
                "pid": pid,
                "name": pdata.get("username", f"Player{pid}"),
                "hp": pdata.get("hp", 100),
                "hp_max": pdata.get("hp_max", 100),
                "atk": pdata.get("atk", 5),
                "def": pdata.get("def", 0),
                "spd": pdata.get("spd", 20),
                "bar": 0.0,
                "dead": False,
            })
        except Exception:
            continue

    room["combat"] = {
        "state": "ACTIVE",
        "players": players,
        "enemies": [boss],
        "turn": 0,
        "logs": ["⚔️ Combate iniciado!"],
        "turn_state": {"idx": -1, "type": None},  # -1 = nenhum; 0+ = player idx
    }


def raid_advance_atb(room: Dict[str, Any]) -> List[str]:
    """Avança ATB até alguém ficar pronto."""
    combat = room.get("combat", {})
    players = combat.get("players", [])
    enemies = combat.get("enemies", [])
    logs = []

    loop_count = 0
    while loop_count < MAX_ATB_LOOP:
        loop_count += 1

        # Acha quem fica pronto primeiro
        next_actor = None
        min_time = float("inf")

        for i, p in enumerate(players):
            if not p.get("dead") and p.get("bar", 0.0) < ATB_MAX:
                spd = max(1, int(p.get("spd", 20)))
                time_to_ready = (ATB_MAX - p.get("bar", 0.0)) / spd
                if time_to_ready < min_time:
                    min_time = time_to_ready
                    next_actor = ("player", i)

        for i, e in enumerate(enemies):
            if e.get("hp", 0) > 0 and e.get("bar", 0.0) < ATB_MAX:
                spd = max(1, int(e.get("spd", 20)))
                time_to_ready = (ATB_MAX - e.get("bar", 0.0)) / spd
                if time_to_ready < min_time:
                    min_time = time_to_ready
                    next_actor = ("enemy", i)

        if next_actor is None:
            break

        if min_time <= 0:
            min_time = 0.1

        # Avança tempo
        for p in players:
            if not p.get("dead"):
                spd = max(1, int(p.get("spd", 20)))
                p["bar"] = min(ATB_MAX, p.get("bar", 0.0) + spd * min_time)

        for e in enemies:
            if e.get("hp", 0) > 0:
                spd = max(1, int(e.get("spd", 20)))
                e["bar"] = min(ATB_MAX, e.get("bar", 0.0) + spd * min_time)

        # Encontrou pronto?
        if next_actor[0] == "player":
            combat["turn_state"] = {"idx": next_actor[1], "type": "player"}
            return logs

        elif next_actor[0] == "enemy":
            # Inimigo ataca automaticamente
            enemy = enemies[next_actor[1]]
            enemy["bar"] = 0.0

            # Pega alvo vivo aleatório
            alive_players = [p for p in players if not p.get("dead")]
            if alive_players:
                target = random.choice(alive_players)
                dmg = max(1, enemy.get("atk", 5) - target.get("def", 0))
                target["hp"] -= dmg

                if target["hp"] <= 0:
                    target["hp"] = 0
                    target["dead"] = True
                    logs.append(f"💀 {target.get('name')} foi derrotado!")
                else:
                    logs.append(f"🗡️ Boss atacou {target.get('name')} (-{dmg} HP)")

            combat["turn"] += 1
            continue

    if loop_count >= MAX_ATB_LOOP:
        logs.append("⏰ Combate congelado (ATB loop). Atualize a tela.")

    return logs


# ============ AÇÕES ============

def raid_player_attack(room: Dict[str, Any], player_idx: int) -> List[str]:
    """Player ataca o boss."""
    combat = room.get("combat", {})
    players = combat.get("players", [])
    enemies = combat.get("enemies", [])
    logs = []

    if player_idx < 0 or player_idx >= len(players):
        return ["❌ Jogador inválido"]

    player = players[player_idx]
    enemy = enemies[0]  # Boss

    # Calcula dano
    dmg = max(1, player.get("atk", 5) - enemy.get("def", 0))

    # Crítico?
    # crítico: um menos o outro (25/09) — crítico do jogador − esquiva do boss
    from game.logic import multiplicador_de_critico
    _mcrit = multiplicador_de_critico(int(player.get("crit", 0)), int(enemy.get("eva", 0)))
    if _mcrit:
        dmg = int(dmg * _mcrit)
        logs.append(f"💥 CRÍTICO! {player.get('name')} causou {dmg} de dano!")
    else:
        logs.append(f"🗡️ {player.get('name')} atacou (-{dmg} HP)")

    enemy["hp"] -= dmg
    player["bar"] = 0.0

    # Boss morreu?
    if enemy.get("hp", 0) <= 0:
        enemy["hp"] = 0
        combat["state"] = "WIN"
        logs.append("🏆 O BOSS FOI DERROTADO! Vitória!")
        return logs

    # Próximo turno
    combat["turn"] += 1
    advance_logs = raid_advance_atb(room)
    logs.extend(advance_logs)

    return logs


# ============ VITÓRIA ============

def raid_finish_with_loot(room: Dict[str, Any], enemy: Dict[str, Any]) -> List[str]:
    """Distribui loot para todos vivos."""
    logs = ["💰 Distribuindo loot..."]

    members = room.get("members", [])
    if not enemy.get("cores_drop"):
        logs.append("Nenhum core dropado.")
        return logs

    drops = enemy.get("cores_drop", [])

    for drop in drops:
        for member_pid in members:
            from game.sql_repo import load_player, save_player_sql
            try:
                pdata = load_player(int(member_pid))
                if pdata:
                    cores = pdata.setdefault("inv", {}).setdefault("cores", {})
                    cores[drop] = cores.get(drop, 0) + 1
                    save_player_sql(int(member_pid), pdata)
                    logs.append(f"✅ {pdata.get('username')} recebeu +1x {drop}")
            except Exception:
                pass

    return logs


# ============ MORTE E CLEANUP ============

def raid_handle_deaths(room: Dict[str, Any]) -> List[str]:
    """Remove players mortos da sala."""
    combat = room.get("combat", {})
    players = combat.get("players", [])
    dead_pids = [p.get("pid") for p in players if p.get("dead")]

    logs = []
    for pid in dead_pids:
        room["members"].remove(str(pid))
        logs.append(f"💀 Player {pid} foi expulso da sala.")

    if not room.get("members"):
        logs.append("⚠️ Todos morreram! Sala será fechada.")
        room["state"] = "CLOSED"

    return logs


def raid_cleanup_room(room: Dict[str, Any]) -> None:
    """Limpa combate e reseta para lobby."""
    room["combat"] = None
    room["state"] = "LOBBY"
    room["floor"] += 1

    for m in room.get("members", []):
        room.setdefault("ready_map", {})[m] = False


# ============ GETTERS ============

def raid_get_combat_view(room: Dict[str, Any]) -> str:
    """Gera texto do combate para enviar para o player."""
    combat = room.get("combat", {})

    if not combat:
        return "❌ Sem combate ativo"

    logs_text = "\n".join(combat.get("logs", [])[-10:])  # Últimas 10 mensagens

    boss = combat.get("enemies", [{}])[0]
    boss_hp_bar = "█" * (boss.get("hp", 0) // max(1, boss.get("hp_max", 1) // 10))
    boss_hp_bar += "░" * (10 - len(boss_hp_bar))

    players_info = []
    for i, p in enumerate(combat.get("players", [])):
        status = "💀" if p.get("dead") else "✅"
        bar = "█" * int(p.get("bar", 0) // 10) + "░" * (10 - int(p.get("bar", 0) // 10))
        players_info.append(f"{status} P{i}: {p.get('name')} | {bar}")

    turn_state = combat.get("turn_state", {})
    if turn_state.get("type") == "player":
        current = f"🎯 Turno do Player {turn_state.get('idx')}"
    else:
        current = "🤖 Boss está se movendo..."

    return f"""
⚔️ COMBATE DA RAID
━━━━━━━━━━━━━━━━━━
BOSS: {boss.get('nome')}
HP: {boss_hp_bar} {boss.get('hp')}/{boss.get('hp_max')}

PLAYERS:
{"\n".join(players_info)}

LOGS:
{logs_text}

{current}
━━━━━━━━━━━━━━━━━━
"""
def raid_start_combat_for_party(room: dict) -> None:
    floor = int(room.get("floor", 1))
    enemies = raid_build_enemies_for_floor(floor)

    players_data = []
    for pid in room.get("members", []):
        try:
            player = load_player(int(pid))  # pid agora É o user_id numérico
        except:
            player = None
        players_data.append({
            "pid": str(pid),
            "name": (player or {}).get("username") or f"Player {pid}",
            "hp": int((player or {}).get("hp", 100)),
            "hp_max": int((player or {}).get("hp_max", 100)),
            "atk": int((player or {}).get("atk", 5)),
            "def": int((player or {}).get("def", 0)),
            "bar": 0.0,
            "dead": False,
        })

    boss_name = enemies[0].get("name") or enemies[0].get("nome", "Boss")
    room["combat"] = {
        "state": "RUNNING",
        "players": players_data,
        "enemies": enemies,
        "turn_state": {"idx": 0, "type": "player"},
        "logs": [f"⚔️ Andar {floor} iniciado! Boss: {boss_name}"],
        "p_cooldowns": {},
    }
    room["state"] = "RAID_COMBAT"
    save_room(room)
# logic.py
def raid_build_enemies_for_floor(floor: int) -> list[dict]:
    """Cria a lista de inimigos para a raid daquele andar."""
    enemies: list[dict] = []
    bosses_qtd = get_bosses_no_andar(floor)

    # Garante pelo menos 1 boss
    if bosses_qtd <= 0:
        bosses_qtd = 1

    # BOSS PRINCIPAL BUFFADO
    mon = criar_monstro_por_andar(floor)
    st = mon.get("status", {})

    base_hp_max = int(mon.get("hp_max", 60))
    hp_max = int(base_hp_max * 10)
    hp = hp_max

    enemies.append({
        "name": mon.get("nome", "BOSS RAID"),
        "tipo": "boss",
        "tier": int(mon.get("tier", get_tier(floor))),
        "hp": hp,
        "hp_max": hp_max,
        "atk": int(st.get("atk", 1) * 2),
        "def": int(st.get("def", 0) * 2),
        "spd": int(st.get("spd", 20)),
        "floor": int(mon.get("lvl", floor)),
        "skill": random.choice(["a_fire", "a_ice", "a_thunder", "a_execution", "a_meteor"]),
        "bar": 0.0,
    })

    # ADDS (mesma quantidade de bosses-1, levemente mais fracos)
    for _ in range(bosses_qtd - 1):
        add_floor = max(1, floor + random.randint(-3, 0))
        mon_add = criar_monstro_por_andar(add_floor)
        st_add = mon_add.get("status", {})

        add_hp_max = int(mon_add.get("hp_max", 60) * 7)
        add_hp = add_hp_max

        enemies.append({
            "name": mon_add.get("nome", "ADD"),
            "tipo": mon_add.get("tipo", "elite"),
            "tier": int(mon_add.get("tier", get_tier(add_floor)+5)),
            "hp": add_hp,
            "hp_max": add_hp_max,
            "atk": int(st_add.get("atk", 1)),
            "def": int(st_add.get("def", 0)),
            "spd": int(st_add.get("spd", 20)),
            "floor": int(mon_add.get("lvl", add_floor)),
            "skill": random.choice(["a_fire", "a_ice", "a_thunder"]),
            "bar": 0.0,
        })

    return enemies
def raid_advance_combat(room_id: int) -> list[str]:
    """Avança o ATB global até algum player ficar pronto ou inimigo agir."""
    room = get_room(room_id)
    if not room or not room.get("combat"):
        return []

    combat = room["combat"]
    logs = combat.get("logs", [])
    combat["logs"] = []

    players = combat.get("players", [])
    enemies = combat.get("enemies", [])

    vivos = [pl for pl in players if not pl.get("dead")]
    if not vivos:
        for pid in list(room.get("members", [])):
            raid_handle_player_death(room, pid)
        delete_room(room["id"])
        return ["☠️ WIPE! A PARTY FOI COMPLETAMENTE DESTRUÍDA!\nFim da Raid."]

    import random

    max_events = 80
    while max_events > 0:
        max_events -= 1

        # 1) Se algum inimigo já está pronto, ele age primeiro
        inimigos_prontos = [
            e for e in enemies
            if int(e.get("hp", 0)) > 0 and float(e.get("bar", 0.0)) >= 100.0
        ]

        if inimigos_prontos:
            enemy = max(inimigos_prontos, key=lambda e: float(e.get("bar", 0.0)))
            enemy["bar"] = max(0.0, float(enemy.get("bar", 0.0)) - 100.0)

            alvos_vivos = [p for p in players if not p.get("dead")]
            if not alvos_vivos:
                for pid in list(room.get("members", [])):
                    raid_handle_player_death(room, pid)
                delete_room(room["id"])
                return logs + ["☠️ WIPE! A PARTY FOI COMPLETAMENTE DESTRUÍDA!\nFim da Raid."]

            alvo = random.choice(alvos_vivos)
            enemy_name = enemy.get("name", "Inimigo")
            alvo_name = alvo.get("name", "Jogador")

            skill_id = enemy.get("skill")
            use_skill = bool(skill_id) and random.random() < 0.7

            if use_skill:
                dano_final = max(
                    1,
                    int(int(enemy.get("atk", 10)) * 1.5) - int(alvo.get("def", 0))
                )
                logs.append(f"🔥 {enemy_name} usou {skill_id} em {alvo_name}! {dano_final} dano!")

                if "fire" in skill_id or "afire" in skill_id:
                    alvo["dot"] = {"dano": int(dano_final * 0.3), "turns": 4}
                    logs.append(f"🔥 Queimadura! {alvo['dot']['dano']} dano/turno por 4 turnos")
                elif "ice" in skill_id:
                    alvo["frozen"] = int(alvo.get("frozen", 0)) + 2
                    logs.append(f"❄️ {alvo_name} ficou congelado por 2 turnos!")
            else:
                dano_final = max(
                    1,
                    int(enemy.get("atk", 10)) - int(alvo.get("def", 0))
                )
                logs.append(f"💥 {enemy_name} atacou {alvo_name}! {dano_final} dano!")

            alvo["hp"] = max(0, int(alvo.get("hp", 0)) - dano_final)

            if alvo["hp"] <= 0 and not alvo.get("dead"):
                alvo["dead"] = True
                logs.append(f"💀 {alvo_name} morreu e foi expulso da raid!")
                raid_handle_player_death(room, alvo["pid"])

            continue

        # 2) Se algum player já está pronto, para e entrega o turno
        for i, player in enumerate(players):
            if player.get("dead"):
                continue
            if float(player.get("bar", 0.0)) < 100.0:
                continue

            # DoT no começo do turno
            if player.get("dot"):
                dot = player["dot"]
                if int(dot.get("turns", 0)) > 0:
                    dmg = int(dot.get("dano", 0))
                    player["hp"] = max(0, int(player.get("hp", 0)) - dmg)
                    logs.append(f"🔥 DoT: -{dmg} HP em {player['name']}")
                    dot["turns"] -= 1
                    if dot["turns"] <= 0:
                        player.pop("dot", None)

                    if player["hp"] <= 0 and not player.get("dead"):
                        player["dead"] = True
                        logs.append(f"💀 {player['name']} morreu por DoT e foi expulso da raid!")
                        raid_handle_player_death(room, player["pid"])
                        continue

            if int(player.get("frozen", 0)) > 0:
                player["frozen"] -= 1
                logs.append(f"❄️ {player['name']} ainda está congelado!")
                # perdeu a vez, volta pro loop
                player["bar"] = 0.0
                continue

            player["bar"] = max(0.0, float(player.get("bar", 0.0)) - 100.0)
            combat.setdefault("turn_state", {})
            combat["turn_state"]["idx"] = i
            save_room(room)
            return logs

        # 3) Avança o tempo até o próximo ficar pronto
        fighters = []

        for player in players:
            if not player.get("dead"):
                spd = max(1, int(player.get("spd", 20)))
                bar = float(player.get("bar", 0.0))
                if bar < 100.0:
                    fighters.append(("player", player, (100.0 - bar) / spd))

        for enemy in enemies:
            if int(enemy.get("hp", 0)) > 0:
                spd = max(1, int(enemy.get("spd", 20)))
                bar = float(enemy.get("bar", 0.0))
                if bar < 100.0:
                    fighters.append(("enemy", enemy, (100.0 - bar) / spd))

        if not fighters:
            break

        dt = min(item[2] for item in fighters)
        if dt <= 0:
            dt = 0.1

        for player in players:
            if not player.get("dead"):
                spd = max(1, int(player.get("spd", 20)))
                player["bar"] = min(100.0, float(player.get("bar", 0.0)) + spd * dt)

        for enemy in enemies:
            if int(enemy.get("hp", 0)) > 0:
                spd = max(1, int(enemy.get("spd", 20)))
                enemy["bar"] = min(100.0, float(enemy.get("bar", 0.0)) + spd * dt)

    save_room(room)
    return logs + ["⏰ Loop ATB demorou demais. Atualize."]
if __name__ == "__main__":
    # Teste
    room = {
        "members": ["123", "456"],
        "floor": 10,
        "combat": None,
    }

    raid_init_combat(room, 10)
    print(raid_get_combat_view(room))