# game/clan_reliquias.py
"""
🏺 RELÍQUIAS DO CLÃ (20/09/2026 — o último sistema do documento)

O dev: "cria uma chance de drop dos postos, 1% ou menos de conseguir".

Relíquia é o prêmio raro do trabalho braçal: cada EQUIPE que passa a sessão
num posto tem ~1% de desenterrar uma. Não se compra, não se forja, não cai
de monstro — é achado de quem cava, e por isso cada uma tem uma história de
onde veio.

O QUE ELA FAZ
-------------
Uma relíquia dá um efeito PERMANENTE e passivo ao clã, e o clã só consegue
manter TRÊS ativas (`SLOTS`). O resto fica no acervo. É essa escolha — qual
das oito deixar de fora — que faz a relíquia valer mais que um número.

Puro: sem banco. `clan_repo` sorteia na sessão das equipes e guarda em
`clan.reliquias`.
"""
from __future__ import annotations

import random

CHANCE_POR_EQUIPE = 0.01     # por equipe, por sessão cheia
SLOTS = 3

RELIQUIAS = {
    "martelo_frio": {
        "nome": "Martelo Frio", "icone": "🔨",
        "historia": "Um martelo que não esquenta por mais que bata. O ferreiro jura que é ele "
                    "que trabalha, não a pessoa.",
        "efeito": "ferreiro_desconto", "valor": 0.20,
        "texto": "O ferreiro cobra 20% menos material.",
    },
    "mapa_rasgado": {
        "nome": "Mapa Rasgado", "icone": "🗺️",
        "historia": "Metade de um mapa de alguém que não voltou. A metade que sobrou é a do caminho.",
        "efeito": "achar_melhor", "valor": 0.15,
        "texto": "Explorar acha 15% mais vezes.",
    },
    "bandeira_velha": {
        "nome": "Bandeira Velha", "icone": "🏴",
        "historia": "O pano está puído, mas ninguém do clã consegue olhar pra ele e recuar.",
        "efeito": "poder_guarda", "valor": 0.10,
        "texto": "Guardas lutam com 10% mais poder.",
    },
    "moinho_de_pedra": {
        "nome": "Moinho de Pedra", "icone": "🌾",
        "historia": "Chegou quebrado e alguém consertou. Desde então a aldeia come melhor.",
        "efeito": "producao", "valor": 0.10,
        "texto": "As equipes coletam 10% a mais.",
    },
    "sino_da_vigia": {
        "nome": "Sino da Vigia", "icone": "🔔",
        "historia": "Toca sozinho um instante antes do perigo. Ninguém explica; todos correm.",
        "efeito": "defesa_cidade", "valor": 0.25,
        "texto": "A guarnição defende a cidade com 25% mais poder.",
    },
    "cantil_sem_fundo": {
        "nome": "Cantil sem Fundo", "icone": "🧴",
        "historia": "Nunca esvazia de todo. Nunca enche também.",
        "efeito": "manutencao", "valor": 0.15,
        "texto": "A aldeia gasta 15% menos pra se manter.",
    },
    "pedra_de_amolar": {
        "nome": "Pedra de Amolar", "icone": "🪨",
        "historia": "Uma pedra comum, de um rio qualquer. O fio que ela dá não é comum.",
        "efeito": "material_extra", "valor": 0.15,
        "texto": "Os postos de ferro rendem 15% mais material.",
    },
    "diario_do_fundador": {
        "nome": "Diário do Fundador", "icone": "📓",
        "historia": "A letra é de quem começou tudo. As últimas páginas estão em branco — de propósito.",
        "efeito": "xp_npc", "valor": 0.25,
        "texto": "Os NPCs do clã ganham 25% mais XP.",
    },
}


def sortear(qtd_equipes: int, ja_tem: list, rng: random.Random, fracao: float = 1.0) -> str | None:
    """Uma relíquia nova (ou None). Cada equipe tem a sua chance; relíquia
    repetida não sai — quando acabam, o sorteio para de existir."""
    faltam = [k for k in RELIQUIAS if k not in (ja_tem or [])]
    if not faltam or qtd_equipes <= 0:
        return None
    for _ in range(int(qtd_equipes)):
        if rng.random() < CHANCE_POR_EQUIPE * float(fracao):
            return rng.choice(faltam)
    return None


def bonus(ativas: list) -> dict:
    """{efeito: valor} das relíquias ativas (as que estão nos slots)."""
    return {RELIQUIAS[k]["efeito"]: RELIQUIAS[k]["valor"]
            for k in (ativas or [])[:SLOTS] if k in RELIQUIAS}


def fator(ativas: list, efeito: str) -> float:
    """1 + o bônus daquele efeito (1.0 = sem relíquia)."""
    return 1.0 + float(bonus(ativas).get(efeito, 0.0))
