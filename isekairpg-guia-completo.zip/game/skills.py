# game/skills.py
import random

SKILL_DB = {
    # =========================================================
    # 🌟 SKILL INICIAL (08/07/2026)
    # Todo jogador já começa com ela aprendida. É a ÚNICA sem
    # "req_class" — todas as outras 210 exigem uma classe, que só é
    # escolhida no Andar 5. Sem ela, um jogador novo não teria skill
    # nenhuma pra usar (nem pra aprender) nos primeiros andares.
    # =========================================================
    "core_starter_1": {
        "name": "Core de Golpe Firme 🤍",
        "sell": 0,
        "skill": {
            "id": "a_starter_1",
            "name": "Golpe Firme",
            "type": "active",
            "rarity": 1,
            "target": "single",
            "cooldown": 3,
            "mult": 1.6,
        },
    },
    # =========================================================
    # 🧙‍♂️ CLASSE: MAGO (Elementos e Controle)
    # =========================================================
    # 🔥 FOGO (Foco: Queimadura e Detonação)
    "core_fire_1": {"name": "Core de Faísca 🤍", "sell": 50, "skill": {"id": "a_fire_1", "name": "Faísca", "type": "active", "rarity": 1, "req_class": "mago", "target": "single", "cooldown": 3, "mult": 1.5}},
    "core_fire_2": {"name": "Core de Bola de Fogo 💚", "sell": 150, "skill": {"id": "a_fire_2", "name": "Bola de Fogo", "type": "active", "rarity": 2, "req_class": "mago", "target": "single", "cooldown": 3, "mult": 2.0, "dot_mult": 0.7, "dot_turns": 3, "dot_name": "Queimadura"}},
    "core_fire_3": {"name": "Core de Onda de Calor 💙", "sell": 400, "skill": {"id": "a_fire_3", "name": "Onda de Calor", "type": "active", "rarity": 3, "req_class": "mago", "target": "all", "cooldown": 4, "mult": 2.0, "dot_mult": 0.8, "dot_turns": 4, "dot_name": "Queimadura"}},
    "core_fire_4": {"name": "Core de Combustão 💜", "sell": 1000, "skill": {"id": "a_fire_4", "name": "Combustão", "type": "active", "rarity": 4, "req_class": "mago", "req_spec": "spec_fogo", "target": "single", "cooldown": 5, "mult": 4.5, "dot_mult": 1.5, "dot_turns": 7, "dot_name": "Queimadura"}},
    "core_fire_5": {"name": "Core de Meteoro de Ifrit 💛", "sell": 3000, "skill": {"id": "a_fire_5", "name": "Meteoro de Ifrit", "type": "active", "rarity": 5, "req_class": "mago", "req_spec": "spec_fogo", "target": "all", "cooldown": 7, "mult": 5.0, "detonate": True}}, # 💥 Explode todos os DoTs!

    # ❄️ GELO (Foco: Stun e Lentidão/ATB Drain)
    "core_ice_1": {"name": "Core de Lasca de Gelo 🤍", "sell": 50, "skill": {"id": "a_ice_1", "name": "Lasca de Gelo", "type": "active", "rarity": 1, "req_class": "mago", "target": "single", "cooldown": 3, "mult": 1.3, "stun": 1}},
    "core_ice_2": {"name": "Core de Lança de Gelo 💚", "sell": 150, "skill": {"id": "a_ice_2", "name": "Lança de Gelo", "type": "active", "rarity": 2, "req_class": "mago", "target": "single", "cooldown": 4, "mult": 1.8, "stun": 1}},
    "core_ice_3": {"name": "Core de Nevasca 💙", "sell": 400, "skill": {"id": "a_ice_3", "name": "Nevasca", "type": "active", "rarity": 3, "req_class": "mago", "target": "all", "cooldown": 5, "mult": 1.5, "stun": 1}},
    "core_ice_4": {"name": "Core de Prisão Glacial 💜", "sell": 1000, "skill": {"id": "a_ice_4", "name": "Prisão Glacial", "type": "active", "rarity": 4, "req_class": "mago", "req_spec": "spec_gelo", "target": "single", "cooldown": 6, "mult": 2.5, "stun": 2, "atb_drain": 30.0}}, # ⏳ Atrasa o turno do Boss!
    "core_ice_5": {"name": "Core de Zero Absoluto 💛", "sell": 3000, "skill": {"id": "a_ice_5", "name": "Zero Absoluto", "type": "active", "rarity": 5, "req_class": "mago", "req_spec": "spec_gelo", "target": "all", "cooldown": 8, "mult": 4.5, "stun": 1, "atb_drain": 50.0}}, # ⏳ Rouba metade da barra de turno!

    # ⚡ RAIO (Foco: Dano Bruto e Quebra de Armadura/Debuff)
    "core_thunder_1": {"name": "Core de Choque 🤍", "sell": 50, "skill": {"id": "a_thunder_1", "name": "Choque Elétrico", "type": "active", "rarity": 1, "req_class": "mago", "target": "single", "cooldown": 3, "mult": 1.7}},
    "core_thunder_2": {"name": "Core de Relâmpago 💚", "sell": 150, "skill": {"id": "a_thunder_2", "name": "Relâmpago", "type": "active", "rarity": 2, "req_class": "mago", "target": "single", "cooldown": 3, "mult": 2.4}},
    "core_thunder_3": {"name": "Core de Cadeia de Raios 💙", "sell": 400, "skill": {"id": "a_thunder_3", "name": "Cadeia de Raios", "type": "active", "rarity": 3, "req_class": "mago", "target": "all", "cooldown": 4, "mult": 2.0}},
    "core_thunder_4": {"name": "Core de Tempestade Magnética 💜", "sell": 1000, "skill": {"id": "a_thunder_4", "name": "Tempestade Magnética", "type": "active", "rarity": 4, "req_class": "mago", "req_spec": "spec_raio", "target": "all", "cooldown": 5, "mult": 3.0, "debuff_def": 0.3, "debuff_turns": 3}}, # 📉 Quebra Defesa em Área!
    "core_thunder_5": {"name": "Core de Ira de Zeus 💛", "sell": 3000, "skill": {"id": "a_thunder_5", "name": "Ira de Zeus", "type": "active", "rarity": 5, "req_class": "mago", "req_spec": "spec_raio", "target": "single", "cooldown": 6, "mult": 6.5, "debuff_def": 0.5, "debuff_turns": 3}}, # 📉 Derrete a armadura do Boss!

    # =========================================================
    # ⚔️ CLASSE: GUERREIRO (Dano Físico e Combate Próximo)
    # =========================================================
    # 🗡️ ESPADA (Foco: Sangramento e Execução)
    "core_sword_1": {"name": "Core de Golpe Rápido 🤍", "sell": 50, "skill": {"id": "a_sword_1", "name": "Golpe Rápido", "type": "active", "rarity": 1, "req_class": "guerreiro", "target": "single", "cooldown": 3, "mult": 1.5}},
    "core_sword_2": {"name": "Core de Corte Profundo 💚", "sell": 150, "skill": {"id": "a_sword_2", "name": "Corte Profundo", "type": "active", "rarity": 2, "req_class": "guerreiro", "target": "single", "cooldown": 3, "mult": 2.0, "dot_mult": 0.7, "dot_turns": 3, "dot_name": "Sangramento"}},
    "core_sword_3": {"name": "Core de Giro de Lâminas 💙", "sell": 400, "skill": {"id": "a_sword_3", "name": "Giro de Lâminas", "type": "active", "rarity": 3, "req_class": "guerreiro", "target": "all", "cooldown": 4, "mult": 1.5, "dot_mult": 0.5, "dot_turns": 3, "dot_name": "Sangramento"}},
    "core_sword_4": {"name": "Core de Retalhar 💜", "sell": 1000, "skill": {"id": "a_sword_4", "name": "Retalhar", "type": "active", "rarity": 4, "req_class": "guerreiro", "req_spec": "spec_espada", "target": "single", "cooldown": 5, "mult": 4.5, "dot_mult": 1.3, "dot_turns": 3, "dot_name": "Hemorragia"}},
    "core_sword_5": {"name": "Core de Excalibur 💛", "sell": 3000, "skill": {"id": "a_sword_5", "name": "Excalibur", "type": "active", "rarity": 5, "req_class": "guerreiro", "req_spec": "spec_espada", "target": "single", "cooldown": 7, "mult": 4.0, "execute_pct": 2.5}}, # 🩸 Bate até 2.5x mais se o Boss estiver a morrer!

    # 🥊 LUVAS (Foco: Stun e Silenciamento)
    "core_glove_1": {"name": "Core de Soco Direto 🤍", "sell": 50, "skill": {"id": "a_glove_1", "name": "Soco Direto", "type": "active", "rarity": 1, "req_class": "guerreiro", "target": "single", "cooldown": 3, "mult": 1.3, "stun": 1}},
    "core_glove_2": {"name": "Core de Gancho Brutal 💚", "sell": 150, "skill": {"id": "a_glove_2", "name": "Gancho Brutal", "type": "active", "rarity": 2, "req_class": "guerreiro", "target": "single", "cooldown": 4, "mult": 1.8, "stun": 1}},
    "core_glove_3": {"name": "Core de Terremoto 💙", "sell": 400, "skill": {"id": "a_glove_3", "name": "Terremoto", "type": "active", "rarity": 3, "req_class": "guerreiro", "target": "all", "cooldown": 5, "mult": 1.5, "stun": 1}},
    "core_glove_4": {"name": "Core de Golpe na Garganta 💜", "sell": 1000, "skill": {"id": "a_glove_4", "name": "Golpe na Garganta", "type": "active", "rarity": 4, "req_class": "guerreiro", "req_spec": "spec_luvas", "target": "single", "cooldown": 6, "mult": 2.5, "silence_turns": 2}}, # 🤫 O Boss não usa magias por 2 turnos!
    "core_glove_5": {"name": "Core de Impacto Meteórico 💛", "sell": 3000, "skill": {"id": "a_glove_5", "name": "Impacto Meteórico", "type": "active", "rarity": 5, "req_class": "guerreiro", "req_spec": "spec_luvas", "target": "all", "cooldown": 8, "mult": 4.5, "stun": 2}}, # Nocaute absoluto!

    # 🔱 LANÇA (Foco: Dano e Quebra de Defesa Bruta)
    "core_spear_1": {"name": "Core de Estocada 🤍", "sell": 50, "skill": {"id": "a_spear_1", "name": "Estocada", "type": "active", "rarity": 1, "req_class": "guerreiro", "target": "single", "cooldown": 3, "mult": 1.7}},
    "core_spear_2": {"name": "Core de Investida 💚", "sell": 150, "skill": {"id": "a_spear_2", "name": "Investida", "type": "active", "rarity": 2, "req_class": "guerreiro", "target": "single", "cooldown": 3, "mult": 2.4}},
    "core_spear_3": {"name": "Core de Ciclone de Lanças 💙", "sell": 400, "skill": {"id": "a_spear_3", "name": "Ciclone de Lanças", "type": "active", "rarity": 3, "req_class": "guerreiro", "target": "all", "cooldown": 4, "mult": 2.0}},
    "core_spear_4": {"name": "Core de Empalar 💜", "sell": 1000, "skill": {"id": "a_spear_4", "name": "Empalar", "type": "active", "rarity": 4, "req_class": "guerreiro", "req_spec": "spec_lanca", "target": "single", "cooldown": 5, "mult": 4.0, "debuff_def": 0.4, "debuff_turns": 3}}, # 📉 Perfura armadura
    "core_spear_5": {"name": "Core de Queda do Dragão 💛", "sell": 3000, "skill": {"id": "a_spear_5", "name": "Queda do Dragão", "type": "active", "rarity": 5, "req_class": "guerreiro", "req_spec": "spec_lanca", "target": "single", "cooldown": 6, "mult": 7.0, "debuff_def": 0.6, "debuff_turns": 3}},

    # =========================================================
    # 🥷 CLASSE: ASSASSINO (Furtividade e Letalidade)
    # =========================================================
    # 🌑 SOMBRAS (Foco: Evasão e Silenciamento)
    "core_shadow_1": {"name": "Core de Ataque Furtivo 🤍", "sell": 50, "skill": {"id": "a_shadow_1", "name": "Ataque Furtivo", "type": "active", "rarity": 1, "req_class": "assassino", "target": "single", "cooldown": 3, "mult": 1.5}},
    "core_shadow_2": {"name": "Core de Lâmina Oculta 💚", "sell": 150, "skill": {"id": "a_shadow_2", "name": "Lâmina Oculta", "type": "active", "rarity": 2, "req_class": "assassino", "target": "single", "cooldown": 3, "mult": 2.2}},
    "core_shadow_3": {"name": "Core de Dança das Sombras 💙", "sell": 400, "skill": {"id": "a_shadow_3", "name": "Dança das Sombras", "type": "active", "rarity": 3, "req_class": "assassino", "target": "all", "cooldown": 4, "mult": 1.8}},
    "core_shadow_4": {"name": "Core de Corte Fantasma 💜", "sell": 1000, "skill": {"id": "a_shadow_4", "name": "Corte Fantasma", "type": "active", "rarity": 4, "req_class": "assassino", "req_spec": "spec_sombras", "target": "single", "cooldown": 5, "mult": 4.0, "silence_turns": 2}}, # 🤫 Silencia o alvo
    "core_shadow_5": {"name": "Core de Pesadelo Infinito 💛", "sell": 3000, "skill": {"id": "a_shadow_5", "name": "Pesadelo Infinito", "type": "active", "rarity": 5, "req_class": "assassino", "req_spec": "spec_sombras", "target": "all", "cooldown": 7, "mult": 4.5, "buff_eva": 0.5, "buff_turns": 3}}, # Esquiva massiva para si mesmo

    # ☠️ FATAL (Foco: Hit Kill e Execução Mágica)
    "core_fatal_1": {"name": "Core de Golpe Preciso 🤍", "sell": 50, "skill": {"id": "a_fatal_1", "name": "Golpe Preciso", "type": "active", "rarity": 1, "req_class": "assassino", "target": "single", "cooldown": 3, "mult": 1.7}},
    "core_fatal_2": {"name": "Core de Perfuração Vital 💚", "sell": 150, "skill": {"id": "a_fatal_2", "name": "Perfuração Vital", "type": "active", "rarity": 2, "req_class": "assassino", "target": "single", "cooldown": 3, "mult": 2.5}},
    "core_fatal_3": {"name": "Core de Chuva de Adagas 💙", "sell": 400, "skill": {"id": "a_fatal_3", "name": "Chuva de Adagas", "type": "active", "rarity": 3, "req_class": "assassino", "target": "all", "cooldown": 4, "mult": 2.0}},
    "core_fatal_4": {"name": "Core de Assassinar 💜", "sell": 1000, "skill": {"id": "a_fatal_4", "name": "Assassinar", "type": "active", "rarity": 4, "req_class": "assassino", "req_spec": "spec_fatal", "target": "single", "cooldown": 5, "mult": 5.0, "execute_pct": 2.0}}, # 🩸 Bate o dobro se faltar vida
    "core_fatal_5": {"name": "Core de Marca da Morte 💛", "sell": 3000, "skill": {"id": "a_fatal_5", "name": "Marca da Morte", "type": "active", "rarity": 5, "req_class": "assassino", "req_spec": "spec_fatal", "target": "single", "cooldown": 6, "mult": 6.0, "execute_pct": 3.0}}, # 🩸 O golpe de misericórdia Supremo!

    # 🐍 VENENO (Foco: DoTs e Detonação)
    "core_venom_1": {"name": "Core de Adaga Tóxica 🤍", "sell": 50, "skill": {"id": "a_venom_1", "name": "Adaga Tóxica", "type": "active", "rarity": 1, "req_class": "assassino", "target": "single", "cooldown": 3, "mult": 1.3, "dot_mult": 0.6, "dot_turns": 5, "dot_name": "Veneno"}},
    "core_venom_2": {"name": "Core de Toxina Paralisante 💚", "sell": 150, "skill": {"id": "a_venom_2", "name": "Toxina Paralisante", "type": "active", "rarity": 2, "req_class": "assassino", "target": "single", "cooldown": 4, "mult": 1.9, "dot_mult": 0.9, "dot_turns": 5, "dot_name": "Veneno", "stun": 1}},
    "core_venom_3": {"name": "Core de Bomba de Gás 💙", "sell": 400, "skill": {"id": "a_venom_3", "name": "Bomba de Gás", "type": "active", "rarity": 3, "req_class": "assassino", "target": "all", "cooldown": 4, "mult": 1.9, "dot_mult": 0.9, "dot_turns": 5, "dot_name": "Gás Tóxico"}},
    "core_venom_4": {"name": "Core de Veneno de Manticora 💜", "sell": 1000, "skill": {"id": "a_venom_4", "name": "Veneno de Manticora", "type": "active", "rarity": 4, "req_class": "assassino", "req_spec": "spec_veneno", "target": "single", "cooldown": 5, "mult": 3.5, "dot_mult": 1.5, "dot_turns": 3, "dot_name": "Veneno Letal"}},
    "core_venom_5": {"name": "Core de Epidemia Mortal 💛", "sell": 3000, "skill": {"id": "a_venom_5", "name": "Epidemia Mortal", "type": "active", "rarity": 5, "req_class": "assassino", "req_spec": "spec_veneno", "target": "all", "cooldown": 7, "mult": 3.0, "detonate": True}}, # 💥 Explode todos os venenos!

    # =========================================================
    # 🌿 CLASSE: SUPORTE (Sobrevivência da Equipa)
    # =========================================================
    # ✨ CURA (Foco: Cleanse, Curas e Revive)
    "core_heal_1": {"name": "Core de Cura Menor 🤍", "sell": 50, "skill": {"id": "a_heal_1", "name": "Cura Menor", "type": "active", "rarity": 1, "req_class": "curandeiro", "target": "single", "cooldown": 3, "mult": 0, "heal_percent": 2.0}},
    "core_heal_2": {"name": "Core de Luz Revigorante 💚", "sell": 150, "skill": {"id": "a_heal_2", "name": "Luz Revigorante", "type": "active", "rarity": 2, "req_class": "curandeiro", "target": "single", "cooldown": 3, "mult": 0, "heal_percent": 3.5}},
    "core_heal_3": {"name": "Core de Cura em Área 💙", "sell": 400, "skill": {"id": "a_heal_3", "name": "Cura em Área", "type": "active", "rarity": 3, "req_class": "curandeiro", "target": "all", "cooldown": 4, "mult": 0, "heal_percent": 2.0}},
    "core_heal_4": {"name": "Core de Purificação Divina 💜", "sell": 1000, "skill": {"id": "a_heal_4", "name": "Purificação Divina", "type": "active", "rarity": 4, "req_class": "curandeiro", "req_spec": "spec_cura", "target": "all", "cooldown": 5, "mult": 0, "heal_percent": 3.0, "cleanse": True}}, # 🧼 Limpa Stun e Venenos de todos!
    "core_heal_5": {"name": "Core de Ressurreição Divina 💛", "sell": 3000, "skill": {"id": "a_heal_5", "name": "Ressurreição Divina", "type": "active", "rarity": 5, "req_class": "curandeiro", "req_spec": "spec_cura", "target": "all", "cooldown": 8, "mult": 0, "heal_percent": 5.0, "revive_target": True}}, # 👼 Revive Aliados Mortos!

    # ⚖️ EQUILÍBRIO (Foco: Heal over Time [HoT] e Buffs)
    "core_balance_1": {"name": "Core de Semente da Vida 🤍", "sell": 50, "skill": {"id": "a_balance_1", "name": "Semente da Vida", "type": "active", "rarity": 1, "req_class": "curandeiro", "target": "single", "cooldown": 3, "mult": 0, "hot_pct": 0.8, "hot_turns": 3}},
    "core_balance_2": {"name": "Core de Brisa Revigorante 💚", "sell": 150, "skill": {"id": "a_balance_2", "name": "Brisa Revigorante", "type": "active", "rarity": 2, "req_class": "curandeiro", "target": "single", "cooldown": 3, "mult": 0, "hot_pct": 1.2, "hot_turns": 3, "buff_atk": 0.2, "buff_turns": 3}},
    "core_balance_3": {"name": "Core de Chuva Primaveril 💙", "sell": 400, "skill": {"id": "a_balance_3", "name": "Chuva Primaveril", "type": "active", "rarity": 3, "req_class": "curandeiro", "target": "all", "cooldown": 4, "mult": 0, "hot_pct": 0.8, "hot_turns": 3, "atb_boost": 20.0}},
    "core_balance_4": {"name": "Core de Santuário Kármico 💜", "sell": 1000, "skill": {"id": "a_balance_4", "name": "Santuário Kármico", "type": "active", "rarity": 4, "req_class": "curandeiro", "req_spec": "spec_equilibrio", "target": "all", "cooldown": 5, "mult": 0, "hot_pct": 1.5, "hot_turns": 3, "buff_def": 0.5, "buff_turns": 3}},
    "core_balance_5": {"name": "Core de Avatar do Equilíbrio 💛", "sell": 3000, "skill": {"id": "a_balance_5", "name": "Avatar do Equilíbrio", "type": "active", "rarity": 5, "req_class": "curandeiro", "req_spec": "spec_equilibrio", "target": "all", "cooldown": 7, "mult": 0, "hot_pct": 2.0, "hot_turns": 4, "buff_atk": 0.5, "buff_turns": 4}},

    # 🛡️ APOIO (Foco: Escudos [Shield] e Buffs Extremos)
    "core_support_1": {"name": "Core de Barreira Leve 🤍", "sell": 50, "skill": {"id": "a_support_1", "name": "Barreira Leve", "type": "active", "rarity": 1, "req_class": "curandeiro", "target": "single", "cooldown": 3, "mult": 0, "shield_pct": 1.5}},
    "core_support_2": {"name": "Core de Égide de Luz 💚", "sell": 150, "skill": {"id": "a_support_2", "name": "Égide de Luz", "type": "active", "rarity": 2, "req_class": "curandeiro", "target": "single", "cooldown": 3, "mult": 0, "shield_pct": 2.5, "buff_def": 0.3, "buff_turns": 3}},
    "core_support_3": {"name": "Core de Falange de Cristal 💙", "sell": 400, "skill": {"id": "a_support_3", "name": "Falange de Cristal", "type": "active", "rarity": 3, "req_class": "curandeiro", "target": "all", "cooldown": 5, "mult": 0, "shield_pct": 1.5}},
    "core_support_4": {"name": "Core de Bênção do Campeão 💜", "sell": 1000, "skill": {"id": "a_support_4", "name": "Bênção do Campeão", "type": "active", "rarity": 4, "req_class": "curandeiro", "req_spec": "spec_apoio", "target": "single", "cooldown": 5, "mult": 0, "shield_pct": 4.0, "buff_atk": 0.6, "buff_turns": 4}},
    "core_support_5": {"name": "Core de Muralha Imortal 💛", "sell": 3000, "skill": {"id": "a_support_5", "name": "Muralha Imortal", "type": "active", "rarity": 5, "req_class": "curandeiro", "req_spec": "spec_apoio", "target": "all", "cooldown": 7, "mult": 0, "shield_pct": 3.0, "buff_def": 1.0, "buff_turns": 3}},

    # =========================================================
    # 🛡️ CLASSE: TANKER (A Muralha de Resistência)
    # =========================================================
    # 🌵 ESPINHOS (Foco: Retaliação e Debuff de Ataque)
    "core_thorns_1": {"name": "Core de Agulha Farpada 🤍", "sell": 50, "skill": {"id": "a_thorns_1", "name": "Agulha Farpada", "type": "active", "rarity": 1, "req_class": "guardiao", "target": "single", "cooldown": 3, "mult": 1.2, "buff_def": 0.3, "buff_turns": 2}},
    "core_thorns_2": {"name": "Core de Carapaça de Espinhos 💚", "sell": 150, "skill": {"id": "a_thorns_2", "name": "Carapaça de Espinhos", "type": "active", "rarity": 2, "req_class": "guardiao", "target": "single", "cooldown": 3, "mult": 1.5, "buff_def": 0.5, "buff_turns": 3}},
    "core_thorns_3": {"name": "Core de Chuva de Farpas 💙", "sell": 400, "skill": {"id": "a_thorns_3", "name": "Chuva de Farpas", "type": "active", "rarity": 3, "req_class": "guardiao", "target": "all", "cooldown": 4, "mult": 1.5, "dot_mult": 0.5, "dot_turns": 3, "dot_name": "Sangramento Farpado"}},
    "core_thorns_4": {"name": "Core de Abraço da Morte 💜", "sell": 1000, "skill": {"id": "a_thorns_4", "name": "Abraço da Morte", "type": "active", "rarity": 4, "req_class": "guardiao", "req_spec": "spec_espinhos", "target": "single", "cooldown": 5, "mult": 3.5, "debuff_atk": 0.4, "debuff_turns": 3}}, # 📉 O Boss bate mais fraco
    "core_thorns_5": {"name": "Core de Dama de Ferro 💛", "sell": 3000, "skill": {"id": "a_thorns_5", "name": "Dama de Ferro", "type": "active", "rarity": 5, "req_class": "guardiao", "req_spec": "spec_espinhos", "target": "all", "cooldown": 7, "mult": 4.0, "debuff_atk": 0.6, "debuff_turns": 3, "dot_mult": 1.0, "dot_turns": 3, "dot_name": "Hemorragia Brutal"}},

    # 🪨 PEDRA (Foco: Stun na Retaliação e Auto-Cura)
    "core_stone_1": {"name": "Core de Soco de Pedra 🤍", "sell": 50, "skill": {"id": "a_stone_1", "name": "Soco de Pedra", "type": "active", "rarity": 1, "req_class": "guardiao", "target": "single", "cooldown": 3, "mult": 1.3, "stun": 1}},
    "core_stone_2": {"name": "Core de Pele de Granito 💚", "sell": 150, "skill": {"id": "a_stone_2", "name": "Pele de Granito", "type": "active", "rarity": 2, "req_class": "guardiao", "target": "self", "cooldown": 4, "mult": 0, "buff_def": 0.8, "buff_turns": 3, "stun_on_hit_chance": 15}},
    "core_stone_3": {"name": "Core de Fissura Sísmica 💙", "sell": 400, "skill": {"id": "a_stone_3", "name": "Fissura Sísmica", "type": "active", "rarity": 3, "req_class": "guardiao", "target": "all", "cooldown": 5, "mult": 1.5, "stun": 1}},
    "core_stone_4": {"name": "Core de Armadura de Titã 💜", "sell": 1000, "skill": {"id": "a_stone_4", "name": "Armadura de Titã", "type": "active", "rarity": 4, "req_class": "guardiao", "req_spec": "spec_pedra", "target": "self", "cooldown": 6, "mult": 0, "buff_def": 1.5, "buff_turns": 4, "stun_on_hit_chance": 30, "heal_percent": 2.0}},
    "core_stone_5": {"name": "Core de Colosso de Terra 💛", "sell": 3000, "skill": {"id": "a_stone_5", "name": "Colosso de Terra", "type": "active", "rarity": 5, "req_class": "guardiao", "req_spec": "spec_pedra", "target": "all", "cooldown": 8, "mult": 3.5, "buff_def": 1.2, "buff_turns": 4, "stun_on_hit_chance": 50, "stun": 1}}, # 🪨 50% de chance de Stun ao ser atacado!

    # 🛡️ ESCUDOS (Foco: Escudos Pessoais e Stun)
    "core_shield_1": {"name": "Core de Golpe de Escudo 🤍", "sell": 50, "skill": {"id": "a_shield_1", "name": "Golpe de Escudo", "type": "active", "rarity": 1, "req_class": "guardiao", "target": "single", "cooldown": 3, "mult": 1.2, "stun": 1, "taunt": True, "taunt_turns": 2}},
    "core_shield_2": {"name": "Core de Barreira de Bronze 💚", "sell": 150, "skill": {"id": "a_shield_2", "name": "Barreira de Bronze", "type": "active", "rarity": 2, "req_class": "guardiao", "target": "self", "cooldown": 3, "mult": 0, "shield_pct": 2.0, "buff_def": 0.6, "buff_turns": 3, "taunt": True, "taunt_turns": 2}},
    "core_shield_3": {"name": "Core de Impacto em Falange 💙", "sell": 400, "skill": {"id": "a_shield_3", "name": "Impacto em Falange", "type": "active", "rarity": 3, "req_class": "guardiao", "target": "all", "cooldown": 4, "mult": 1.5, "buff_def": 0.4, "buff_turns": 3, "taunt": True, "taunt_turns": 2}},
    "core_shield_4": {"name": "Core de Égide do Protetor 💜", "sell": 1000, "skill": {"id": "a_shield_4", "name": "Égide do Protetor", "type": "active", "rarity": 4, "req_class": "guardiao", "req_spec": "spec_escudos", "target": "self", "cooldown": 5, "mult": 0, "shield_pct": 4.0, "buff_def": 1.5, "buff_turns": 4, "taunt": True, "taunt_turns": 3}},
    "core_shield_5": {"name": "Core de Baluarte Absoluto 💛", "sell": 3000, "skill": {"id": "a_shield_5", "name": "Baluarte Absoluto", "type": "active", "rarity": 5, "req_class": "guardiao", "req_spec": "spec_escudos", "target": "all", "cooldown": 7, "mult": 3.0, "shield_pct": 2.5, "buff_def": 2.0, "buff_turns": 3, "stun": 1, "taunt": True, "taunt_turns": 3}},

    # =========================================================
    # 🩸 CLASSE: BERSERKER (Sacrifício e Fúria)
    # =========================================================
    # 💢 FÚRIA (Foco: Custo de Sangue e Dano Bruto)
    "core_fury_1": {"name": "Core de Golpe Raivoso 🤍", "sell": 50, "skill": {"id": "a_fury_1", "name": "Golpe Raivoso", "type": "active", "rarity": 1, "req_class": "bezerk", "target": "single", "cooldown": 3, "mult": 1.6}},
    "core_fury_2": {"name": "Core de Grito de Guerra 💚", "sell": 150, "skill": {"id": "a_fury_2", "name": "Grito de Guerra", "type": "active", "rarity": 2, "req_class": "bezerk", "target": "single", "cooldown": 3, "mult": 2.0, "buff_atk": 0.3, "buff_turns": 3}},
    "core_fury_3": {"name": "Core de Giro Violento 💙", "sell": 400, "skill": {"id": "a_fury_3", "name": "Giro Violento", "type": "active", "rarity": 3, "req_class": "bezerk", "target": "all", "cooldown": 4, "mult": 1.8}},
    "core_fury_4": {"name": "Core de Corte Berserker 💜", "sell": 1000, "skill": {"id": "a_fury_4", "name": "Corte Berserker", "type": "active", "rarity": 4, "req_class": "bezerk", "req_spec": "spec_furia", "target": "single", "cooldown": 5, "mult": 6.5, "hp_cost_pct": 0.15}}, # 🩸 Perde 15% HP pra dar um ataque massivo!
    "core_fury_5": {"name": "Core de Fúria Titânica 💛", "sell": 3000, "skill": {"id": "a_fury_5", "name": "Fúria Titânica", "type": "active", "rarity": 5, "req_class": "bezerk", "req_spec": "spec_furia", "target": "all", "cooldown": 7, "mult": 6.0, "hp_cost_pct": 0.30, "buff_atk": 0.8, "buff_turns": 4}}, # 🩸 Sacrifica 30% da vida para limpar a tela!

    # ❤️ VITALIDADE (Foco: Auto-Cura e Custo de Sangue)
    "core_vitality_1": {"name": "Core de Soco Vigoroso 🤍", "sell": 50, "skill": {"id": "a_vitality_1", "name": "Soco Vigoroso", "type": "active", "rarity": 1, "req_class": "bezerk", "target": "single", "cooldown": 3, "mult": 1.3, "heal_percent": 0.5}},
    "core_vitality_2": {"name": "Core de Pele de Sangue 💚", "sell": 150, "skill": {"id": "a_vitality_2", "name": "Pele de Sangue", "type": "active", "rarity": 2, "req_class": "bezerk", "target": "self", "cooldown": 4, "mult": 0, "heal_percent": 2.0, "buff_def": 0.4, "buff_turns": 3}},
    "core_vitality_3": {"name": "Core de Rugido do Colosso 💙", "sell": 400, "skill": {"id": "a_vitality_3", "name": "Rugido do Colosso", "type": "active", "rarity": 3, "req_class": "bezerk", "target": "all", "cooldown": 4, "mult": 1.5, "heal_percent": 1.0}},
    "core_vitality_4": {"name": "Core de Fôlego Inesgotável 💜", "sell": 1000, "skill": {"id": "a_vitality_4", "name": "Fôlego Inesgotável", "type": "active", "rarity": 4, "req_class": "bezerk", "req_spec": "spec_vitalidade", "target": "single", "cooldown": 5, "mult": 4.5, "hp_cost_pct": 0.1, "heal_percent": 5.0}}, # Se machuca e se cura na mesma hora!
    "core_vitality_5": {"name": "Core de Tremor Terrestre 💛", "sell": 3000, "skill": {"id": "a_vitality_5", "name": "Tremor Terrestre", "type": "active", "rarity": 5, "req_class": "bezerk", "req_spec": "spec_vitalidade", "target": "all", "cooldown": 7, "mult": 4.5, "hp_cost_pct": 0.2, "heal_percent": 3.0, "stun": 1}},

    # 🦇 SANGUINÁRIO (Foco: Lifesteal Percentual Balanceado)
    "core_blood_1": {"name": "Core de Mordida Vampírica 🤍", "sell": 50, "skill": {"id": "a_blood_1", "name": "Mordida Vampírica", "type": "active", "rarity": 1, "req_class": "bezerk", "target": "single", "cooldown": 3, "mult": 1.4, "lifesteal_pct": 0.2}},
    "core_blood_2": {"name": "Core de Corte Sanguessuga 💚", "sell": 150, "skill": {"id": "a_blood_2", "name": "Corte Sanguessuga", "type": "active", "rarity": 2, "req_class": "bezerk", "target": "single", "cooldown": 3, "mult": 2.0, "lifesteal_pct": 0.3}},
    "core_blood_3": {"name": "Core de Chuva de Sangue 💙", "sell": 400, "skill": {"id": "a_blood_3", "name": "Chuva de Sangue", "type": "active", "rarity": 3, "req_class": "bezerk", "target": "all", "cooldown": 4, "mult": 1.6, "lifesteal_pct": 0.3}},
    "core_blood_4": {"name": "Core de Banquete Macabro 💜", "sell": 1000, "skill": {"id": "a_blood_4", "name": "Banquete Macabro", "type": "active", "rarity": 4, "req_class": "bezerk", "req_spec": "spec_sanguinario", "target": "single", "cooldown": 5, "mult": 4.5, "lifesteal_pct": 0.5}},
    "core_blood_5": {"name": "Core de Devorar Almas 💛", "sell": 3000, "skill": {"id": "a_blood_5", "name": "Devorar Almas", "type": "active", "rarity": 5, "req_class": "bezerk", "req_spec": "spec_sanguinario", "target": "all", "cooldown": 7, "mult": 3.5, "lifesteal_pct": 0.6, "dot_mult": 1.0, "dot_turns": 3, "dot_name": "Hemorragia Profunda"}},

    # =========================================================
    # 🏹 CLASSE: ARQUEIRO (Tiro Preciso e Manipulação de Turno)
    # =========================================================
    # 🦅 CAÇADOR (Foco: Marca de Vulnerabilidade e Sangramento)
    "core_hunter_1": {"name": "Core de Tiro Rápido 🤍", "sell": 50, "skill": {"id": "a_hunter_1", "name": "Tiro Rápido", "type": "active", "rarity": 1, "req_class": "arqueiro", "target": "single", "cooldown": 3, "mult": 1.5}},
    "core_hunter_2": {"name": "Core de Flecha Farpada 💚", "sell": 150, "skill": {"id": "a_hunter_2", "name": "Flecha Farpada", "type": "active", "rarity": 2, "req_class": "arqueiro", "target": "single", "cooldown": 3, "mult": 2.0, "dot_mult": 0.8, "dot_turns": 3, "dot_name": "Sangramento"}},
    "core_hunter_3": {"name": "Core de Chuva de Prata 💙", "sell": 400, "skill": {"id": "a_hunter_3", "name": "Chuva de Prata", "type": "active", "rarity": 3, "req_class": "arqueiro", "target": "all", "cooldown": 4, "mult": 1.5, "dot_mult": 0.4, "dot_turns": 3, "dot_name": "Sangramento"}},
    "core_hunter_4": {"name": "Core de Marca da Presa 💜", "sell": 1000, "skill": {"id": "a_hunter_4", "name": "Marca da Presa", "type": "active", "rarity": 4, "req_class": "arqueiro", "req_spec": "spec_cacador", "target": "single", "cooldown": 5, "mult": 3.0, "mark_dmg_bonus": 0.15, "buff_turns": 3}}, # 🎯 O Boss recebe +15% de Dano da Raid!
    "core_hunter_5": {"name": "Core de Disparo do Predador 💛", "sell": 3000, "skill": {"id": "a_hunter_5", "name": "Disparo do Predador", "type": "active", "rarity": 5, "req_class": "arqueiro", "req_spec": "spec_cacador", "target": "single", "cooldown": 6, "mult": 5.0, "mark_dmg_bonus": 0.30, "buff_turns": 3, "dot_mult": 1.5, "dot_turns": 3, "dot_name": "Ferida Mortal"}}, # 🎯 O Boss recebe +30% de Dano da Raid!

    # 🎯 FLECHAS (Foco: Sniper, Dano Bruto Absoluto)
    "core_arrow_1": {"name": "Core de Tiro Certeiro 🤍", "sell": 50, "skill": {"id": "a_arrow_1", "name": "Tiro Certeiro", "type": "active", "rarity": 1, "req_class": "arqueiro", "target": "single", "cooldown": 3, "mult": 1.8}},
    "core_arrow_2": {"name": "Core de Flecha Perfurante 💚", "sell": 150, "skill": {"id": "a_arrow_2", "name": "Flecha Perfurante", "type": "active", "rarity": 2, "req_class": "arqueiro", "target": "single", "cooldown": 3, "mult": 2.5}},
    "core_arrow_3": {"name": "Core de Rajada de Flechas 💙", "sell": 400, "skill": {"id": "a_arrow_3", "name": "Rajada de Flechas", "type": "active", "rarity": 3, "req_class": "arqueiro", "target": "all", "cooldown": 4, "mult": 2.0}},
    "core_arrow_4": {"name": "Core de Disparo Balístico 💜", "sell": 1000, "skill": {"id": "a_arrow_4", "name": "Disparo Balístico", "type": "active", "rarity": 4, "req_class": "arqueiro", "req_spec": "spec_flechas", "target": "single", "cooldown": 5, "mult": 5.5, "debuff_def": 0.4, "debuff_turns": 3}}, # 📉 Ignora e quebra defesa
    "core_arrow_5": {"name": "Core de Flecha do Destino 💛", "sell": 3000, "skill": {"id": "a_arrow_5", "name": "Flecha do Destino", "type": "active", "rarity": 5, "req_class": "arqueiro", "req_spec": "spec_flechas", "target": "single", "cooldown": 7, "mult": 8.0, "debuff_def": 0.6, "debuff_turns": 3}}, # 📉 O MAIOR Multiplicador do Jogo

    # 🌪️ VENTO (Foco: ATB Drain, Roubo de Turnos e Evasão)
    "core_wind_1": {"name": "Core de Flecha Veloz 🤍", "sell": 50, "skill": {"id": "a_wind_1", "name": "Flecha Veloz", "type": "active", "rarity": 1, "req_class": "arqueiro", "target": "single", "cooldown": 3, "mult": 1.4, "atb_boost": 20.0}},
    "core_wind_2": {"name": "Core de Passos de Vento 💚", "sell": 150, "skill": {"id": "a_wind_2", "name": "Passos de Vento", "type": "active", "rarity": 2, "req_class": "arqueiro", "target": "self", "cooldown": 3, "mult": 0, "buff_eva": 0.5, "buff_turns": 3}},
    "core_wind_3": {"name": "Core de Ciclone de Flechas 💙", "sell": 400, "skill": {"id": "a_wind_3", "name": "Ciclone de Flechas", "type": "active", "rarity": 3, "req_class": "arqueiro", "target": "all", "cooldown": 4, "mult": 1.5, "atb_boost": 15.0}},
    "core_wind_4": {"name": "Core de Disparo Vendaval 💜", "sell": 1000, "skill": {"id": "a_wind_4", "name": "Disparo Vendaval", "type": "active", "rarity": 4, "req_class": "arqueiro", "req_spec": "spec_vento", "target": "single", "cooldown": 5, "mult": 3.5, "atb_drain": 40.0}}, # ⏳ Atrasa o turno do inimigo!
    "core_wind_5": {"name": "Core de Tempestade de Vento 💛", "sell": 3000, "skill": {"id": "a_wind_5", "name": "Tempestade de Vento", "type": "active", "rarity": 5, "req_class": "arqueiro", "req_spec": "spec_vento", "target": "all", "cooldown": 7, "mult": 3.5, "buff_eva": 1.0, "buff_turns": 3, "atb_drain": 30.0}}, # ⏳ A equipe desvia de tudo e o inimigo não ataca!
    # =========================================================
    # 🧠 PASSIVAS MAGO (Fogo: ATK/Crit | Gelo: HP/ACC | Raio: SPD/ATK)
    # =========================================================
    "core_p_fire_1": {"name": "Passiva Fogo 🤍", "skill": {"id": "p_fire_1", "name": "Afinidade Ígnea I", "type": "passive", "rarity": 1, "req_class": "mago", "bonus_pct": {"atk": 0.05}}},
    "core_p_fire_2": {"name": "Passiva Fogo 💚", "skill": {"id": "p_fire_2", "name": "Afinidade Ígnea II", "type": "passive", "rarity": 2, "req_class": "mago", "bonus_pct": {"atk": 0.10}}},
    "core_p_fire_3": {"name": "Passiva Fogo 💙", "skill": {"id": "p_fire_3", "name": "Mestre do Calor", "type": "passive", "rarity": 3, "req_class": "mago", "bonus_pct": {"atk": 0.15}}},
    "core_p_fire_4": {"name": "Passiva Fogo 💜", "skill": {"id": "p_fire_4", "name": "Corpo de Chamas", "type": "passive", "rarity": 4, "req_class": "mago", "req_spec": "spec_fogo", "bonus_pct": {"atk": 0.20, "crit": 0.10}}},
    "core_p_fire_5": {"name": "Passiva Fogo 💛", "skill": {"id": "p_fire_5", "name": "Alma de Ifrit", "type": "passive", "rarity": 5, "req_class": "mago", "req_spec": "spec_fogo", "bonus_pct": {"atk": 0.35, "crit": 0.20}}},

    "core_p_ice_1": {"name": "Passiva Gelo 🤍", "skill": {"id": "p_ice_1", "name": "Foco Glacial I", "type": "passive", "rarity": 1, "req_class": "mago", "bonus_pct": {"hp_max": 0.05}}},
    "core_p_ice_2": {"name": "Passiva Gelo 💚", "skill": {"id": "p_ice_2", "name": "Foco Glacial II", "type": "passive", "rarity": 2, "req_class": "mago", "bonus_pct": {"hp_max": 0.10}}},
    "core_p_ice_3": {"name": "Passiva Gelo 💙", "skill": {"id": "p_ice_3", "name": "Mente Fria", "type": "passive", "rarity": 3, "req_class": "mago", "bonus_pct": {"hp_max": 0.15}}},
    "core_p_ice_4": {"name": "Passiva Gelo 💜", "skill": {"id": "p_ice_4", "name": "Veias de Gelo", "type": "passive", "rarity": 4, "req_class": "mago", "req_spec": "spec_gelo", "bonus_pct": {"hp_max": 0.20, "acc": 0.15}}},
    "core_p_ice_5": {"name": "Passiva Gelo 💛", "skill": {"id": "p_ice_5", "name": "Coração de Shiva", "type": "passive", "rarity": 5, "req_class": "mago", "req_spec": "spec_gelo", "bonus_pct": {"hp_max": 0.30, "acc": 0.25, "def": 0.20}}},

    "core_p_thunder_1": {"name": "Passiva Raio 🤍", "skill": {"id": "p_thunder_1", "name": "Reflexos Elétricos I", "type": "passive", "rarity": 1, "req_class": "mago", "bonus_pct": {"spd": 0.05}}},
    "core_p_thunder_2": {"name": "Passiva Raio 💚", "skill": {"id": "p_thunder_2", "name": "Reflexos Elétricos II", "type": "passive", "rarity": 2, "req_class": "mago", "bonus_pct": {"spd": 0.10}}},
    "core_p_thunder_3": {"name": "Passiva Raio 💙", "skill": {"id": "p_thunder_3", "name": "Condutor", "type": "passive", "rarity": 3, "req_class": "mago", "bonus_pct": {"spd": 0.15}}},
    "core_p_thunder_4": {"name": "Passiva Raio 💜", "skill": {"id": "p_thunder_4", "name": "Sobrecarga", "type": "passive", "rarity": 4, "req_class": "mago", "req_spec": "spec_raio", "bonus_pct": {"spd": 0.20, "atk": 0.15}}},
    "core_p_thunder_5": {"name": "Passiva Raio 💛", "skill": {"id": "p_thunder_5", "name": "Avatar da Tempestade", "type": "passive", "rarity": 5, "req_class": "mago", "req_spec": "spec_raio", "bonus_pct": {"spd": 0.30, "atk": 0.30}}},

    # =========================================================
    # 🧠 PASSIVAS GUERREIRO (Espada: ATK/Crit | Luvas: DEF/ATK | Lança: ATK/ACC)
    # =========================================================
    "core_p_sword_1": {"name": "Passiva Espada 🤍", "skill": {"id": "p_sword_1", "name": "Força Bruta I", "type": "passive", "rarity": 1, "req_class": "guerreiro", "bonus_pct": {"atk": 0.05}}},
    "core_p_sword_2": {"name": "Passiva Espada 💚", "skill": {"id": "p_sword_2", "name": "Força Bruta II", "type": "passive", "rarity": 2, "req_class": "guerreiro", "bonus_pct": {"atk": 0.10}}},
    "core_p_sword_3": {"name": "Passiva Espada 💙", "skill": {"id": "p_sword_3", "name": "Aperto Firme", "type": "passive", "rarity": 3, "req_class": "guerreiro", "bonus_pct": {"atk": 0.15}}},
    "core_p_sword_4": {"name": "Passiva Espada 💜", "skill": {"id": "p_sword_4", "name": "Maestria com Lâminas", "type": "passive", "rarity": 4, "req_class": "guerreiro", "req_spec": "spec_espada", "bonus_pct": {"atk": 0.20, "crit": 0.15}}},
    "core_p_sword_5": {"name": "Passiva Espada 💛", "skill": {"id": "p_sword_5", "name": "Deus da Guerra", "type": "passive", "rarity": 5, "req_class": "guerreiro", "req_spec": "spec_espada", "bonus_pct": {"atk": 0.35, "crit": 0.25}}},

    "core_p_glove_1": {"name": "Passiva Luvas 🤍", "skill": {"id": "p_glove_1", "name": "Queixo Duro I", "type": "passive", "rarity": 1, "req_class": "guerreiro", "bonus_pct": {"def": 0.05}}},
    "core_p_glove_2": {"name": "Passiva Luvas 💚", "skill": {"id": "p_glove_2", "name": "Queixo Duro II", "type": "passive", "rarity": 2, "req_class": "guerreiro", "bonus_pct": {"def": 0.10}}},
    "core_p_glove_3": {"name": "Passiva Luvas 💙", "skill": {"id": "p_glove_3", "name": "Fibra Muscular", "type": "passive", "rarity": 3, "req_class": "guerreiro", "bonus_pct": {"def": 0.15}}},
    "core_p_glove_4": {"name": "Passiva Luvas 💜", "skill": {"id": "p_glove_4", "name": "Peso Pesado", "type": "passive", "rarity": 4, "req_class": "guerreiro", "req_spec": "spec_luvas", "bonus_pct": {"def": 0.20, "atk": 0.15}}},
    "core_p_glove_5": {"name": "Passiva Luvas 💛", "skill": {"id": "p_glove_5", "name": "Corpo Diamante", "type": "passive", "rarity": 5, "req_class": "guerreiro", "req_spec": "spec_luvas", "bonus_pct": {"def": 0.35, "atk": 0.20, "hp_max": 0.20}}},

    "core_p_spear_1": {"name": "Passiva Lança 🤍", "skill": {"id": "p_spear_1", "name": "Estabilidade I", "type": "passive", "rarity": 1, "req_class": "guerreiro", "bonus_pct": {"acc": 0.05}}},
    "core_p_spear_2": {"name": "Passiva Lança 💚", "skill": {"id": "p_spear_2", "name": "Estabilidade II", "type": "passive", "rarity": 2, "req_class": "guerreiro", "bonus_pct": {"acc": 0.10}}},
    "core_p_spear_3": {"name": "Passiva Lança 💙", "skill": {"id": "p_spear_3", "name": "Foco Físico", "type": "passive", "rarity": 3, "req_class": "guerreiro", "bonus_pct": {"acc": 0.15}}},
    "core_p_spear_4": {"name": "Passiva Lança 💜", "skill": {"id": "p_spear_4", "name": "Perfurador", "type": "passive", "rarity": 4, "req_class": "guerreiro", "req_spec": "spec_lanca", "bonus_pct": {"acc": 0.20, "atk": 0.20}}},
    "core_p_spear_5": {"name": "Passiva Lança 💛", "skill": {"id": "p_spear_5", "name": "Olho do Dragão", "type": "passive", "rarity": 5, "req_class": "guerreiro", "req_spec": "spec_lanca", "bonus_pct": {"acc": 0.40, "atk": 0.30}}},

    # =========================================================
    # 🧠 PASSIVAS ASSASSINO (Sombras: EVA/SPD | Fatal: Crit/ATK | Veneno: ACC/ATK)
    # =========================================================
    "core_p_shadow_1": {"name": "Passiva Sombras 🤍", "skill": {"id": "p_shadow_1", "name": "Passos Leves I", "type": "passive", "rarity": 1, "req_class": "assassino", "bonus_pct": {"eva": 0.05}}},
    "core_p_shadow_2": {"name": "Passiva Sombras 💚", "skill": {"id": "p_shadow_2", "name": "Passos Leves II", "type": "passive", "rarity": 2, "req_class": "assassino", "bonus_pct": {"eva": 0.10}}},
    "core_p_shadow_3": {"name": "Passiva Sombras 💙", "skill": {"id": "p_shadow_3", "name": "Furtividade", "type": "passive", "rarity": 3, "req_class": "assassino", "bonus_pct": {"eva": 0.15}}},
    "core_p_shadow_4": {"name": "Passiva Sombras 💜", "skill": {"id": "p_shadow_4", "name": "Manto da Noite", "type": "passive", "rarity": 4, "req_class": "assassino", "req_spec": "spec_sombras", "bonus_pct": {"eva": 0.25, "spd": 0.15}}},
    "core_p_shadow_5": {"name": "Passiva Sombras 💛", "skill": {"id": "p_shadow_5", "name": "Intocável", "type": "passive", "rarity": 5, "req_class": "assassino", "req_spec": "spec_sombras", "bonus_pct": {"eva": 0.40, "spd": 0.25}}},

    "core_p_fatal_1": {"name": "Passiva Fatal 🤍", "skill": {"id": "p_fatal_1", "name": "Instinto Assassino I", "type": "passive", "rarity": 1, "req_class": "assassino", "bonus_pct": {"crit": 0.05}}},
    "core_p_fatal_2": {"name": "Passiva Fatal 💚", "skill": {"id": "p_fatal_2", "name": "Instinto Assassino II", "type": "passive", "rarity": 2, "req_class": "assassino", "bonus_pct": {"crit": 0.10}}},
    "core_p_fatal_3": {"name": "Passiva Fatal 💙", "skill": {"id": "p_fatal_3", "name": "Ponto Cego", "type": "passive", "rarity": 3, "req_class": "assassino", "bonus_pct": {"crit": 0.15}}},
    "core_p_fatal_4": {"name": "Passiva Fatal 💜", "skill": {"id": "p_fatal_4", "name": "Executor", "type": "passive", "rarity": 4, "req_class": "assassino", "req_spec": "spec_fatal", "bonus_pct": {"crit": 0.25, "atk": 0.15}}},
    "core_p_fatal_5": {"name": "Passiva Fatal 💛", "skill": {"id": "p_fatal_5", "name": "Ceifador", "type": "passive", "rarity": 5, "req_class": "assassino", "req_spec": "spec_fatal", "bonus_pct": {"crit": 0.40, "atk": 0.30}}},

    "core_p_venom_1": {"name": "Passiva Veneno 🤍", "skill": {"id": "p_venom_1", "name": "Alquimia I", "type": "passive", "rarity": 1, "req_class": "assassino", "bonus_pct": {"acc": 0.05}}},
    "core_p_venom_2": {"name": "Passiva Veneno 💚", "skill": {"id": "p_venom_2", "name": "Alquimia II", "type": "passive", "rarity": 2, "req_class": "assassino", "bonus_pct": {"acc": 0.10}}},
    "core_p_venom_3": {"name": "Passiva Veneno 💙", "skill": {"id": "p_venom_3", "name": "Sangue Tóxico", "type": "passive", "rarity": 3, "req_class": "assassino", "bonus_pct": {"acc": 0.15}}},
    "core_p_venom_4": {"name": "Passiva Veneno 💜", "skill": {"id": "p_venom_4", "name": "Mestre dos Venenos", "type": "passive", "rarity": 4, "req_class": "assassino", "req_spec": "spec_veneno", "bonus_pct": {"acc": 0.20, "atk": 0.20}}},
    "core_p_venom_5": {"name": "Passiva Veneno 💛", "skill": {"id": "p_venom_5", "name": "Peste Viva", "type": "passive", "rarity": 5, "req_class": "assassino", "req_spec": "spec_veneno", "bonus_pct": {"acc": 0.35, "atk": 0.30}}},

    # =========================================================
    # 🧠 PASSIVAS SUPORTE (Cura: HP | Equilíbrio: ATK/HP | Apoio: DEF/SPD)
    # =========================================================
    "core_p_heal_1": {"name": "Passiva Cura 🤍", "skill": {"id": "p_heal_1", "name": "Vitalidade I", "type": "passive", "rarity": 1, "req_class": "curandeiro", "bonus_pct": {"hp_max": 0.05}}},
    "core_p_heal_2": {"name": "Passiva Cura 💚", "skill": {"id": "p_heal_2", "name": "Vitalidade II", "type": "passive", "rarity": 2, "req_class": "curandeiro", "bonus_pct": {"hp_max": 0.10}}},
    "core_p_heal_3": {"name": "Passiva Cura 💙", "skill": {"id": "p_heal_3", "name": "Coração Puro", "type": "passive", "rarity": 3, "req_class": "curandeiro", "bonus_pct": {"hp_max": 0.15}}},
    "core_p_heal_4": {"name": "Passiva Cura 💜", "skill": {"id": "p_heal_4", "name": "Aura de Luz", "type": "passive", "rarity": 4, "req_class": "curandeiro", "req_spec": "spec_cura", "bonus_pct": {"hp_max": 0.25, "def": 0.15}}},
    "core_p_heal_5": {"name": "Passiva Cura 💛", "skill": {"id": "p_heal_5", "name": "Anjo Guardião", "type": "passive", "rarity": 5, "req_class": "curandeiro", "req_spec": "spec_cura", "bonus_pct": {"hp_max": 0.40}, "triggers": {"auto_revive_once": True}}}, # ✨ O auto-revive mágico da Raid!

    "core_p_balance_1": {"name": "Passiva Equilíbrio 🤍", "skill": {"id": "p_balance_1", "name": "Harmonia I", "type": "passive", "rarity": 1, "req_class": "curandeiro", "bonus_pct": {"atk": 0.05}}},
    "core_p_balance_2": {"name": "Passiva Equilíbrio 💚", "skill": {"id": "p_balance_2", "name": "Harmonia II", "type": "passive", "rarity": 2, "req_class": "curandeiro", "bonus_pct": {"atk": 0.10}}},
    "core_p_balance_3": {"name": "Passiva Equilíbrio 💙", "skill": {"id": "p_balance_3", "name": "Yin", "type": "passive", "rarity": 3, "req_class": "curandeiro", "bonus_pct": {"atk": 0.15}}},
    "core_p_balance_4": {"name": "Passiva Equilíbrio 💜", "skill": {"id": "p_balance_4", "name": "Yang", "type": "passive", "rarity": 4, "req_class": "curandeiro", "req_spec": "spec_equilibrio", "bonus_pct": {"atk": 0.20, "hp_max": 0.20}}},
    "core_p_balance_5": {"name": "Passiva Equilíbrio 💛", "skill": {"id": "p_balance_5", "name": "Caminho do Meio", "type": "passive", "rarity": 5, "req_class": "curandeiro", "req_spec": "spec_equilibrio", "bonus_pct": {"atk": 0.30, "hp_max": 0.30, "def": 0.15}}},

    "core_p_support_1": {"name": "Passiva Apoio 🤍", "skill": {"id": "p_support_1", "name": "Prontidão I", "type": "passive", "rarity": 1, "req_class": "curandeiro", "bonus_pct": {"spd": 0.05}}},
    "core_p_support_2": {"name": "Passiva Apoio 💚", "skill": {"id": "p_support_2", "name": "Prontidão II", "type": "passive", "rarity": 2, "req_class": "curandeiro", "bonus_pct": {"spd": 0.10}}},
    "core_p_support_3": {"name": "Passiva Apoio 💙", "skill": {"id": "p_support_3", "name": "Tático", "type": "passive", "rarity": 3, "req_class": "curandeiro", "bonus_pct": {"spd": 0.15}}},
    "core_p_support_4": {"name": "Passiva Apoio 💜", "skill": {"id": "p_support_4", "name": "Bastião", "type": "passive", "rarity": 4, "req_class": "curandeiro", "req_spec": "spec_apoio", "bonus_pct": {"spd": 0.20, "def": 0.20}}},
    "core_p_support_5": {"name": "Passiva Apoio 💛", "skill": {"id": "p_support_5", "name": "General da Luz", "type": "passive", "rarity": 5, "req_class": "curandeiro", "req_spec": "spec_apoio", "bonus_pct": {"spd": 0.30, "def": 0.40}}},

    # =========================================================
    # 🧠 PASSIVAS TANKER (Espinhos: DEF/ATK | Pedra: HP/DEF | Escudos: DEF Max)
    # =========================================================
    "core_p_thorns_1": {"name": "Passiva Espinhos 🤍", "skill": {"id": "p_thorns_1", "name": "Couro Duro I", "type": "passive", "rarity": 1, "req_class": "guardiao", "bonus_pct": {"def": 0.05}}},
    "core_p_thorns_2": {"name": "Passiva Espinhos 💚", "skill": {"id": "p_thorns_2", "name": "Couro Duro II", "type": "passive", "rarity": 2, "req_class": "guardiao", "bonus_pct": {"def": 0.10}}},
    "core_p_thorns_3": {"name": "Passiva Espinhos 💙", "skill": {"id": "p_thorns_3", "name": "Aura Farpada", "type": "passive", "rarity": 3, "req_class": "guardiao", "bonus_pct": {"def": 0.15}}},
    "core_p_thorns_4": {"name": "Passiva Espinhos 💜", "skill": {"id": "p_thorns_4", "name": "Armadura de Lâminas", "type": "passive", "rarity": 4, "req_class": "guardiao", "req_spec": "spec_espinhos", "bonus_pct": {"def": 0.25, "atk": 0.15}}},
    "core_p_thorns_5": {"name": "Passiva Espinhos 💛", "skill": {"id": "p_thorns_5", "name": "Vingança Física", "type": "passive", "rarity": 5, "req_class": "guardiao", "req_spec": "spec_espinhos", "bonus_pct": {"def": 0.40, "atk": 0.25}}},

    "core_p_stone_1": {"name": "Passiva Pedra 🤍", "skill": {"id": "p_stone_1", "name": "Resiliência I", "type": "passive", "rarity": 1, "req_class": "guardiao", "bonus_pct": {"hp_max": 0.05}}},
    "core_p_stone_2": {"name": "Passiva Pedra 💚", "skill": {"id": "p_stone_2", "name": "Resiliência II", "type": "passive", "rarity": 2, "req_class": "guardiao", "bonus_pct": {"hp_max": 0.10}}},
    "core_p_stone_3": {"name": "Passiva Pedra 💙", "skill": {"id": "p_stone_3", "name": "Inabalável", "type": "passive", "rarity": 3, "req_class": "guardiao", "bonus_pct": {"hp_max": 0.15}}},
    "core_p_stone_4": {"name": "Passiva Pedra 💜", "skill": {"id": "p_stone_4", "name": "Montanha Viva", "type": "passive", "rarity": 4, "req_class": "guardiao", "req_spec": "spec_pedra", "bonus_pct": {"hp_max": 0.25, "def": 0.15}}},
    "core_p_stone_5": {"name": "Passiva Pedra 💛", "skill": {"id": "p_stone_5", "name": "Imortal", "type": "passive", "rarity": 5, "req_class": "guardiao", "req_spec": "spec_pedra", "bonus_pct": {"hp_max": 0.40, "def": 0.25}, "triggers": {"immortal_1hp_once": True}}}, # 💢 O famoso 1HP que nós codamos no Interceptor!

    "core_p_shield_1": {"name": "Passiva Escudos 🤍", "skill": {"id": "p_shield_1", "name": "Guarda I", "type": "passive", "rarity": 1, "req_class": "guardiao", "bonus_pct": {"def": 0.05}}},
    "core_p_shield_2": {"name": "Passiva Escudos 💚", "skill": {"id": "p_shield_2", "name": "Guarda II", "type": "passive", "rarity": 2, "req_class": "guardiao", "bonus_pct": {"def": 0.10}}},
    "core_p_shield_3": {"name": "Passiva Escudos 💙", "skill": {"id": "p_shield_3", "name": "Aço Puro", "type": "passive", "rarity": 3, "req_class": "guardiao", "bonus_pct": {"def": 0.20}}},
    "core_p_shield_4": {"name": "Passiva Escudos 💜", "skill": {"id": "p_shield_4", "name": "Muralha de Ferro", "type": "passive", "rarity": 4, "req_class": "guardiao", "req_spec": "spec_escudos", "bonus_pct": {"def": 0.35}}},
    "core_p_shield_5": {"name": "Passiva Escudos 💛", "skill": {"id": "p_shield_5", "name": "Fortaleza Ambulante", "type": "passive", "rarity": 5, "req_class": "guardiao", "req_spec": "spec_escudos", "bonus_pct": {"def": 0.60}}}, # Maior multiplicador de defesa do jogo!

    # =========================================================
    # 🧠 PASSIVAS BERSERKER (Fúria: ATK Max | Vitalidade: HP Max | Sanguinário: Lifesteal)
    # =========================================================
    "core_p_fury_1": {"name": "Passiva Fúria 🤍", "skill": {"id": "p_fury_1", "name": "Raiva I", "type": "passive", "rarity": 1, "req_class": "bezerk", "bonus_pct": {"atk": 0.05}}},
    "core_p_fury_2": {"name": "Passiva Fúria 💚", "skill": {"id": "p_fury_2", "name": "Raiva II", "type": "passive", "rarity": 2, "req_class": "bezerk", "bonus_pct": {"atk": 0.10}}},
    "core_p_fury_3": {"name": "Passiva Fúria 💙", "skill": {"id": "p_fury_3", "name": "Adrenalina", "type": "passive", "rarity": 3, "req_class": "bezerk", "bonus_pct": {"atk": 0.15}}},
    "core_p_fury_4": {"name": "Passiva Fúria 💜", "skill": {"id": "p_fury_4", "name": "Fervor Batalhador", "type": "passive", "rarity": 4, "req_class": "bezerk", "req_spec": "spec_furia", "bonus_pct": {"atk": 0.30}}},
    "core_p_fury_5": {"name": "Passiva Fúria 💛", "skill": {"id": "p_fury_5", "name": "Destruidor de Mundos", "type": "passive", "rarity": 5, "req_class": "bezerk", "req_spec": "spec_furia", "bonus_pct": {"atk": 0.50, "spd": 0.15}}},

    "core_p_vitality_1": {"name": "Passiva Vitalidade 🤍", "skill": {"id": "p_vitality_1", "name": "Sangue Frio I", "type": "passive", "rarity": 1, "req_class": "bezerk", "bonus_pct": {"hp_max": 0.05}}},
    "core_p_vitality_2": {"name": "Passiva Vitalidade 💚", "skill": {"id": "p_vitality_2", "name": "Sangue Frio II", "type": "passive", "rarity": 2, "req_class": "bezerk", "bonus_pct": {"hp_max": 0.10}}},
    "core_p_vitality_3": {"name": "Passiva Vitalidade 💙", "skill": {"id": "p_vitality_3", "name": "Cicatrizes", "type": "passive", "rarity": 3, "req_class": "bezerk", "bonus_pct": {"hp_max": 0.15}}},
    "core_p_vitality_4": {"name": "Passiva Vitalidade 💜", "skill": {"id": "p_vitality_4", "name": "Gigante", "type": "passive", "rarity": 4, "req_class": "bezerk", "req_spec": "spec_vitalidade", "bonus_pct": {"hp_max": 0.30}}},
    "core_p_vitality_5": {"name": "Passiva Vitalidade 💛", "skill": {"id": "p_vitality_5", "name": "Titã de Sangue", "type": "passive", "rarity": 5, "req_class": "bezerk", "req_spec": "spec_vitalidade", "bonus_pct": {"hp_max": 0.50, "def": 0.15}}},

    "core_p_blood_1": {"name": "Passiva Sanguinário 🤍", "skill": {"id": "p_blood_1", "name": "Sede I", "type": "passive", "rarity": 1, "req_class": "bezerk", "bonus_pct": {"atk": 0.05}}},
    "core_p_blood_2": {"name": "Passiva Sanguinário 💚", "skill": {"id": "p_blood_2", "name": "Sede II", "type": "passive", "rarity": 2, "req_class": "bezerk", "bonus_pct": {"atk": 0.10}}},
    "core_p_blood_3": {"name": "Passiva Sanguinário 💙", "skill": {"id": "p_blood_3", "name": "Hematofagia", "type": "passive", "rarity": 3, "req_class": "bezerk", "bonus_pct": {"atk": 0.15}}},
    "core_p_blood_4": {"name": "Passiva Sanguinário 💜", "skill": {"id": "p_blood_4", "name": "Banho de Sangue", "type": "passive", "rarity": 4, "req_class": "bezerk", "req_spec": "spec_sanguinario", "bonus_pct": {"atk": 0.20}, "triggers": {"innate_lifesteal": 0.10}}}, # 🦇 Roubo de vida passivo!
    "core_p_blood_5": {"name": "Passiva Sanguinário 💛", "skill": {"id": "p_blood_5", "name": "Conde Drácula", "type": "passive", "rarity": 5, "req_class": "bezerk", "req_spec": "spec_sanguinario", "bonus_pct": {"atk": 0.30}, "triggers": {"innate_lifesteal": 0.25}}}, # 🦇 25% de Lifesteal em qualquer ataque!

    # =========================================================
    # 🧠 PASSIVAS ARQUEIRO (Caçador: ACC/ATK | Flechas: Crit/ATK | Vento: EVA/SPD)
    # =========================================================
    "core_p_hunter_1": {"name": "Passiva Caçador 🤍", "skill": {"id": "p_hunter_1", "name": "Olho de Águia I", "type": "passive", "rarity": 1, "req_class": "arqueiro", "bonus_pct": {"acc": 0.05}}},
    "core_p_hunter_2": {"name": "Passiva Caçador 💚", "skill": {"id": "p_hunter_2", "name": "Olho de Águia II", "type": "passive", "rarity": 2, "req_class": "arqueiro", "bonus_pct": {"acc": 0.10}}},
    "core_p_hunter_3": {"name": "Passiva Caçador 💙", "skill": {"id": "p_hunter_3", "name": "Foco Absoluto", "type": "passive", "rarity": 3, "req_class": "arqueiro", "bonus_pct": {"acc": 0.15}}},
    "core_p_hunter_4": {"name": "Passiva Caçador 💜", "skill": {"id": "p_hunter_4", "name": "Rastreador", "type": "passive", "rarity": 4, "req_class": "arqueiro", "req_spec": "spec_cacador", "bonus_pct": {"acc": 0.20, "atk": 0.15}}},
    "core_p_hunter_5": {"name": "Passiva Caçador 💛", "skill": {"id": "p_hunter_5", "name": "Mestre de Caça", "type": "passive", "rarity": 5, "req_class": "arqueiro", "req_spec": "spec_cacador", "bonus_pct": {"acc": 0.35, "atk": 0.25}}},

    "core_p_arrow_1": {"name": "Passiva Flechas 🤍", "skill": {"id": "p_arrow_1", "name": "Mira Fria I", "type": "passive", "rarity": 1, "req_class": "arqueiro", "bonus_pct": {"crit": 0.05}}},
    "core_p_arrow_2": {"name": "Passiva Flechas 💚", "skill": {"id": "p_arrow_2", "name": "Mira Fria II", "type": "passive", "rarity": 2, "req_class": "arqueiro", "bonus_pct": {"crit": 0.10}}},
    "core_p_arrow_3": {"name": "Passiva Flechas 💙", "skill": {"id": "p_arrow_3", "name": "Atirador", "type": "passive", "rarity": 3, "req_class": "arqueiro", "bonus_pct": {"crit": 0.15}}},
    "core_p_arrow_4": {"name": "Passiva Flechas 💜", "skill": {"id": "p_arrow_4", "name": "Mãos Precisas", "type": "passive", "rarity": 4, "req_class": "arqueiro", "req_spec": "spec_flechas", "bonus_pct": {"crit": 0.25, "atk": 0.15}}},
    "core_p_arrow_5": {"name": "Passiva Flechas 💛", "skill": {"id": "p_arrow_5", "name": "Sniper de Elite", "type": "passive", "rarity": 5, "req_class": "arqueiro", "req_spec": "spec_flechas", "bonus_pct": {"crit": 0.40, "atk": 0.30}}},

    "core_p_wind_1": {"name": "Passiva Vento 🤍", "skill": {"id": "p_wind_1", "name": "Brisa I", "type": "passive", "rarity": 1, "req_class": "arqueiro", "bonus_pct": {"eva": 0.05}}},
    "core_p_wind_2": {"name": "Passiva Vento 💚", "skill": {"id": "p_wind_2", "name": "Brisa II", "type": "passive", "rarity": 2, "req_class": "arqueiro", "bonus_pct": {"eva": 0.10}}},
    "core_p_wind_3": {"name": "Passiva Vento 💙", "skill": {"id": "p_wind_3", "name": "Andarilho", "type": "passive", "rarity": 3, "req_class": "arqueiro", "bonus_pct": {"eva": 0.15}}},
    "core_p_wind_4": {"name": "Passiva Vento 💜", "skill": {"id": "p_wind_4", "name": "Esquiva Ventania", "type": "passive", "rarity": 4, "req_class": "arqueiro", "req_spec": "spec_vento", "bonus_pct": {"eva": 0.25, "spd": 0.15}}},
    "core_p_wind_5": {"name": "Passiva Vento 💛", "skill": {"id": "p_wind_5", "name": "Fantasma do Vento", "type": "passive", "rarity": 5, "req_class": "arqueiro", "req_spec": "spec_vento", "bonus_pct": {"eva": 0.40, "spd": 0.30}}},



}

# =========================================================
# 🎲 SISTEMA DE AFIXOS (bônus extra de raridade) — v2 (09/07/2026)
# =========================================================
# Reformulado: cada skill agora rola VÁRIOS bônus flat (soma direta ao
# atributo), com a QUANTIDADE definida pela raridade:
#   Comum (1)    → 0 bônus
#   Incomum (2)  → 1 bônus
#   Raro (3)     → 2 bônus
#   Épico (4)    → 3 bônus
#   Lendário (5) → 4 bônus
# Cada bônus é um atributo aleatório com valor aleatório de 1 a 7.
# Os bônus são rolados ao APRENDER a skill, e podem ser re-rolados pagando
# ouro + 1 core da própria skill (ver reroll_skill_affix).

STAT_AFFIX_POOL = ["atk", "def", "hp_max", "spd", "crit", "acc", "eva"]

STAT_LABELS = {
    "atk": "ATK", "def": "DEF", "hp_max": "VIDA MÁX",
    "spd": "VELOCIDADE", "crit": "CRÍTICO", "acc": "PRECISÃO", "eva": "ESQUIVA",
}

AFFIX_VALOR_MIN = 1
AFFIX_VALOR_MAX = 7

# raridade (1-5) → quantos bônus a skill ganha
AFFIX_QTD_POR_RARIDADE = {1: 0, 2: 1, 3: 2, 4: 3, 5: 4}

# =============================================================================
# 📈 ESCALA DOS AFIXOS (25/09/2026, pedido do dev)
# -----------------------------------------------------------------------------
# Antes: +1 a +7 FIXO, em qualquer raridade e qualquer nível. Medido: no
# Andar 100 os monstros têm ~43 mil de HP e ~4,6 mil de ATK/DEF/VEL — +7 de
# precisão numa lendária não mudava nada no endgame (e +7 de ATK num
# personagem de ATK 11 era +64%: pesava demais no começo e nada no fim).
# Agora o bônus = BASE do atributo × RARIDADE × QUALIDADE da rolagem × NÍVEL
# da skill (linear no nível: Nv2 = 2×, Nv10 = 10×).
# · ATK/DEF/VEL: 50 por nível (lendária). HP: 10× isso — os números de vida
#   do jogo são 10× maiores que os de ataque (monstro do andar 100: 43k HP,
#   4,6k ATK).
# · CRIT/PRECISÃO/ESQUIVA são PONTOS DE PORCENTAGEM (crit 30 = 30% de
#   chance; acerto = 100 + precisão − esquiva). Não podem crescer como ATK:
#   1,5 por nível na lendária → 15 no nível 10.
# · O "value" 1..7 que já estava gravado em cada afixo virou a QUALIDADE da
#   rolagem (0,7× a 1,3×; 4 é a média). Skills já aprendidas passam pra
#   escala nova sozinhas, e o re-roll continua sendo aposta.
# =============================================================================
# 25/09 (2ª rodada, dev): metade — lendária média = 25 por nível (250 no
# Nv10). Crit/precisão/esquiva entram na MESMA escala: acerto e crítico
# são "um menos o outro" (atacante − defensor), e o crítico que passa de
# 100 vira dano crítico — então número grande não quebra mais nada.
AFFIX_BASE = {"atk": 25, "def": 25, "spd": 25, "hp_max": 250,
              "crit": 25, "acc": 25, "eva": 25}
AFFIX_RARIDADE = {1: 0.0, 2: 0.3, 3: 0.5, 4: 0.75, 5: 1.0}


def qualidade_do_afixo(valor) -> float:
    """1..7 → 0,7..1,3 (4 = 1,0)."""
    v = max(AFFIX_VALOR_MIN, min(AFFIX_VALOR_MAX, int(valor or 4)))
    return 0.7 + (v - 1) * 0.1


def valor_do_afixo(stat: str, valor, rarity: int, level: int = 1) -> int:
    """O bônus REAL que um afixo dá, com raridade e nível da skill."""
    base = AFFIX_BASE.get(stat, 0)
    rar = AFFIX_RARIDADE.get(max(1, min(5, int(rarity or 1))), 0.0)
    nivel = max(1, min(10, int(level or 1)))
    if not base or not rar:
        return 0
    return max(1, int(round(base * rar * qualidade_do_afixo(valor) * nivel)))


def roll_skill_affix(rarity: int) -> dict:
    """Sorteia os afixos de uma skill: o atributo e a QUALIDADE (1..7) de
    cada um. O quanto isso vale é `valor_do_afixo` (raridade × nível).
    Comum não ganha bônus nenhum (lista vazia)."""
    rarity = max(1, min(5, int(rarity)))
    qtd = AFFIX_QTD_POR_RARIDADE.get(rarity, 0)

    bonuses = []
    for _ in range(qtd):
        stat = random.choice(STAT_AFFIX_POOL)
        valor = random.randint(AFFIX_VALOR_MIN, AFFIX_VALOR_MAX)
        bonuses.append({"stat": stat, "value": valor})

    return {"kind": "escala_v2", "bonuses": bonuses}


def format_skill_affix(affix: dict | None, rarity: int = 1, level: int = 1) -> str:
    """Traduz o afixo pra texto, com o valor REAL no nível atual da skill."""
    if not isinstance(affix, dict):
        return ""

    bonuses = affix.get("bonuses") or []
    if not bonuses:
        return "<i>Sem bônus (raridade Comum)</i>"

    partes = []
    for b in bonuses:
        label = STAT_LABELS.get(b.get("stat"), b.get("stat", "?"))
        partes.append(f"{label} +{valor_do_afixo(b.get('stat'), b.get('value'), rarity, level)}")
    return "💠 <b>Bônus:</b> " + ", ".join(partes)


def get_skill_by_id(search_id: str) -> dict | None:
    """
    Radar Mestre: Busca a skill tanto pelo ID do Core de drop (ex: core_fire_1) 
    quanto pelo ID interno do motor de combate (ex: a_fire_1 ou p_wind_1).
    """
    # 1. Primeiro tenta achar direto pela chave do item/core
    if search_id in SKILL_DB:
        return SKILL_DB[search_id]
    
    # 2. Se for um ID interno equipado no corpo do jogador, varre o sistema
    for core_id, data in SKILL_DB.items():
        base_sk = data.get("skill", {})
        if base_sk.get("id") == search_id:
            return data
            
    return None
