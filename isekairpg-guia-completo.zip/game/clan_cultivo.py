# game/clan_cultivo.py
"""
⚔️ CULTIVO EM BATALHA (25/09/2026 — pedido do dev)

O antigo Cultivo de Aura (XP por minuto offline, `claim_all_rewards`) ficou
sem botão no site. Ele volta DENTRO do clã: o jogador deixa os personagens
da conta — o que ele pilota e os do armário, que já são membros do clã —
batalhando no andar onde o clã está. Enquanto ele não está, eles ganham XP.

REGRAS DO DEV
-------------
- XP a cada **5 minutos** (antes era a cada 1): a mesma taxa por bloco que
  o cultivo antigo dava por minuto — 1 a 10 conforme o andar do personagem.
- **Pode morrer.** Quem morre vai pro estado de morte da Torre (a mesma
  tela do Explorar/Torre, com reviver pelo portal ou pagando ouro). Não é
  morte permanente: é a morte da Torre.

COMO O RISCO É MEDIDO
---------------------
Não é número inventado: é o mesmo perfil do AFK do clã (`clan_afk.
montar_perfil`), que DUELA de verdade o personagem contra os monstros dos
5 andares a partir do andar do clã (o chefe pesa menos, porque aparece
menos). `chance_morte` é a fatia ponderada desses duelos que ele perde.
Uma luta por hora, no máximo 4 por sessão (o mesmo TETO_ENCONTROS do AFK):
quem vence tudo no andar é "eterno"; quem perde pro chefe corre risco.
A chance aparece na tela ANTES de mandar — número escondido vira injustiça.

Puro: sem banco. Quem lê e grava é a rota (`webapp/api.py`).
"""
from __future__ import annotations

import random

BLOCO_SEG = 5 * 60                 # XP a cada 5 minutos (era a cada 1)
TETO_BLOCOS = 24 * 12              # 24h, o mesmo teto do cultivo antigo
BLOCOS_POR_ENCONTRO = 12           # uma luta por hora
TETO_ENCONTROS = 4                 # o mesmo teto de perigo por sessão do AFK


def xp_por_bloco(andar_do_personagem: int) -> int:
    """A taxa que o cultivo antigo dava POR MINUTO, agora por 5 minutos."""
    return max(1, min(10, int(andar_do_personagem or 1) // 10))


def blocos_passados(ultimo_tick: int, agora: int) -> tuple[int, int]:
    """(blocos a creditar, novo último tick). O resto que não fecha um
    bloco fica pra próxima; o que passa do teto de 24h não vira nada."""
    ultimo = int(ultimo_tick or agora)
    blocos = max(0, (int(agora) - ultimo) // BLOCO_SEG)
    if blocos > TETO_BLOCOS:
        return TETO_BLOCOS, int(agora) - (int(agora) - ultimo) % BLOCO_SEG
    return blocos, ultimo + blocos * BLOCO_SEG


def risco_da_sessao(chance_morte_pct: float, encontros: int = TETO_ENCONTROS) -> float:
    """Chance de morrer numa sessão cheia (4 lutas), de 0 a 1."""
    c = max(0.0, min(1.0, float(chance_morte_pct) / 100.0))
    return 1.0 - (1.0 - c) ** int(encontros)


def simular(blocos: int, chance_morte_pct: float, rng: random.Random) -> dict:
    """Roda a sessão. Morreu na luta N: só os blocos ATÉ ela rendem XP."""
    blocos = max(0, min(int(blocos), TETO_BLOCOS))
    encontros = min(TETO_ENCONTROS, blocos // BLOCOS_POR_ENCONTRO)
    c = max(0.0, min(1.0, float(chance_morte_pct) / 100.0))
    for i in range(1, encontros + 1):
        if rng.random() < c:
            return {"blocos": i * BLOCOS_POR_ENCONTRO, "morreu": True, "lutas": i}
    return {"blocos": blocos, "morreu": False, "lutas": encontros}


def morrer(pdata: dict) -> None:
    """O estado de morte da TORRE: a tela da Torre mostra a morte e o
    reviver (portal grátis com espera, ou ouro), como no Explorar."""
    pdata["combat"] = None
    pdata["state"] = "DEAD"
    pdata["hp"] = 0


def pode_batalhar(pdata: dict) -> tuple[bool, str]:
    if not pdata:
        return False, "Esse personagem ainda não nasceu — troque pra ele uma vez primeiro."
    if pdata.get("state") == "DEAD" or int(pdata.get("hp", 1) or 0) <= 0:
        return False, "Morto não luta — reviva na Torre primeiro."
    return True, ""


def ocupado(pdata: dict) -> bool:
    """O personagem ao vivo no meio de uma luta (Torre, Explorar, Onda) não
    cultiva: o relógio espera a luta acabar, pra o AFK não matar ninguém no
    meio de um combate que o jogador está jogando."""
    return bool(pdata.get("combat") or pdata.get("explore_mode") or pdata.get("wave_mode"))



# =============================================================================
# ⚡ XP PELO PODER, GUARDAS E IDLE AUTOMÁTICO (26/09/2026, pedido do dev)
# -----------------------------------------------------------------------------
# "A XP idle vai ser conforme a quantia de guardas batalhando, e se o jogador
# ficar mais de 20 min AFK o personagem entra automaticamente no idle, e
# conforme o poder dele rende tanto de XP."
#   · XP por bloco de 5 min = PODER DE COMBATE ÷ 250 (o poder do bot antigo,
#     `logic.calc_power_level`). Medido: ~5% de um nível por hora em
#     qualquer nível (Nv10 poder ~526 → 24 XP/h de 550; Nv72 ~3.758 →
#     180/h de 3.650; Nv200 ~16.452 → 790/h de 10.050) — com o teto de 24 h,
#     ~1 nível por dia. O teto de nível do andar continua valendo (gain_xp).
#   · +10% por GUARDA do clã batalhando (aldeão na função de guarda), até +100%.
#   · IDLE AUTOMÁTICO: o personagem que você pilota entra sozinho depois de
#     20 min sem ação na Torre/combate. Esse idle NÃO mata — é o AFK passivo
#     (o antigo Cultivo de Aura também não matava). A batalha LIGADA na mão
#     segue com o risco de morte de antes.
# =============================================================================
PODER_POR_XP = 250
BONUS_POR_GUARDA = 0.10
BONUS_GUARDAS_TETO = 1.0
IDLE_AUTO_SEG = 20 * 60


def xp_por_bloco_pelo_poder(poder: int, guardas: int = 0) -> int:
    base = max(1, int(poder) // PODER_POR_XP)
    bonus = min(BONUS_GUARDAS_TETO, BONUS_POR_GUARDA * max(0, int(guardas)))
    return max(1, int(round(base * (1 + bonus))))


def inicio_do_idle_auto(ultima_acao, agora: int):
    """Quando o idle automático começou (ou None se ainda não passou 20 min)."""
    if not ultima_acao:
        return None
    inicio = int(ultima_acao) + IDLE_AUTO_SEG
    return inicio if inicio <= int(agora) else None
