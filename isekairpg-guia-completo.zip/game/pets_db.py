# game/pets_db.py

PETS_DB = {
    # ==========================================
    # ⚪ COMUNS (Status máx: 10 Attr / 100 HP / 1% Eco / Skills Tier 1)
    # ==========================================
    "pet_c_lobo": {"id": "pet_c_lobo", "name": "Lobo Filhote", "rarity": "comum", "archetype": "dps", "bonus_stats": {"atk": 10}, "mechanic": {"type": "dmg_amp", "value": 0.01}, "economy_buff": {"type": "xp", "value": 0.01}, "auto_skill": {"skill_id": "a_stone_1", "cooldown": 3, "power_mult": 0.7}},
    "pet_c_javali": {"id": "pet_c_javali", "name": "Javali Casca-Dura", "rarity": "comum", "archetype": "tank", "bonus_stats": {"hp": 100}, "mechanic": {"type": "dmg_red", "value": 0.01}, "economy_buff": {"type": "gold", "value": 0.01}, "auto_skill": {"skill_id": "a_stone_1", "cooldown": 3, "power_mult": 0.7}},
    "pet_c_fada": {"id": "pet_c_fada", "name": "Fadinha do Bosque", "rarity": "comum", "archetype": "healer", "bonus_stats": {"hp": 50, "def": 5}, "mechanic": {"type": "lifesteal", "value": 0.01}, "economy_buff": {"type": "drop", "value": 0.01}, "auto_skill": {"skill_id": "a_heal_1", "cooldown": 3, "power_mult": 0.7}},
    "pet_c_morcego": {"id": "pet_c_morcego", "name": "Morcego Cego", "rarity": "comum", "archetype": "utility", "bonus_stats": {"spd": 10}, "mechanic": {"type": "eva_amp", "value": 0.01}, "economy_buff": {"type": "craft_comum", "value": 0.01}, "auto_skill": {"skill_id": "a_blood_1", "cooldown": 3, "power_mult": 0.7}},
    "pet_c_wisp": {"id": "pet_c_wisp", "name": "Wisp Arcano", "rarity": "comum", "archetype": "buffer", "bonus_stats": {"atk": 5, "spd": 5}, "mechanic": {"type": "cooldown_red", "value": 0.01}, "economy_buff": {"type": "fusion_chance", "value": 0.01}, "auto_skill": {"skill_id": "a_support_1", "cooldown": 3, "power_mult": 0.7}},
    
    # ... e o resto segue igual
    # ==========================================
    # 🟢 INCOMUNS (Status máx: 20 Attr / 200 HP / 2% Eco / Skills Tier 2)
    # ==========================================
    "pet_u_pantera": {"id": "pet_u_pantera", "name": "Pantera da Noite", "rarity": "incomum", "archetype": "dps", "bonus_stats": {"atk": 20}, "mechanic": {"type": "dmg_amp", "value": 0.02}, "economy_buff": {"type": "xp", "value": 0.02}, "auto_skill": {"skill_id": "a_fatal_2", "cooldown": 3, "power_mult": 0.7}},
    "pet_u_golem_barro": {"id": "pet_u_golem_barro", "name": "Golem de Barro", "rarity": "incomum", "archetype": "tank", "bonus_stats": {"hp": 200}, "mechanic": {"type": "dmg_red", "value": 0.02}, "economy_buff": {"type": "gold", "value": 0.02}, "auto_skill": {"skill_id": "a_stone_2", "cooldown": 3, "power_mult": 0.7}},
    "pet_u_ninfa": {"id": "pet_u_ninfa", "name": "Ninfa das Águas", "rarity": "incomum", "archetype": "healer", "bonus_stats": {"hp": 100, "def": 10}, "mechanic": {"type": "lifesteal", "value": 0.02}, "economy_buff": {"type": "drop", "value": 0.02}, "auto_skill": {"skill_id": "a_heal_2", "cooldown": 3, "power_mult": 0.7}},
    "pet_u_raposa": {"id": "pet_u_raposa", "name": "Raposa dos Ventos", "rarity": "incomum", "archetype": "utility", "bonus_stats": {"spd": 20}, "mechanic": {"type": "eva_amp", "value": 0.02}, "economy_buff": {"type": "craft_incomum", "value": 0.02}, "auto_skill": {"skill_id": "a_wind_2", "cooldown": 3, "power_mult": 0.7}},
    "pet_u_espirito_fogo": {"id": "pet_u_espirito_fogo", "name": "Espírito das Chamas", "rarity": "incomum", "archetype": "buffer", "bonus_stats": {"atk": 10, "spd": 10}, "mechanic": {"type": "cooldown_red", "value": 0.02}, "economy_buff": {"type": "fusion_chance", "value": 0.02}, "auto_skill": {"skill_id": "a_fire_2", "cooldown": 3, "power_mult": 0.7}},

    # ==========================================
    # 🔵 RAROS (Status máx: 35 Attr / 700 HP / 3% Eco / Skills Tier 3)
    # ==========================================
    "pet_r_tigre": {"id": "pet_r_tigre", "name": "Tigre Dentes-de-Sabre", "rarity": "raro", "archetype": "dps", "bonus_stats": {"atk": 35}, "mechanic": {"type": "dmg_amp", "value": 0.03}, "economy_buff": {"type": "xp", "value": 0.03}, "auto_skill": {"skill_id": "a_wind_3", "cooldown": 4, "power_mult": 0.7}},
    "pet_r_golem_pedra": {"id": "pet_r_golem_pedra", "name": "Golem de Pedra", "rarity": "raro", "archetype": "tank", "bonus_stats": {"hp": 700}, "mechanic": {"type": "dmg_red", "value": 0.03}, "economy_buff": {"type": "gold", "value": 0.03}, "auto_skill": {"skill_id": "a_shield_3", "cooldown": 4, "power_mult": 0.7}},
    "pet_r_sirena": {"id": "pet_r_sirena", "name": "Sirena Curandeira", "rarity": "raro", "archetype": "healer", "bonus_stats": {"hp": 350, "def": 17}, "mechanic": {"type": "lifesteal", "value": 0.03}, "economy_buff": {"type": "drop", "value": 0.03}, "auto_skill": {"skill_id": "a_heal_3", "cooldown": 4, "power_mult": 0.7}},
    "pet_r_grifo": {"id": "pet_r_grifo", "name": "Grifo Jovem", "rarity": "raro", "archetype": "utility", "bonus_stats": {"spd": 35}, "mechanic": {"type": "eva_amp", "value": 0.03}, "economy_buff": {"type": "craft_raro", "value": 0.03}, "auto_skill": {"skill_id": "a_thunder_3", "cooldown": 4, "power_mult": 0.7}},
    "pet_r_oraculo": {"id": "pet_r_oraculo", "name": "Olho do Oráculo", "rarity": "raro", "archetype": "buffer", "bonus_stats": {"hp": 350, "spd": 17}, "mechanic": {"type": "cooldown_red", "value": 0.03}, "economy_buff": {"type": "fusion_chance", "value": 0.03}, "auto_skill": {"skill_id": "a_ice_3", "cooldown": 4, "power_mult": 0.7}},
# ==========================================
    # 🟣 ÉPICOS (10 Pets - 2 de cada tipo)
    # ==========================================
    "pet_e_leao_guerra": {"id": "pet_e_leao_guerra", "name": "Leão de Guerra", "rarity": "epico", "archetype": "dps", "bonus_stats": {"atk": 70}, "mechanic": {"type": "dmg_amp", "value": 0.04}, "economy_buff": {"type": "xp", "value": 0.04}, "auto_skill": {"skill_id": "a_fire_4", "cooldown": 4, "power_mult": 0.7}},
    "pet_e_urso_coruja": {"id": "pet_e_urso_coruja", "name": "Urso-Coruja", "rarity": "epico", "archetype": "dps", "bonus_stats": {"atk": 70}, "mechanic": {"type": "dmg_amp", "value": 0.04}, "economy_buff": {"type": "craft_epico", "value": 0.04}, "auto_skill": {"skill_id": "a_fury_4", "cooldown": 4, "power_mult": 0.7}},
    "pet_e_tartaruga": {"id": "pet_e_tartaruga", "name": "Tartaruga de Cristal", "rarity": "epico", "archetype": "tank", "bonus_stats": {"hp": 1400}, "mechanic": {"type": "dmg_red", "value": 0.04}, "economy_buff": {"type": "gold", "value": 0.04}, "auto_skill": {"skill_id": "a_shield_4", "cooldown": 4, "power_mult": 0.7}},
    "pet_e_rinoceronte": {"id": "pet_e_rinoceronte", "name": "Rinoceronte Blindado", "rarity": "epico", "archetype": "tank", "bonus_stats": {"hp": 700, "def": 35}, "mechanic": {"type": "dmg_red", "value": 0.04}, "economy_buff": {"type": "fusion_chance", "value": 0.04}, "auto_skill": {"skill_id": "a_stone_4", "cooldown": 4, "power_mult": 0.7}},
    "pet_e_unicornio": {"id": "pet_e_unicornio", "name": "Unicórnio Sagrado", "rarity": "epico", "archetype": "healer", "bonus_stats": {"hp": 700, "spd": 35}, "mechanic": {"type": "lifesteal", "value": 0.04}, "economy_buff": {"type": "drop", "value": 0.04}, "auto_skill": {"skill_id": "a_heal_4", "cooldown": 4, "power_mult": 0.7}},
    "pet_e_treant": {"id": "pet_e_treant", "name": "Treant Ancião", "rarity": "epico", "archetype": "healer", "bonus_stats": {"hp": 1400}, "mechanic": {"type": "lifesteal", "value": 0.04}, "economy_buff": {"type": "craft_epico", "value": 0.04}, "auto_skill": {"skill_id": "a_heal_4", "cooldown": 4, "power_mult": 0.7}},
    "pet_e_corvo": {"id": "pet_e_corvo", "name": "Corvo de Odin", "rarity": "epico", "archetype": "utility", "bonus_stats": {"spd": 70}, "mechanic": {"type": "eva_amp", "value": 0.04}, "economy_buff": {"type": "craft_epico", "value": 0.04}, "auto_skill": {"skill_id": "a_shadow_4", "cooldown": 4, "power_mult": 0.7}},
    "pet_e_falcao": {"id": "pet_e_falcao", "name": "Falcão dos Ventos", "rarity": "epico", "archetype": "utility", "bonus_stats": {"spd": 50, "atk": 20}, "mechanic": {"type": "eva_amp", "value": 0.04}, "economy_buff": {"type": "xp", "value": 0.04}, "auto_skill": {"skill_id": "a_wind_4", "cooldown": 4, "power_mult": 0.7}},
    "pet_e_fada_rainha": {"id": "pet_e_fada_rainha", "name": "Fada Rainha", "rarity": "epico", "archetype": "buffer", "bonus_stats": {"hp": 700, "atk": 35}, "mechanic": {"type": "cooldown_red", "value": 0.04}, "economy_buff": {"type": "fusion_chance", "value": 0.04}, "auto_skill": {"skill_id": "a_balance_4", "cooldown": 4, "power_mult": 0.7}},
    "pet_e_sapo": {"id": "pet_e_sapo", "name": "Sapo Místico", "rarity": "epico", "archetype": "buffer", "bonus_stats": {"hp": 700, "def": 35}, "mechanic": {"type": "cooldown_red", "value": 0.04}, "economy_buff": {"type": "gold", "value": 0.04}, "auto_skill": {"skill_id": "a_ice_4", "cooldown": 4, "power_mult": 0.7}},

    # ==========================================
    # ⭐ LENDÁRIOS (25 Pets - 5 Famílias Temáticas)
    # ==========================================
    # 🐉 FAMÍLIA 1: OS DRAGÕES (Foco em DPS Extremo e Destruição)
    "pet_l_dragao_fogo": {"id": "pet_l_dragao_fogo", "name": "Dragão do Inferno", "rarity": "lendario", "archetype": "dps", "bonus_stats": {"atk": 150}, "mechanic": {"type": "dmg_amp", "value": 0.05}, "economy_buff": {"type": "craft_lendario", "value": 0.05}, "auto_skill": {"skill_id": "a_fire_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_dragao_gelo": {"id": "pet_l_dragao_gelo", "name": "Dragão de Gelo Ancestral", "rarity": "lendario", "archetype": "dps", "bonus_stats": {"atk": 100, "crit": 50}, "mechanic": {"type": "dmg_amp", "value": 0.05}, "economy_buff": {"type": "xp", "value": 0.05}, "auto_skill": {"skill_id": "a_ice_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_dragao_trovao": {"id": "pet_l_dragao_trovao", "name": "Dragão da Tormenta", "rarity": "lendario", "archetype": "dps", "bonus_stats": {"atk": 100, "spd": 50}, "mechanic": {"type": "dmg_amp", "value": 0.05}, "economy_buff": {"type": "drop", "value": 0.05}, "auto_skill": {"skill_id": "a_thunder_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_dragao_veneno": {"id": "pet_l_dragao_veneno", "name": "Dragão Pestilento", "rarity": "lendario", "archetype": "dps", "bonus_stats": {"atk": 100, "hp": 1000}, "mechanic": {"type": "dmg_amp", "value": 0.05}, "economy_buff": {"type": "gold", "value": 0.05}, "auto_skill": {"skill_id": "a_venom_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_dragao_rei": {"id": "pet_l_dragao_rei", "name": "Rei Dragão Bahamut", "rarity": "lendario", "archetype": "dps", "bonus_stats": {"atk": 150}, "mechanic": {"type": "dmg_amp", "value": 0.05}, "economy_buff": {"type": "craft_lendario", "value": 0.05}, "auto_skill": {"skill_id": "a_fire_5", "cooldown": 5, "power_mult": 0.7}},

    # 🏰 FAMÍLIA 2: OS TITÃS (Foco em Tank e Escudos)
    "pet_l_tita_ferro": {"id": "pet_l_tita_ferro", "name": "Titã de Ferro Fundido", "rarity": "lendario", "archetype": "tank", "bonus_stats": {"hp": 1500, "def": 75}, "mechanic": {"type": "dmg_red", "value": 0.05}, "economy_buff": {"type": "fusion_chance", "value": 0.05}, "auto_skill": {"skill_id": "a_shield_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_tita_magma": {"id": "pet_l_tita_magma", "name": "Titã de Magma", "rarity": "lendario", "archetype": "tank", "bonus_stats": {"hp": 1500, "atk": 75}, "mechanic": {"type": "dmg_red", "value": 0.05}, "economy_buff": {"type": "craft_lendario", "value": 0.05}, "auto_skill": {"skill_id": "a_fire_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_tita_gelo": {"id": "pet_l_tita_gelo", "name": "Titã da Geada", "rarity": "lendario", "archetype": "tank", "bonus_stats": {"hp": 3000}, "mechanic": {"type": "dmg_red", "value": 0.05}, "economy_buff": {"type": "xp", "value": 0.05}, "auto_skill": {"skill_id": "a_shield_5", "cooldown": 5, "power_mult": 0.5}},
    "pet_l_tita_cristal": {"id": "pet_l_tita_cristal", "name": "Titã de Cristal Brilhante", "rarity": "lendario", "archetype": "tank", "bonus_stats": {"hp": 1500, "def": 75}, "mechanic": {"type": "dmg_red", "value": 0.05}, "economy_buff": {"type": "drop", "value": 0.05}, "auto_skill": {"skill_id": "a_stone_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_tita_colossal": {"id": "pet_l_tita_colossal", "name": "Behemoth Colossal", "rarity": "lendario", "archetype": "tank", "bonus_stats": {"hp": 3000}, "mechanic": {"type": "dmg_red", "value": 0.05}, "economy_buff": {"type": "gold", "value": 0.05}, "auto_skill": {"skill_id": "a_thorns_5", "cooldown": 5, "power_mult": 0.7}},

    # 🧚 FAMÍLIA 3: A CORTE DAS FADAS (Foco em Velocidade, Esquiva e Turnos)
    "pet_l_fada_vento": {"id": "pet_l_fada_vento", "name": "Sylph do Vento", "rarity": "lendario", "archetype": "utility", "bonus_stats": {"spd": 150}, "mechanic": {"type": "eva_amp", "value": 0.05}, "economy_buff": {"type": "craft_lendario", "value": 0.05}, "auto_skill": {"skill_id": "a_wind_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_fada_lua": {"id": "pet_l_fada_lua", "name": "Fada do Luar", "rarity": "lendario", "archetype": "utility", "bonus_stats": {"spd": 100, "hp": 1000}, "mechanic": {"type": "eva_amp", "value": 0.05}, "economy_buff": {"type": "fusion_chance", "value": 0.05}, "auto_skill": {"skill_id": "a_shadow_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_fada_sol": {"id": "pet_l_fada_sol", "name": "Fada Solar", "rarity": "lendario", "archetype": "utility", "bonus_stats": {"spd": 150, "atk": 100}, "mechanic": {"type": "eva_amp", "value": 0.05}, "economy_buff": {"type": "xp", "value": 0.05}, "auto_skill": {"skill_id": "a_fire_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_fada_astral": {"id": "pet_l_fada_astral", "name": "Fada das Estrelas", "rarity": "lendario", "archetype": "utility", "bonus_stats": {"spd": 130, "crit": 20}, "mechanic": {"type": "eva_amp", "value": 0.05}, "economy_buff": {"type": "drop", "value": 0.05}, "auto_skill": {"skill_id": "a_balance_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_titania": {"id": "pet_l_titania", "name": "Rainha Titânia", "rarity": "lendario", "archetype": "utility", "bonus_stats": {"spd": 200}, "mechanic": {"type": "eva_amp", "value": 0.05}, "economy_buff": {"type": "craft_lendario", "value": 0.05}, "auto_skill": {"skill_id": "a_wind_5", "cooldown": 5, "power_mult": 0.7}},

    # 🦇 FAMÍLIA 4: LORDES VAMPÍRICOS (Foco em Lifesteal e Cura Constante)
    "pet_l_vampiro_nobre": {"id": "pet_l_vampiro_nobre", "name": "Vampiro Nobre", "rarity": "lendario", "archetype": "healer", "bonus_stats": {"atk": 150, "hp": 1500}, "mechanic": {"type": "lifesteal", "value": 0.05}, "economy_buff": {"type": "xp", "value": 0.05}, "auto_skill": {"skill_id": "a_blood_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_sucubus": {"id": "pet_l_sucubus", "name": "Rainha Succubus", "rarity": "lendario", "archetype": "healer", "bonus_stats": {"hp": 2000, "spd": 50}, "mechanic": {"type": "lifesteal", "value": 0.05}, "economy_buff": {"type": "gold", "value": 0.05}, "auto_skill": {"skill_id": "a_fire_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_gargula": {"id": "pet_l_gargula", "name": "Gárgula de Sangue", "rarity": "lendario", "archetype": "healer", "bonus_stats": {"def": 150, "hp": 2000}, "mechanic": {"type": "lifesteal", "value": 0.05}, "economy_buff": {"type": "drop", "value": 0.05}, "auto_skill": {"skill_id": "a_stone_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_cavaleiro_morte": {"id": "pet_l_cavaleiro_morte", "name": "Cavaleiro da Morte", "rarity": "lendario", "archetype": "healer", "bonus_stats": {"atk": 200, "def": 100}, "mechanic": {"type": "lifesteal", "value": 0.05}, "economy_buff": {"type": "craft_lendario", "value": 0.05}, "auto_skill": {"skill_id": "a_fatal_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_dracula": {"id": "pet_l_dracula", "name": "Lorde Drácula", "rarity": "lendario", "archetype": "healer", "bonus_stats": {"atk": 300, "hp": 3000}, "mechanic": {"type": "lifesteal", "value": 0.05}, "economy_buff": {"type": "fusion_chance", "value": 0.05}, "auto_skill": {"skill_id": "a_blood_5", "cooldown": 5, "power_mult": 0.7}},

    # 👑 FAMÍLIA 5: DIVINDADES / ARCANJOS (Foco em Buffs e Redução de Cooldown)
    "pet_l_anjo_fortuna": {"id": "pet_l_anjo_fortuna", "name": "Anjo da Riqueza", "rarity": "lendario", "archetype": "buffer", "bonus_stats": {"hp": 1500, "def": 50}, "mechanic": {"type": "cooldown_red", "value": 0.05}, "economy_buff": {"type": "gold", "value": 0.10}, "auto_skill": {"skill_id": "a_support_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_anjo_conhecimento": {"id": "pet_l_anjo_conhecimento", "name": "Serafim da Sabedoria", "rarity": "lendario", "archetype": "buffer", "bonus_stats": {"atk": 100, "spd": 80}, "mechanic": {"type": "cooldown_red", "value": 0.05}, "economy_buff": {"type": "xp", "value": 0.10}, "auto_skill": {"skill_id": "a_balance_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_anjo_forja": {"id": "pet_l_anjo_forja", "name": "Arcanjo da Forja", "rarity": "lendario", "archetype": "buffer", "bonus_stats": {"hp": 2000, "atk": 150}, "mechanic": {"type": "cooldown_red", "value": 0.05}, "economy_buff": {"type": "craft_lendario", "value": 0.10}, "auto_skill": {"skill_id": "a_fire_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_anjo_tempo": {"id": "pet_l_anjo_tempo", "name": "Guardião do Tempo", "rarity": "lendario", "archetype": "buffer", "bonus_stats": {"spd": 120, "eva": 10}, "mechanic": {"type": "cooldown_red", "value": 0.05}, "economy_buff": {"type": "drop", "value": 0.10}, "auto_skill": {"skill_id": "a_wind_5", "cooldown": 5, "power_mult": 0.7}},
    "pet_l_arcanjo_supremo": {"id": "pet_l_arcanjo_supremo", "name": "Arcanjo Metatron", "rarity": "lendario", "archetype": "buffer", "bonus_stats": {"atk": 250, "hp": 3000, "spd": 100}, "mechanic": {"type": "cooldown_red", "value": 0.05}, "economy_buff": {"type": "fusion_chance", "value": 0.10}, "auto_skill": {"skill_id": "a_support_5", "cooldown": 5, "power_mult": 0.7}},
}


def get_pet_bonuses(p: dict) -> dict:
    """Soma os bônus de 'mechanic' e 'economy_buff' de TODOS os pets no
    esquadrão (os 5 slots do deck), do mesmo jeito que bonus_stats já soma.

    🔥 Corrigido em 06/07/2026: esses campos existiam no banco de pets e
    apareciam no card (views.py), mas nunca eram somados nem usados em
    lugar nenhum do jogo — eram 100% decorativos. Agora essa função é
    consumida em combate (dmg_amp/dmg_red/eva_amp/cooldown_red/lifesteal)
    e na economia (xp/gold/drop/craft_<raridade>).

    Retorna algo como:
    {"dmg_amp": 0.07, "xp": 0.03, "craft_raro": 0.02, ...}
    """
    totals: dict[str, float] = {}
    deck = (p.get("pets", {}) or {}).get("deck", [None] * 5)

    for pet_id in deck:
        if not pet_id:
            continue
        pet = PETS_DB.get(pet_id)
        if not pet:
            continue

        mech = pet.get("mechanic") or {}
        mtype = mech.get("type")
        if mtype:
            totals[mtype] = totals.get(mtype, 0.0) + float(mech.get("value", 0))

        eco = pet.get("economy_buff") or {}
        etype = eco.get("type")
        if etype:
            totals[etype] = totals.get(etype, 0.0) + float(eco.get("value", 0))

    return totals


# =============================================================================
# 🔀 FUSÃO — funde 5 cópias repetidas da mesma raridade por 20% de chance
# de ganhar um espírito aleatório de raridade superior (08/07/2026)
# =============================================================================
RARITY_ORDER = ["comum", "incomum", "raro", "epico", "lendario"]
FUSION_COST = 5
FUSION_SUCCESS_CHANCE = 0.20


def get_pets_by_rarity(rarity: str) -> list:
    return [pid for pid, data in PETS_DB.items() if data.get("rarity") == rarity]


def get_fusable_pets(p: dict, rarity: str) -> list:
    """Pets daquela raridade que o jogador tem MAIS DE 1 cópia (candidatos
    a fusão, mesmo que ainda não tenha as 5 completas)."""
    owned = p.get("pets", {}).get("owned", {})
    return [pid for pid in get_pets_by_rarity(rarity) if owned.get(pid, 0) > 1]


def contar_pets_por_raridade(owned: dict, rarity: str) -> int:
    """Soma quantas cópias de pets de uma raridade o jogador tem no total
    (somando todos os pets diferentes daquela raridade)."""
    total = 0
    for pid, qtd in owned.items():
        pet = PETS_DB.get(pid)
        if pet and pet.get("rarity") == rarity:
            total += int(qtd)
    return total


def contar_material_disponivel_por_raridade(owned: dict, rarity: str, excluir_pet_id: str | None = None) -> int:
    """🔥 (09/07/2026): soma quantas cópias de pets de uma raridade estão
    DISPONÍVEIS como material — ou seja, excluindo 1 cópia protegida de
    CADA pet diferente que o jogador tem. A primeira cópia de qualquer pet
    é sempre guardada (é a que você usa/coleciona); só a partir da 2ª cópia
    ele vira material aproveitável em Nível/Fusão."""
    total = 0
    for pid, qtd in owned.items():
        if pid == excluir_pet_id:
            continue
        pet = PETS_DB.get(pid)
        if pet and pet.get("rarity") == rarity:
            total += max(0, int(qtd) - 1)
    return total


def fuse_pets_by_rarity(p: dict, rarity: str) -> tuple:
    """🔥 v2 (09/07/2026): funde 5 cópias de QUALQUER pet da mesma raridade
    (antes exigia 5 do MESMO pet). Consome as 5 do estoque daquela raridade
    — começando pelos que o jogador tem mais cópias — e dá 20% de chance de
    um pet aleatório da raridade seguinte.
    Retorna (ok, msg, pet_ganho_id) — o 3º valor serve pra UI mostrar a
    imagem do pet recebido."""
    import random

    owned = p.setdefault("pets", {}).setdefault("owned", {})

    if rarity not in RARITY_ORDER or RARITY_ORDER.index(rarity) >= len(RARITY_ORDER) - 1:
        return False, "❌ Essa já é a raridade máxima — não dá pra fundir pra cima.", None

    total = contar_pets_por_raridade(owned, rarity)
    if total < FUSION_COST:
        return False, f"❌ Você precisa de {FUSION_COST} cópias de espíritos {rarity.upper()} (tem {total}).", None

    # Consome 5 cópias da raridade, priorizando quem tem mais cópias
    # (pra não zerar variedade à toa).
    a_consumir = FUSION_COST
    pets_da_raridade = sorted(
        [(pid, q) for pid, q in owned.items()
         if PETS_DB.get(pid, {}).get("rarity") == rarity and q > 0],
        key=lambda kv: kv[1], reverse=True
    )
    consumidos = []
    for pid, q in pets_da_raridade:
        if a_consumir <= 0:
            break
        tira = min(q, a_consumir)
        owned[pid] -= tira
        if owned[pid] <= 0:
            owned.pop(pid, None)
        a_consumir -= tira
        consumidos.append((pid, tira))

    proxima = RARITY_ORDER[RARITY_ORDER.index(rarity) + 1]
    candidatos = get_pets_by_rarity(proxima)

    if candidatos and random.random() < FUSION_SUCCESS_CHANCE:
        ganho_id = random.choice(candidatos)
        owned[ganho_id] = owned.get(ganho_id, 0) + 1
        nome_ganho = PETS_DB[ganho_id]["name"]
        return True, (
            f"✨ <b>FUSÃO BEM-SUCEDIDA!</b>\n"
            f"Consumiu 5 espíritos {rarity.upper()} e ganhou "
            f"<b>1x {nome_ganho}</b> ({proxima.upper()})!"
        ), ganho_id
    else:
        return False, (
            f"💨 A fusão falhou...\n"
            f"5 espíritos {rarity.upper()} foram consumidos, mas nenhum "
            f"espírito superior surgiu. Tente de novo!"
        ), None


def fuse_pets(p: dict, pet_id: str) -> tuple:
    """Compat: versão antiga (funde pelo pet específico). Mantida pra não
    quebrar chamadas antigas, mas a UI agora usa fuse_pets_by_rarity."""
    import random

    owned = p.setdefault("pets", {}).setdefault("owned", {})
    pet = PETS_DB.get(pet_id)
    if not pet:
        return False, "❌ Espírito inválido."
    # Redireciona pra nova lógica por raridade
    ok, msg, _ganho = fuse_pets_by_rarity(p, pet.get("rarity", "comum"))
    return ok, msg


# =============================================================================
# 🌟 EVOLUÇÃO DE PETS (09/07/2026)
# =============================================================================
# Consome cópias do MESMO pet pra deixá-lo mais forte de verdade (soma um
# multiplicador permanente nos stats dele). Separado da Fusão (que troca
# cópias por um pet ALEATÓRIO de raridade acima) e do Nível (que usa OUTROS
# pets como material) — agora sobra de pet tem 3 destinos diferentes.

EVOLUTION_MAX_TIER = 5  # ⭐ até ⭐⭐⭐⭐⭐
EVOLUTION_BONUS_PER_TIER = 0.15  # +15% nos stats a cada tier
# custo em cópias do MESMO pet pra subir de tier: tier 1→2 custa 2, 2→3
# custa 3, 3→4 custa 4, 4→5 custa 5
EVOLUTION_COST_BY_TIER = {1: 2, 2: 3, 3: 4, 4: 5}


def get_pet_progress(p: dict, pet_id: str) -> dict:
    """Progresso (nível/xp/evolução) de um pet específico que o jogador
    possui. Cria com valores base na primeira vez que é consultado."""
    progresso = p.setdefault("pets", {}).setdefault("progress", {})
    if pet_id not in progresso:
        progresso[pet_id] = {"level": 1, "xp": 0, "evolution": 1}
    return progresso[pet_id]


def get_pet_evolution_multiplier(p: dict, pet_id: str) -> float:
    """Multiplicador de stats vindo só da evolução (1.0 = tier 1, sem bônus)."""
    tier = get_pet_progress(p, pet_id).get("evolution", 1)
    return 1.0 + (tier - 1) * EVOLUTION_BONUS_PER_TIER


# 🔥 (09/07/2026): custo em ouro por tier atual (além das cópias)
EVOLUTION_GOLD_COST_BY_TIER = {1: 200, 2: 500, 3: 1000, 4: 2000}


def evolve_pet(p: dict, pet_id: str) -> tuple:
    """⭐ Evolui um pet, consumindo cópias DELE MESMO do estoque + ouro.
    Retorna (ok, msg)."""
    pet = PETS_DB.get(pet_id)
    if not pet:
        return False, "❌ Espírito inválido."

    progresso = get_pet_progress(p, pet_id)
    tier_atual = int(progresso.get("evolution", 1))

    if tier_atual >= EVOLUTION_MAX_TIER:
        return False, f"❌ {pet['name']} já está na evolução máxima (⭐{EVOLUTION_MAX_TIER})."

    custo_copias = EVOLUTION_COST_BY_TIER.get(tier_atual, 5)
    custo_ouro = EVOLUTION_GOLD_COST_BY_TIER.get(tier_atual, 2000)
    owned = p.setdefault("pets", {}).setdefault("owned", {})
    disponivel = int(owned.get(pet_id, 0))
    gold_atual = int(p.get("gold", 0))

    # 🔥 CORRIGIDO (09/07/2026): a evolução gasta as CÓPIAS EXTRAS, nunca a
    # última que você tem — senão o pet que está equipado/evoluindo some do
    # seu estoque. Se você tem 3, só as 2 além da 1ª contam como material.
    copias_extras = max(0, disponivel - 1)

    # 🔥 checa TUDO antes de consumir qualquer coisa — evita cobrar ouro
    # e depois recusar por falta de cópia (ou vice-versa)
    if copias_extras < custo_copias:
        return False, (
            f"❌ Precisa de {custo_copias} cópia(s) EXTRA de <b>{pet['name']}</b> pra evoluir "
            f"(você tem {disponivel}, e sempre guarda 1 — só sobram {copias_extras} disponíveis)."
        )
    if gold_atual < custo_ouro:
        return False, f"❌ Precisa de {custo_ouro}g pra evoluir (tem {gold_atual}g)."

    owned[pet_id] = disponivel - custo_copias  # nunca fica abaixo de 1
    p["gold"] = gold_atual - custo_ouro

    progresso["evolution"] = tier_atual + 1
    novo_bonus = int((tier_atual) * EVOLUTION_BONUS_PER_TIER * 100)

    return True, (
        f"⭐ <b>{pet['name']} evoluiu!</b>\n"
        f"Evolução {tier_atual} → {tier_atual + 1} (consumiu {custo_copias} cópias + {custo_ouro}g)\n"
        f"Bônus de stats agora: +{novo_bonus}%"
    )


# =============================================================================
# 📈 NÍVEL DE PETS (09/07/2026)
# =============================================================================
# Sobe de nível "alimentando" o pet com OUTROS pets (sacrificados como
# material de XP). Cada nível soma um valor FIXO em cada stat que o pet já
# tem, escalando pela raridade do pet que está subindo de nível (não pela
# raridade do material).

LEVEL_MAX = 100

# ganho fixo por nível, em CADA stat que o pet possui, por raridade do pet
LEVEL_STAT_GAIN_BY_RARITY = {
    "comum": 1,
    "incomum": 2,
    "raro": 4,
    "epico": 7,
    "lendario": 12,
}

# XP que cada pet sacrificado (material) dá, pela raridade DELE
MATERIAL_XP_BY_RARITY = {
    "comum": 10,
    "incomum": 25,
    "raro": 60,
    "epico": 150,
    "lendario": 400,
}

# 🔥 (09/07/2026): custo em ouro pra processar o material, proporcional
# ao XP que ele vai gerar (2 ouro por ponto de XP)
LEVEL_GOLD_PER_XP = 2


def xp_para_proximo_nivel(nivel_atual: int) -> int:
    """Quanto de XP falta pra passar do nível atual pro seguinte. Curva
    progressiva — os primeiros níveis são rápidos, os últimos exigem bem
    mais material (o padrão comum em jogos desse estilo)."""
    return int(50 * (nivel_atual ** 1.5))


def get_pet_level_stat_bonus(pet_id: str, level: int) -> int:
    """Quanto cada stat do pet ganha de bônus fixo, total, pelo nível atual."""
    pet = PETS_DB.get(pet_id)
    if not pet:
        return 0
    ganho_por_nivel = LEVEL_STAT_GAIN_BY_RARITY.get(pet.get("rarity", "comum"), 1)
    return (max(1, int(level)) - 1) * ganho_por_nivel


def level_up_pet(p: dict, pet_id: str, material_pet_ids: list[str]) -> tuple:
    """📈 Sobe o nível de um pet sacrificando outros pets como material.
    `material_pet_ids` é a lista de pet_ids a consumir (1 cópia de cada
    entrada da lista — se quiser sacrificar 3 cópias do mesmo, repita o id
    3x na lista). Retorna (ok, msg)."""
    pet = PETS_DB.get(pet_id)
    if not pet:
        return False, "❌ Espírito inválido."
    if not material_pet_ids:
        return False, "❌ Escolha ao menos 1 espírito pra sacrificar como material."

    owned = p.setdefault("pets", {}).setdefault("owned", {})
    progresso = get_pet_progress(p, pet_id)
    nivel_atual = int(progresso.get("level", 1))

    if nivel_atual >= LEVEL_MAX:
        return False, f"❌ {pet['name']} já está no nível máximo ({LEVEL_MAX})."

    # Confere se o jogador realmente tem todos os materiais ANTES de
    # consumir qualquer coisa (evita sacrificar metade e falhar no meio).
    contagem_pedida: dict[str, int] = {}
    for mid in material_pet_ids:
        contagem_pedida[mid] = contagem_pedida.get(mid, 0) + 1
        if mid == pet_id:
            return False, "❌ Um pet não pode ser material de si mesmo."
        if mid not in PETS_DB:
            return False, f"❌ Espírito de material inválido: {mid}."

    for mid, qtd_pedida in contagem_pedida.items():
        # 🔥 CORRIGIDO (09/07/2026): sempre guarda 1 cópia de CADA pet
        # material — a primeira cópia que você ganha fica protegida (é a
        # que você usa/coleciona). Só a partir da 2ª cópia vira material
        # disponível. Antes, dava pra sacrificar a ÚLTIMA cópia de um pet
        # que você só tinha 1, apagando ele do seu estoque sem querer.
        disponivel_mid = max(0, int(owned.get(mid, 0)) - 1)
        if disponivel_mid < qtd_pedida:
            nome = PETS_DB[mid]["name"]
            return False, (
                f"❌ Você só tem {disponivel_mid} {nome} disponível como material "
                f"(sempre guarda 1 cópia — pediu {qtd_pedida})."
            )

    # 🔥 (09/07/2026): custo em ouro, proporcional ao XP que os materiais
    # vão dar (calcula ANTES de consumir qualquer coisa, pra poder recusar
    # sem sacrificar nada se faltar ouro).
    xp_previsto = sum(
        MATERIAL_XP_BY_RARITY.get(PETS_DB[mid].get("rarity", "comum"), 10) * qtd
        for mid, qtd in contagem_pedida.items()
    )
    custo_ouro = xp_previsto * LEVEL_GOLD_PER_XP
    gold_atual = int(p.get("gold", 0))
    if gold_atual < custo_ouro:
        return False, f"❌ Precisa de {custo_ouro}g pra processar esse material (tem {gold_atual}g)."
    p["gold"] = gold_atual - custo_ouro

    # Consome os materiais e calcula o XP ganho (nunca zera um pet, a
    # validação acima já garantiu que sempre sobra 1 cópia de cada)
    xp_ganho = 0
    for mid, qtd in contagem_pedida.items():
        owned[mid] -= qtd
        xp_por_unidade = MATERIAL_XP_BY_RARITY.get(PETS_DB[mid].get("rarity", "comum"), 10)
        xp_ganho += xp_por_unidade * qtd

    progresso["xp"] = int(progresso.get("xp", 0)) + xp_ganho

    # Sobe quantos níveis o XP permitir, respeitando o teto
    subiu = 0
    while progresso["level"] < LEVEL_MAX and progresso["xp"] >= xp_para_proximo_nivel(progresso["level"]):
        progresso["xp"] -= xp_para_proximo_nivel(progresso["level"])
        progresso["level"] += 1
        subiu += 1

    nivel_final = progresso["level"]
    if subiu > 0:
        msg = (
            f"📈 <b>{pet['name']} ganhou {xp_ganho} XP!</b> (-{custo_ouro}g)\n"
            f"Subiu {subiu} nível(is) → agora é <b>nível {nivel_final}</b>!"
        )
    else:
        faltando = xp_para_proximo_nivel(nivel_final) - progresso["xp"]
        msg = (
            f"📈 {pet['name']} ganhou {xp_ganho} XP. (-{custo_ouro}g)\n"
            f"Ainda nível {nivel_final} (faltam {faltando} XP pro próximo)."
        )
    return True, msg

# =============================================================================
# ⚔️ ARENA DOS PETS — stats de combate derivados (09/07/2026)
# =============================================================================
# Os pets hoje só têm "bonus_stats.atk" (pro bônus passivo no personagem) —
# não têm HP, DEF, SPD, ACC, EVA, CRIT. Pra virarem combatentes de verdade
# na Arena dos Pets, esses stats são DERIVADOS por raridade aqui, e depois
# escalados pela Evolução (%) e Nível (do mesmo jeito que já fizemos pro
# bônus no personagem).

# ⚔️ ATK ENTROU AQUI EM 20/09/2026 — antes ele saía de `bonus_stats.atk`,
# que é OUTRA coisa: o bônus passivo que o pet dá ao personagem. Como esse
# número é quase sempre 10 (é um bônus de equipe, não um stat de luta), o
# resultado era um ataque parado em 10 enquanto a defesa subia de 5 pra 70
# por raridade. Medido no lendário tank: atk 10 contra def 70 — e o dano
# deste jogo é SUBTRATIVO (`max(1, atk - def)`), então a luta virava 1 de
# dano por golpe contra 979 de vida: 979 turnos pra matar.
#
# Agora o atk é derivado por raridade como todo o resto, e dimensionado
# pela vida: `atk ≈ def + hp/10`, ou seja, dois pets da mesma raridade se
# derrubam em ~10 golpes básicos (com skill, em 5 a 7). `bonus_stats.atk`
# continua intacto e continua sendo o bônus no personagem — só parou de
# fazer dois trabalhos ao mesmo tempo.
BASE_PET_COMBAT_STATS = {
    "comum":    {"hp_max": 80,  "atk": 13,  "def": 5,  "spd": 15, "acc": 90, "eva": 5,  "crit": 5},
    "incomum":  {"hp_max": 140, "atk": 24,  "def": 10, "spd": 18, "acc": 92, "eva": 7,  "crit": 7},
    "raro":     {"hp_max": 240, "atk": 42,  "def": 18, "spd": 21, "acc": 94, "eva": 9,  "crit": 10},
    "epico":    {"hp_max": 400, "atk": 70,  "def": 30, "spd": 24, "acc": 96, "eva": 12, "crit": 14},
    "lendario": {"hp_max": 700, "atk": 120, "def": 50, "spd": 28, "acc": 98, "eva": 15, "crit": 20},
}

# arquétipo ajusta o "perfil" do pet — pequenos multiplicadores sobre a
# base por raridade (dps bate mais forte, tank aguenta mais, etc.)
ARCHETYPE_MULT = {
    "dps":     {"atk": 1.15, "crit": 1.2},
    # 20/09: 1,4 nos DOIS (vida e defesa) fazia o tanque durar 19 golpes
    # contra os 8 de um dps — luta de tanque contra tanque não terminava.
    # 1,25 mantém a diferença de papel sem virar esponja.
    "tank":    {"hp_max": 1.25, "def": 1.25},
    "healer":  {"hp_max": 1.1, "acc": 1.05},
    "buffer":  {"spd": 1.1, "acc": 1.1},
    "utility": {"eva": 1.2, "spd": 1.05},
}


def derive_pet_combat_stats(p: dict, pet_id: str) -> dict | None:
    """Monta os stats de combate completos de um pet (pra Arena dos Pets),
    já aplicando Evolução (multiplicador %) e Nível (soma fixa só no ATK,
    igual ao bônus do personagem; nos demais stats aplica só a evolução —
    somar o mesmo fixo em crit/acc/eva, por exemplo, desequilibraria esses
    stats percentuais)."""
    pet = PETS_DB.get(pet_id)
    if not pet:
        return None

    rarity = pet.get("rarity", "comum")
    base = dict(BASE_PET_COMBAT_STATS.get(rarity, BASE_PET_COMBAT_STATS["comum"]))
    arch_mult = ARCHETYPE_MULT.get(pet.get("archetype", ""), {})

    # O atk de COMBATE vem da tabela por raridade. `bonus_stats.atk` é o
    # bônus passivo que o pet dá ao personagem e não tem nada a ver com a
    # força dele na Arena — usar um pelo outro era o que deixava o ataque
    # parelho com a defesa.
    atk_base = int(base.get("atk", 13))
    mult_evo = get_pet_evolution_multiplier(p, pet_id)
    progresso = get_pet_progress(p, pet_id)
    nivel = progresso.get("level", 1)
    bonus_nivel_atk = get_pet_level_stat_bonus(pet_id, nivel)

    stats = {"atk": int(atk_base * mult_evo * arch_mult.get("atk", 1.0)) + bonus_nivel_atk}
    for stat, val in base.items():
        mult = arch_mult.get(stat, 1.0)
        stats[stat] = int(val * mult * mult_evo)

    auto_sk = pet.get("auto_skill", {}) or {}

    return {
        "pet_id": pet_id,
        "name": pet.get("name", "Espírito"),
        "rarity": rarity,
        # 🧭 20/09/2026: o arquétipo passou a viajar junto. É ele que
        # decide QUAIS das 4 opções de batalha o pet leva pra Arena
        # (game/pet_skills.py) — antes só existia como multiplicador
        # escondido nos atributos aqui em cima.
        "archetype": pet.get("archetype", "dps"),
        "evolution": progresso.get("evolution", 1),
        "level": nivel,
        "hp": stats["hp_max"],
        "hp_max": stats["hp_max"],
        "atk": stats["atk"],
        "def": stats["def"],
        "spd": max(1, stats["spd"]),
        "acc": stats["acc"],
        "eva": stats["eva"],
        "crit": stats["crit"],
        "shield": 0,
        "bar": 0.0,
        "cooldown": 0,
        "skill_id": auto_sk.get("skill_id"),
        "skill_cooldown_max": int(auto_sk.get("cooldown", 3)),
        "skill_power_mult": float(auto_sk.get("power_mult", 0.7)),
        "dots": [],
        "stun": 0,
    }


def build_pet_team(p: dict) -> list:
    """Monta o time de 5 pets (o mesmo deck de bônus passivo) já com os
    stats de combate derivados, pronto pra Arena dos Pets. Pula slots
    vazios — se o jogador não completou os 5 slots, luta com menos."""
    deck = p.get("pets", {}).get("deck", [None] * 5)
    time = []
    for pet_id in deck:
        if not pet_id:
            continue
        combatente = derive_pet_combat_stats(p, pet_id)
        if combatente:
            time.append(combatente)
    return time


# =============================================================================
# 🔮 FUSÃO DE ESPÍRITOS (26/09/2026, pedido do dev)
# -----------------------------------------------------------------------------
# 5 espíritos da MESMA raridade (podem ser espécies diferentes) numa tentativa
# com 15% de chance de virar UM espírito sorteado da raridade de cima. Dá
# certo ou errado, os 5 são consumidos. Usa só CÓPIAS EXTRAS — a mesma regra
# da evolução ("sempre guarda 1"): a fusão nunca apaga um espírito que você
# tem, nem o nível/evolução dele, nem um que está no esquadrão. As mais
# repetidas vão primeiro.
# =============================================================================
ORDEM_RARIDADE = ["comum", "incomum", "raro", "epico", "lendario"]
FUSAO_QTD = 5
FUSAO_CHANCE = 0.15


def copias_extras_por_raridade(p: dict) -> dict:
    owned = (p.get("pets") or {}).get("owned") or {}
    saida = {r: 0 for r in ORDEM_RARIDADE}
    for pid, qtd in owned.items():
        pet = PETS_DB.get(pid)
        if pet:
            saida[pet.get("rarity", "comum")] = saida.get(pet.get("rarity", "comum"), 0) + max(0, int(qtd or 0) - 1)
    return saida


def fundir_pets(p: dict, raridade: str, rng=None) -> dict:
    import random as _r
    rng = rng or _r.Random()
    if raridade not in ORDEM_RARIDADE[:-1]:
        return {"ok": False, "erro": "Essa raridade não funde (lendário já é o topo)."}
    owned = p.setdefault("pets", {}).setdefault("owned", {})
    extras = sorted(((pid, int(q or 0) - 1) for pid, q in owned.items()
                     if PETS_DB.get(pid, {}).get("rarity") == raridade and int(q or 0) > 1),
                    key=lambda x: -x[1])
    if sum(q for _, q in extras) < FUSAO_QTD:
        return {"ok": False, "erro": f"Precisa de {FUSAO_QTD} cópias extras de espíritos {raridade} "
                                     f"(sempre fica 1 de cada)."}
    falta, gastos = FUSAO_QTD, {}
    while falta:
        extras.sort(key=lambda x: -x[1])
        pid, q = extras[0]
        owned[pid] = int(owned[pid]) - 1
        extras[0] = (pid, q - 1)
        gastos[pid] = gastos.get(pid, 0) + 1
        falta -= 1
    acima = ORDEM_RARIDADE[ORDEM_RARIDADE.index(raridade) + 1]
    sucesso = rng.random() < FUSAO_CHANCE
    ganho = None
    if sucesso:
        cands = [pid for pid, pet in PETS_DB.items() if pet.get("rarity") == acima]
        ganho = rng.choice(cands)
        owned[ganho] = int(owned.get(ganho, 0) or 0) + 1
    return {"ok": True, "sucesso": sucesso, "raridade": raridade, "raridade_nova": acima,
            "gastos": [{"pet_id": k, "nome": PETS_DB[k].get("name", k), "qtd": v} for k, v in gastos.items()],
            "ganho": None if not ganho else {"pet_id": ganho, "nome": PETS_DB[ganho].get("name", ganho),
                                              "raridade": acima}}
