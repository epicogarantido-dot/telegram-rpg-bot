# game/pet_skills.py
"""
📖 LIVRO DE SKILLS DOS PETS (20/09/2026)

POR QUE EXISTE
--------------
Na Arena dos Pets, o turno do jogador era uma pergunta de sim ou não:
"usa a skill automática ou dá ataque básico?". Cada pet tinha UMA
`auto_skill` herdada do livro de skills de PERSONAGEM (`game/skills.py`),
com `power_mult` de 0,7 pra não ficar forte demais. Resultado: cinco pets
diferentes no esquadrão jogavam praticamente igual, e o arquétipo (tank,
dps, healer, buffer, utility) só existia como multiplicador escondido nos
atributos.

Agora cada pet leva **4 opções pra batalha**: o ataque básico, que nunca
recarrega, e **3 skills do arquétipo dele**. O arquétipo decide QUAIS
skills, e a raridade decide QUÃO FORTES elas são — o mesmo "Golpe Feroz"
de um pet comum e de um lendário é a mesma decisão tática com o dobro de
número.

POR QUE ESCALAR EM VEZ DE LISTAR
--------------------------------
5 arquétipos × 3 skills × 5 raridades daria 75 definições escritas à mão,
que é exatamente o tipo de tabela que se desatualiza em pedaços. Aqui são
15 skills e uma escala por raridade. Quem quiser uma skill exclusiva de
lendário acrescenta uma entrada com `raridade_minima` — o motor já lê.

CAMPOS QUE O MOTOR DA ARENA ENTENDE
-----------------------------------
`mult`, `dot_mult`/`dot_turns`/`dot_name`, `stun`, `debuff_def`,
`execute_pct` (já existiam, do combate de personagem) e, novos daqui:
`alvo` ("inimigo", "todos_inimigos", "proprio", "aliados"),
`escudo_pct` (escudo = % da vida máxima), `cura_pct` (cura = % da vida
máxima de quem RECEBE — era % do ATK até 20/09, ver `healer` abaixo),
`roubo_vida_pct`, `buff_atk`/`buff_turnos`, `atb_drain`, `atb_aliados`.
Um campo que o motor não conhece é ignorado em silêncio — por isso o
teste `auditar_pet_skills.py` recusa campo desconhecido: campo que nada
lê é enfeite (armadilha nº 10).
"""

# Quanto a raridade multiplica os NÚMEROS da skill.
#
# Medido antes de fixar: os atributos de pet já escalam MUITO por
# raridade (`BASE_PET_COMBAT_STATS`: 80 de vida no comum contra 700 no
# lendário, quase 9x). Escalar a skill em 2x em cima disso é cobrar duas
# vezes pela mesma raridade — na simulação, o time lendário ganhava 100%
# das partidas e a escolha da skill deixava de existir. Por isso a escala
# aqui é modesta: ela diferencia, não decide.
ESCALA_RARIDADE = {
    "comum": 1.00,
    "incomum": 1.05,
    "raro": 1.12,
    "epico": 1.20,
    "lendario": 1.30,
}

# O que a raridade alta dá de verdade não é número, é RITMO: uma skill
# que volta um turno antes muda como se joga o combate inteiro, e isso o
# jogador sente. Nunca desce abaixo de 2 — recarga 1 faria a skill
# substituir o ataque básico e as 4 opções virariam 3.
ALIVIO_DE_RECARGA = {"epico": 1, "lendario": 1}

# Campos que escalam com a raridade. Os de DURAÇÃO (turnos de atordoar,
# de DoT, de buff) ficam de fora de propósito: dobrar a duração de um
# stun é muito mais forte que dobrar o dano, e é assim que se faz um pet
# lendário que trava o adversário a partida inteira.
CAMPOS_ESCALAVEIS = ("mult", "dot_mult", "escudo_pct", "cura_pct",
                     "roubo_vida_pct", "buff_atk", "atb_drain", "atb_aliados")

ALVOS = ("inimigo", "todos_inimigos", "proprio", "aliados")

# O ataque básico é a quarta opção e é de propósito o único sem recarga:
# é ele que sustenta o turno quando as três skills estão esfriando, e é
# contra ele que o valor das outras é medido.
ATAQUE_BASICO = {
    "id": "pet_basico",
    "nome": "Ataque",
    "icone": "⚔️",
    "descricao": "Sem recarga. Sempre disponível.",
    "recarga": 0,
    "alvo": "inimigo",
    "mult": 1.0,
}

LIVRO = {
    "dps": [
        {"id": "dps_1", "nome": "Golpe Feroz", "icone": "🩸", "recarga": 2,
         "alvo": "inimigo", "mult": 1.7,
         "descricao": "Dano forte em um alvo, recarga curta."},
        {"id": "dps_2", "nome": "Rasgo Profundo", "icone": "🗡️", "recarga": 3,
         "alvo": "inimigo", "mult": 1.3,
         "dot_mult": 0.5, "dot_turns": 3, "dot_name": "Sangramento",
         "descricao": "Dano médio e sangramento por 3 turnos."},
        {"id": "dps_3", "nome": "Bote Final", "icone": "💀", "recarga": 4,
         "alvo": "inimigo", "mult": 2.2, "execute_pct": 0.18,
         "descricao": "Dano alto. Finaliza quem estiver abaixo de 18% de vida."},
    ],
    "tank": [
        {"id": "tank_1", "nome": "Pancada", "icone": "🔨", "recarga": 3,
         "alvo": "inimigo", "mult": 1.2, "stun": 1,
         "descricao": "Dano leve e atordoa por 1 turno."},
        # 20/09: era 45% — num espelho de tanques o escudo absorvia mais
        # que o dano de 4 turnos e a luta NUNCA acabava (medido: 0 de 60
        # lutas terminaram). 25% segura um golpe forte sem virar parede.
        {"id": "tank_2", "nome": "Muralha", "icone": "🛡️", "recarga": 4,
         "alvo": "proprio", "escudo_pct": 0.25,
         "descricao": "Escudo de 25% da própria vida máxima."},
        {"id": "tank_3", "nome": "Quebrar Guarda", "icone": "🪓", "recarga": 3,
         "alvo": "inimigo", "mult": 1.1, "debuff_def": 0.30,
         "descricao": "Derruba 30% da defesa do alvo."},
    ],
    "healer": [
        # 20/09: a cura era % do ATK (2,5× ATK) e o dano da Arena é
        # SUBTRATIVO (atk − def). Resultado medido: num espelho de curandeiros
        # a cura de 3 turnos passava o dano de 3 turnos, e as 60 lutas
        # testadas não terminaram. A cura agora é % da VIDA máxima, que é a
        # mesma régua do dano (~10% da vida por golpe): 15% a cada 3 turnos
        # atrasa a queda sem impedi-la.
        {"id": "healer_1", "nome": "Lamber Feridas", "icone": "💚", "recarga": 3,
         "alvo": "proprio", "cura_pct": 0.15,
         "descricao": "Cura 15% da própria vida máxima."},
        {"id": "healer_2", "nome": "Sopro Vital", "icone": "🌿", "recarga": 5,
         "alvo": "aliados", "cura_pct": 0.08,
         "descricao": "Cura 8% da vida de TODO o esquadrão de uma vez."},
        {"id": "healer_3", "nome": "Toque Amargo", "icone": "🩹", "recarga": 3,
         "alvo": "inimigo", "mult": 1.4, "roubo_vida_pct": 0.45,
         "descricao": "Dano médio e converte 45% dele em cura."},
    ],
    "buffer": [
        {"id": "buffer_1", "nome": "Uivo de Guerra", "icone": "📣", "recarga": 4,
         "alvo": "aliados", "buff_atk": 0.30, "buff_turnos": 3,
         "descricao": "+30% de ataque pro esquadrão por 3 turnos."},
        {"id": "buffer_2", "nome": "Fúria", "icone": "🔥", "recarga": 3,
         "alvo": "proprio", "buff_atk": 0.60, "buff_turnos": 2,
         "descricao": "+60% de ataque só pra si, por 2 turnos."},
        {"id": "buffer_3", "nome": "Ritmo de Caça", "icone": "🎐", "recarga": 4,
         "alvo": "aliados", "atb_aliados": 25.0,
         "descricao": "Adianta o turno de todo o esquadrão."},
    ],
    "utility": [
        {"id": "util_1", "nome": "Teia", "icone": "🕸️", "recarga": 3,
         "alvo": "inimigo", "mult": 0.8, "atb_drain": 35.0,
         "descricao": "Dano fraco e atrasa bastante o turno do alvo."},
        {"id": "util_2", "nome": "Pó Cegante", "icone": "💨", "recarga": 3,
         "alvo": "inimigo", "mult": 0.9, "stun": 1,
         "descricao": "Dano fraco e atordoa por 1 turno."},
        {"id": "util_3", "nome": "Praga", "icone": "☠️", "recarga": 5,
         "alvo": "todos_inimigos", "mult": 0.9,
         "dot_mult": 0.4, "dot_turns": 4, "dot_name": "Praga",
         "descricao": "Atinge TODOS os inimigos e envenena por 4 turnos."},
    ],
}


def skills_do_pet(archetype: str, rarity: str) -> list[dict]:
    """As 4 opções de batalha de um pet: ataque básico + 3 do arquétipo,
    com os números já escalados pela raridade.

    Arquétipo desconhecido cai em `dps` em vez de devolver lista vazia:
    pet sem opção nenhuma travaria o turno do jogador, e um pet mal
    cadastrado não pode parar uma partida.
    """
    escala = ESCALA_RARIDADE.get(str(rarity or "comum").lower(), 1.0)
    base = LIVRO.get(str(archetype or "").lower()) or LIVRO["dps"]

    saida = [dict(ATAQUE_BASICO)]
    for skill in base:
        s = dict(skill)
        for campo in CAMPOS_ESCALAVEIS:
            if campo in s:
                s[campo] = round(float(s[campo]) * escala, 3)
        alivio = ALIVIO_DE_RECARGA.get(str(rarity or "").lower(), 0)
        if alivio and int(s.get("recarga", 0)) > 2:
            s["recarga"] = int(s["recarga"]) - alivio
        s["raridade"] = rarity
        saida.append(s)
    return saida


def skill_por_id(archetype: str, rarity: str, skill_id: str) -> dict | None:
    for s in skills_do_pet(archetype, rarity):
        if s["id"] == skill_id:
            return s
    return None
