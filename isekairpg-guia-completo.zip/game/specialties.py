# game/specialties.py
from __future__ import annotations

SPECIALTIES_DB = {
    # ==========================================
    # 🧙‍♂️ MAGO (Fogo, Gelo, Raio)
    # ==========================================
    "spec_fogo": {
        "name": "Mestre do Fogo",
        "desc": "ATK +50%. Bônus nas skills de Fogo. 20% chance de Dano Duplo.",
        "passives": {"atk": 0.50},
        "triggers": {"double_damage_chance": 20}
    },
    "spec_gelo": {
        "name": "Mestre do Gelo",
        "desc": "ATK +50%. Bônus nas skills de Gelo. 20% chance de Dano Duplo.",
        "passives": {"atk": 0.50},
        "triggers": {"double_damage_chance": 20}
    },
    "spec_raio": {
        "name": "Mestre do Raio",
        "desc": "ATK +50%. Bônus nas skills de Raio. 20% chance de Dano Duplo.",
        "passives": {"atk": 0.50},
        "triggers": {"double_damage_chance": 20}
    },

    # ==========================================
    # 🗡️ ASSASSINO (Sombras, Fatal, Veneno)
    # ==========================================
    "spec_sombras": {
        "name": "Caminhante das Sombras",
        "desc": "Evasão +50%. Ganha bônus de ATK após esquivar.",
        "passives": {"eva": 0.50},
        "triggers": {"dodge_atk_buff_pct": 0.10}
    },
    "spec_fatal": {
        "name": "Lâmina Fatal",
        "desc": "Dano Crítico +50%. Executa inimigos abaixo de 10% de HP. 10% chance de Dano Triplo.",
        "passives": {"crit": 0.50},
        "triggers": {"execute_threshold_pct": 0.10, "triple_damage_chance": 10}
    },
    "spec_veneno": {
        "name": "Mestre dos Venenos",
        "desc": "Velocidade +50%. Todo DoT aumenta 50%. 15% chance de Atordoar.",
        "passives": {"spd": 0.50},
        "triggers": {"venom_stun_chance": 15, "dot_dmg_pct": 0.50}
    },

    # ==========================================
    # 🛡️ TANKER (Espinhos, Pedra, Escudos)
    # ==========================================
    "spec_espinhos": {
        "name": "Guardião de Espinhos",
        "desc": "DEF +50%. Se o ATK inimigo for menor que sua DEF, reflete o dobro do dano!",
        "passives": {"def": 0.50},
        "triggers": {"thorns_def_scaling": True}
    },
    "spec_pedra": {
        "name": "Coração de Pedra",
        "desc": "DEF +50% e HP +30%. 15% chance de Atordoar o inimigo que te atacar.",
        "passives": {"def": 0.50, "hp_max": 0.30},
        "triggers": {"stun_attacker_chance": 15}
    },
    "spec_escudos": {
        "name": "Baluarte",
        "desc": "DEF +50%. Escudos mais fortes e com chance de regenerar.",
        "passives": {"def": 0.50},
        "triggers": {"shield_refresh_chance": 20}
    },

    # ==========================================
    # 🩸 BERSERKER (Fúria, Vitalidade, Sanguinário)
    # ==========================================
    "spec_furia": {
        "name": "Fúria Cega",
        "desc": "ATK +30%. Se HP cair abaixo de 50%, dano dobra. 10% chance de Dano Triplo.",
        "passives": {"atk": 0.30},
        "triggers": {"berserk_threshold_pct": 0.50, "berserk_dmg_mult": 2.0, "triple_damage_chance": 10}
    },
    "spec_vitalidade": {
        "name": "Colosso de Vitalidade",
        "desc": "HP e Regen +50%. 20% chance de ignorar dano. Sobrevive a golpe mortal com 1 HP.",
        "passives": {"hp_max": 0.50, "reg": 0.50},
        "triggers": {"ignore_damage_chance": 20, "immortal_1hp_once": True}
    },
    "spec_sanguinario": {
        "name": "Sanguinário",
        "desc": "ATK +50%. Vampirismo de 25%. 20% chance de curar todo o grupo na Raid.",
        "passives": {"atk": 0.50},
        "triggers": {"lifesteal_pct": 0.25, "lifesteal_double_party_chance": 20}
    },

    # ==========================================
    # 🌿 SUPORTE (Cura, Equilíbrio, Apoio)
    # ==========================================
    "spec_cura": {
        "name": "Milagreiro",
        "desc": "HP Máximo +30%. Cura turbinada e chance de curar em dobro.",
        "passives": {"hp_max": 0.30},
        "triggers": {"auto_revive_once": True, "double_heal_chance": 25, "heal_mult": 2.0}
    },
    "spec_equilibrio": {
        "name": "Mestre do Equilíbrio",
        "desc": "Regen +50%. Chance da Cura gerar um Escudo equivalente.",
        "passives": {"reg": 0.50},
        "triggers": {"heal_creates_shield_chance": 25, "heal_mult": 1.5}
    },
    "spec_apoio": {
        "name": "Aura de Proteção",
        "desc": "Defesa +30%. 20% chance de anular completamente o dano recebido.",
        "passives": {"def": 0.30},
        "triggers": {"ignore_damage_chance": 20}
    },



    # ==========================================
    # ⚔️ GUERREIRO E 🏹 ARQUEIRO
    # ==========================================
    "spec_espada": {
        "name": "Mestre da Espada",
        "desc": "ATK +50% e DEF +20%. 20% chance de Dano Duplo.",
        "passives": {"atk": 0.50, "def": 0.20},
        "triggers": {"double_damage_chance": 20}
    },
    "spec_lanca": {
        "name": "Mestre da Lança",
        "desc": "ATK +50% e DEF +20%. 20% chance de Dano Duplo.",
        "passives": {"atk": 0.50, "def": 0.20},
        "triggers": {"double_damage_chance": 20}
    },
    "spec_luvas": {
        "name": "Pugilista Místico",
        "desc": "ATK +50% e DEF +20%. 20% chance de Dano Duplo.",
        "passives": {"atk": 0.50, "def": 0.20},
        "triggers": {"double_damage_chance": 20}
    },
    "spec_cacador": {
        "name": "Caçador Implacável",
        "desc": "Precisão +50%. 20% de chance de ignorar a Evasão do alvo.",
        "passives": {"acc": 0.50},
        "triggers": {"ignore_evasion_chance": 20}
    },
    "spec_flechas": {
        "name": "Atirador de Elite",
        "desc": "Precisão +50%. 20% de chance de ignorar a Evasão.",
        "passives": {"acc": 0.50},
        "triggers": {"ignore_evasion_chance": 20}
    },
    "spec_vento": {
        "name": "Andarilho do Vento",
        "desc": "Evasão +30% e Velocidade +50%. 20% chance do ataque não consumir seu turno.",
        "passives": {"eva": 0.30, "spd": 0.50},
        "triggers": {"free_turn_chance": 20}
    }
}
