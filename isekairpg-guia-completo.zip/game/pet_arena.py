# game/pet_arena.py
"""
Arena dos Pets (09/07/2026) — time de 5 pets vs time de 5 pets de outro
jogador, igual a Arena de personagens só que com espíritos.

1. O jogador se CADASTRA (`register_in_pet_arena`): tira um snapshot do
   time atual (os 5 pets do deck, já com stats derivados por raridade,
   evolução e nível). Atualiza sozinho depois de 24h.
2. A luta é automática pros pets do OPONENTE (a cópia dele), mas cada um
   dos SEUS pets pausa a luta e pergunta: em qual inimigo atacar, e se
   libera a skill (se estiver pronta) ou ataca normal.
3. Motor ATB generalizado pra N combatentes (versão da arena 1v1, só que
   com 5+5 ao invés de 1+1) — quem enche a barra primeiro age.
4. Pontuação: vitória +0.2, derrota -0.4 (nunca fica negativo), igual a
   arena normal.
"""
import random
import time

VITORIA_PONTOS = 0.2
DERROTA_PONTOS = 0.4
REFRESH_SECONDS = 24 * 60 * 60  # 1 dia
MAX_ROUNDS_SAFETY = 80  # trava de segurança (evita loop infinito)
BAR_TICK = 4.0  # incremento mínimo de barra por "microtick" de avanço


# =============================================================================
# 📸 SNAPSHOT (cadastro + atualização diária)
# =============================================================================

def register_in_pet_arena(p: dict) -> str:
    """Cadastra (ou atualiza na hora) o time de pets do jogador na Arena."""
    from game.pets_db import build_pet_team
    from game.sql_repo import save_pet_arena_snapshot_sync

    uid = int(p.get("user_id") or p.get("telegram_id"))
    time_atual = build_pet_team(p)

    if not time_atual:
        return "❌ Você precisa equipar ao menos 1 espírito no esquadrão antes de entrar na Arena dos Pets."

    save_pet_arena_snapshot_sync(uid, p.get("username", ""), time_atual, int(time.time()))
    return f"✅ Seu esquadrão de {len(time_atual)} espírito(s) foi cadastrado na Arena dos Pets!"


def ensure_pet_arena_daily_refresh(p: dict) -> None:
    """Chame sempre que o jogador abrir o menu: se fizer 24h+ desde a
    última atualização, atualiza sozinho (sem mexer em pontos/vitórias)."""
    from game.pets_db import build_pet_team
    from game.sql_repo import get_pet_arena_snapshot_sync, save_pet_arena_snapshot_sync

    uid = int(p.get("user_id") or p.get("telegram_id"))
    snap = get_pet_arena_snapshot_sync(uid)
    if not snap:
        return

    agora = int(time.time())
    if agora - int(snap.get("updated_at", 0)) >= REFRESH_SECONDS:
        time_atual = build_pet_team(p)
        if time_atual:
            save_pet_arena_snapshot_sync(uid, p.get("username", ""), time_atual, agora)


# =============================================================================
# ⚔️ COMBATE
# =============================================================================

def start_pet_arena_combat(p: dict, opponent_telegram_id: int) -> dict:
    """Prepara p['pet_arena_combat'] com os dois times. Retorna {"ok": True}
    ou {"erro": msg}."""
    import copy
    import json as _json
    from game.pets_db import build_pet_team
    from game.sql_repo import get_pet_arena_snapshot_sync

    uid = int(p.get("user_id") or p.get("telegram_id"))
    meu_snapshot = get_pet_arena_snapshot_sync(uid)
    if not meu_snapshot:
        return {"erro": "❌ Você precisa se cadastrar na Arena dos Pets antes de lutar."}

    oponente_snap = get_pet_arena_snapshot_sync(int(opponent_telegram_id))
    if not oponente_snap:
        return {"erro": "❌ Esse oponente não está mais cadastrado na Arena dos Pets."}

    # Time do jogador: pega AO VIVO (reflete evolução/nível atuais), não o
    # snapshot salvo — assim o jogador luta com o time de verdade de agora.
    player_team = build_pet_team(p)
    if not player_team:
        return {"erro": "❌ Seu esquadrão está vazio. Equipe ao menos 1 espírito."}

    team_raw = oponente_snap.get("team_json") or "[]"
    enemy_team_base = team_raw if isinstance(team_raw, list) else _json.loads(team_raw)
    enemy_team = copy.deepcopy(enemy_team_base)
    # zera campos de estado de batalha (o snapshot foi salvo já "cheio")
    for e in enemy_team:
        e["hp"] = e["hp_max"]
        e["bar"] = 0.0
        e["cooldown"] = 0
        e["shield"] = 0
        e["dots"] = []
        e["stun"] = 0

    for e in enemy_team:
        preparar_pet(e)
    for pl in player_team:
        pl["bar"] = 0.0
        preparar_pet(pl)

    p["pet_arena_combat"] = {
        "opponent_id": int(opponent_telegram_id),
        "opponent_name": oponente_snap.get("username") or "Adestrador Rival",
        "player_team": player_team,
        "enemy_team": enemy_team,
        "logs": [f"⚔️ Seu esquadrão desafia o time de {oponente_snap.get('username') or 'um rival'} na Arena dos Pets!"],
        "acting_idx": None,
        # 🥊 quem está EM CAMPO de cada lado (índice no time). O resto é banco.
        "player_active": None,
        "enemy_active": None,
        "finalizado": None,
        "rounds": 0,
    }

    _advance_until_action_needed(p["pet_arena_combat"])
    return {"ok": True}


def _pets_vivos(time_: list) -> list:
    return [c for c in time_ if int(c.get("hp", 0)) > 0]


def _tick_dots(entity: dict, logs: list) -> None:
    dots = entity.get("dots") or []
    novos = []
    for dot in dots:
        turns = int(dot.get("turns", 0))
        if turns <= 0:
            continue
        dmg = max(0, int(dot.get("dmg", 0)))
        entity["hp"] = max(0, entity["hp"] - dmg)
        if dmg:
            logs.append(f"☠️ {entity['name']} sofreu {dmg} de {dot.get('name', 'veneno')}.")
        turns -= 1
        if turns > 0:
            dot["turns"] = turns
            novos.append(dot)
    entity["dots"] = novos


def preparar_pet(entidade: dict) -> dict:
    """Garante os campos de batalha de um pet — inclusive os que vieram de
    snapshot antigo, salvo antes das skills existirem.

    O snapshot da Arena é JSON gravado no banco: times cadastrados semanas
    atrás não têm `archetype` nem `cooldowns`. Sem este remendo, o time do
    adversário ficaria sem skill nenhuma e a luta viraria dois lados dando
    ataque básico.
    """
    entidade.setdefault("dots", [])
    entidade.setdefault("buffs", [])
    entidade.setdefault("cooldowns", {})
    entidade.setdefault("shield", 0)
    entidade.setdefault("stun", 0)
    if not entidade.get("archetype"):
        from game.pets_db import PETS_DB
        base = PETS_DB.get(entidade.get("pet_id"), {})
        entidade["archetype"] = base.get("archetype", "dps")
        entidade.setdefault("rarity", base.get("rarity", "comum"))
    return entidade


def opcoes_de_batalha(entidade: dict) -> list[dict]:
    """As 4 opções do pet, já com a recarga restante de cada uma.

    A recarga é POR SKILL (`cooldowns[id]`), não mais uma trava única do
    pet. Com uma trava só, ter três skills não mudaria nada: usar
    qualquer uma travaria as outras, e a escolha voltaria a ser "skill ou
    básico".
    """
    from game.pet_skills import skills_do_pet
    preparar_pet(entidade)
    cds = entidade.get("cooldowns") or {}
    saida = []
    for skill in skills_do_pet(entidade.get("archetype"), entidade.get("rarity")):
        s = dict(skill)
        s["recarga_restante"] = int(cds.get(skill["id"], 0))
        s["pronta"] = s["recarga_restante"] <= 0
        saida.append(s)
    return saida


def _skill_escolhida(entidade: dict, skill_id: str | None, usar_skill: bool | None):
    """Traduz a escolha do jogador (ou da IA) numa skill pronta.

    `usar_skill` (o booleano antigo) continua funcionando: o bot e
    qualquer chamada velha caem na primeira skill pronta em vez de
    quebrar. Quem manda `skill_id` escolhe de verdade.
    """
    opcoes = opcoes_de_batalha(entidade)
    if skill_id:
        for s in opcoes:
            if s["id"] == skill_id:
                return s if s["pronta"] else None
        return None
    if usar_skill:
        prontas = [s for s in opcoes[1:] if s["pronta"]]
        if prontas:
            return prontas[0]
        return None
    return opcoes[0]   # ataque básico


# 🏟️ A ARENA SE FECHA (20/09/2026). Rede de segurança pra luta que não
# termina: a partir da ação `RODADA_FECHA`, cada nova rodada tira 10% da
# força de cura e escudo e soma 10% no dano. Os números das skills já foram
# acertados pra não travar; isto existe pra que NENHUMA combinação futura —
# pet novo, skill nova, raridade nova — consiga prender o jogador clicando
# pra sempre. Antes medido: espelho de curandeiros, 60 de 60 lutas sem fim.
RODADA_FECHA = 40


def _fechamento(entidade: dict) -> int:
    return max(0, int(entidade.get("_rodada", 0)) - RODADA_FECHA)


def _fator_de_cura(entidade: dict) -> float:
    return max(0.0, 1.0 - 0.10 * _fechamento(entidade))


def _atk_com_buff(entidade: dict) -> int:
    """ATK depois dos buffs ativos. Multiplicativo e somado entre si: dois
    buffs de +30% dão +60%, não +69% — a conta que o jogador consegue
    fazer de cabeça durante a luta."""
    bonus = sum(float(b.get("atk", 0)) for b in (entidade.get("buffs") or []))
    return max(1, int(entidade.get("atk", 1) * (1.0 + bonus)))


def _tick_turno(entidade: dict, logs: list) -> None:
    """Começo do turno de um pet: esfria as skills e envelhece os buffs."""
    cds = entidade.get("cooldowns") or {}
    entidade["cooldowns"] = {k: v - 1 for k, v in cds.items() if v - 1 > 0}

    vivos = []
    for b in (entidade.get("buffs") or []):
        b["turnos"] = int(b.get("turnos", 0)) - 1
        if b["turnos"] > 0:
            vivos.append(b)
        else:
            logs.append(f"⌛ O efeito em {entidade['name']} passou.")
    entidade["buffs"] = vivos


def _dano_em(atacante: dict, defensor: dict, skill: dict, logs: list) -> int:
    """Uma batida: acerto, dano, escudo, DoT, atordoar, quebra de defesa e
    execução. Reaproveita os primitivos do combate de personagem."""
    from game.logic import calc_final_damage, check_hit_and_evasion, calc_thorns_and_counters

    t_vazio = {}
    acertou, log_hit, _ = check_hit_and_evasion(
        atacante["acc"], defensor["eva"], t_vazio, t_vazio, atacante["name"], defensor["name"]
    )
    if log_hit:
        logs.append(log_hit.strip())
    if not acertou:
        return 0

    mult = float(skill.get("mult", 1.0)) * (1.0 + 0.10 * _fechamento(atacante))
    atk_efetivo = int(_atk_com_buff(atacante) * mult)
    dano, log_dmg = calc_final_damage(
        atk_efetivo, defensor["def"], atacante["crit"], t_vazio, t_vazio,
        defensor["hp"], defensor["hp_max"]
    )
    logs.extend(x.strip() for x in log_dmg if x.strip())

    if defensor.get("shield", 0) > 0:
        if defensor["shield"] >= dano:
            defensor["shield"] -= dano
            logs.append(f"🛡️ O escudo de {defensor['name']} absorveu {dano} de dano!")
            dano = 0
        else:
            dano -= defensor["shield"]
            logs.append(f"🛡️ O escudo de {defensor['name']} quebrou!")
            defensor["shield"] = 0

    defensor["hp"] = max(0, defensor["hp"] - dano)
    logs.append(f"💢 {atacante['name']} usou {skill.get('nome', 'ataque')} e causou "
                f"{dano} de dano em {defensor['name']}! ({defensor['hp']}/{defensor['hp_max']} HP)")

    if float(skill.get("dot_mult", 0)) > 0 and int(skill.get("dot_turns", 0)) > 0:
        dmg_dot = max(1, int(_atk_com_buff(atacante) * float(skill["dot_mult"])))
        defensor.setdefault("dots", []).append({
            "name": skill.get("dot_name", "DoT"), "dmg": dmg_dot,
            "turns": int(skill["dot_turns"])})
        logs.append(f"☠️ {defensor['name']} foi afetado por {skill.get('dot_name', 'um veneno')}!")

    if int(skill.get("stun", 0)) > 0:
        defensor["stun"] = defensor.get("stun", 0) + int(skill["stun"])
        logs.append(f"💫 {defensor['name']} foi atordoado!")

    if float(skill.get("debuff_def", 0)) > 0:
        defensor["def"] = max(0, int(defensor["def"] * (1.0 - float(skill["debuff_def"]))))
        logs.append(f"🔻 A defesa de {defensor['name']} foi reduzida!")

    if float(skill.get("atb_drain", 0)) > 0 and defensor["hp"] > 0:
        defensor["bar"] = max(0.0, float(defensor.get("bar", 0)) - float(skill["atb_drain"]))
        logs.append(f"⏳ O turno de {defensor['name']} foi atrasado!")

    execute_pct = float(skill.get("execute_pct", 0))
    if execute_pct and defensor["hp"] > 0 and (defensor["hp"] / defensor["hp_max"]) <= execute_pct:
        defensor["hp"] = 0
        logs.append(f"⚡ EXECUÇÃO! {defensor['name']} foi finalizado!")

    if dano > 0:
        rebatido, log_thorns, _ = calc_thorns_and_counters(dano, t_vazio, defensor["def"], atacante["atk"])
        if rebatido:
            atacante["hp"] = max(0, atacante["hp"] - rebatido)
            logs.extend(x.strip() for x in log_thorns if x.strip())

    return dano


def _apply_pet_action(atacante: dict, defensor: dict | None, skill: dict,
                      aliados: list, inimigos: list, logs: list) -> None:
    """Executa a ação escolhida. O alvo sai do PRÓPRIO campo `alvo` da
    skill — por isso cura, escudo e buff não precisam de alvo escolhido na
    tela: só ataque tem alvo."""
    preparar_pet(atacante)
    # A rodada da luta viaja nos combatentes (todos do time), porque esta
    # função não recebe o estado — e é por aqui que TODA ação passa.
    rodada = max([int(x.get("_rodada", 0)) for x in (aliados or []) + (inimigos or [])] + [0]) + 1
    for x in (aliados or []) + (inimigos or []):
        x["_rodada"] = rodada
    alvo = skill.get("alvo", "inimigo")

    if skill.get("recarga"):
        atacante.setdefault("cooldowns", {})[skill["id"]] = int(skill["recarga"])

    if alvo == "proprio":
        if float(skill.get("escudo_pct", 0)) > 0:
            escudo = max(1, int(atacante["hp_max"] * float(skill["escudo_pct"])
                                * _fator_de_cura(atacante)))
            atacante["shield"] = atacante.get("shield", 0) + escudo
            logs.append(f"🛡️ {atacante['name']} usou {skill['nome']} e ganhou {escudo} de escudo!")
        if float(skill.get("cura_pct", 0)) > 0:
            cura = max(1, int(atacante["hp_max"] * float(skill["cura_pct"])
                              * _fator_de_cura(atacante)))
            antes = atacante["hp"]
            atacante["hp"] = min(atacante["hp_max"], atacante["hp"] + cura)
            logs.append(f"💚 {atacante['name']} usou {skill['nome']} e recuperou "
                        f"{atacante['hp'] - antes} HP!")
        if float(skill.get("buff_atk", 0)) > 0:
            atacante.setdefault("buffs", []).append(
                {"atk": float(skill["buff_atk"]), "turnos": int(skill.get("buff_turnos", 2)) + 1})
            logs.append(f"🔥 {atacante['name']} usou {skill['nome']}: "
                        f"+{round(float(skill['buff_atk']) * 100)}% de ataque!")
        return

    if alvo == "aliados":
        vivos = _pets_vivos(aliados)
        if float(skill.get("cura_pct", 0)) > 0:
            for a in vivos:
                a["hp"] = min(a["hp_max"], a["hp"] + max(1, int(
                    a["hp_max"] * float(skill["cura_pct"]) * _fator_de_cura(atacante))))
            logs.append(f"🌿 {atacante['name']} usou {skill['nome']}: "
                        f"{round(float(skill['cura_pct']) * 100)}% de vida em "
                        f"{len(vivos)} espírito(s)!")
        if float(skill.get("buff_atk", 0)) > 0:
            for a in vivos:
                a.setdefault("buffs", []).append(
                    {"atk": float(skill["buff_atk"]), "turnos": int(skill.get("buff_turnos", 2)) + 1})
            logs.append(f"📣 {atacante['name']} usou {skill['nome']}: "
                        f"+{round(float(skill['buff_atk']) * 100)}% de ataque no esquadrão!")
        if float(skill.get("atb_aliados", 0)) > 0:
            for a in vivos:
                if a is not atacante:
                    a["bar"] = min(100.0, float(a.get("bar", 0)) + float(skill["atb_aliados"]))
            logs.append(f"🎐 {atacante['name']} usou {skill['nome']}: o esquadrão adiantou o turno!")
        return

    if alvo == "todos_inimigos":
        vivos = _pets_vivos(inimigos)
        if not vivos:
            return
        logs.append(f"☠️ {atacante['name']} usou {skill['nome']} em {len(vivos)} inimigo(s)!")
        for d in vivos:
            _dano_em(atacante, d, skill, logs)
        return

    # alvo == "inimigo"
    if defensor is None or defensor["hp"] <= 0:
        vivos = _pets_vivos(inimigos)
        if not vivos:
            return
        defensor = vivos[0]
    dano = _dano_em(atacante, defensor, skill, logs)
    if dano > 0 and float(skill.get("roubo_vida_pct", 0)) > 0:
        cura = max(1, int(dano * float(skill["roubo_vida_pct"])))
        antes = atacante["hp"]
        atacante["hp"] = min(atacante["hp_max"], atacante["hp"] + cura)
        logs.append(f"🩹 {atacante['name']} drenou {atacante['hp'] - antes} HP.")


def _ai_enemy_turn(atacante: dict, player_team: list, enemy_team: list, logs: list,
                   alvo_forcado: dict | None = None) -> None:
    """IA do rival: sorteia entre as opções PRONTAS, com peso pra skill —
    senão o adversário lendário lutaria de ataque básico e a raridade dele
    não apareceria.

    Num combate 1x1 o alvo não é escolha: é quem está em campo
    (`alvo_forcado`). A mira em "quem tem menos vida" só sobrou pro caso
    de alguém chamar esta função fora do laço (a auditoria faz isso)."""
    alvos_vivos = _pets_vivos(player_team)
    if not alvos_vivos:
        return
    alvo = alvo_forcado if (alvo_forcado and alvo_forcado["hp"] > 0) else \
        min(alvos_vivos, key=lambda c: c["hp"] / max(1, c["hp_max"]))

    opcoes = opcoes_de_batalha(atacante)
    prontas = [s for s in opcoes[1:] if s["pronta"]]
    if prontas and random.random() < 0.7:
        skill = random.choice(prontas)
    else:
        skill = opcoes[0]
    _apply_pet_action(atacante, alvo, skill, enemy_team, player_team, logs)


def is_pet_arena_over(p: dict):
    """None (continua), 'vitoria' ou 'derrota'."""
    state = p.get("pet_arena_combat")
    if not state:
        return None
    if state.get("finalizado"):
        return state["finalizado"]
    if not _pets_vivos(state["player_team"]):
        return "derrota"
    if not _pets_vivos(state["enemy_team"]):
        return "vitoria"
    return None


def _proximo_vivo(time_: list, atual) -> int | None:
    """Quem entra: o primeiro vivo a partir do slot seguinte ao atual, e
    dando a volta. A ORDEM DO ESQUADRÃO passa a ser uma decisão — quem
    você põe no slot 1 é quem começa a luta."""
    n = len(time_)
    if n == 0:
        return None
    inicio = 0 if atual is None else atual + 1
    for passo in range(n):
        i = (inicio + passo) % n
        if int(time_[i].get("hp", 0)) > 0:
            return i
    return None


def _garantir_ativos(state: dict, logs: list) -> bool:
    """Põe em campo o próximo pet de cada lado quando o que estava lá cai.
    Devolve False se um dos lados não tem mais ninguém — aí a luta acabou.

    O pet que entra começa com a barra ZERADA: perder um espírito custa o
    tempo de o próximo se posicionar. Sem esse custo, cair seria quase de
    graça e a ordem do esquadrão não importaria.
    """
    for lado, chave, rotulo in (("player_team", "player_active", "Seu"),
                                ("enemy_team", "enemy_active", "O rival")):
        time_ = state[lado]
        atual = state.get(chave)
        precisa = (atual is None or atual >= len(time_)
                   or int(time_[atual].get("hp", 0)) <= 0)
        if not precisa:
            continue
        caido = time_[atual]["name"] if (atual is not None and atual < len(time_)) else None
        novo = _proximo_vivo(time_, atual)
        if novo is None:
            return False
        state[chave] = novo
        time_[novo]["bar"] = 0.0
        if caido:
            logs.append(f"🔁 {caido} caiu! {rotulo} próximo espírito, "
                        f"{time_[novo]['name']}, entra na arena.")
        else:
            logs.append(f"🐾 {rotulo.lower()} espírito {time_[novo]['name']} entra na arena.")
    return True


def _comecar_turno_do_jogador(state: dict, meu: dict, logs: list) -> bool:
    """O começo do turno do SEU pet acontece AQUI, na hora em que ele fica
    pronto — e não quando você escolhe a ação.

    🐛 20/09/2026: a recarga das skills (e o veneno) só andava DEPOIS do
    clique, dentro de `resolve_player_pet_turn`. A tela, montada antes do
    clique, mostrava toda skill com um turno a mais de recarga — e o botão
    vinha desabilitado ("volta em 1t") num turno em que ela já podia ser
    usada. O rival não tinha esse atraso (o turno dele começa aqui no laço).
    Medido: em luta espelhada, mesma estratégia dos dois lados, o jogador
    ganhava só 38–40%.

    Devolve True se o jogador tem uma escolha a fazer; False se o turno já
    se resolveu sozinho (caiu pelo veneno, ou estava atordoado).
    """
    if state.get("acting_idx") == state.get("player_active") and state.get("turno_aberto"):
        return True        # já começou; não conta a recarga duas vezes
    _tick_turno(meu, logs)
    _tick_dots(meu, logs)
    if meu["hp"] <= 0:
        meu["bar"] = 0.0
        return False
    if meu.get("stun", 0) > 0:
        meu["stun"] -= 1
        meu["bar"] = 0.0
        logs.append(f"💫 {meu['name']} está atordoado e perdeu o turno!")
        return False
    state["acting_idx"] = state["player_active"]
    state["turno_aberto"] = True
    return True


def _advance_until_action_needed(state: dict) -> None:
    """Avança o relógio até: (a) o SEU pet em campo estar pronto pra agir —
    pausa e marca acting_idx; ou (b) a luta acabar.

    🥊 20/09/2026 — É UM CONTRA UM.
    Antes os 5 de cada lado lutavam todos ao mesmo tempo, num ATB de 10
    combatentes. O problema disso não era técnico: com todo mundo em campo,
    a ordem do esquadrão não valia nada, a vida de cada pet virava um
    detalhe no meio de dez barras, e perder um espírito quase não se
    sentia. Agora entra UM de cada lado; quem cai dá lugar ao próximo da
    equipe, e a batalha só acaba quando um dos lados não tem mais ninguém.
    """
    player_team = state["player_team"]
    enemy_team = state["enemy_team"]
    logs = state["logs"]

    rounds = 0
    while rounds < MAX_ROUNDS_SAFETY:
        if not _pets_vivos(player_team):
            state["finalizado"] = "derrota"
            state["acting_idx"] = None
            return
        if not _pets_vivos(enemy_team):
            state["finalizado"] = "vitoria"
            state["acting_idx"] = None
            return

        if not _garantir_ativos(state, logs):
            state["finalizado"] = "vitoria" if _pets_vivos(player_team) else "derrota"
            state["acting_idx"] = None
            return

        meu = player_team[state["player_active"]]
        dele = enemy_team[state["enemy_active"]]

        if meu["bar"] >= 100:
            if _comecar_turno_do_jogador(state, meu, logs):
                return
            continue

        # Só os DOIS em campo enchem barra. O banco não ganha turno — é o
        # que faz a luta ser um contra um de verdade e não cinco esperando.
        seguranca = 0
        while seguranca < 500 and meu["bar"] < 100 and dele["bar"] < 100:
            meu["bar"] = min(100.0, meu["bar"] + max(BAR_TICK, meu["spd"] * 0.4))
            dele["bar"] = min(100.0, dele["bar"] + max(BAR_TICK, dele["spd"] * 0.4))
            seguranca += 1

        # Empate (os dois encheram no mesmo passo): moeda. Antes o jogador
        # ganhava TODO empate — e em espelho as barras sempre empatam, então
        # quem começava e quem voltava depois de cada queda era sempre ele.
        # Medido: espelho 1x1 de dps lendário, 43 a 54 vitórias em 60.
        empate = meu["bar"] >= 100 and dele["bar"] >= 100
        if meu["bar"] >= 100 and not (empate and random.random() < 0.5):
            if _comecar_turno_do_jogador(state, meu, logs):
                return
            continue

        # turno do rival
        dele["bar"] = 0.0
        _tick_turno(dele, logs)
        _tick_dots(dele, logs)
        rounds += 1
        if dele["hp"] <= 0:
            continue
        if dele.get("stun", 0) > 0:
            dele["stun"] -= 1
            logs.append(f"💫 {dele['name']} está atordoado e perdeu o turno!")
            continue
        _ai_enemy_turn(dele, player_team, enemy_team, logs,
                       alvo_forcado=player_team[state["player_active"]])

    # segurança: luta que não termina não pode prender o jogador
    state["finalizado"] = "vitoria" if _pets_vivos(player_team) else "derrota"
    state["acting_idx"] = None


def resolve_player_pet_turn(p: dict, target_idx: int, usar_skill: bool | None = None,
                            skill_id: str | None = None, trocar_para: int | None = None) -> str:
    """O jogador escolheu a AÇÃO (uma das 4) e, se ela mira inimigo, o
    alvo. Resolve o turno do pet em `acting_idx`, avança o relógio e
    devolve o log.

    `usar_skill` segue aceito pra não quebrar o bot, que ainda manda o
    booleano antigo: sem `skill_id`, True cai na primeira skill pronta.
    """
    state = p.get("pet_arena_combat")
    if not state or state.get("finalizado"):
        return "❌ Não há combate de Arena de Pets em andamento."

    idx = state.get("acting_idx")
    if idx is None:
        return "❌ Não é a vez de nenhum pet seu agora."

    player_team = state["player_team"]
    enemy_team = state["enemy_team"]
    logs = state["logs"] = []  # novo "turno" de log, pra tela não empilhar tudo

    atacante = player_team[idx]
    atacante["bar"] = 0.0
    # A recarga e o veneno já andaram quando o turno ABRIU
    # (`_comecar_turno_do_jogador`) — aqui é só a ação escolhida.
    state["turno_aberto"] = False

    if atacante["hp"] <= 0:
        state["acting_idx"] = None
        _advance_until_action_needed(state)
        return "\n".join(logs) or "..."

    if trocar_para is not None:
        # 🔁 TROCA DE PET (25/09/2026, pedido do dev): gasta o turno. Quem
        # entra começa com a barra ZERADA — a mesma regra de quando um pet
        # cai (`_garantir_ativos`): ele age no PRÓXIMO turno dele, nunca
        # nesse. O que saiu guarda a vida que tinha e pode voltar depois.
        novo = int(trocar_para)
        if not (0 <= novo < len(player_team)) or novo == state.get("player_active"):
            logs.append("❌ Esse espírito não pode entrar agora.")
            state["turno_aberto"] = True
            atacante["bar"] = 100.0            # não gastou o turno
            return "\n".join(logs)
        if int(player_team[novo].get("hp", 0)) <= 0:
            logs.append(f"❌ {player_team[novo]['name']} já caiu e não pode entrar.")
            state["turno_aberto"] = True
            atacante["bar"] = 100.0
            return "\n".join(logs)
        state["player_active"] = novo
        player_team[novo]["bar"] = 0.0
        logs.append(f"🔁 {atacante['name']} sai da arena. {player_team[novo]['name']} entra no lugar "
                    f"— o turno foi gasto na troca.")
    elif atacante.get("stun", 0) > 0:
        atacante["stun"] -= 1
        logs.append(f"💫 {atacante['name']} está atordoado e perdeu o turno!")
    else:
        skill = _skill_escolhida(atacante, skill_id, usar_skill)
        if skill is None:
            # Skill pedida ainda esfriando: em vez de perder o turno em
            # silêncio, cai no básico e DIZ. Perder turno por causa da
            # tela é o pior jeito de descobrir uma recarga.
            skill = opcoes_de_batalha(atacante)[0]
            logs.append("⏳ Essa habilidade ainda está recarregando — foi ataque básico.")

        # 🥊 Num 1x1 o alvo não é escolha: é quem está em campo. `target_idx`
        # continua na assinatura porque o bot ainda manda, e ignorá-lo é
        # melhor que quebrar a chamada dele.
        defensor = None
        if skill.get("alvo", "inimigo") == "inimigo":
            ativo = state.get("enemy_active")
            if ativo is not None and 0 <= ativo < len(enemy_team) and enemy_team[ativo]["hp"] > 0:
                defensor = enemy_team[ativo]
            else:
                vivos_e = _pets_vivos(enemy_team)
                defensor = vivos_e[0] if vivos_e else None
        _apply_pet_action(atacante, defensor, skill, player_team, enemy_team, logs)

    state["acting_idx"] = None
    _advance_until_action_needed(state)
    return "\n".join(logs) or "..."


def finalize_pet_arena_combat(p: dict) -> dict:
    """Chame quando is_pet_arena_over() != None. Aplica pontos/vitórias
    e limpa o estado de combate. Retorna {"resultado": "vitoria"/"derrota",
    "pontos": delta}."""
    from game.sql_repo import update_pet_arena_score_sync

    state = p.get("pet_arena_combat") or {}
    resultado = state.get("finalizado") or is_pet_arena_over(p)
    uid = int(p.get("user_id") or p.get("telegram_id"))
    opponent_id = state.get("opponent_id")

    venceu = resultado == "vitoria"
    delta = VITORIA_PONTOS if venceu else -DERROTA_PONTOS
    # 🔥 (09/07/2026): só a pontuação de QUEM DESAFIOU muda — igual a arena
    # de personagens, o oponente é uma cópia passiva sendo farmada por
    # vários jogadores; mexer no placar dele a cada luta alheia seria
    # incoerente com o resto do jogo.
    update_pet_arena_score_sync(uid, delta, venceu)

    p["pet_arena_combat"] = None
    return {"resultado": resultado, "pontos": delta}
