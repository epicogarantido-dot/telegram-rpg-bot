"""
Materiais, ranks e o que um clã precisa.

O MAPA É A TORRE
----------------
Cada andar é uma área de AFK. O perfil de risco já funciona por andar, e a
profundidade já escala sozinha — não precisa de sistema de mapa nenhum.

A MEDIÇÃO QUE DEFINIU OS RANKS
------------------------------
O nível é travado em `andar * 2` (gain_xp, logic.py). Medindo até onde o AFK
é seguro (morte abaixo de 10% por encontro) com esse teto:

    seu andar   nível máx   farma até   fração
         10          20          6       60%
         30          60         22       73%
         60         120         31       52%
        100         200         49       49%

**A fronteira é ~metade do seu andar**, e no fim do jogo ela para no andar
49 — tier 5 de 10 da tabela de monstros.

Se o rank do material viesse do tier do andar, os **tiers 6 a 10 nunca
seriam farmáveis**. Cinco ranks inteiros de conteúdo que ninguém alcança —
o bug recorrente deste projeto, em escala nova.

Por isso são **5 ranks mapeados nos andares 1–50**, e não 10 em 1–100. E
isso separa bem os dois pilares: a Torre ativa é onde VOCÊ vai fundo; o AFK
é onde o clã trabalha atrás de você. Andar 50+ não dá material novo porque
lá não é trabalho de clã, é expedição sua.

⚠️ A medição foi feita SEM equipamento. Equipar o cavaleiro sobe o poder e
empurra a fronteira — que é exatamente por que a forja precisa existir.
Quando o equipamento entrar na conta, vale medir de novo: se a fronteira
passar do andar 50 com folga, cabe um rank 6.
"""
from __future__ import annotations

# ---------------------------------------------------------------- ranks

# ⚔️ 20/09/2026 (regra do dev) — O RANK VEM DO MONSTRO, NÃO DO ANDAR.
#   monstro comum → rank 1 (forja Comum e Incomum)
#   elite/general → rank 2 (forja Raro e Épico)
#   chefe         → rank 3 (forja Lendário)
# Eram 5 ranks por faixa de andar (1–10, 11–20, ...). Com 3 ranks por TIPO
# de monstro, o material de lendário só existe onde há chefe — e chefe só
# nasce nos andares 5, 10, 15... (na Torre, andar de chefe é só de chefe).
# "andares" saiu: nenhum rank é mais de uma faixa de andar.
RANKS = {
    1: {"nome": "Bruto",      "fonte": "monstros comuns",  "cor": "comum"},
    2: {"nome": "Rúnico",     "fonte": "elites e generais", "cor": "raro"},
    3: {"nome": "Primordial", "fonte": "chefes",            "cor": "lendario"},
}
RANK_DO_TIPO = {"normal": 1, "elite": 2, "general": 2, "boss": 3}

RANK_MAX = max(RANKS)


def rank_do_andar(andar: int) -> int:
    """(Legado) O andar não decide mais o rank — ver RANK_DO_TIPO. Fica
    devolvendo 1 pra quem ainda pergunta pelo andar (postos, áreas antigas
    dos testes de AFK), que é o material dos bichos comuns."""
    return 1


def andar_minimo_do_rank(rank: int) -> int:
    """Primeiro andar onde o rank pode sair: comum e elite desde o 1 (a
    Torre tem elite desde o começo); chefe desde o 5."""
    return 5 if int(rank) >= 3 else 1


# ------------------------------------------------- o que um clã precisa

# Três necessidades, e elas competem pelo mesmo material. É a competição que
# faz a decisão existir — se desse pra fazer tudo, não haveria escolha.
NECESSIDADES = {
    "comida": {
        "nome": "Comida",
        "porque": "Membro com fome perde poder, e poder é o que decide a fronteira dele.",
        "consome": None,          # vem da coleta, não de material
        "urgencia": "constante",
    },
    "equipamento": {
        "nome": "Armas e armaduras",
        "porque": "Sobe o poder do membro — é o que empurra a fronteira de farm pra frente.",
        "consome": "material",
        "urgencia": "investimento",
    },
    "comodidade": {
        "nome": "Comodidades do clã",
        "porque": "Bônus passivo pra todo o clã, não pra um membro.",
        "consome": "material",
        "urgencia": "longo prazo",
    },
}

# Equipamento por rank. O ganho de poder é o número que importa: ele decide
# quantos andares a mais o membro alcança.
EQUIPAMENTO = {
    # 3 ranks desde 20/09 (o rank é do monstro). Os poderes são os antigos
    # 1, 3 e 5 — a escada continua indo do ferro ao núcleo primordial.
    1: {"nome": "Ferro bruto",       "custo": 20,  "poder": 4},
    2: {"nome": "Liga rúnica",       "custo": 60,  "poder": 16},
    3: {"nome": "Núcleo primordial", "custo": 40,  "poder": 40},   # 40 chefes
}

# Comodidades: melhoram o CLÃ, não o indivíduo. De propósito elas competem
# com o equipamento pelo mesmo material — construir muralha é abrir mão de
# armar alguém, e é aí que mora a decisão.
# ⚠️ CUSTO EM DOIS RECURSOS (18/09): `custo` é METAL do rank, `madeira` é
# o volume da estrutura. A madeira decide QUANDO dá pra construir; o rank do
# metal decide O QUE — assim o rank continua significando alguma coisa e a
# madeira deixa de ser número que só sobe.
#
# ⚠️ MEDIDO, E VALE SABER: com um membro dedicado na melhor área, a árvore
# INTEIRA de construções custa menos de uma sessão (0,2 a 1,1). O custo
# nunca foi o gargalo — o ANDAR é. Se um dia a construção tiver que ser uma
# decisão de economia e não só de progressão, é este número que sobe. Por
# ora a folga é de propósito: é ela que a mudança de acampamento vai comer,
# porque reerguer as construções custa madeira.
COMODIDADES = {
    "celeiro": {
        "nome": "Celeiro", "rank": 1, "custo": 24, "madeira": 60,
        "efeito": "dobra o que cabe de comida", "chave": "teto_comida", "valor": 2,
        "porque": "Sem celeiro, a comida que sobra se perde — e sobra justo "
                  "quando você fica muito tempo fora.",
    },
    "muralha": {
        "nome": "Muralha", "rank": 2, "custo": 56, "madeira": 140,
        "efeito": "reduz perda em ataque", "chave": "reduz_perda", "valor": 0.4,
        "porque": "Vale quando outros clãs começarem a olhar pro seu território.",
    },
    "forja": {
        "nome": "Forja do clã", "rank": 2, "custo": 64, "madeira": 160,
        "efeito": "equipamento custa menos", "chave": "desconto_equip", "valor": 0.25,
        "porque": "Se paga depois de quatro peças. Antes disso é material parado.",
    },
    "salao": {
        "nome": "Salão", "rank": 2, "custo": 104, "madeira": 260,
        "efeito": "mais situações por sessão", "chave": "bonus_situacoes", "valor": 4,
        "porque": "Mais gente reunida, mais coisa acontecendo — é o que "
                  "alimenta o pilar de storylet.",
    },
    "enfermaria": {
        "nome": "Enfermaria", "rank": 2, "custo": 96, "madeira": 240,
        "efeito": "cura ferimentos entre sessões", "chave": "cura_ferimento", "valor": 2,
        "porque": "Ferimento derruba o poder, e poder derrubado encolhe a "
                  "fronteira. Sem enfermaria, um susto vira espiral.",
    },
    # 🏠 (25/09/2026, dev) "uma que tu gasta tanto pra aumentar tanto de
    # limite": POR NÍVEIS. Cada nível +25 no limite de aldeões; o próximo
    # custa 200×nível de madeira e 20×nível de metal rank 1 (nv1: 200+20,
    # nv10: 2000+200). Conta como UMA construção pro estágio da aldeia.
    "moradias": {
        "nome": "Moradias", "rank": 1, "custo": 20, "madeira": 200,
        "efeito": "+25 no limite de aldeões por nível", "chave": "capacidade", "valor": 25,
        "niveis": True, "nivel_max": 20, "custo_por_nivel": 20, "madeira_por_nivel": 200,
        "porque": "Aldeia cheia não acolhe ninguém. Cada nível de casas abre 25 vagas.",
    },
    "atalaia": {
        # rank 3 é de chefe (1 por chefe abatido)
        "nome": "Atalaia", "rank": 3, "custo": 40, "madeira": 420,
        "efeito": "mostra o perfil antes de mandar", "chave": "revela_perfil", "valor": 1,
        "porque": "Sem ela você manda no escuro. Com ela, a morte permanente "
                  "vira aposta em vez de armadilha.",
    },
}


# Quanto o clã consegue guardar. O que passa disso apodrece.
#
# ⚠️ Este número existe pra o Celeiro ter função. Antes dele, `teto_comida`
# estava declarado na tabela acima e não era lido em lugar NENHUM do
# projeto — o jogador pagava 60 de material rank 1 por nada.
#
# O teto ACOMPANHA O CLÃ, e não é um número fixo, porque o consumo também
# acompanha: um clã de 5 come 30 por sessão e um de 2 come 12. Teto fixo
# faria o depósito ser folgado demais pra clã pequeno e apertado demais pra
# clã grande, que é justo quando guardar importa.
#
# Medido: 60 por membro (nunca menos que o de 3 membros) dá ~10 sessões de
# consumo de folga, e o Celeiro dobra isso. Dez sessões é bastante de
# propósito — estocar tem que valer a pena —, mas não é infinito: quem
# nunca põe ninguém pra colher drena o estoque e passa fome do mesmo jeito.
TETO_COMIDA_POR_MEMBRO = 60
TETO_COMIDA_MINIMO = 180


def teto_de_comida(comodidades: dict | None = None, membros: int = 1) -> int:
    """Quanto de comida o clã guarda. Cresce com o clã; o Celeiro dobra."""
    teto = max(TETO_COMIDA_MINIMO, TETO_COMIDA_POR_MEMBRO * max(1, int(membros)))
    if comodidades and comodidades.get("celeiro"):
        teto = int(teto * COMODIDADES["celeiro"]["valor"])
    return teto


def custo_equipamento(rank: int, comodidades: dict | None = None) -> int:
    base = EQUIPAMENTO.get(int(rank), EQUIPAMENTO[RANK_MAX])["custo"]
    desconto = 0.0
    if comodidades and comodidades.get("forja"):
        desconto = COMODIDADES["forja"]["valor"]
    return max(1, int(round(base * (1 - desconto))))


def poder_do_equipamento(rank: int) -> int:
    return EQUIPAMENTO.get(int(rank), EQUIPAMENTO[RANK_MAX])["poder"]


def bonus_do_clan(comodidades: dict | None) -> dict:
    """Tudo que as comodidades construídas dão, junto. Uma função só pra o
    resto do jogo não precisar saber a tabela."""
    saida = {}
    for chave, construida in (comodidades or {}).items():
        if not construida:
            continue
        dados = COMODIDADES.get(chave)
        if dados:
            # por níveis (Moradias): o efeito soma a cada nível
            saida[dados["chave"]] = (dados["valor"] * nivel_da_comodidade(comodidades, chave)
                                     if dados.get("niveis") else dados["valor"])
    return saida


def rank_do_monstro(tipo: str) -> int:
    return RANK_DO_TIPO.get(str(tipo or "normal").lower(), 1)


def onde_cai(rank: int) -> str:
    """Texto pra tela: de onde vem o material daquele rank."""
    return {1: "monstros comuns (e veios dos postos)",
            2: "elites e generais (e veios profundos)",
            3: "chefes — andares 5, 10, 15..."}.get(int(rank), "—")


def rende_no_andar(andar: int) -> dict:
    """Quanto e de que rank um andar rende por coleta.

    Cresce com o andar, mas o rank é o que realmente importa: 300 de rank 1
    não fazem uma peça de rank 3. Isso impede farmar andar fácil pra sempre.
    """
    a = max(1, int(andar))
    return {"rank": 1, "quantidade": max(2, int(2 + a * 0.8))}



# ────────────────────────────────────────────── material na Torre (pessoal)
#
# ⛏️ 20/09/2026: o material deixou de ser só do clã. Matar monstro na Torre
# também dá material — do rank do ANDAR em que o monstro estava, o mesmo
# mapa andar→rank de cima — e ele vai pra mochila do personagem
# (`p["materiais_torre"]`). A Forja gasta essa mochila primeiro e só depois
# o estoque do clã.
#
# Medido antes de fixar (clan_afk, grupo dedicado de 3): um posto rende
# ~91 de rank 1 por sessão no andar 9 e ~400 de rank 5 no andar 46. A drop
# pessoal é deliberadamente MENOR que isso — a Torre dá o suficiente pra
# forjar as peças de quem joga, e o clã continua sendo a fonte grande.
CHANCE_MATERIAL_NORMAL = 0.35


def material_do_monstro(andar: int, tipo: str, rng) -> tuple[int, int]:
    """(rank, quantidade) que um monstro morto deixa. Quantidade 0 = nada.

    20/09/2026 (dev): TUDO deixa 1 — chefe era 5, elite/general 2. Elite,
    general e chefe deixam sempre (valem o que custam pra matar); o comum
    deixa em 35% das vezes. A escassez agora está no rank, não no volume."""
    t = str(tipo or "normal").lower()
    rank = rank_do_monstro(t)
    if t in ("boss", "elite", "general"):
        return rank, 1
    return (rank, 1) if rng.random() < CHANCE_MATERIAL_NORMAL else (rank, 0)



# 🛒 (dev, 20/09) A LOJA DA CIDADE vende material de forja — caro de
# propósito: é o atalho pra quem tem ouro e não tem tempo, e o preço tem
# que doer mais que farmar (um monstro comum deixa rank 1 em 35% das
# vezes; um chefe deixa 1 de rank 3).
PRECO_NA_LOJA = {1: 50, 2: 100, 3: 200}



# 🏠 construção por níveis (Moradias)
def nivel_da_comodidade(comodidades: dict | None, chave: str) -> int:
    v = (comodidades or {}).get(chave)
    if v is True:
        return 1
    try:
        return max(0, int(v or 0))
    except (TypeError, ValueError):
        return 0


def custo_do_proximo_nivel(chave: str, nivel_atual: int) -> tuple[int, int]:
    """(metal, madeira) do PRÓXIMO nível de uma construção por níveis."""
    d = COMODIDADES[chave]
    n = int(nivel_atual) + 1
    return int(d["custo_por_nivel"]) * n, int(d["madeira_por_nivel"]) * n


def capacidade_das_construcoes(comodidades: dict | None) -> int:
    """Quanto as construções por níveis somam no limite de aldeões."""
    return sum(nivel_da_comodidade(comodidades, k) * int(d.get("valor", 0))
               for k, d in COMODIDADES.items() if d.get("niveis") and d.get("chave") == "capacidade")
