# game/clan_equipes.py
"""
👥 A ALDEIA POR EQUIPES (20/09/2026 — fase 1 do redesenho pedido pelo dev)

O QUE MUDOU
-----------
Antes, cada habitante tinha UMA profissão e uma estrela de potencial, e
produzia de dentro da aldeia. Agora:

- **Talentos**: todo NPC tem estrelas (0 a 5) em CADA profissão. A maioria
  é 0★ — e 0★ quer dizer que ele NÃO PODE exercer aquilo. Nem todo mundo
  pode ser guarda.
- **Produção**: 5★ produz 4× o que 1★ produz (linear: 1, 1,75, 2,5, 3,25, 4).
- **Nível máximo**: coletor para no 20. Guarda vai até 20 × estrelas de
  guarda (5★ = 100); passar de 100 só usuário de aura.
- **Equipes**: coletar é FORA da aldeia, num posto achado no andar. Uma
  equipe só sai se levar guarda junto — quantos, o jogador decide. Guarda
  é caro: come 3× e gasta couro e ferro.
- **Manutenção**: a aldeia sempre custa (comida, madeira, couro, ferro). Se
  faltar qualquer um, a aldeia entra em GREVE e ninguém sai pra coletar
  naquela sessão.

Puro: sem banco. `clan_repo` guarda e chama; `testes/auditar_equipes.py`
mede.
"""
from __future__ import annotations

import random

# ─────────────────────────────────────────────────────────── talentos ──
# profissão → recurso que ela tira de um posto
COLETA = {"agricultor": "comida", "lenhador": "madeira", "cacador": "couro", "minerador": "ferro"}
PROFISSOES = ("agricultor", "lenhador", "cacador", "minerador", "guarda", "curandeiro")
NOME_PROFISSAO = {"agricultor": "Agricultor", "lenhador": "Lenhador", "cacador": "Caçador",
                  "minerador": "Minerador", "guarda": "Guarda", "curandeiro": "Curandeiro"}

# A maioria é 0★: talento é raro, e é isso que faz o recrutamento importar.
PESO_TALENTO = {0: 62, 1: 16, 2: 10, 3: 7, 4: 4, 5: 1}
PESO_GUARDA = {0: 78, 1: 8, 2: 6, 3: 4, 4: 3, 5: 1}      # nem todos podem ser guardas

# posto → recurso (os tipos de `clan_postos`); ferro = material rank 1
RECURSO_DO_POSTO = {"clareira": "comida", "nascente": "comida", "bosque": "madeira",
                    "caca": "couro", "veio": "ferro", "veio_rico": "ferro"}


def _sortear(pesos: dict, rng: random.Random) -> int:
    corte, acc = rng.uniform(0, sum(pesos.values())), 0.0
    for k, p in pesos.items():
        acc += p
        if corte <= acc:
            return int(k)
    return int(max(pesos))


def sortear_talentos(rng: random.Random) -> dict:
    """Estrelas em cada profissão. Garante UM talento de coleta ≥1★ —
    ninguém chega à aldeia sem saber fazer nada."""
    t = {p: _sortear(PESO_GUARDA if p == "guarda" else PESO_TALENTO, rng) for p in PROFISSOES}
    if not any(t[p] for p in COLETA):
        t[rng.choice(list(COLETA))] = 1
    return t


def estrelas(hab: dict, profissao: str) -> int:
    return int((hab.get("talentos") or {}).get(profissao, 0))


def pode(hab: dict, profissao: str) -> bool:
    return estrelas(hab, profissao) >= 1


def mult_estrelas(n: int) -> float:
    """5★ = 4× o 1★; 0★ = não produz."""
    return 0.0 if int(n) <= 0 else 1.0 + 0.75 * (int(n) - 1)


# ─────────────────────────────────────────────────────────── níveis ──
NIVEL_MAX_COLETOR = 20
NIVEL_POR_ESTRELA_GUARDA = 20
NIVEL_EXTRA_POR_AURA = 20       # além do 100, só com aura: +20 por estrela de aura


def nivel_maximo(hab: dict) -> int:
    if hab.get("funcao") == "guarda":
        teto = NIVEL_POR_ESTRELA_GUARDA * estrelas(hab, "guarda")
        if teto >= 100 and int(hab.get("aura") or 0) > 0:
            teto += NIVEL_EXTRA_POR_AURA * int(hab["aura"])
        return max(1, teto)
    return NIVEL_MAX_COLETOR


# ─────────────────────────────────────────────────── produção e poder ──
BASE_POR_SESSAO = 12.0          # um coletor 1★ nível 1, sessão cheia


def producao_do_coletor(hab: dict, recurso: str, fracao: float = 1.0) -> float:
    """Quanto um coletor tira de um posto numa sessão (ou fração). Só rende
    se a profissão dele coleta ESSE recurso — lenhador na clareira não faz
    nada. O nível soma 5% por nível (no 20, dobra)."""
    prof = next((p for p, r in COLETA.items() if r == recurso and pode(hab, p)), None)
    if not prof:
        return 0.0
    from game.clan_ferreiro import bonus_de        # ⚒️ a ferramenta DESSA função
    return (BASE_POR_SESSAO * mult_estrelas(estrelas(hab, prof))
            * (1 + 0.05 * (int(hab.get("nivel") or 1) - 1)) * float(fracao)
            * bonus_de(hab, prof))


# ⚔️ CAVALEIRO (28/09, dev): "os personagens podem passar por um treinamento
# pra virar um cavaleiro, um tipo novo de aldeão focado em guerra" — e "tem
# que ser no mínimo umas 10 vezes mais forte que um guarda do mesmo nível".
# É um usuário de aura que largou a Torre pra servir o clã. Entra como guarda
# 5★ com o NÍVEL que o personagem tinha e rende 10× o que um guarda 5★ do
# mesmo nível rende (5★ é o guarda mais forte que existe, então ele é 10× ou
# mais que QUALQUER guarda do nível dele) — na escolta, na batalha pelo ponto
# e em tudo que soma poder de guarda. Na guarnição da cidade vale 10 guardas.
MULT_CAVALEIRO = 10.0
MULT_CAVALEIRO_GUARNICAO = 10.0

# 💰 (28/09, dev) "um custo em ouro pros cavaleiros — já que usam aura, eles
# podem vir morar na cidade". Mora na cidade do reino (não na aldeia) e
# recebe SOLDO em ouro, pago adiantado. Sem soldo, não luta nem defende —
# fica na cidade esperando. 500/dia ≈ 1/8 do que as missões do reino pagam
# num dia (~4.000): 2 cavaleiros comem 1/4 da renda, 4 comem metade.
SOLDO_CAVALEIRO_DIA = 500
DIAS_DE_SOLDO_NO_TREINO = 7          # o treino já paga a 1ª semana


def sem_soldo(hab: dict) -> bool:
    import time as _t
    return bool(hab.get("cavaleiro")) and int(hab.get("soldo_ate") or 0) <= int(_t.time())


def em_treino(hab: dict) -> bool:
    import time as _t
    return int(hab.get("treino_ate") or 0) > int(_t.time())


def poder_do_guarda(hab: dict) -> int:
    """Força militar de um guarda: nível e estrelas de guarda."""
    from game.clan_ferreiro import bonus_de        # ⚒️ equipamento do ferreiro
    if em_treino(hab) or sem_soldo(hab):
        return 0                                   # treinando, ou sem soldo: não luta
    base = ((10 + 3 * int(hab.get("nivel") or 1)) * mult_estrelas(estrelas(hab, "guarda"))
            * bonus_de(hab, "guarda"))
    return int(base * (MULT_CAVALEIRO if hab.get("cavaleiro") else 1.0))


def ameaca_do_andar(andar: int) -> int:
    """O perigo que uma equipe fora da aldeia encontra numa sessão."""
    a = max(1, int(andar))
    # cresce mais que linear: fundo pede MAIS guardas, não só guarda melhor
    return int(12 + 6 * a + 0.25 * a * a)


def resultado_da_saida(equipe_guardas: list, andar: int, rng: random.Random) -> dict:
    """A escolta aguentou? Guarda suficiente = equipe inteira. Escolta fraca =
    rende proporcional e alguém se machuca. Sem guarda a equipe nem sai
    (quem garante isso é quem monta a equipe)."""
    poder = sum(poder_do_guarda(g) for g in equipe_guardas)
    ameaca = int(ameaca_do_andar(andar) * rng.uniform(0.8, 1.2))
    if poder >= ameaca:
        return {"poder": poder, "ameaca": ameaca, "fator": 1.0, "ferido": False}
    fator = max(0.2, poder / max(1, ameaca))
    return {"poder": poder, "ameaca": ameaca, "fator": round(fator, 2), "ferido": True}


# ─────────────────────────────────────────────────────── manutenção ──
# Por sessão, ALÉM da ração que todo habitante já come na aldeia
# (`clan_habitantes`, 1 a cada 4 ticks = 6 por sessão). Guarda é caro de
# propósito — o dev: "guarda come mais e gasta mais recursos" —, e é isso
# que faz "quantos guardas mandar" ser decisão: come o triplo (+12) e gasta
# couro e ferro do equipamento. Madeira é o conserto da aldeia, de todos.
# 🔥 25/09/2026 (dev): "a madeira aumenta o custo por causa de lenha" — todo
# aldeão queima lenha (cozinhar, aquecer): a madeira passou de 0,5 pra 2 por
# aldeão por sessão. Medido antes: 50 aldeões gastavam 26 de madeira e UMA
# equipe de lenhadores trazia 160–306 — a madeira não pesava em nada.
LENHA_POR_ALDEAO = 2.0
MANUTENCAO = {
    "coletor": {"comida": 0, "madeira": LENHA_POR_ALDEAO, "couro": 0.0, "ferro": 0.0},
    "guarda":  {"comida": 12, "madeira": LENHA_POR_ALDEAO, "couro": 1.0, "ferro": 1.0},
    # 🏙️ cavaleiro mora na cidade do reino: não custa recurso da aldeia —
    # o custo dele é o soldo em ouro (SOLDO_CAVALEIRO_DIA)
    "cavaleiro": {"comida": 0, "madeira": 0, "couro": 0.0, "ferro": 0.0},
    "outro":   {"comida": 0, "madeira": LENHA_POR_ALDEAO, "couro": 0.0, "ferro": 0.0},
}


def manutencao_da_aldeia(habitantes: list, fracao: float = 1.0) -> dict:
    """Quanto a aldeia gasta nesta sessão pra se manter."""
    total = {"comida": 0.0, "madeira": 0.0, "couro": 0.0, "ferro": 0.0}
    for h in habitantes:
        chave = ("cavaleiro" if h.get("cavaleiro") else "guarda" if h.get("funcao") == "guarda"
                 else "coletor" if h.get("funcao") == "coletor" else "outro")
        for r, q in MANUTENCAO[chave].items():
            total[r] += q * float(fracao)
    return {r: int(round(q)) for r, q in total.items()}


def falta_pra_manter(estoque: dict, custo: dict) -> dict:
    """O que falta pra pagar a manutenção. Vazio = paga tudo."""
    return {r: q - int(estoque.get(r, 0)) for r, q in custo.items() if int(estoque.get(r, 0)) < q}


# preço (em ouro) de comprar de outras aldeias — mais caro que produzir
PRECO_OUTRAS_ALDEIAS = {"comida": 1, "madeira": 2, "couro": 3, "ferro": 5}



def preco_de_outra_aldeia(recurso: str, vizinhos: int = 50) -> int:
    """🤝 O preço anda com a RELAÇÃO com as aldeias vizinhas (qualidade
    `vizinhos` dos storylets, 0–100): 50 = preço de tabela; 100 = 30% mais
    barato; 0 = 30% mais caro. É o que faz os storylets de vizinhança
    pesarem no bolso, e não só no texto."""
    fator = 1.3 - 0.6 * max(0, min(100, int(vizinhos))) / 100
    return max(1, round(PRECO_OUTRAS_ALDEIAS[recurso] * fator))
