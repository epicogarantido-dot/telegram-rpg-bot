# game/premium_api.py
from __future__ import annotations
from premiumsystem import premiumrepo  # premium_system.py

def ensure_playerid(p: dict) -> str:
    """
    Define/retorna um playerid estável.
    Neste projeto, o mais simples é usar o userid como string.
    """
    uid = p.get("userid")
    if uid is None:
        return ""
    pid = str(p.get("playerid") or uid)
    p["playerid"] = pid
    return pid

def ensure_wallet(p: dict) -> str:
    """
    Garante que existe uma wallet no banco premium para esse playerid.
    """
    pid = ensure_playerid(p)
    if not pid:
        return ""
    # Aqui você pode usar chatid/ userid separados se tiver.
    chatid = int(p.get("userid", 0) or 0)
    userid = int(p.get("userid", 0) or 0)
    premiumrepo.getorcreatewallet(pid, chatid, userid)
    return pid

def balance(p: dict) -> int:
    pid = ensure_wallet(p)
    return int(premiumrepo.getpremium(pid)) if pid else 0

def add(p: dict, amount: int, reason: str = "credit") -> bool:
    pid = ensure_wallet(p)
    if not pid:
        return False
    return bool(premiumrepo.addpremium(pid, int(amount), str(reason)))

def spend(p: dict, amount: int, reason: str = "spend") -> bool:
    pid = ensure_wallet(p)
    if not pid:
        return False
    amt = int(amount)
    if amt <= 0:
        return False
    return bool(premiumrepo.removepremium(pid, amt, str(reason)))

def sync_cache(p: dict) -> int:
    """
    Cache só pra UI/debug. A verdade continua sendo o banco premium.
    """
    b = balance(p)
    p["premium"] = b
    return b