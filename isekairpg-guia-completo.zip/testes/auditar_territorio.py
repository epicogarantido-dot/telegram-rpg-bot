#!/usr/bin/env python3
"""Auditoria do mapa de território (20/09).

POR QUE EXISTE
--------------
O mapa é mundo COMPARTILHADO: um erro de desenho aqui não estraga a conta
de um jogador, estraga o jogo de todos ao mesmo tempo. Então cada regra
pedida e cada promessa do documento do clã é medida:

- 10 pontos de cada tipo, e locais seguros que ninguém toma nem ataca;
- a chance de vitória é justa (forças iguais = 50%) e cresce com a força;
- a perda é GRADUAL: um clã fraco leva várias sessões pra perder o ponto,
  passando por "ameaçado" — nunca "perdeu tudo" de uma vez;
- um clã forte segura o ponto indefinidamente;
- o tier paga: ponto mais fundo rende mais e é mais bem defendido;
- um clã comum tem onde disputar (nem tudo é impossível, nem tudo é fácil).
"""
import sys, os, random, collections

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)

from game import territorio as T

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


mapa = T.gerar_mapa()
por_tipo = collections.Counter(p["tipo"] for p in mapa)
print("pontos por tipo:", dict(por_tipo))
for tipo in T.TIPOS:
    # (dev, 20/09) 3 de cada tipo em CADA andar; o Covil só nos de chefe
    esperado = T.PONTOS_POR_TIPO_POR_ANDAR * (T.ANDARES_DO_MAPA // 5 if T.TIPOS[tipo].get("so_chefe")
                                              else T.ANDARES_DO_MAPA)
    exigir(por_tipo[tipo] == esperado, f"o tipo {tipo} tem {por_tipo[tipo]} pontos, e não {esperado}")
from collections import Counter as _C
por_andar = _C((p["andar"], p["tipo"]) for p in mapa)
exigir(all(por_andar[(a, t)] == 3 for a in range(1, 51) for t in T.TIPOS if not T.TIPOS[t].get("so_chefe")),
       "algum andar não tem 3 pontos de cada tipo")
exigir(por_tipo["seguro"] == T.ANDARES_DO_MAPA, "falta um refúgio em cada andar")
exigir(T.gerar_mapa() == mapa, "o mapa muda entre gerações — cada jogador veria um mundo diferente")
exigir(len({p["nome"] for p in mapa}) == len(mapa), "dois pontos com o mesmo nome no mapa")

# ── locais seguros: ninguém toma, ninguém ataca ─────────────────────────
seguro = next(p for p in mapa if p["seguro"])
exigir(T.defesa_do_ponto(seguro) == 0, "local seguro tem defesa — dá pra 'tomar'")
seguro_ocupado = dict(seguro, dono_tipo="jogador", dono_id="1")
rng = random.Random(1)
ataques = sum(T.pressao_dos_bots(seguro_ocupado, 1, 1.0, rng)["atacado"] for _ in range(500))
exigir(ataques == 0, f"local seguro foi atacado {ataques} vezes em 500 sessões")
exigir(T.bonus_do_ponto(seguro) == {},
       "o refúgio dá bônus — ele é abrigo, não fonte")

# ── a chance é justa e cresce com a força ───────────────────────────────
exigir(abs(T.chance_de_vencer(50, 50) - 0.5) < 1e-9, "forças iguais não dão 50%")
exigir(T.chance_de_vencer(100, 50) >= 0.79, "o dobro da força não passa de 79%")
exigir(T.chance_de_vencer(25, 50) <= 0.21, "metade da força ainda passa de 21% — vira loteria")

# ── um clã comum tem onde disputar ──────────────────────────────────────
forca_comum = T.forca_do_cla([{"nivel": 10}] * 5, 10)
chances = {t: T.chance_de_vencer(forca_comum, T.guarnicao_bot(t)) for t in range(1, 11)}
print(f"clã comum (força {forca_comum}) contra bot, por tier:",
      {t: f"{100 * c:.0f}%" for t, c in chances.items()})
faceis = [t for t, c in chances.items() if c >= 0.7]
dificeis = [t for t, c in chances.items() if c <= 0.3]
exigir(faceis, "um clã comum não tem NENHUM ponto que tome com folga")
exigir(dificeis, "um clã comum toma tudo com facilidade — o mapa não tem topo")

# ── perda gradual ───────────────────────────────────────────────────────
def sessoes_ate_perder(forca, tier, semente, limite=200):
    pt = {"tipo": "mina", "tier": tier, "seguro": 0, "dono_tipo": "jogador",
          "dono_id": "1", "integridade": 100}
    rng_ = random.Random(semente)
    viu_ameaca = False
    for s in range(1, limite + 1):
        T.pressao_dos_bots(pt, forca, 1.0, rng_)
        if T.estado_do_ponto(pt["integridade"]) == "ameaçado":
            viu_ameaca = True
        if pt["integridade"] <= 0:
            return s, viu_ameaca
    return None, viu_ameaca

fraco = [sessoes_ate_perder(20, 8, sem) for sem in range(40)]
perdeu = [s for s, _ in fraco if s]
print(f"clã fraco (força 20) no tier 8: perde em média em "
      f"{sum(perdeu) / max(1, len(perdeu)):.1f} sessões (mínimo {min(perdeu or [0])})")
exigir(perdeu and min(perdeu) >= 2, "um ponto foi perdido de uma vez só — o documento pede perda gradual")
exigir(all(v for s, v in fraco if s), "um ponto foi perdido sem passar por 'ameaçado'")

forte = [sessoes_ate_perder(400, 8, sem)[0] for sem in range(40)]
exigir(all(s is None for s in forte), "um clã muito forte perdeu o ponto")

# ── 📈 o ponto dá BÔNUS (+100% a +150%), não produz (regra do dev, 20/09) ──
b1 = T.bonus_do_ponto({"tipo": "floresta", "tier": 1, "integridade": 100})
b10 = T.bonus_do_ponto({"tipo": "floresta", "tier": 10, "integridade": 100})
bmeia = T.bonus_do_ponto({"tipo": "floresta", "tier": 10, "integridade": 50})
print(f"floresta: tier 1 +{100 * b1['madeira']:.0f}% · tier 10 +{100 * b10['madeira']:.0f}% "
      f"· tier 10 a 50% +{100 * bmeia['madeira']:.0f}% de madeira")
exigir(abs(b1["madeira"] - 1.0) < 1e-9 and abs(b10["madeira"] - 1.5) < 1e-9,
       "o bônus não vai de +100% (tier 1) a +150% (tier 10)")
exigir(abs(bmeia["madeira"] - 0.75) < 1e-9, "a integridade não derruba o bônus na mesma proporção")
recursos_validos = {"comida", "madeira", "couro", "ouro", "material"}
for tipo, info in T.TIPOS.items():
    if info.get("so_guardas"):
        exigir(info.get("cores_por_sessao", 0) > 0, f"{tipo} (só guardas) não rende cores — virou enfeite")
        continue
    exigir(info["bonus"], f"{tipo} não dá bônus em nada — o ponto virou enfeite")
    for recurso in info["bonus"]:
        exigir(recurso in recursos_validos, f"{tipo} dá bônus em '{recurso}', que o AFK não soma")
    exigir("rende" not in info and "produz_material" not in info,
           f"{tipo} ainda PRODUZ recurso — o ponto agora só multiplica")

# o AFK aplica o bônus em cima do que o trabalho rendeu
from game.clan_repo import aplicar_bonus_do_ponto
extra = aplicar_bonus_do_ponto({"comida": 40, "madeira": 30, "couro": 0, "ouro": 10,
                                "material": {1: 20, 2: 4}}, {"madeira": 1.2, "material": 1.0})
exigir(extra["madeira"] == 36 and extra["comida"] == 0,
       f"o bônus de madeira não foi aplicado só na madeira: {extra}")
exigir(extra["material"] == {1: 20, 2: 4}, f"o bônus de material não vale pra todo rank: {extra}")
fonte = open(os.path.join(RAIZ, "game", "clan_repo.py"), encoding="utf-8").read()
corpo = fonte[fonte.index("def rodar_afk("):]
exigir("aplicar_bonus_do_ponto(" in corpo, "o rodar_afk não aplica o bônus do ponto — virou enfeite")

# ── 👹 covis: um por andar de chefe, o ponto mais guardado ──────────────
covis = [p for p in mapa if p["tipo"] == "covil"]
exigir(len(covis) == 30 and all(p["andar"] % 5 == 0 for p in covis),
       "o Covil não está 3 vezes em cada andar de chefe (e só neles)")
for c in covis:
    andar = T.andar_do_ponto(c["tier"])
    exigir(f"Andar {andar}" in c["nome"], f"o covil do tier {c['tier']} não é do andar {andar}")
g_covil = next((p for p in covis if p["tier"] == 5 and p["dono_tipo"] == "bot"), None)
if g_covil:
    exigir(g_covil["guarnicao"] > T.guarnicao_bot(5),
           "o covil guardado por bot não é mais difícil que um ponto comum do mesmo tier")

if falhas:
    print("\n❌ TERRITÓRIO COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("\n✅ mapa justo: 3 de cada tipo por andar, covil nos de chefe, refúgios intocáveis, perda gradual, bônus de +100% a +150%")
