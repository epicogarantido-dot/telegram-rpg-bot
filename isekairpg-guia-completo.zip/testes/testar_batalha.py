#!/usr/bin/env python3
"""Fase 3 (20/09): batalha pelo ponto entre dois jogadores, no banco.

As regras do dev, conferidas uma a uma:
- guardas contra guardas (a equipe do ponto de cada um); sem equipe do
  ponto não se marcha contra outro clã;
- QUEM VENCE ROUBA OS COLETORES do outro e os GUARDAS de quem perdeu MORREM
  — nos dois sentidos (atacar e perder custa caro);
- defensor configurado pra FUGIR entrega o ponto e ninguém morre;
- o personagem de guarda soma poder na defesa, e toda rota da Torre recusa
  quem está de guarda.
"""
import sys, os, json, tempfile, types, re

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

BANCO = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = BANCO
from game import clan_repo as CR
from game import clan_batalha as B

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


class Dado:
    def __init__(self, v): self.v = v
    def random(self): return self.v


CR.init_clan()
mapa = CR.listar_mapa()


def clan(dono, guarda_estrelas, n_guardas, n_coletores, nivel=20):
    CR.carregar_clan(dono)
    ids = {"g": [], "c": []}
    with CR._conn() as c:
        c.execute("UPDATE clan SET andar = 5, comida = 500 WHERE owner_id = ?", (dono,))
        for i in range(n_guardas):
            cur = c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial, fadiga,"
                            " descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
                            (dono, f"G{dono}-{i}", "guarda", nivel, 1, 0, 0, 0, 1,
                             json.dumps({"guarda": guarda_estrelas})))
            ids["g"].append(cur.lastrowid)
        for i in range(n_coletores):
            cur = c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial, fadiga,"
                            " descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
                            (dono, f"C{dono}-{i}", "agricultor", 5, 1, 0, 0, 0, 1,
                             json.dumps({"agricultor": 2})))
            ids["c"].append(cur.lastrowid)
        c.commit()
    r = CR.montar_equipe(dono, CR.EQUIPE_DO_PONTO, ids["c"], ids["g"], 30)
    exigir(r["ok"], f"não montou a equipe do ponto de {dono}: {r}")
    return ids


def dar_ponto(dono, ponto):
    with CR._conn() as c:
        c.execute("UPDATE territorio SET dono_tipo='jogador', dono_id=?, dono_nome=?, integridade=100 WHERE id=?",
                  (str(dono), f"Clã {dono}", ponto["id"]))
        c.execute("UPDATE clan SET ponto_id = ? WHERE owner_id = ?", (ponto["id"], dono))
        c.commit()


def vivos(dono):
    return {h["nome"] for h in CR.listar_habitantes(dono)}


pontos = [p for p in mapa if not p["seguro"] and p["andar"] == 5][:3]

# ── 1) ataque vence: guardas do defensor morrem, coletores vêm pro atacante
A, D = 101, 102
ia, idd = clan(A, 3, 2, 1), clan(D, 1, 1, 2)
dar_ponto(D, pontos[0])
r = CR.conquistar_ponto(A, pontos[0]["id"], "Clã A", Dado(0.0))
exigir(r.get("venceu") and r.get("mortos") == 1 and r.get("roubados") == 2, f"o ataque vencedor não matou/roubou: {r}")
exigir(CR.ponto(pontos[0]["id"])["dono_id"] == str(A), "o ponto não passou pro atacante")
exigir({"C102-0", "C102-1"} <= vivos(A) and not ({"C102-0", "C102-1"} & vivos(D)),
       "os coletores do defensor não foram pra aldeia do atacante")
exigir("G102-0" not in vivos(D), "o guarda do defensor sobreviveu à derrota")

# ── 2) ataque perde: guardas do ATACANTE morrem e coletores dele vão pro defensor
A2, D2 = 201, 202
clan(A2, 1, 1, 2), clan(D2, 3, 2, 1)
dar_ponto(D2, pontos[1])
r = CR.conquistar_ponto(A2, pontos[1]["id"], "Clã A2", Dado(0.9999))
exigir(r.get("venceu") is False and r.get("mortos") == 1 and r.get("roubados") == 2,
       f"o atacante derrotado não perdeu guardas e coletores: {r}")
exigir({"C201-0", "C201-1"} <= vivos(D2), "os coletores do atacante derrotado não foram pro defensor")
exigir(CR.ponto(pontos[1]["id"])["dono_id"] == str(D2), "o defensor vencedor perdeu o ponto")

# ── 3) defensor que foge: ponto muda de dono e ninguém morre
A3, D3 = 301, 302
clan(A3, 1, 1, 0 + 1), clan(D3, 5, 3, 2)
dar_ponto(D3, pontos[2])
CR.definir_defesa(D3, "fugir")
antes = vivos(D3)
r = CR.conquistar_ponto(A3, pontos[2]["id"], "Clã A3", Dado(0.9999))
exigir(r.get("venceu") and r["batalha"]["resultado"] == "fuga", f"o defensor que foge lutou: {r}")
exigir(vivos(D3) == antes, "alguém morreu ou foi levado numa fuga")
exigir(CR.ponto(pontos[2]["id"])["dono_id"] == str(A3), "a fuga não entregou o ponto")
exigir(CR.equipes_do_cla(D3).get(CR.EQUIPE_DO_PONTO) is None, "a equipe que fugiu continuou no ponto")

# ── 4) sem equipe do ponto não se marcha; o personagem de guarda soma
sem = 401
CR.carregar_clan(sem)
with CR._conn() as c:
    c.execute("UPDATE clan SET andar = 5, comida = 500 WHERE owner_id = ?", (sem,))
    c.commit()
exigir(not CR.conquistar_ponto(sem, pontos[0]["id"], "Sem", Dado(0.0))["ok"],
       "marchou contra outro clã sem equipe do ponto")
CR.definir_guarda_pessoal(A, B.poder_do_personagem(40))
E_ = 501
clan(E_, 1, 1, 1)            # um novo atacante, com equipe do ponto
r = CR.conquistar_ponto(E_, pontos[0]["id"], "Clã E", Dado(0.9999))
exigir(r.get("batalha", {}).get("defesa", 0) >= B.poder_do_personagem(40),
       f"o personagem de guarda não somou na defesa: {r}")

# ── 5) toda rota da Torre passa pelo _exigir_fora_da_guarda (26/09: que TIRA
#       o personagem da guarda/batalha do clã sozinho, com aviso)
api = open(os.path.join(RAIZ, "webapp", "api.py"), encoding="utf-8").read()
for rota in re.findall(r'@app\.post\("(/api/(?:tower|combate)/[^"]+)"\)', api):
    corpo = api[api.index(f'@app.post("{rota}")'):]
    corpo = corpo[:corpo.index("@app.", 10)]
    exigir("_exigir_fora_da_guarda(p)" in corpo, f"{rota} deixa entrar quem está de guarda")

if falhas:
    print("❌ BATALHA PELO PONTO COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ batalha pelo ponto: quem vence rouba coletores e mata guardas (nos dois sentidos), "
      "fuga sem mortes, guarda pessoal soma, Torre travada pra quem está de guarda")
