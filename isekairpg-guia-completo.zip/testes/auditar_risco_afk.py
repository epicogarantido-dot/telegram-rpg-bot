#!/usr/bin/env python3
"""Auditoria da curva de risco do AFK.

Mesma lógica do auditor de storylets: com morte permanente, um posto que
ninguém racionalmente escolhe é conteúdo que existe e nunca é visitado — e
um posto estritamente dominado é pior ainda, porque quem escolhe está só
perdendo cavaleiro à toa.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from game.clan_risco import risco_expedicao, previsao, poder_do_membro

# Tabela de exemplo. Quando os postos de verdade existirem, é só trocar aqui.
# ⚠️ A primeira versão desta tabela só tinha postos de PRODUZIR, e o auditor
# acusou "Guardar o celeiro nunca é a melhor escolha". Estava certo — e o
# erro era meu: guardar o celeiro não produz, ele PROTEGE. Medido só por
# rendimento, proteção sempre perde, porque está no eixo errado.
#
# Postos têm dois tipos. "produz" rende recursos; "protege" corta a perda
# quando o clã é atacado ou alguém passa fome. Comparar os dois pelo mesmo
# número é o que fazia o posto seguro parecer inútil.
POSTOS = [
    {"id": "celeiro",   "nome": "Guardar o celeiro",  "perigo": 5,  "rende": 0,
     "tipo": "protege", "protege": "comida", "reduz_perda": 0.60},
    {"id": "escolta",   "nome": "Escoltar os fracos", "perigo": 20, "rende": 0,
     "tipo": "protege", "protege": "membros", "reduz_perda": 0.45},
    {"id": "caca",      "nome": "Caçar nas matas",    "perigo": 15, "rende": 24,
     "tipo": "produz"},
    {"id": "fronteira", "nome": "Patrulhar fronteira","perigo": 30, "rende": 50,
     "tipo": "produz", "raro": "mapa_ponto", "chance_raro": 0.08},
    {"id": "ruinas",    "nome": "Vasculhar ruínas",   "perigo": 65, "rende": 92,
     "tipo": "produz", "raro": "material_raro", "chance_raro": 0.20},
    {"id": "abismo",    "nome": "Descer ao abismo",   "perigo": 95, "rende": 160,
     "tipo": "produz", "raro": "membro_perdido", "chance_raro": 0.30},
]

def auditar():
    problemas, avisos = [], []

    # 1. dominância: posto com risco maior E rendimento menor que outro
    produz = [x for x in POSTOS if x.get("tipo", "produz") == "produz"]
    protege = [x for x in POSTOS if x.get("tipo") == "protege"]
    for a in produz:
        for b in produz:
            if a is b: continue
            if a["perigo"] >= b["perigo"] and a["rende"] <= b["rende"] and \
               (a["perigo"] > b["perigo"] or a["rende"] < b["rende"]):
                if not a.get("raro"):
                    problemas.append(f"'{a['nome']}' é dominado por '{b['nome']}' — "
                                     f"mais perigoso e rende menos, sem nada raro pra compensar")

    # 2. todo posto é o ótimo de ALGUÉM? senão ninguém o escolhe nunca
    otimos = set()
    for nivel in range(1, 121, 2):
        membro = {"level": nivel}
        melhor, valor = None, -1
        for p in produz:
            pr = previsao(membro, p)
            r = pr["risco"] / 100
            total = pr["esperado"] * (1 / r if r > 0 else 0)
            if total > valor: melhor, valor = p["id"], total
        otimos.add(melhor)
    # Postos de proteção não entram nesta conta: eles não rendem, e cobrá-los
    # por rendimento foi exatamente o erro que gerou o falso "nunca é ótimo".
    nunca = [p for p in produz if p["id"] not in otimos]
    for p in nunca:
        if p.get("raro"):
            avisos.append(f"'{p['nome']}' nunca é o ótimo por números — só se paga "
                          f"pelo '{p['raro']}' que ele dá e mais ninguém dá")
        else:
            problemas.append(f"'{p['nome']}' NUNCA é a melhor escolha em nível nenhum, "
                             f"e não oferece nada exclusivo — ninguém vai escolher")

    # 3. área segura demais? risco zero tira o peso do AFK
    for p in POSTOS:
        r = previsao({"level": 120}, p)["risco"]
        if r <= 0.51 and p["perigo"] > 30:
            avisos.append(f"'{p['nome']}' vira {r}% pra quem é forte — perigo virou enfeite")

    # 4. saturação: dois postos de perigos bem diferentes com risco quase
    # igual. O mais perigoso rende mais pelo mesmo preço — dominância
    # disfarçada, e é onde a curva logística engana.
    for nivel in (20, 40, 60, 100):
        for i, a in enumerate(produz):
            for b in produz[i+1:]:
                ra = previsao({"level": nivel}, a)["risco"]
                rb = previsao({"level": nivel}, b)["risco"]
                if ra <= 0.01 and rb <= 0.01: continue
                if abs(ra - rb) < max(ra, rb) * 0.15 and abs(a["perigo"] - b["perigo"]) >= 20:
                    maior = a if a["rende"] > b["rende"] else b
                    menor = b if maior is a else a
                    avisos.append(
                        f"nv{nivel}: '{menor['nome']}' e '{maior['nome']}' têm risco quase "
                        f"igual ({ra:.1f}% x {rb:.1f}%), mas '{maior['nome']}' rende "
                        f"{maior['rende']} contra {menor['rende']} — saturação da curva")
                    break

    # 5. o ótimo se move com o nível? senão a progressão não muda nada
    caminho = []
    for nivel in (5, 20, 40, 60, 90, 120):
        melhor, valor = None, -1
        for p in produz:
            pr = previsao({"level": nivel}, p)
            r = pr["risco"] / 100
            total = pr["esperado"] * (1 / r if r > 0 else 0)
            if total > valor: melhor, valor = p["nome"], total
        caminho.append(f"nv{nivel}→{melhor}")
    if len(set(c.split('→')[1] for c in caminho)) == 1:
        problemas.append("o posto ótimo NUNCA muda com o nível — progredir não muda a decisão")

    print("=" * 70)
    print(f"AUDITORIA DO RISCO DO AFK — {len(POSTOS)} postos")
    print("=" * 70)
    # Duas tabelas: encrenca e morte. Mostrar só o produto esconde a leitura
    # que o jogador realmente faz — "10% de encrenca, e se der, 25% de não
    # voltar" se entende; "2,5%" não diz nada sobre o que acontece lá fora.
    print(f"\nCHANCE DE ENCRENCA")
    print(f"{'posto':>22} {'perigo':>7} " + "".join(f"{'nv'+str(n):>8}" for n in (20,40,60,100)))
    for p in POSTOS:
        linha = f"{p['nome']:>22} {p['perigo']:>7} "
        for n in (20, 40, 60, 100):
            linha += f"{previsao({'level': n}, p)['incidente']:>7.1f}%"
        print(linha)
    print(f"\nSESSÕES ATÉ MORRER (3 expedições por sessão)")
    print(f"{'posto':>22} {'perigo':>7} " + "".join(f"{'nv'+str(n):>8}" for n in (20,40,60,100)))
    for p in POSTOS:
        linha = f"{p['nome']:>22} {p['perigo']:>7} "
        for n in (20, 40, 60, 100):
            m = previsao({'level': n}, p)['risco'] / 100
            viva = (1 - m) ** 3
            linha += f"{(1/(1-viva) if viva < 1 else 999):>8.0f}"
        print(linha)
    print(f"\ncaminho do ótimo (só postos que produzem): {'  '.join(caminho)}")
    print(f"postos de proteção: {', '.join(x['nome'] for x in protege)} "
          f"— julgados por perda evitada, não por rendimento")

    print(f"\n❌ PROBLEMAS: {len(problemas)}")
    for x in problemas: print("   ", x)
    print(f"\n⚠️  AVISOS: {len(avisos)}")
    for x in avisos: print("   ", x)
    print()
    print("🟢 nenhum posto inalcançável" if not problemas else "❌ há posto que ninguém escolheria")
    return not problemas

sys.exit(0 if auditar() else 1)
