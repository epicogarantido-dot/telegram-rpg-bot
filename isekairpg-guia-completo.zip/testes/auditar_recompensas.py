#!/usr/bin/env python3
"""Auditoria do XP por monstro e da rota da autobatalha.

POR QUE ESTE TESTE EXISTE
-------------------------
Dois achados de 20/09, dos que não aparecem em tela de erro nenhuma:

1. **XP fixo em 10 do andar 1 ao 100.** O custo do nível sobe
   (`xp_next = 100 + 50*(nível-1)`) e o teto de nível é `andar*2`, que
   OBRIGA a subir de andar. Com XP fixo, subir de nível no andar 100
   custava 1.005 monstros — 67 vezes mais que no andar 1. O jogo ficava
   exponencialmente mais lento exatamente onde exige mais.

2. **A autobatalha travava a tela.** A rota `/api/combate/auto` resolvia
   a luta e pulava `_pos_combate_explorar`/`_pos_combate_onda`, que toda
   outra ação de combate chama. Sem eles a resposta não trazia o
   snapshot, o front pedia `/api/tower/combat` (que dá 400 quando o
   combate acabou) e a tela ficava parada no começo da batalha. O
   jogador pagava 500⭐ e via travar.

O primeiro é medido de verdade. O segundo é conferido no CÓDIGO da
rota: rodar a rota aqui exigiria FastAPI e banco, e o que precisa não
voltar é a AUSÊNCIA das duas chamadas.
"""
import sys, os, re

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


# ── 1) Ritmo de XP ───────────────────────────────────────────────────────
# `xp_por_monstro` é importada do logic.py e não recopiada: auditoria que
# reimplementa a fórmula mede a si mesma (armadilha nº 3). O import é
# isolado porque o logic.py puxa o banco inteiro junto.
def _xp_por_monstro():
    fonte = open(os.path.join(RAIZ, "game", "logic.py"), encoding="utf-8").read()
    inicio = fonte.index("def xp_por_monstro(")
    fim = fonte.index("def _on_enemy_killed(", inicio)
    escopo = {}
    exec(fonte[inicio:fim], escopo)
    return escopo["xp_por_monstro"]


xp_por_monstro = _xp_por_monstro()


def xp_next(nivel: int) -> int:
    return 100 + (int(nivel) - 1) * 50


# 26/09/2026 (dev): o monstro COMUM vale 10 fixo; elite, general e boss
# crescem com o andar. Então o ritmo se mede com a MISTURA REAL que o
# gerador sorteia em cada andar (monsters.pesos_do_andar) — do andar 30 em
# diante não existe monstro comum, e medir só o comum mediria um andar que
# ninguém joga.
import sys as _sys, types as _types
_sys.path.insert(0, RAIZ)
_sys.modules.setdefault("aiosqlite", _types.ModuleType("aiosqlite"))
from game.monsters import pesos_do_andar


def xp_medio(andar: int) -> float:
    w = pesos_do_andar(andar)
    tot = sum(w.values()) or 1
    return sum(xp_por_monstro(andar, tipo) * peso for tipo, peso in w.items()) / tot


print("andar | nível teto | XP médio/monstro | monstros por nível")
pior = 0
for andar in (1, 5, 10, 25, 50, 75, 100):
    nivel_teto = andar * 2            # a trava de gain_xp: level <= andar*2
    xp = xp_medio(andar)
    kills = xp_next(nivel_teto) / xp
    pior = max(pior, kills)
    print(f"{andar:5d} | {nivel_teto:10d} | {xp:16.0f} | {kills:6.1f}")

exigir(pior <= 40,
       f"o pior andar exige {pior:.0f} monstros por nível — o XP voltou a "
       "não acompanhar o custo do nível")

# A ordem importa mais que o número: andar fundo não pode ser MAIS lento
# que andar raso, que era o defeito original.
ritmo = [xp_next(a * 2) / xp_medio(a) for a in range(1, 101)]
exigir(max(ritmo) - min(ritmo) <= 20,
       f"o ritmo varia demais entre andares ({min(ritmo):.0f} a {max(ritmo):.0f} "
       "monstros por nível)")

# Elite, boss e raid pagam mais que o monstro comum do mesmo andar.
exigir(xp_por_monstro(30, "elite") > xp_por_monstro(30), "elite não paga mais que comum")
exigir(xp_por_monstro(30, "boss") > xp_por_monstro(30, "elite"), "boss não paga mais que elite")
exigir(xp_por_monstro(30, "normal", True) == xp_por_monstro(30) * 10, "a raid perdeu o 10x")

# ── 1b) O monstro NÃO paga mais ouro, e paga XP e material ───────────────
# 20/09 (dev): ouro virou salário do reino (diárias, login, arena, missões
# de iniciante) — monstro dá XP e material. Antes ele pagava 10 + 2×andar,
# e o bloco aqui garantia que o ouro CAÍA; agora garante o contrário, pra
# ninguém reintroduzir a torneira sem querer.
import types as _types
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    _falso = _types.ModuleType("aiosqlite")
    _falso.connect = lambda *a, **k: (_ for _ in ()).throw(
        RuntimeError("auditar_recompensas não deve tocar no banco"))
    sys.modules["aiosqlite"] = _falso

from game.logic import _on_enemy_killed

print("\nandar | ouro | material na mochila")
for andar in (1, 10, 50, 100):
    jogador = {"gold": 0, "level": 1, "xp": 0, "xp_next": 10 ** 9,
               "tower_floor": andar, "hp": 100, "hp_max": 100,
               "pets": {"deck": [None] * 5}, "inv": {"cores": {}, "items": {}},
               "combat": {"enemies": [{"name": "Alvo", "hp": 0, "hp_max": 10,
                                       "floor": andar, "tipo": "boss",
                                       "cores_drop": []}], "target": 0}}
    _on_enemy_killed(jogador, 0)
    material = sum(int(v) for v in (jogador.get("materiais_torre") or {}).values())
    print(f"{andar:5d} | {jogador['gold']:4d} | {material:3d}")
    exigir(jogador["gold"] == 0, f"monstro do andar {andar} voltou a pagar ouro")
    exigir(jogador["xp"] > 0, f"monstro do andar {andar} não pagou XP")
    exigir(material > 0, f"chefe do andar {andar} não deixou material")


# ── 2) A rota da autobatalha faz o pós-combate ───────────────────────────
api = open(os.path.join(RAIZ, "webapp", "api.py"), encoding="utf-8").read()
inicio = api.index('@app.post("/api/combate/auto")')
corpo = api[inicio:api.index("@app.", inicio + 10)]
for chamada in ("_pos_combate_explorar", "_pos_combate_onda", "_montar_snapshot_combate"):
    exigir(chamada in corpo,
           f"/api/combate/auto voltou a pular {chamada} — a tela trava no "
           "começo da luta depois de autobatalhar")

app_js = open(os.path.join(RAIZ, "webapp", "static", "app.js"), encoding="utf-8").read()
exigir("aoTerminar(r)" in app_js,
       "o botão da autobatalha não repassa mais o snapshot pro pós-combate")

if falhas:
    print("\n❌ RECOMPENSAS/AUTOBATALHA COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print(f"\n✅ XP acompanha o andar ({min(ritmo):.0f} a {max(ritmo):.0f} monstros por "
      "nível) e a autobatalha fecha o combate")
