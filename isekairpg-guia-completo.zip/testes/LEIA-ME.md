# Testes

Oito verificações que rodam contra o código-fonte, sem precisar subir o
servidor nem instalar as dependências. São as que pegaram bugs de verdade
durante a migração.

## `testar_imports.py`
Confere os 204 `from x import y` que ficam **dentro** das rotas. Import
tardio só falha quando a rota é chamada — um nome errado ficaria escondido
até alguém tocar no botão, e apareceria como 500 pro jogador.

## `testar_backend.js`
Nas 123 rotas:
- toda rota protegida exige sessão, e toda rota de admin exige a senha
- toda rota que muda o jogador grava no banco
- todo serviço da cidade tem o portão (`_exigir_cidade`)

Rota nova que esquecer qualquer um dos três quebra aqui.

## `testar_varredura.js`
- todo caminho que o front chama existe no servidor (404 silencioso)
- nenhuma tela ficou órfã do menu
- nenhuma função definida e nunca chamada
- estados vazios que dizem o próximo passo

## `testar_estado_jogador.py`
Grava um jogador com 23 campos preenchidos, relê do banco e exige que nada
tenha sumido nem mudado de valor.

### Os bugs que ele pega
`save_player_sql` só grava os campos de uma lista à mão (`_extra_fields`).
O que não tem coluna e não está nela é **descartado em silêncio** — sem erro,
sem aviso. Ler o código não pega: o código parece certo dos dois lados.

A lista já mordeu quatro vezes. As duas últimas foram relatadas juntas:
recompensa diária infinita (`daily_login_date` sumia, então nunca era "hoje")
e subir andar sem efeito (`tower_choice` sumia, e `/api/tower/advance`
recarrega do banco pra decidir). Antes disso foram `pending_orders` /
`conta_em_analise` (o Pix) e `conta_bloqueada` (o bloqueio do admin que se
desfazia sozinho no reinício).

O teste confere também o caminho inteiro do resgate diário: resgata, grava,
relê e exige que o segundo resgate seja recusado.

## `testar_schema_cla.py`
Monta o banco **como estava em produção** — tabela velha, com dados dentro
—, roda `init_clan()` e exige que as colunas apareçam, que nada se perca e
que rodar de novo não mude nada.

### O bug que ele pega
`sqlite3.OperationalError: no such column: equip_poder` na tela do clã.
`CREATE TABLE IF NOT EXISTS` não faz nada numa tabela que já existe: o banco
de produção nasceu antes de `equip_poder`, `equip_rank`, `perfil_json` e
`perfil_nivel`, e as tabelas do clã nunca tiveram migração. Lendo o código o
schema parecia certo; no disco estava errado.

A correção não foi acrescentar um ALTER por coluna que faltou — seria a
mesma armadilha esperando a próxima. `TABELAS` em `clan_repo.py` virou a
única fonte: o CREATE sai dela e a migração também.

## `testar_fome.py`
E2E do laço da comida: roda `rodar_afk` contra um SQLite de verdade e
confere que o consumo é cobrado, que a fome é **gravada**, que quem fica na
aldeia se recupera, que o estoque nunca fica negativo nem passa do teto, e
que fome e ferimento invalidam o perfil guardado.

Existe porque o auditor mede os números e este mede a gravação — e neste
projeto a falha foi exatamente essa: `fome` existia como campo, já
derrubava poder numa fórmula, e mesmo assim não acontecia nada, porque
ninguém escrevia nela.

## `testar_telegram.js`
Roda o bloco do Telegram do `app.js` contra três clientes: um que existe e
**estoura tudo** (fora do Telegram), um navegador sem Telegram nenhum, e um
cliente antigo de verdade. Exige que nada suba, que o login por `initData`
continue de pé, e que nenhuma chamada crua a `tg.` tenha voltado.

### O bug que ele pega
O jogo travava no "carregando" com `WebAppMethodUnsupported`. O index
carrega `telegram-web-app.js` sempre, e fora do Telegram esse script **mesmo
assim** cria `window.Telegram.WebApp` — então `if (tg)` não provava nada.
`tg.ready()` na terceira linha do arquivo, no escopo do módulo, derrubava
todo o resto do app.js: `entrarNoJogo()` nunca chegava a ser definido.
Optional chaining não protege, porque o método existe e só estoura quando
chamado.

## `testar_trava.py`
Confere que a trava por jogador morre com a **requisição**, e não com a
thread: rota de leitura solta, rota que estoura solta, rota que carrega
dois jogadores solta os dois, duas requisições do mesmo jogador ainda se
serializam, jogadores diferentes não esperam um pelo outro, e trava presa
por um sumido vira 409 em vez de espera infinita.

### O bug que ele pega
Era o travamento do "Explorar". A trava ficava num `threading.local()` e
era solta "no começo do próximo `_carregar_jogador`", apostando que o
threadpool reaproveitaria a thread — ele não reaproveita. `GET /api/explore`
é rota de leitura, nunca chama `_salvar_jogador`, então prendia a trava
numa thread; o `POST /api/explore/go` seguinte caía noutra e esperava pra
sempre. O front ficava no "carregando", e cada tentativa prendia mais uma
thread do pool até o processo inteiro parar — bot incluso, porque roda no
mesmo event loop. Medido: **38 rotas** pegavam a trava e nunca soltavam.

O `contextvars.copy_context()` do teste é exatamente o que o
`anyio.to_thread.run_sync` faz por baixo do FastAPI. É por isso que a caixa
por requisição funciona e o `threading.local()` não funcionava.

## `rodar_tudo.sh`
Roda a suíte inteira: os cinco testes acima e os cinco auditores.

⚠️ Até 17/09/2026 este script chamava **nove arquivos que não existem**
neste repositório (`executar_appjs.js`, `testar_abas.js`,
`testar_cidade.js`, `testar_login.js`, `testar_criacao.js`,
`testar_expirado.js` e a pasta `teste_contas/` inteira). Ele saía sempre
com `❌ ALGO FALHOU`, então o resultado dos testes que de fato rodavam
sumia no ruído — num projeto cuja primeira regra é "medir antes e depois",
a suíte tinha virado um carimbo vermelho sem informação. Se aqueles
arquivos reaparecerem, é só voltar a linha deles.

Auditor que sai com **2** está *pulado* (falta `aiosqlite`, rodando fora do
servidor), não falhou.

---

**Por que isso existe:** a checagem de sintaxe não executa nada. Durante a
migração, `node --check` passou num `app.js` ao qual eu tinha apagado 475
linhas por engano — inclusive o menu inteiro. Quem pegou foi a varredura.

## `auditar_storylets.py`
Roda 10 mil partidas simuladas e conta quantas vezes cada storylet apareceu
e cada opção foi escolhida. **Contagem zero é bug.**

Pega seis coisas:
- storylet que nunca aparece, com o motivo mais comum da recusa
- opção que nunca é escolhida, mesmo com o evento saindo
- opção estritamente dominada (outra é melhor ou igual em tudo)
- arco que abre e não fecha (flag criada e nunca lida)
- teste que nunca falha ou nunca passa
- turno com o saco vazio — o jogo sem nada pra oferecer

Rode depois de escrever ou mexer em qualquer storylet.

A política de simulação escolhe ao acaso de propósito: um jogador que joga
BEM visita menos conteúdo, não mais — ele converge pra estratégia que
funciona. O passeio aleatório cobre mais.

**Validado com bugs plantados.** Oito defeitos foram inseridos de propósito
(condição impossível, opção trancada, opção dominada, teste impossível,
teste que sempre passa, agenda apontando pro vazio, evento sem saída, teste
sem consequência de falha) e o auditor pegou os oito, sem acusar nada no
catálogo limpo. Auditor que nunca acusa é decoração.

## `auditar_risco_afk.py`
Audita a tabela de postos do AFK. Com morte permanente, posto que ninguém
escolheria não é só conteúdo morto — é cavaleiro perdido à toa.

Checa:
- posto dominado (mais perigoso e rende menos, sem nada exclusivo)
- posto que nunca é o ótimo em nível nenhum
- perigo que vira enfeite pra quem é forte
- se o posto ótimo se move com o nível (senão progredir não muda a decisão)

**Postos de produzir e de proteger são julgados em eixos diferentes.** A
primeira versão comparava tudo por rendimento e acusou "Guardar o celeiro
nunca é a melhor escolha" — estava certo pelo número e errado pelo jogo:
guardar o celeiro não produz, evita perda. Comparar os dois pela mesma
conta é o que fazia o posto seguro parecer inútil.

### A correção estrutural que a medição obrigou

A primeira versão do risco era "chance de morrer por expedição". A
composição destruía o jogo: risco 6%, 3 expedições por sessão, dá 83% de
voltar vivo — o cavaleiro morre em menos de uma semana. Com 1 expedição por
hora e 8h de sono, 61%.

Risco por expedição passou a ser **chance de incidente**, e a morte é um
resultado do incidente. A maior parte das expedições é sem graça; quando dá
encrenca, aí existe teste. O incidente é o storylet do AFK.

E a chance de morrer NO incidente é linear na margem, sem saturar. A de
encrenca satura, e o auditor pegou o efeito: no nível 20, perigo 65 e
perigo 95 davam risco quase igual, mas o de 95 rendia o dobro. Risco igual
com prêmio maior é dominância disfarçada — curva logística é ótima em
esconder isso.

## `auditar_areas_afk.py`
Monta o perfil de risco de cada nível em cada área e checa se a tabela é
jogável: área que mata em qualquer nível, área segura pra todos, faixa de
nível sem nenhuma opção, e se a melhor área acessível melhora conforme
subir de nível.

### A ideia que torna o AFK barato

Não se simula combate por tick. Simula-se **uma vez** por (membro, área),
contra cada tipo de inimigo que sai lá, e guarda-se o resultado. Depois o
tick só rola dado contra a tabela.

Medido: 39 ms para montar um perfil, 2,6 µs por tick. Vinte mil ticks em
52 ms, sem tocar no motor de combate.

E o perfil é estável — o mesmo confronto deu o mesmo resultado em 8 de 8
sementes, porque o combate da Torre é praticamente determinístico. Isso me
atrapalhou quando tentei tirar uma curva de risco dele, e aqui é justamente
o que faz o perfil valer.

O efeito colateral bom: o número vira frase. Em vez de "3,2% de risco", a
tela diz **"vence os comuns, morre se esbarrar no chefe"** — e a chance de
morrer É literalmente a chance de encontrar o chefe.

## A conta que definiu a cadência do AFK

Tick de 15 min, 30% dos ticks virando encontro: 8 horas fora dão 32 ticks e
~10 encontros. Um cavaleiro de perfil 5,9% ("morre se esbarrar no chefe")
tem **43% de não estar lá de manhã**. Ninguém joga assim.

Mas baixar o teto de ticks pra consertar cortaria junto o que o jogador
recebe — storylets pra ler, recursos pra gastar. Ficaria seguro e vazio.

Por isso são **dois tetos**, e é o ponto do desenho:

    TETO_TICKS = 24      quanto o mundo andou (recursos, storylets, membros)
    TETO_ENCONTROS = 4   quanto perigo o cavaleiro comeu

Quanta história você recebe e quanto risco você corre são recursos
diferentes. Fundir os dois num número só foi o erro da primeira conta.

Com encontros em 4: perfil 0% é eterno, 5,9% dura ~5 sessões, 29% dura ~1.
Área folgada é folgada, esticar custa caro, e a diferença é visível antes
de mandar.

E tempo acima do teto não rende: três dias fora não vira 300 situações.
Isso não é recompensa, é dever de casa — e faz o jogador evitar voltar.

## `auditar_materiais.py`
Checa se cada rank de material é farmável por alguém. Rank cujo andar exige
um nível que ninguém alcança mata junto o equipamento daquele rank — some
uma faixa inteira de progressão e o jogo continua rodando.

### A medição que definiu quantos ranks existem

O mapa é a própria Torre: cada andar é uma área de AFK. Mas o nível é
travado em `andar * 2` (gain_xp), e medindo até onde o AFK fica seguro com
esse teto:

    seu andar   nível máx   farma até   fração
         10          20          6       60%
         30          60         22       73%
         60         120         31       52%
        100         200         49       49%

**A fronteira é ~metade do seu andar**, e no fim do jogo ela para no andar
49 — tier 5 de 10 da tabela de monstros.

Se o rank viesse do tier do andar, os **tiers 6 a 10 nunca seriam
farmáveis**: cinco ranks de conteúdo que ninguém alcança. Por isso são 5
ranks em 1–50, não 10 em 1–100.

E isso separa os pilares: a Torre ativa é onde VOCÊ vai fundo; o AFK é onde
o clã trabalha atrás de você.

A medição foi feita sem equipamento. Quando ele entrar na conta de verdade,
vale rodar de novo — se a fronteira passar do andar 50 com folga, cabe um
rank 6.

## `testar_imagens.js`
Confere que toda arte é pedida no tamanho em que vai ser desenhada.

As artes vêm do Telegram em ~1280px e são desenhadas a 30–84px. A auditoria
antes de mexer achou **1 de 9 `<img>` com `loading="lazy"`** e nenhuma
pedindo tamanho. Economia medida por imagem: 97% em retrato (w=64), 93% em
quadro (w=128), 80% em banner médio.

Pillow é **opcional** de propósito — a lição do `python-multipart`: pacote
faltando não pode derrubar funcionalidade. Sem ele o jogo serve a original,
que funciona e só gasta mais banda.

A largura pedida é o **dobro** do CSS, por causa de tela retina, e só as
quatro da lista são aceitas — largura livre deixaria qualquer um encher o
disco pedindo dez mil variações da mesma arte.

## `auditar_fome.py`
Pergunta se o **laço da comida fecha**: a ração cabe na renda? a fome morde?
existe saída? o Celeiro faz alguma coisa?

### O bug que ele pega
Durante meses `comida` foi um número que só subia. Nada consumia, `fome`
nunca era escrita por ninguém, e `teto_comida` estava declarado na tabela de
comodidades **sem ser lido em lugar nenhum do projeto** — o jogador pagava
60 de material rank 1 pelo Celeiro e recebia exatamente zero.

### O que a medição mostrou
A primeira medição achou um teto duro: só o **Andar 1** alimentava, porque
a regra é `comida if andar <= 5` e `areas_disponiveis` andava de 5 em 5. A
renda ficava em ~24 por sessão em qualquer nível. O passo virou 2 em 2 até
o andar 10, então a faixa rasa tem três andares (1, 3, 5) e postar no Andar
5 rende ~85. Com 1 ração por membro postado a cada 4 ticks (6 por sessão
cheia):

| configuração | saldo | o déficit custa |
|---|---|---|
| 3 postados, 1 na comida | +67 | — |
| 3 postados, nenhum na comida | −18 | 8🥉 de 74 (10%) |
| 5 postados, 1 na comida | +53 | — |
| 5 postados, nenhum na comida | −30 | 12🥉 de 196 (6%) |

É esse o desenho: cedo, alimentar custa um **corpo** (alguém tem que ficar
no andar raso, que não rende material); tarde, custa **bronze**, via o
serviço `mantimentos` da aldeia, que já existia justamente pra isso. A
pressão fica no começo, que é quando há pouca gente.

### A mordida
Fome no teto muda a chance de morte em **5 de 16** combinações de (área,
nível), com saltos de +23 a +47 pontos. Não muda nada pra quem está muito à
frente nem pra quem já estava perdido — morde exatamente na fronteira. Na
prática, clã com fome farma cerca de meia faixa mais raso.

⚠️ A fome morde pelos **atributos do perfil** (`clan_repo.penalizar_modelo`),
não por `clan_risco.poder_do_membro`. Aquele módulo desconta fome e
ferimento numa fórmula bonita e **não é importado por ninguém fora dos
testes** — quem decide vida e morte no AFK é `clan_afk.montar_perfil`, que
só olha atributo. Descontar lá e achar que isso mudava o jogo foi
exatamente o que manteve a fome de enfeite.

---

## `auditar_catalogo_imagens.py`

Confere que o catálogo da aba **Imagens** do `/admin` pede as MESMAS chaves
que o jogo pede rodando: gera monstro em todos os 100 andares, item em todo
slot e raridade, e todo pet e montaria, e exige que cada chave resultante
esteja catalogada. Sem isso o painel vira a segunda cópia da regra de nomes
— a armadilha nº 3.

O que ele mediu ao nascer (20/09): **334 chaves pedidas, 79 faltando**.
Três achados que o contador do espelho (`/api/admin/imagens`) não tinha como
mostrar, porque ele só conta o que JÁ ESTÁ no `assets.py`:

- **15 montarias sem chave nenhuma.** `explore.py` pede `MOUNT_{id}` e não
  existe um único `MOUNT_` no `assets.py`. Toda montaria do jogo mostra a
  arte da Cidade, desde sempre.
- **24 artes que existem e nunca aparecem.** Estão gravadas com acento
  (`MOB_XAMÃ_GOBLIN`) e o combate pede sem (`MOB_XAMA_GOBLIN`), porque
  `resolver_asset_key_inimigo` troca só alguns acentos. Arte paga, subida,
  invisível.
- **38 chaves com acento**, que `imagens.chave_valida` recusa: `/api/imagem`
  devolve 400 e o espelho nunca as baixa. São todas as raças acentuadas
  (Gárgula, Demônio, Aberração...) nos andares normais.

Os dois últimos foram fechados no mesmo dia por `assets.normalizar_chave`:
**79 → 55 faltando, 38 → 0 inválidas**, sem uma arte nova. O auditor agora
trava os dois (nenhuma chave inválida, e a normalização conferida em quatro
nomes difíceis, com parêntese e com `+`).

## `testar_admin.js`

Executa o JavaScript do `admin.html` num DOM de mentira e desenha o
catálogo com os quatro estados de chave e com um grupo que estourou.
`node --check` não pega nada disso (armadilha nº 21).

Pegou de cara um bug que estava no ar: o laço que troca de aba listava só
`pix`, `conta` e `imagens`, então clicar em **Backup** escondia as outras
três e não mostrava nada — a aba existia e era inalcançável. Hoje o teste
lê os `data-aba` do próprio HTML e recusa aba descoberta.

## `auditar_pet_skills.py`

Mede o equilíbrio das 4 opções de batalha dos pets simulando combates com
o MOTOR de verdade (`pet_arena._apply_pet_action`), não com uma cópia da
fórmula.

Duas réguas, porque uma só não separa nada: contra o time que **só dá
ataque básico** (piso — a skill tem que pagar o turno que custa) e contra
o time que **varia as três** (teto — nenhuma pode ganhar sozinha, senão as
outras duas viram decoração). Comparar as três entre si, que era a
tentação, premiaria automaticamente a de recarga mais curta.

Mediu na primeira rodada, e mudou o desenho por causa disso: com a escala
de raridade em 2x, o time lendário ganhava **100%** das partidas — porque
os atributos de pet JÁ escalam quase 9x por raridade (`80` de vida no
comum contra `700` no lendário), e a skill cobrava a raridade uma segunda
vez. A escala caiu pra 1,30x e o que o lendário ganha virou **ritmo**:
1 turno a menos de recarga.

Também varre todo campo do livro de skills contra o que `pet_arena.py`
realmente lê — campo que nada lê é enfeite (armadilha nº 10).

## `auditar_arena.py`

Confere que a tela da Arena PvP e a rota que a alimenta falam a mesma
língua. Desde que a Arena passou a usar o desenho da batalha da Torre, a
tela lê campos (`img_key`, `spd`, `bar`, `escudo`, `dots`) que só existem
porque `_montar_snapshot_arena` passou a mandá-los. Tirar um deles não
estoura nada: vira `undefined`, e a luta continua funcionando com barra em
0% e retrato vazio. O teste cobre as duas pontas — campo lido que ninguém
manda, e campo mandado que ninguém lê.

Também trava o retrato do adversário: ele sai do personagem vivo
(`load_player`), porque `arena_snapshots` não guarda raça nem sexo e
acrescentar coluna lá exigiria migração — a armadilha nº 14, que já
estourou em produção com `no such column`.

Junto com isso, `executar_appjs.js` passou a EXECUTAR `desenharArenaCombate`
e `ladoDoDuelo` (inclusive as telas de vitória e derrota). É um pedaço do
furo descrito no cabeçalho dele sendo fechado: telas `desenhar*` recebem o
snapshot pronto e, ao contrário das `render*`, não precisam de servidor.
Para isso o stub de áudio teve que cobrir `linearRampToValueAtTime` e o de
`style`, `setProperty` — faltando eles, quebrava o teste, não o app.

## `auditar_aldeia.py` e `testar_aldeia.py`

A aldeia viva (20/09) tem duas redes, pela distinção que este projeto
aprendeu a fazer: **desenho** e **gravação**.

`auditar_aldeia.py` simula o laço puro (`game/clan_habitantes.py`) e mede
cada promessa do desenho. Pegou dois defeitos antes de chegar no jogo:
com Exausto rendendo 40%, trabalhar sem parar rendia só 8% menos que fazer
rodízio — o descanso não valia a sessão parada. Caiu pra 25% e o rodízio
passou a render 42% mais. E a Aura: na primeira versão, zero despertares
aconteciam num ataque, que é o coração da ideia ("vendo a família em
perigo"). Hoje a chance da crise é escrita direto e medida: 34%.

`testar_aldeia.py` roda a gravação num SQLite de verdade, começando de um
banco VELHO (a migração tem que criar as colunas novas — armadilha nº 14),
e força um RECUA pra conferir que o `ferimento` chega no disco. Foi provado
que ele pega o bug antigo: desligando a gravação, o teste fica vermelho.

## `testar_ouro_e_forja.py`

A troca de bronze/prata por ouro (20/09) mexeu em três economias ao mesmo
tempo, e cada uma quebra em silêncio de um jeito:

- **Chave esquecida.** Um `"bronze"` que sobrasse num `producao` seria
  somado por ninguém — recurso sumindo sem erro. O teste varre `game/`,
  `webapp/` e o conteúdo dos storylets atrás de chave viva.
- **Forja cobrando pela metade.** Descontar ouro e depois descobrir que
  falta material cobraria por nada. O teste confere que, sem material,
  nem ouro nem core saem — e que a mochila é gasta antes do clã (provado
  por mutação: desligando a ordem, fica vermelho).
- **Comida paga e jogada fora.** O celeiro tem teto; o teste confere que
  só se paga o que entrou.

E trava um achado de brinde: as recompensas de ouro/comida das decisões
agora chegam de verdade (`_aplicar_recursos_reais` nas duas rotas).

## `testar_migracoes.py`

Fecha a armadilha nº 14 pras 19 tabelas que ainda não tinham migração.
Não lista tabela nenhuma: varre os módulos atrás das constantes `_SQL_*`,
monta cada tabela no formato mais velho possível (só a primeira coluna),
roda `infra.migracao.garantir_colunas` e exige todas as colunas do CREATE.
Também exige que o init CHAME a migração com cada constante (provado por
mutação: tirando a chamada do `raid_rooms`, fica vermelho) e recusa
`execute("CREATE TABLE ...")` solto fora do padrão.

## `testar_modo_so_site.py`

O `main.py` estourava sem `BOT_TOKEN` — nem o site subia. O teste importa
o `main.py` sem token, com aiogram/uvicorn substituídos, e exige modo só
site: sem Bot, sem polling, API como processo principal. Provado por
mutação: recolocando o `raise`, fica vermelho.

## `testar_modo_so_site.py` (reescrito em 20/09)

O bot do Telegram foi removido. O teste agora importa o `main.py` SEM
nenhum `aiogram` (nem falso), roda `main()` e exige banco preparado + API
servida; varre o projeto recusando qualquer import de aiogram, telebot ou
dos arquivos do bot, e confere que o `requirements.txt` não os pede mais.
O `testar_telegram.js` teve uma checagem invertida: o `index.html` não
carrega mais o script do Mini App.

## `auditar_jornada.py` e `testar_jornada.py` (reescritos em 20/09)

A jornada virou TRAVESSIA: só pro andar seguinte, batalhas contra o relógio
com reforço crescente. A auditoria usa o mesmo modelo de lutador do AFK e
trava: grupo "no ponto" (nível 2×andar) atravessa E vence batalhas em todo
andar; metade do ponto não passa (do andar 10 em diante); decidir fere
menos que ficar parado; reforço cresce a cada estouro; destino só o
próximo andar alcançado. O E2E confere no banco que chegar muda o andar
do clã, e que comida, material, memória e ferimento gravam.

## `auditar_postos.py`

Postos por andar, achados explorando. Trava: a lista cresce com o andar;
a busca acha em ~60% e o TIPO é sorteado (quem quer veio acha bosque);
o raro sai bem menos que o comum; a ★ também é sorte; cada andar se esgota
(um de cada tipo) e explorar esgotado não acha; todo posto vira área que o
AFK entende. O E2E (`testar_jornada.py`) confere no banco: Clareira inicial,
explorar cobra comida e grava o achado, posto fora do alcance não trabalha,
e a Travessia revela um posto ao chegar. A caixa de exploração saiu de
dentro do `renderClan` pra virar construtor puro coberto pelo
`executar_appjs.js` (o furo documentado no topo dele).

## `auditar_logistica.py`

Posto longe da aldeia perde no caminho e a rota pode ser emboscada; o
posto avançado resolve. Trava: longe chega menos (até o piso), a emboscada
tem teto, o posto avançado mais que dobra o que chega de 10 andares, as
vagas crescem com o estágio, e o `rodar_afk` LÊ os dois números. O E2E
(`testar_jornada.py`) confere no banco o custo e o efeito do posto avançado
e o limite de vagas.

## Limpeza do Telegram (20/09)

`testar_telegram.js` foi apagado: ele protegia o app DENTRO do cliente do
Telegram, e o Mini App saiu junto com o bot. O `testar_modo_so_site.py`
passou a recusar qualquer resto (login `tma`, instância do bot, download de
arte pelo Telegram, `window.Telegram`/vibração do cliente no app.js,
script no index.html). `auditar_logistica.py` também saiu: a logística
entre andares foi retirada quando o dev definiu que o clã só trabalha no
andar onde está (coberto em `testar_jornada.py`).

## `testar_guia.js`
Roda as funções reais do guia de clique num DOM de mentira que redesenha a
tela L ms depois do toque (como a resposta do servidor faz), e conta os
toques do jogador que o guia bloqueou. Antes de 28/09 o guia travava a
partir de 300 ms: agarrava o botão velho e engolia o toque no novo.

## `testar_chefe_novato.py`
Trava o 5º e o 10º andar (faixa do novato): o chefe é vencível por quem
chega no ponto e continua derrotando quem não gastou os pontos; o portal do
andar de chefe só abre vencendo o chefe; metade das lutas ali são capangas
(senão quem subiu fraco ficava preso — não dá pra descer); do 15º em diante
o chefe é o de antes. Antes de 28/09: 0 vitórias em 20 no ponto, e o afoito
passava morrendo de graça até o 11º, onde ficava 5 h trancado.

## `testar_cavaleiro.py`
Do aldeão ao cavaleiro, com banco sqlite temporário (inclui soldo em ouro e morar na cidade): aldeão desperto vira
personagem (nome da aldeia, 4 pontos de trilha por ★ de aura); personagem
extra Nv.10+ vira cavaleiro (guarda 5★ do nível dele, 10× o poder de
um guarda 5★, 10 guardas na guarnição, 12h de treino, 60 ferro + 40 couro). Imprime a tabela
de poder: personagem de guarda × guarda 3★/5★ × cavaleiro.

## `testar_convidado.py`
Começar como convidado: conta sem usuário e senha, id negativo que não
colide com o cadastro seguinte (mostra que colidia sem a tabela
`convidados`), sessão de anos, limite por IP, "Salvar progresso" dando
usuário e senha à mesma conta, e 12 convidados simultâneos com ids distintos.

## `testar_recompensa.py` e `testar_janela_recompensa.js`
Janela de recompensa. O Python confere o pacote da vitória contra o que
entrou de verdade (XP, cores), nível novo, derrota sem pacote e XP travado
no teto do andar. O JS roda o componente real da janela: leve no fim da luta
(sem botão, fecha sozinha, não repete), core de habilidade como raro, e a
janela do clã com botão, gastos e dica quando a aldeia não produziu.

## `testar_miticos.py`
Gatilhos dos míticos que faziam o contrário ou nada (Cinturão do Avatar
cortava a cura; Fúria Titânica nunca ligava sem a especialidade; Dama de
Ferro não tinha rebote base) e o catálogo da Fusão: 45 itens com arte
própria, gatilho em português e a habilidade na versão do mítico (65% da
força, um alvo), não a da skill normal.

## `testar_criacao_fluxo.js`
Roda o app.js INTEIRO num DOM simulado (montado a partir do index.html real)
com um servidor de mentira, e toca nos botões da criação: sexo → raça →
profissão → habilidade (ou só sexo → habilidade com `--nascido`). Confere
que o menu de baixo fica apagado durante a criação e que o jogo só abre no
fim. `--falha=abertura:N` / `--falha=habilidade:N` fazem o servidor falhar N
vezes a pergunta "ainda falta criar?": antes de 28/09 uma falha fazia o jogo
abrir com o personagem pela metade e o menu aceso.

## `testar_guia_real.js` (+ `ponte/servidor_real.py`)
O teste mais completo do projeto: sobe as rotas REAIS de webapp/api.py num
HTTP mínimo (a ponte, com banco temporário), roda o app.js inteiro num DOM
falso honesto (clique passa pela captura do document antes do botão, botão
desabilitado não recebe clique, `.oculto` não tem tamanho) e joga como um
jogador novo: convidado → criação → nome → o guia inteiro, tocando só onde
ele manda. A cada passo também toca FORA do alvo e confere que o guia segurou.
Pegou em 28/09: no passo "Peça pronta!" o guia liberava o Continuar antes de
conferir que ele era o alvo — o toque não contava e a Forja do tutorial
travava com todos os toques bloqueados.

## `testar_perfil_real.js` (+ `ponte/navegador_falso.js`)
Perfil público contra o servidor real: dois convidados; o "Leitor" abre o
ranking no app.js inteiro e toca no nome do "Rival". Confere que abre a
ficha dele só leitura (sem trocar nome, sem barras de vida/XP), com
Habilidades e Especialidades, que a rota não entrega ouro/⭐/XP/vida, que
"‹ Ranking" volta e que tocar no próprio nome abre a sua ficha.
O navegador falso agora mora em `ponte/navegador_falso.js` e é usado também
pelo `testar_guia_real.js`.
