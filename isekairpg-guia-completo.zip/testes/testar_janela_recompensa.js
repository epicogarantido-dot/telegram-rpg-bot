// 🎁 Janela de recompensa (28/09): roda o componente REAL do app.js num DOM
// de mentira e confere o que ele monta.
// - fim da luta: janela leve, sem botão, fecha sozinha, aparece UMA vez por
//   pacote (mesma resposta desenhada duas vezes não repete);
// - itens: XP, cores (skill = raro), material, banner de nível;
// - clã: janela cheia com botão, seção de gastos e dica quando não rendeu.
const fs = require('fs'), vm = require('vm'), path = require('path');
const src = fs.readFileSync(path.join(path.dirname(__dirname), 'webapp/static/app.js'), 'utf8');
const ini = src.indexOf('let JANELA_RECOMPENSA = null;');
const fim = src.indexOf('// 🎁 banner do clã');
if (ini < 0 || fim < 0) { console.log('❌ não achei o componente'); process.exit(1); }
const bloco = src.slice(ini, fim);

function criar(tag) {
  return { tag, className: '', textContent: '', filhos: [], style: { setProperty() {} }, classList: { add() {} },
    append(...xs) { this.filhos.push(...xs); }, appendChild(x) { this.filhos.push(x); return x; },
    remove() { this.removido = true; } };
}
const corpo = criar('body');
const timers = [];
const ctx = vm.createContext({
  document: { body: corpo, createElement: criar },
  el: (t, c, x) => { const e = criar(t); e.className = c || ''; e.textContent = x || ''; return e; },
  setTimeout: (f, ms) => { timers.push(ms); return 1; }, clearTimeout() {},
  vibrar() {}, som: { raro() { ctx.__som = 'raro'; }, moeda() { ctx.__som = 'moeda'; } },
});
vm.runInContext(bloco + '\nthis.__j = () => JANELA_RECOMPENSA;', ctx);

let falhas = 0;
const exigir = (c, m) => { console.log((c ? '✅ ' : '❌ ') + m); if (!c) falhas++; };
const todos = (n, acc = []) => { acc.push(n); (n.filhos || []).forEach((f) => todos(f, acc)); return acc; };
const comClasse = (n, cls) => todos(n).filter((x) => (x.className || '').split(' ').includes(cls));

// fim da luta
const pacote = { id: 'a1', xp: 25, nivel: 4, material: { Bruto: 2 },
  cores: { wa_atk: { nome: 'Core de Arma ATK', qtd: 1, tier: 1, skill: false },
           core_fire_1: { nome: 'Bola de Fogo', qtd: 1, tier: 1, skill: true } } };
ctx.talvezMostrarRecompensaDaLuta({ recompensa: pacote });
let j = ctx.__j();
exigir(j && j.className.includes('leve') && typeof j.onclick === 'function', 'fim da luta: janela leve no topo, cobrindo o fundo (o toque fecha ela, não passa pro jogo)');
exigir(comClasse(j, 'recomp-botao').length === 0, 'fim da luta: sem botão de fechar (fecha sozinha ou com toque)');
exigir(timers.length === 1 && timers[0] === 1500, `fim da luta: fecha sozinha em 1,5s (${timers[0]} ms)`);
const itens = comClasse(j, 'recomp-item');
exigir(itens.length === 4, `XP, 2 cores e material viram ${itens.length} linhas (esperado 4)`);
exigir(itens.filter((x) => x.className.includes('raro')).length === 1 && ctx.__som === 'raro',
       'core de habilidade aparece como raro (e toca o som de raro)');
exigir(comClasse(j, 'recomp-nivel').length === 1, 'subiu de nível: banner "Nível 4!"');
const qtd = corpo.filhos.length;
ctx.talvezMostrarRecompensaDaLuta({ recompensa: pacote });
exigir(corpo.filhos.length === qtd, 'a mesma resposta desenhada de novo não repete a janela');
ctx.talvezMostrarRecompensaDaLuta({ recompensa: null });
exigir(corpo.filhos.length === qtd, 'luta sem pacote (fuga/derrota) não abre janela');

// clã
ctx.janelaRecompensa({ titulo: 'O clã não produziu', itens: [],
  gastos: [{ icone: '🍖', texto: 'Comida consumida', valor: '-150' }], dica: 'monte equipes', botao: 'Entendi' });
j = ctx.__j();
exigir(!j.className.includes('leve') && comClasse(j, 'recomp-botao').length === 1, 'clã: janela cheia com botão');
exigir(comClasse(j, 'recomp-gasto').length === 1 && comClasse(j, 'recomp-dica').length === 1,
       'clã sem ganho: mostra os gastos da aldeia e a dica (não fica vazia)');

console.log(falhas ? `❌ ${falhas} falha(s)` : '✅ janela de recompensa ok');
process.exit(falhas ? 1 : 0);
