#!/usr/bin/env python3
"""A aldeia por equipes (fase 1, 20/09) — as regras do dev, medidas.

- a maioria dos talentos é 0★ (e 0★ = não pode); nem todos podem ser guardas;
- 5★ produz 4× o 1★; lenhador na clareira não produz;
- coletor para no nível 20; guarda vai a 20 × estrelas (5★ = 100); só aura
  passa do 100;
- guarda come e gasta mais (manutenção);
- a ameaça do andar cresce mais que linear — fundo pede MAIS guardas;
- faltar qualquer recurso de manutenção = greve.
"""
import sys, os, random, statistics

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
from game import clan_equipes as E

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


rng = random.Random(1)
ts = [E.sortear_talentos(rng) for _ in range(20000)]
zeros = statistics.mean(sum(1 for v in t.values() if v == 0) / len(t) for t in ts)
guardas = sum(1 for t in ts if t["guarda"] >= 1) / len(ts)
print(f"talentos 0★: {100 * zeros:.0f}% · podem ser guarda: {100 * guardas:.0f}%")
exigir(zeros >= 0.55, f"só {100 * zeros:.0f}% dos talentos são 0★ — a maioria devia ser")
exigir(0.10 <= guardas <= 0.35, f"{100 * guardas:.0f}% podem ser guarda — nem todos deviam poder")
exigir(all(any(t[p] for p in E.COLETA) for t in ts), "alguém chegou sem talento de coleta nenhum")

exigir(E.mult_estrelas(5) == 4 * E.mult_estrelas(1), "5★ não produz 4× o 1★")
exigir(E.mult_estrelas(0) == 0, "0★ produz")
h = {"talentos": {"lenhador": 3}, "nivel": 1}
exigir(E.producao_do_coletor(h, "madeira") > 0 and E.producao_do_coletor(h, "comida") == 0,
       "o lenhador não produz madeira, ou produz comida")

exigir(E.nivel_maximo({"funcao": "coletor", "talentos": {"agricultor": 5}}) == 20, "coletor passa do 20")
for n in range(1, 6):
    exigir(E.nivel_maximo({"funcao": "guarda", "talentos": {"guarda": n}}) == 20 * n,
           f"guarda {n}★ não tem teto {20 * n}")
exigir(E.nivel_maximo({"funcao": "guarda", "talentos": {"guarda": 4}, "aura": 3}) == 80,
       "aura deixou um guarda 4★ passar do teto — só o 5★ passa do 100")
exigir(E.nivel_maximo({"funcao": "guarda", "talentos": {"guarda": 5}, "aura": 2}) > 100,
       "guarda 5★ com aura não passa do 100")

coletor = E.manutencao_da_aldeia([{"funcao": "coletor"}])
guarda = E.manutencao_da_aldeia([{"funcao": "guarda"}])
exigir(guarda["comida"] > coletor["comida"] and guarda["couro"] > 0 and guarda["ferro"] > 0,
       "guarda não custa mais que coletor (comida, couro, ferro)")
exigir(E.falta_pra_manter({"comida": 5, "madeira": 0}, {"comida": 3, "madeira": 1}) == {"madeira": 1},
       "falta_pra_manter não aponta o que falta")

a10, a40 = E.ameaca_do_andar(10), E.ameaca_do_andar(40)
exigir(a40 > 4 * a10, "a ameaça do andar não cresce mais que linear")
g1 = {"nivel": 20, "talentos": {"guarda": 1}}
print(f"ameaça andar 10: {a10} ({-(-a10 // E.poder_do_guarda(g1))} guardas 1★ Nv20) · "
      f"andar 40: {a40} ({-(-a40 // E.poder_do_guarda(g1))})")
r = E.resultado_da_saida([g1], 40, random.Random(1))
exigir(r["ferido"] and r["fator"] < 1, "um guarda fraco no andar 40 não sofreu nada")

if falhas:
    print("❌ EQUIPES COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ equipes: talento raro, 5★ = 4× o 1★, tetos de nível, guarda caro, fundo pede mais guarda")
