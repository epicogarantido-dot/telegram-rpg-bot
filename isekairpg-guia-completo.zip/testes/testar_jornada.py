#!/usr/bin/env python3
"""E2E da travessia no banco.

Confere a GRAVAÇÃO — onde este projeto mais perdeu coisa em silêncio:
- só dá pra atravessar pro andar SEGUINTE ao do clã, e só se o jogador já
  chegou nele;
- partir tira a comida do celeiro na hora; uma travessia por vez; lutador
  em posto não parte;
- chegar MUDA o andar do clã, põe o material no estoque e vai pras Memórias;
- quem caiu volta com ferimento no disco; a comida que sobrou volta.
"""
import sys, os, random, tempfile, types

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

BANCO = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = BANCO
from game import clan_repo as CR
from game import clan_jornada as T

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


def forte(slot):
    return {"slot": slot, "nome": f"L{slot}", "hp": 10 ** 6, "hp_max": 10 ** 6, "atk": 10 ** 5,
            "def": 10 ** 5, "acc": 200, "eva": 0, "crit": 0}


CR.init_clan()
DONO = 5
CR.carregar_clan(DONO)
with CR._conn() as c:
    c.execute("UPDATE clan SET comida = 300, materiais = '{}' WHERE owner_id = ?", (DONO,))
    for slot in range(3):
        c.execute("INSERT INTO clan_membro(owner_id, slot, nome, nivel) VALUES (?,?,?,?)",
                  (DONO, slot, f"L{slot}", 50))
    c.commit()
exigir(int(CR.carregar_clan(DONO)["andar"]) == 1, "o clã não começa no Andar 1")

lut = [forte(i) for i in range(3)]
r = CR.iniciar_jornada(DONO, lut, 100, andar_max=1)
exigir(not r["ok"], "atravessou pra um andar que o jogador ainda não alcançou")

with CR._conn() as c:
    c.execute("UPDATE clan_membro SET area_id = 'andar1' WHERE owner_id = ? AND slot = 0", (DONO,))
    c.commit()
exigir(not CR.iniciar_jornada(DONO, lut, 100, andar_max=5)["ok"], "partiu com lutador no posto")
with CR._conn() as c:
    c.execute("UPDATE clan_membro SET area_id = NULL WHERE owner_id = ?", (DONO,))
    c.commit()
exigir(CR.carregar_clan(DONO)["comida"] == 300, "tentativa recusada cobrou comida")

levar = T.comida_maxima(2, 3)
r = CR.iniciar_jornada(DONO, lut, 10_000, andar_max=5, rng=random.Random(1))
exigir(r["ok"] and r["jornada"]["destino"] == 2, f"do Andar 1 o destino não foi o 2: {r}")
exigir(r["ok"] and r["jornada"]["comida_levada"] == levar, "a carroça não respeitou o limite")
exigir(CR.carregar_clan(DONO)["comida"] == 300 - levar, "partir não tirou a comida do celeiro")
exigir(not CR.iniciar_jornada(DONO, lut, 50, andar_max=5)["ok"], "duas travessias ao mesmo tempo")

t = CR.jornada_atual(DONO)
rng = random.Random(2)
while not t["fim"]:
    T.avancar(t, rng, 60)
CR.gravar_jornada(DONO, t)
exigir(t["fim"] == "sucesso", f"um grupo imbatível não atravessou: {t['fim']}")
comida_antes = CR.carregar_clan(DONO)["comida"]
final = CR.encerrar_jornada(DONO, t)
clan = CR.carregar_clan(DONO)
exigir(int(clan["andar"]) == 2, f"chegar não mudou o andar do clã: {clan['andar']}")
for rank, qtd in final["material"].items():
    exigir(clan["materiais"].get(int(rank), 0) == qtd, "o material da travessia não entrou no estoque")
exigir(clan["comida"] == comida_antes + final["comida_volta"], "a comida que sobrou não voltou")
exigir(any("atravessou" in m["texto"] for m in clan["memorias"]), "a travessia não foi pras Memórias")
exigir(final.get("posto_revelado") and final["posto_revelado"]["andar"] == 2,
       f"chegar ao Andar 2 não revelou um posto de lá: {final.get('posto_revelado')}")
exigir(CR.jornada_atual(DONO) is None, "a travessia encerrada continuou gravada")

# a próxima é do 2 pro 3 — e quem cai volta ferido no disco
r = CR.iniciar_jornada(DONO, lut, 100, andar_max=5, rng=random.Random(3))
exigir(r["ok"] and r["jornada"]["destino"] == 3, "a segunda travessia não foi do 2 pro 3")
t = CR.jornada_atual(DONO)
for m in t["grupo"]:
    m["hp"] = 0
T.recuar(t)
CR.encerrar_jornada(DONO, t)
exigir(int(CR.carregar_clan(DONO)["andar"]) == 2, "recuar mudou o andar do clã")
feridos = [m["ferimento"] for m in CR.listar_membros(DONO)]
exigir(all(f >= 5 for f in feridos), f"quem caiu não voltou ferido grave: {feridos}")

# ── 🔎 postos: começa com a Clareira, o resto se acha explorando ─────────
with CR._conn() as c:
    c.execute("UPDATE clan SET andar = 1, comida = 500 WHERE owner_id = ?", (DONO,))
    c.commit()
areas = CR.areas_do_cla(DONO, tower_floor=30)
exigir("p1_clareira" in areas, f"o clã não começa com a Clareira do Andar 1: {sorted(areas)}")
exigir(all(a["andar"] == 1 for a in areas.values()),
       f"o clã no Andar 1 trabalha em posto de outro andar: {sorted(areas)}")
exigir(not CR.explorar_andar(DONO, 9, tower_floor=30)["ok"],
       "explorou um andar que o clã ainda não alcança")

# lutador num posto fora do alcance volta
with CR._conn() as c:
    c.execute("UPDATE clan_membro SET area_id = 'p9_veio' WHERE owner_id = ? AND slot = 1", (DONO,))
    c.commit()
voltaram = CR.recolher_fora_do_alcance(DONO, areas)
exigir(voltaram == ["L1"], f"o lutador num posto fora do alcance não voltou: {voltaram}")

# no Andar 9, explorar gasta comida e (às vezes) acha
with CR._conn() as c:
    c.execute("UPDATE clan SET andar = 9 WHERE owner_id = ?", (DONO,))
    c.commit()
rng = random.Random(7)
achados, tentativas = [], 0
while not achados and tentativas < 30:
    tentativas += 1
    antes = CR.carregar_clan(DONO)["comida"]
    r = CR.explorar_andar(DONO, 9, tower_floor=30, rng=rng)
    exigir(r["ok"], f"explorar o Andar 9 falhou: {r}")
    exigir(CR.carregar_clan(DONO)["comida"] == antes - r["custo"], "explorar não cobrou a comida")
    if r["achado"]:
        achados.append(r["achado"]["id"])
exigir(achados, "30 buscas no Andar 9 e nada achado")
if achados:
    exigir(achados[0] in CR.areas_do_cla(DONO, tower_floor=30), "o posto achado não virou área do AFK")
    exigir(achados[0] not in CR.areas_do_cla(DONO, tower_floor=5),
           "o clã trabalha num posto de andar que o JOGADOR ainda não alcançou")

# ── só os postos do andar ONDE o clã está ─────────────────────────────────
exigir(not CR.explorar_andar(DONO, 8, tower_floor=30)["ok"],
       "explorou um andar que não é o do clã")
with CR._conn() as c:
    c.execute("UPDATE clan SET andar = 10 WHERE owner_id = ?", (DONO,))
    c.commit()
exigir(all(a["andar"] == 10 for a in CR.areas_do_cla(DONO, tower_floor=30).values()),
       "o clã no Andar 10 ainda trabalha num posto de outro andar — os de trás ficam pra trás")
if achados:
    exigir(achados[0] not in CR.areas_do_cla(DONO, tower_floor=30),
           "o posto do Andar 9 continuou sendo trabalhado depois que o clã foi pro 10")

if falhas:
    print("❌ TRAVESSIA (E2E) COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ travessia no disco: só o próximo andar alcançado, comida sai e volta, "
      "chegar muda o andar do clã e revela um posto, explorar cobra e acha, "
      "e o clã só trabalha e explora o andar onde está")
