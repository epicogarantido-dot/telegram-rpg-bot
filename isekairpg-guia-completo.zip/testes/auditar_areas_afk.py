#!/usr/bin/env python3
"""Auditoria das áreas de AFK.

Mesma pergunta de sempre: existe área que ninguém vai usar? Existe faixa de
nível sem nenhuma área adequada? Com morte permanente, mandar pra área
errada custa um personagem — então a tabela precisa ser legível ANTES.
"""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    import aiosqlite  # noqa: F401
except ImportError:
    print("⚠️  aiosqlite não instalado — rode no servidor, onde ele existe.")
    sys.exit(2)
from game.clan_afk import montar_perfil

AREAS = [
    {"id": "matas",     "nome": "Matas",     "andar": 2,  "rende": 12},
    {"id": "fronteira", "nome": "Fronteira", "andar": 8,  "rende": 30},
    {"id": "ruinas",    "nome": "Ruínas",    "andar": 18, "rende": 70},
    {"id": "abismo",    "nome": "Abismo",    "andar": 32, "rende": 150},
]
NIVEIS = [10, 20, 30, 45, 60, 80, 110]


def modelo(level):
    return {"telegram_id": 1, "level": level, "xp": 0, "xp_next": 9**9, "gold": 0,
            "tower_floor": 1, "hp": 100, "hp_max": 100, "state": "TOWER",
            "class_id": None, "race_id": None,
            "attrs": {"str": level, "vit": level, "agi": level, "dex": level},
            "trails": {}, "combat": None,
            "inv": {"potion": 0, "cores": {}, "items": {}}, "equip": {},
            "pets": {"owned": {}, "deck": [None] * 5},
            "skills_learned": {}, "skill_slots": {"equipped": [None] * 5}, "chakra": None}


t0 = time.perf_counter()
tabela = {(n, a["id"]): montar_perfil(modelo(n), a) for n in NIVEIS for a in AREAS}
print("=" * 74)
print(f"AUDITORIA DAS ÁREAS DE AFK — {len(tabela)} perfis em {(time.perf_counter()-t0)*1000:.0f} ms")
print("=" * 74)
print(f"{'nível':>7} " + "".join(f"{a['nome']:>12}" for a in AREAS))
for n in NIVEIS:
    print(f"{n:>7} " + "".join(f"{tabela[(n,a['id'])]['chance_morte']:>11.1f}%" for a in AREAS))

problemas, avisos = [], []

# 1. área que é suicídio pra TODO nível testado, ou segura pra todos
for a in AREAS:
    mortes = [tabela[(n, a["id"])]["chance_morte"] for n in NIVEIS]
    if min(mortes) >= 99:
        problemas.append(f"'{a['nome']}' mata em qualquer nível testado — ninguém vai usar")
    if max(mortes) <= 0.1:
        problemas.append(f"'{a['nome']}' é segura pra qualquer nível — o perigo é enfeite")

# 2. faixa de nível sem área adequada (nem segura demais, nem mortal)
for n in NIVEIS:
    uteis = [a for a in AREAS if 0 < tabela[(n, a["id"])]["chance_morte"] < 60]
    seguras = [a for a in AREAS if tabela[(n, a["id"])]["chance_morte"] <= 0.1]
    if not uteis and not seguras:
        problemas.append(f"nível {n} não tem nenhuma área utilizável — só armadilha")
    elif not uteis:
        avisos.append(f"nível {n} só tem área de risco zero — nada em jogo, nada a decidir")

# 3. a melhor área acessível melhora com o nível?
melhor_por_nivel = []
for n in NIVEIS:
    acessiveis = [a for a in AREAS if tabela[(n, a["id"])]["chance_morte"] < 60]
    melhor_por_nivel.append(max(acessiveis, key=lambda a: a["rende"])["nome"] if acessiveis else "—")
print(f"\nmelhor área acessível: " +
      "  ".join(f"nv{n}→{m}" for n, m in zip(NIVEIS, melhor_por_nivel)))
if len(set(melhor_por_nivel)) == 1:
    problemas.append("a melhor área acessível nunca muda — subir de nível não abre nada")

# 4. o resumo é útil? "perde pra 3 dos 5" ensina menos que "morre pro chefe"
vagos = sum(1 for k, v in tabela.items() if v["resumo"].startswith("Perde para"))
if vagos > len(tabela) * 0.5:
    avisos.append(f"{vagos} de {len(tabela)} perfis dão resumo vago ('perde para N dos M') — "
                  f"o jogador entende muito melhor 'morre se esbarrar no chefe'")

print(f"\n❌ PROBLEMAS: {len(problemas)}")
for x in problemas: print("   ", x)
print(f"\n⚠️  AVISOS: {len(avisos)}")
for x in avisos: print("   ", x)
print()
print("🟢 tabela de áreas utilizável" if not problemas else "❌ há área que ninguém usaria")
sys.exit(0 if not problemas else 1)
