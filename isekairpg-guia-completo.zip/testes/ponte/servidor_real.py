#!/usr/bin/env python3
"""PONTE: as rotas REAIS do jogo (webapp/api.py) num servidor HTTP mínimo,
sem FastAPI — pros testes de ponta a ponta rodarem o app.js de verdade
contra a lógica de verdade. Lê as rotas dos decoradores @app.get/@app.post,
monta os argumentos pela assinatura (authorization, corpo, request, path)
e devolve o JSON (ou o status + detail de um HTTPException).
Uso: python3 servidor_real.py <porta> <pasta_do_banco>"""
import sys, os, re, json, types, inspect, asyncio, shutil, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

RAIZ = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
PASTA = sys.argv[2]
porta = int(sys.argv[1])
sys.path.insert(0, RAIZ)

# --- dublês mínimos de fastapi/aiosqlite (só se não estiverem instalados)
try:
    import fastapi  # noqa: F401
except ModuleNotFoundError:
    fa = types.ModuleType("fastapi")
    class HTTPException(Exception):
        def __init__(s, status_code=500, detail=None): s.status_code, s.detail = status_code, detail
    class _App:
        def __init__(s, *a, **k): s.router = types.SimpleNamespace(route_class=None)
        def _d(s, *a, **k): return lambda f: f
        get = post = put = delete = middleware = exception_handler = on_event = _d
        def mount(s, *a, **k): pass
        def add_middleware(s, *a, **k): pass
    fa.HTTPException = HTTPException; fa.FastAPI = _App
    fa.Body = fa.Header = fa.File = lambda *a, **k: None
    fa.Response = type("Response", (), {"__init__": lambda s, *a, **k: None})
    fa.Request = type("Request", (), {}); fa.UploadFile = type("UploadFile", (), {})
    resp = types.ModuleType("fastapi.responses")
    class JSONResponse:
        def __init__(s, content=None, status_code=200, **k): s.content, s.status_code = content, status_code
    resp.JSONResponse = JSONResponse; resp.FileResponse = JSONResponse
    est = types.ModuleType("fastapi.staticfiles"); est.StaticFiles = lambda *a, **k: None
    rot = types.ModuleType("fastapi.routing"); rot.APIRoute = type("APIRoute", (), {})
    sys.modules.update({"fastapi": fa, "fastapi.responses": resp, "fastapi.staticfiles": est, "fastapi.routing": rot})
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
    import aiosqlite_minimo as _a  # noqa: F401
    sys.modules["aiosqlite"] = _a

os.makedirs(PASTA, exist_ok=True); os.chdir(PASTA)
shutil.rmtree("data", True); os.makedirs("data")
sys.path.insert(0, RAIZ)
import main  # noqa: E402
asyncio.run(main.preparar_banco())
import webapp.api as A  # noqa: E402
from fastapi import HTTPException  # noqa: E402

ROTAS = []
fonte = open(os.path.join(RAIZ, "webapp", "api.py"), encoding="utf-8").read()
for m in re.finditer(r'@app\.(get|post)\("([^"]+)"\)\s*\n(?:@[^\n]*\n)*(?:async\s+)?def\s+(\w+)\(', fonte):
    metodo, caminho, nome = m.group(1).upper(), m.group(2), m.group(3)
    padrao = "^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", caminho) + "$"
    ROTAS.append((metodo, re.compile(padrao), getattr(A, nome)))


class Tratar(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _responder(self, status, dados):
        b = json.dumps(dados, ensure_ascii=False, default=str).encode()
        self.send_response(status); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

    def _tratar(self, metodo):
        url = urllib.parse.urlparse(self.path)
        query = dict(urllib.parse.parse_qsl(url.query))
        n = int(self.headers.get("Content-Length") or 0)
        corpo = json.loads(self.rfile.read(n) or b"null") if n else None
        for m, padrao, f in ROTAS:
            achou = padrao.match(url.path)
            if m != metodo or not achou:
                continue
            args = {}
            for nome, p in inspect.signature(f).parameters.items():
                if nome == "authorization":
                    args[nome] = self.headers.get("Authorization")
                elif nome in achou.groupdict():
                    args[nome] = achou.group(nome)
                elif nome == "request":
                    args[nome] = types.SimpleNamespace(headers={k.lower(): v for k, v in self.headers.items()},
                                                       client=types.SimpleNamespace(host="127.0.0.1"))
                elif nome in query:
                    args[nome] = query[nome]
                elif nome in ("corpo", "body", "dados", "payload") or (p.annotation and "dict" in str(p.annotation)):
                    args[nome] = corpo
            try:
                r = f(**args)
                if inspect.iscoroutine(r):
                    r = asyncio.run(r)
                status = getattr(r, "status_code", 200) or 200
                if hasattr(r, "content"):                      # dublê do JSONResponse
                    dados = r.content
                elif isinstance(getattr(r, "body", None), (bytes, bytearray)):   # FastAPI de verdade
                    dados = json.loads(r.body or b"null")
                else:
                    dados = r
                self._responder(status, dados)
            except HTTPException as e:
                self._responder(e.status_code, {"detail": e.detail})
            except Exception as e:  # erro de servidor de verdade: 500 com o motivo
                import traceback; traceback.print_exc()
                self._responder(500, {"detail": f"{type(e).__name__}: {e}"})
            return
        self._responder(404, {"detail": f"rota não existe: {metodo} {url.path}"})

    def do_GET(self): self._tratar("GET")
    def do_POST(self): self._tratar("POST")


servidor = ThreadingHTTPServer(("127.0.0.1", porta), Tratar)   # já escutando
print("PRONTO", flush=True)
servidor.serve_forever()
