// 🧪 NAVEGADOR FALSO (28/09) — compartilhado pelos testes de ponta a ponta
// (testar_guia_real.js, testar_perfil_real.js). Roda o app.js INTEIRO num DOM
// falso honesto: clique passa pela captura do document antes do botão,
// botão desabilitado não recebe clique, `.oculto` não tem tamanho, seletores
// com classe/id/[data-x="y"]/descendente/vírgula; fetch vai pra ponte.
const vm = require('vm');

function montarNavegador({ src, html, BASE, ESCALA = 0.3, pilha = false }) {
  // ───────────────────────────── DOM falso, mas honesto
  const porId = {};
  const ouvintesDoc = { click: [] };
  function criar(tag) {
    const classes = new Set();
    const e = {
      tag: String(tag).toLowerCase(), filhos: [], pai: null, _texto: '', dataset: {}, attrs: {},
      style: { setProperty() {}, removeProperty() {}, getPropertyValue: () => '' },
      disabled: false, value: '', type: '', checked: false,
      classList: {
        add: (...c) => c.forEach((x) => classes.add(x)), remove: (...c) => c.forEach((x) => classes.delete(x)),
        toggle: (c, f) => { const v = f === undefined ? !classes.has(c) : !!f; v ? classes.add(c) : classes.delete(c); return v; },
        contains: (c) => classes.has(c),
      },
      get className() { return [...classes].join(' '); },
      set className(v) { classes.clear(); String(v || '').split(/\s+/).filter(Boolean).forEach((x) => classes.add(x)); },
      get id() { return this.attrs.id || ''; }, set id(v) { this.attrs.id = v; porId[v] = this; },
      get textContent() { return this._texto + this.filhos.map((f) => f.textContent || '').join(''); },
      set textContent(v) { this._texto = String(v ?? ''); this.filhos.forEach((f) => (f.pai = null)); this.filhos = []; },
      get innerText() { return this.textContent; }, set innerText(v) { this.textContent = v; },
      get innerHTML() { return ''; }, set innerHTML(v) { this.filhos.forEach((f) => (f.pai = null)); this.filhos = []; this._texto = ''; },
      appendChild(x) { if (x && typeof x === 'object') { if (x.pai) x.remove(); x.pai = this; this.filhos.push(x); } return x; },
      append(...xs) { xs.forEach((x) => (typeof x === 'string' ? this.appendChild(Object.assign(criar('#t'), { _texto: x })) : this.appendChild(x))); },
      prepend(...xs) { xs.reverse().forEach((x) => { if (x.pai) x.remove(); x.pai = this; this.filhos.unshift(x); }); },
      insertBefore(x, ref) { if (x.pai) x.remove(); x.pai = this; const i = this.filhos.indexOf(ref); i < 0 ? this.filhos.push(x) : this.filhos.splice(i, 0, x); return x; },
      remove() { if (this.pai) { this.pai.filhos = this.pai.filhos.filter((f) => f !== this); this.pai = null; } },
      replaceWith(x) { if (!this.pai) return; const p = this.pai, i = p.filhos.indexOf(this); if (x.pai) x.remove(); p.filhos[i] = x; x.pai = p; this.pai = null; },
      setAttribute(k, v) { if (k === 'id') this.id = v; else if (k.startsWith('data-')) this.dataset[camel(k.slice(5))] = String(v); else this.attrs[k] = String(v); },
      getAttribute(k) { return k.startsWith('data-') ? this.dataset[camel(k.slice(5))] ?? null : this.attrs[k] ?? null; },
      removeAttribute(k) { delete this.attrs[k]; },
      addEventListener(t, f) { (this['_ev_' + t] ||= []).push(f); }, removeEventListener(t, f) { this['_ev_' + t] = (this['_ev_' + t] || []).filter((x) => x !== f); },
      focus() {}, blur() {}, select() {}, scrollIntoView() {}, scrollTo() {}, scrollBy() {},
      getBoundingClientRect() { return visivel(this) ? { left: 10, top: 300, right: 110, bottom: 340, width: 100, height: 40 } : { left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 }; },
      querySelector(s) { return buscar(this, s)[0] || null; }, querySelectorAll(s) { return buscar(this, s); },
      matches(s) { return casaLista(this, s); },
      closest(s) { for (let x = this; x; x = x.pai) if (x.tag !== '#t' && casaLista(x, s)) return x; return null; },
      contains(x) { for (let y = x; y; y = y.pai) if (y === this) return true; return false; },
      get isConnected() { for (let y = this; y; y = y.pai) if (y === corpo) return true; return false; },
      get parentNode() { return this.pai; }, get parentElement() { return this.pai; },
      get children() { return this.filhos.filter((f) => f.tag !== "#t"); }, get childNodes() { return this.filhos; }, get firstChild() { return this.filhos[0] || null; },
      get lastChild() { return this.filhos[this.filhos.length - 1] || null; },
      get offsetWidth() { return visivel(this) ? 100 : 0; }, get offsetHeight() { return visivel(this) ? 40 : 0; },
      scrollLeft: 0, scrollTop: 0, clientWidth: 380, clientHeight: 700, scrollWidth: 380, scrollHeight: 700,
      animate() { return { finished: Promise.resolve(), onfinish: null, cancel() {} }; },
    };
    return e;
  }
  const camel = (s) => s.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
  function visivel(e) {
    for (let x = e; x; x = x.pai) {
      if (x.classList && x.classList.contains('oculto')) return false;
      if (x.style && x.style.display === 'none') return false;
      if (x === corpo) return true;
    }
    return false;
  }
  function todos(n, acc = []) { for (const f of n.filhos || []) { if (f.tag !== '#t') acc.push(f); todos(f, acc); } return acc; }
  function casaComposto(e, comp) {
    const re = /(#[\w-]+)|(\.[\w-]+)|(\[[^\]]+\])|(^[a-z][\w-]*)/gi;
    let m, algum = false;
    while ((m = re.exec(comp))) {
      algum = true;
      if (m[1] && e.id !== m[1].slice(1)) return false;
      if (m[2] && !e.classList.contains(m[2].slice(1))) return false;
      if (m[4] && e.tag !== m[4].toLowerCase()) return false;
      if (m[3]) {
        const [, k, v] = m[3].match(/^\[([\w-]+)(?:="?([^"]*)"?)?\]$/) || [];
        const val = e.getAttribute(k);
        if (v === undefined ? val === null : val !== v) return false;
      }
    }
    return algum;
  }
  function casaSeletor(e, sel) {
    const partes = sel.trim().split(/\s+/);
    if (!casaComposto(e, partes[partes.length - 1])) return false;
    let x = e.pai;
    for (let i = partes.length - 2; i >= 0; i--) {
      while (x && !(x.tag !== '#t' && casaComposto(x, partes[i]))) x = x.pai;
      if (!x) return false;
      x = x.pai;
    }
    return true;
  }
  const casaLista = (e, s) => String(s).split(',').some((p) => casaSeletor(e, p));
  const buscar = (raiz, s) => todos(raiz).filter((x) => casaLista(x, s));

  const corpo = criar('body');
  for (const m of html.matchAll(/<([a-z0-9]+)([^>]*)\bid="([^"]+)"([^>]*)>/gi)) {
    const e = criar(m[1]);
    e.className = ((m[0].match(/class="([^"]*)"/) || [])[1]) || '';
    for (const d of m[0].matchAll(/data-([\w-]+)="([^"]*)"/g)) e.dataset[camel(d[1])] = d[2];
    e.id = m[3];
    corpo.appendChild(e);
  }
  // as abas de baixo (o guia toca nelas)
  const barra = porId['barra-abas'];
  for (const m of html.matchAll(/<button[^>]*class="aba-item[^"]*"[^>]*data-grupo="([^"]+)"[^>]*>/g)) {
    const b = criar('button'); b.className = 'aba-item'; b.dataset.grupo = m[1]; barra.appendChild(b);
  }

  // ───────────────────────────── toque como no navegador
  function tocar(e) {
    if (!e || e.disabled) return { bloqueado: true, motivo: e ? 'desabilitado' : 'sem alvo' };
    const ev = { type: 'click', target: e, defaultPrevented: false, parado: false,
      preventDefault() { this.defaultPrevented = true; }, stopPropagation() { this.parado = true; },
      stopImmediatePropagation() { this.parado = true; } };
    for (const f of [...ouvintesDoc.click]) { f(ev); if (ev.parado) break; }
    if (ev.parado || ev.defaultPrevented) return { bloqueado: true, motivo: 'guia' };
    for (let x = e; x && !ev.parado; x = x.pai) {
      if (x.onclick) x.onclick(ev);
      for (const f of x._ev_click || []) f(ev);
    }
    return { bloqueado: false };
  }

  // ───────────────────────────── janela
  const toasts = [], erros = [];
  let recarregou = 0;
  const documento = {
    getElementById: (id) => (porId[id] && porId[id].isConnected ? porId[id] : (porId[id] || null)),
    createElement: (t) => criar(t), createElementNS: (_, t) => criar(t), createTextNode: (t) => Object.assign(criar('#t'), { _texto: String(t) }),
    createDocumentFragment: () => criar('#frag'),
    querySelector: (s) => buscar(corpo, s)[0] || null, querySelectorAll: (s) => buscar(corpo, s),
    addEventListener: (t, f) => { (ouvintesDoc[t] ||= []).push(f); },
    removeEventListener: (t, f) => { ouvintesDoc[t] = (ouvintesDoc[t] || []).filter((x) => x !== f); },
    body: corpo, head: criar('head'), documentElement: criar('html'), hidden: false, activeElement: null,
  };
  const store = {};
  const parametro = () => ({ value: 0, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {}, cancelScheduledValues() {}, setTargetAtTime() {} });
  const janela = {
    document: documento, location: { href: BASE + '/', search: '', pathname: '/', origin: BASE, reload() { recarregou++; } },
    localStorage: { getItem: (k) => store[k] ?? null, setItem: (k, v) => { store[k] = String(v); }, removeItem: (k) => { delete store[k]; } },
    sessionStorage: { getItem: () => null, setItem() {}, removeItem() {} },
    addEventListener() {}, removeEventListener() {}, matchMedia: () => ({ matches: false, addEventListener() {} }),
    fetch: (url, op = {}) => fetch(String(url).startsWith('http') ? url : BASE + url, op),
    navigator: { userAgent: 'teste', onLine: true, vibrate() {} }, innerHeight: 800, innerWidth: 390, scrollY: 0,
    setTimeout: (f, ms) => setTimeout(f, (ms || 0) * ESCALA), clearTimeout,
    setInterval: (f, ms) => setInterval(f, Math.max(5, (ms || 0) * ESCALA)), clearInterval,
    requestAnimationFrame: (f) => setTimeout(() => f(Date.now()), 0), cancelAnimationFrame: clearTimeout,
    confirm: () => true, alert() {}, prompt: () => '', scrollTo() {}, getComputedStyle: () => ({ getPropertyValue: () => '' }),
    AudioContext: function () {
      return { createOscillator: () => ({ connect() {}, start() {}, stop() {}, disconnect() {}, type: 'sine', frequency: parametro(), detune: parametro() }),
        createGain: () => ({ connect() {}, disconnect() {}, gain: parametro() }),
        createBiquadFilter: () => ({ connect() {}, disconnect() {}, type: 'lowpass', frequency: parametro(), Q: parametro() }),
        createBufferSource: () => ({ connect() {}, start() {}, stop() {}, buffer: null }),
        createBuffer: () => ({ getChannelData: () => new Float32Array(1) }), resume() {}, currentTime: 0, sampleRate: 44100, destination: {} };
    },
    Audio: function () { return { play: () => Promise.resolve(), pause() {}, addEventListener() {}, volume: 1, loop: false }; },
    Image: function () { return criar('img'); }, FormData: class {},
    IntersectionObserver: class { observe() {} unobserve() {} disconnect() {} },
    ResizeObserver: class { observe() {} unobserve() {} disconnect() {} },
    MutationObserver: class { observe() {} disconnect() {} },
  };
  janela.window = janela;
  const ctx = vm.createContext({ ...janela, window: janela, document: documento, console, Promise, JSON, Math, Date, URL,
    URLSearchParams, Error, TypeError, Set, Map, WeakMap, Array, Object, String, Number, Boolean, Symbol, RegExp, parseInt,
    parseFloat, isNaN, isFinite, encodeURIComponent, decodeURIComponent, Intl, Float32Array, Uint8Array, performance });
  vm.runInContext(src.replace(/\(async function iniciar\(\) \{/, '(async function __naoIniciar() { return;'), ctx, { filename: 'app.js' });
  vm.runInContext('toast = (m, e) => { __toasts.push([String(m), !!e]); if (e && __pilha) __pilhas.push(String(m) + " <- " + new Error().stack.split("\\n").slice(2, 5).join(" | ")); };',
    Object.assign(ctx, { __toasts: toasts, __pilha: !!process.env.PILHA, __pilhas: (globalThis.__pilhas = []) }));
  if (process.env.PILHA) vm.runInContext(`
    for (const nome of ['forja', 'inventario']) {
      const f = TELAS[nome];
      TELAS[nome] = async function () { try { return await f.apply(this, arguments); } catch (e) { __pilhas.push('[' + nome + '] ' + e.message + ' :: ' + e.stack.split('\\n').slice(1, 4).join(' | ')); throw e; } };
    }
    const _df = desenharForja; desenharForja = function () { try { return _df.apply(this, arguments); } catch (e) { __pilhas.push('[desenharForja] ' + e.stack.split('\\n').slice(0, 3).join(' | ')); throw e; } };
  `, ctx);
  return { ctx, corpo, porId, tocar, todos, visivel, store, toasts, erros,
           recarregou: () => recarregou };
}

module.exports = { montarNavegador };
