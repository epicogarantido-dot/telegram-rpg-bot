# aiosqlite mínimo em cima do sqlite3 — só pros testes (o servidor de verdade usa o aiosqlite real)
# shim mínimo do aiosqlite em cima do sqlite3 (só pra benchmark local)
import sqlite3
class _Cur:
    def __init__(s, c): s.c = c
    async def fetchone(s): return s.c.fetchone()
    async def fetchall(s): return s.c.fetchall()
    async def close(s): pass
    async def __aenter__(s): return s
    async def __aexit__(s, *a): pass
    @property
    def lastrowid(s): return s.c.lastrowid
    @property
    def rowcount(s): return s.c.rowcount
class _Exec:
    def __init__(s, conn, sql, params): s.conn, s.sql, s.params = conn, sql, params; s._cur=None
    def _run(s):
        if s._cur is None: s._cur = _Cur(s.conn.execute(s.sql, s.params))
        return s._cur
    def __await__(s):
        async def f(): return s._run()
        return f().__await__()
    async def __aenter__(s): return s._run()
    async def __aexit__(s, *a): pass
class Connection:
    def __init__(s, path, **k): s.path=path; s.conn=None; s.row_factory=None
    async def _open(s):
        s.conn = sqlite3.connect(s.path, check_same_thread=False)
        return s
    def __await__(s): return s._open().__await__()
    async def __aenter__(s):
        await s._open(); return s
    async def __aexit__(s, *a): s.conn.commit(); s.conn.close()
    def execute(s, sql, params=()):
        if s.row_factory is not None: s.conn.row_factory = s.row_factory
        return _Exec(s.conn, sql, params)
    async def executemany(s, sql, seq): s.conn.executemany(sql, seq)
    async def executescript(s, sql): s.conn.executescript(sql)
    async def commit(s): s.conn.commit()
    async def close(s): s.conn.close()
def connect(path, **k): return Connection(path, **k)
Row = sqlite3.Row
Error = sqlite3.Error
