#!/usr/bin/env python3
"""⭐ XP dos guardas (20/09, dev: "os guardas também têm estrelas e níveis e
ganham XP"), no banco.

XP vem do TRABALHO: coletor ganha coletando numa equipe que saiu; guarda
ganha escoltando (mais fundo, mais XP), vigiando a cidade, enfrentando
emboscada e vencendo batalha. Quem fica parado em casa não aprende nada. E
o teto é o das estrelas de guarda (1★ para no 20; 3★ passa dele).
"""
import sys, os, json, random, tempfile, time, types

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

BANCO = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = BANCO
from game import clan_repo as CR
from game import clan_habitantes as H

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


CR.init_clan()
DONO = 31
CR.carregar_clan(DONO)


def hab(nome, talentos, nivel=1):
    with CR._conn() as c:
        cur = c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial, fadiga,"
                        " descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (DONO, nome, "agricultor", nivel, 1, 0, 0, 0, 1, json.dumps(talentos)))
        c.commit()
        return cur.lastrowid


g_escolta = hab("Escolta", {"guarda": 3})
g_casa = hab("Vigia", {"guarda": 2})
g_parado = hab("Parado", {"guarda": 2})
coletor = hab("Ana", {"agricultor": 2})
CR.montar_equipe(DONO, "p1_clareira", [coletor], [g_escolta], 30)
CR.montar_equipe(DONO, CR.EQUIPE_DA_CIDADE, [], [g_casa], 30)
with CR._conn() as c:
    c.execute("UPDATE clan SET comida = 500, madeira = 50, couro = 50, materiais = ?, ultimo_tick = ?"
              " WHERE owner_id = ?", (json.dumps({"1": 50}), int(time.time()) - 6 * 3600, DONO))
    c.commit()
CR.rodar_afk(DONO, areas={}, modelos={}, rng=random.Random(2))
por_nome = {h["nome"]: h for h in CR.listar_habitantes(DONO)}
ganho = lambda n: int(por_nome[n]["nivel"]) * 1000 + int(por_nome[n]["xp"])
exigir(ganho("Escolta") > 1000, "o guarda que escoltou a equipe não ganhou XP")
exigir(ganho("Ana") > 1000, "o coletor que coletou não ganhou XP")
exigir(ganho("Vigia") > 1000, "o guarda da guarnição não ganhou XP de vigia")
exigir(ganho("Parado") == 1000, "quem ficou parado em casa ganhou XP")

# teto pelas estrelas de guarda
um = {"nome": "Um", "nivel": 19, "xp": 0, "funcao": "guarda", "talentos": {"guarda": 1}}
tres = {"nome": "Três", "nivel": 19, "xp": 0, "funcao": "guarda", "talentos": {"guarda": 3}}
for h in (um, tres):
    H.ganhar_xp(h, 10 ** 5)
exigir(um["nivel"] == 20, f"guarda 1★ passou (ou não chegou) do nível 20: {um['nivel']}")
exigir(tres["nivel"] > 20, f"guarda 3★ travou no 20: {tres['nivel']}")

# batalha vencida dá XP
antes = ganho("Escolta")
frases = CR.dar_xp(DONO, [g_escolta], CR.XP_BATALHA)
por_nome = {h["nome"]: h for h in CR.listar_habitantes(DONO)}
exigir(ganho("Escolta") > antes, "XP de batalha não gravou no guarda")

if falhas:
    print("❌ XP DOS GUARDAS COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ XP: escolta, vigia e coletor ganham trabalhando, parado não ganha; teto pelas estrelas; batalha dá XP")
