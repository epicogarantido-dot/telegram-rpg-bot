// 🧭 GUIA INICIAL DE PONTA A PONTA, CONTRA O SERVIDOR DE VERDADE (28/09)
//
// Sobe a ponte (ponte/servidor_real.py: as rotas reais de webapp/api.py num
// HTTP mínimo, banco sqlite temporário), roda o app.js INTEIRO num DOM falso
// e joga como um jogador novo: entra como convidado, cria o personagem, dá o
// nome e segue o guia tocando SÓ onde ele manda — até o fim.
//
// O DOM falso faz o que importa pro guia: clique passa primeiro pelos
// ouvintes de captura do document (é ali que o guia bloqueia toque fora do
// alvo) e só depois chega no botão; botão desabilitado não recebe clique;
// elemento dentro de algo `.oculto` não tem tamanho; seletores com classe,
// id, [data-x="y"], descendente e vírgula.
//
// Em cada passo também toca em algo que NÃO é o alvo (um botão qualquer da
// tela) e confere que o guia segurou o toque.
//
// Uso: node testar_guia_real.js            (sai 2 se não tiver Python)
const fs = require('fs'), vm = require('vm'), path = require('path');
const { spawn, spawnSync } = require('child_process');

const RAIZ = process.env.RAIZ_APP || path.dirname(__dirname);
const src = fs.readFileSync(path.join(RAIZ, 'webapp/static/app.js'), 'utf8');
const html = fs.readFileSync(path.join(RAIZ, 'webapp/static/index.html'), 'utf8');
const PORTA = 8700 + Math.floor(Math.random() * 200);
const BASE = `http://127.0.0.1:${PORTA}`;
const ESCALA = 0.3;                 // relógio acelerado (setTimeout/setInterval)

if (spawnSync('python3', ['--version']).status !== 0) { console.log('⏭️ sem python3'); process.exit(2); }

const { montarNavegador } = require('./ponte/navegador_falso');
const nav = montarNavegador({ src, html, BASE, ESCALA, pilha: !!process.env.PILHA });
const { ctx, corpo, porId, tocar, todos, visivel, store, toasts, erros } = nav;
const lerGuia = () => vm.runInContext('GUIA_ATIVO ? { i: GUIA_ATIVO.i, titulo: GUIA_ATIVO.passo && GUIA_ATIVO.passo.titulo, ok: !!(GUIA_ATIVO.passo && GUIA_ATIVO.passo.ok), alvo: GUIA_ATIVO.passo && GUIA_ATIVO.passo.alvo, toques: GUIA_ATIVO.toques || 0, temAlvo: !!GUIA_ATIVO.alvoEl } : null', ctx);

const espera = (ms) => new Promise((r) => setTimeout(r, ms));
const botaoComTexto = (raiz, t) => todos(raiz).find((x) => x.tag === 'button' && visivel(x) && !x.disabled && (x.textContent || '').includes(t));

// ───────────────────────────── o jogo
let falhas = 0;
const linha = (ok, msg) => { console.log(`${ok ? '✅' : '❌'} ${msg}`); if (!ok) falhas++; };

(async () => {
  process.on('unhandledRejection', (e) => erros.push(String((e && e.stack) || e).split('\n').slice(0, 3).join(' | ')));
  const servidor = spawn('python3', [path.join(__dirname, 'ponte', 'servidor_real.py'), String(PORTA), fs.mkdtempSync('/tmp/guia-real-')],
                         { stdio: ['ignore', 'pipe', 'pipe'] });
  let logServidor = '';
  servidor.stderr.on('data', (d) => { logServidor += d; });
  await new Promise((ok, falha) => {
    servidor.stdout.on('data', (d) => { if (String(d).includes('PRONTO')) ok(); });
    setTimeout(() => falha(new Error('ponte não subiu: ' + logServidor.slice(-400))), 30000);
  });
  try {
    const conv = await (await fetch(BASE + '/api/auth/convidado', { method: 'POST' })).json();
    const chave = (src.match(/const CHAVE_TOKEN\s*=\s*["']([^"']+)/) || [])[1];
    store[chave] = conv.token;
    vm.runInContext('CONVIDADO = true;', ctx);

    await ctx.entrarNoJogo(); await espera(300);
    // sexo, e depois o 1º card de cada etapa (raça, profissão, habilidade)
    for (const t of ['Masculino', 'Escolher ', 'Escolher ', 'Escolher ']) {
      const b = botaoComTexto(porId.conteudo, t);
      if (!b) { if (t !== 'Masculino' && !porId['barra-abas'].classList.contains('oculto')) break;
                linha(false, `criação: não achei "${t}" (botões: ${todos(porId.conteudo).filter((x) => x.tag === 'button').map((x) => x.textContent).slice(0, 6).join(' / ')})`); break; }
      tocar(b); await espera(700);
    }
    linha(!porId['barra-abas'].classList.contains('oculto'), 'criação terminou e o jogo abriu');
    // nome obrigatório
    const campo = todos(porId['sheet-corpo']).find((x) => x.tag === 'input');
    if (campo) { campo.value = 'Viajante'; tocar(botaoComTexto(porId['sheet-corpo'], 'Salvar') || botaoComTexto(porId['sheet-corpo'], '')); }
    await espera(1500);

    // o guia
    const vistos = [];
    let semMudar = 0, ultimo = '', foraBloqueados = 0, foraVazou = [];
    for (let rodada = 0; rodada < 400; rodada++) {
      const g = lerGuia();
      if (!g) break;
      const marca = `${g.i}:${g.toques}`;
      if (marca === ultimo) semMudar++; else { semMudar = 0; ultimo = marca; if (!vistos.length || vistos[vistos.length - 1] !== g.titulo) vistos.push(g.titulo); }
      if (semMudar > 60) { linha(false, `guia PRESO no passo ${g.i + 1} "${g.titulo}" (alvo ${g.alvo || '—'}; ${g.temAlvo ? 'achou o alvo' : 'NÃO achou o alvo'})`); break; }
      if (g.ok) {
        const ok = todos(porId['guia-camada'] || corpo).find((x) => x.tag === 'button' && x.classList.contains('guia-ok') && !x.disabled);
        if (ok) { tocar(ok); await espera(500); } else await espera(100);
        continue;
      }
      if (!g.temAlvo) { await espera(100); continue; }
      // 1) toque FORA do alvo: algum botão visível da tela que não é o alvo
      const alvo = vm.runInContext('alvoVivoDoGuia()', ctx);
      const outro = todos(corpo).find((x) => x.tag === 'button' && visivel(x) && !x.disabled && x !== alvo
        && !(alvo && alvo.contains(x)) && !x.closest('.guia-balao') && !x.classList.contains('sheet-opcao'));
      if (outro) {
        const telaAntes = vm.runInContext('TELA_ATUAL', ctx);
        const r = tocar(outro);
        await espera(150);
        if (r.bloqueado) foraBloqueados++;
        else foraVazou.push(`passo "${g.titulo}": "${(outro.textContent || outro.className).slice(0, 30)}" passou (tela ${telaAntes}→${vm.runInContext('TELA_ATUAL', ctx)})`);
      }
      // 2) toque no alvo
      tocar(vm.runInContext('alvoVivoDoGuia()', ctx));
      await espera(500);
    }
    const fim = lerGuia();
    linha(!fim, fim ? `o guia não terminou (parou em "${fim.titulo}")` : `guia inteiro concluído (${vistos.length} passos)`);
    console.log('   passos:', vistos.join(' → '));
    linha(foraVazou.length === 0, `toques FORA do alvo bloqueados (${foraBloqueados} testados${foraVazou.length ? '; vazaram: ' + foraVazou.join(' | ') : ''})`);
    const ruins = toasts.filter((t) => t[1]).map((t) => t[0]);
    linha(!ruins.length && !erros.length, `nenhum erro durante o guia${ruins.length || erros.length ? ': ' + ruins.concat(erros).join(' | ') : ''}`);
    if (nav.recarregou()) console.log(`   (a página pediu reload ${nav.recarregou()}×)`);
    if (process.env.PILHA) console.log('   PILHAS:', JSON.stringify(globalThis.__pilhas.slice(0, 2)));
    const p = await (await fetch(BASE + '/api/character', { headers: { Authorization: 'Bearer ' + conv.token } })).json();
    const eq = Object.entries(p.equip || {}).filter(([, v]) => v).map(([k]) => k);
    linha(['weapon', 'armor', 'helmet', 'ring'].every((s) => eq.includes(s)), `fim do guia com arma, armadura, elmo e anel vestidos (${eq.join(', ') || 'nada'})`);
  } finally {
    servidor.kill();
  }
  console.log(falhas ? `❌ ${falhas} falha(s)` : '✅ guia real de ponta a ponta ok');
  process.exit(falhas ? 1 : 0);
})().catch((e) => { console.log('❌ o teste quebrou: ' + e.message); process.exit(1); });
