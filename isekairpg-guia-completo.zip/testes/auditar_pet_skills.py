#!/usr/bin/env python3
"""Auditoria das 4 opções de batalha dos pets (Arena dos Pets).

POR QUE ESTE TESTE EXISTE
-------------------------
Antes de 20/09 o turno do jogador na Arena dos Pets era "usa a skill ou
não". Cada pet tinha UMA `auto_skill` emprestada do livro de skills de
personagem, com `power_mult` 0,7: cinco pets diferentes jogavam igual, e
o arquétipo (tank, dps, healer, buffer, utility) só existia como
multiplicador escondido nos atributos.

Agora cada pet leva 4 opções — ataque básico + 3 do arquétipo dele — e a
raridade escala os números. Isso abre três jeitos de estragar a Arena em
silêncio, e é o que este arquivo mede:

1. **Skill que nada lê.** Um campo escrito no livro que o motor não
   consulta é enfeite — a armadilha nº 10 deste projeto, que já mordeu
   `fome`, `teto_comida` e `clan.diario`. Aqui o teste varre todos os
   campos do livro contra o que `pet_arena.py` lê de verdade.
2. **Opção dominante.** Se uma das 4 vence sempre, não há escolha: o
   jogador aperta o mesmo botão a partida inteira. O teste simula cada
   estratégia contra as outras e exige que nenhuma passe de 85%.
3. **Raridade que decide tudo.** Se o lendário ganhar do comum em 100%
   das partidas, a tática deixou de importar. O teste mede e exige uma
   folga.
"""
import sys, os, random, copy, re

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)

# `game.logic` traz o banco junto no import (aiosqlite), e o que este teste
# precisa dele são três funções de CÁLCULO de dano, que não tocam em banco
# nenhum. Sem este stub o teste só rodaria num ambiente com a dependência
# instalada — e teste que só roda na sua máquina é enfeite (armadilha nº 11).
# O stub cobre só o import; se alguma função realmente for ao banco, ela
# estoura aqui em vez de passar batido.
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    import types
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(
        RuntimeError("auditar_pet_skills não deve tocar no banco"))
    sys.modules["aiosqlite"] = falso

from game.pet_skills import LIVRO, ATAQUE_BASICO, skills_do_pet, ESCALA_RARIDADE

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


# ── 1) Todo campo do livro é lido pelo motor ─────────────────────────────
motor = open(os.path.join(RAIZ, "game", "pet_arena.py"), encoding="utf-8").read()
ESTRUTURAIS = {"id", "nome", "icone", "descricao", "raridade"}
campos = set()
for lista in LIVRO.values():
    for s in lista:
        campos |= set(s)
campos |= set(ATAQUE_BASICO)
for campo in sorted(campos - ESTRUTURAIS):
    exigir(f'"{campo}"' in motor,
           f"o campo '{campo}' existe no livro de skills e NINGUÉM lê em pet_arena.py")

# Toda skill precisa de recarga, senão ela substitui o ataque básico.
for arq, lista in LIVRO.items():
    exigir(len(lista) == 3, f"o arquétipo {arq} não tem exatamente 3 skills")
    for s in lista:
        exigir(int(s.get("recarga", 0)) > 0,
               f"{arq}/{s['id']} não tem recarga — o ataque básico viraria inútil")
        exigir(s.get("alvo") in ("inimigo", "todos_inimigos", "proprio", "aliados"),
               f"{arq}/{s['id']} tem alvo desconhecido: {s.get('alvo')}")

for arq in LIVRO:
    exigir(len(skills_do_pet(arq, "comum")) == 4,
           f"{arq} não entrega 4 opções de batalha")


# ── 1b) ATAQUE x DEFESA: o dano não pode virar 1 ─────────────────────────
# O dano deste jogo é SUBTRATIVO (`max(1, atk - def)`). Se o ataque
# encostar na defesa, todo golpe vira 1 de dano e a luta não termina — era
# o estado até 20/09, com o atk saindo de `bonus_stats.atk` (um bônus de
# equipe, quase sempre 10) enquanto a defesa ia a 70 por raridade.
from game.pets_db import PETS_DB as _PETS, derive_pet_combat_stats as _stats

print("espelho (mesmo pet dos dois lados), só ataque básico:")
for raridade in ("comum", "incomum", "raro", "epico", "lendario"):
    for arq in ("dps", "tank", "healer", "buffer", "utility"):
        pid = next((k for k, v in _PETS.items()
                    if v.get("rarity") == raridade and v.get("archetype") == arq), None)
        if not pid:
            continue
        st = _stats({}, pid)
        dano = max(1, st["atk"] - st["def"])
        turnos = st["hp_max"] / dano
        exigir(st["atk"] > st["def"] * 1.5,
               f"{raridade}/{arq}: atk {st['atk']} está parelho com a def {st['def']} — "
               "o dano subtrativo cai pra 1 por golpe")
        exigir(4 <= turnos <= 25,
               f"{raridade}/{arq}: {turnos:.0f} golpes básicos pra derrubar o espelho "
               "(fora da faixa de 4 a 25)")
    print(f"  {raridade:9s} | ok")


# ── 2) Simulação: nenhuma estratégia domina ──────────────────────────────
# Um duelo de esquadrões usando o MOTOR de verdade (`_apply_pet_action` e
# companhia), não uma cópia da fórmula. Cada "estratégia" é um jeito de
# escolher entre as 4 opções.
from game.pets_db import PETS_DB, derive_pet_combat_stats
from game import pet_arena


def montar_time(arquetipos, raridade):
    time_ = []
    for arq in arquetipos:
        pid = next((k for k, v in PETS_DB.items()
                    if v.get("archetype") == arq and v.get("rarity") == raridade), None)
        if not pid:
            pid = next(k for k, v in PETS_DB.items() if v.get("archetype") == arq)
        c = derive_pet_combat_stats({}, pid)
        pet_arena.preparar_pet(c)
        time_.append(c)
    return time_


# As estratégias comparadas são jeitos de escolher ENTRE AS TRÊS SKILLS.
# O ataque básico não entra como estratégia de propósito: ele não existe
# pra ser a melhor opção, e sim pra sustentar o turno enquanto as skills
# esfriam — uma "estratégia só básico" perderia 100% por desenho e não
# diria nada sobre equilíbrio. O papel dele é medido logo abaixo, pela
# fatia de turnos em que nada está pronto.
USO_BASICO = {"turnos": 0, "basico": 0}


def escolher(estrategia, pet, inimigos):
    opcoes = pet_arena.opcoes_de_batalha(pet)
    prontas = [s for s in opcoes[1:] if s["pronta"]]
    USO_BASICO["turnos"] += 1
    if not prontas:
        USO_BASICO["basico"] += 1
        return opcoes[0]
    if estrategia == "so_basico":
        USO_BASICO["basico"] += 1
        return opcoes[0]
    if estrategia == "aleatoria":
        return random.choice(prontas)
    # "skill1/2/3": o pet SÓ usa aquela skill do arquétipo; nas outras vezes
    # dá básico. É o que mede o peso de cada uma das três isoladamente — se
    # uma delas vence quase sempre sozinha, as outras duas são decoração.
    alvo_id = opcoes[int(estrategia[-1])]["id"]
    for s in prontas:
        if s["id"] == alvo_id:
            return s
    USO_BASICO["basico"] += 1
    return opcoes[0]


ULTIMO_DUELO: dict = {}


def duelo(time_a, time_b, estrat_a, estrat_b):
    """Um combate INTEIRO pelo motor real da Arena: `_advance_until_action_needed`
    (o laço 1x1 com troca) e `resolve_player_pet_turn`.

    A IA do rival é trocada por uma que segue `estrat_b` — é a única forma
    de comparar duas estratégias sem reimplementar o combate aqui, e
    reimplementá-lo seria a segunda cópia da regra (armadilha nº 3).
    """
    st = {
        "player_team": copy.deepcopy(time_a),
        "enemy_team": copy.deepcopy(time_b),
        "logs": [], "acting_idx": None,
        "player_active": None, "enemy_active": None, "finalizado": None,
    }
    for c in st["player_team"] + st["enemy_team"]:
        c["bar"] = 0.0
        pet_arena.preparar_pet(c)
    p = {"pet_arena_combat": st}

    original = pet_arena._ai_enemy_turn

    def ia(atacante, player_team, enemy_team, logs, alvo_forcado=None):
        alvo = alvo_forcado or (pet_arena._pets_vivos(player_team) or [None])[0]
        if alvo is None:
            return
        skill = escolher(estrat_b, atacante, [alvo])
        pet_arena._apply_pet_action(atacante, alvo, skill, enemy_team, player_team, logs)

    pet_arena._ai_enemy_turn = ia
    try:
        pet_arena._advance_until_action_needed(st)
        turnos = 0
        while not st.get("finalizado") and turnos < 400:
            turnos += 1
            meu = st["player_team"][st["acting_idx"]]
            inimigos = pet_arena._pets_vivos(st["enemy_team"])
            escolha = escolher(estrat_a, meu, inimigos)
            pet_arena.resolve_player_pet_turn(p, 0, skill_id=escolha["id"])
    finally:
        pet_arena._ai_enemy_turn = original

    ULTIMO_DUELO["finalizado"] = st.get("finalizado")
    return "a" if st.get("finalizado") == "vitoria" else "b"


ARQ = ["dps", "tank", "healer", "buffer", "utility"]


# ── 2b) O combate é 1x1 com troca, não 5x5 ──────────────────────────────
# O que se perde quando isso quebra é silencioso: a luta volta a ser dez
# barras ao mesmo tempo e ninguém percebe olhando a tela, só o ritmo muda.
_st = {"player_team": montar_time(ARQ, "raro"), "enemy_team": montar_time(ARQ, "raro"), "logs": [],
       "acting_idx": None, "player_active": None, "enemy_active": None, "finalizado": None}
for _c in _st["player_team"] + _st["enemy_team"]:
    _c["bar"] = 0.0
pet_arena._advance_until_action_needed(_st)
exigir(_st["player_active"] == 0 and _st["enemy_active"] == 0,
       "a luta não começou com o primeiro espírito de cada lado em campo")
_banco = [c for i, c in enumerate(_st["enemy_team"]) if i != _st["enemy_active"]]
exigir(all(c["bar"] == 0 for c in _banco),
       "o banco está enchendo barra — a luta voltou a ser 5x5")

# Derruba quem está em campo e confere que o PRÓXIMO entra, com barra zerada.
_st["enemy_team"][0]["hp"] = 0
pet_arena._advance_until_action_needed(_st)
exigir(_st["enemy_active"] == 1, "o espírito seguinte não entrou no lugar do que caiu")
exigir(_st["enemy_team"][1]["bar"] == 0,
       "quem entra não começa com a barra zerada — cair sairia de graça")

# Sem ninguém no banco, a batalha acaba.
for _c in _st["enemy_team"]:
    _c["hp"] = 0
pet_arena._advance_until_action_needed(_st)
exigir(_st["finalizado"] == "vitoria",
       "o time inteiro caiu e a batalha não terminou")


random.seed(11)
PARTIDAS = 40

# Comparar as três skills ENTRE SI premiaria automaticamente a de recarga
# mais curta — ela age mais vezes, e isso não diz se as outras prestam.
# A régua certa é o ATAQUE BÁSICO: cada skill precisa ganhar do time que
# só bate. Skill que não ganha do básico é botão que o jogador aprende a
# não apertar.
# Duas réguas, porque uma só não separa nada:
#
#   - contra o time que SÓ BATE (piso): a skill tem que pagar o turno que
#     custa. Skill que não ganha do ataque básico é botão que o jogador
#     aprende a não apertar.
#   - contra o time que VARIA as três (teto): nenhuma pode ganhar
#     sozinha. Se uma ganha, as outras duas viram decoração e as 4 opções
#     voltam a ser uma só.
#
# Comparar as três entre si, que era a tentação, premiaria automaticamente
# a de recarga mais curta — ela age mais vezes — e não diria nada sobre as
# outras prestarem.
print("cada skill sozinha:  vs só-básico  |  vs quem varia as três")
piso, teto = {}, {}
for estrategia in ("skill1", "skill2", "skill3"):
    ta = montar_time(ARQ, "raro")
    tb = montar_time(ARQ, "raro")
    piso[estrategia] = 100 * sum(1 for _ in range(PARTIDAS)
                                 if duelo(ta, tb, estrategia, "so_basico") == "a") / PARTIDAS
    teto[estrategia] = 100 * sum(1 for _ in range(PARTIDAS)
                                 if duelo(ta, tb, estrategia, "aleatoria") == "a") / PARTIDAS
    print(f"  {estrategia:10s} |    {piso[estrategia]:5.1f}%     |    {teto[estrategia]:5.1f}%")
    exigir(piso[estrategia] >= 60,
           f"'{estrategia}' ganha só {piso[estrategia]:.0f}% do time que só bate — "
           "essa opção não paga o turno que custa")
    exigir(teto[estrategia] <= 60,
           f"'{estrategia}' ganha {teto[estrategia]:.0f}% até de quem varia as três — "
           "as outras duas viraram decoração")

# ── 2c) espelho: a MESMA estratégia dos dois lados tem que dar luta parelha
# 🐛 20/09, dois defeitos opostos achados aqui:
#   - a recarga do jogador só andava depois do clique: a tela mostrava toda
#     skill com um turno a mais e o botão vinha travado (jogador 38–40%);
#   - todo EMPATE de barra era do jogador, e em espelho as barras sempre
#     empatam: ele começava toda luta e toda volta depois de uma queda.
# Com os dois corrigidos (recarga na abertura do turno, empate na moeda), o
# espelho tem que dar perto de 50%.
espelho = sum(1 for _ in range(200)
              if duelo(montar_time(ARQ, "raro"), montar_time(ARQ, "raro"),
                       "aleatoria", "aleatoria") == "a") / 200
print(f"\nespelho (mesma estratégia dos dois lados): jogador vence {100 * espelho:.0f}%")
exigir(0.38 <= espelho <= 0.62,
       f"em luta espelhada o jogador vence {100 * espelho:.0f}% — um lado voltou a ter "
       "vantagem de relógio (recarga fora de hora, ou empate sempre do mesmo lado)?")

# ── 2d) nenhuma luta pode ser infinita ──────────────────────────────────
# Medido em 20/09: espelho de curandeiros (cura em % do ATK) e de tanques
# (escudo de 45%) — 60 de 60 lutas SEM FIM. O jogador ficaria clicando pra
# sempre. Toda combinação arquétipo × skill, na raridade mais forte, tem que
# terminar.
from game.pets_db import PETS_DB as _P2, derive_pet_combat_stats as _d2
for arq in ARQ:
    pid = next(k for k, v in _P2.items() if v.get("archetype") == arq and v.get("rarity") == "lendario")
    for n in (1, 2, 3):
        terminaram = sum(1 for _ in range(20)
                         if duelo([pet_arena.preparar_pet(_d2({}, pid))],
                                  [pet_arena.preparar_pet(_d2({}, pid))],
                                  f"skill{n}", f"skill{n}") in ("a", "b")
                         and ULTIMO_DUELO.get("finalizado"))
        exigir(terminaram == 20,
               f"espelho {arq}/skill{n}: só {terminaram} de 20 lutas terminaram — luta infinita")

pct_basico = 100 * USO_BASICO["basico"] / max(1, USO_BASICO["turnos"])
print(f"\nataque básico usado em {pct_basico:.0f}% dos turnos (nada pronto)")
exigir(pct_basico >= 8,
       f"o básico só é usado em {pct_basico:.0f}% dos turnos — as recargas estão "
       "curtas demais e ele virou opção morta")


# ── 3) Raridade pesa, mas não decide sozinha ─────────────────────────────
lendario = montar_time(ARQ, "lendario")
comum = montar_time(ARQ, "comum")
vit_lend = sum(1 for _ in range(40)
               if duelo(lendario, comum, "aleatoria", "aleatoria") == "a")
pct_lend = 100 * vit_lend / 40
print(f"\nlendário x comum  | {pct_lend:.0f}% pro lendário "
      f"(escala {ESCALA_RARIDADE['lendario']}x)")
exigir(pct_lend >= 60, f"o time lendário ganha só {pct_lend:.0f}% — a raridade não vale nada")

if falhas:
    print("\n❌ SKILLS DE PET COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("\n✅ 4 opções por pet, nenhuma domina, e todo campo do livro é lido pelo motor")
