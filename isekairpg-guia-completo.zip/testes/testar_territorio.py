#!/usr/bin/env python3
"""E2E do território: conquista, um-ponto-por-vez, PvP e perda gradual NO DISCO.

POR QUE EXISTE
--------------
`auditar_territorio.py` mede o desenho. Este confere a gravação — e aqui
ela tem uma dificuldade que o resto do clã não tinha: o mapa é COMPARTILHADO.
Um erro não fica numa conta, aparece pra todo mundo. As regras que só
existem no código de gravação são as que mais precisam de rede:

- o mapa é semeado UMA vez e nunca regerado (regerar apagaria conquistas);
- um ponto por vez: tomar outro larga o anterior, que fica sem dono;
- tomar o ponto de outro JOGADOR tira o ponteiro dele e avisa nas Memórias;
- o ponto rende na sessão de AFK e, sob pressão, é perdido pra um bot;
- dois donos pro mesmo ponto nunca (a troca é condicionada ao dono lido).
"""
import sys, os, random, sqlite3, tempfile, time, types

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

BANCO = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = BANCO

from game import clan_repo as CR
from game import territorio as T

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


class SempreVence(random.Random):
    """Sorteio que sempre dá 0: toda chance positiva 'acontece'. Serve pra
    testar a GRAVAÇÃO da vitória sem depender da sorte do dia."""
    def random(self):
        return 0.0


CR.init_clan()
mapa = CR.listar_mapa()
TOTAL = len(T.gerar_mapa())
exigir(len(mapa) == TOTAL, f"o mapa semeado tem {len(mapa)} pontos, e não {TOTAL}")
CR.garantir_mapa()
exigir(len(CR.listar_mapa()) == TOTAL, "garantir_mapa semeou de novo — duplicou o mundo")

A, B = 101, 202
for dono in (A, B):
    CR.carregar_clan(dono)
    with CR._conn() as c:
        # os dois clãs no Andar 5: o tier 1 do mapa fica lá, e (regra de
        # 20/09) o clã só toma pontos do andar onde está
        c.execute("UPDATE clan SET comida = 500, andar = 5 WHERE owner_id = ?", (dono,))
        for slot in range(5):
            c.execute("INSERT INTO clan_membro(owner_id, slot, nome, nivel) VALUES (?,?,?,?)",
                      (dono, slot, f"L{dono}-{slot}", 40))
        c.commit()

# ── ⚔️ só o andar onde o clã está ───────────────────────────────────────
longe = next(p for p in mapa if p["tipo"] == "mina" and p["andar"] == 15)
r = CR.conquistar_ponto(A, longe["id"], "Clã A", SempreVence())
exigir(not r["ok"], "o clã no Andar 5 tomou um ponto do Andar 15")
refugios = [p for p in mapa if p["seguro"]]
exigir(sorted(T.andar_do_ponto(p) for p in refugios) == list(range(1, 51)),
       "não há um refúgio em cada andar — clã preso ao andar ficaria sem abrigo")

# ── local seguro e a regra de um por vez ────────────────────────────────
seguro = next(p for p in mapa if p["seguro"] and p["andar"] == 5)
r = CR.conquistar_ponto(A, seguro["id"], "Clã A")
exigir(r["ok"] and CR.carregar_clan(A)["ponto_id"] == seguro["id"], "não ocupou o local seguro")
r = CR.conquistar_ponto(B, seguro["id"], "Clã B")
exigir(r["ok"], "o segundo clã não pôde dividir o local seguro")

mina1 = next(p for p in mapa if p["tipo"] == "mina" and p["andar"] == 5)
comida_antes = CR.carregar_clan(A)["comida"]
r = CR.conquistar_ponto(A, mina1["id"], "Clã A", SempreVence())
exigir(r["ok"] and r["venceu"], f"não tomou a mina rasa com força alta: {r}")
clan_a = CR.carregar_clan(A)
exigir(clan_a["ponto_id"] == mina1["id"],
       "tomou a mina e o clã continuou apontando pro local seguro — dois pontos ao mesmo tempo")
exigir(clan_a["comida"] == comida_antes - T.custo_de_ataque(1), "a marcha não cobrou a comida")
exigir(CR.ponto(mina1["id"])["dono_id"] == str(A), "o dono do ponto não foi gravado")

floresta = next(p for p in mapa if p["tipo"] == "floresta" and p["andar"] == 5)
CR.conquistar_ponto(A, floresta["id"], "Clã A", SempreVence())
largado = CR.ponto(mina1["id"])
exigir(largado["dono_id"] is None and largado["dono_tipo"] is None,
       "tomar a floresta não largou a mina — o clã segurou dois pontos")
exigir(CR.carregar_clan(A)["ponto_id"] == floresta["id"], "o ponteiro não foi pra floresta")

# ── PvP: B toma a floresta de A ─────────────────────────────────────────
# (fase 3, 20/09: ponto de outro JOGADOR se toma com a equipe do ponto —
# guardas contra guardas. O detalhe da batalha está em testar_batalha.py.)
for dono, nome in ((B, "GuardaB"), (A, "GuardaA")):
    with CR._conn() as c:
        cur = c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial, fadiga,"
                        " descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (dono, nome, "guarda", 20, 1, 0, 0, 0, 1, '{"guarda": 2, "agricultor": 1}'))
        c.commit()
        gid = cur.lastrowid
    with CR._conn() as c:
        cur = c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial, fadiga,"
                        " descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (dono, nome + "-col", "agricultor", 5, 1, 0, 0, 0, 1, '{"agricultor": 1}'))
        c.commit()
        cid = cur.lastrowid
    exigir(CR.montar_equipe(dono, CR.EQUIPE_DO_PONTO, [cid], [gid], 30)["ok"],
           f"não montou a equipe do ponto de {nome}")
r = CR.conquistar_ponto(B, floresta["id"], "Clã B", SempreVence())
exigir(r["ok"] and r["venceu"], f"B não conseguiu disputar o ponto de A: {r}")
exigir(CR.ponto(floresta["id"])["dono_id"] == str(B), "a floresta não mudou de dono")
exigir(CR.carregar_clan(A)["ponto_id"] is None, "A perdeu a floresta e continuou apontando pra ela")
exigir(any("tomou" in m["texto"] and "Clã B" in m["texto"]
           for m in CR.carregar_clan(A)["memorias"]),
       "A perdeu o ponto e nada ficou nas Memórias dele")

# ── AFK: o ponto dá BÔNUS no que o clã tira, e sob pressão é perdido ─────
# (20/09: o ponto não produz sozinho; multiplica o trabalho. Um lenhador da
# aldeia corta a madeira e a floresta ocupada soma +100% em cima.)
with CR._conn() as c:
    c.execute("UPDATE clan SET madeira = 0, ultimo_tick = ? WHERE owner_id = ?",
              (int(time.time()) - 6 * 3600, B))
    # 20/09 (equipes): quem coleta é a EQUIPE num posto — um bosque no
    # Andar 5 (onde o clã está), lenhador + guarda, e o couro/ferro/madeira
    # da manutenção do guarda
    c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial, fadiga,"
              " descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
              (B, "Tora", "lenhador", 10, 3, 0, 0, 0, 1, '{"lenhador": 3}'))
    c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial, fadiga,"
              " descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
              (B, "Muro", "guarda", 20, 3, 0, 0, 0, 1, '{"guarda": 3}'))
    c.execute("UPDATE clan SET couro = 20, madeira = 20, materiais = '{\"1\": 20}' WHERE owner_id = ?", (B,))
    c.commit()
postos_b = CR.postos_descobertos(B)
postos_b["p5_bosque"] = {"id": "p5_bosque", "andar": 5, "tipo": "bosque", "estrelas": 2, "mult": 1.0}
CR._gravar_postos(B, postos_b)
ids_b = {h["nome"]: h["id"] for h in CR.listar_habitantes(B)}
exigir(CR.montar_equipe(B, "p5_bosque", [ids_b["Tora"]], [ids_b["Muro"]], 30)["ok"],
       "não montou a equipe do bosque do Andar 5")
rel = CR.rodar_afk(B, areas={}, modelos={}, rng=random.Random(2))
extra = (rel.get("territorio") or {}).get("extra") or {}
coletado = sum(sd["qtd"] for sd in rel["equipes"]["saidas"] if sd["recurso"] == "madeira")
exigir(extra.get("madeira", 0) > 0, f"a floresta ocupada não deu bônus de madeira: {rel.get('territorio')}")
# +100% no tier 1, vezes a integridade — que a pressão dos bots da própria
# sessão pode ter arranhado; abaixo de 75% seria outro problema
exigir(extra.get("madeira", 0) >= 0.75 * coletado,
       f"o bônus da floresta tier 1 não chegou perto de dobrar a madeira: coletado {coletado}, extra {extra}")

with CR._conn() as c:
    c.execute("UPDATE clan_membro SET vivo = 0 WHERE owner_id = ?", (B,))  # força ~ nenhuma
    c.execute("UPDATE territorio SET integridade = 10 WHERE id = ?", (floresta["id"],))
    # "sem força nenhuma": os guardas que B ganhou pra batalha do ponto saem
    c.execute("UPDATE clan_habitante SET vivo = 0 WHERE owner_id = ? AND profissao = 'guarda'", (B,))
    c.commit()
perdeu = False
for s in range(80):
    with CR._conn() as c:
        c.execute("UPDATE clan SET ultimo_tick = ? WHERE owner_id = ?",
                  (int(time.time()) - 6 * 3600, B))
        c.commit()
    CR.rodar_afk(B, areas={}, modelos={}, rng=random.Random(100 + s))
    if CR.carregar_clan(B)["ponto_id"] is None:
        perdeu = True
        break
pt = CR.ponto(floresta["id"])
exigir(perdeu and pt["dono_tipo"] == "bot",
       "um clã sem força nenhuma, com o ponto em 10%, nunca o perdeu pros bots")

# ── banco VELHO sem os covis: ganha os covis sem perder conquista ──────
with CR._conn() as c:
    c.execute("DELETE FROM territorio WHERE tipo = 'covil'")
    c.execute("UPDATE territorio SET dono_tipo='jogador', dono_id=?, dono_nome='Clã A'"
              " WHERE id = ?", (str(A), mina1["id"]))
    c.commit()
CR.garantir_mapa()
depois = CR.listar_mapa()
covis = [p for p in depois if p["tipo"] == "covil"]
exigir(len(covis) == 30, f"um banco sem covis ganhou {len(covis)} covis, e não 30 — "
                         "tipo novo não chega em mundo que já existia")
exigir(len(depois) == TOTAL, "semear os covis duplicou outros pontos")
exigir(CR.ponto(mina1["id"])["dono_id"] == str(A),
       "semear os covis apagou uma conquista que já existia")

# ── mudar de andar larga o ponto ────────────────────────────────────────
with CR._conn() as c:
    c.execute("UPDATE clan SET andar = 5, comida = 500 WHERE owner_id = ?", (B,))
    c.commit()
cacada = next(p for p in mapa if p["tipo"] == "caca" and p["andar"] == 5)
r = CR.conquistar_ponto(B, cacada["id"], "Clã B", SempreVence())
exigir(r["ok"] and CR.carregar_clan(B)["ponto_id"] == cacada["id"], f"B não tomou a caça do Andar 5: {r}")
with CR._conn() as c:
    c.execute("UPDATE clan SET andar = 6 WHERE owner_id = ?", (B,))
    c.commit()
CR.sessao_do_territorio(B, 24, random.Random(1))
exigir(CR.carregar_clan(B)["ponto_id"] is None,
       "o clã foi pro Andar 6 e continuou segurando o ponto do Andar 5")
exigir(CR.ponto(cacada["id"])["dono_id"] is None, "o ponto deixado pra trás continuou com dono")

if falhas:
    print("❌ TERRITÓRIO (E2E) COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print(f"✅ território no disco: {TOTAL} pontos semeados uma vez (e os covis chegam em mundo "
      "velho), um por vez, PvP e perda pros bots")
