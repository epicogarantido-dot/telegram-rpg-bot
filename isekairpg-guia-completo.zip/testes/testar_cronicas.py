"""📖 Crônicas (26/09/2026): o conteúdo não pode ter agenda pra evento que
não existe, opção padrão fora do lugar, efeito desconhecido, nem texto com
{marcador} que o motor não preenche."""
import os, re, sys
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
import types
sys.modules.setdefault("aiosqlite", types.ModuleType("aiosqlite"))
from game import cronicas as K

problemas = list(K.validar())
MARCADORES = {"alvo", "alvo2", "alvo_estrelas", "posto", "recurso", "cla", "equipe_tamanho", "faixa"}
cat = K.catalogo()
for sid, ev in cat.items():
    textos = [ev.get("titulo", ""), ev.get("texto", "")] + [o.get("label", "") for o in ev["opcoes"]]
    for o in ev["opcoes"]:
        for lado in ("efeitos", "sucesso", "falha"):
            textos += [e.get("texto", "") for e in o.get(lado) or []]
    for t in textos:
        for m in re.findall(r"\{(\w+)\}", t):
            if m not in MARCADORES:
                problemas.append(f"{sid}: marcador {{{m}}} que o motor não preenche")
    if ev.get("gatilho") == "sessao" and not ev.get("cooldown"):
        problemas.append(f"{sid}: crônica de sessão sem cooldown (repetiria toda hora)")
if "fundacao_acampamento" not in cat or not any(
        e.get("flag") == "fundado" for ev in cat.values() for o in ev["opcoes"] for e in o.get("efeitos") or []):
    problemas.append("a fundação precisa existir e terminar com a flag 'fundado'")
if problemas:
    print("❌ CRÔNICAS COM PROBLEMA")
    for p_ in problemas:
        print("  -", p_)
    sys.exit(1)
print(f"  ✅ {len(cat)} crônicas, agenda e padrões válidos, marcadores ok")
print("🟢 CRÔNICAS: TUDO PASSOU")
