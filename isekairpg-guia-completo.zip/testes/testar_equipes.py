#!/usr/bin/env python3
"""E2E da aldeia por equipes (fase 1) no banco.

Confere a GRAVAÇÃO e as travas: montar equipe sem guarda / com quem não tem
talento / num posto fora do andar é recusado; a equipe montada coleta NA
SESSÃO do AFK e o recurso entra no estoque; a manutenção é paga; faltando
couro pros guardas, a aldeia entra em GREVE e ninguém coleta; comprar de
outras aldeias soma no estoque e devolve o custo em ouro.
"""
import sys, os, json, random, tempfile, time, types

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

BANCO = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = BANCO
from game import clan_repo as CR

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


CR.init_clan()
DONO = 3
CR.carregar_clan(DONO)


def habitante(nome, talentos, nivel=10):
    with CR._conn() as c:
        cur = c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial, fadiga,"
                        " descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (DONO, nome, "agricultor", nivel, 1, 0, 0, 0, 1, json.dumps(talentos)))
        c.commit()
        return cur.lastrowid


agri = habitante("Ana", {"agricultor": 3})
lenha = habitante("Beto", {"lenhador": 2})
guarda = habitante("Caio", {"guarda": 2, "agricultor": 1}, nivel=20)
posto = "p1_clareira"      # a Clareira que todo clã ganha

# Equipe pode ficar incompleta (tirar gente um a um tem que funcionar), mas
# SEM GUARDA ELA NÃO SAI: confere na sessão, não na montagem.
r = CR.montar_equipe(DONO, posto, [agri], [], tower_floor=5)
exigir(r["ok"], f"não deu pra deixar a equipe incompleta: {r}")
with CR._conn() as c:
    c.execute("UPDATE clan SET comida = 300, madeira = 50, couro = 20, materiais = '{\"1\": 50}',"
              " ultimo_tick = ? WHERE owner_id = ?", (int(time.time()) - 6 * 3600, DONO))
    c.commit()
rel0 = CR.rodar_afk(DONO, areas={}, modelos={}, rng=random.Random(1))
exigir(not rel0["equipes"]["saidas"], "a equipe saiu sem guarda")
r = CR.montar_equipe(DONO, posto, [agri], [lenha], tower_floor=5)
exigir(not r["ok"], "alguém sem talento de guarda (0★) virou guarda")
r = CR.montar_equipe(DONO, posto, [lenha], [guarda], tower_floor=5)
exigir(not r["ok"], "um lenhador foi coletar comida na clareira")
r = CR.montar_equipe(DONO, "p9_veio", [agri], [guarda], tower_floor=5)
exigir(not r["ok"], "montou equipe num posto que não é do andar do clã")
r = CR.montar_equipe(DONO, posto, [agri], [guarda], tower_floor=5)
exigir(r["ok"], f"a equipe certa foi recusada: {r}")
funcoes = {h["nome"]: (h["funcao"], h["equipe"]) for h in CR.listar_habitantes(DONO)}
exigir(funcoes["Ana"] == ("coletor", posto) and funcoes["Caio"] == ("guarda", posto)
       and funcoes["Beto"] == (None, None), f"as funções não gravaram: {funcoes}")


def sessao(couro, comida=300):
    with CR._conn() as c:
        c.execute("UPDATE clan SET comida = ?, madeira = 50, couro = ?, materiais = '{\"1\": 50}',"
                  " ultimo_tick = ? WHERE owner_id = ?",
                  (comida, couro, int(time.time()) - 6 * 3600, DONO))
        c.commit()
    antes = CR.carregar_clan(DONO)
    rel = CR.rodar_afk(DONO, areas={}, modelos={}, rng=random.Random(4))
    return antes, CR.carregar_clan(DONO), rel


antes, depois, rel = sessao(couro=20)
eq = rel["equipes"]
exigir(not eq["greve"], f"entrou em greve tendo tudo: {eq['greve']}")
exigir(eq["saidas"] and eq["saidas"][0]["qtd"] > 0, f"a equipe não coletou: {eq}")
exigir(depois["couro"] == antes["couro"] - eq["pago"]["couro"] and eq["pago"]["couro"] >= 1,
       "a manutenção do guarda (couro) não foi paga")
exigir(depois["materiais"].get(1, 0) == 50 - eq["pago"]["ferro"], "o ferro do guarda não foi pago")


antes, depois, rel = sessao(couro=0)
eq = rel["equipes"]
# 25/09/2026 (dev): "em vez de greve, uma baixa de 50%" — faltando couro, a
# equipe SAI e coleta, rendendo metade; o que faltou vai pro relatório e
# pras Memórias.
exigir(eq["greve"] and eq.get("baixa") == 0.5, f"sem couro pro guarda, não houve a baixa de 50%: {eq}")
exigir(eq["saidas"] and eq["saidas"][0]["qtd"] > 0, f"com a baixa, a equipe tinha de sair e coletar: {eq}")
exigir(any(m.get("tipo") == "greve" and "metade" in m["texto"] for m in depois["memorias"]),
       "a baixa não foi pras Memórias")

# 🧹 (26/09/2026) o sistema antigo de decisões saiu: o AFK NÃO gera mais
# "situações" (as histórias agora são as Crônicas, game/cronicas.py).
for semente in range(4):
    with CR._conn() as c:
        c.execute("UPDATE clan SET comida = 300, madeira = 50, couro = 20,"
                  " materiais = '{\"1\": 50}', ultimo_tick = ? WHERE owner_id = ?",
                  (int(time.time()) - 6 * 3600, DONO))
        c.commit()
    rel = CR.rodar_afk(DONO, areas={}, modelos={}, rng=random.Random(100 + semente))
    exigir(not rel.get("situacoes"), f"o AFK voltou a gerar situações antigas: {rel.get('situacoes')}")

couro_antes = CR.carregar_clan(DONO)["couro"]
r = CR.comprar_de_outras_aldeias(DONO, "couro", 10)
exigir(r["ok"] and r["custo_ouro"] == 30 and CR.carregar_clan(DONO)["couro"] == couro_antes + 10,
       f"comprar couro de outras aldeias não somou/cobrou certo: {r}")
r = CR.comprar_de_outras_aldeias(DONO, "ferro", 5)
exigir(r["ok"] and CR.carregar_clan(DONO)["materiais"].get(1, 0) >= 5, "comprar ferro não virou material rank 1")

exigir(CR.desfazer_equipe(DONO, posto)["ok"] and not CR.equipes_do_cla(DONO), "desfazer a equipe falhou")
exigir(all(h["funcao"] is None for h in CR.listar_habitantes(DONO)), "quem voltou continua com função")

if falhas:
    print("❌ EQUIPES (E2E) COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ equipes no disco: só sai com guarda e talento, coleta no AFK, paga manutenção, greve, compra")
