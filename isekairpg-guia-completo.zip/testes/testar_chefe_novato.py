#!/usr/bin/env python3
"""Chefe do novato, portal preso ao chefe e capangas (28/09).

POR QUE EXISTE
--------------
No 5º andar o Rei Goblin vencia SEMPRE: medido com o jogador no ponto
(nível máximo do 4º andar, pontos gastos, peças do guia), 0 vitórias em 20,
em qualquer divisão de pontos. E o portal aparecia no andar de chefe, então
o jogador afoito passava morrendo de graça (proteção do novato) até o 11º
andar, no nível 3, e ali ficava 5 h trancado.

O que este teste trava:
- no 5º e no 10º, quem chega no ponto vence o chefe na maioria das vezes, e
  quem chega sem gastar os pontos perde — o chefe continua sendo prova;
- do 15º em diante o chefe é exatamente o de antes (não medido daqui);
- no andar de chefe do novato o portal só abre vencendo o chefe, e abre na
  hora da vitória;
- enquanto o chefe não cai, metade das lutas é de capangas (senão quem subiu
  fraco ficava preso: não dá pra descer e o chefe era o único monstro);
- os campos novos persistem (save_player_sql só grava os da lista).
"""
import sys, os, types, random, copy

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

import game.logic as L
import game.monsters as M
from game.sql_repo import CAMPOS_EXTRAS

falhas = []


def exigir(cond, msg):
    print(("✅ " if cond else "❌ ") + msg)
    if not cond:
        falhas.append(msg)


def jogador(nivel, gastar=True):
    p = L.create_player(1)
    p["class_id"] = "guerreiro"; p["race_id"] = "humano"; p["level"] = nivel
    p["trail_points"] = 4 * (nivel - 1)
    if gastar:
        for i in range(p["trail_points"]):
            t, sec = (("str", "atk"), ("vit", "hp_max"))[i % 2]
            L.spend_trail_point(p, t, amount=1, sec=sec)
    L.recalc(p); p["hp"] = p["hp_max"]; p["state"] = "TOWER"
    return p


def taxa_vitoria(p, andar, n=30):
    ganhou = 0
    for _ in range(n):
        q = copy.deepcopy(p); q["tower_floor"] = andar; q["chefes_vencidos"] = []
        q["hp"] = q["hp_max"]
        L.start_combat(q)
        while q["combat"]["enemies"][0]["tipo"] != "boss":      # só luta de chefe
            L.start_combat(q)
        for _t in range(300):
            L.combat_attack(q)
            if not (q.get("combat") or {}).get("enemies") or q["hp"] <= 0:
                break
        ganhou += q["hp"] > 0
    return ganhou / n


random.seed(5)
for andar in (5, 10):
    cap = 2 * (andar - 1)
    v = taxa_vitoria(jogador(cap), andar)
    exigir(v >= 0.6, f"andar {andar}: no ponto (nv {cap}, pontos gastos) vence o chefe {v:.0%} (≥ 60%)")
    v = taxa_vitoria(jogador(cap, gastar=False), andar)
    exigir(v <= 0.2, f"andar {andar}: sem gastar os pontos perde pro chefe (vence {v:.0%}, ≤ 20%)")

# do 15º em diante: gerador cru, sem o ajuste
q = {"tower_floor": 15, "spd": 30, "chefes_vencidos": []}
random.seed(1); cru = M.criar_monstro_por_andar(15)
random.seed(1); L.start_combat(q)
e = q["combat"]["enemies"][0]
exigir(e["spd"] == cru["status"]["spd"] and e["atk"] == cru["status"]["atk"],
       "andar 15: chefe igual ao de antes (sem o ajuste do novato)")

# portal preso ao chefe
p = jogador(8); p["tower_floor"] = 5; p["chefes_vencidos"] = []
portais = 0
for _ in range(400):
    p["combat"] = None; p["tower_choice"] = None; p["torre_encontro"] = None
    L.tower_explore(p)
    portais += bool(p.get("tower_choice"))
exigir(portais == 0, f"andar 5 com o chefe vivo: 0 portais em 400 explorações (deu {portais})")
p["chefes_vencidos"] = [5]; portais = 0
for _ in range(400):
    p["combat"] = None; p["tower_choice"] = None; p["torre_encontro"] = None
    L.tower_explore(p)
    portais += bool(p.get("tower_choice"))
exigir(portais > 10, f"andar 5 com o chefe vencido: portal volta a sair ({portais} em 400)")
p = jogador(8); p["tower_floor"] = 11; portais = 0
for _ in range(400):
    p["combat"] = None; p["tower_choice"] = None; p["torre_encontro"] = None
    L.tower_explore(p)
    portais += bool(p.get("tower_choice"))
exigir(portais > 10, f"andar 11 (fora do novato): portal como antes ({portais} em 400)")

# capangas
p = jogador(8); p["tower_floor"] = 5; p["chefes_vencidos"] = []
chefes = 0
for _ in range(400):
    L.start_combat(p); chefes += p["combat"]["enemies"][0]["tipo"] == "boss"
exigir(120 <= chefes <= 280, f"andar 5 com o chefe vivo: ~metade das lutas é o chefe ({chefes}/400)")
p["chefes_vencidos"] = [5]; chefes = 0
for _ in range(100):
    L.start_combat(p); chefes += p["combat"]["enemies"][0]["tipo"] == "boss"
exigir(chefes == 100, f"andar 5 com o chefe vencido: volta a ser só o chefe ({chefes}/100)")

# vencer o chefe abre o portal na hora
p = jogador(8); p["tower_floor"] = 5; p["chefes_vencidos"] = []
L.start_combat(p)
while p["combat"]["enemies"][0]["tipo"] != "boss":
    L.start_combat(p)
p["combat"]["enemies"][0]["hp"] = 1
for _ in range(20):
    L.combat_attack(p)
    if not (p.get("combat") or {}).get("enemies"):
        break
exigir(p.get("tower_choice") == "chefe" and 5 in p.get("chefes_vencidos", []),
       "vencer o chefe do 5º abre o portal na tela da vitória")

exigir({"chefes_vencidos", "ultima_derrota"} <= set(CAMPOS_EXTRAS), "campos novos persistem no save")

print("\n" + ("🟢 CHEFE DO NOVATO: TUDO PASSOU" if not falhas else f"🔴 {len(falhas)} FALHA(S)"))
sys.exit(1 if falhas else 0)
