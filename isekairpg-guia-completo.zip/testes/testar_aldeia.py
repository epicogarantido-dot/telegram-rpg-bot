#!/usr/bin/env python3
"""E2E da aldeia viva: roda o código de GRAVAÇÃO num banco SQLite de verdade.

POR QUE EXISTE
--------------
`auditar_aldeia.py` mede se o DESENHO fecha (números, curvas, taxas).
Este aqui confere se o CÓDIGO grava o que o desenho promete. A distinção
já custou caro neste projeto: `fome`, `teto_comida`, `clan.diario` e
`ferimento` existiam no schema, apareciam em fórmulas — e ninguém
escrevia neles. Planilha certa com gravação faltando foi o bug, quatro
vezes. Então aqui cada coisa que a aldeia promete é conferida NO DISCO:

- banco velho (sem as colunas novas) ganha as colunas na migração;
- acolher cobra comida, respeita a capacidade e escreve nas Memórias;
- uma sessão de AFK soma a produção dos habitantes no estoque do clã,
  grava a fadiga deles e põe a aldeia no diário;
- trocar de profissão zera o nível (é o custo que faz a troca ser decisão);
- o `ferimento` do RECUA é gravado no lutador, e o curandeiro trata.

Roda sem o aiosqlite instalado: o clã usa sqlite3 síncrono, e o stub só
cobre o import do módulo assíncrono que vem junto.
"""
import sys, os, json, json, random, sqlite3, tempfile, time, types

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)

try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(
        RuntimeError("testar_aldeia usa só o caminho síncrono"))
    sys.modules["aiosqlite"] = falso

pasta = tempfile.mkdtemp()
BANCO = os.path.join(pasta, "t.db")
import game.sql_repo as SR
SR.DB_PATH = BANCO

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


# ── 1) banco VELHO: as tabelas do clã como eram antes de 20/09 ──────────
with sqlite3.connect(BANCO) as c:
    c.execute("CREATE TABLE clan (owner_id INTEGER PRIMARY KEY, nome TEXT DEFAULT '',"
              " comida INTEGER DEFAULT 0, ultimo_tick INTEGER DEFAULT 0,"
              " situacoes TEXT DEFAULT '[]', diario TEXT DEFAULT '[]')")
    c.commit()

from game import clan_repo as CR
from game import clan_habitantes as H

CR.init_clan()
with sqlite3.connect(BANCO) as c:
    colunas = {l[1] for l in c.execute("PRAGMA table_info(clan)").fetchall()}
    tabelas = {l[0] for l in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
exigir({"memorias", "estagio_registrado"} <= colunas,
       f"a migração não criou as colunas novas do clã: faltam "
       f"{ {'memorias', 'estagio_registrado'} - colunas}")
exigir("clan_habitante" in tabelas, "a tabela clan_habitante não foi criada")

DONO = 7
clan = CR.carregar_clan(DONO)

# ── 2) acolher: cobra comida, respeita capacidade, escreve memória ──────
r = CR.acolher_habitante(DONO, random.Random(1))
exigir(not r["ok"], "acolheu alguém sem comida nenhuma no estoque")

with CR._conn() as c:
    c.execute("UPDATE clan SET comida = 200 WHERE owner_id = ?", (DONO,))
    c.commit()
aceitos = 0
for i in range(10):
    if CR.acolher_habitante(DONO, random.Random(10 + i))["ok"]:
        aceitos += 1
cap = H.estagio_da_aldeia(0, 0)["capacidade"]
vivos = CR.listar_habitantes(DONO)
exigir(len(vivos) <= H.ESTAGIOS[1][3],
       f"a aldeia passou da capacidade: {len(vivos)} habitantes")
# 25/09/2026: a capacidade inicial foi pra 200 (dev) — 10 acolhidas não
# lotam mais a aldeia; abaixo do teto, TODAS têm de ser aceitas.
exigir(aceitos >= min(cap, 10), f"só aceitou {aceitos} de 10, com capacidade {cap}")
clan = CR.carregar_clan(DONO)
exigir(clan["comida"] == 200 - H.CUSTO_ACOLHER * aceitos,
       f"acolher não cobrou certo: comida {clan['comida']} depois de {aceitos} acolhidos")
exigir(len(clan["memorias"]) == aceitos,
       f"as Memórias do Clã têm {len(clan['memorias'])} entradas pra {aceitos} chegadas")
exigir(len({h["nome"] for h in vivos}) == len(vivos), "dois habitantes com o mesmo nome")

# ── 3) trocar de profissão zera o nível ─────────────────────────────────
alvo = vivos[0]
with CR._conn() as c:
    c.execute("UPDATE clan_habitante SET nivel = 7, xp = 30 WHERE id = ?", (alvo["id"],))
    c.commit()
nova = "guarda" if alvo["profissao"] != "guarda" else "agricultor"
CR.mudar_habitante(DONO, alvo["id"], profissao=nova)
depois = {h["id"]: h for h in CR.listar_habitantes(DONO)}[alvo["id"]]
exigir(depois["profissao"] == nova and depois["nivel"] == 1 and depois["xp"] == 0,
       f"trocar de profissão não zerou o nível: {depois}")
CR.mudar_habitante(DONO, alvo["id"], descansar=True)
exigir({h["id"]: h for h in CR.listar_habitantes(DONO)}[alvo["id"]]["descansando"] == 1,
       "mandar descansar não gravou")

# ── 4) uma sessão de AFK: a EQUIPE coleta, a aldeia cansa e entra no diário
# (20/09: habitante não produz de dentro da aldeia — só em equipe, num
# posto, com guarda. Todos ganham talento de agricultor; o último, de guarda.)
todos = CR.listar_habitantes(DONO)
with CR._conn() as c:
    for h in todos:
        c.execute("UPDATE clan_habitante SET talentos = ? WHERE id = ?",
                  (json.dumps({"agricultor": 2, "guarda": 1}), h["id"]))
    c.commit()
r_eq = CR.montar_equipe(DONO, "p1_clareira", [h["id"] for h in todos[:-1]], [todos[-1]["id"]], 5)
exigir(r_eq["ok"], f"não montou a equipe da clareira: {r_eq}")
with CR._conn() as c:
    c.execute("UPDATE clan_habitante SET profissao = 'agricultor', descansando = 0, fadiga = 0"
              " WHERE owner_id = ?", (DONO,))
    # couro/madeira/ferro pra manutenção do guarda — sem isso é greve
    c.execute("UPDATE clan SET couro = 20, materiais = '{\"1\": 20}' WHERE owner_id = ?", (DONO,))
    c.execute("UPDATE clan SET comida = 100, madeira = 20, ultimo_tick = ? WHERE owner_id = ?",
              (int(time.time()) - 6 * 3600, DONO))
    c.commit()
antes = CR.carregar_clan(DONO)
rel = CR.rodar_afk(DONO, areas={}, modelos={}, rng=random.Random(3))
depois_clan = CR.carregar_clan(DONO)
exigir(rel["ticks"] > 0, "a sessão de AFK não rodou nenhum tick")
prod = rel["comida"]
exigir(prod > 0, f"a equipe de agricultores não coletou nada na sessão: {rel.get('equipes')}")
esperado = min(CR.carregar_clan(DONO)["comida"], antes["comida"] + prod - rel["consumido"])
exigir(depois_clan["comida"] == max(0, antes["comida"] + prod - rel["consumido"])
       or depois_clan["comida"] == rel.get("teto_comida"),
       f"o estoque não bate: antes {antes['comida']} + produção {prod} - consumo "
       f"{rel['consumido']} ≠ {depois_clan['comida']}")
cansados = [h for h in CR.listar_habitantes(DONO) if h["fadiga"] > 0]
exigir(cansados, "a fadiga dos habitantes não foi gravada depois de trabalhar")
exigir(depois_clan["diario"] and "aldeia" in depois_clan["diario"][0],
       "a aldeia não entrou no diário da sessão")

# ── 5) ferimento do RECUA é gravado, e o curandeiro trata ───────────────
with CR._conn() as c:
    c.execute("INSERT INTO clan_membro(owner_id, slot, nome, nivel, area_id, ferimento, perfil_json,"
              " perfil_nivel) VALUES (?,?,?,?,?,?,?,?)",
              (DONO, 0, "Lutadora", 5, "andar_1", 0, json.dumps({"area": "andar_1"}), 0))
    c.execute("UPDATE clan SET ultimo_tick = ? WHERE owner_id = ?",
              (int(time.time()) - 6 * 3600, DONO))
    c.execute("UPDATE clan_habitante SET profissao = 'agricultor' WHERE owner_id = ?", (DONO,))
    c.commit()

import game.clan_afk as AFK
import game.clan_repo as _CR
original_tick = AFK.rodar_tick
original_perfil = _CR.perfil_do_membro
AFK.rodar_tick = lambda grupo, area, rng=None: {"tipo": "monstro", "resultado": "recua",
                                                 "ferimento": 1, "motivo": "recuou"}
_CR.perfil_do_membro = lambda owner, m, area, modelo: {"area": area.get("id")}
AFK.perfil_do_grupo = lambda perfis: {}
try:
    CR.rodar_afk(DONO, areas={"andar_1": {"id": "andar_1", "nome": "Andar 1", "andar": 1}},
                 modelos={0: {}}, rng=random.Random(4))
finally:
    AFK.rodar_tick = original_tick
    _CR.perfil_do_membro = original_perfil
membro = CR.listar_membros(DONO)[0]
exigir(membro["ferimento"] > 0,
       "o RECUA devolveu ferimento e nada foi gravado no lutador — o bug antigo voltou")

ferido = membro["ferimento"]
with CR._conn() as c:
    c.execute("UPDATE clan_membro SET area_id = NULL WHERE owner_id = ?", (DONO,))
    c.execute("UPDATE clan_habitante SET profissao = 'curandeiro', descansando = 0 WHERE owner_id = ?",
              (DONO,))
    c.execute("UPDATE clan SET ultimo_tick = ? WHERE owner_id = ?",
              (int(time.time()) - 6 * 3600, DONO))
    c.commit()
CR.rodar_afk(DONO, areas={}, modelos={}, rng=random.Random(5))
exigir(CR.listar_membros(DONO)[0]["ferimento"] < ferido,
       "havia curandeiro na aldeia e o ferimento do lutador não baixou")

# ── 6) chefe, especialização e regras: gravados E lidos pela sessão ─────
with CR._conn() as c:
    c.execute("UPDATE clan_membro SET vivo = 0 WHERE owner_id = ?", (DONO,))
    c.execute("UPDATE clan_habitante SET profissao = 'agricultor', nivel = 20, potencial = 5,"
              " fadiga = 0, descansando = 0 WHERE owner_id = ?", (DONO,))
    c.commit()
hab_ids = [h["id"] for h in CR.listar_habitantes(DONO)]


def uma_sessao(semente):
    with CR._conn() as c:
        c.execute("UPDATE clan SET comida = 50, ultimo_tick = ? WHERE owner_id = ?",
                  (int(time.time()) - 6 * 3600, DONO))
        c.execute("UPDATE clan_habitante SET fadiga = 0, descansando = 0 WHERE owner_id = ?", (DONO,))
        c.commit()
    return CR.rodar_afk(DONO, areas={}, modelos={}, rng=random.Random(semente))["aldeia"]


sem_chefe = uma_sessao(7)["producao"]["comida"]
r = CR.nomear_chefe(DONO, "guarda", hab_ids[0])
exigir(not r["ok"], "aceitou um agricultor como Capitão")
r = CR.nomear_chefe(DONO, "agricultor", hab_ids[0])
exigir(r["ok"], f"não nomeou o Chefe da Lavoura: {r}")
exigir(CR.carregar_clan(DONO)["comandantes"].get("agricultor") == hab_ids[0],
       "o chefe não foi gravado no clã")
com_chefe = uma_sessao(7)
exigir(com_chefe["producao"]["comida"] > sem_chefe,
       f"com Chefe da Lavoura Nv.20 a comida não subiu ({sem_chefe} → "
       f"{com_chefe['producao']['comida']}) — o cargo é gravado e ninguém lê")
exigir("agricultor" in (com_chefe.get("chefes") or {}), "a sessão não reconheceu o chefe gravado")

r = CR.escolher_especializacao(DONO, "agricola")
estagio_agora = H.estagio_da_aldeia(len(hab_ids), 0)["indice"]
if estagio_agora < H.ESTAGIO_1A_ESPECIALIZACAO:
    exigir(not r["ok"], "deu identidade à aldeia antes de ela virar Vila")

r = CR.definir_regras(DONO, {"descanso_auto": True, "limite": 50, "volta": 10})
exigir(r["regras"]["descanso_auto"] and r["regras"]["limite"] == 50,
       "as regras de automação não foram gravadas")
with CR._conn() as c:
    c.execute("UPDATE clan SET ultimo_tick = ? WHERE owner_id = ?",
              (int(time.time()) - 6 * 3600, DONO))
    c.execute("UPDATE clan_habitante SET fadiga = 49, descansando = 0 WHERE owner_id = ?", (DONO,))
    c.commit()
aldeia_auto = CR.rodar_afk(DONO, areas={}, modelos={}, rng=random.Random(8))["aldeia"]
exigir(aldeia_auto["descanso_auto"],
       "a regra de descanso estava ligada e ninguém foi mandado descansar")

# ── 7) família: parente acolhido fica gravado com o laço ────────────────
with CR._conn() as c:
    c.execute("UPDATE clan_habitante SET vivo = 0 WHERE owner_id = ? AND id > ?",
              (DONO, hab_ids[1]))
    c.execute("UPDATE clan SET comida = 500 WHERE owner_id = ?", (DONO,))
    c.commit()
achou_parente = False
for semente in range(60):
    r = CR.acolher_habitante(DONO, random.Random(1000 + semente))
    if not r["ok"]:
        break
    if "— é" in r["texto"]:
        achou_parente = True
        break
novos = [h for h in CR.listar_habitantes(DONO) if h.get("parente_de")]
exigir(achou_parente and novos and novos[-1]["laco"],
       "chegou um parente e o vínculo (parente_de/laço) não foi gravado")

if falhas:
    print("❌ ALDEIA (E2E) COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print(f"✅ aldeia no disco: migração, {aceitos} acolhidos, produção {prod} de comida "
      f"na sessão, ferimento gravado e tratado")
