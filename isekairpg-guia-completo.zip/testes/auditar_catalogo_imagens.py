#!/usr/bin/env python3
"""Auditoria do catálogo de imagens (a aba Imagens do /admin).

POR QUE ESTE TESTE EXISTE
-------------------------
O catálogo só vale alguma coisa se a lista de chaves que ele diz que o
jogo pede for A MESMA que o jogo pede de verdade em tempo de execução. Um
catálogo que deriva as chaves por conta própria vira a segunda cópia da
lógica — a armadilha nº 3 deste projeto, que já custou quatro bugs.

Então aqui a auditoria não confere números bonitos: ela GERA monstro,
item, pet e montaria pelos caminhos reais do jogo e exige que a chave
resultante esteja no catálogo. Se alguém mudar a regra de nomes num lugar
só, este arquivo fica vermelho.

O que ele mediu quando nasceu (20/09):
  334 chaves pedidas · 240 com arte própria · 79 faltando
  - 15 montarias sem NENHUMA chave em assets.py (toda montaria mostra a
    Cidade)
  - 24 artes que EXISTEM com o nome acentuado e que o jogo pede sem
    acento: estão no disco e nunca apareceram pra ninguém
  - 38 chaves com acento, que `chave_valida` recusa: /api/imagem devolve
    400 e o espelho nunca as baixa

Depois de `normalizar_chave` (mesmo dia):
  310 chaves pedidas · 240 próprias · 55 faltando · 0 inválidas
As 24 artes órfãs casaram com o que o jogo pede, e os monstros caíram de
57 para 33 faltando sem ninguém desenhar nada.
"""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from webapp.catalogo_imagens import montar_catalogo
from game.assets import resolver_asset_key_inimigo, resolver_asset_key_item

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


cat = montar_catalogo()
todas = {i["chave"] for g in cat["grupos"] for i in g["itens"]}
por_grupo = {g["id"]: g for g in cat["grupos"]}

# 1) Nenhum grupo pode ter estourado nem vir vazio.
for gid in ("telas", "itens", "pets", "montarias", "monstros"):
    g = por_grupo.get(gid)
    exigir(g is not None, f"grupo {gid} sumiu do catálogo")
    if g:
        exigir(not g.get("erro"), f"grupo {gid} estourou: {g.get('erro')}")
        exigir(len(g["itens"]) > 0, f"grupo {gid} veio vazio")

# 2) A chave que o COMBATE pede tem que estar catalogada. Gera monstro de
#    verdade em toda a Torre, inclusive nos andares de boss.
from game.monsters import criar_monstro_por_andar
random.seed(7)
faltou_mob = set()
for andar in range(1, 101):
    for _ in range(6):
        mon = criar_monstro_por_andar(andar)
        alvo = {"raca_nome": mon.get("raca_nome", ""), "name": mon.get("nome", ""),
                "tipo": mon.get("tipo", "normal"), "arquetipo": mon.get("arquetipo")}
        chave = resolver_asset_key_inimigo(alvo)
        if chave not in todas:
            faltou_mob.add(chave)
exigir(not faltou_mob,
       f"o combate pede chaves que o catálogo não lista: {sorted(faltou_mob)[:5]}")

# 3) A chave que o INVENTÁRIO pede idem — inclusive escrita em português,
#    que é como pet e montaria guardam raridade (o bug da classe rar-*).
from game.items import SLOTS, WEAPON_TYPES
faltou_item = set()
for slot in SLOTS:
    for sub in (list(WEAPON_TYPES) if slot == "weapon" else [""]):
        for rar in ("common", "lendário", "Raro", "epic"):
            chave = resolver_asset_key_item(slot, rar, sub)
            if chave not in todas:
                faltou_item.add(chave)
exigir(not faltou_item,
       f"o inventário pede chaves que o catálogo não lista: {sorted(faltou_item)[:5]}")

# 4) Pets e montarias, na forma que explore.py monta ao dropar.
from game.pets_db import PETS_DB
from game.mounts import MOUNTS_DB
for pid in PETS_DB:
    exigir(f"PET_{pid.upper()}" in todas, f"pet fora do catálogo: {pid}")
for mid in MOUNTS_DB:
    exigir(f"MOUNT_{mid.upper()}" in todas, f"montaria fora do catálogo: {mid}")

# 5) Nada some: toda chave de assets.py aparece em algum grupo (nem que
#    seja em "Outras"). Um painel que esconde arte carregada é pior que
#    painel nenhum.
from game.assets import ASSETS
sumidas = [k for k in ASSETS if k not in todas]
exigir(not sumidas, f"chaves de assets.py fora do painel: {sumidas[:5]}")

# 6) Nenhuma chave pode ter acento ou pontuação: `chave_valida` recusa, e
#    aí /api/imagem dá 400 e o espelho nunca baixa. Era o estado de 38
#    chaves até 20/09; `normalizar_chave` fechou isso dos dois lados
#    (quem pede e quem grava). Este bloco é a trava pra não voltar.
from webapp.catalogo_imagens import montar_catalogo as _mc  # noqa: F401
from game.assets import normalizar_chave
invalidas = [i["chave"] for g in cat["grupos"] for i in g["itens"] if not i["valida"]]
exigir(not invalidas,
       f"chave que /api/imagem recusa (acento/pontuação): {invalidas[:5]}")

for bruto, esperado in [
    ("Xamã Goblin", "XAMA_GOBLIN"),
    ("Aranha-Mãe Colossal", "ARANHA_MAE_COLOSSAL"),
    ("Elemental Prisma (3 fases)", "ELEMENTAL_PRISMA_3_FASES"),
    ("Núcleo do Vazio (4 fases + enrage)", "NUCLEO_DO_VAZIO_4_FASES_ENRAGE"),
]:
    exigir(normalizar_chave(bruto) == esperado,
           f"normalizar_chave({bruto!r}) deu {normalizar_chave(bruto)!r}")

# 7) As contagens têm que fechar com os itens.
for g in cat["grupos"]:
    c = g["contagem"]
    soma = c["propria"] + c["repetida"] + c["emprestada"] + c["ausente"]
    exigir(soma == c["total"], f"contagem do grupo {g['id']} não fecha: {c}")

# 8) monstro NORMAL do andar 30 em diante nunca nasce (pesos_do_andar) — o
#    catálogo não pode cobrar arte dele. Regra lida do MESMO lugar do combate.
from game.monsters import RAÇAS_POR_BLOCO, normal_possivel
grupo_mob = {i["chave"] for i in por_grupo["monstros"]["itens"]}
for (ini, fim), dados in RAÇAS_POR_BLOCO.items():
    nasce = any(normal_possivel(a) for a in range(int(ini), int(fim) + 1))
    for tipo in dados.get("tipos", []):
        chave = resolver_asset_key_inimigo({"raca_nome": dados["nome"], "arquetipo": tipo,
                                            "tipo": "normal"})
        if not nasce:
            exigir(chave not in grupo_mob,
                   f"{chave} (andares {ini}–{fim}) nunca nasce e o catálogo cobra arte dele")

# 9) 📤 envio pelo painel: grava, invalida miniatura, versiona, e passa a
#    contar como arte própria no catálogo.
import tempfile, shutil
pasta_antiga = os.getcwd()
tmp = tempfile.mkdtemp()
os.chdir(tmp)
try:
    from webapp import imagens as IMG
    png = b"\x89PNG\r\n\x1a\n" + b"0" * 64
    exigir(not IMG.gravar_envio("MOUNT_MOUNT_C_PONEI", b"texto qualquer")["ok"],
           "aceitou um arquivo que não é imagem")
    exigir(not IMG.gravar_envio("chave com espaço", png)["ok"], "aceitou chave inválida")
    os.makedirs(IMG.PASTA_MINIATURAS, exist_ok=True)
    velha = os.path.join(IMG.PASTA_MINIATURAS, "MOUNT_MOUNT_C_PONEI_128.jpg")
    open(velha, "wb").write(b"velha")
    r = IMG.gravar_envio("MOUNT_MOUNT_C_PONEI", png)
    exigir(r["ok"] and r.get("versao"), f"o envio de um PNG válido falhou: {r}")
    exigir(not os.path.exists(velha), "a miniatura antiga ficou — a tela pequena mostraria a arte velha")
    exigir(IMG.tipo_da_imagem(IMG.ler_local("MOUNT_MOUNT_C_PONEI")) == "image/png",
           "o PNG enviado não é servido como PNG")
    exigir("MOUNT_MOUNT_C_PONEI" in IMG.versoes_enviadas(), "o envio não gravou versão (cache de 24h)")
    cat2 = montar_catalogo()
    item = next((i for g in cat2["grupos"] for i in g["itens"] if i["chave"] == "MOUNT_MOUNT_C_PONEI"), None)
    exigir(item and item["estado"] == "propria" and item["enviada"],
           f"a montaria com arte enviada continua como faltando no catálogo: {item}")
    # 🐛 20/09: com o espelho no disco, chave que tem file_id mas NÃO tem
    # arquivo (as 31 com acento que o espelho recusou) é "sem_arquivo" e
    # conta como faltando — antes contava como arte própria e o jogo
    # mostrava emoji (xamã goblin, chefe do andar 20).
    cat3 = montar_catalogo()
    xama = next(i for g in cat3["grupos"] for i in g["itens"] if i["chave"] == "MOB_XAMA_GOBLIN")
    exigir(xama["estado"] == "sem_arquivo", f"o Xamã Goblin sem arquivo não aparece como faltando: {xama}")
    exigir(cat3["total"]["faltando"] > cat2["total"]["faltando"] - 1 and cat3["total"].get("sem_arquivo", 0) > 0,
           "o total de faltando não conta as chaves sem arquivo")
finally:
    os.chdir(pasta_antiga)
    shutil.rmtree(tmp, ignore_errors=True)

t = cat["total"]
print(f"📊 {t['total']} chaves pedidas · {t['propria']} próprias · "
      f"{t['repetida']} dividindo arte · {t['faltando']} faltando · "
      f"{t['invalidas']} com chave inválida")
for g in cat["grupos"]:
    c = g["contagem"]
    print(f"   {g['titulo']}: {c['faltando']}/{c['total']} faltando")

if falhas:
    print("\n❌ CATÁLOGO DE IMAGENS COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ catálogo de imagens bate com o que o jogo pede")
