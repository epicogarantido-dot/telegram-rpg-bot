#!/usr/bin/env python3
"""Toda tabela do projeto migra banco VELHO — sem lista feita à mão.

POR QUE EXISTE
--------------
A armadilha nº 14: `CREATE TABLE IF NOT EXISTS` não conserta tabela que já
existe. Produção caiu com `no such column: equip_poder` porque o banco
nasceu antes da coluna. Em 20/09 as 16 tabelas que ainda tinham esse risco
passaram a chamar `infra.migracao.garantir_colunas` com a MESMA string do
CREATE.

Este teste não lista tabela nenhuma: ele varre os módulos atrás de toda
constante `_SQL_*` com CREATE TABLE, monta cada tabela no formato mais
velho possível (só a PRIMEIRA coluna), roda a migração e exige que todas
as colunas do CREATE apareçam. Tabela nova que alguém criar com o mesmo
padrão entra no teste sozinha — e tabela nova criada FORA do padrão (um
`execute("CREATE TABLE ...")` solto) é recusada pela varredura do fim.
"""
import sys, os, re, sqlite3, types, importlib

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

from infra.migracao import tabelas_do_sql, garantir_colunas, definicao_para_alter

# Alguns módulos abrem o banco já no import (caminho relativo "data/...").
# Roda num diretório temporário pra nunca tocar num banco de verdade.
import tempfile
_pasta = tempfile.mkdtemp()
os.makedirs(os.path.join(_pasta, "data"), exist_ok=True)
os.chdir(_pasta)

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


# ── 1) o parser aguenta o que existe de verdade nos CREATE ──────────────
t = tabelas_do_sql("""
    CREATE TABLE IF NOT EXISTS a (
        owner_id INTEGER NOT NULL,   -- dono, com vírgula, no comentário
        slot INTEGER NOT NULL,
        preco TEXT DEFAULT (printf('%d,%d', 1, 2)),
        PRIMARY KEY (owner_id, slot)
    );
    CREATE INDEX IF NOT EXISTS i ON a(slot);
    CREATE TABLE IF NOT EXISTS b (id INTEGER PRIMARY KEY AUTOINCREMENT, x TEXT UNIQUE);
""")
exigir([c for c, _ in t.get("a", [])] == ["owner_id", "slot", "preco"],
       f"o parser errou as colunas de 'a': {t.get('a')}")
exigir([c for c, _ in t.get("b", [])] == ["id", "x"], f"o parser errou 'b': {t.get('b')}")
exigir("PRIMARY" not in definicao_para_alter("INTEGER PRIMARY KEY AUTOINCREMENT").upper(),
       "o ALTER tentaria acrescentar uma PRIMARY KEY — o SQLite recusa")
exigir("NOT NULL" not in definicao_para_alter("INTEGER NOT NULL").upper(),
       "NOT NULL sem DEFAULT iria pro ALTER — o SQLite recusa")
exigir("NOT NULL" in definicao_para_alter("INTEGER NOT NULL DEFAULT 0").upper(),
       "NOT NULL COM DEFAULT foi tirado sem precisar")

# ── 2) toda constante _SQL_* de todo módulo migra banco velho ───────────
MODULOS = ["game.arena_week_repo", "game.characters", "game.global_boss_repo",
           "game.premium_system", "game.raid_repo", "game.trade_repo",
           "game.sql_repo", "webapp.avisos", "webapp.contas"]
tabelas_testadas = []
for nome_mod in MODULOS:
    try:
        mod = importlib.import_module(nome_mod)
    except Exception as e:
        falhas.append(f"{nome_mod} não importa: {e}")
        continue
    fonte_mod = open(mod.__file__, encoding="utf-8").read()
    for nome, valor in vars(mod).items():
        if not (nome.startswith("_SQL_") and isinstance(valor, str)):
            continue
        # A constante precisa ser MIGRADA no init, não só executada: criar e
        # esquecer de migrar é exatamente o bug que isto veio fechar.
        exigir(re.search(rf"garantir_colunas(?:_async)?\(\s*\w+\s*,\s*{nome}\s*\)", fonte_mod),
               f"{nome_mod}: {nome} cria a tabela mas o init não chama a migração com ela")
        for tabela, cols in tabelas_do_sql(valor).items():
            conn = sqlite3.connect(":memory:")
            # A versão mais velha possível: só a primeira coluna.
            primeira, definicao = cols[0]
            conn.execute(f"CREATE TABLE {tabela} ({primeira} {definicao})")
            try:
                garantir_colunas(conn, valor)
            except Exception as e:
                falhas.append(f"{tabela} ({nome_mod}): a migração estourou — {e}")
                continue
            no_disco = {l[1] for l in conn.execute(f"PRAGMA table_info({tabela})")}
            faltam = [c for c, _ in cols if c not in no_disco]
            exigir(not faltam, f"{tabela}: banco velho continua sem {faltam}")
            # E rodar de novo não faz nada (idempotente, é chamado a cada boot).
            exigir(garantir_colunas(conn, valor) == [], f"{tabela}: migrar de novo mexeu de novo")
            tabelas_testadas.append(tabela)

esperadas = {"arena_week", "character_storage", "active_slot", "character_market", "global_boss",
             "premium_wallet", "premium_history", "player_registry", "raid_rooms", "marketplace",
             "avisos", "usuarios", "sessoes", "codigos_vinculo", "players", "arena_snapshots"}
exigir(esperadas <= set(tabelas_testadas),
       f"tabelas que deviam estar cobertas e não estão: {sorted(esperadas - set(tabelas_testadas))}")

# ── 3) nenhum CREATE TABLE solto fora do padrão ─────────────────────────
soltos = []
for raiz, _d, arquivos in os.walk(RAIZ):
    if "testes" in raiz or "__pycache__" in raiz:
        continue
    for arq in arquivos:
        # clan_repo tem o TABELAS próprio, que já migra. (infra/db.py e
        # infra/repo.py, código morto do bot, foram apagados em 20/09.)
        if not arq.endswith(".py") or arq in ("migracao.py", "clan_repo.py"):
            continue
        caminho = os.path.join(raiz, arq)
        texto = open(caminho, encoding="utf-8").read()
        for m in re.finditer(r"execute(?:script)?\(\s*[rf]?[\"']{1,3}\s*CREATE TABLE", texto):
            soltos.append(os.path.relpath(caminho, RAIZ))
exigir(not soltos, f"CREATE TABLE solto (sem migração) em: {sorted(set(soltos))}")

if falhas:
    print("❌ MIGRAÇÕES COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print(f"✅ {len(tabelas_testadas)} tabelas migram banco velho a partir do próprio CREATE "
      f"(e o clã segue com o TABELAS dele)")
