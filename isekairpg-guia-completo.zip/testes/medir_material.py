#!/usr/bin/env python3
"""Quanto material se consegue nos andares 5 e 10 (pedido do dev, 20/09).

Mede, com os geradores e motores REAIS do jogo, cada fonte de material:
  A) a Torre do jogador — no andar de chefe (5, 10) e no andar comum antes
     dele (4, 9): material por luta vencida;
  B) a Travessia do clã chegando ao andar (4→5, 9→10), com o grupo "no
     ponto" (nível 2× o andar): material por travessia;
  C) as equipes da aldeia num Veio (só existe do andar 6 em diante): ferro
     (rank 1) por sessão, sem e com a Mina do mapa.
Regra vigente: comum deixa 1 de rank 1 em 35% das vezes; elite/general
deixam 1 de rank 2; chefe deixa 1 de rank 3.
"""
import sys, os, types, random, statistics
from collections import Counter

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: None
    sys.modules["aiosqlite"] = falso

import game.logic as L
from game import monsters as M
from game import clan_jornada as T
from game import clan_equipes as E
from game import territorio as TR
from game.clan_materiais import material_do_monstro

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


def por_luta_na_torre(andar, n=20000, semente=1):
    """Média de material por luta VENCIDA na Torre, com o spawn real."""
    random.seed(semente)
    rng = random.Random(semente)
    total = Counter()
    for _ in range(n):
        bosses = M.get_bosses_no_andar(andar)
        if bosses:
            tipos = ["boss"] * bosses
        else:
            tipos = [M.criar_monstro_por_andar(andar).get("tipo", "normal")
                     for _ in range(L.qtd_monstros_por_andar(andar))]
        for t in tipos:
            rank, qtd = material_do_monstro(andar, t, rng)
            total[rank] += qtd
    return {r: total[r] / n for r in (1, 2, 3)}


def ficha(nivel):
    p = {"telegram_id": 1, "level": nivel, "xp": 0, "xp_next": 9 ** 9, "gold": 0, "tower_floor": 1,
         "hp": 100, "hp_max": 100, "state": "TOWER", "class_id": None, "race_id": None,
         "attrs": {k: nivel for k in ("str", "vit", "agi", "dex")}, "trails": {}, "combat": None,
         "inv": {"potion": 0, "cores": {}, "items": {}}, "equip": {},
         "pets": {"owned": {}, "deck": [None] * 5}, "skills_learned": {},
         "skill_slots": {"equipped": [None] * 5}, "chakra": None}
    L.recalc(p)
    return p


def por_travessia(destino, n=150, semente=2):
    rng = random.Random(semente)
    f = ficha(2 * destino)
    total, chegou = Counter(), 0
    for _ in range(n):
        t = T.nova_travessia(destino - 1, destino, [T.lutador(i, f"L{i}", f) for i in range(5)],
                             T.comida_maxima(destino, 5), rng)
        while not t["fim"]:
            T.mudar_tatica(t, "ofensiva" if any(e["tipo"] == "boss" for e in t["inimigos"]) else "defensiva")
            T.avancar(t, rng, 1)
        r = T.resultado_final(t)
        chegou += r["chegou"]
        for rank, q in r["material"].items():
            total[int(rank)] += q
    return {r: total[r] / n for r in (1, 2, 3)}, chegou / n


print("A) TORRE — material por luta vencida")
print(f"{'andar':>6} {'rank 1':>8} {'rank 2':>8} {'rank 3':>8}")
torre = {}
for andar in (4, 5, 9, 10):
    torre[andar] = por_luta_na_torre(andar)
    m = torre[andar]
    print(f"{andar:>6} {m[1]:>8.2f} {m[2]:>8.2f} {m[3]:>8.2f}")
exigir(torre[5][3] == 1 and torre[10][3] == 1, "a luta do andar de chefe não dá 1 de rank 3")
exigir(torre[4][3] == 0 and torre[9][3] == 0, "andar comum deu rank 3")

print("\nB) TRAVESSIA DO CLÃ — material por travessia (grupo no ponto, 5 lutadores)")
for destino in (5, 10):
    m, taxa = por_travessia(destino)
    print(f"  {destino - 1}→{destino}: chega {100 * taxa:.0f}% · rank 1 {m[1]:.1f} · rank 2 {m[2]:.1f} · rank 3 {m[3]:.2f}")

print("\nC) EQUIPES DA ALDEIA — ferro (rank 1) por sessão num Veio ★★")
mina5 = TR.fracao_de_bonus(1)
mina10 = TR.fracao_de_bonus(2)
for estrelas in (1, 3, 5):
    for nivel in (1, 20):
        h = {"talentos": {"minerador": estrelas}, "nivel": nivel}
        q = E.producao_do_coletor(h, "ferro")
        print(f"  minerador {estrelas}★ Nv{nivel:>2}: {q:5.1f}/sessão · com a Mina do andar 10 "
              f"(+{100 * mina10:.0f}%): {q * (1 + mina10):5.1f}")
print(f"  (andar 5: o Veio existe desde 20/09; com a Mina do andar 5, +{100 * mina5:.0f}%)")
exigir("veio" in __import__("game.clan_postos", fromlist=["x"]).pool_do_andar(5),
       "o andar 5 não tem Veio — a Mina de lá não multiplica nada")

if falhas:
    print("\n❌ MEDIÇÃO COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("\n✅ medição de material nos andares 5 e 10")
