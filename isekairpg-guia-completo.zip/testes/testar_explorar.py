#!/usr/bin/env python3
"""🔎 Explorar o andar (20/09, pedido do dev), no banco.

- só equipe COM GUARDA explora; cada busca custa comida;
- a emboscada que a escolta não segura cansa a equipe;
- a busca volta com até 5 achados do andar (postos, pontos, cidades);
- escolher um POSTO: ele é descoberto e a equipe fica lá;
- escolher um PONTO: a equipe vira a do ponto e marcha (batalha se tiver dono);
- escolher uma CIDADE: vencendo, a guarnição de lá morre e 20% do estoque
  vem; perdendo, a regra de sempre (guardas mortos, coletores levados).
"""
import sys, os, json, random, tempfile, types

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

BANCO = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = BANCO
from game import clan_repo as CR
from game import clan_explorar as X

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


class Dado(random.Random):
    def __init__(self, v): super().__init__(1); self.v = v
    def random(self): return self.v


CR.init_clan()


def clan(dono, g_estrelas, n_g, n_c, comida=500):
    CR.carregar_clan(dono)
    ids = {"g": [], "c": []}
    with CR._conn() as c:
        c.execute("UPDATE clan SET andar = 5, comida = ?, madeira = 100, couro = 100,"
                  " materiais = '{\"1\": 100}' WHERE owner_id = ?", (comida, dono))
        for i in range(n_g):
            ids["g"].append(c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial,"
                                      " fadiga, descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
                                      (dono, f"G{dono}-{i}", "guarda", 20, 1, 0, 0, 0, 1,
                                       json.dumps({"guarda": g_estrelas}))).lastrowid)
        for i in range(n_c):
            ids["c"].append(c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial,"
                                      " fadiga, descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
                                      (dono, f"C{dono}-{i}", "agricultor", 5, 1, 0, 0, 0, 1,
                                       json.dumps({"agricultor": 2}))).lastrowid)
        c.commit()
    return ids


A = 21
ia = clan(A, 3, 2, 2)
CR.montar_equipe(A, "p1_clareira", [], [], 30)          # (sem gente: não explora)
exigir(not CR.explorar_com_equipe(A, "p1_clareira", 30)["ok"], "equipe sem guarda explorou")
exigir(CR.montar_equipe(A, CR.EQUIPE_DO_PONTO, ia["c"], ia["g"], 30)["ok"], "não montou a equipe")

antes = CR.carregar_clan(A)["comida"]
r = CR.explorar_com_equipe(A, CR.EQUIPE_DO_PONTO, 30, Dado(0.99))
exigir(r["ok"] and 1 <= len(r["lista"]) <= X.TAMANHO_DA_LISTA, f"a busca não voltou com até 5 achados: {r}")
exigir(CR.carregar_clan(A)["comida"] == antes - X.custo_da_busca(5), "explorar não cobrou a comida")
exigir(CR.carregar_clan(A)["madeira"] == 100 - X.madeira_da_busca(5),
       "explorar não cobrou a madeira (lenha da tocha e da fogueira)")
with CR._conn() as c:
    c.execute("UPDATE clan SET madeira = 0 WHERE owner_id = ?", (A,))
    c.commit()
comida_sem_lenha = CR.carregar_clan(A)["comida"]
exigir(not CR.explorar_com_equipe(A, CR.EQUIPE_DO_PONTO, 30, Dado(0.99))["ok"]
       and CR.carregar_clan(A)["comida"] == comida_sem_lenha,
       "explorou sem madeira — ou cobrou a comida de uma busca recusada")
with CR._conn() as c:
    c.execute("UPDATE clan SET madeira = 100 WHERE owner_id = ?", (A,))
    c.commit()
tipos = {a["tipo"] for a in CR.explorar_com_equipe(A, CR.EQUIPE_DO_PONTO, 30, random.Random(4))["lista"]}
exigir("ponto" in tipos, f"a busca no Andar 5 não achou ponto nenhum: {tipos}")

# emboscada que passa pela escolta: equipe volta cansada
fraco = 22
ifr = clan(fraco, 1, 1, 1)
with CR._conn() as c:
    c.execute("UPDATE clan_habitante SET nivel = 1 WHERE owner_id = ?", (fraco,))
    c.commit()
CR.montar_equipe(fraco, CR.EQUIPE_DO_PONTO, ifr["c"], ifr["g"], 30)
r = CR.explorar_com_equipe(fraco, CR.EQUIPE_DO_PONTO, 50, Dado(0.0))   # 0.0 = sempre emboscada
exigir(r["emboscada"] and r["emboscada"]["ferido"], "a emboscada não aconteceu / não passou pela escolta fraca")
exigir(all(h["fadiga"] >= X.CANSACO_DA_EMBOSCADA for h in CR.listar_habitantes(fraco)),
       "a equipe emboscada não voltou cansada")

# escolher um POSTO: descoberto e a equipe fica lá
lista = CR.explorar_com_equipe(A, CR.EQUIPE_DO_PONTO, 30, random.Random(8))["lista"]
i_posto = next((i for i, a in enumerate(lista) if a["tipo"] == "posto"), None)
if i_posto is None:
    for s in range(20):
        lista = CR.explorar_com_equipe(A, CR.EQUIPE_DO_PONTO, 30, random.Random(100 + s))["lista"]
        i_posto = next((i for i, a in enumerate(lista) if a["tipo"] == "posto"), None)
        if i_posto is not None:
            break
exigir(i_posto is not None, "20 buscas e nenhum posto")
if i_posto is not None:
    pid = lista[i_posto]["posto"]["id"]
    r = CR.escolher_achado(A, i_posto, "Clã A", 30)
    exigir(r["ok"] and pid in CR.postos_descobertos(A) and pid in CR.equipes_do_cla(A),
           f"escolher o posto não descobriu nem levou a equipe pra lá: {r}")
    exigir(not CR.achados_do_cla(A), "a lista não foi consumida ao escolher")

# atacar uma CIDADE do mesmo andar
D = 23
idd = clan(D, 1, 1, 0)
CR.montar_equipe(D, CR.EQUIPE_DA_CIDADE, [], idd["g"], 30)
CR.montar_equipe(A, CR.EQUIPE_DO_PONTO, [], ia["g"], 30)
comida_d = CR.carregar_clan(D)["comida"]
r = CR.atacar_cidade(A, D, CR.EQUIPE_DO_PONTO, "Clã A", Dado(0.0))
exigir(r["venceu"] and r["saque"]["comida"] == int(comida_d * 0.2), f"o saque da cidade não levou 20%: {r}")
exigir("G23-0" not in {h["nome"] for h in CR.listar_habitantes(D)}, "a guarnição vencida sobreviveu")
# e perder o ataque custa a equipe
E_ = 24
ie = clan(E_, 1, 1, 1)
CR.montar_equipe(E_, CR.EQUIPE_DO_PONTO, ie["c"], ie["g"], 30)
r = CR.atacar_cidade(E_, A, CR.EQUIPE_DO_PONTO, "Clã E", Dado(0.9999))
exigir(r["venceu"] is False and "C24-0" in {h["nome"] for h in CR.listar_habitantes(A)},
       f"o atacante derrotado não perdeu os coletores pra cidade: {r}")

if falhas:
    print("❌ EXPLORAR COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ explorar: só com guarda, custa comida e madeira, emboscada cansa, 5 achados, posto/ponto/cidade levam a equipe")
