#!/usr/bin/env python3
"""Postos por andar, achados explorando (20/09).

POR QUE EXISTE
--------------
O dev pediu: a lista de postos depende do andar, e achar é sorte — "nem
sempre tu acha o posto que deseja". As duas metades quebram em silêncio:
se a busca achar sempre, explorar vira botão; se o raro não for raro, a
escolha de onde procurar some. Este teste mede:
- a lista cresce com o andar (raso não tem veio, fundo tem veio profundo);
- uma busca acha em ~60% das vezes, e o tipo achado é SORTEADO — quem
  procura veio no andar 12 acha bosque, caça, clareira...;
- o raro (Veio Profundo, Nascente) sai bem menos que o comum;
- cada andar se esgota (um de cada tipo), e explorar esgotado não acha;
- a ★ também é sorte, com ★3 rara;
- todo posto vira uma área que o AFK entende.
"""
import sys, os, random
from collections import Counter

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
from game import clan_postos as P

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


exigir("veio" not in P.pool_do_andar(2), "o Andar 2 já tem veio de minério")
exigir("veio_rico" in P.pool_do_andar(12) and "veio_rico" not in P.pool_do_andar(11),
       "o Veio Profundo não começa no Andar 12")
exigir(len(P.pool_do_andar(20)) > len(P.pool_do_andar(1)), "a lista não cresce com o andar")

rng = random.Random(1)
N = 6000
achou, tipos, estrelas = 0, Counter(), Counter()
for _ in range(N):
    r = P.explorar(12, {}, rng)
    if r:
        achou += 1
        tipos[r["tipo"]] += 1
        estrelas[r["estrelas"]] += 1
taxa = achou / N
print(f"Andar 12: acha em {100 * taxa:.0f}% · tipos {dict(tipos)} · ★ {dict(estrelas)}")
exigir(0.55 <= taxa <= 0.65, f"a busca acha em {100 * taxa:.0f}% (esperado ~60%)")
exigir(tipos["veio_rico"] * 3 < tipos["clareira"], "o Veio Profundo sai quase tanto quanto a Clareira")
exigir(len(tipos) == len(P.pool_do_andar(12)), "algum tipo do andar nunca sai")
exigir(estrelas[3] * 2 < estrelas[1], "★★★ sai quase tanto quanto ★")

# esgota: um de cada tipo por andar
desc = {}
for _ in range(500):
    r = P.explorar(7, desc, rng)
    if r:
        exigir(r["id"] not in desc, "achou de novo um posto que já tinha sido achado")
        desc[r["id"]] = r
exigir(len(desc) == len(P.pool_do_andar(7)), "o Andar 7 não se esgotou com buscas suficientes")
exigir(P.explorar(7, desc, rng) is None, "explorar um andar esgotado ainda achou algo")

for pid, pt in desc.items():
    area = P.area_do_posto(pt)
    for campo in ("id", "andar", "nome", "rank", "rende", "recurso"):
        exigir(campo in area, f"{pid}: a área do posto não tem '{campo}' — o AFK precisa")
    exigir(isinstance(area["rende"], int) and area["rende"] >= 1, f"{pid}: rende não é inteiro positivo")

if falhas:
    print("❌ POSTOS COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ postos: a lista cresce com o andar, achar é sorte (~60%), o raro é raro, o andar se esgota")
