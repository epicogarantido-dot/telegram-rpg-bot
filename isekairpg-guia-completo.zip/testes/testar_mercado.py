#!/usr/bin/env python3
"""O mercado cobra pra anunciar e paga quem vende — e a TELA mostra isso.

POR QUE ESTE TESTE EXISTE
-------------------------
Foi relatado que o mercado "não cobra pra anunciar e não paga quando vende".
Medindo, a carteira estava certa o tempo todo: 100⭐ -> 50⭐ ao anunciar
(taxa de 50) e 50⭐ -> 350⭐ ao vender por 300. Nenhum ⭐ se perdeu.

O errado era o que a tela lia. A carteira mora no premium.db; `p["premium"]`
é só uma CÓPIA. `spend_premium`/`add_premium` mexem no banco e não tocam na
cópia, então a rota devolvia o saldo velho e o jogador via o número parado —
que é indistinguível de "não cobrou".

Por isso o teste confere as DUAS coisas: a carteira e a cópia. Conferir só a
carteira teria dado verde com o bug em pé.
"""
import sys, os, tempfile

base = tempfile.mkdtemp()
os.chdir(base)
os.makedirs("data", exist_ok=True)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    import aiosqlite  # noqa: F401
except ImportError:
    print("⚠️  aiosqlite não instalado — rode no servidor, onde ele existe.")
    sys.exit(2)

os.environ["DB_PATH"] = os.path.join(base, "data", "game.db")
import game.sql_repo as SR; SR.DB_PATH = os.environ["DB_PATH"]
import asyncio
asyncio.set_event_loop(asyncio.new_event_loop())
if hasattr(SR, "init_db"): asyncio.get_event_loop().run_until_complete(SR.init_db())

from game.premium_system import premium_repo, ensure_premium_player
from game import trade_repo
from game.logic import marketplace_list_item, marketplace_buy_item

def wallet(pid): return premium_repo.get_premium(pid)

VEND, COMP = 1001, 1002
vendedor = {"telegram_id": VEND, "username": "Vendedor",
            "inv": {"items": {"arma": [{"name": "Espada Teste", "rar": "raro", "bonus": {"atk": 10}}]}}}
comprador = {"telegram_id": COMP, "username": "Comprador", "inv": {"items": {}}}

pid_v = ensure_premium_player(vendedor, user_id=VEND)
pid_c = ensure_premium_player(comprador, user_id=COMP)
premium_repo.add_premium(pid_v, 100, "seed")
premium_repo.add_premium(pid_c, 500, "seed")

print(f"antes:   vendedor {wallet(pid_v)}⭐   comprador {wallet(pid_c)}⭐")

msg = marketplace_list_item(vendedor, "arma", 0, price=300)
print(f"\nanunciar -> {msg.strip()}")
print(f"  carteira do vendedor: {wallet(pid_v)}⭐  (esperado 50 = 100-50 de taxa)")
print(f"  p['premium'] do vendedor: {vendedor.get('premium')}  <- é o que a tela mostra")

itens = trade_repo.trade_repo.get_all_items() if hasattr(trade_repo, "trade_repo") else trade_repo.get_all_items()
print(f"  anúncios no mercado: {len(itens)}")
if not itens:
    print("  ❌ nada foi anunciado"); sys.exit(1)

item_id = itens[0]["id"]
ok, msg = marketplace_buy_item(comprador, item_id)
print(f"\ncomprar -> ok={ok} {msg.strip()}")
print(f"  carteira do comprador: {wallet(pid_c)}⭐  (esperado 200 = 500-300)")
print(f"  carteira do vendedor:  {wallet(pid_v)}⭐  (esperado 350 = 50+300)")
print(f"  p['premium'] do vendedor: {vendedor.get('premium')}  <- NÃO foi atualizado?")
print(f"  p['premium'] do comprador: {comprador.get('premium')}")


falhou = 0


def checar(nome, cond, det=""):
    global falhou
    print(("  ✅ " if cond else "  ❌ ") + nome + ("" if cond else f"  -> {det}"))
    if not cond:
        falhou = 1


print("\nconferindo:")
checar("a taxa de 50⭐ saiu da carteira do vendedor", wallet(pid_v) == 350,
       wallet(pid_v))
checar("o comprador pagou os 300⭐", wallet(pid_c) == 200, wallet(pid_c))
checar("a venda caiu na carteira do vendedor (50 + 300)", wallet(pid_v) == 350,
       wallet(pid_v))
checar("o saldo que a TELA lê acompanhou o do comprador",
       comprador.get("premium") == 200, comprador.get("premium"))
checar("o anúncio saiu do mercado depois de vendido",
       len(trade_repo.trade_repo.get_all_items()
           if hasattr(trade_repo, "trade_repo") else trade_repo.get_all_items()) == 0)
checar("o item entrou no inventário do comprador",
       bool((comprador.get("inv") or {}).get("items", {}).get("arma")),
       comprador.get("inv"))

print("\n" + ("🟢 MERCADO: TUDO PASSOU" if not falhou else "❌ MERCADO: FALHOU"))
sys.exit(falhou)
