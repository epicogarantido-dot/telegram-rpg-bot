#!/usr/bin/env python3
"""✨ Míticos (28/09): gatilhos que funcionam e o catálogo da Fusão.

Antes de 28/09, três míticos faziam o contrário ou nada:
- Cinturão do Avatar do Equilíbrio (heal_mult 0.50): cura ×0,5 (cortava);
- Punhos/Faixa da Fúria Titânica (berserk): sem a especialidade Fúria nunca
  ligava (faltava o limiar de vida que só ela dava); e o valor, somado a
  partir de zero, valeria ×1,0 / ×0,9 em vez de +100% / +90%;
- Armadura/Broquel da Dama de Ferro (dobrar o rebote): nada no jogo dava o
  rebote base (thorns_pct), então nunca disparava.
E o catálogo: 45 itens, cada um com arte própria, habilidade e um gatilho
descrito em português (nenhum caindo no "nome_da_chave: valor").
"""
import os, sys, types
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    f = types.ModuleType("aiosqlite"); f.connect = lambda *a, **k: None; sys.modules["aiosqlite"] = f
import game.logic as L
from game.mythic_items import criar_item_mitico_do_banco, catalogo_miticos, MYTHIC_ITEMS_DB

falhas = []
def exigir(c, m):
    print(("✅ " if c else "❌ ") + m)
    if not c: falhas.append(m)

def gatilhos(slot, mit_id, hp=1.0, spec=None):
    p = L.create_player(1); p["class_id"] = "guerreiro"; p["race_id"] = "humano"
    if spec: p["specialties"] = [spec]
    p["equip"][slot] = criar_item_mitico_do_banco(slot, mit_id)
    L.recalc(p); p["hp"] = int(p["hp_max"] * hp)
    return L.get_combat_triggers(p)

t = gatilhos("belt", "mit_belt_5")
exigir(abs(t["heal_mult"] - 1.5) < 1e-9, f"Cinturão do Avatar: curas ×1,5 (era ×0,5) → {t['heal_mult']}")
exigir(gatilhos("gloves", "mit_gloves_5", 1.0).get("dmg_mult_active") is None, "Fúria Titânica com vida cheia: sem bônus")
v = gatilhos("gloves", "mit_gloves_5", 0.3).get("dmg_mult_active")
exigir(v == 2.0, f"Fúria Titânica abaixo de 50% de vida: dano ×2 (antes nunca ligava) → {v}")
v = gatilhos("belt", "mit_belt_2", 0.3).get("dmg_mult_active")
exigir(abs((v or 0) - 1.9) < 1e-9, f"Faixa da Fúria abaixo de 50%: dano ×1,9 (antes nunca ligava) → {v}")
t = gatilhos("armor", "mit_armor_3")
exigir(t.get("thorns_pct") == L.ESPINHOS_DA_DAMA_DE_FERRO and t.get("reflect_double_chance") == 20,
       "Dama de Ferro: agora devolve 20% do dano (base que faltava) e tem 20% de chance de dobrar")
reb, _, _ = L.calc_thorns_and_counters(100, t, 0, 999)
exigir(reb in (20, 40), f"Dama de Ferro rebate de verdade num golpe de 100 (rebateu {reb})")
t = gatilhos("armor", "mit_armor_1")
exigir("thorns_pct" not in t, "mítico sem 'dobrar rebote' não ganha espinhos de brinde")

cat = catalogo_miticos()
exigir(len(cat) == sum(len(v) for v in MYTHIC_ITEMS_DB.values()) == 45, f"catálogo com os 45 míticos ({len(cat)})")
exigir(len({x["img_key"] for x in cat}) == 45 and all(x["img_key"].startswith("MITICO_") for x in cat),
       "cada mítico com a sua arte (MITICO_...)")
crus = [x["nome"] for x in cat if "_" in x["gatilho"]]
exigir(not crus, f"todo gatilho descrito em português (sem chave crua): {crus[:3]}")
exigir(all(x["skill"]["nome"] and x["skill"]["efeitos"] for x in cat), "toda habilidade própria existe e tem efeito descrito")
ex = next(x for x in cat if x["mit_id"] == "mit_weapon_1")
exigir(ex["skill"]["efeitos"][0] == "Dano de 260% do seu ataque no alvo",
       f"a habilidade mostra a versão do mítico (400% × 65% = 260%), não a normal: {ex['skill']['efeitos'][0]}")
exigir(not any("Recarga" in e or "todos" in e for x in cat for e in x["skill"]["efeitos"]),
       "nada da skill normal que o mítico não faz (recarga própria, 'em todos')")
exigir(all(x["bonus_raridade"] and x["bonus_raridade"]["pct"] == 30 for x in cat), "bônus de raridade do mítico: +30%")

print("\n" + ("🟢 MÍTICOS: TUDO PASSOU" if not falhas else f"🔴 {len(falhas)} FALHA(S)"))
sys.exit(1 if falhas else 0)
