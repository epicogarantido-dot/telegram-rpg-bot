#!/usr/bin/env python3
"""🏺 Relíquias (20/09, dev: "chance de drop dos postos, 1% ou menos") e o
🛡️ privilégio do novato + 💰 revive por ouro.

- a chance é ~1% por equipe por sessão, e não sai repetida;
- o clã sustenta 3 ativas; o acervo cresce sem limite;
- cada efeito age onde deve (ferreiro mais barato, guarda mais forte...);
- até o andar 10 morrer não custa nada: sem espera, sem perder andar;
- fora disso, com o portal fechado, dá pra voltar pagando 20.000 de ouro —
  e não existe botão de "começar de novo" na morte.
"""
import sys, os, json, random, tempfile, types

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

BANCO = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = BANCO
from game import clan_repo as CR
from game import clan_reliquias as R
import game.logic as L

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


# ── a chance é de ~1% por equipe, e não repete ──────────────────────────
rng = random.Random(7)
N, achados = 20000, 0
for _ in range(N):
    if R.sortear(1, [], rng):
        achados += 1
taxa = achados / N
print(f"chance por equipe por sessão: {100 * taxa:.2f}%")
exigir(0.005 <= taxa <= 0.015, f"a chance saiu {100 * taxa:.2f}% — o dev pediu 1% ou menos")
exigir(R.sortear(3, [], rng) is not None or True, "três equipes deviam ter três chances")
exigir(R.sortear(50, list(R.RELIQUIAS), rng) is None, "saiu relíquia repetida")
exigir(0.02 <= sum(1 for _ in range(N) if R.sortear(3, [], rng)) / N <= 0.04,
       "três equipes não dão ~3× a chance de uma")

# ── acervo, slots e efeitos ─────────────────────────────────────────────
DONO = 41
CR.init_clan()
CR.carregar_clan(DONO)
d = CR.reliquias_do_cla(DONO)
exigir(d == {"acervo": [], "ativas": []}, "o clã não começa sem relíquia")
with CR._conn() as c:
    CR._gravar_reliquias(c, DONO, {"acervo": list(R.RELIQUIAS)[:5], "ativas": []})
    c.commit()
for k in list(R.RELIQUIAS)[:3]:
    exigir(CR.ativar_reliquia(DONO, k, True)["ok"], f"não ativou {k}")
quarta = list(R.RELIQUIAS)[3]
exigir(not CR.ativar_reliquia(DONO, quarta, True)["ok"], "ativou a 4ª relíquia (o limite é 3)")
exigir(CR.ativar_reliquia(DONO, list(R.RELIQUIAS)[0], False)["ok"], "não guardou de volta")
exigir(CR.ativar_reliquia(DONO, quarta, True)["ok"], "com um slot livre, a 4ª foi recusada")
exigir(not CR.ativar_reliquia(DONO, "nao_existe", True)["ok"], "ativou relíquia que o clã não tem")

exigir(R.fator([], "producao") == 1.0, "sem relíquia o fator não é 1")
exigir(R.fator(["moinho_de_pedra"], "producao") > 1.0, "o Moinho não aumenta a produção")
exigir(R.fator(list(R.RELIQUIAS), "producao") == R.fator(list(R.RELIQUIAS)[:R.SLOTS], "producao"),
       "relíquia fora dos slots está valendo")

fonte = open(os.path.join(RAIZ, "game", "clan_repo.py"), encoding="utf-8").read()
for efeito in {d["efeito"] for d in R.RELIQUIAS.values()}:
    exigir(f'"{efeito}"' in fonte, f"o efeito {efeito} não é lido em lugar nenhum — relíquia de enfeite")

# ── 🛡️ novato e 💰 revive pago ───────────────────────────────────────────
novato = {"state": "DEAD", "hp": 0, "hp_max": 100, "tower_floor": 7, "gold": 0,
          "last_free_revive": 10 ** 12}
exigir(L.e_novato(novato), "andar 7 não é novato")
ok, msg = L.free_revive_player(novato)
exigir(ok and novato["tower_floor"] == 7 and novato["state"] == "CITY",
       f"o novato não reviveu de graça sem perder o andar: {ok} {novato}")
exigir(int(novato["last_free_revive"]) == 10 ** 12, "o revive do novato gastou o portal")

veterano = {"state": "DEAD", "hp": 0, "hp_max": 100, "tower_floor": 25, "gold": 0,
            "last_free_revive": 10 ** 12}
ok, _ = L.free_revive_player(veterano)
exigir(not ok, "o veterano reviveu de graça com o portal fechado")
ok, msg = L.revive_pago(veterano)
exigir(not ok, "reviveu pagando sem ter o ouro")
veterano["gold"] = L.CUSTO_REVIVER_OURO
ok, msg = L.revive_pago(veterano)
exigir(ok and veterano["gold"] == 0 and veterano["state"] == "CITY" and veterano["tower_floor"] == 24,
       f"o revive pago não cobrou/voltou direito: {ok} {veterano}")
exigir(L.CUSTO_REVIVER_OURO == 20000, f"o revive pago custa {L.CUSTO_REVIVER_OURO}, e não 20.000")

app = open(os.path.join(RAIZ, "webapp", "static", "app.js"), encoding="utf-8").read()
morte = app[app.index("if (dados.morreu) {"):app.index("// 👣 Encontro na Torre")]
exigir("revive_pago" in morte and "custo_reviver" in morte, "a tela da morte não tem o revive por ouro")
exigir("conta/reset" not in morte and "RESETAR" not in morte,
       "voltou um botão de começar de novo na tela da morte")

if falhas:
    print("❌ RELÍQUIAS / MORTE COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ relíquias: ~1% por equipe, sem repetir, 3 ativas, todo efeito lido; "
      "novato revive de graça até o andar 10 e o veterano paga 20.000")
