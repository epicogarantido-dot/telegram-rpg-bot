#!/usr/bin/env python3
"""O jogo é SÓ site: sobe sem aiogram, sem BOT_TOKEN, e nada importa o bot.

POR QUE EXISTE
--------------
Até 20/09 o `main.py` era o bot do Telegram com a API do site pendurada
nele: sem `BOT_TOKEN` estourava na primeira linha, e sem `aiogram`
instalado nem importava. O bot saiu (com `core/router.py`, `core/keyboards.py`
e `game/views.py`). Este teste garante que ele não volte pela porta dos
fundos:
- o `main.py` importa num ambiente SEM aiogram (nenhum módulo falso aqui);
- `main()` prepara o banco e serve a API como processo principal;
- nenhum arquivo do projeto importa aiogram, telebot ou os arquivos do bot;
- o `requirements.txt` não pede mais as bibliotecas do Telegram.
"""
import sys, os, re, types, asyncio, tempfile

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
os.environ.pop("BOT_TOKEN", None)
pasta = tempfile.mkdtemp()
os.makedirs(os.path.join(pasta, "data"), exist_ok=True)
os.chdir(pasta)

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


# aiosqlite e uvicorn podem faltar no ambiente de teste; o aiogram NÃO é
# substituído — se o main.py pedir, este teste tem que quebrar.
for nome in ("aiogram", "telebot"):
    sys.modules.pop(nome, None)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

SERVIU = []


class ServidorFalso:
    def __init__(self, *a, **k): pass
    async def serve(self): SERVIU.append(True)


uv = types.ModuleType("uvicorn")
uv.Config = lambda *a, **k: None
uv.Server = ServidorFalso
sys.modules["uvicorn"] = uv
api_falsa = types.ModuleType("webapp.api")
api_falsa.app = object()
sys.modules["webapp.api"] = api_falsa

import importlib
try:
    main = importlib.import_module("main")
except Exception as e:
    falhas.append(f"o main.py não importa sem aiogram: {type(e).__name__}: {e}")
    main = None

if main:
    preparou = []

    async def preparar_falso():
        preparou.append(True)

    main.preparar_banco = preparar_falso
    try:
        asyncio.run(asyncio.wait_for(main.main(), timeout=10))
    except Exception as e:
        falhas.append(f"main() não terminou limpo: {type(e).__name__}: {e}")
    exigir(preparou, "main() não preparou o banco antes de servir")
    exigir(SERVIU, "main() não serviu a API como processo principal")

# ── ninguém importa o bot ───────────────────────────────────────────────
proibidos = re.compile(r"^\s*(from|import)\s+(aiogram|telebot|core\.|core\b|game\.views|game import views)",
                       re.M)
for raiz, _d, arquivos in os.walk(RAIZ):
    if "testes" in raiz or "__pycache__" in raiz:
        continue
    for arq in arquivos:
        if arq.endswith(".py"):
            caminho = os.path.join(raiz, arq)
            if proibidos.search(open(caminho, encoding="utf-8").read()):
                falhas.append(f"{os.path.relpath(caminho, RAIZ)} ainda importa o bot/Telegram")
for sumido in ("core/router.py", "core/keyboards.py", "game/views.py",
               "webapp/auth.py", "infra/db.py", "infra/repo.py"):
    exigir(not os.path.exists(os.path.join(RAIZ, sumido)), f"{sumido} voltou")

# 20/09: o resto do Telegram também saiu (login pelo Mini App, download de
# arte pelo bot, vibração/alerta do cliente). Nada disso pode voltar.
api_txt = open(os.path.join(RAIZ, "webapp", "api.py"), encoding="utf-8").read()
for resto in ("_bot_instance", "validar_init_data", 'startswith("tma ")', "BOT_TOKEN"):
    exigir(resto not in api_txt, f"webapp/api.py ainda tem '{resto}' (Telegram)")
app_txt = open(os.path.join(RAIZ, "webapp", "static", "app.js"), encoding="utf-8").read()
for resto in ("window.Telegram", "INIT_DATA", "tgTentar", "HapticFeedback"):
    exigir(resto not in app_txt, f"app.js ainda tem '{resto}' (Telegram)")
img_txt = open(os.path.join(RAIZ, "webapp", "imagens.py"), encoding="utf-8").read()
exigir("bot.download" not in img_txt and "exportar_tudo" not in img_txt,
       "webapp/imagens.py ainda baixa arte pelo Telegram")
idx_txt = open(os.path.join(RAIZ, "webapp", "static", "index.html"), encoding="utf-8").read()
exigir(not re.search(r"<script[^>]+telegram", idx_txt), "o index.html voltou a carregar script do Telegram")
reqs = open(os.path.join(RAIZ, "requirements.txt"), encoding="utf-8").read()
exigir(not re.search(r"^\s*(aiogram|pyTelegramBotAPI)\b", reqs, re.M),
       "o requirements.txt ainda pede biblioteca do Telegram")

if falhas:
    print("❌ SÓ SITE COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ só site: o main.py sobe sem aiogram nem BOT_TOKEN, e nada importa o bot")
