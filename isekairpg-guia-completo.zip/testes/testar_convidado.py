#!/usr/bin/env python3
"""Começar como convidado (28/09, dev).

O convidado entra com um toque: conta sem usuário e senha, id negativo como
as contas do site, e uma sessão cujo token é a ÚNICA chave da conta. Trava:
- o id do convidado não colide com cadastro/convidado seguinte, mesmo antes
  do personagem existir em `players` (e mostra que SEM contar a tabela nova
  colidia);
- a sessão do convidado dura anos (vencer = perder a conta);
- limite por IP por hora;
- "Salvar progresso" dá usuário e senha à MESMA conta (mesmo id), só uma vez,
  e nome em uso não estraga o convidado;
- 12 convidados criados ao mesmo tempo recebem 12 ids diferentes.
"""
import os, sys, time, types, tempfile, sqlite3, threading

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite"); falso.connect = lambda *a, **k: None
    sys.modules["aiosqlite"] = falso

os.chdir(tempfile.mkdtemp()); os.makedirs("data", exist_ok=True)
import game.sql_repo as SR
with SR.get_connection() as c:          # o mínimo de players que o id precisa
    c.execute("CREATE TABLE IF NOT EXISTS players (telegram_id INTEGER PRIMARY KEY)")
    c.commit()
from webapp import contas as CT
CT.init_contas()

falhas = []


def exigir(cond, msg):
    print(("✅ " if cond else "❌ ") + msg)
    if not cond:
        falhas.append(msg)


# 1. convidado nasce, com sessão longa
g1 = CT.criar_convidado("1.1.1.1")
tok, expira = CT.abrir_sessao(g1, CT.SESSAO_CONVIDADO)
exigir(g1 < 0, f"convidado recebe id negativo ({g1})")
exigir(CT.sessao_valida(tok) == g1 and CT.eh_convidado(g1), "a sessão abre a conta do convidado")
exigir(expira - time.time() > 365 * 86400, "a sessão do convidado dura anos (não 30 dias)")

# 2. colisão: o personagem do convidado ainda NÃO existe em players
with CT._conn() as c:
    antes = min(0, c.execute("SELECT MIN(telegram_id) FROM players").fetchone()[0] or 0,
                c.execute("SELECT MIN(telegram_id) FROM usuarios").fetchone()[0] or 0) - 1
exigir(antes == g1, f"SEM contar os convidados, o próximo cadastro pegaria o MESMO id ({antes})")
tid_conta, _ = CT.criar_conta("jogadora1", "segredo1")
g2 = CT.criar_convidado("1.1.1.1")
exigir(len({g1, tid_conta, g2}) == 3, f"com a tabela nova, cada um tem o seu id ({g1}, {tid_conta}, {g2})")

# 3. limite por IP
for _ in range(3):
    CT.criar_convidado("1.1.1.1")
try:
    CT.criar_convidado("1.1.1.1"); limitou = False
except CT.ErroConta:
    limitou = True
exigir(limitou, f"o {CT.CONVIDADOS_POR_IP_HORA + 1}º convidado do mesmo IP na mesma hora é recusado")
exigir(CT.criar_convidado("2.2.2.2") < 0, "outro IP continua entrando")

# 4. salvar progresso
try:
    CT.converter_convidado(g1, "jogadora1", "outrasenha"); ok_nome = False
except CT.ErroConta:
    ok_nome = True
exigir(ok_nome and CT.eh_convidado(g1), "nome já em uso: recusa e ele continua convidado (nada quebra)")
nome = CT.converter_convidado(g1, "Viajante", "minhasenha")
tid, usu = CT.conferir_senha("viajante", "minhasenha")
exigir(tid == g1 and usu == "Viajante", "salvou: entra com usuário e senha na MESMA conta (mesmo id)")
exigir(not CT.eh_convidado(g1), "deixou de ser convidado")
exigir(CT.sessao_valida(tok) == g1, "a sessão que ele já tinha continua valendo")
try:
    CT.converter_convidado(g1, "Viajante2", "minhasenha"); dupla = False
except CT.ErroConta:
    dupla = True
exigir(dupla, "não converte duas vezes")

# 5. concorrência
ids, erros = [], []
def criar(i):
    try:
        ids.append(CT.criar_convidado(f"9.9.{i}.1"))
    except Exception as e:
        erros.append(str(e))
threads = [threading.Thread(target=criar, args=(i,)) for i in range(12)]
[t.start() for t in threads]; [t.join() for t in threads]
exigir(len(ids) == 12 and len(set(ids)) == 12 and not erros,
       f"12 convidados simultâneos: {len(set(ids))} ids diferentes, {len(erros)} erros")

print("\n" + ("🟢 CONVIDADO: TUDO PASSOU" if not falhas else f"🔴 {len(falhas)} FALHA(S)"))
sys.exit(1 if falhas else 0)
