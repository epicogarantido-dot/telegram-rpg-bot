#!/usr/bin/env python3
"""Auditoria da Fusão Mítica.

POR QUE ESTE TESTE EXISTE
-------------------------
A fusão consome 5 Lendários SEMPRE, dê certo ou não. Num sistema assim,
qualquer erro de validação ou de índice come itens que levaram horas pra
sair — e o jogador não tem como provar nem como desfazer.

As perguntas:

1. A CURVA bate com o prometido? 5 iguais têm que dar exatamente 50% de o
   Mítico sair daquele tipo. O peso foi DERIVADO desse alvo
   ((1+5w)/(9+5w)=1/2 -> w=1.4), então se a conta estiver errada o número
   sai errado e o texto da tela vira mentira.
2. Entrada inválida come item? Índice que não existe, item repetido,
   raridade errada, lista com tamanho errado — nada disso pode remover
   nada do inventário.
3. Remover 5 itens de slots diferentes tira os CERTOS? Índices escorregam
   quando se remove de frente pra trás; é o erro clássico aqui.
"""
import sys, os, random, collections

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from game.mythic_items import (chance_por_tipo, sortear_tipo, fundir_composicao,
                               lendarios_do_jogador, FUSION_COST,
                               SLOTS_MITICOS, PESO_DO_ITEM)

falhou = 0


def checar(nome, cond, det=""):
    global falhou
    print(("  ✅ " if cond else "  ❌ ") + nome + ("" if cond else f"  -> {det}"))
    if not cond:
        falhou = 1


def lendario(nome):
    return {"name": nome, "rar": "legendary", "bonus": {"atk": 10}}


print("=" * 70)
print("1. A CURVA — o peso foi derivado do alvo de 50%, não chutado")
print("=" * 70)
print(f"\npeso por item: {PESO_DO_ITEM}  ·  {len(SLOTS_MITICOS)} slots  ·  "
      f"denominador constante {len(SLOTS_MITICOS) + FUSION_COST * PESO_DO_ITEM:.0f}")
print(f"\n{'iguais':>8}{'fórmula':>12}{'simulado':>12}")
rng = random.Random(11)
for k in range(FUSION_COST + 1):
    comp = ["weapon"] * k + ["ring"] * (FUSION_COST - k)
    formula = chance_por_tipo(comp)["weapon"]
    saidas = collections.Counter(sortear_tipo(comp, rng) for _ in range(60000))
    simulado = saidas["weapon"] / 60000
    print(f"{k:>8}{formula*100:>11.1f}%{simulado*100:>11.1f}%")
    checar(f"{k} iguais: fórmula e simulação batem", abs(formula - simulado) < 0.01,
           f"{formula:.3f} vs {simulado:.3f}")

checar("5 iguais dão exatamente 50%",
       abs(chance_por_tipo(["weapon"] * 5)["weapon"] - 0.5) < 0.001,
       chance_por_tipo(["weapon"] * 5)["weapon"])
checar("as chances somam 1 em qualquer composição",
       all(abs(sum(chance_por_tipo(c).values()) - 1) < 1e-9
           for c in (["weapon"]*5, ["weapon"]*3 + ["ring","boots"],
                     ["weapon","armor","helmet","boots","ring"], [])))
checar("item avulso não vira lixo: 1 de cada ainda dá chance a cada um",
       chance_por_tipo(["weapon","armor","helmet","boots","ring"])["weapon"] > 0.10)

print("\n" + "=" * 70)
print("2. ENTRADA INVÁLIDA NÃO PODE COMER ITEM")
print("=" * 70)


def jogador():
    return {"inv": {"items": {
        "weapon": [lendario("Espada A"), lendario("Espada B")],
        "boots":  [lendario("Bota A"), {"name": "Bota comum", "rar": "common"}],
        "ring":   [lendario("Anel A"), lendario("Anel B")],
    }}}


def total(p):
    return sum(len(v) for v in p["inv"]["items"].values())


casos = [
    ("menos de 5 itens", [{"slot": "weapon", "idx": 0}]),
    ("mais de 5 itens", [{"slot": "weapon", "idx": 0}] * 6),
    ("o mesmo item duas vezes",
     [{"slot": "weapon", "idx": 0}, {"slot": "weapon", "idx": 0},
      {"slot": "ring", "idx": 0}, {"slot": "ring", "idx": 1}, {"slot": "boots", "idx": 0}]),
    ("índice que não existe",
     [{"slot": "weapon", "idx": 99}, {"slot": "weapon", "idx": 1},
      {"slot": "ring", "idx": 0}, {"slot": "ring", "idx": 1}, {"slot": "boots", "idx": 0}]),
    ("item que não é lendário",
     [{"slot": "boots", "idx": 1}, {"slot": "weapon", "idx": 0},
      {"slot": "weapon", "idx": 1}, {"slot": "ring", "idx": 0}, {"slot": "ring", "idx": 1}]),
    ("slot que não existe",
     [{"slot": "chapeu_magico", "idx": 0}, {"slot": "weapon", "idx": 0},
      {"slot": "weapon", "idx": 1}, {"slot": "ring", "idx": 0}, {"slot": "ring", "idx": 1}]),
]
for nome, escolha in casos:
    p = jogador()
    antes = total(p)
    ok, msg = fundir_composicao(p, escolha, random.Random(1))
    checar(f"{nome}: recusa e não remove nada",
           not ok and total(p) == antes, f"ok={ok} itens {antes}->{total(p)}")

print("\n" + "=" * 70)
print("3. REMOÇÃO — tira os 5 CERTOS, de slots diferentes")
print("=" * 70)
p = jogador()
escolha = [{"slot": "weapon", "idx": 0}, {"slot": "weapon", "idx": 1},
           {"slot": "ring", "idx": 0}, {"slot": "ring", "idx": 1},
           {"slot": "boots", "idx": 0}]
antes = total(p)
ok, msg = fundir_composicao(p, escolha, random.Random(3))
itens = p["inv"]["items"]
checar("consumiu exatamente 5 (o item novo, se veio, entra depois)",
       total(p) == antes - FUSION_COST + (1 if ok else 0),
       f"{antes} -> {total(p)} (ok={ok})")
checar("a bota COMUM sobrou — índices não escorregaram",
       any(it.get("rar") == "common" for it in itens.get("boots", [])),
       itens.get("boots"))
checar("nenhum lendário sobrou nos slots esvaziados",
       not [it for s in ("weapon", "ring") for it in itens.get(s, [])
            if it.get("rar") == "legendary"],
       {s: itens.get(s) for s in ("weapon", "ring")})

print("\n4. lendarios_do_jogador só lista lendário")
p = jogador()
achados = lendarios_do_jogador(p)
checar(f"achou os 5 lendários (e ignorou o comum)", len(achados) == 5, len(achados))
checar("cada um traz slot e idx utilizáveis",
       all("slot" in a and "idx" in a for a in achados))

print("\n" + ("🟢 FUSÃO MÍTICA: TUDO PASSOU" if not falhou else "❌ FUSÃO MÍTICA: FALHOU"))
sys.exit(falhou)
