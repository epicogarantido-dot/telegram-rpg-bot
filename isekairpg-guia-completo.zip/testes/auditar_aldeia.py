#!/usr/bin/env python3
"""Auditoria da aldeia viva: habitantes, profissões, fadiga, aura, ataques.

POR QUE ESTE TESTE EXISTE
-------------------------
Os habitantes (20/09) são um laço com cinco peças que se mordem: trabalho
gera recurso e cansa; cansaço derruba produção; comida sustenta a gente;
ataque fere e às vezes desperta Aura; gente nova chega se houver lugar.
Qualquer uma dessas peças mal dimensionada quebra o laço em silêncio — e
é o tipo de coisa que só aparece depois de vinte sessões, que ninguém
testa à mão. Aqui cada propriedade que o desenho promete é MEDIDA:

1. Todo campo das profissões é lido pelo motor (armadilha nº 10).
2. O habitante não substitui o posto da Torre (senão "Torre ou aldeia"
   some — a decisão central do clã).
3. Rodízio importa: trabalhar sem parar derruba a produção, descansar
   conserta. E a fadiga tem saída — fadiga sem saída seria armadilha.
4. O potencial ★ separa quem trava de quem continua.
5. A Aura é rara no dia a dia e acontece de preferência no perigo.
6. Uma aldeia bem cuidada cresce; uma largada à própria sorte não explode.
"""
import sys, os, random, copy, statistics

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)

from game import clan_habitantes as H

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


TICKS = 24   # uma sessão cheia (clan_repo.TETO_TICKS)

# ── 1) profissão que nada faz é enfeite ─────────────────────────────────
fonte = open(os.path.join(RAIZ, "game", "clan_habitantes.py"), encoding="utf-8").read()
for pid, prof in H.PROFISSOES.items():
    if prof["produz"]:
        exigir(prof["produz"] in ("comida", "madeira", "couro", "material_r1"),
               f"{pid} produz '{prof['produz']}', que a sessão não soma")
    else:
        exigir(f'"{pid}"' in fonte.split("def sessao_da_aldeia")[1]
               or f'"{pid}"' in fonte.split("def defesa_da_aldeia")[1],
               f"{pid} não produz e nenhum cálculo o lê — é enfeite")

# ── 2) o habitante não substitui o posto ────────────────────────────────
rng = random.Random(1)
agricultor = H.novo_habitante(rng, profissao="agricultor")
agricultor["potencial"] = 5
r = H.sessao_da_aldeia([agricultor], TICKS, 999, 0, random.Random(2))
comida_nv1 = r["producao"]["comida"]
print(f"agricultor Nv1, 1 sessão: {comida_nv1} de comida (lutador no Andar 5: ~85)")
exigir(10 <= comida_nv1 <= 40,
       f"agricultor Nv1 rende {comida_nv1} por sessão — fora da faixa pensada (10 a 40)")
exigir(comida_nv1 < 85, "o agricultor rende tanto quanto um lutador em posto — a Torre perde o sentido")

# ── 3) rodízio importa, e a fadiga tem saída ────────────────────────────
def producao_em(sessoes, descansa_a_cada=None, semente=3):
    h = H.novo_habitante(random.Random(semente), profissao="lenhador")
    h["potencial"] = 5
    total = 0
    rng_ = random.Random(semente)
    for s in range(sessoes):
        h["descansando"] = 1 if (descansa_a_cada and (s + 1) % descansa_a_cada == 0) else 0
        total += H.sessao_da_aldeia([h], TICKS, 999, 0, rng_)["producao"]["madeira"]
        h["vivo"] = 1   # isola o teste do ataque
    return total, h["fadiga"]

sem_parar, fad_sem = producao_em(12)
com_rodizio, fad_com = producao_em(12, descansa_a_cada=3)
print(f"lenhador, 12 sessões: sem parar {sem_parar} (fadiga final {fad_sem}) · "
      f"com 1 de descanso a cada 3: {com_rodizio} (fadiga final {fad_com})")
exigir(fad_sem >= 80, "trabalhar sem parar não leva à exaustão — a fadiga não pesa")
exigir(fad_com < 80, "com rodízio o habitante ainda termina exausto — descansar não conserta")

h = H.novo_habitante(random.Random(9), profissao="agricultor")
h["fadiga"] = H.FADIGA_MAX
h["descansando"] = 1
H.sessao_da_aldeia([h], TICKS, 999, 0, random.Random(4))
exigir(h["fadiga"] <= 10, f"uma sessão de descanso deixou fadiga {h['fadiga']} — a saída é lenta demais")

# ── 4) o potencial separa quem trava de quem continua ───────────────────
def nivel_apos(sessoes, potencial):
    h = H.novo_habitante(random.Random(5), profissao="minerador")
    h["potencial"] = potencial
    for s in range(sessoes):
        h["descansando"] = 1 if s % 3 == 2 else 0
        H.ganhar_xp(h, 0 if h["descansando"] else TICKS)
    return h["nivel"]

print("nível após 60 sessões (com rodízio):",
      {f"★{p}": nivel_apos(60, p) for p in range(1, 6)})
# 20/09 (equipes): o teto do coletor é 20 pra todos (o do guarda vai com as
# estrelas de guarda — medido em auditar_equipes.py)
exigir(max(nivel_apos(200, p) for p in range(1, 6)) <= 20, "um coletor passou do nível 20")
exigir(nivel_apos(60, 5) >= H.NIVEL_ESPECIALIZACAO,
       "★5 não chega à especialização em 60 sessões — progressão lenta demais")
exigir(nivel_apos(3, 5) >= 2, "nem o ★5 sobe de nível nas primeiras sessões — progresso invisível")

# ── 5) Aura: rara no calmo, acontece no perigo ──────────────────────────
def despertares(sessoes, semente):
    rng_ = random.Random(semente)
    aldeia = [H.novo_habitante(rng_, profissao=p) for p in
              ("agricultor", "agricultor", "lenhador", "cacador", "minerador",
               "guarda", "guarda", "curandeiro")]
    total, no_ataque = 0, 0
    for _ in range(sessoes):
        for x in aldeia:
            x["descansando"] = 0
            x["fadiga"] = min(x["fadiga"], 30)
        r = H.sessao_da_aldeia(aldeia, TICKS, 999, 1, rng_)
        total += len(r["despertaram"])
        if r["ataque"] and r["ataque"].get("heroi"):
            no_ataque += 1
        for x in aldeia:
            x["vivo"] = 1           # isola: mede despertar, não mortalidade
    return total, no_ataque

tot, ataque = despertares(240, 7)
por_sessao = tot / 240
print(f"aura numa aldeia de 8 (2 guardas), 240 sessões: {tot} despertares "
      f"(1 a cada {240 / max(1, tot):.0f} sessões), {ataque} num ataque")
exigir(0.01 <= por_sessao <= 0.25,
       f"{por_sessao:.3f} despertares por sessão — a Aura deixou de ser rara ou virou lenda")

# O coração da ideia: no ataque que a defesa NÃO segura, alguém pode
# despertar. Mede direto nesse momento, sem depender de quão bem defendida
# está a aldeia (uma aldeia forte quase nunca vive a crise — e é por isso
# que desperta menos: poucos guardas é mais risco E mais chance).
crises, herois = 0, 0
rng_c = random.Random(21)
for _ in range(3000):
    aldeia = [H.novo_habitante(rng_c, profissao="agricultor") for _ in range(8)]
    defesa = H.defesa_da_aldeia(aldeia, 0)
    ameaca = H.ameaca_do_ataque(len(aldeia), rng_c)
    if defesa >= ameaca:
        continue
    crises += 1
    if any(H.tentar_despertar(x, rng_c, perigo=True) for x in rng_c.sample(aldeia, len(aldeia))):
        herois += 1
taxa = herois / max(1, crises)
print(f"na crise (ataque que passa da defesa): alguém desperta em {100 * taxa:.0f}% das vezes")
exigir(0.15 <= taxa <= 0.60,
       f"na crise, o despertar acontece {100 * taxa:.0f}% das vezes — fora da faixa de 15% a 60%")

# ── 6) uma aldeia cresce; uma largada não explode ───────────────────────
def aldeia_em(sessoes, cuidada, semente):
    rng_ = random.Random(semente)
    aldeia = [H.novo_habitante(rng_, profissao=p)
              for p in ("agricultor", "agricultor", "lenhador", "guarda")]
    comida = 60
    for s in range(sessoes):
        vivos = [x for x in aldeia if x["vivo"]]
        if cuidada:
            for x in vivos:
                x["descansando"] = 1 if x["fadiga"] >= 60 else 0
        r = H.sessao_da_aldeia(aldeia, TICKS, comida, 2, rng_)
        comida = max(0, comida + r["producao"]["comida"] - r["comida_consumida"])
        comida = min(comida, 300)
    vivos = [x for x in aldeia if x["vivo"]]
    return len(vivos), comida

tamanhos_c, tamanhos_l = [], []
for sem in range(20):
    tamanhos_c.append(aldeia_em(40, True, sem)[0])
    tamanhos_l.append(aldeia_em(40, False, sem)[0])
print(f"após 40 sessões — cuidada: {statistics.mean(tamanhos_c):.1f} habitantes · "
      f"largada: {statistics.mean(tamanhos_l):.1f}")
exigir(statistics.mean(tamanhos_c) > 4, "a aldeia bem cuidada não cresceu em 40 sessões")
exigir(min(tamanhos_c) >= 1, "uma aldeia bem cuidada foi dizimada")

# ── 7) estágio: população sozinha não faz Fortaleza ─────────────────────
# (25/09/2026: os mínimos saem de ESTAGIOS — a população dos estágios
# cresceu ×10 quando a aldeia passou a começar com 50 e caber 200)
_FORT = H.ESTAGIOS[3][1] + 2
exigir(H.estagio_da_aldeia(_FORT, 0)["indice"] < 3,
       f"{_FORT} habitantes sem nenhuma construção já contam como Fortaleza")
exigir(H.estagio_da_aldeia(_FORT, 2)["nome"] == "Fortaleza", f"a Fortaleza não reconhece {_FORT} + 2 comodidades")

# ── 8) chefes: cada cargo muda alguma coisa, e o nível do chefe pesa ─────
def hab(i, prof, nivel=1, aura=0, pot=5):
    x = H.novo_habitante(random.Random(i), profissao=prof)
    x.update({"id": i, "nivel": nivel, "potencial": pot, "aura": aura})
    return x

aldeia_base = [hab(1, "agricultor", 20), hab(2, "lenhador", 4), hab(3, "cacador"),
               hab(4, "minerador", 12), hab(5, "guarda", 16), hab(6, "curandeiro", 1, aura=2)]
sem = H.modificadores_da_aldeia(aldeia_base, {})
for cargo, regra in H.CARGOS.items():
    chefe = next((x for x in aldeia_base if (regra["exige"] is None and x["aura"])
                  or x["profissao"] == regra["exige"]), None)
    com = H.modificadores_da_aldeia(aldeia_base, {"comandantes": {cargo: chefe["id"]}})
    exigir(com != sem and cargo in com["chefes"],
           f"o cargo '{cargo}' não muda nada na aldeia — é enfeite")
m20 = H.modificadores_da_aldeia(aldeia_base, {"comandantes": {"agricultor": 1}})
print(f"Chefe da Lavoura Nv.20: comida ×{m20['producao']['comida']:.2f}")
exigir(abs(m20["producao"]["comida"] - 1.20) < 0.001, "o chefe Nv.20 não dá +20%")
# chefe que trocou de profissão perde o cargo sozinho
aldeia_base[0]["profissao"] = "guarda"
exigir("agricultor" not in H.modificadores_da_aldeia(
    aldeia_base, {"comandantes": {"agricultor": 1}})["chefes"],
    "quem trocou de profissão continuou chefe da antiga")
aldeia_base[0]["profissao"] = "agricultor"

# ── 9) especialização: toda opção mexe em algo ──────────────────────────
for esp in H.ESPECIALIZACOES:
    m = H.modificadores_da_aldeia(aldeia_base, {"especializacoes": [esp]})
    exigir(m["producao"] or m["defesa"] != 1.0 or m["aura"] != 1.0 or m["capacidade"],
           f"a especialização '{esp}' não muda nada — é enfeite")
exigir(H.vagas_de_especializacao(1) == 0 and H.vagas_de_especializacao(2) == 1
       and H.vagas_de_especializacao(4) == 2, "as vagas de especialização não seguem os estágios")

# ── 10) automação: a regra de descanso faz o rodízio sozinha ────────────
def produz_com(regras, sessoes=12, semente=31):
    h = H.novo_habitante(random.Random(semente), profissao="lenhador")
    h.update({"id": 1, "potencial": 5})
    rng_ = random.Random(semente)
    total = 0
    for _ in range(sessoes):
        total += H.sessao_da_aldeia([h], TICKS, 999, 0, rng_,
                                    {"regras": regras})["producao"]["madeira"]
        h["vivo"] = 1
    return total, h["fadiga"]

sem_regra, _ = producao_em(12)
com_regra, fad_regra = produz_com({"descanso_auto": True, "limite": 80, "volta": 20})
print(f"lenhador, 12 sessões: sem descanso {sem_regra} · rodízio à mão {com_rodizio} · "
      f"regra automática {com_regra}")
exigir(com_regra > sem_regra * 1.2, "a regra de descanso não rende mais que trabalhar sem parar")
exigir(com_regra >= com_rodizio * 0.9,
       "a regra automática rende bem menos que o rodízio à mão — automatizar sairia caro")

# ── 11) família: na crise, quem vê o parente em perigo desperta mais ────
def taxa_crise(com_familia, n=4000, semente=41):
    rng_ = random.Random(semente)
    herois = crises = 0
    for _ in range(n):
        vitima = hab(1, "agricultor")
        outro = hab(2, "agricultor")
        if com_familia:
            outro["parente_de"] = 1
        crises += 1
        if H.tentar_despertar(outro, rng_, perigo=True,
                              mult=H.MULT_AURA_FAMILIA if com_familia else 1.0):
            herois += 1
    return herois / crises

t_sem, t_com = taxa_crise(False), taxa_crise(True)
print(f"despertar na crise: {100 * t_sem:.1f}% sem parente em perigo · {100 * t_com:.1f}% com")
exigir(t_com > t_sem * 1.5, "ver a família em perigo não muda a chance de despertar")

# luto: a morte de alguém cansa a família dele
rng_l = random.Random(5)
aldeia_l = [hab(1, "agricultor"), hab(2, "agricultor"), hab(3, "agricultor")]
aldeia_l[1]["parente_de"] = 1
viu_luto = False
for semente in range(400):
    for x in aldeia_l:
        x.update({"vivo": 1, "fadiga": 0, "descansando": 0})
    r = H.sessao_da_aldeia(aldeia_l, TICKS, 999, 0, random.Random(semente))
    if r["ataque"] and r["ataque"].get("morto") == aldeia_l[0]["nome"]:
        viu_luto = any("chorou" in f for f in r["frases"])
        break
exigir(viu_luto, "um habitante morreu e o parente dele não reagiu")

if falhas:
    print("\n❌ ALDEIA COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("\n✅ a aldeia cresce, cansa, desperta e se defende dentro do desenho")
