#!/usr/bin/env python3
"""A trava do jogador morre com a REQUISIÇÃO, não com a thread.

POR QUE ESTE TESTE EXISTE
-------------------------
Este é o bug que travava o jogo no "Explorar".

A trava por jogador era guardada num `threading.local()` e solta "no começo
do próximo `_carregar_jogador`", contando com o threadpool reaproveitar a
thread. Ele não reaproveita — o FastAPI serve cada rota síncrona numa
thread qualquer do pool. Então `GET /api/explore` (rota de leitura, que
nunca chama `_salvar_jogador`) prendia a trava numa thread, e o
`POST /api/explore/go` seguinte caía noutra e esperava para sempre. O front
ficava no "carregando", e cada tentativa prendia mais uma thread do pool
até o processo inteiro parar — bot incluído, já que ele roda no mesmo
event loop.

Medido na época: **38 rotas** pegavam a trava e nunca soltavam, e qualquer
rota de escrita que estourasse entre carregar e gravar deixava a trava
presa do mesmo jeito, porque o `finally` morava em `_salvar_jogador`.

O QUE ESTE TESTE REPRODUZ
-------------------------
O `contextvars.copy_context().run(...)` abaixo é exatamente o que o
`anyio.to_thread.run_sync` faz por baixo do FastAPI: a thread do pool
recebe uma CÓPIA do contexto, e a cópia aponta pro mesmo dicionário. É por
isso que a caixa funciona e o `threading.local()` não funcionava.

Não dá pra subir o FastAPI de verdade aqui (o pacote não é dependência de
teste), então o teste replica o fluxo dele e confere as três situações que
quebravam: rota de leitura, rota que estoura, e duas rotas ao mesmo tempo.
"""
import sys, os, contextvars, threading, time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

TRAVA_DO_PEDIDO = contextvars.ContextVar("trava_do_pedido", default=None)
TRAVAS = {}
TRAVA_DAS_TRAVAS = threading.Lock()
ESPERA_MAXIMA = 2.0

falhou = 0


def checar(nome, condicao, detalhe=""):
    global falhou
    print(("  ✅ " if condicao else "  ❌ ") + nome + ("" if condicao else f"  -> {detalhe}"))
    if not condicao:
        falhou = 1


# --------------------------------------------------- cópia fiel do api.py
def pegar_trava(tid):
    with TRAVA_DAS_TRAVAS:
        return TRAVAS.setdefault(int(tid), threading.Lock())


def soltar_trava_pendente():
    caixa = TRAVA_DO_PEDIDO.get()
    if not caixa:
        return
    trava = caixa.get("trava")
    if trava is not None:
        try:
            trava.release()
        except RuntimeError:
            pass
        caixa["trava"] = None


def carregar_jogador(tid):
    soltar_trava_pendente()
    trava = pegar_trava(tid)
    if not trava.acquire(timeout=ESPERA_MAXIMA):
        raise TimeoutError("409: outra ação sua ainda está em andamento")
    caixa = TRAVA_DO_PEDIDO.get()
    if caixa is not None:
        caixa["trava"] = trava
    else:
        trava.release()


def salvar_jogador(tid):
    try:
        pass          # gravaria aqui
    finally:
        soltar_trava_pendente()


def servir(rota, *args):
    """O que a RotaQueSoltaATrava faz: cria a caixa, roda a rota numa thread
    do pool (com o contexto COPIADO, como o anyio faz) e esvazia no finally."""
    caixa = {"trava": None}
    token = TRAVA_DO_PEDIDO.set(caixa)
    erro = []
    try:
        def dentro_da_thread():
            try:
                rota(*args)
            except BaseException as e:
                erro.append(e)

        ctx = contextvars.copy_context()
        t = threading.Thread(target=lambda: ctx.run(dentro_da_thread))
        t.start()
        t.join()
    finally:
        trava = caixa.get("trava")
        if trava is not None:
            try:
                trava.release()
            except RuntimeError:
                pass
            caixa["trava"] = None
        TRAVA_DO_PEDIDO.reset(token)
    if erro:
        raise erro[0]


# ------------------------------------------------------------------ rotas
JOGADOR = 777


def rota_de_leitura(tid):            # GET /api/explore: carrega e não grava
    carregar_jogador(tid)


def rota_de_escrita(tid):            # POST /api/explore/go
    carregar_jogador(tid)
    salvar_jogador(tid)


def rota_que_estoura(tid):           # erro no meio de tower_explore()
    carregar_jogador(tid)
    raise RuntimeError("estourou antes de gravar")


def rota_de_dois_jogadores(a, b):    # mercado/troca: carrega dois
    carregar_jogador(a)
    carregar_jogador(b)
    salvar_jogador(b)


print("=" * 72)
print("A TRAVA DO JOGADOR MORRE COM A REQUISIÇÃO")
print("=" * 72)

print("\n1. rota de LEITURA solta a trava mesmo sem gravar")
servir(rota_de_leitura, JOGADOR)
livre = pegar_trava(JOGADOR).acquire(blocking=False)
checar("a trava ficou livre depois da requisição", livre)
if livre:
    pegar_trava(JOGADOR).release()

print("\n2. a requisição seguinte cai em OUTRA thread — era aqui que travava")
inicio = time.time()
servir(rota_de_escrita, JOGADOR)
gasto = time.time() - inicio
checar(f"respondeu na hora ({gasto*1000:.0f} ms), sem esperar trava", gasto < 0.5, f"{gasto:.1f}s")

print("\n3. rota que ESTOURA no meio não deixa a trava presa")
try:
    servir(rota_que_estoura, JOGADOR)
except RuntimeError:
    pass
livre = pegar_trava(JOGADOR).acquire(blocking=False)
checar("a trava ficou livre mesmo com a rota estourando", livre)
if livre:
    pegar_trava(JOGADOR).release()

print("\n4. rota que carrega DOIS jogadores solta os dois")
servir(rota_de_dois_jogadores, JOGADOR, JOGADOR + 1)
for tid in (JOGADOR, JOGADOR + 1):
    livre = pegar_trava(tid).acquire(blocking=False)
    checar(f"trava do jogador {tid} livre", livre)
    if livre:
        pegar_trava(tid).release()

print("\n5. duas requisições do MESMO jogador ainda se serializam")
ordem = []


def rota_lenta(tid):
    carregar_jogador(tid)
    ordem.append("entrou")
    time.sleep(0.3)
    ordem.append("saiu")
    salvar_jogador(tid)


t1 = threading.Thread(target=lambda: servir(rota_lenta, JOGADOR))
t2 = threading.Thread(target=lambda: servir(rota_lenta, JOGADOR))
t1.start(); time.sleep(0.05); t2.start()
t1.join(); t2.join()
checar("uma esperou a outra (nada de ler-modificar-gravar sobreposto)",
       ordem == ["entrou", "saiu", "entrou", "saiu"], ordem)

print("\n6. jogadores DIFERENTES nunca esperam um pelo outro")
marcas = []


def rota_lenta_marcando(tid):
    carregar_jogador(tid)
    time.sleep(0.3)
    marcas.append(time.time())
    salvar_jogador(tid)


inicio = time.time()
t1 = threading.Thread(target=lambda: servir(rota_lenta_marcando, 1))
t2 = threading.Thread(target=lambda: servir(rota_lenta_marcando, 2))
t1.start(); t2.start(); t1.join(); t2.join()
total = time.time() - inicio
checar(f"rodaram em paralelo ({total*1000:.0f} ms, não ~600)", total < 0.5, f"{total:.1f}s")

print("\n7. trava presa por um sumido vira erro claro, não espera infinita")
pegar_trava(4242).acquire()          # simula uma trava vazada de outro tempo
inicio = time.time()
try:
    servir(rota_de_escrita, 4242)
    checar("deveria ter estourado 409", False, "passou direto")
except TimeoutError:
    gasto = time.time() - inicio
    checar(f"estourou 409 em {gasto:.1f}s em vez de pendurar a thread",
           gasto < ESPERA_MAXIMA + 1)

# ------------------------------------- e o que o código de verdade declara
print("\n8. o api.py de verdade está com a correção")
fonte = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          "webapp", "api.py"), encoding="utf-8").read()
checar("nenhum threading.local() sobrou pra trava", "_TRAVA_DA_THREAD" not in fonte)
checar("a rota que solta a trava existe", "class RotaQueSoltaATrava" in fonte)
checar("e está ligada em TODAS as rotas",
       "app.router.route_class = RotaQueSoltaATrava" in fonte)
checar("o route_class é ligado ANTES da primeira rota",
       fonte.index("app.router.route_class = RotaQueSoltaATrava") < fonte.index("@app.get("))
checar("o acquire tem timeout", "acquire(timeout=ESPERA_MAXIMA_TRAVA)" in fonte)

print("\n" + ("🟢 TRAVA DO JOGADOR: TUDO PASSOU" if not falhou else "❌ TRAVA: FALHOU"))
sys.exit(falhou)
