#!/usr/bin/env python3
"""Auditoria dos ranks de material.

A pergunta que decide tudo: **cada rank é farmável por alguém?** Rank cujo
andar exige um nível que ninguém alcança é conteúdo morto — e como o
equipamento desse rank também morre junto, morre uma faixa inteira de
progressão sem ninguém perceber.

Roda depois de mexer em RANKS, EQUIPAMENTO ou na tabela de monstros.
"""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    import aiosqlite  # noqa: F401
except ImportError:
    print("⚠️  aiosqlite não instalado — rode no servidor, onde ele existe.")
    sys.exit(2)

from game.clan_afk import montar_perfil
from game.clan_materiais import (RANKS, EQUIPAMENTO, COMODIDADES, RANK_MAX,
                                 andar_minimo_do_rank, poder_do_equipamento,
                                 custo_equipamento, rende_no_andar)

TETO_MORTE_SEGURO = 10.0   # acima disso não é farmar, é apostar


def modelo(level, equip_poder=0):
    # equip_poder entra como atributo extra: é a aproximação de "equipado".
    bonus = int(equip_poder)
    return {"telegram_id": 1, "level": level, "xp": 0, "xp_next": 9**9, "gold": 0,
            "tower_floor": 1, "hp": 100, "hp_max": 100, "state": "TOWER",
            "class_id": None, "race_id": None,
            "attrs": {"str": level + bonus, "vit": level + bonus,
                      "agi": level + bonus, "dex": level + bonus},
            "trails": {}, "combat": None,
            "inv": {"potion": 0, "cores": {}, "items": {}}, "equip": {},
            "pets": {"owned": {}, "deck": [None] * 5},
            "skills_learned": {}, "skill_slots": {"equipped": [None] * 5}, "chakra": None}


def farmavel(andar, nivel, equip=0):
    return montar_perfil(modelo(nivel, equip), {"id": "x", "andar": andar})["chance_morte"] <= TETO_MORTE_SEGURO


problemas, avisos = [], []
t0 = time.perf_counter()

print("=" * 76)
print("AUDITORIA DOS RANKS DE MATERIAL")
print("=" * 76)
print(f"{'rank':>5} {'nome':>12} {'andares':>10} {'nível p/ farmar':>17} {'com equip do rank-1':>21}")

for r in sorted(RANKS):
    andar = andar_minimo_do_rank(r)
    # O nível é travado em andar*2, e você só farma o que está atrás de você.
    # O melhor caso é estar no topo da torre: nível 200.
    equip_anterior = poder_do_equipamento(r - 1) if r > 1 else 0
    nivel_ok = next((n for n in range(10, 201, 5) if farmavel(andar, n)), None)
    nivel_eq = next((n for n in range(10, 201, 5) if farmavel(andar, n, equip_anterior)), None)
    print(f"{r:>5} {RANKS[r]['nome']:>12} {str(RANKS[r]['andares']):>10} "
          f"{str(nivel_ok or 'inalcançável'):>17} {str(nivel_eq or 'inalcançável'):>21}")

    if nivel_ok is None and nivel_eq is None:
        problemas.append(f"rank {r} ({RANKS[r]['nome']}) é INALCANÇÁVEL — nem com o "
                         f"equipamento do rank anterior alguém farma o andar {andar}")
    elif nivel_ok is None:
        avisos.append(f"rank {r} só é farmável COM equipamento do rank {r-1} — "
                      f"a corrente é apertada, mas fecha")
    else:
        # Você precisa estar no andar nivel/2 pra ter esse nível.
        andar_necessario = nivel_ok // 2
        if andar_necessario > 100:
            problemas.append(f"rank {r} exige nível {nivel_ok}, que exige estar no andar "
                             f"{andar_necessario} — acima do topo da torre")

# equipamento de cada rank é comprável com o material daquele rank?
print()
for r in sorted(EQUIPAMENTO):
    andar = andar_minimo_do_rank(r)
    rende = rende_no_andar(andar)
    coletas = custo_equipamento(r) / max(1, rende["quantidade"])
    if coletas > 120:
        problemas.append(f"equipamento rank {r} custa {custo_equipamento(r)} e o andar "
                         f"{andar} rende {rende['quantidade']} por coleta — "
                         f"{coletas:.0f} coletas por peça, ninguém vai fazer")
    elif coletas > 60:
        avisos.append(f"equipamento rank {r}: {coletas:.0f} coletas por peça")
    print(f"  equipamento rank {r}: {custo_equipamento(r):>4} de material, "
          f"andar {andar} rende {rende['quantidade']:>3}/coleta -> {coletas:>5.0f} coletas")

# comodidade de rank alto é alcançável?
print()
for chave, c in COMODIDADES.items():
    andar = andar_minimo_do_rank(c["rank"])
    rende = rende_no_andar(andar)
    coletas = c["custo"] / max(1, rende["quantidade"])
    print(f"  {c['nome']:>12} (rank {c['rank']}): {c['custo']:>4} -> {coletas:>5.0f} coletas")
    if coletas > 120:
        problemas.append(f"comodidade '{c['nome']}' custa {coletas:.0f} coletas — "
                         f"existe e ninguém constrói")

# cada comodidade justifica a própria existência?
sem_porque = [c["nome"] for c in COMODIDADES.values() if not c.get("porque")]
if sem_porque:
    avisos.append(f"comodidade sem razão escrita: {', '.join(sem_porque)} — "
                  f"se não dá pra explicar por que existe, provavelmente não precisa")

print(f"\n({time.perf_counter()-t0:.0f}s)")
print(f"\n❌ PROBLEMAS: {len(problemas)}")
for x in problemas: print("   ", x)
print(f"\n⚠️  AVISOS: {len(avisos)}")
for x in avisos: print("   ", x)
print()
print("🟢 todos os ranks são alcançáveis" if not problemas else "❌ há rank inalcançável")
sys.exit(0 if not problemas else 1)
