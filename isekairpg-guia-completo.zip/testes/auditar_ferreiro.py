#!/usr/bin/env python3
"""Ferreiro da aldeia (fase 2, 20/09) — as regras do dev, medidas.

- 5 tiers; o custo do lote cresce com a quantidade de gente;
- quem chega novo é NIVELADO primeiro, com custo maior (×1,5 por degrau);
- equipamento de guarda custa mais que ferramenta (×2);
- o tier dá bônus: produção do coletor e poder do guarda, sempre subindo.
Imprime quanto custa levar 10 e 25 NPCs do Tier 1 ao 5.
"""
import sys, os

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
from game import clan_ferreiro as F
from game import clan_equipes as E

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


def aldeia(n, tier=1, guardas=0):
    return [{"id": i, "vivo": 1, "tiers": {"agricultor": tier, "guarda": tier},
             "talentos": {"agricultor": 1, "guarda": 1 if i < guardas else 0}} for i in range(n)]


def trabalho(habs, funcao="agricultor"):
    return {h["id"]: funcao for h in habs}


a10, a25 = aldeia(10), aldeia(25)
p10, p25 = F.plano(a10, "agricultor", trabalho(a10)), F.plano(a25, "agricultor", trabalho(a25))
exigir(p10["acao"] == "evoluir" and sum(p25["custo"].values()) > sum(p10["custo"].values()),
       "o lote de 25 não custa mais que o de 10")

habs = aldeia(10, tier=3)
habs.append({"id": 99, "vivo": 1, "tiers": {}, "talentos": {"agricultor": 1}})
pl = F.plano(habs, "agricultor", trabalho(habs))
exigir(pl["acao"] == "nivelar" and pl["quem"] == [99] and pl["alvo"] == 3,
       f"o recém-chegado não foi nivelado primeiro: {pl}")
normal = {}
for alvo in (2, 3):
    r, q = F.custo_do_degrau("agricultor", alvo)
    normal[r] = normal.get(r, 0) + q
exigir(all(pl["custo"][r] > normal[r] for r in normal), "nivelar o novo não custa mais que o degrau normal")

rf, qf = F.custo_do_degrau("lenhador", 3)
re_, qe = F.custo_do_degrau("guarda", 3)
exigir(re_ == rf and qe == 2 * qf, "equipamento de guarda não custa o dobro da ferramenta")
a5 = aldeia(5, tier=5)
exigir(F.plano(a5, "agricultor", trabalho(a5))["acao"] == "maximo", "passou do Tier 5")
a5b = aldeia(5)
exigir(F.plano(a5b, "lenhador", trabalho(a5b))["acao"] == "nada",
       "a bancada do lenhador pegou quem está trabalhando de agricultor")
# separado por função: o tier de lenhador não vale pra minerador
h = {"id": 1, "tiers": {"lenhador": 4}}
exigir(F.tier_de(h, "lenhador") == 4 and F.tier_de(h, "minerador") == 1,
       "a ferramenta de uma função valeu pra outra")

for trilha in F.TRILHAS:
    vals = [F.BONUS[trilha][t] for t in range(1, 6)]
    exigir(vals == sorted(vals) and vals[0] == 1.0, f"o bônus de {trilha} não sobe do 1,0")
h1 = {"talentos": {"minerador": 3, "guarda": 3}, "nivel": 10, "tiers": {}}
h5 = dict(h1, tiers={"minerador": 5, "guarda": 5})
exigir(E.producao_do_coletor(h5, "ferro") > E.producao_do_coletor(h1, "ferro"),
       "a ferramenta Tier 5 não aumenta a produção")
exigir(E.poder_do_guarda(h5) > E.poder_do_guarda(h1), "o equipamento Tier 5 não aumenta o poder")

print("Custo de levar o lote do Tier 1 ao 5 (material do clã, por rank):")
for n in (10, 25):
    for trilha in ("agricultor", "guarda"):
        total = {}
        for alvo in range(2, 6):
            r, q = F.custo_do_degrau(trilha, alvo)
            total[r] = total.get(r, 0) + q * n
        print(f"  {n:>2} {'coletores' if trilha != 'guarda' else 'guardas':<9}: "
              + " · ".join(f"rank {r}: {q}" for r, q in sorted(total.items())))

if falhas:
    print("❌ FERREIRO COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ ferreiro: lote mais caro com mais gente, novato nivelado primeiro (mais caro), guarda ×2, bônus sobe")
