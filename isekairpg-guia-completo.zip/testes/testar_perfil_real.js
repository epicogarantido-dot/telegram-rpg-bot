// 👤 PERFIL PÚBLICO DE PONTA A PONTA, CONTRA O SERVIDOR DE VERDADE (28/09)
//
// "No rank, se outro jogador clicar no nome dele vê a página de status desse
// jogador: itens, equipamentos, tudo o que aparece no meu personagem — e as
// skills e especialidades."
//
// Dois convidados de verdade na ponte: o "Rival" cria o personagem, aprende
// a habilidade inicial e equipa uma especialidade; o "Leitor" abre o
// ranking no app.js inteiro (navegador falso) e toca no nome do Rival.
// Confere: abre a ficha DELE, só leitura (sem trocar nome, sem barras de
// vida/XP), com Habilidades e Especialidades; a resposta da rota não traz
// ouro/⭐/XP; "‹ Ranking" volta; tocar no próprio nome abre a SUA ficha, que
// também ganhou Habilidades e Especialidades.
const fs = require('fs'), vm = require('vm'), path = require('path');
const { spawn, spawnSync } = require('child_process');
const { montarNavegador } = require('./ponte/navegador_falso');

const RAIZ = path.dirname(__dirname);
const src = fs.readFileSync(path.join(RAIZ, 'webapp/static/app.js'), 'utf8');
const html = fs.readFileSync(path.join(RAIZ, 'webapp/static/index.html'), 'utf8');
const PORTA = 8900 + Math.floor(Math.random() * 90);
const BASE = `http://127.0.0.1:${PORTA}`;
if (spawnSync('python3', ['--version']).status !== 0) { console.log('⏭️ sem python3'); process.exit(2); }

const espera = (ms) => new Promise((r) => setTimeout(r, ms));
let falhas = 0;
const linha = (ok, msg) => { console.log(`${ok ? '✅' : '❌'} ${msg}`); if (!ok) falhas++; };

async function chamar(token, metodo, rota, corpo) {
  const r = await fetch(BASE + rota, { method: metodo, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
                                      body: corpo ? JSON.stringify(corpo) : undefined });
  return { status: r.status, dados: await r.json().catch(() => ({})) };
}

async function criarJogador(nome, classe, spec) {
  const { dados } = await chamar(null, 'POST', '/api/auth/convidado');
  const t = dados.token;
  await chamar(t, 'POST', '/api/character/sexo', { sexo: 'f' });
  await chamar(t, 'POST', '/api/character/raca', { id: 'humano' });
  await chamar(t, 'POST', '/api/character/classe', { id: classe });
  const op = (await chamar(t, 'GET', '/api/character/opcoes')).dados.skills_iniciais[0];
  await chamar(t, 'POST', '/api/character/skill_inicial', { id: op.id });
  await chamar(t, 'POST', '/api/character/nome', { nome });
  if (spec) await chamar(t, 'POST', '/api/specialties/equip', { spec_id: spec, slot_idx: 0 });
  // jogadores do teste já passaram do guia inicial (senão ele segura os toques)
  await chamar(t, 'POST', '/api/tutorial/guia_inicio/visto');
  const eu = (await chamar(t, 'GET', '/api/auth/eu')).dados;
  return { token: t, id: eu.telegram_id, skill: op.nome };
}

(async () => {
  const servidor = spawn('python3', [path.join(__dirname, 'ponte', 'servidor_real.py'), String(PORTA), fs.mkdtempSync('/tmp/perfil-real-')],
                         { stdio: ['ignore', 'pipe', 'pipe'] });
  let log = '';
  servidor.stderr.on('data', (d) => { log += d; });
  await new Promise((ok, falha) => {
    servidor.stdout.on('data', (d) => { if (String(d).includes('PRONTO')) ok(); });
    setTimeout(() => falha(new Error('ponte não subiu: ' + log.slice(-300))), 30000);
  });
  try {
    const rival = await criarJogador('Rival', 'mago', 'spec_fogo');
    const leitor = await criarJogador('Leitor', 'guerreiro', null);

    // a rota pública, crua
    const pub = await chamar(leitor.token, 'GET', `/api/jogador/${rival.id}/ficha`);
    const vazou = ['gold', 'premium', 'xp', 'hp', 'trail_points'].filter((k) => k in pub.dados);
    linha(pub.status === 200 && !vazou.length, `rota pública responde sem ouro/⭐/XP/vida (${vazou.join(', ') || 'nada vazou'})`);
    linha((await chamar(null, 'GET', `/api/jogador/${rival.id}/ficha`)).status === 401, 'sem login, a rota recusa');

    // o app do Leitor
    const nav = montarNavegador({ src, html, BASE });
    const { ctx, porId, tocar, todos } = nav;
    const chave = (src.match(/const CHAVE_TOKEN\s*=\s*["']([^"']+)/) || [])[1];
    nav.store[chave] = leitor.token;
    vm.runInContext(`MEU_ID = ${leitor.id};`, ctx);
    await ctx.entrarNoJogo(); await espera(400);
    await ctx.irPara('ranking'); await espera(400);
    const texto = () => porId.conteudo.textContent || '';
    const abriveis = todos(porId.conteudo).filter((x) => x.classList.contains('abre-perfil'));
    const doRival = abriveis.find((x) => (x.textContent || '').includes('Rival'));
    linha(!!doRival, `no ranking, o Rival é tocável (${abriveis.length} jogadores tocáveis)`);
    tocar(doRival); await espera(500);
    const tela = vm.runInContext('TELA_ATUAL', ctx);
    linha(tela === 'perfil_jogador' && texto().includes('Rival'), `tocar no nome abre a ficha do Rival (tela: ${tela})`);
    for (const secao of ['Status', 'Atributos', 'Equipamentos', 'Habilidades', 'Especialidades', 'Montaria']) {
      linha(texto().includes(secao), `ficha do Rival mostra "${secao}"`);
    }
    linha(texto().includes(rival.skill), `mostra a habilidade dele (${rival.skill})`);
    linha(texto().includes('Mestre do Fogo') || texto().includes('Fogo'), 'mostra a especialidade dele');
    linha(!todos(porId.conteudo).some((x) => x.classList.contains('btn-editar-nome')), 'só leitura: sem botão de trocar o nome');
    linha(!texto().includes('Experiência'), 'só leitura: sem barra de XP do outro');
    const voltar = todos(porId.conteudo).find((x) => x.tag === 'button' && (x.textContent || '').includes('Ranking'));
    tocar(voltar); await espera(400);
    linha(vm.runInContext('TELA_ATUAL', ctx) === 'ranking', '"‹ Ranking" volta pro ranking');
    const meu = todos(porId.conteudo).filter((x) => x.classList.contains('abre-perfil')).find((x) => (x.textContent || '').includes('Leitor'));
    tocar(meu); await espera(500);
    linha(vm.runInContext('TELA_ATUAL', ctx) === 'personagem', 'tocar no PRÓPRIO nome abre a sua ficha');
    linha(texto().includes('Habilidades') && texto().includes('Especialidades') && texto().includes('Experiência'),
          'a sua ficha também ganhou Habilidades e Especialidades (e mantém a barra de XP)');
    const ruins = nav.toasts.filter((t) => t[1]).map((t) => t[0]);
    linha(!ruins.length && !nav.erros.length, `nenhum erro na tela${ruins.length || nav.erros.length ? ': ' + ruins.concat(nav.erros).join(' | ') : ''}`);
  } finally {
    servidor.kill();
  }
  console.log(falhas ? `❌ ${falhas} falha(s)` : '✅ perfil público de ponta a ponta ok');
  process.exit(falhas ? 1 : 0);
})().catch((e) => { console.log('❌ o teste quebrou: ' + e.message); process.exit(1); });
