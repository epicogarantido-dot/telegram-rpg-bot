#!/usr/bin/env python3
"""As tabelas do clã migram sozinhas quando o banco é antigo.

POR QUE ESTE TESTE EXISTE
-------------------------
Produção estourou com `sqlite3.OperationalError: no such column: equip_poder`
na tela do clã. A causa: `CREATE TABLE IF NOT EXISTS` não faz NADA numa
tabela que já existe. O banco de produção nasceu antes de `equip_poder`,
`equip_rank`, `perfil_json` e `perfil_nivel` entrarem no CREATE, e como não
havia migração nenhuma nestas tabelas, as colunas simplesmente não existiam
lá. Lendo o código o schema parecia certo; no disco estava errado.

O teste monta o banco **como estava em produção** — a tabela velha, com
dados dentro — roda `init_clan()` e exige que as colunas apareçam e que
nada se perca. É a única forma de pegar este bug sem ter o banco antigo na
mão.
"""
import sys, os, tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    import aiosqlite  # noqa: F401
except ImportError:
    print("⚠️  aiosqlite não instalado — rode no servidor, onde ele existe.")
    sys.exit(2)

os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "antigo.db")
import game.sql_repo as SR
SR.DB_PATH = os.environ["DB_PATH"]

from game import clan_repo as CR

falhou = 0


def checar(nome, condicao, detalhe=""):
    global falhou
    print(("  ✅ " if condicao else "  ❌ ") + nome + ("" if condicao else f"  -> {detalhe}"))
    if not condicao:
        falhou = 1


# O schema exatamente como era antes do equipamento e do perfil existirem.
SCHEMA_ANTIGO = """
CREATE TABLE clan (
    owner_id    INTEGER PRIMARY KEY,
    nome        TEXT DEFAULT '',
    comida      INTEGER DEFAULT 0,
    materiais   TEXT DEFAULT '{}',
    ultimo_tick INTEGER DEFAULT 0
);
CREATE TABLE clan_membro (
    owner_id INTEGER NOT NULL,
    slot     INTEGER NOT NULL,
    nome     TEXT DEFAULT '',
    nivel    INTEGER DEFAULT 1,
    area_id  TEXT,
    vivo     INTEGER DEFAULT 1,
    PRIMARY KEY (owner_id, slot)
);
"""

print("1. banco velho, com dados dentro")
with CR._conn() as c:
    c.executescript(SCHEMA_ANTIGO)
    c.execute("INSERT INTO clan(owner_id, nome, comida) VALUES (7, 'Os Primeiros', 44)")
    c.execute("INSERT INTO clan_membro(owner_id, slot, nome, nivel, area_id)"
              " VALUES (7, 0, 'Vetusto', 31, 'andar11')")
    c.commit()
    antes_clan = set(CR._colunas_existentes(c, "clan"))
    antes_membro = set(CR._colunas_existentes(c, "clan_membro"))
checar("o banco começa sem equip_poder (como produção)",
       "equip_poder" not in antes_membro)
print(f"     clan:        {len(antes_clan)} colunas")
print(f"     clan_membro: {len(antes_membro)} colunas")

print("\n2. init_clan() migra")
CR.init_clan()
with CR._conn() as c:
    depois_clan = set(CR._colunas_existentes(c, "clan"))
    depois_membro = set(CR._colunas_existentes(c, "clan_membro"))

for tabela, existentes in (("clan", depois_clan), ("clan_membro", depois_membro)):
    faltando = [n for n, _t in CR.TABELAS[tabela]["colunas"] if n not in existentes]
    checar(f"{tabela} tem todas as colunas do schema", not faltando, faltando)
print(f"     clan:        +{len(depois_clan - antes_clan)} "
      f"({', '.join(sorted(depois_clan - antes_clan)) or 'nada'})")
print(f"     clan_membro: +{len(depois_membro - antes_membro)} "
      f"({', '.join(sorted(depois_membro - antes_membro)) or 'nada'})")

print("\n3. os dados que já estavam lá sobreviveram")
clan = CR.carregar_clan(7)
membros = CR.listar_membros(7)
checar("o clã continua lá com o nome e a comida",
       clan["nome"] == "Os Primeiros" and clan["comida"] == 44,
       (clan["nome"], clan["comida"]))
checar("o membro continua lá com nível e posto",
       membros and membros[0]["nome"] == "Vetusto" and membros[0]["nivel"] == 31
       and membros[0]["area_id"] == "andar11", membros)
checar("as colunas novas vieram com o padrão, não com lixo",
       membros and membros[0]["equip_poder"] == 0 and membros[0]["fome"] == 0,
       membros[0] if membros else None)

print("\n4. a operação que estourava em produção agora passa")
try:
    CR.distribuir_equipamento(7)
    checar("distribuir_equipamento roda (era o `no such column: equip_poder`)", True)
except Exception as e:
    checar("distribuir_equipamento roda", False, f"{type(e).__name__}: {e}")

print("\n5. rodar de novo não faz nada (idempotente)")
try:
    CR.init_clan()
    CR.init_clan()
    with CR._conn() as c:
        checar("o schema fica igual depois de reexecutar",
               set(CR._colunas_existentes(c, "clan_membro")) == depois_membro)
except Exception as e:
    checar("init_clan é idempotente", False, f"{type(e).__name__}: {e}")

print("\n6. banco novo em folha nasce completo")
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "novo.db")
SR.DB_PATH = os.environ["DB_PATH"]
CR.init_clan()
with CR._conn() as c:
    for tabela in CR.TABELAS:
        existentes = set(CR._colunas_existentes(c, tabela))
        faltando = [n for n, _t in CR.TABELAS[tabela]["colunas"] if n not in existentes]
        checar(f"{tabela} nasce com o schema inteiro", not faltando, faltando)

print("\n" + ("🟢 SCHEMA DO CLÃ: TUDO PASSOU" if not falhou else "❌ SCHEMA DO CLÃ: FALHOU"))
sys.exit(falhou)
