#!/usr/bin/env python3
"""E2E da moeda única (ouro), do material na forja e da comida comprada.

POR QUE EXISTE
--------------
Em 20/09 três coisas mudaram juntas, e cada uma tem um jeito próprio de
quebrar em silêncio:

1. **Bronze e prata saíram do jogo.** O risco é o que sobra: uma chave
   "bronze" esquecida num `producao`, somada por ninguém — recurso que
   some sem erro. O teste varre o código atrás de chave viva e confere que
   mina, ruínas e minerador agora dão MATERIAL que chega no estoque.
2. **A forja pessoal pede material da Torre.** O risco é cobrar pela
   metade: descontar o ouro e depois descobrir que falta material (foi
   exatamente o bug que a construção do clã já tinha evitado). O teste
   confere que, quando falta material, NADA é descontado — nem ouro, nem
   core — e que a mochila é gasta antes do clã.
3. **Comida se compra com ouro.** O risco é pagar por comida que foi pro
   lixo: o celeiro tem teto, e comprar além dele cobraria por nada. O
   teste confere que só se paga o que entrou.

Roda sem aiosqlite instalado: o caminho testado é todo síncrono.
"""
import sys, os, re, random, sqlite3, tempfile, time, types

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

BANCO = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = BANCO

from game import clan_repo as CR
from game import clan_habitantes as H
from game import territorio as T
from game.clan_materiais import material_do_monstro, teto_de_comida
from game.items import REQ_MATERIAL_CRAFT

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


# ── 1) nenhuma chave viva de bronze/prata no código ────────────────────
vivas = []
for pasta in ("game", "webapp"):
    for raiz, _d, arquivos in os.walk(os.path.join(RAIZ, pasta)):
        for nome in arquivos:
            if not nome.endswith((".py", ".js")):
                continue
            caminho = os.path.join(raiz, nome)
            for n, linha in enumerate(open(caminho, encoding="utf-8"), 1):
                limpa = linha.strip()
                if limpa.startswith(("#", "//")):
                    continue
                if re.search(r"""["'](bronze|prata)["']""", linha):
                    vivas.append(f"{os.path.relpath(caminho, RAIZ)}:{n}")
for raiz, _d, arquivos in os.walk(os.path.join(RAIZ, "game", "conteudo")):
    for nome in arquivos:
        if nome.endswith(".json"):
            texto = open(os.path.join(raiz, nome), encoding="utf-8").read()
            if re.search(r'"(bronze|prata)"\s*:', texto):
                vivas.append(f"conteudo/{nome}")
exigir(not vivas, f"ainda existe chave viva de bronze/prata: {vivas[:5]}")

# (26/09/2026) as decisões antigas saíram; as recompensas das Crônicas
# chegam no jogo de verdade (game/cronicas.py grava no clã/jogador) e as
# rotas antigas não podem voltar.
api = open(os.path.join(RAIZ, "webapp", "api.py"), encoding="utf-8").read()
for rota in ('@app.post("/api/clan/decidir")', '@app.post("/api/clan/fundacao")'):
    exigir(rota not in api, f"{rota} (sistema antigo de decisões) voltou")
cron = open(os.path.join(RAIZ, "game", "cronicas.py"), encoding="utf-8").read()
exigir("UPDATE clan SET comida" in cron and "UPDATE clan SET materiais" in cron,
       "as Crônicas não gravam mais comida/ferro no clã de verdade")

# ── 2) schema novo sem as colunas; banco velho com elas continua abrindo
with sqlite3.connect(BANCO) as c:
    c.execute("CREATE TABLE clan (owner_id INTEGER PRIMARY KEY, comida INTEGER DEFAULT 0,"
              " bronze INTEGER DEFAULT 0, prata INTEGER DEFAULT 0)")
    c.execute("INSERT INTO clan(owner_id, comida, bronze, prata) VALUES (1, 10, 500, 9)")
    c.commit()
CR.init_clan()
velho = CR.carregar_clan(1)
exigir(velho["comida"] == 10, "o clã de um banco velho (com bronze/prata) não abriu")

DONO = 42
clan = CR.carregar_clan(DONO)

# ── 3) comprar comida: só se paga o que coube no celeiro ───────────────
teto = teto_de_comida(clan["comodidades"], 0)
with CR._conn() as c:
    c.execute("UPDATE clan SET comida = ? WHERE owner_id = ?", (teto - 30, DONO))
    c.commit()
r = CR.comprar_comida(DONO, 100)
exigir(r["ok"] and r["comprado"] == 30,
       f"o celeiro tinha espaço pra 30 e a compra entregou {r.get('comprado')}")
exigir(r["custo_ouro"] == CR.custo_comida(30),
       "cobrou pela comida pedida, não pela que entrou — pagou por comida jogada fora")
exigir(CR.carregar_clan(DONO)["comida"] == teto, "a comida comprada não chegou no celeiro")
exigir(not CR.comprar_comida(DONO, 10)["ok"], "comprou com o celeiro cheio")

# ── 4) especialização: trocar pede ouro, e quem cobra é quem chama ─────
with CR._conn() as c:
    c.execute("UPDATE clan SET especializacoes = ? WHERE owner_id = ?",
              ('["militar"]', DONO))
    c.commit()
r = CR.escolher_especializacao(DONO, "agricola", trocar="militar", ouro_disponivel=10)
exigir(not r["ok"], "trocou de identidade sem ter o ouro da troca")
r = CR.escolher_especializacao(DONO, "agricola", trocar="militar",
                               ouro_disponivel=H.CUSTO_TROCAR_ESPECIALIZACAO)
exigir(r["ok"] and r["custo_ouro"] == H.CUSTO_TROCAR_ESPECIALIZACAO,
       f"a troca paga não devolveu o custo pro chamador cobrar: {r}")

# ── 5) AFK: minerador e mina do mapa dão MATERIAL, e sai ouro no relatório
with CR._conn() as c:
    # 20/09 (equipes): o minerador coleta numa EQUIPE, num veio do andar do
    # clã (50), com guarda; ferro/couro/madeira pra manutenção do guarda
    c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial, fadiga,"
              " descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
              (DONO, "Kael", "minerador", 20, 5, 0, 0, 0, 1, '{"minerador": 5}'))
    c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial, fadiga,"
              " descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
              (DONO, "Brasa", "guarda", 100, 5, 0, 0, 0, 1, '{"guarda": 5}'))
    c.execute("UPDATE clan SET materiais = '{\"1\": 5}', comida = 100, couro = 20, madeira = 20,"
              " ultimo_tick = ? WHERE owner_id = ?", (int(time.time()) - 6 * 3600, DONO))
    c.commit()
mina = next(p for p in CR.listar_mapa() if p["tipo"] == "mina" and p["andar"] == 50)
with CR._conn() as c:
    c.execute("UPDATE territorio SET dono_tipo='jogador', dono_id=?, integridade=100 WHERE id=?",
              (str(DONO), mina["id"]))
    # o clã tem que ESTAR no andar do ponto (regra de 20/09: a mina do
    # tier 10 fica no Andar 50)
    c.execute("UPDATE clan SET ponto_id = ?, andar = 50 WHERE owner_id = ?", (mina["id"], DONO))
    c.commit()
pts = CR.postos_descobertos(DONO)
pts["p50_veio"] = {"id": "p50_veio", "andar": 50, "tipo": "veio", "estrelas": 2, "mult": 1.0}
CR._gravar_postos(DONO, pts)
ids_d = {h["nome"]: h["id"] for h in CR.listar_habitantes(DONO)}
exigir(CR.montar_equipe(DONO, "p50_veio", [ids_d["Kael"]], [ids_d["Brasa"]], 60)["ok"],
       "não montou a equipe do veio")
rel = CR.rodar_afk(DONO, areas={}, modelos={}, rng=random.Random(3))
mats = CR.carregar_clan(DONO)["materiais"]
exigir("ouro" in rel, "o relatório do AFK não traz a chave 'ouro'")
exigir(mats.get(1, 0) > 0, f"o minerador não pôs material rank 1 no clã: {mats}")
# 20/09: a mina não produz — dá +150% (tier 10) no material que o clã tira
extra_mat = ((rel.get("territorio") or {}).get("extra") or {}).get("material") or {}
exigir(extra_mat.get(1, 0) > 0 or rel.get("territorio", {}).get("perdido"),
       f"a mina do tier 10 não deu bônus no material do minerador: {rel.get('territorio')}")

# ── 6) material que o monstro deixa ────────────────────────────────────
rng = random.Random(1)
exigir(material_do_monstro(45, "boss", rng) == (3, 1), "chefe não deixa 1 de rank 3")
exigir(material_do_monstro(3, "elite", rng) == (2, 1), "elite não deixa 1 de rank 2")
normais = [material_do_monstro(15, "normal", rng)[1] for _ in range(4000)]
taxa = sum(1 for q in normais if q) / len(normais)
exigir(0.28 <= taxa <= 0.42, f"monstro comum deixa material em {100 * taxa:.0f}% das vezes (esperado ~35%)")

# ── 7) forja: sem material, NADA é cobrado; com, a mochila vai primeiro ─
from game.craft import craft_confirm
from game.items import RARITIES, REQ_CRAFT, SLOTS

slot = "armor"
req_cores = REQ_CRAFT.get(slot, {})
need = int(RARITIES["common"]["cores"])
sel = []
for base, qtd in req_cores.items():
    sel += [base] * int(qtd)
while len(sel) < need:
    sel.append(list(req_cores)[0] if req_cores else "ar_def")


def jogador(ouro, mochila):
    # Personagem completo o bastante pro `recalc` que roda depois da forja
    # bem-sucedida — o mesmo formato que `testar_fome.py` usa.
    return {"telegram_id": DONO, "gold": ouro, "state": "CITY", "level": 5,
            "xp": 0, "xp_next": 9 ** 9, "tower_floor": 1, "hp": 100, "hp_max": 100,
            "class_id": None, "race_id": None,
            "attrs": {k: 5 for k in ("str", "vit", "agi", "dex")},
            "trails": {}, "combat": None, "chakra": None,
            "skills_learned": {}, "skill_slots": {"equipped": [None] * 5},
            "materiais_torre": {"1": mochila},
            "craft": {"slot": slot, "rar": "common", "sub": None, "sel": list(sel)},
            "inv": {"potion": 0, "cores": {c: 5 for c in set(sel)},
                    "items": {s: [] for s in SLOTS}},
            "equip": {}, "pets": {"owned": {}, "deck": [None] * 5}}


req = REQ_MATERIAL_CRAFT["common"]
with CR._conn() as c:
    c.execute("UPDATE clan SET materiais = '{}' WHERE owner_id = ?", (DONO,))
    c.commit()
p = jogador(10_000, 3)
ok, msg = craft_confirm(p, owner_id=DONO)
exigir(not ok and "material" in msg.lower(), f"forjou sem material: {msg}")
exigir(p["gold"] == 10_000, "faltou material e mesmo assim o ouro foi descontado")
exigir(all(q == 5 for q in p["inv"]["cores"].values()),
       "faltou material e mesmo assim os cores foram gastos")

with CR._conn() as c:
    c.execute("UPDATE clan SET materiais = ? WHERE owner_id = ?",
              ('{"1": %d}' % (req["qtd"] - 3 + 7), DONO))
    c.commit()
p = jogador(10_000, 3)
random.seed(0)
craft_confirm(p, owner_id=DONO)
exigir(int(p["materiais_torre"]["1"]) == 0, "a mochila não foi gasta primeiro")
sobra_cla = CR.carregar_clan(DONO)["materiais"].get(1, 0)
exigir(sobra_cla == 7, f"o clã deveria ter ficado com 7 de rank 1, ficou com {sobra_cla}")
exigir(p["gold"] < 10_000, "a forja com material suficiente não cobrou o ouro")

# ── 8) custo pelo tier dos cores, lendário com piso 10 ─────────────────
from game.craft import custo_material
lend_t1 = custo_material("legendary", ["wa_atk"] * 8)
lend_t5 = custo_material("legendary", ["wa_atk_t5"] * 8)
exigir(lend_t1["rank"] == 3, "o lendário não pede material rank 3 (de chefe)")
exigir(lend_t1["qtd"] == 10, f"o lendário com cores Tier 1 pede {lend_t1['qtd']}, e não o piso 10")
exigir(lend_t5["qtd"] == 42, f"o lendário com 8 cores Tier 5 pede {lend_t5['qtd']}, e não 10 + 8×4 = 42")
exigir(custo_material("common", ["ar_def_t3"] * 4)["qtd"] == 25 + 4 * 2,
       "o tier dos cores não soma no custo do comum")

# ── 9) mão de obra: tem leitor, é consumida, e não se paga duas vezes ──
clan = CR.carregar_clan(DONO)
exigir(CR.custo_com_mao_de_obra(clan, 60, 40) == (60, 40), "sem contratar, já veio desconto")
exigir(CR.contratar_mao_de_obra(DONO, 0.3), "não gravou a mão de obra contratada")
exigir(not CR.contratar_mao_de_obra(DONO, 0.3),
       "contratou de novo com uma já pendente — pagaria duas vezes pelo mesmo desconto")
clan = CR.carregar_clan(DONO)
exigir(CR.custo_com_mao_de_obra(clan, 60, 40) == (42, 28),
       f"com mão de obra, 60/40 deveria virar 42/28: {CR.custo_com_mao_de_obra(clan, 60, 40)}")
CR.consumir_mao_de_obra(DONO)
exigir(CR.custo_com_mao_de_obra(CR.carregar_clan(DONO), 60, 40) == (60, 40),
       "o desconto não foi consumido depois da construção")
corpo_construir = api[api.index('@app.post("/api/clan/construir")'):]
corpo_construir = corpo_construir[:corpo_construir.index("@app.", 10)]
exigir("custo_com_mao_de_obra" in corpo_construir and "consumir_mao_de_obra" in corpo_construir,
       "a rota de construir não lê (ou não consome) a mão de obra — voltou a ser enfeite")

# ── 10) ⚔️ o rank vem do MONSTRO (regra do dev, 20/09) ───────────────────
from game.clan_materiais import RANKS, rank_do_monstro
from game.clan_postos import area_do_posto
exigir(sorted(RANKS) == [1, 2, 3], f"material não tem 3 ranks: {sorted(RANKS)}")
for andar in (3, 22, 49):
    exigir(material_do_monstro(andar, "normal", random.Random(0))[0] == 1,
           f"monstro comum do andar {andar} não deixa rank 1")
    exigir(material_do_monstro(andar, "elite", random.Random(0))[0] == 2
           and material_do_monstro(andar, "general", random.Random(0))[0] == 2,
           f"elite/general do andar {andar} não deixam rank 2")
exigir(material_do_monstro(10, "boss", random.Random(0)) == (3, 1), "chefe não deixa 1 de rank 3")
exigir(REQ_MATERIAL_CRAFT["common"]["rank"] == REQ_MATERIAL_CRAFT["uncommon"]["rank"] == 1
       and REQ_MATERIAL_CRAFT["rare"]["rank"] == REQ_MATERIAL_CRAFT["epic"]["rank"] == 2
       and REQ_MATERIAL_CRAFT["legendary"]["rank"] == 3,
       "a forja não pede rank 1 (comum/incomum), 2 (raro/épico), 3 (lendário)")
exigir(area_do_posto({"id": "p9_veio", "andar": 9, "tipo": "veio", "estrelas": 2, "mult": 1.0})["rank"] == 1
       and area_do_posto({"id": "p49_veio_rico", "andar": 49, "tipo": "veio_rico",
                          "estrelas": 2, "mult": 1.0})["rank"] == 2,
       "veio não dá rank 1, ou veio profundo não dá rank 2 (rank 3 é só de chefe)")

if falhas:
    print("❌ OURO / FORJA / COMIDA COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print(f"✅ só ouro no código, material na forja (mochila primeiro), comida paga só no que coube; "
      f"monstro comum deixa material em {100 * taxa:.0f}% das vezes")
