#!/usr/bin/env python3
"""O estado do jogador sobrevive ao save/load.

POR QUE ESTE TESTE EXISTE
-------------------------
`save_player_sql` só grava os campos que estão numa lista à mão
(`_extra_fields`). O que não tem coluna própria e não está nela é
**descartado em silêncio** — sem erro, sem aviso. O jogo funciona
perfeitamente até o próximo `_carregar_jogador`, e aí o campo simplesmente
não está lá.

Essa lista já mordeu quatro vezes. As duas últimas foram relatadas juntas:

  - RECOMPENSA DIÁRIA INFINITA. `claim_daily_reward` grava
    `daily_login_date` e recusa se for hoje. O campo era descartado, então
    todo reload o jogador voltava sem data e podia pegar de novo, pra
    sempre.
  - SUBIR ANDAR NÃO FUNCIONAVA. A vitória marca `tower_choice`, o front
    mostra "Avançar ou ficar", e `/api/tower/advance` recarrega do banco
    pra decidir. Sem o campo, o `if` falhava em silêncio: o botão
    respondia e o andar não subia.

Antes disso foram `pending_orders`/`conta_em_analise` (o Pix) e
`conta_bloqueada` (o bloqueio do admin que se desfazia sozinho).

Ler o código não pega este bug: o código parece certo dos dois lados. Só
gravar de verdade e reler pega.
"""
import sys, os, tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    import aiosqlite  # noqa: F401
except ImportError:
    print("⚠️  aiosqlite não instalado — rode no servidor, onde ele existe.")
    sys.exit(2)

import asyncio
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = os.environ["DB_PATH"]

falhou = 0


def checar(nome, condicao, detalhe=""):
    global falhou
    print(("  ✅ " if condicao else "  ❌ ") + nome + ("" if condicao else f"  -> {detalhe}"))
    if not condicao:
        falhou = 1


# Um valor reconhecível por campo, pra saber se voltou o que foi gravado.
ESTADO = {
    "daily_login_date": "2026-09-18",
    "daily_streak": 5,
    "last_daily": 1789000000,
    "tower_choice": True,
    "tower_mode": "normal",
    "explore_mode": True,
    "explore_state": {"saved_tower_floor": 37, "passos": 3},
    "wave_mode": True,
    "wave_state": {"onda": 9},
    "wave_recorde": 14,
    "raid_floor": 22,
    "raid_ready": True,
    "raid_target": 2,
    "global_boss_session": {"dano": 5000},
    "specialties": ["ferreiro"],
    "almas": 13,
    "skill_cooldowns": {"bola_de_fogo": 3},
    "socket_temp": {"target": "arma", "slot_idx": 1},
    "craft": {"slot": "arma", "rar": "raro", "sub": None, "sel": []},
    # Os que já estavam na lista — não podem regredir.
    "chakra": "Fogo",
    "pending_orders": [{"id": "x1", "estrelas": 100}],
    "conta_bloqueada": True,
    "storylets": {"turno": 12, "qualidades": {"moral": 40}},
}

TELEGRAM_ID = 777001


async def rodar():
    await SR.init_db() if hasattr(SR, "init_db") else None


print("1. grava um jogador com o estado todo preenchido")
try:
    asyncio.get_event_loop()
except RuntimeError:
    asyncio.set_event_loop(asyncio.new_event_loop())

if hasattr(SR, "init_db"):
    asyncio.get_event_loop().run_until_complete(SR.init_db())

jogador = {
    "telegram_id": TELEGRAM_ID, "username": "teste", "level": 30,
    "gold": 1000, "tower_floor": 12, "hp": 100, "hp_max": 100, "state": "TOWER",
    "xp": 0, "xp_next": 500, "attrs": {"str": 10}, "trails": {}, "combat": None,
    "pets": {"owned": {}, "deck": [None] * 5},
}
jogador.update(ESTADO)

asyncio.get_event_loop().run_until_complete(
    SR.save_player_sql_async(TELEGRAM_ID, jogador))
print(f"     {len(ESTADO)} campos gravados")

print("\n2. relê do banco — nada pode ter sumido")
lido = asyncio.get_event_loop().run_until_complete(
    SR.load_player_sql_async(TELEGRAM_ID)) if hasattr(SR, "load_player_sql_async") \
    else SR.load_player(TELEGRAM_ID)

sumidos = [k for k in ESTADO if k not in (lido or {})]
checar(f"os {len(ESTADO)} campos voltaram", not sumidos, sumidos)

errados = [f"{k}: gravou {ESTADO[k]!r}, voltou {lido.get(k)!r}"
           for k in ESTADO if k in (lido or {}) and lido.get(k) != ESTADO[k]]
checar("voltaram com o MESMO valor", not errados, errados[:3])

print("\n3. os dois bugs relatados, no caminho que o jogo usa")
checar("recompensa diária: a data do resgate sobrevive",
       lido.get("daily_login_date") == "2026-09-18", lido.get("daily_login_date"))
checar("subir andar: tower_choice sobrevive",
       bool(lido.get("tower_choice")), lido.get("tower_choice"))
checar("exploração: saved_tower_floor sobrevive (armadilha nº 5)",
       (lido.get("explore_state") or {}).get("saved_tower_floor") == 37,
       lido.get("explore_state"))
checar("modo onda: o recorde sobrevive",
       lido.get("wave_recorde") == 14, lido.get("wave_recorde"))

print("\n4. claim_daily_reward recusa o segundo resgate no mesmo dia")
from game.logic import claim_daily_reward
import datetime
novo = dict(jogador)
novo["daily_login_date"] = ""
ok1, _ = claim_daily_reward(novo)
checar("o primeiro resgate passa", ok1)
asyncio.get_event_loop().run_until_complete(
    SR.save_player_sql_async(TELEGRAM_ID + 1, novo))
relido = SR.load_player(TELEGRAM_ID + 1)
hoje = datetime.datetime.now().strftime("%Y-%m-%d")
checar("a data ficou gravada com o dia de hoje",
       relido.get("daily_login_date") == hoje, relido.get("daily_login_date"))
ok2, msg2 = claim_daily_reward(relido)
checar("o segundo resgate, DEPOIS de reler do banco, é recusado", not ok2, msg2[:60])

print("\n" + ("🟢 ESTADO DO JOGADOR: TUDO PASSOU" if not falhou
              else "❌ ESTADO DO JOGADOR: FALHOU"))
sys.exit(falhou)
