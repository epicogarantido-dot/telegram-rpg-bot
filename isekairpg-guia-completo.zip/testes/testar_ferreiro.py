#!/usr/bin/env python3
"""E2E do ferreiro no banco: evoluir o lote cobra o material do clã e sobe
TODO mundo; quem chega depois precisa ser nivelado antes do próximo lote;
sem material não cobra nada; o tier aparece na produção de verdade."""
import sys, os, json, tempfile, types

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

BANCO = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = BANCO
from game import clan_repo as CR
from game import clan_equipes as E

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


CR.init_clan()
DONO = 8
CR.carregar_clan(DONO)


def novo(nome, talentos):
    with CR._conn() as c:
        c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial, fadiga,"
                  " descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
                  (DONO, nome, "agricultor", 10, 1, 0, 0, 0, 1, json.dumps(talentos)))
        c.commit()


def material(**ranks):
    with CR._conn() as c:
        c.execute("UPDATE clan SET materiais = ? WHERE owner_id = ?",
                  (json.dumps({str(k[1:]): v for k, v in ranks.items()}), DONO))
        c.commit()


for i in range(4):
    novo(f"N{i}", {"agricultor": 2})
novo("Guarda", {"guarda": 1})


def equipe_da_clareira():
    """A bancada só vê quem está FAZENDO a função: todos na clareira."""
    habs = CR.listar_habitantes(DONO)
    col = [h["id"] for h in habs if h["nome"] != "Guarda"]
    g = [h["id"] for h in habs if h["nome"] == "Guarda"]
    assert CR.montar_equipe(DONO, "p1_clareira", col, g, 5)["ok"]


equipe_da_clareira()

material(r1=5)
r = CR.usar_ferreiro(DONO, "agricultor")
exigir(not r["ok"] and CR.carregar_clan(DONO)["materiais"].get(1) == 5, "sem material, o ferreiro cobrou")

material(r1=100)
antes = E.producao_do_coletor(CR.listar_habitantes(DONO)[0], "comida")
r = CR.usar_ferreiro(DONO, "agricultor")
exigir(r["ok"] and r["acao"] == "evoluir" and r["alvo"] == 2, f"não evoluiu o lote: {r}")
exigir(CR.carregar_clan(DONO)["materiais"].get(1) == 100 - 3 * 4, "o lote de 4 não cobrou 3 por cabeça")
exigir(all(h["tiers"].get("agricultor") == 2 for h in CR.listar_habitantes(DONO) if h["nome"] != "Guarda"),
       "nem todos os agricultores subiram pro Tier 2")
exigir(not CR.listar_habitantes(DONO)[-1]["tiers"].get("agricultor"),
       "o guarda subiu na bancada dos agricultores")
depois = E.producao_do_coletor(CR.listar_habitantes(DONO)[0], "comida")
exigir(depois > antes, "a ferramenta Tier 2 não aumentou a produção de verdade")

novo("Recém", {"agricultor": 1})
equipe_da_clareira()
r = CR.usar_ferreiro(DONO, "agricultor")
exigir(r["ok"] and r["acao"] == "nivelar" and r["quantos"] == 1, f"o recém-chegado não foi nivelado primeiro: {r}")
exigir(CR.carregar_clan(DONO)["materiais"].get(1) == 88 - 5, "nivelar não custou 1,5× (3 → 5 arredondado)")
exigir(all(h["tiers"].get("agricultor") == 2 for h in CR.listar_habitantes(DONO) if h["nome"] != "Guarda"),
       "o recém-chegado não chegou no Tier 2")

if falhas:
    print("❌ FERREIRO (E2E) COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ ferreiro no disco: lote cobra e sobe todos, novato nivelado antes (mais caro), bônus na produção")
