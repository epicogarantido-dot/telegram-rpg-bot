"""Imports tardios de api.py — só quebram quando a rota é chamada, então
uma verificação em tempo de teste é a única rede possível."""
#
# ⚠️ 17/09/2026 — este teste importava um `stub_aiosqlite` de
# '/home/claude/bench' e fazia chdir pra '/home/claude/isekai', dois
# caminhos absolutos da máquina de quem escreveu. Fora dali ele não
# passava NUNCA — nem no servidor, onde o aiosqlite de verdade existe mas
# o stub não. Agora a raiz vem do próprio arquivo e a dependência é
# checada como nos auditores: sai com 2 (pulado) em vez de 1 (falhou).
import ast, sys, importlib, os
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ); os.chdir(RAIZ)
try:
    import aiosqlite  # noqa: F401
except ImportError:
    print("⚠️  aiosqlite não instalado — rode no servidor, onde ele existe.")
    sys.exit(2)
arv = ast.parse(open("webapp/api.py", encoding="utf-8").read())
alvos = [(f.module, a.name, no.name, f.lineno)
         for no in ast.walk(arv) if isinstance(no,(ast.FunctionDef, ast.AsyncFunctionDef))
         for f in ast.walk(no) if isinstance(f, ast.ImportFrom) and f.module
         for a in f.names]
ruins = []
for mod, nome, func, linha in alvos:
    try: m = importlib.import_module(mod)
    except Exception as e: ruins.append(f"{func}():{linha} '{mod}' -> {e}"); continue
    if hasattr(m, nome): continue
    try: importlib.import_module(f"{mod}.{nome}")
    except Exception: ruins.append(f"{func}():{linha} '{mod}' não tem '{nome}'")
if ruins:
    print(f"  ❌ {len(ruins)} import(s) tardio(s) quebrado(s):")
    for r in ruins[:10]: print("     ", r)
    sys.exit(1)
print(f"  ✅ {len(alvos)} imports dentro de rotas, todos resolvem")
print("🟢 IMPORTS TARDIOS: TUDO PASSOU")
