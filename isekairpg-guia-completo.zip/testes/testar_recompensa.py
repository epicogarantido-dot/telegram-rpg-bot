#!/usr/bin/env python3
"""🎁 Janela de recompensa (28/09, dev) — o pacote da vitória.

Os ganhos de cada abate se somam DENTRO do combate (salvo entre um toque e
outro) e viram um pacote só na vitória (`_ultima_recompensa`), que a resposta
da luta entrega e tira do jogador (aparece uma vez). Trava:
- o pacote bate com o que entrou de fato (XP do jogador, cores na mochila);
- subir de nível vem no pacote;
- morrer não gera pacote;
- no teto de nível do andar, o pacote diz "travado" e não inventa XP.
"""
import os, sys, types, random, copy
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    f = types.ModuleType("aiosqlite"); f.connect = lambda *a, **k: None; sys.modules["aiosqlite"] = f
import game.logic as L

falhas = []
def exigir(c, m):
    print(("✅ " if c else "❌ ") + m)
    if not c: falhas.append(m)

def jogador(nivel=1, andar=1):
    p = L.create_player(7); p["class_id"] = "guerreiro"; p["race_id"] = "humano"
    p["level"] = nivel; p["tower_floor"] = andar; p["state"] = "TOWER"
    L.recalc(p); p["hp"] = p["hp_max"]; return p

def lutar(p):
    L.start_combat(p)
    for _ in range(300):
        L.combat_attack(p)
        if not (p.get("combat") or {}).get("enemies") or p["hp"] <= 0:
            break

random.seed(3)
vitorias = mortes_sem = 0
for _ in range(40):
    p = jogador()
    xp0, cores0 = int(p.get("xp") or 0), sum((p["inv"].get("cores") or {}).values())
    nivel0 = p["level"]
    lutar(p)
    rec = p.get("_ultima_recompensa")
    if p["hp"] <= 0:
        mortes_sem += rec is None
        continue
    vitorias += 1
    cores_pacote = sum(c["qtd"] for c in (rec or {}).get("cores", {}).values())
    cores_novos = sum((p["inv"].get("cores") or {}).values()) - cores0
    xp_real = (p["level"] - nivel0) * 0 + int(p.get("xp") or 0) - xp0
    if vitorias == 1:
        print("   exemplo de pacote:", {k: v for k, v in (rec or {}).items() if k != "id"})
    if not rec or cores_pacote != cores_novos or (p["level"] == nivel0 and rec.get("xp") != xp_real):
        falhas.append(f"pacote não bate: {rec} · cores +{cores_novos} · xp +{xp_real}")
exigir(vitorias >= 20 and not any("não bate" in f for f in falhas),
       f"{vitorias} vitórias: o pacote bate com o XP e os cores que entraram de verdade")
exigir(mortes_sem == 40 - vitorias, "derrota não gera pacote")

# subir de nível vem no pacote
p = jogador(); p["xp"] = int(p.get("xp_next") or 100) - 1
lutar(p)
exigir(p["hp"] <= 0 or (p.get("_ultima_recompensa") or {}).get("nivel") == p["level"],
       f"subir de nível vem no pacote (nível {p['level']})")

# teto de nível do andar: travado, sem XP inventado
p = jogador(nivel=2, andar=1)
lutar(p)
rec = p.get("_ultima_recompensa") or {}
exigir(p["hp"] <= 0 or (rec.get("xp_travado") and not rec.get("xp")),
       "no nível máximo do andar: pacote diz 'travado' e não mostra XP")

print("\n" + ("🟢 RECOMPENSA: TUDO PASSOU" if not falhas else f"🔴 {len(falhas)} FALHA(S)"))
sys.exit(1 if falhas else 0)
