// SIMULA o guia de clique (GUIA_INICIO) com LATÊNCIA DE REDE.
//
// POR QUE ESTE TESTE EXISTE
// -------------------------
// O guia acha o alvo 250 ms depois do toque. Quando o toque dispara um
// pedido ao servidor (Atacar, Equipar, trocar de aba da Mochila), a tela só
// é redesenhada quando a resposta chega. Se ela demora mais que isso, o guia
// "agarra" o botão VELHO, a tela troca por um botão novo igualzinho, e o
// toque do jogador no botão novo é BLOQUEADO — só sobra "Pular tutorial".
// No celular, com o servidor longe, 300 ms de resposta é o normal.
//
// O teste roda as funções REAIS do guia (recortadas do app.js) num DOM de
// mentira que troca os elementos depois de L ms, e conta quantos toques do
// jogador foram engolidos para cada latência.
//
// Uso: node testar_guia.js [caminho/do/app.js]
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const arq = process.argv[2] || path.join(path.dirname(__dirname), 'webapp/static/app.js');
const src = fs.readFileSync(arq, 'utf8');
const ini = src.indexOf('let GUIA_ATIVO = null;');
const fim = src.indexOf('async function talvezMostrarTutorial');
if (ini < 0 || fim < 0) { console.log('❌ não achei o bloco do guia no app.js'); process.exit(1); }
const bloco = src.slice(ini, fim);

// ---------- DOM de mentira ----------
function criarDom() {
  const vivos = new Map();                  // seletor -> elemento atual
  const soltos = [];
  let serie = 0;
  function elem(seletor) {
    const e = {
      id: ++serie, seletor, conectado: true, filhos: [],
      style: {}, className: '', textContent: '',
      get isConnected() { return this.conectado; },
      contains(x) { return x === this; },
      closest(s) { return s === this.seletor ? this : null; },
      getBoundingClientRect() {
        return this.conectado ? { left: 10, top: 300, width: 100, height: 40, bottom: 340 }
                              : { left: 0, top: 0, width: 0, height: 0, bottom: 0 };
      },
      scrollIntoView() {}, appendChild(x) { this.filhos.push(x); return x; },
      remove() { this.conectado = false; }, set innerHTML(v) { this.filhos = []; },
      get innerHTML() { return ''; }, set onclick(f) { this._click = f; }, get onclick() { return this._click; },
    };
    return e;
  }
  const doc = {
    ouvintes: [],
    body: elem('body'),
    addEventListener(t, f) { if (t === 'click') this.ouvintes.push(f); },
    removeEventListener(t, f) { this.ouvintes = this.ouvintes.filter((x) => x !== f); },
    getElementById(id) { return id === 'guia-camada' ? (this._camada ||= elem('#guia-camada')) : null; },
    createElement(t) { return elem(t); },
    querySelector(s) { for (const p of String(s).split(',')) { const e = vivos.get(p.trim()); if (e) return e; } return null; },
    contains(e) { return !!(e && e.conectado); },
  };
  return {
    doc,
    por(seletor) { const e = elem(seletor); vivos.set(seletor, e); return e; },
    trocar(seletor) {                         // a tela redesenhou: elemento novo
      const velho = vivos.get(seletor); if (velho) { velho.conectado = false; soltos.push(velho); }
      return this.por(seletor);
    },
    atual(seletor) { return vivos.get(seletor); },
    // o jogador toca no que está NA TELA agora
    tocar(seletor) {
      const alvo = vivos.get(seletor);
      let bloqueado = false;
      const ev = { target: alvo, preventDefault() { bloqueado = true; }, stopPropagation() {} };
      for (const f of [...doc.ouvintes]) f(ev);
      if (!bloqueado && alvo && alvo._acao) alvo._acao();
      return !bloqueado;
    },
  };
}

async function cenario(latencia) {
  const dom = criarDom();
  const esperar = (ms) => new Promise((r) => setTimeout(r, ms));
  const ctx = vm.createContext({
    document: dom.doc, window: { addEventListener() {}, innerHeight: 800 },
    setTimeout, clearTimeout, setInterval, clearInterval, Promise, Date, Math, String, Object,
    requestAnimationFrame: (f) => setTimeout(f, 16), cancelAnimationFrame: clearTimeout,
    el: (tag, cls, txt) => { const e = dom.doc.createElement(tag); e.className = cls || ''; e.textContent = txt || ''; return e; },
    sleep: esperar, toast() {}, desenharCombate() {}, renderTorre() {},
    api: async () => ({ visto: false }),
    console,
  });
  vm.runInContext(bloco + '\nthis.__g = () => GUIA_ATIVO;', ctx);

  // telas: botão Atacar (2 toques) e, na Mochila, Equipar → aba Armadura
  const recarregar = (...sels) => setTimeout(() => {
    for (const s of sels) { const n = dom.trocar(s); n._acao = acoes[s]; }
  }, latencia);
  const acoes = {
    '#btn-atacar': () => recarregar('#btn-atacar', '.combate-vs'),
    '.btn-equipar': () => recarregar('.btn-equipar', '[data-inv-slot="armor"]'),
    '[data-inv-slot="armor"]': () => recarregar('.btn-equipar', '[data-inv-slot="armor"]'),
  };
  for (const s of Object.keys(acoes)) dom.por(s)._acao = acoes[s];
  dom.por('.combate-vs');

  const passos = [
    { alvo: '#btn-atacar', vezes: 2, titulo: 'a', texto: '' },
    { alvo: '.combate-vs', ok: true, titulo: 'b', texto: '' },
    { alvo: '.btn-equipar', titulo: 'c', texto: '' },
    { alvo: '[data-inv-slot="armor"]', titulo: 'd', texto: '' },
    { alvo: '.btn-equipar', titulo: 'e', texto: '' },
  ];
  await ctx.iniciarGuia('teste', passos);

  // o jogador: espera a tela assentar (latência + um respiro humano) e toca
  let engolidos = 0, tentativas = 0;
  const humano = 600;
  async function tocarAte(seletor) {
    for (let k = 0; k < 4; k++) {           // desiste depois de 4 toques sem efeito
      await esperar(latencia + humano);
      tentativas++;
      if (dom.tocar(seletor)) { await esperar(latencia + 400); return true; }
      engolidos++;                          // o guia bloqueou o toque no botão certo
    }
    return false;
  }
  const g = () => ctx.__g();
  let ok = await tocarAte('#btn-atacar');          // 1º ataque
  ok = ok && await tocarAte('#btn-atacar');        // 2º ataque
  await esperar(latencia + humano);
  if (ok && g() && g().i === 1) { g().passo.ok && await ctx.avancarGuia(); }
  ok = ok && await tocarAte('.btn-equipar');
  ok = ok && await tocarAte('[data-inv-slot="armor"]');
  ok = ok && await tocarAte('.btn-equipar');
  await esperar(latencia + 800);
  const terminou = !g();
  if (g()) await ctx.encerrarGuia(false);
  return { latencia, terminou, engolidos, tentativas };
}

// ---------- 2. o contador por etapa e a entrada depois da criação ----------
function checarEstatico() {
  let falhas = 0;
  const ctx = vm.createContext({ document: { addEventListener() {} }, window: { addEventListener() {} }, api: async () => ({}) ,
    desenharCombate() {}, renderTorre() {}, toast() {}, setTimeout, clearTimeout, setInterval, clearInterval,
    requestAnimationFrame() {}, cancelAnimationFrame() {} });
  vm.runInContext(bloco + '\nthis.__roteiro = GUIA_INICIO;', ctx);
  const passos = ctx.__roteiro;
  if (typeof ctx.rotuloDoGuia === 'function') {
    const rotulos = passos.map((_, i) => ctx.rotuloDoGuia(passos, i));
    const amostra = passos.map((x, i) => (x.cap || i === passos.length - 1) ? `  ${String(i + 1).padStart(2)}. ${rotulos[i]}` : null).filter(Boolean);
    console.log(`contador (${passos.length} passos, começo de cada etapa):\n` + amostra.join('\n'));
    if (rotulos.some((r) => /^\d+\/\d+$/.test(r))) { console.log('❌ passo sem etapa no guia inicial'); falhas++; }
  } else {
    console.log(`contador: "${passos.length > 30 ? '30' : '1'}/${passos.length}" (sem etapas)`);
  }
  // a criação termina na ENTRADA completa (nome + guia + abas), não numa tela solta
  const criacao = src.slice(src.indexOf('async function telaCriacao'), src.indexOf('// ---------- 🏥 hospital'));
  const soltas = (criacao.match(/else await irPara\("personagem"\)/g) || []).length;
  const entradas = (criacao.match(/else await entrarNoJogo\(\)/g) || []).length;
  console.log(`fim da criação: ${entradas} de ${entradas + soltas} caminhos passam pela entrada completa`);
  if (soltas) falhas++;
  return falhas;
}

// ---------- 3. atualizar a página no meio: o guia retoma no marco ----------
async function checarRetomar() {
  const dom = criarDom();
  const ctx = vm.createContext({
    document: dom.doc, window: { addEventListener() {}, innerHeight: 800 },
    setTimeout, clearTimeout, setInterval, clearInterval, Promise, Date, Math, String, Object,
    requestAnimationFrame: (f) => setTimeout(f, 16), cancelAnimationFrame: clearTimeout,
    el: (t, c, x) => { const e = dom.doc.createElement(t); e.className = c || ''; e.textContent = x || ''; return e; },
    sleep: (ms) => new Promise((r) => setTimeout(r, ms)), toast() {}, desenharCombate() {}, renderTorre() {},
    api: async (url) => (url.includes('/api/tutorial/') ? { visto: false, retomar: ctx.__retomar } : {}),
  });
  vm.runInContext(bloco + '\nthis.__g = () => GUIA_ATIVO; this.__roteiro = GUIA_INICIO;', ctx);
  const passos = ctx.__roteiro;
  for (const x of passos) if (x.alvo) dom.por(x.alvo);   // toda tela "existe": mede só onde o guia abre
  if (!passos.some((x) => x.id)) { console.log('retomar: o guia não tem marcos (recomeça do passo 1 ao atualizar)'); return 1; }
  let falhas = 0;
  for (const [marco, emLuta] of [['forja_resto', false], ['equipar', false], ['atacar', true], ['forja', true]]) {
    ctx.__retomar = marco;
    await ctx.iniciarGuia('guia_inicio', passos, emLuta);
    const g = ctx.__g();
    const onde = g ? (g.passo && g.passo.id) || `passo ${g.i + 1}` : 'não abriu';
    const esperado = emLuta && marco !== 'atacar' ? 'não abriu' : marco;
    console.log(`retomar ${marco}${emLuta ? ' (em luta)' : ''}: ${onde}${onde === esperado ? '' : '  ❌ esperado ' + esperado}`);
    if (onde !== esperado) falhas++;
    if (g) await ctx.encerrarGuia(false);
  }
  return falhas;
}

// ---------- 4. toque duplo rápido (dedo nervoso) ----------
// Toque no alvo certo avança 250 ms depois. Um 2º toque nesse intervalo
// passava de novo: a ação rodava duas vezes (Forjar duas vezes!) e o guia
// avançava dois passos, pulando o seguinte.
async function checarToqueDuplo() {
  const dom = criarDom();
  const esperar = (ms) => new Promise((r) => setTimeout(r, ms));
  const ctx = vm.createContext({
    document: dom.doc, window: { addEventListener() {}, innerHeight: 800 },
    setTimeout, clearTimeout, setInterval, clearInterval, Promise, Date, Math, String, Object,
    requestAnimationFrame: (f) => setTimeout(f, 16), cancelAnimationFrame: clearTimeout,
    el: (t, c, x) => { const e = dom.doc.createElement(t); e.className = c || ''; e.textContent = x || ''; return e; },
    sleep: esperar, toast() {}, desenharCombate() {}, renderTorre() {},
    api: async () => ({ visto: false }),
  });
  vm.runInContext(bloco + '\nthis.__g = () => GUIA_ATIVO;', ctx);
  let forjas = 0, mais = 0;
  dom.por('#aba')._acao = () => {};
  dom.por('#mais')._acao = () => { mais++; };
  dom.por('#forjar')._acao = () => { forjas++; };
  dom.por('#pronto');
  await ctx.iniciarGuia('teste', [
    { alvo: '#aba', titulo: '', texto: '' },
    { alvo: '#mais', vezes: 4, titulo: '', texto: '' },
    { alvo: '#forjar', titulo: '', texto: '' },
    { alvo: '#pronto', ok: true, titulo: '', texto: '' },
  ]);
  const g = () => ctx.__g();
  let falhas = 0;
  await esperar(500); dom.tocar('#aba'); await esperar(60); dom.tocar('#aba'); await esperar(900);
  const pos1 = g() ? g().passo.alvo : 'guia acabou (pulou passos)';
  for (let k = 0; k < 6; k++) { dom.tocar('#mais'); await esperar(70); }   // 6 toques rápidos no +
  await esperar(900);
  const pos2 = g() ? g().passo.alvo : 'guia acabou (pulou passos)';
  dom.tocar('#forjar'); await esperar(60); dom.tocar('#forjar'); await esperar(900);
  const pos3 = g() ? g().passo.alvo : 'guia acabou (pulou passos)';
  const linha = (rot, obtido, esperado) => {
    const ok = obtido === esperado; if (!ok) falhas++;
    console.log(`${rot}: ${obtido}${ok ? '' : '  ❌ esperado ' + esperado}`);
  };
  console.log('toque duplo:');
  linha('  2 toques na aba → guia em', pos1, '#mais');
  linha('  6 toques no + (pede 4) → + contados', mais, 4);
  linha('  → guia em', pos2, '#forjar');
  linha('  2 toques em Forjar → forjas', forjas, 1);
  linha('  → guia em', pos3, '#pronto');
  if (g()) await ctx.encerrarGuia(false);
  return falhas;
}

(async () => {
  console.log(`guia: ${path.relative(process.cwd(), arq)}`);
  const estaticas = checarEstatico() + await checarRetomar() + await checarToqueDuplo();
  console.log('latência | chegou ao fim | toques engolidos');
  let falhas = 0;
  for (const L of [50, 150, 300, 500, 900]) {
    const r = await cenario(L);
    if (!r.terminou || r.engolidos) falhas++;
    console.log(`${String(L).padStart(5)} ms | ${r.terminou ? 'sim' : 'NÃO (travou)'}${' '.repeat(r.terminou ? 11 : 1)}| ${r.engolidos}`);
  }
  if (falhas) console.log(`❌ o guia engole toques em ${falhas} de 5 latências`);
  if (estaticas) console.log('❌ contador ou fluxo de criação com problema');
  if (!falhas && !estaticas) console.log('✅ guia não engole toque, contador por etapa e criação leva à entrada completa');
  process.exit(falhas || estaticas ? 1 : 0);
})();
