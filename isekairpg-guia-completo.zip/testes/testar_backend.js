// Varredura do backend — auth, persistência e portão da cidade.
const fs=require('fs');
// ⚠️ Caminhos derivados deste arquivo, nunca absolutos. Teste com o caminho
// da máquina de quem escreveu não passa em lugar nenhum — nem no servidor —
// e vira rede que não pega nada. É a armadilha nº 11 do projeto.
const path = require('path');
const RAIZ = path.dirname(__dirname);

const api=fs.readFileSync(path.join(RAIZ,'webapp/api.py'),'utf8');
let falhou=false; const ok=t=>console.log('  ✅ '+t); const nok=(t,e='')=>{console.log('  ❌ '+t+' '+e);falhou=true};
const blocos=api.split(/(?=\n@app\.)/);
// Páginas e rotas públicas de propósito: são o próprio site, ou o que cria
// a sessão que as outras exigem.
// '/api/imagens/versoes' é pública de propósito (20/09), como a própria
// '/api/imagem/{chave}': só diz QUAIS artes foram trocadas e quando, pro
// front furar o cache de 24h. Não expõe nada de conta nem de jogo.
// 🎮 28/09: /api/auth/convidado é pública como o registrar — é ela que CRIA a sessão
const publicas=new Set(['/api/auth/registrar','/api/auth/entrar','/api/auth/sair','/api/auth/convidado',
  '/api/imagem/{chave}','/api/imagens/versoes','/admin','/admin/','/','/index.html']);
const prefCidade=['/api/shop','/api/craft','/api/socket','/api/market','/api/gacha','/api/stable','/api/hospital','/api/estabulo'];
const isentas=new Set(['/api/shop/comprovante']);
let total=0; const semAuth=[], semSalvar=[], semCidade=[];
for(const b of blocos){
  const m=/@app\.(get|post|put|delete)\("([^"]+)"/.exec(b); if(!m) continue;
  const [,metodo,rota]=m; total++;
  const i=b.indexOf('def '); const corpo=i<0?'':b.slice(b.indexOf('\n',i));
  if(!publicas.has(rota)&&!rota.startsWith('/api/admin/')&&!/_extrair_usuario/.test(corpo)) semAuth.push(metodo+' '+rota);
  if(rota.startsWith('/api/admin/')&&!/_exigir_admin/.test(corpo)) semAuth.push(metodo+' '+rota+' (admin sem senha)');
  // persistência: aceita o helper OU a função do repo direto — as duas gravam
  if(['post','put','delete'].includes(metodo)&&/_carregar_jogador/.test(corpo)){
    const escreve=/\bp\[["'][a-z_]+["']\]\s*(=|\+=|-=)|\.pop\(|setdefault\(|from game\.\w+ import/.test(corpo);
    // _soltar_trava_pendente conta: a rota que delega a persistência pra outro
    // módulo ainda precisa fechar a trava que _carregar_jogador abriu.
    const salva=/_salvar_jogador|save_player_sql|_soltar_trava_pendente/.test(corpo);
    if(escreve&&!salva) semSalvar.push(metodo+' '+rota);
  }
  if(prefCidade.some(pre=>rota.startsWith(pre))&&!isentas.has(rota)&&!/_exigir_cidade/.test(corpo)) semCidade.push(metodo+' '+rota);
}
console.log(`  rotas analisadas: ${total}`);
semAuth.length?nok('rota sem autenticação',semAuth.join(', ')):ok('toda rota protegida exige sessão (e as de admin, a senha)');
semSalvar.length?nok('mexe no jogador e não grava',semSalvar.join(', ')):ok('toda rota que muda o jogador grava no banco');
semCidade.length?nok('serviço da cidade sem o portão',semCidade.join(', ')):ok('os serviços da cidade exigem estar nela — inclusive as telas de ver');
console.log(falhou?'\n❌ ALGO FALHOU':'\n🟢 VARREDURA DO BACKEND: TUDO PASSOU');
process.exit(falhou?1:0);
