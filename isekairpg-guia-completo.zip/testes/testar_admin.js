#!/usr/bin/env node
/**
 * Executa o JavaScript do /admin num DOM de mentira.
 *
 * POR QUE ESTE TESTE EXISTE
 * -------------------------
 * `node --check` não pega constante não declarada nem função que só
 * quebra quando é chamada — foi a armadilha nº 21, e o app.js ganhou o
 * `executar_appjs.js` por causa dela. O admin.html não tinha nada: o
 * painel roda solto no celular, sem console à vista, e erro lá aparece
 * como "a aba não abre".
 *
 * Foi assim que se descobriu que a aba Backup nunca aparecia: o laço que
 * troca de aba listava só pix/conta/imagens, então clicar em Backup
 * escondia as outras três e não mostrava nada.
 *
 * O teste chama `desenharCatalogo` com os QUATRO estados possíveis de uma
 * chave e com um grupo que estourou, porque o caminho de erro é
 * justamente o que ninguém exercita à mão.
 */
const fs = require("fs");
const path = require("path");
const vm = require("vm");

// A raiz sai do próprio arquivo: caminho absoluto da máquina de alguém é
// enfeite, não rede (armadilha nº 11).
const RAIZ = path.resolve(__dirname, "..");
const html = fs.readFileSync(path.join(RAIZ, "webapp/static/admin.html"), "utf8");

const bloco = html.split("<script>")[1];
if (!bloco || !bloco.includes("</script>")) {
  console.error("❌ não achei o <script> do admin.html");
  process.exit(1);
}
const js = bloco.split("</script>")[0];

const nos = {};
const CHAMADAS = [];
function elemento() {
  const e = {
    innerHTML: "", value: "", textContent: "", disabled: false, dataset: {},
    classList: { add() {}, remove() {}, toggle() {} },
    querySelectorAll: () => [], appendChild() {}, append() {},
  };
  return e;
}
function pegar(id) {
  if (!nos[id]) nos[id] = elemento();
  return nos[id];
}

const ctx = {
  console, setTimeout, Date, encodeURIComponent,
  sessionStorage: { getItem: () => "", setItem() {} },
  fetch: async (url, op) => { CHAMADAS.push({ url, op }); return { ok: true, json: async () => ({}) }; },
  FileReader: class { readAsDataURL() { this.result = "data:image/png;base64,iVBORw0KGgo="; this.onload(); } },
  alert() {}, confirm: () => true,
  document: {
    getElementById: pegar,
    querySelectorAll: () => [],
    createElement: elemento,
    addEventListener() {},
  },
};
ctx.window = { addEventListener() {} };
vm.createContext(ctx);

try {
  vm.runInContext(js, ctx, { filename: "admin.html" });
} catch (e) {
  console.error("❌ o script do admin estourou ao carregar: " + e.message);
  process.exit(1);
}

// ── 1) A troca de abas tem que cobrir TODAS as abas declaradas no HTML.
const abas = [...html.matchAll(/data-aba="([a-z]+)"/g)].map((m) => m[1]);
const laco = (js.match(/for \(const nome of \[([^\]]+)\]/) || [])[1] || "";
const cobertas = [...laco.matchAll(/"([a-z]+)"/g)].map((m) => m[1]);
const descobertas = abas.filter((a) => !cobertas.includes(a));
if (descobertas.length) {
  console.error("❌ aba que nunca se mostra (some ao clicar): " + descobertas.join(", "));
  process.exit(1);
}

// ── 2) O catálogo renderiza os quatro estados e o grupo que estourou.
const fake = {
  total: { total: 4, propria: 1, repetida: 1, emprestada: 1, ausente: 1,
           faltando: 2, invalidas: 1, espelhadas: 1 },
  grupos: [
    { id: "g1", titulo: "Grupo", contagem: { total: 4, propria: 1, repetida: 1,
        emprestada: 1, ausente: 1, faltando: 2, invalidas: 1, espelhadas: 0 },
      itens: [
        { chave: "A", rotulo: "a", estado: "propria", valida: true, espelhada: true, parecida: "", dividido_com: [] },
        { chave: "B", rotulo: "b", estado: "repetida", valida: true, espelhada: false, parecida: "", dividido_com: ["A"] },
        { chave: "MOB_GÁRGULA", rotulo: "c", estado: "emprestada", valida: false, espelhada: false, parecida: "", dividido_com: [] },
        { chave: "MOUNT_X", rotulo: "d", estado: "ausente", valida: true, espelhada: false, parecida: "MOUNT_Y", dividido_com: [] },
      ] },
    { id: "g2", titulo: "Quebrado", erro: "boom", itens: [], contagem: {} },
  ],
};

function rodar(codigo) {
  try { vm.runInContext(codigo, ctx, { filename: "admin.html" }); }
  catch (e) { console.error("❌ " + codigo + " estourou: " + e.message); process.exit(1); }
}
rodar("CATALOGO = " + JSON.stringify(fake) + ";");
rodar('ABERTOS.add("g1"); ABERTOS.add("g2"); desenharCatalogo();');

const saida = nos["cartao-catalogo"].innerHTML;
const exigido = ["MOUNT_Y", "c-ausente", "chave com acento", "Quebrado", "boom"];
for (const t of exigido) {
  if (!saida.includes(t)) {
    console.error("❌ o catálogo não desenhou: " + t);
    process.exit(1);
  }
}
// Filtrado, a chave que TEM arte não pode aparecer; sem filtro, tem que aparecer.
if (saida.includes("c-propria")) {
  console.error("❌ 'só o que falta' mostrou chave que já tem arte");
  process.exit(1);
}
rodar("SO_FALTA = false; desenharCatalogo();");
const tudo = nos["cartao-catalogo"].innerHTML;
if (!tudo.includes("c-propria") || !tudo.includes("c-repetida")) {
  console.error("❌ 'mostrar tudo' não mostrou as chaves com arte");
  process.exit(1);
}

// ── 3) Escapar de verdade: chave com < > não pode virar HTML.
rodar('__t = escapar(\'<img onerror=1>\');');
if (String(ctx.__t).includes("<img")) {
  console.error("❌ escapar() deixou passar HTML");
  process.exit(1);
}

// ── 4) 📤 enviar/trocar: botão certo em cada estado, e o envio chama a rota
if (!tudo.includes("🔁 Trocar") || !tudo.includes("📤 Enviar")) {
  console.error("❌ faltou o botão de trocar (arte que existe) ou de enviar (arte que falta)");
  process.exit(1);
}
if (/data-chave="MOB_GÁRGULA"/.test(tudo)) {
  console.error("❌ chave inválida ganhou botão de envio — o servidor recusaria");
  process.exit(1);
}
(async () => {
  try {
    await vm.runInContext('enviarImagem("MOUNT_X", { size: 1234 })', ctx);
  } catch (e) { console.error("❌ enviarImagem estourou: " + e.message); process.exit(1); }
  const envio = CHAMADAS.find((c) => String(c.url).includes("/api/admin/imagens/enviar"));
  if (!envio || !String(envio.op && envio.op.body).includes("MOUNT_X")) {
    console.error("❌ enviar a imagem não chamou a rota com a chave");
    process.exit(1);
  }
  const grande = CHAMADAS.length;
  await vm.runInContext('enviarImagem("MOUNT_X", { size: 9 * 1024 * 1024 })', ctx);
  if (CHAMADAS.length !== grande) {
    console.error("❌ arquivo de 9 MB foi enviado mesmo acima do limite");
    process.exit(1);
  }
  console.log("✅ painel /admin executa: " + abas.length + " abas cobertas, catálogo renderiza, " +
              "envio e troca de imagem chamam a rota");
})();
