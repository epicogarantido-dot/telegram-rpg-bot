#!/usr/bin/env python3
"""Do aldeão ao cavaleiro (28/09, dev).

"O aldeão desperto vira personagem e, caso tenha muitos personagens, os
personagens podem passar por um treinamento pra virar um cavaleiro — um
tipo novo de aldeão, focado em guerra."

O que este teste trava, com banco de verdade (sqlite num diretório temporário):
- só aldeão DESPERTO vira personagem; ele sai da aldeia, ocupa um slot, e o
  personagem nasce com o nome dele e 4 pontos de trilha por estrela de aura;
- sem slot livre não promove (a saída é treinar alguém como cavaleiro);
- cavaleiro: só personagem extra, fora do armário ativo, nível ≥ mínimo, com
  ferro e couro no clã; ele sai da conta, vira guarda 5★ do nível que tinha,
  entra na guarnição e fica 12h em treino — sem lutar, sem defender, sem sair
  em equipe;
- pronto, rende 10× um guarda 5★ (40× um 1★) e vale 10 guardas na guarnição;
- 💰 mora na cidade do reino: não ocupa casa nem come da aldeia; o custo é o
  SOLDO em ouro (a 1ª semana paga no treino); sem soldo não luta nem defende;
- não troca de ofício (zeraria o nível) e não volta a ser personagem;
- quem saiu da conta sai da lista de membros do clã.
E imprime a tabela de poder que decide se a troca vale a pena.
"""
import sys, os, types, time, json, random, asyncio, sqlite3, tempfile

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)

try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    # aiosqlite mínimo em cima do sqlite3: só pro init_db criar as tabelas
    falso = types.ModuleType("aiosqlite")

    class _Cur:
        def __init__(s, c): s.c = c
        async def fetchone(s): return s.c.fetchone()
        async def fetchall(s): return s.c.fetchall()
        async def close(s): pass

    class _Exec:
        def __init__(s, conn, sql, params): s.conn, s.sql, s.params, s.r = conn, sql, params, None
        def _run(s):
            if s.r is None:
                s.r = _Cur(s.conn.execute(s.sql, s.params))
            return s.r
        def __await__(s):
            async def f(): return s._run()
            return f().__await__()
        async def __aenter__(s): return s._run()
        async def __aexit__(s, *a): pass

    class _Conn:
        def __init__(s, path, **k): s.path, s.conn, s.row_factory = path, None, None
        async def _abrir(s):
            s.conn = sqlite3.connect(s.path)
            return s
        def __await__(s): return s._abrir().__await__()
        async def __aenter__(s): return await s._abrir()
        async def __aexit__(s, *a): s.conn.commit(); s.conn.close()
        def execute(s, sql, params=()):
            if s.row_factory is not None:
                s.conn.row_factory = s.row_factory
            return _Exec(s.conn, sql, params)
        async def executemany(s, sql, seq): s.conn.executemany(sql, seq)
        async def executescript(s, sql): s.conn.executescript(sql)
        async def commit(s): s.conn.commit()
        async def close(s): s.conn.close()

    falso.connect = lambda path, **k: _Conn(path, **k)
    falso.Row = sqlite3.Row
    falso.Error = sqlite3.Error
    sys.modules["aiosqlite"] = falso

PASTA = tempfile.mkdtemp()
os.chdir(PASTA)
os.makedirs("data", exist_ok=True)
import game.sql_repo as SR
asyncio.run(SR.init_db())
from game import characters as CH
from game import clan_repo as CR
from game import clan_equipes as E
from game import clan_habitantes as H
from game import cronicas as K
from game.clan_batalha import poder_do_personagem
from game.logic import create_player

CH.init_tables()
CR.init_clan()

falhas = []


def exigir(cond, msg):
    print(("✅ " if cond else "❌ ") + msg)
    if not cond:
        falhas.append(msg)


# ─────────────────────────────────────────── a conta: principal + clã fundado
DONO = 4242
p = create_player(DONO); p["username"] = "Chefe"; p["tower_floor"] = 3
SR.save_player_sql(DONO, p)
CR.carregar_clan(DONO)
K.garantir_fundacao(DONO, p)
CR.garantir_populacao_inicial(DONO, random.Random(1))
CR.sincronizar_com_slots(DONO)

# ─────────────────────────────────────────── 1. aldeão desperto → personagem
habs = CR.listar_habitantes(DONO)
comum, desperto = habs[0], habs[1]
desperto["aura"] = 4
with CR._conn() as c:
    CR._gravar_habitantes(c, DONO, [desperto], int(time.time()))
    c.commit()
r = CR.promover_a_personagem(DONO, comum["id"])
exigir(not r["ok"], "aldeão SEM aura não vira personagem")
r = CR.promover_a_personagem(DONO, desperto["id"])
exigir(r["ok"], f"aldeão desperto vira personagem ({r.get('erro') or 'slot ' + str(r.get('slot'))})")
slot_novo = r.get("slot")
vivos_ids = {h["id"] for h in CR.listar_habitantes(DONO)}
exigir(desperto["id"] not in vivos_ids, "quem virou personagem saiu da aldeia")
ok, _ = CH.trocar_personagem(DONO, slot_novo)
pn = SR.load_player(DONO)
exigir(ok and pn.get("username") == desperto["nome"], f"o personagem nasce com o nome da aldeia ({pn.get('username')})")
exigir(int(pn.get("trail_points") or 0) == 16, f"aura 4★ → 16 pontos de trilha (tem {pn.get('trail_points')})")
exigir((pn.get("origem_aldeao") or {}).get("aura") == 4, "a origem fica gravada no personagem")
# 🌱 nascido na Torre: raça e profissão sorteadas, +10% em todos os status
from game.logic import RACESDB, CLASSESDB, recalc
import copy
exigir(pn.get("race_id") in RACESDB and pn.get("class_id") in CLASSESDB,
       f"raça e profissão já vêm sorteadas ({pn.get('race_id')} / {pn.get('class_id')})")
sem = copy.deepcopy(pn); sem.pop("origem_aldeao"); recalc(sem)
com = copy.deepcopy(pn); recalc(com)
print("   status sem → com o bônus:", {k: f"{sem[k]}→{com[k]}" for k in ("hp_max", "atk", "def", "spd", "crit", "acc", "eva", "reg")})
exigir(all(com[k] == int(sem_pre * 1.10) or abs(com[k] - sem[k] * 1.10) <= 1
           for k, sem_pre in ((k, sem[k]) for k in ("hp_max", "atk", "def", "spd", "crit", "acc", "eva", "reg"))),
       "+10% em todos os status")
pn["level"] = 15
SR.save_player_sql(DONO, pn)
CH.trocar_personagem(DONO, 0)
sorteios = {"raca": set(), "classe": set()}
for i in range(60):
    ok_, sl = CH.criar_slot_de_aldeao(DONO, f"Teste{i}", 1)
    if not ok_: break
    CH.trocar_personagem(DONO, sl); q = SR.load_player(DONO)
    sorteios["raca"].add(q["race_id"]); sorteios["classe"].add(q["class_id"])
    CH.trocar_personagem(DONO, 0); CH._remover_do_armario(DONO, sl)
exigir(len(sorteios["classe"]) >= 5 and len(sorteios["raca"]) >= 3,
       f"o sorteio varia ({len(sorteios['classe'])} profissões e {len(sorteios['raca'])} raças em 60 nascimentos)")

# sem slot livre, não promove
reservados = []
while CH.slots_livres(DONO):
    reservados.append(CH.criar_personagem_slot(DONO)[1])
outro = CR.listar_habitantes(DONO)[2]
outro["aura"] = 1
with CR._conn() as c:
    CR._gravar_habitantes(c, DONO, [outro], int(time.time()))
    c.commit()
r = CR.promover_a_personagem(DONO, outro["id"])
exigir(not r["ok"] and "cavaleiro" in r["erro"], "sem slot livre não promove — e a mensagem aponta o cavaleiro")

# ─────────────────────────────────────────── 2. personagem → cavaleiro
r = CR.treinar_cavaleiro(DONO, 0)
exigir(not r["ok"], "o principal não vira cavaleiro")
r = CR.treinar_cavaleiro(DONO, reservados[0])
exigir(not r["ok"] and "nasceu" in r["erro"], "slot que nunca foi jogado não vira cavaleiro")
clan = CR.carregar_clan(DONO)
with CR._conn() as c:     # zera os recursos: o treino tem que recusar
    c.execute("UPDATE clan SET couro = 0, materiais = ? WHERE owner_id = ?", (json.dumps({"1": 0}), DONO))
    c.commit()
r = CR.treinar_cavaleiro(DONO, slot_novo)
exigir(not r["ok"] and "ferro" in r["erro"], "sem ferro e couro não treina")
with CR._conn() as c:
    c.execute("UPDATE clan SET couro = 100, materiais = ? WHERE owner_id = ?", (json.dumps({"1": 100}), DONO))
    c.commit()
r = CR.treinar_cavaleiro(DONO, slot_novo, ouro=CR.ouro_do_treino() - 1)
exigir(not r["ok"] and "soldo" in r["erro"], f"sem ouro pra 1ª semana de soldo não treina ({r.get('erro')})")
CR.sincronizar_com_slots(DONO)      # conta os slots reservados antes de medir
habs_antes = len(CR.listar_habitantes(DONO)); bocas_antes = CR.bocas_do_cla(DONO)
r = CR.treinar_cavaleiro(DONO, slot_novo, ouro=CR.ouro_do_treino())
exigir(r["ok"] and r.get("custo_ouro") == E.SOLDO_CAVALEIRO_DIA * 7,
       f"personagem Nv.15 vira cavaleiro, cobrando {r.get('custo_ouro')} de ouro ({r.get('erro') or 'ok'})")
clan = CR.carregar_clan(DONO)
exigir(clan["materiais"].get(1) == 40 and clan["couro"] == 60, "cobrou 60 de ferro e 40 de couro")
exigir(slot_novo not in [pe["slot"] for pe in CH.listar_personagens_da_conta(DONO)], "saiu da conta")
CR.sincronizar_com_slots(DONO)
exigir(slot_novo not in [m["slot"] for m in CR.listar_membros(DONO)], "saiu da lista de membros do clã")
cav = next(h for h in CR.listar_habitantes(DONO) if h.get("cavaleiro"))
exigir(cav["nivel"] == 15 and cav["aura"] == 4 and cav["talentos"].get("guarda") == 5,
       f"cavaleiro: guarda 5★, nível e aura do personagem (Nv.{cav['nivel']}, aura {cav['aura']})")
exigir(cav["funcao"] == "guarda" and cav["equipe"] == CR.EQUIPE_DA_CIDADE, "entra na guarnição da cidade")
exigir(cav["soldo_ate"] == cav["treino_ate"] + 7 * 86400, "soldo pago por 7 dias a partir do fim do treino")
exigir(CR.bocas_do_cla(DONO) == bocas_antes - 1,
       "🏙️ mora na cidade: o personagem saiu do celeiro e o cavaleiro não entrou (bocas -1)")
exigir(cav not in H.moradores(CR.listar_habitantes(DONO)) and len(CR.listar_habitantes(DONO)) == habs_antes + 1,
       "não ocupa casa na aldeia (fora dos moradores)")

# em treino: não luta, não defende, não sai
exigir(E.poder_do_guarda(cav) == 0, "em treino: poder 0")
d_treino = H.defesa_da_aldeia([cav], 0)
r = CR.montar_equipe(DONO, CR.EQUIPE_DO_PONTO, [], [cav["id"]], 3)
exigir(not r["ok"] and "treinamento" in r["erro"], "em treino não entra em equipe")
r = CR.mudar_habitante(DONO, cav["id"], profissao="agricultor")
exigir(not r["ok"], "cavaleiro não troca de ofício")
r = CR.promover_a_personagem(DONO, cav["id"])
exigir(not r["ok"], "cavaleiro não volta a ser personagem")

# pronto
cav["treino_ate"] = 0
with CR._conn() as c:
    CR._gravar_habitantes(c, DONO, [cav], int(time.time()))
    c.commit()
cav = next(h for h in CR.listar_habitantes(DONO) if h.get("cavaleiro"))
guarda5 = {"nivel": 15, "talentos": {"guarda": 5}, "funcao": "guarda", "equipe": "cidade", "aura": 4}
g1 = dict(guarda5, talentos={"guarda": 1})
exigir(E.poder_do_guarda(cav) >= 10 * E.poder_do_guarda(guarda5),
       f"pronto: ≥10× o guarda 5★ do mesmo nível ({E.poder_do_guarda(cav)} × {E.poder_do_guarda(guarda5)}; "
       f"× 1★: {E.poder_do_guarda(g1)})")
exigir(H.defesa_da_aldeia([cav], 0) - H.defesa_da_aldeia([], 0)
       == 10 * (3 + 15) + H.BONUS_AURA_DEFESA * 4 and d_treino == H.defesa_da_aldeia([], 0),
       "na guarnição: 10 guardas do mesmo nível (+ a aura); em treino não contava")
up_cav = E.manutencao_da_aldeia([cav])
exigir(not any(up_cav.values()), f"não custa recurso da aldeia ({up_cav}) — o custo é o soldo em ouro")

# 💰 sem soldo: parado na cidade
cav["soldo_ate"] = 0
with CR._conn() as c:
    CR._gravar_habitantes(c, DONO, [cav], int(time.time()))
    c.commit()
cav = next(h for h in CR.listar_habitantes(DONO) if h.get("cavaleiro"))
exigir(E.poder_do_guarda(cav) == 0 and H.defesa_da_aldeia([cav], 0) == H.defesa_da_aldeia([], 0),
       "sem soldo: não luta nem defende (fica na cidade)")
r = CR.pagar_soldo(DONO, cav["id"], 3)
exigir(not r["ok"], "soldo só se paga por 1, 7 ou 30 dias")
r = CR.pagar_soldo(DONO, cav["id"], 7)
cav = next(h for h in CR.listar_habitantes(DONO) if h.get("cavaleiro"))
exigir(r["ok"] and r["custo_ouro"] == 7 * E.SOLDO_CAVALEIRO_DIA and abs(cav["soldo_ate"] - (time.time() + 7 * 86400)) < 60,
       f"pagou 7 dias ({r.get('custo_ouro')} de ouro): recomeça de agora, sem cobrar os dias parados")
exigir(E.poder_do_guarda(cav) >= 10 * E.poder_do_guarda(guarda5), "com soldo, volta a lutar")
r = CR.pagar_soldo(DONO, CR.listar_habitantes(DONO)[0]["id"], 7)
exigir(not r["ok"], "aldeão comum não tem soldo")

# ─────────────────────────────────────────── a tabela que decide a troca
print("\nPoder militar (escolta, batalha pelo ponto) — o mesmo personagem, três destinos:")
print("  nível | de guarda (personagem) | guarda 1★ | guarda 5★ | CAVALEIRO | ameaça andar=nível/2 | ameaça andar=nível")
for nv in (10, 20, 40, 80):
    g3 = E.poder_do_guarda({"nivel": nv, "talentos": {"guarda": 1}})
    g5 = E.poder_do_guarda({"nivel": nv, "talentos": {"guarda": 5}})
    ck = E.poder_do_guarda({"nivel": nv, "talentos": {"guarda": 5}, "cavaleiro": "guerreiro", "soldo_ate": 2**40})
    print(f"  {nv:5d} | {poder_do_personagem(nv):22d} | {g3:9d} | {g5:9d} | {ck:9d} | {E.ameaca_do_andar(nv // 2):19d} | {E.ameaca_do_andar(nv)}")
ck20 = E.poder_do_guarda({"nivel": 20, "talentos": {"guarda": 5}, "cavaleiro": "x", "soldo_ate": 2**40})
exigir(ck20 / poder_do_personagem(20) >= 10.0, f"cavaleiro Nv.20 rende ≥10× o personagem de guarda ({ck20 / poder_do_personagem(20):.1f}×)")

print("\n" + ("🟢 CAVALEIRO: TUDO PASSOU" if not falhas else f"🔴 {len(falhas)} FALHA(S)"))
sys.exit(1 if falhas else 0)
