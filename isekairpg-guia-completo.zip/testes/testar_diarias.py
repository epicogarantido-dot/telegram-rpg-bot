#!/usr/bin/env python3
"""📜 Missões diárias e o fim do ouro de monstro (20/09, dev).

- as 4 diárias somam 4.000 de ouro;
- o progresso conta onde a coisa acontece (abate na Torre / na raid,
  vitória na arena, exploração) — conferido nos arquivos que dão o passo;
- resgatar paga uma vez só, e só com a meta batida;
- virar o dia zera progresso E recompensas não resgatadas;
- monstro da Torre e da raid NÃO dão mais ouro; a Travessia e as decisões
  do clã pagam em recurso.
"""
import sys, os, re, random, types

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: None
    sys.modules["aiosqlite"] = falso

from game import diarias as D

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


exigir(D.TOTAL_DO_DIA == 4000, f"as diárias somam {D.TOTAL_DO_DIA}, e não 4.000")
exigir(len(D.DIARIAS) == 4, "não são 4 missões diárias")
contadores = {d["contador"] for d in D.DIARIAS}
exigir({"torre", "raid"} <= contadores, "faltou a diária da Torre ou a da raid")

torre = next(d for d in D.DIARIAS if d["contador"] == "torre")
p = {"gold": 0}
for _ in range(torre["meta"] - 1):
    D.contar(p, "torre")
ok, _msg, _ouro = D.resgatar(p, torre["id"])
exigir(not ok, "pagou sem a meta")
D.contar(p, "torre")
ok, _msg, ouro = D.resgatar(p, torre["id"])
exigir(ok and ouro == torre["ouro"], f"a caçada não pagou {torre['ouro']}: {ouro}")
exigir(not D.resgatar(p, torre["id"])[0], "pagou a mesma diária duas vezes")

# tudo feito = as quatro + o bônus de completar todas
for d in D.DIARIAS:
    for _ in range(d["meta"]):
        D.contar(p, d["contador"])
pago = torre["ouro"]
for d in D.DIARIAS:
    ok, _m, o = D.resgatar(p, d["id"])
    pago += o if ok else 0
ok, _m, o = D.resgatar(p, "bonus")
exigir(ok and pago + o == D.TOTAL_DO_DIA, f"fazer todas pagou {pago + (o if ok else 0)}, e não {D.TOTAL_DO_DIA}")

# virar o dia zera tudo
D.estado(p)["dia"] = "2020-01-01"
st = D.status(p)
exigir(all(m["progresso"] == 0 and not m["resgatada"] for m in st["diarias"]),
       "virar o dia não zerou progresso e recompensas")

# os contadores estão ligados onde a coisa acontece
fontes = {"game/logic.py": ('"torre"', '"raid"'), "game/arena.py": ('"arena"',),
          "webapp/api.py": ('"clan_explorar"',)}
for arq, chaves in fontes.items():
    texto = open(os.path.join(RAIZ, arq), encoding="utf-8").read()
    for chave in chaves:
        exigir(chave in texto and "diarias" in texto, f"{arq} não marca a diária {chave}")

# monstro não paga mais ouro
logic = open(os.path.join(RAIZ, "game", "logic.py"), encoding="utf-8").read()
exigir("reward_gold = 0" in logic, "o abate ainda soma ouro no jogador")
exigir("p['gold'] += reward_gold" not in logic and 'p["gold"] += reward_gold' not in logic,
       "sobrou soma de ouro por abate")

# travessia paga mantimento, não ouro
from game import clan_jornada as J
f = {"hp_max": 100, "atk": 10, "def": 1, "acc": 10, "eva": 0, "crit": 0}
t = J.nova_travessia(4, 5, [J.lutador(0, "L", f)], 30, random.Random(1))
t["espolio_couro"] = 10
t["fim"] = "sucesso"
r = J.resultado_final(t)
exigir("ouro" not in r and r.get("couro", 0) >= 10, f"a travessia ainda paga ouro: {r}")

# decisões do clã: nenhum efeito "ouro" sobrou no conteúdo
for raiz, _d, arqs in os.walk(os.path.join(RAIZ, "game", "conteudo")):
    for a in arqs:
        if a.endswith(".json"):
            texto = open(os.path.join(raiz, a), encoding="utf-8").read()
            exigir(not re.search(r'"ouro"\s*:', texto), f"{a} ainda dá ouro numa decisão")

if falhas:
    print("❌ DIÁRIAS COM PROBLEMA")
    for f_ in falhas:
        print("  -", f_)
    sys.exit(1)
print("✅ diárias: 4 missões = 4.000g, contadores ligados, paga uma vez, o dia zera; "
      "monstro, travessia e decisões não dão mais ouro")
