const fs=require('fs');
// ⚠️ Caminhos derivados deste arquivo, nunca absolutos. Teste com o caminho
// da máquina de quem escreveu não passa em lugar nenhum — nem no servidor —
// e vira rede que não pega nada. É a armadilha nº 11 do projeto.
const path = require('path');
const RAIZ = path.dirname(__dirname);

const codigo=fs.readFileSync(path.join(RAIZ,'webapp/static/app.js'),'utf8');
const html=fs.readFileSync(path.join(RAIZ,'webapp/static/index.html'),'utf8');
let falhou=false; const ok=t=>console.log('  ✅ '+t); const nok=(t,e='')=>{console.log('  ❌ '+t+' '+e);falhou=true};
class E{constructor(t='div'){this.tagName=t;this.children=[];this.style={setProperty(){},removeProperty(){}};this._txt='';this.dataset={};
 this.classList={_s:new Set(),add(...c){c.forEach(x=>this._s.add(x))},remove(...c){c.forEach(x=>this._s.delete(x))},
 toggle(c,f){f===undefined?(this._s.has(c)?this._s.delete(c):this._s.add(c)):(f?this._s.add(c):this._s.delete(c))},contains(c){return this._s.has(c)}};
 this.value='';this.id='';this.className='';this.src='';this.disabled=false;}
 get textContent(){return this._txt} set textContent(v){this._txt=String(v)}
 get innerHTML(){return this._txt} set innerHTML(v){this._txt=String(v);this.children=[]}
 appendChild(c){this.children.push(c);return c} append(...c){c.forEach(x=>this.children.push(x))}
 remove(){} addEventListener(){} removeEventListener(){} setAttribute(){} focus(){} insertBefore(c){this.children.unshift(c)}
 scrollTo(){} get scrollLeft(){return 0} get clientWidth(){return 360}
 querySelector(){return new E()} querySelectorAll(){return this._abas||[]}
 getBoundingClientRect(){return{top:0,left:0,width:0,height:0}}
 todos(p,a=[]){if(p(this))a.push(this);this.children.forEach(c=>c.todos&&c.todos(p,a));return a}}
const porId={};['tela-carregando','app','conteudo','sheet-overlay','sheet-corpo','badge-avisos','btn-avisos','retrato-mini','drawer-lista'].forEach(i=>porId[i]=new E());
porId['barra-abas']=new E();
porId['barra-abas']._abas=['mundo','cidade','personagem','clan','mais'].map(g=>{const b=new E('button');b.dataset.grupo=g;return b});
const guardado={iso_token:'T'};
global.window=global;
global.document={getElementById:i=>porId[i]||(porId[i]=new E()),querySelector:()=>new E(),querySelectorAll:()=>[],
 createElement:t=>new E(t),createTextNode:t=>{const e=new E('#text');e.textContent=t;return e},addEventListener(){},removeEventListener(){},
 body:new E('body'),head:new E('head'),documentElement:new E('html'),readyState:'complete',getElementsByClassName:()=>[],getElementsByTagName:()=>[]};
global.navigator={userAgent:'node',vibrate(){},language:'pt-BR'};
global.location={href:'',search:'',hash:'',reload(){},origin:'http://x'};
global.localStorage={getItem:k=>(k in guardado?guardado[k]:null),setItem:(k,v)=>{guardado[k]=String(v)},removeItem:k=>{delete guardado[k]}};
global.fetch=async()=>({ok:true,status:200,json:async()=>({}),text:async()=>''});
global.Telegram=undefined;
global.AudioContext=function(){return{createOscillator:()=>({connect(){},start(){},stop(){},frequency:{setValueAtTime(){},value:0},type:''}),
 createGain:()=>({connect(){},gain:{setValueAtTime(){},linearRampToValueAtTime(){},exponentialRampToValueAtTime(){},value:0}}),
 createBuffer:()=>({getChannelData:()=>new Float32Array(8)}),createBufferSource:()=>({connect(){},start(){},stop(){},buffer:null,loop:false}),
 destination:{},currentTime:0,resume(){},state:'running',close(){}}};
global.webkitAudioContext=global.AudioContext;
global.requestAnimationFrame=f=>setTimeout(f,0);global.cancelAnimationFrame=()=>{};global.setInterval=()=>0;
global.alert=()=>{};global.confirm=()=>true;global.CustomEvent=function(){};
global.MutationObserver=function(){return{observe(){},disconnect(){}}};
global.IntersectionObserver=function(){return{observe(){},disconnect(){},unobserve(){}}};
global.addEventListener=()=>{};global.removeEventListener=()=>{};
(async()=>{
  /btn-menu|☰/.test(html) ? nok('o sanduíche ainda está no HTML') : ok('o ☰ saiu do header');
  const botoes=(html.match(/data-grupo="/g)||[]).length;
  botoes===5 ? ok('5 botões de grupo na barra de baixo') : nok('esperava 5 grupos, achei '+botoes);

  const M=new Function(codigo+'; return {GRUPOS_MENU, GRUPO_DA_TELA, TELAS_DA_CIDADE, TELAS, gradeDeCaminhos, FORA_DA_CIDADE};')();
  const ordem=M.GRUPOS_MENU.map(g=>g.id).join(',');
  ordem==='mundo,cidade,personagem,clan,mais' ? ok('ordem: Mundo → Cidade → Você → Clã → Mais') : nok('ordem errada: '+ordem);

  // toda tela do menu tem renderizador
  const semRender=M.GRUPOS_MENU.flatMap(g=>g.telas).filter(t=>!M.TELAS[t.tela]).map(t=>t.tela);
  semRender.length ? nok('tela no menu sem renderizador', semRender.join(',')) : ok('todas as telas do menu existem de verdade');

  // nenhuma tela em dois grupos
  const todas=M.GRUPOS_MENU.flatMap(g=>g.telas.map(t=>t.tela));
  const dup=todas.filter((t,i)=>todas.indexOf(t)!==i);
  dup.length ? nok('tela repetida em dois grupos', dup.join(',')) : ok(`${todas.length} telas, nenhuma em dois grupos`);

  // o grupo Cidade é exatamente o que o servidor tranca
  const cid=[...M.TELAS_DA_CIDADE].sort().join(',');
  // loja_premium entrou em 18/09: é tela própria, mas come do mesmo
  // /api/shop, que já é trancado por _exigir_cidade no servidor.
  cid==='engaste,estabulo,forja,fusao,gacha,hospital,loja,loja_premium,mercado'
    ? ok('grupo Cidade = os 9 serviços que o servidor exige estar na cidade')
    : nok('grupo Cidade não bate com o portão do servidor: '+cid);

  // toda tela conhecida cai em algum grupo
  const orfas=Object.keys(M.TELAS).filter(t=>!M.GRUPO_DA_TELA[t]&&t!=='cidade'&&t!=='ajuda');
  orfas.length ? console.log('  ⚠️ telas fora dos grupos (só por link direto):', orfas.join(', '))
               : ok('nenhuma tela ficou órfã');
  // a navegação agora é GRADE no fim da página, não folha
  global.som={clique(){},erro(){},moeda(){}};
  const grade = M.gradeDeCaminhos('clan');
  if(!grade){nok('gradeDeCaminhos não devolveu nada pra uma tela de grupo');}
  else {
    const itens = grade.todos(n=>n.tagName==='button');
    const grupoClan = M.GRUPOS_MENU.find(g=>g.id==='clan');
    itens.length===grupoClan.telas.length
      ? ok(`a grade traz os ${itens.length} caminhos irmãos da seção`)
      : nok(`esperava ${grupoClan.telas.length} caminhos, achei ${itens.length}`);
    const atuais = itens.filter(n=>/(^| )atual( |$)/.test(n.className));
    atuais.length===1 ? ok('exatamente 1 marcado como "você está aqui"') : nok(`marcados: ${atuais.length}`);
    atuais[0] && atuais[0].disabled ? ok('e ele está desabilitado — botão que leva pra onde você já está é ruído')
                                    : nok('o atual continua clicável');
    const outros = itens.filter(n=>!/(^| )atual( |$)/.test(n.className));
    outros.every(n=>typeof n.onclick==='function') ? ok('os outros navegam ao toque') : nok('caminho sem ação');
    const imgs = grade.todos(n=>n.tagName==='img');
    imgs.length ? nok(`a grade desenha ${imgs.length} imagem(ns)`) : ok('grade sem imagem — é texto, e texto se lê mais rápido');
  }
  const semGrupo = M.gradeDeCaminhos('nao_existe');
  semGrupo===null ? ok('tela fora de grupo não ganha grade em vez de quebrar') : nok('grade em tela sem grupo');

  // abrirGrupo não pode ter voltado
  /function abrirGrupo\s*\(/.test(codigo) ? nok('abrirGrupo ainda existe') : ok('a folha antiga foi removida junto');

  // trilhas está no grupo do personagem
  const temTrilhas = M.GRUPOS_MENU.find(g=>g.id==='personagem').telas.some(t=>t.tela==='trilhas');
  temTrilhas ? ok('Trilhas aparece no grupo Você') : nok('Trilhas não está em nenhum grupo');
  M.TELAS['trilhas'] ? ok('a tela de Trilhas existe de verdade') : nok('renderTrilhas não registrado');

  console.log(falhou?'\n❌ ALGO FALHOU':'\n🟢 MENU EM LISTA + TRILHAS: TUDO PASSOU');
  process.exit(falhou?1:0);
})();
