#!/usr/bin/env python3
"""O backup restaura — inclusive de um banco que está sendo escrito.

POR QUE ESTE TESTE EXISTE
-------------------------
O zip de deploy nunca leva `data/`. Isso é a regra certa (subir o banco
sobrescreveria o de produção), mas a consequência é que jogadores, itens,
clãs, as artes espelhadas e, principalmente, as CARTEIRAS DE ⭐ existem num
lugar só: o disco do servidor.

Backup que não restaura é pior que não ter backup — dá a sensação de estar
protegido. E o jeito errado de fazer é sedutor: `shutil.copy` do .db é uma
linha e parece funcionar. SQLite em uso tem escrita em andamento e WAL à
parte; a cópia crua vem sem as últimas transações ou corrompida, e isso só
aparece no dia de restaurar, que é a pior hora possível.

Por isso o teste não confere só "o zip tem os arquivos". Ele abre o banco
restaurado e LÊ os dados de volta, com escrita acontecendo durante o
backup.
"""
import os
import shutil
import sqlite3
import sys
import tempfile
import threading
import time
import zipfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

falhou = 0


def checar(nome, cond, det=""):
    global falhou
    print(("  ✅ " if cond else "  ❌ ") + nome + ("" if cond else f"  -> {det}"))
    if not cond:
        falhou = 1


base = tempfile.mkdtemp(prefix="backup_teste_")
os.chdir(base)
os.makedirs("data/imagens", exist_ok=True)
os.makedirs("data/comprovantes", exist_ok=True)

from webapp import backup as B  # noqa: E402


def semear(nome, linhas):
    caminho = os.path.join("data", nome)
    conn = sqlite3.connect(caminho)
    conn.execute("CREATE TABLE IF NOT EXISTS t (id INTEGER PRIMARY KEY, v TEXT)")
    conn.executemany("INSERT INTO t (id, v) VALUES (?,?)",
                     [(i, f"valor-{i}") for i in range(linhas)])
    conn.commit()
    conn.close()


print("1. monta um data/ de mentira")
semear("game.db", 500)
semear("premium.db", 40)
semear("player_ids.db", 40)
for i in range(7):
    open(f"data/imagens/ARTE_{i}.jpg", "wb").write(b"\xff\xd8" + bytes(300))
open("data/comprovantes/pix_1.jpg", "wb").write(b"\xff\xd8" + bytes(120))

inv = B.inventario()
checar("o inventário acha os 3 bancos e as 2 pastas", len(inv["itens"]) == 5, inv["itens"])
checar("conta as 7 imagens",
       any(i["nome"] == "imagens" and i["arquivos"] == 7 for i in inv["itens"]),
       inv["itens"])
checar("soma bytes > 0", inv["bytes_total"] > 0, inv["bytes_total"])

print("\n2. o snapshot é consistente COM ESCRITA ACONTECENDO")
# É aqui que a cópia crua falharia. Uma thread martela o banco enquanto o
# backup roda; o restaurado tem que abrir e conferir a integridade.
parar = threading.Event()


def escrever():
    conn = sqlite3.connect("data/game.db", timeout=30)
    i = 10000
    while not parar.is_set():
        try:
            conn.execute("INSERT INTO t (id, v) VALUES (?,?)", (i, f"quente-{i}"))
            conn.commit()
            i += 1
        except sqlite3.Error:
            pass
        time.sleep(0.001)
    conn.close()


t = threading.Thread(target=escrever, daemon=True)
t.start()
time.sleep(0.15)
caminho_zip = B.montar_backup(incluir_imagens=True, incluir_comprovantes=True)
parar.set()
t.join(timeout=5)
checar("o zip foi criado", os.path.exists(caminho_zip) and os.path.getsize(caminho_zip) > 0)

print("\n3. restaura num lugar limpo e LÊ os dados de volta")
destino = tempfile.mkdtemp(prefix="restaurado_")
with zipfile.ZipFile(caminho_zip) as z:
    nomes = z.namelist()
    z.extractall(destino)

for nome in ("data/game.db", "data/premium.db", "data/player_ids.db"):
    checar(f"{nome} está no zip", nome in nomes)
checar("as 7 imagens estão no zip",
       len([n for n in nomes if n.startswith("data/imagens/")]) == 7,
       [n for n in nomes if n.startswith("data/imagens/")])
checar("o comprovante está no zip", "data/comprovantes/pix_1.jpg" in nomes)
checar("tem LEIA-ME com o passo a passo de restaurar", "LEIA-ME.txt" in nomes)

for nome, esperado in (("game.db", 500), ("premium.db", 40), ("player_ids.db", 40)):
    caminho = os.path.join(destino, "data", nome)
    try:
        conn = sqlite3.connect(caminho)
        integridade = conn.execute("PRAGMA integrity_check").fetchone()[0]
        linhas = conn.execute("SELECT COUNT(*) FROM t").fetchone()[0]
        amostra = conn.execute("SELECT v FROM t WHERE id = 7").fetchone()
        conn.close()
    except sqlite3.Error as e:
        checar(f"{nome}: abre", False, str(e))
        continue
    checar(f"{nome}: integrity_check = ok", integridade == "ok", integridade)
    checar(f"{nome}: tem ao menos as {esperado} linhas semeadas",
           linhas >= esperado, linhas)
    checar(f"{nome}: o dado volta legível", amostra and amostra[0] == "valor-7", amostra)

print("\n4. dá pra deixar as imagens de fora (o zip fica pequeno pro 4G)")
zip_leve = B.montar_backup(incluir_imagens=False, incluir_comprovantes=False)
with zipfile.ZipFile(zip_leve) as z:
    nomes_leve = z.namelist()
checar("sem imagens", not [n for n in nomes_leve if n.startswith("data/imagens/")])
checar("sem comprovantes", not [n for n in nomes_leve if n.startswith("data/comprovantes/")])
checar("mas COM os bancos — o que não dá pra recriar",
       all(f"data/{n}" in nomes_leve for n in B.BANCOS), nomes_leve)
checar("e é menor que o completo",
       os.path.getsize(zip_leve) < os.path.getsize(caminho_zip),
       (os.path.getsize(zip_leve), os.path.getsize(caminho_zip)))

print("\n5. banco faltando não derruba o backup")
os.remove("data/premium.db")
try:
    z3 = B.montar_backup(incluir_imagens=False, incluir_comprovantes=False)
    with zipfile.ZipFile(z3) as z:
        leiame = z.read("LEIA-ME.txt").decode("utf-8")
    checar("monta mesmo assim", True)
    checar("e o LEIA-ME avisa o que faltou", "NÃO EXISTIA" in leiame,
           [l for l in leiame.splitlines() if "premium" in l])
    os.remove(z3)
except Exception as e:
    checar("monta mesmo assim", False, f"{type(e).__name__}: {e}")

for f in (caminho_zip, zip_leve):
    if os.path.exists(f):
        os.remove(f)
shutil.rmtree(destino, ignore_errors=True)

print("\n6. a faxina apaga zip velho e poupa o novo")
# A limpeza roda na ENTRADA do backup. Se ela apagasse pelo nome sem olhar
# a idade, apagaria o zip que acabou de ser gerado — e o download baixaria
# um arquivo que não existe mais.
import tempfile as _tmp
velho = os.path.join(_tmp.gettempdir(), B.PREFIXO_TEMP + "antigo.zip")
open(velho, "wb").write(b"lixo")
os.utime(velho, (time.time() - B.IDADE_MAXIMA_TEMP - 60,) * 2)
novo = B.montar_backup(incluir_imagens=False, incluir_comprovantes=False)
checar("o zip velho foi apagado", not os.path.exists(velho))
checar("o zip recém-criado sobreviveu", os.path.exists(novo))
checar("e ainda abre", zipfile.is_zipfile(novo))
os.remove(novo)

print("\n" + ("🟢 BACKUP: TUDO PASSOU" if not falhou else "❌ BACKUP: FALHOU"))
sys.exit(falhou)
