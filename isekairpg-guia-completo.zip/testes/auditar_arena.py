#!/usr/bin/env python3
"""Auditoria da Arena PvP: a tela e a rota falam a mesma língua?

POR QUE ESTE TESTE EXISTE
-------------------------
Em 20/09 a tela da Arena passou a usar o MESMO desenho da batalha da
Torre: retratos, barra de ATB, fila de turnos. Isso criou uma dependência
nova e silenciosa — a tela lê campos (`img_key`, `spd`, `bar`, `escudo`)
que só existem porque `_montar_snapshot_arena` passou a mandá-los.

Se alguém mexer na rota e tirar um deles, nada estoura: `undefined` vira
barra em 0%, retrato vazio e fila sem ordem. A luta continua funcionando
e fica errada — que é exatamente o tipo de falha que este projeto já
pagou caro várias vezes (o efeito de raridade que nunca apareceu, a
coluna `diario` que ninguém escrevia).

E a outra ponta: campo que a rota manda e a tela não lê é peso morto no
JSON de toda ação de combate.
"""
import sys, os, re

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


api = open(os.path.join(RAIZ, "webapp", "api.py"), encoding="utf-8").read()
app_js = open(os.path.join(RAIZ, "webapp", "static", "app.js"), encoding="utf-8").read()
arena_py = open(os.path.join(RAIZ, "game", "arena.py"), encoding="utf-8").read()

# ── 1) O que a rota manda em cada lado do duelo ──────────────────────────
inicio = api.index("def _montar_snapshot_arena(")
corpo_rota = api[inicio:api.index("@app.get(\"/api/arena\")", inicio)]
bloco_lado = corpo_rota[corpo_rota.index("def lado(e):"):corpo_rota.index("resultado[\"voce\"]")]
campos_enviados = set(re.findall(r'"([a-z_]+)":', bloco_lado))

# ── 2) O que a tela lê de cada lado ──────────────────────────────────────
inicio_tela = app_js.index("function ladoDoDuelo(")
corpo_tela = app_js[inicio_tela:app_js.index("\n}", app_js.index("return caixa;", inicio_tela))]
campos_lidos = set(re.findall(r"lutador\.([a-z_]+)", corpo_tela))
# a fila de turnos, logo acima, lê direto do snapshot
campos_lidos |= {"bar", "spd", "img_key", "nome"}

for campo in sorted(campos_lidos):
    exigir(campo in campos_enviados,
           f"a tela da Arena lê '{campo}' e a rota não manda — vira undefined "
           "em silêncio (barra em 0, retrato vazio)")

for campo in sorted(campos_enviados - campos_lidos - {"nome"}):
    exigir(False, f"a rota manda '{campo}' e ninguém lê — peso morto no JSON "
                  "de toda ação de combate")

# ── 3) O retrato do adversário existe e não depende de schema novo ───────
exigir("_arte_do_oponente" in arena_py,
       "a Arena perdeu a resolução do retrato do adversário")
exigir("resolver_asset_key_jogador" in arena_py,
       "o retrato da Arena não usa mais a regra de raça e sexo do resto do jogo")
# A tabela arena_snapshots não tem coluna de raça/sexo, e criar uma exigiria
# migração (armadilha nº 14). O retrato sai do personagem vivo.
exigir("load_player" in arena_py,
       "o retrato do adversário voltou a depender do snapshot — que não guarda "
       "raça nem sexo, e acrescentar coluna lá pede migração")
exigir("ALTER TABLE arena_snapshots" not in arena_py,
       "alguém acrescentou coluna em arena_snapshots sem migração")

# ── 4) A tela usa os blocos da Torre, não um desenho paralelo ────────────
# A ficha de cada lado vive em `ladoDoDuelo`, logo abaixo — as duas
# contam como "a tela da Arena".
tela_arena = app_js[app_js.index("function desenharArenaCombate("):
                    app_js.index("let ARENA_ESTADO_ANTERIOR")] + corpo_tela
for bloco in ("tituloDaLuta", "combate-vs", "filaIniciativa", "log-combate",
              "combate-acoes", "barra-atb"):
    exigir(bloco in tela_arena,
           f"a Arena parou de usar '{bloco}' — o desenho voltou a ser só dela")

if falhas:
    print("❌ ARENA PVP COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print(f"✅ Arena PvP: {len(campos_lidos)} campos casam entre rota e tela, "
      "e a luta usa os blocos da Torre")
