#!/usr/bin/env python3
"""Auditoria do laço da comida.

POR QUE ESTE TESTE EXISTE
-------------------------
Durante meses `comida` foi um número que só subia: nada consumia, `fome`
nunca era escrita por ninguém, e `teto_comida` estava declarado na tabela
de comodidades sem ser lido em lugar NENHUM do projeto — o jogador pagava
60 de material pelo Celeiro e recebia zero. O laço não fechava.

As perguntas que este auditor faz, e que pegaram o bug:

1. A ração cabe na renda? Existe configuração sustentável e existe
   configuração que cobra caro? Se todas fossem sustentáveis, a comida
   voltaria a ser enfeite; se nenhuma fosse, o jogo seria fome eterna.
2. A fome MORDE? Ela muda a chance de morte em alguma combinação real de
   (área, nível), ou é só um número vermelho na tela?
3. Existe saída? Um clã sem comida e sem ouro consegue se recuperar, ou
   a fome é espiral sem fundo — que com morte permanente é armadilha?
4. O Celeiro faz alguma coisa?
"""
import sys, os, random, statistics
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    import aiosqlite  # noqa: F401
except ImportError:
    print("⚠️  aiosqlite não instalado — rode no servidor, onde ele existe.")
    sys.exit(2)

from game.clan_afk import rodar_tick, montar_perfil
from game.clan_repo import (TETO_TICKS, TETO_ENCONTROS, RACAO_TICKS, FOME_MAX,
                            areas_disponiveis, penalizar_modelo)
from game.clan_materiais import teto_de_comida
from game import clan_repo as _CR

REPETICOES = 300
problemas, avisos = [], []


def grupo_forte(andar):
    """Perfil de quem vence tudo na área — isola a renda do risco."""
    return {"encontros": [{"andar": andar + i, "resultado": "vence",
                           "peso": 4 if (andar + i) % 5 else 1,
                           "chefe": (andar + i) % 5 == 0} for i in range(5)],
            "chance_morte": 0.0, "resumo": "forte"}


def sessao(uso, rng, ticks=TETO_TICKS):
    """Renda de uma sessão. `uso` é uma lista de (área, nº de membros)."""
    comida = ouro = 0
    for area, _n in uso:
        grupo = grupo_forte(int(area["andar"]))
        encontros = 0
        for _ in range(ticks):
            ev = rodar_tick(grupo, area, rng)
            if ev["tipo"] == "monstro":
                if encontros >= TETO_ENCONTROS:
                    continue
                encontros += 1
            if ev.get("recurso") and area["recurso"] == "comida":
                comida += int(ev["recurso"])
            if ev["tipo"] == "recurso" or ev.get("resultado") == "vence":
                # 🥇 20/09: a mesma regra de `clan_repo.rodar_afk` — era o
                # bronze da sessão, virou o ouro da sessão.
                ouro += max(1, int(area["andar"]) // 3)
    postados = sum(n for _a, n in uso)
    return {"comida": comida, "ouro": ouro,
            "racao": (ticks // RACAO_TICKS) * postados}


def modelo(nivel, equip=0):
    return {"telegram_id": 1, "level": int(nivel), "xp": 0, "xp_next": 9**9,
            "gold": 0, "tower_floor": 1, "hp": 100, "hp_max": 100, "state": "TOWER",
            "class_id": None, "race_id": None,
            "attrs": {k: int(nivel) + int(equip) for k in ("str", "vit", "agi", "dex")},
            "trails": {}, "combat": None,
            "inv": {"potion": 0, "cores": {}, "items": {}}, "equip": {},
            "pets": {"owned": {}, "deck": [None] * 5},
            "skills_learned": {}, "skill_slots": {"equipped": [None] * 5}, "chakra": None}


print("=" * 78)
print(f"AUDITORIA DO LAÇO DA COMIDA — 1 ração por membro postado a cada "
      f"{RACAO_TICKS} ticks")
print(f"(sessão cheia de {TETO_TICKS} ticks = {TETO_TICKS // RACAO_TICKS} por membro)")
print("=" * 78)

rng = random.Random(11)
areas = areas_disponiveis(50)
de_comida = [a for a in areas.values() if a["recurso"] == "comida"]
# A melhor área que alimenta — é nela que o jogador posta quem colhe.
MELHOR_COMIDA = max([a for a in areas.values() if a["recurso"] == "comida"],
                    key=lambda a: a["rende"])
A1, A11, A26 = MELHOR_COMIDA, areas["andar11"], areas["andar26"]

print(f"\náreas que alimentam: {len(de_comida)} de {len(areas)} "
      f"-> {[a['nome'] for a in de_comida]}")
if len(de_comida) <= 1:
    problemas.append(f"só {len(de_comida)} área alimenta o clã inteiro — a renda de comida "
                     f"fica travada num teto que não cresce, e alimentar deixa de ser "
                     f"decisão de onde postar")

# ------------------------------------------------- 1. a ração cabe na renda?
CENARIOS = [
    (f"1 postado, na comida ({A1['nome']})",  [(A1, 1)]),
    ("3 postados, 1 na comida",           [(A1, 1), (A11, 2)]),
    ("3 postados, nenhum na comida",      [(A11, 3)]),
    ("5 postados, 1 na comida",           [(A1, 1), (A26, 4)]),
    ("5 postados, nenhum na comida",      [(A26, 5)]),
]
# 🥇 20/09: o déficit se cobre COMPRANDO comida com ouro na Aldeia
# (`clan_repo.custo_comida`), em vez do antigo serviço "mantimentos" em bronze.
from game.clan_repo import custo_comida
print(f"\n{'cenário':<34}{'comida':>8}{'ração':>7}{'saldo':>8}{'💰':>7}{'déficit custa':>16}")
sustentaveis = 0
for nome, uso in CENARIOS:
    r = [sessao(uso, rng) for _ in range(REPETICOES)]
    c = statistics.mean(x["comida"] for x in r)
    b = statistics.mean(x["ouro"] for x in r)
    ra = r[0]["racao"]
    saldo = c - ra
    if saldo >= 0:
        sustentaveis += 1
        print(f"{nome:<34}{c:>8.0f}{ra:>7}{saldo:>+8.0f}{b:>7.0f}{'—':>16}")
        continue
    custo = custo_comida(int(-saldo))
    fatia = custo / b * 100 if b else 999
    print(f"{nome:<34}{c:>8.0f}{ra:>7}{saldo:>+8.0f}{b:>7.0f}{custo:>11.0f}g ({fatia:>3.0f}%)")
    if fatia > 100:
        problemas.append(f"'{nome}': cobrir o déficit custa mais ouro do que a "
                         f"sessão rende — é fome sem saída, não decisão")
    elif fatia < 3:
        avisos.append(f"'{nome}': o déficit custa {fatia:.0f}% do ouro da sessão — "
                      f"quase de graça, a decisão some")

if sustentaveis == 0:
    problemas.append("nenhuma configuração é sustentável — o clã vive em fome, "
                     "e fome que não dá pra evitar é imposto, não escolha")
if sustentaveis == len(CENARIOS):
    problemas.append("toda configuração é sustentável — a comida volta a ser "
                     "número que só sobe, e o Celeiro não tem razão de existir")

# ------------------------------------------------------------ 2. ela morde?
print(f"\n{'área':>10}{'nível':>7}{'morte alimentado':>19}{'morte faminto':>16}{'delta':>9}")
mordeu = 0
casos = 0
for area in (areas["andar1"], areas["andar7"], areas["andar11"], areas["andar16"]):
    for nivel in (10, 20, 30, 45):
        base = montar_perfil(modelo(nivel), area)["chance_morte"]
        faminto = montar_perfil(
            penalizar_modelo(modelo(nivel), {"fome": FOME_MAX, "ferimento": 0}),
            area)["chance_morte"]
        casos += 1
        if faminto - base > 0.01:
            mordeu += 1
        print(f"{area['nome']:>10}{nivel:>7}{base:>18.1f}%{faminto:>15.1f}%{faminto-base:>+8.1f}")
print(f"\nfome mudou a chance de morte em {mordeu} de {casos} combinações")
if mordeu == 0:
    problemas.append("fome no teto não muda a chance de morte em nenhuma combinação "
                     "testada — continua sendo enfeite")
elif mordeu == casos:
    avisos.append("fome muda TODAS as combinações — se ela pesa até onde o membro "
                  "estava folgado, vira imposto em vez de fronteira")

# --------------------------------------------------------- 3. existe saída?
# A regra: quem NÃO está em posto não come e recupera 1 de fome por sessão.
# Sem ela, um clã sem comida e sem ouro não teria como voltar.
saidas = []
# 🥇 20/09: a saída comprada virou "comprar comida com ouro" (e a compra
# automática). Confere que a função existe de verdade, não só o texto.
if callable(getattr(_CR, "comprar_comida", None)) and _CR.custo_comida(1) > 0:
    saidas.append("comprar comida com ouro na aldeia (ou a compra automática)")
saidas.append("recolher o pessoal (quem não está em posto não come e se recupera)")
if de_comida:
    saidas.append("mandar alguém pro andar raso")
print(f"\nsaídas pra um clã faminto: {len(saidas)}")
for s in saidas:
    print("   ·", s)
if len(saidas) < 2:
    problemas.append("fome com menos de duas saídas é espiral — com morte permanente, "
                     "isso é armadilha e não aposta")

# --------------------------------------------------- 4. o Celeiro faz algo?
sem = teto_de_comida({}, 5)
com = teto_de_comida({"celeiro": True}, 5)
consumo_5 = (TETO_TICKS // RACAO_TICKS) * 5
print(f"\nteto de comida: {sem} sem Celeiro, {com} com ele")
print(f"um clã de 5 postados come {consumo_5} por sessão -> "
      f"{sem/consumo_5:.1f} sessões de folga sem Celeiro, {com/consumo_5:.1f} com ele")
if com <= sem:
    problemas.append("o Celeiro não aumenta o teto de comida — é material jogado fora")
elif (com - sem) < consumo_5:
    avisos.append("o Celeiro não chega a cobrir uma sessão de consumo do clã cheio")
if sem < consumo_5:
    problemas.append(f"o teto base ({sem}) não cobre nem uma sessão de consumo "
                     f"({consumo_5}) — o estoque nunca serve pra nada")

print(f"\n❌ PROBLEMAS: {len(problemas)}")
for x in problemas: print("   ", x)
print(f"\n⚠️  AVISOS: {len(avisos)}")
for x in avisos: print("   ", x)
print()
print("🟢 o laço da comida fecha" if not problemas else "❌ o laço não fecha")
sys.exit(0 if not problemas else 1)
