#!/usr/bin/env python3
"""Auditoria da TRAVESSIA do clã, por simulação (20/09, 2ª versão).

POR QUE EXISTE
--------------
O dev achou a 1ª jornada irreal (cada perigo era um sorteio só, e dava pra
ir a qualquer andar). A travessia nova é batalha atrás de batalha contra o
relógio, com REFORÇO quando a batalha não termina no limite, e só pro andar
seguinte. Medindo a primeira montagem dela, dois defeitos apareceram — e é
exatamente o que este teste trava:
- com os números crus da Torre (feitos pro personagem inteiro, com
  equipamento e skills), do andar 20 em diante o clã não vencia UMA
  batalha: sobrevivia no relógio, o contrário do pedido;
- com reforço fixo de 1, um grupo fraco também passava só apanhando devagar.

As propriedades, medidas com o MESMO modelo de lutador do AFK:
- o grupo "no ponto" (nível 2× o andar) atravessa quase sempre E vence
  batalhas no caminho — em todo andar, raso ou fundo;
- o grupo na metade do ponto não atravessa;
- decidir importa: jogar esperto (tática + comer na hora) fere menos que
  ficar parado no "normal";
- nenhuma travessia é infinita;
- o único destino é o andar seguinte, e só se o jogador já chegou nele.
"""
import sys, os, types, random, statistics

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

import game.logic as L
from game import clan_jornada as T

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


def ficha(nivel, equip=0):
    p = {"telegram_id": 1, "level": nivel, "xp": 0, "xp_next": 9 ** 9, "gold": 0, "tower_floor": 1,
         "hp": 100, "hp_max": 100, "state": "TOWER", "class_id": None, "race_id": None,
         "attrs": {k: nivel + equip for k in ("str", "vit", "agi", "dex")}, "trails": {},
         "combat": None, "inv": {"potion": 0, "cores": {}, "items": {}}, "equip": {},
         "pets": {"owned": {}, "deck": [None] * 5}, "skills_learned": {},
         "skill_slots": {"equipped": [None] * 5}, "chakra": None}
    L.recalc(p)
    return p


def politica(t, estilo):
    """"esperto": defende por padrão e só aperta (ofensiva) quando o limite
    da batalha vai estourar ou o chefe está em campo; come quando o grupo
    está baixo. É o jogador que olha o contador de turnos."""
    if estilo != "esperto":
        return
    vivos = T.de_pe(t)
    media = statistics.mean(m["hp"] / m["hp_max"] for m in vivos)
    if media < 0.45 and t["comida"] >= T.CUSTO_REFEICAO * len(vivos) + 2 * len(vivos):
        T.comer(t)
    apertar = t["inimigos"] and (t["turno_da_batalha"] >= T.LIMITE_BATALHA - 2
                                 or any(e["tipo"] == "boss" for e in t["inimigos"]))
    T.mudar_tatica(t, "ofensiva" if apertar else "defensiva")


def rodar(nivel, destino, estilo="esperto", N=80, semente=1):
    rng = random.Random(semente)
    f = ficha(nivel)
    ok, fer, bat, voltas = 0, [], [], 0
    for _ in range(N):
        t = T.nova_travessia(destino - 1, destino, [T.lutador(i, f"L{i}", f) for i in range(5)],
                             T.comida_maxima(destino, 5), rng)
        n = 0
        while not t["fim"] and n < 2000:
            n += 1
            politica(t, estilo)
            T.avancar(t, rng, 1)
        voltas = max(voltas, n)
        r = T.resultado_final(t)
        ok += r["chegou"]
        fer.append(sum(r["ferimentos"].values()))
        bat.append(r["batalhas"])
    return ok / N, statistics.mean(fer), statistics.mean(bat), voltas


print(f"{'destino':>8} {'grupo':>10} {'chega':>6} {'ferim.':>7} {'batalhas':>9}")
for destino in (3, 9, 10, 21, 30, 41, 50):
    s_ref, f_ref, b_ref, v1 = rodar(2 * destino, destino)
    s_meio, _, _, v2 = rodar(destino, destino)
    s_par, f_par, _, v3 = rodar(2 * destino, destino, "parado")
    print(f"{destino:>8} {'no ponto':>10} {100 * s_ref:>5.0f}% {f_ref:>7.1f} {b_ref:>9.1f}")
    print(f"{'':>8} {'metade':>10} {100 * s_meio:>5.0f}%")
    print(f"{'':>8} {'parado':>10} {100 * s_par:>5.0f}% {f_par:>7.1f}")
    exigir(s_ref >= 0.85, f"andar {destino}: o grupo no ponto só atravessa {100 * s_ref:.0f}%")
    exigir(b_ref >= 1.5, f"andar {destino}: o grupo no ponto vence só {b_ref:.1f} batalha(s) — "
                         "voltou a atravessar no relógio, sem lutar")
    # Nos primeiros andares a base do personagem (+5 de ataque, +100 de vida)
    # pesa mais que o nível — é a Torre fácil do começo. Daqui pra frente, a
    # metade do ponto não pode passar.
    if destino >= 10:
        exigir(s_meio <= 0.2, f"andar {destino}: o grupo na metade do ponto atravessa {100 * s_meio:.0f}%")
    exigir(f_ref <= f_par, f"andar {destino}: jogar esperto fere mais que ficar parado")
    exigir(max(v1, v2, v3) < 2000, f"andar {destino}: travessia que não termina")

# ── o destino é só o próximo andar, e só se o jogador chegou lá ──────────
exigir(T.andar_permitido(9, 12) == 10, "do Andar 9, com o jogador no 12, o destino não é o 10")
exigir(T.andar_permitido(9, 9) is None, "o clã pode ir a um andar que o jogador ainda não alcançou")

# ── o reforço escala dentro da mesma batalha ───────────────────────────
rng = random.Random(5)
# um lutador que não cai e quase não fere: toda batalha estoura o limite
muralha = {"slot": 0, "nome": "muralha", "hp": 10 ** 9, "hp_max": 10 ** 9, "atk": 1,
           "def": 10 ** 7, "acc": 0, "eva": 0, "crit": 0}
t = T.nova_travessia(28, 29, [muralha], 999, rng)
chegadas = []
while not t["fim"] and len(chegadas) < 3:
    antes = t["reforcos"]
    T.turno(t, rng)
    if t["reforcos"] > antes and t["inimigos"]:
        chegadas.append(t["reforcos"] - antes)
exigir(chegadas[:2] == [1, 2], f"o reforço não cresce a cada limite estourado: {chegadas}")

if falhas:
    print("\n❌ TRAVESSIA COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("\n✅ travessia: no ponto atravessa lutando, metade não passa, decidir importa, só o próximo andar")
