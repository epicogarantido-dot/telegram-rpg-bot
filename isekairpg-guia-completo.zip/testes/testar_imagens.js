// Imagens no tamanho certo — o que o WebView de celular realmente carrega.
const fs=require('fs');
// ⚠️ Caminho derivado do arquivo, não absoluto: a versão anterior tinha
// '/home/claude/isekai/...' embutido e não passava em lugar nenhum além
// da máquina de quem escreveu — mesmo problema que o testar_imports.py já
// teve.
const path=require('path');
const RAIZ=path.dirname(__dirname);
const js=fs.readFileSync(path.join(RAIZ,'webapp/static/app.js'),'utf8');
const css=fs.readFileSync(path.join(RAIZ,'webapp/static/style.css'),'utf8');
const api=fs.readFileSync(path.join(RAIZ,'webapp/api.py'),'utf8');
const img=fs.readFileSync(path.join(RAIZ,'webapp/imagens.py'),'utf8');
let falhou=false; const ok=t=>console.log('  ✅ '+t); const nok=(t,e='')=>{console.log('  ❌ '+t+' '+e);falhou=true};

const criadas=(js.match(/createElement\("img"\)/g)||[]).length;
const lazy=(js.match(/\.loading = "lazy"/g)||[]).length;
const async_=(js.match(/\.decoding = "async"/g)||[]).length;
lazy===criadas ? ok(`${criadas} imagens, todas com loading="lazy"`) : nok(`só ${lazy} de ${criadas} com lazy`);
async_===criadas ? ok('todas com decoding="async" (não trava a thread principal)') : nok('falta decoding=async');
/function urlImagem\(chave, largura\)/.test(js) ? ok('urlImagem pede a largura') : nok('urlImagem sem largura');
/Math\.min\(512/.test(js) ? ok('largura limitada ao teto do servidor') : nok('sem teto de largura');
/largura \* 2/.test(js) ? ok('pede o dobro do CSS por causa de tela retina') : nok('vai borrar em retina');

/^img \{/m.test(css) ? ok('regra global de <img> como rede de segurança') : nok('sem regra global');
/max-width: 100%/.test(css) ? ok('nenhuma imagem estoura a largura da tela') : nok('imagem pode estourar');
/object-fit: cover/.test(css) ? ok('nenhuma imagem deforma') : nok('imagem pode deformar');

/def largura_valida/.test(img) ? ok('o servidor só aceita larguras da lista') : nok('qualquer largura aceita');
/LARGURAS = \(64, 128, 256, 512\)/.test(img) ? ok('4 tamanhos — disco não enche com variações') : nok('lista de larguras não encontrada');
/TEM_PILLOW/.test(img) && /except ImportError/.test(img)
  ? ok('Pillow é opcional: sem ele serve a original em vez de quebrar') : nok('Pillow obrigatório');
/w: int = 0/.test(api) ? ok('a rota aceita ?w=') : nok('rota sem parâmetro de largura');

// economia estimada
const orig=150, mini={64:4,128:11,256:30,512:90};
console.log('\n  economia por imagem (estimativa, original ~150 KB):');
for (const [w,kb] of Object.entries(mini))
  console.log(`    w=${w}: ~${kb} KB  (${Math.round((1-kb/orig)*100)}% menos)`);
console.log(falhou?'\n❌ ALGO FALHOU':'\n🟢 IMAGENS NO TAMANHO CERTO: TUDO PASSOU');
process.exit(falhou?1:0);
