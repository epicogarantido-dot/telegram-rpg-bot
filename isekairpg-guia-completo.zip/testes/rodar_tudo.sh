#!/bin/bash
# Suíte completa. Cada arquivo sai com código != 0 se falhar.
#
# ⚠️ 17/09/2026 — este script chamava NOVE arquivos que não existem no
# repositório (executar_appjs.js, testar_abas.js, testar_cidade.js,
# testar_login.js, testar_criacao.js, testar_expirado.js e a pasta
# teste_contas/ inteira). Resultado: ele saía SEMPRE com "❌ ALGO FALHOU",
# e o sinal dos testes que de fato rodam sumia no meio do ruído — num
# projeto cuja primeira regra é "medir antes e depois", a suíte tinha
# virado um carimbo vermelho sem informação. Se aqueles arquivos
# reaparecerem, é só voltar a linha deles.
#
# Os auditores agora rodam junto. Eles saem com 2 quando falta aiosqlite
# (rodando fora do servidor), e isso NÃO conta como falha.
cd "$(dirname "$0")"
falhou=0

rodar() {          # rodar <comando...> — 0 passa, 2 é "pulado", resto falha
  "$@" > /tmp/saida_teste.txt 2>&1
  local codigo=$?
  case $codigo in
    0) tail -1 /tmp/saida_teste.txt ;;
    2) echo "⏭️  pulado: $* (falta dependência)" ;;
    *) tail -3 /tmp/saida_teste.txt; echo "❌ falhou: $*"; falhou=1 ;;
  esac
}

echo "── backend ─────────────────────────────"
rodar python3 testar_imports.py
rodar node    testar_backend.js
echo "── front ───────────────────────────────"
rodar node    executar_appjs.js
rodar node    testar_varredura.js
rodar node    testar_imagens.js
rodar node    testar_grupos.js
rodar node    testar_admin.js
rodar node    testar_guia.js
rodar node    testar_janela_recompensa.js
rodar node    testar_criacao_fluxo.js
rodar node    testar_criacao_fluxo.js --nascido
rodar node    testar_criacao_fluxo.js --falha=abertura:1
rodar node    testar_criacao_fluxo.js --falha=abertura:2
rodar node    testar_criacao_fluxo.js --falha=habilidade:2
rodar node    testar_guia_real.js
rodar node    testar_perfil_real.js
echo "── travas e concorrência ───────────────"
rodar python3 testar_trava.py
echo "── clã e AFK ───────────────────────────"
rodar python3 testar_estado_jogador.py
rodar python3 testar_mercado.py
rodar python3 testar_schema_cla.py
rodar python3 testar_backup.py
rodar python3 testar_fome.py
echo "── auditores ───────────────────────────"
rodar python3 testar_cronicas.py
rodar python3 testar_chefe_novato.py
rodar python3 testar_cavaleiro.py
rodar python3 testar_convidado.py
rodar python3 testar_recompensa.py
rodar python3 testar_miticos.py
rodar python3 auditar_areas_afk.py
rodar python3 auditar_materiais.py
rodar python3 auditar_risco_afk.py
rodar python3 auditar_fome.py
rodar python3 auditar_fusao.py
rodar python3 auditar_catalogo_imagens.py
rodar python3 auditar_recompensas.py
rodar python3 auditar_pet_skills.py
rodar python3 auditar_arena.py
rodar python3 auditar_aldeia.py
rodar python3 testar_aldeia.py
rodar python3 auditar_territorio.py
rodar python3 testar_territorio.py
rodar python3 testar_ouro_e_forja.py
rodar python3 testar_migracoes.py
rodar python3 testar_modo_so_site.py
rodar python3 auditar_jornada.py
rodar python3 testar_jornada.py
rodar python3 auditar_postos.py
rodar python3 auditar_equipes.py
rodar python3 testar_equipes.py
rodar python3 medir_material.py
rodar python3 auditar_ferreiro.py
rodar python3 testar_ferreiro.py
rodar python3 testar_batalha.py
rodar python3 testar_cidade_e_cores.py
rodar python3 testar_explorar.py
rodar python3 testar_xp_guardas.py
rodar python3 testar_diarias.py
rodar python3 testar_reliquias.py
rodar python3 testar_fundacao_e_vizinhos.py

echo
[ $falhou -eq 0 ] && echo "🟢 SUÍTE COMPLETA PASSOU" || echo "❌ ALGO FALHOU"
exit $falhou
