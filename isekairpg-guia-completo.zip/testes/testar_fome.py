#!/usr/bin/env python3
"""E2E do laço da comida: roda rodar_afk num banco de verdade.

POR QUE EXISTE
--------------
O auditor (auditar_fome.py) mede se os NÚMEROS fecham. Este aqui confere se
o CÓDIGO faz o que os números dizem — consumo cobrado, fome gravada, teto
respeitado, estoque nunca negativo. A distinção importa neste projeto: a
fome já existia como campo, já derrubava poder numa fórmula, e mesmo assim
não acontecia nada, porque ninguém escrevia nela. Planilha certa com
gravação faltando foi exatamente o bug.
"""
import sys, os, random, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    import aiosqlite  # noqa: F401
except ImportError:
    print("⚠️  aiosqlite não instalado — rode no servidor, onde ele existe.")
    sys.exit(2)
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = os.environ["DB_PATH"]

from game import clan_repo as CR
from game.clan_materiais import teto_de_comida

CR.init_clan()
OWNER = 42
A = CR.areas_disponiveis(30)


def modelo(nivel):
    return {"telegram_id": 1, "level": nivel, "xp": 0, "xp_next": 9**9, "gold": 0,
            "tower_floor": 1, "hp": 100, "hp_max": 100, "state": "TOWER",
            "class_id": None, "race_id": None,
            "attrs": {k: nivel for k in ("str", "vit", "agi", "dex")},
            "trails": {}, "combat": None,
            "inv": {"potion": 0, "cores": {}, "items": {}}, "equip": {},
            "pets": {"owned": {}, "deck": [None] * 5},
            "skills_learned": {}, "skill_slots": {"equipped": [None] * 5}, "chakra": None}


def por(owner, sql, args=()):
    with CR._conn() as c:
        return c.execute(sql, args).fetchall()


def montar(n_membros, area_id, comida_inicial, nivel=40):
    with CR._conn() as c:
        c.execute("DELETE FROM clan WHERE owner_id = ?", (OWNER,))
        c.execute("DELETE FROM clan_membro WHERE owner_id = ?", (OWNER,))
        c.execute("INSERT INTO clan(owner_id, comida, ultimo_tick) VALUES (?,?,1)",
                  (OWNER, comida_inicial))
        for s in range(n_membros):
            c.execute("INSERT INTO clan_membro(owner_id, slot, nome, nivel, area_id)"
                      " VALUES (?,?,?,?,?)",
                      (OWNER, s, f"M{s}", nivel - s, area_id))
        c.commit()


falhou = 0


def checar(nome, condicao, detalhe=""):
    global falhou
    print(("  ✅ " if condicao else "  ❌ ") + nome + ("" if condicao else f"  -> {detalhe}"))
    if not condicao:
        falhou = 1


agora = 25 * CR.INTERVALO_TICK   # garante o teto de ticks

print("1. clã com comida sobrando: todos comem, ninguém passa fome")
montar(3, "andar11", comida_inicial=200)
modelos = {m["slot"]: modelo(m["nivel"]) for m in CR.listar_membros(OWNER)}
r = CR.rodar_afk(OWNER, A, modelos, agora=agora, rng=random.Random(3))
membros = CR.listar_membros(OWNER)
clan = CR.carregar_clan(OWNER)
esperado_racao = (CR.TETO_TICKS // CR.RACAO_TICKS) * 3
checar(f"ração cobrada = {esperado_racao}", r["racao"] == esperado_racao, r["racao"])
checar("ninguém com fome", all(m["fome"] == 0 for m in membros),
       [(m["nome"], m["fome"]) for m in membros])
checar("estoque caiu pelo consumo",
       clan["comida"] <= 200 - r["consumido"] + r["comida"],
       clan["comida"])

print("\n2. clã sem comida nenhuma: todos ficam com fome")
montar(3, "andar11", comida_inicial=0)
modelos = {m["slot"]: modelo(m["nivel"]) for m in CR.listar_membros(OWNER)}
r = CR.rodar_afk(OWNER, A, modelos, agora=agora, rng=random.Random(3))
membros = CR.listar_membros(OWNER)
vivos = [m for m in membros if m["vivo"]]
checar("todo vivo em posto ficou com fome",
       all(m["fome"] >= 1 for m in vivos), [(m["nome"], m["fome"]) for m in vivos])
checar("estoque não ficou negativo", CR.carregar_clan(OWNER)["comida"] >= 0)
checar(f"{len(r['famintos'])} faminto(s) reportado(s)", len(r["famintos"]) > 0)

print("\n3. comida pra 1 de 3: o mais forte come primeiro")
montar(3, "andar11", comida_inicial=6)
modelos = {m["slot"]: modelo(m["nivel"]) for m in CR.listar_membros(OWNER)}
r = CR.rodar_afk(OWNER, A, modelos, agora=agora, rng=random.Random(3))
membros = sorted([m for m in CR.listar_membros(OWNER) if m["vivo"]],
                 key=lambda m: m["nivel"], reverse=True)
if membros:
    checar("o de maior nível está menos faminto que o de menor",
           membros[0]["fome"] <= membros[-1]["fome"],
           [(m["nome"], m["nivel"], m["fome"]) for m in membros])

print("\n4. quem NÃO está em posto se recupera e não come")
montar(2, "andar11", comida_inicial=0)
with CR._conn() as c:
    c.execute("UPDATE clan_membro SET fome = 4, area_id = NULL WHERE owner_id = ? AND slot = 1",
              (OWNER,))
    c.execute("UPDATE clan SET ultimo_tick = 1 WHERE owner_id = ?", (OWNER,))
    c.commit()
modelos = {m["slot"]: modelo(m["nivel"]) for m in CR.listar_membros(OWNER)}
r = CR.rodar_afk(OWNER, A, modelos, agora=agora, rng=random.Random(5))
sem_posto = [m for m in CR.listar_membros(OWNER) if m["slot"] == 1]
checar("quem ficou na aldeia recuperou 1 de fome",
       sem_posto and sem_posto[0]["fome"] == 3, sem_posto[0]["fome"] if sem_posto else "sumiu")
checar("só 1 membro pagou ração", r["racao"] == CR.TETO_TICKS // CR.RACAO_TICKS, r["racao"])

print("\n5. teto de comida: o que passa apodrece, e o Celeiro aumenta o teto")
montar(1, "andar1", comida_inicial=teto_de_comida({}, 1))
modelos = {m["slot"]: modelo(m["nivel"]) for m in CR.listar_membros(OWNER)}
r = CR.rodar_afk(OWNER, A, modelos, agora=agora, rng=random.Random(9))
clan = CR.carregar_clan(OWNER)
checar(f"estoque travado no teto ({teto_de_comida({}, 1)})",
       clan["comida"] <= teto_de_comida({}, 1), clan["comida"])
checar("perda reportada", r["perdido"] >= 0, r["perdido"])
checar("Celeiro dobra o teto",
       teto_de_comida({"celeiro": True}, 5) == teto_de_comida({}, 5) * 2)
checar("o teto cresce com o clã", teto_de_comida({}, 5) > teto_de_comida({}, 1))

print("\n6. fome invalida o perfil guardado")
m = {"nivel": 40, "equip_poder": 10, "fome": 0, "ferimento": 0}
a1 = CR.assinatura_do_perfil(m)
a2 = CR.assinatura_do_perfil(dict(m, fome=3))
a3 = CR.assinatura_do_perfil(dict(m, ferimento=2))
checar("assinatura muda com fome", a1 != a2, (a1, a2))
checar("assinatura muda com ferimento", a1 != a3, (a1, a3))
checar("fome e ferimento não colidem com nível/equipamento",
       len({a1, a2, a3, CR.assinatura_do_perfil(dict(m, nivel=41)),
            CR.assinatura_do_perfil(dict(m, equip_poder=11))}) == 5)
base = modelo(40)
pen = CR.penalizar_modelo(base, dict(m, fome=6))
checar("penalizar_modelo derruba atributo", pen["attrs"]["str"] == base["attrs"]["str"] - 6,
       pen["attrs"]["str"])
checar("penalizar_modelo não muda o original", base["attrs"]["str"] == 40)

print("\n7. o diário fica GRAVADO e a situação é calculada")
montar(3, "andar11", comida_inicial=90)
modelos = {m["slot"]: modelo(m["nivel"]) for m in CR.listar_membros(OWNER)}
CR.rodar_afk(OWNER, A, modelos, agora=agora, rng=random.Random(2))
clan = CR.carregar_clan(OWNER)
checar("a sessão entrou no diário do banco",
       len(clan.get("diario") or []) >= 1, clan.get("diario"))
if clan.get("diario"):
    pag = clan["diario"][0]
    checar("a página tem quando/ticks/ração",
           all(k in pag for k in ("quando", "ticks", "racao")), list(pag))
# roda de novo e confere que o diário acumula sem estourar o teto
for i in range(CR.SESSOES_NO_DIARIO + 3):
    with CR._conn() as c:
        c.execute("UPDATE clan SET ultimo_tick = 1 WHERE owner_id = ?", (OWNER,))
        c.commit()
    CR.rodar_afk(OWNER, A, modelos, agora=agora + i, rng=random.Random(i))
clan = CR.carregar_clan(OWNER)
checar(f"o diário para em {CR.SESSOES_NO_DIARIO} páginas",
       len(clan["diario"]) == CR.SESSOES_NO_DIARIO, len(clan["diario"]))

sit = CR.situacao_do_cla(OWNER, clan, CR.listar_membros(OWNER))
checar("a situação conta os vivos", sit["vivos"] >= 0, sit)
checar("em_posto + na_aldeia = vivos",
       sit["em_posto"] + sit["na_aldeia"] == sit["vivos"], sit)
checar("autonomia é comida / ração",
       sit["autonomia_sessoes"] is None
       or abs(sit["autonomia_sessoes"] - clan["comida"] / sit["racao_por_sessao"]) < 0.11,
       (sit["autonomia_sessoes"], clan["comida"], sit["racao_por_sessao"]))

print("\n" + ("🟢 E2E DO LAÇO DA COMIDA PASSOU" if not falhou else "❌ E2E FALHOU"))
sys.exit(falhou)
