// Varredura do site contra ele mesmo — rotas, telas e estados vazios.
const fs=require('fs');
// ⚠️ Caminhos derivados deste arquivo, nunca absolutos. Teste com o caminho
// da máquina de quem escreveu não passa em lugar nenhum — nem no servidor —
// e vira rede que não pega nada. É a armadilha nº 11 do projeto.
const path = require('path');
const RAIZ = path.dirname(__dirname);

const api=fs.readFileSync(path.join(RAIZ,'webapp/api.py'),'utf8');
const app=fs.readFileSync(path.join(RAIZ,'webapp/static/app.js'),'utf8');
const adm=fs.readFileSync(path.join(RAIZ,'webapp/static/admin.html'),'utf8');
const css=fs.readFileSync(path.join(RAIZ,'webapp/static/style.css'),'utf8');
let falhou=false; const ok=t=>console.log('  ✅ '+t); const nok=(t,e='')=>{console.log('  ❌ '+t+' '+e);falhou=true};
const front=app+adm;

// 1. toda rota chamada pelo front existe
const rotas=new Set([...api.matchAll(/@app\.(get|post|put|delete)\("([^"]+)"/g)].map(m=>m[2]));
const chamadas=[...front.matchAll(/(?:api|fetch|chamar)\(\s*[`"']([^`"'?${]+)/g)].map(m=>m[1]).filter(c=>c.startsWith('/api')).filter(c=>!c.endsWith('/'));  // caminhos montados por concatenação terminam em / e são resolvidos em runtime
const fantasmas=[...new Set(chamadas)].filter(c=>!rotas.has(c)&&![...rotas].some(r=>r.includes('{')&&c.startsWith(r.split('{')[0])));
fantasmas.length ? nok('front chama rota inexistente', fantasmas.join(', ')) : ok(`${new Set(chamadas).size} caminhos chamados, todos existem no servidor`);

// 2. pulsar() não voltou
/function pulsar\s*\(/.test(app) ? nok('pulsar() ainda existe') : ok('pulsar() removido (animarNumero já fazia melhor)');
/numero-pulso|@keyframes bate/.test(css) ? nok('CSS morto do pulsar sobrou') : ok('CSS do pulsar removido junto');

// 3. trocar senha alcançável
/abrirTrocarSenha/.test(app) && /\/api\/auth\/trocar-senha/.test(app)
  ? ok('trocar senha tem tela (a rota existia sem alcance nenhum)') : nok('trocar senha ainda sem tela');
(app.match(/abrirTrocarSenha/g)||[]).length>=2 ? ok('e está ligada a um botão') : nok('função definida mas nunca chamada');

// 4. estados vazios acionáveis
const vazios=[...app.matchAll(/estadoVazio\("[^"]*",\s*\n?\s*"([^"]{10,200})/g)].map(m=>m[1]);
// A lista é de VERBOS DE PRÓXIMO PASSO. 'escolha' e 'troque' são tão
// imperativos quanto 'use' — faltavam por descuido, não por regra.
const verbos=/toque|abra|use|crie|invoque|suba|derrote|anuncie|mande|entre|escolha|troque|recolha|compre|caem|vêm|vem|saem|quem|reabre|enche|forja|aparece/i;
const mudos=vazios.filter(v=>!verbos.test(v));
mudos.length ? console.log(`  ⚠️ ${mudos.length} estado(s) vazio(s) ainda sem próximo passo`)
             : ok(`os ${vazios.length} estados vazios dizem o que fazer`);

// 5. nenhuma tela órfã
const telas=new Set([...app.matchAll(/^\s{2}(\w+): render\w+,/gm)].map(m=>m[1]));
const noMenu=new Set([...app.matchAll(/tela: "(\w+)"/g)].map(m=>m[1]));
// Telas de DETALHE (20/09): não vão no menu porque abrem a partir de um item
// — a página de cada equipe abre pelo cartão da equipe em Clã → Postos. Pra
// não virar buraco, a tela de detalhe precisa de um irPara("x") no código.
// perfil_jogador (28/09): a ficha de outro jogador, aberta tocando no nome no ranking.
const DETALHE=new Set(['clan_equipe','perfil_jogador']);
for(const t of DETALHE){ if(!new RegExp(`irPara\\("${t}"\\)`).test(app)) nok('tela de detalhe sem caminho até ela',t); }
const orfas=[...telas].filter(t=>!noMenu.has(t)&&!DETALHE.has(t));
orfas.length ? nok('tela sem entrada no menu', orfas.join(',')) : ok(`as ${telas.size} telas são alcançáveis pelo menu`);

// 6. a versão de cache é automática? (armadilha nº 7 do projeto)
const api2=fs.readFileSync(path.join(RAIZ,'webapp/api.py'),'utf8');
/_versao_dos_estaticos/.test(api2) && /hashlib/.test(api2)
  ? ok('versão de cache é hash do conteúdo — não dá pra esquecer de subir')
  : nok('versão de cache ainda é um número na mão');
/@app\.get\("\/"\)/.test(api2) ? ok('o servidor serve o index carimbando a versão') : nok('index sem rota própria');

// 9. raridade: um vocabulário só
// ⚠️ Os itens carregam a raridade em INGLÊS (common/uncommon/rare/epic/
// legendary, de game/items.py) e o CSS só define as classes em PORTUGUÊS.
// `class="cartao-item rar-legendary"` não casava com nada, e o efeito de
// raridade — cantos, glow, o pulso do lendário — nunca apareceu em item
// nenhum, em tela nenhuma. Pets e montarias funcionavam porque os bancos
// deles já guardam em português, o que escondia o bug.
const classesRar = new Set([...css.matchAll(/\.rar-([a-z]+)/g)].map(m => m[1]));
const mapa = app.match(/const RARIDADE_CLASSE = \{[\s\S]*?\};/);
if (!mapa) {
  nok('RARIDADE_CLASSE sumiu — a tradução de raridade era o que fazia o efeito aparecer');
} else {
  const destinos = [...mapa[0].matchAll(/:\s*"([a-z]+)"/g)].map(m => m[1]);
  const orfas = [...new Set(destinos)].filter(d => !classesRar.has(d));
  orfas.length
    ? nok('classeRar aponta pra classe que não existe no CSS', orfas.join(','))
    : ok(`classeRar cai em ${new Set(destinos).size} classes que existem de verdade`);
  const ingles = ['common', 'uncommon', 'rare', 'epic', 'legendary'];
  const faltam = ingles.filter(r => !mapa[0].includes(`${r}:`));
  faltam.length
    ? nok('raridade de item sem tradução', faltam.join(','))
    : ok('as 5 raridades em inglês dos itens têm tradução');
}
const naMao = [...app.matchAll(/rar-\$\{/g)].length + [...app.matchAll(/" rar-" \+/g)].length;
naMao ? nok('classe de raridade montada na mão em vez de classeRar()', String(naMao))
      : ok('toda classe de raridade passa por classeRar()');


// 10. nenhum teste com caminho absoluto
// ⚠️ Armadilha nº 11: teste com o caminho da máquina de quem escreveu não
// passa em lugar nenhum — nem no servidor — e vira rede que não pega nada.
// Já aconteceu com testar_imports.py, e depois com mais três de uma vez.
const fsx = require('fs');
const absolutos = fsx.readdirSync(__dirname)
  .filter(f => /\.(js|py)$/.test(f))
  .filter(f => fsx.readFileSync(path.join(__dirname, f), 'utf8')
    .split('\n')
    .some(l => /\/home\/[a-z]+\/(isekai|bench)\//.test(l)
               && !/^\s*(\/\/|#)/.test(l)));
absolutos.length
  ? nok('teste com caminho absoluto embutido', absolutos.join(','))
  : ok(`os ${fsx.readdirSync(__dirname).filter(f=>/\.(js|py)$/.test(f)).length} testes derivam o caminho do próprio arquivo`);

console.log(falhou?'\n❌ ALGO FALHOU':'\n🟢 VARREDURA DO SITE: TUDO PASSOU');
process.exit(falhou?1:0);
