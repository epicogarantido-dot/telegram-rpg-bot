// EXECUTA o app.js de verdade, num DOM de mentira.
//
// POR QUE ESTE TESTE EXISTE
// -------------------------
// Armadilha nº 8 do projeto: `node --check` não executa nada. Ele valida a
// SINTAXE e passa feliz por `ICONE_RECURSO.comida` quando ninguém declarou
// `ICONE_RECURSO` — o erro só aparece no navegador do jogador, na tela que
// usa aquela constante.
//
// Aconteceu em 18/09: uma constante nova foi inserida depois de uma âncora
// que não existia mais, a substituição não aplicou em silêncio, o
// `node --check` passou, e a tela do clã teria quebrado no ar.
//
// Tentei antes varrer o texto procurando identificador não declarado. Não
// funciona: regex não dá conta de template com `${}` aninhado nem de regex
// literal com aspas dentro (`replace(/"/g, ...)` abre uma string falsa e
// engole o resto do arquivo). Varredor de texto sobre JavaScript é remendo;
// executar é a resposta.
//
// O teste faz duas coisas:
//   1. CARREGA o arquivo inteiro — pega qualquer erro de escopo do módulo.
//   2. CHAMA os construtores puros com dados de exemplo — pega constante
//      que só é lida dentro deles.
//
// ⚠️ O QUE ELE **NÃO** PEGA, e vale saber pra não confiar demais:
// código que só roda dentro de uma `render*` continua sem cobertura, porque
// essas funções começam com `await api(...)` e precisariam de servidor.
// Medido: apagando a declaração de ICONE_RECURSO — o bug real que motivou
// este teste — ele passa, porque quem lê essa constante é a lista de áreas
// dentro do renderClan. A rede tem furo e o furo está escrito aqui.
//
// Fechar esse furo pede extrair os construtores de dentro das render — o
// que vale fazer aos poucos, cada vez que uma delas for mexida. Toda
// função que sair de lá pra cá entra na lista de chamadas abaixo.
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const RAIZ = path.dirname(__dirname);
const src = fs.readFileSync(path.join(RAIZ, 'webapp/static/app.js'), 'utf8');

const noop = () => {};
function elementoFalso() {
  const e = {
    style: { setProperty: noop, removeProperty: noop, getPropertyValue: () => '' }, classList: { add: noop, remove: noop, toggle: noop, contains: () => false },
    dataset: {}, children: [], childNodes: [],
    appendChild: (x) => x, append: noop, prepend: noop, remove: noop,
    setAttribute: noop, getAttribute: () => null, removeAttribute: noop,
    addEventListener: noop, removeEventListener: noop, querySelector: () => null,
    querySelectorAll: () => [], insertAdjacentHTML: noop, focus: noop, click: noop,
    scrollIntoView: noop, getBoundingClientRect: () => ({ width: 0, height: 0 }),
  };
  Object.defineProperty(e, 'innerHTML', { get: () => '', set: noop });
  Object.defineProperty(e, 'textContent', { get: () => '', set: noop });
  return e;
}
const documento = {
  getElementById: () => elementoFalso(),
  createElement: () => elementoFalso(),
  createTextNode: () => elementoFalso(),
  querySelector: () => elementoFalso(),
  querySelectorAll: () => [],
  addEventListener: noop, body: elementoFalso(), head: elementoFalso(),
  documentElement: elementoFalso(), hidden: false,
};
const janela = {
  document: documento, location: { href: '', search: '', pathname: '/' },
  localStorage: { getItem: () => null, setItem: noop, removeItem: noop },
  sessionStorage: { getItem: () => null, setItem: noop, removeItem: noop },
  addEventListener: noop, matchMedia: () => ({ matches: false, addEventListener: noop }),
  fetch: () => Promise.resolve({ ok: true, json: () => Promise.resolve({}) }),
  navigator: { userAgent: 'teste', onLine: true },
  setTimeout, clearTimeout, setInterval, clearInterval, requestAnimationFrame: noop,
  // O stub de áudio precisa cobrir TODOS os métodos que os sons usam. Faltava
  // linearRampToValueAtTime (e as rampas de frequência), e o teste quebrava na
  // primeira tela que toca som de vitória — falha do teste, não do app.
  AudioContext: function () {
    const parametro = () => ({ value: 0, setValueAtTime: noop, linearRampToValueAtTime: noop,
                               exponentialRampToValueAtTime: noop, cancelScheduledValues: noop,
                               setTargetAtTime: noop });
    return {
      createOscillator: () => ({ connect: noop, start: noop, stop: noop, disconnect: noop,
                                 type: 'sine', frequency: parametro(), detune: parametro(),
                                 onended: null }),
      createGain: () => ({ connect: noop, disconnect: noop, gain: parametro() }),
      createBiquadFilter: () => ({ connect: noop, disconnect: noop, type: 'lowpass',
                                   frequency: parametro(), Q: parametro() }),
      createBufferSource: () => ({ connect: noop, start: noop, stop: noop, buffer: null }),
      createBuffer: () => ({ getChannelData: () => new Float32Array(1) }),
      resume: noop, currentTime: 0, sampleRate: 44100, destination: {},
    };
  },
  Telegram: undefined,
};
janela.window = janela;
const ctx = vm.createContext({ ...janela, window: janela, document: documento,
  console, Promise, JSON, Math, Date, URL, URLSearchParams, Error, TypeError,
  Set, Map, Array, Object, String, Number, Boolean, parseInt, parseFloat,
  isNaN, encodeURIComponent, decodeURIComponent, alert: noop, navigator: janela.navigator });
try {
  vm.runInContext(src, ctx, { filename: 'app.js' });
  console.log('✅ app.js carregou inteiro sem lançar');
} catch (e) {
  console.log('❌ app.js quebrou ao carregar: ' + e.message);
  console.log((e.stack || '').split('\n').slice(0, 4).join('\n'));
  process.exit(1);
}

// ---------------------------------------------------------------------
// 2. Chama os construtores com dados de exemplo.
//
// É aqui que constante lida DENTRO de função aparece. Carregar o módulo
// sozinho não pega: `ICONE_RECURSO` era usado numa render, então o arquivo
// carregava limpo e quebrava só quando o jogador abrisse a tela do clã.
let falhou = false;
function tentar(nome, fn) {
  if (typeof ctx[nome] !== 'function') {
    console.log('  ⚠️ ' + nome + ' não existe mais — o teste envelheceu');
    return;
  }
  try {
    fn();
    console.log('  ✅ ' + nome);
  } catch (e) {
    console.log('  ❌ ' + nome + ' -> ' + e.message);
    falhou = true;
  }
}

const PET = {
  nome: 'Lobo', raridade: 'incomum', quantidade: 2, evolucao: 2, nivel: 7,
  img_key: 'PET_PET_C_LOBO', arquetipo: 'dps', bonus_stats: { atk: 10 },
  bonus_pct: { crit: 0.03 }, mecanica: { type: 'dmg_amp', value: 0.01 },
  economia: { type: 'xp', value: 0.01 }, extras: ['T1 · 2 disponíveis'],
  acoes: [{ rotulo: 'Evoluir', principal: true, aoTocar: () => {} }],
  verso: (v) => { v.appendChild({}); },
};
const SITUACAO = {
  vivos: 5, em_posto: 3, na_aldeia: 2, com_fome: 1, feridos: 1, mortos: 1,
  colhendo_comida: 0, racao_por_sessao: 18, autonomia_sessoes: 0.4,
  teto_comida: 300, situacoes_pendentes: 2,
};

console.log('\nconstrutores:');
tentar('classeRar', () => {
  for (const r of ['legendary', 'lendario', 'common', null, undefined, 'xpto'])
    ctx.classeRar(r);
});
tentar('cartaoGrande', () => { ctx.cartaoGrande(PET); ctx.cartaoGrande({ nome: 'Vazio' }); });
tentar('fichaInimigo', () => ctx.fichaInimigo({
  nome: 'Goblin', hp: 10, hpMax: 30, icone: '👹', tag: 'A', selecionado: true }));
tentar('painelDaSituacao', () => ctx.painelDaSituacao(SITUACAO));
tentar('alertasDoCla', () => ctx.alertasDoCla(SITUACAO, { comida: 300, teto_comida: 300 }));
// painelDeConsequencia saiu com o sistema antigo de decisões (26/09/2026).

tentar('diarioDoAfk', () => ctx.diarioDoAfk({
  ticks: 24, comida: 20, madeira: 10, couro: 5, ouro: 30, compra_auto: { comprado: 40, custo_ouro: 40 },
  materiais: { 2: 40 }, racao: 18, consumido: 18, perdido: 3,
  famintos: [{ nome: 'M1' }], mortos: [{ nome: 'M2', causa: 'x' }],
  eventos: [], descartados: 2 }, 'Teste'));
tentar('preverTurnos', () => {
  const o = ctx.preverTurnos([{ bar: 40, spd: 12 }, { bar: 80, spd: 6 }], 10);
  if (o.length !== 10) throw new Error('previu ' + o.length + ' de 10');
});
tentar('descreverMecanica', () => {
  for (const t of ['tp_discount', 'dmg_amp', 'lifesteal', 'inexistente'])
    ctx.descreverMecanica({ type: t, value: 0.05 });
  ctx.descreverMecanica(null);
});
tentar('haQuantoTempo', () => { ctx.haQuantoTempo(0); ctx.haQuantoTempo(Date.now() / 1000 - 90000); });
tentar('tituloDaLuta', () => { ctx.tituloDaLuta('Torre', 'Andar 3'); ctx.tituloDaLuta('Raid'); });
tentar('moedaFicha', () => ctx.moedaFicha('💰', '100', 'ouro', 'cheio'));
tentar('carrossel', () => { ctx.carrossel([], { vazio: true }); ctx.carrossel([{}, {}], null); });
tentar('urlImagem', () => { ctx.urlImagem('STATUS', 64); ctx.urlImagem(null); });

// 🏟️ A tela da Arena é `desenhar*` e não `render*` — ela recebe o snapshot
// pronto em vez de buscar. Por isso dá pra EXECUTAR ela aqui, e não só os
// construtores: é um pedaço do furo descrito no cabeçalho sendo fechado.
const LADO_ARENA = {
  nome: 'Rival', hp: 40, hp_max: 100, bar: 55, spd: 18,
  img_key: 'STATUS', escudo: 12, atordoado: true, dots: ['Queimadura'],
};
// 🏘️ a aldeia viva — construtor puro, dá pra executar com dados de exemplo
const ALDEIA = {
  estagio: { indice: 1, nome: 'Aldeia', capacidade: 8,
             proximo: { nome: 'Vila', habitantes: 8, comodidades: 1 } },
  habitantes: [
    { id: 1, nome: 'Kael', profissao: 'minerador', titulo: 'Geólogo', nivel: 10, nivel_max: 20,
      potencial: 5, fadiga: 85, faixa: 'Exausto', fator: 0.25, descansando: false, aura: 3,
      rende: 4.1, produz: 'material rank 1', cargo: 'Chefe da Mineração', familia: 'irmão de Mira' },
    { id: 2, nome: 'Mira', profissao: 'guarda', titulo: 'Guarda', nivel: 2, nivel_max: 4,
      potencial: 1, fadiga: 0, faixa: 'Descansado', fator: 1, descansando: true, aura: 0,
      rende: 0, produz: null },
  ],
  memorial: [{ nome: 'Bram', causa: 'morreu num ataque de monstros à aldeia', quando: 0 }],
  memorias: [{ quando: 0, tipo: 'aura', texto: '✨ Kael despertou' }],
  profissoes: { agricultor: { nome: 'Agricultor', icone: '🌾', produz: 'comida' },
                guarda: { nome: 'Guarda', icone: '🛡️', produz: null } },
  custo_acolher: 15, defesa: 20,
  cargos: { minerador: { nome: 'Chefe da Mineração', exige: 'minerador', chefe: null },
            aura: { nome: 'Mestre da Aura', exige: null, chefe: null } },
  especializacoes: { escolhidas: ['militar'], vagas: 2, custo_troca: 60,
                     catalogo: { militar: { nome: 'Militar', icone: '⚔️', efeito: '+25%' },
                                 aura: { nome: 'Da Aura', icone: '🔮', efeito: '2×' } } },
  regras: { descanso_auto: true, limite: 80, volta: 20 },
};
// painelDaAldeia virou cabecalhoDaAldeia + linhaDoMembro (Resumo) e
// memoriasDaAldeia (Histórico) em 25/09/2026.
tentar('cabecalhoDaAldeia', () => {
  ctx.cabecalhoDaAldeia(ALDEIA, 100);
  ctx.cabecalhoDaAldeia({ ...ALDEIA, habitantes: [], estagio: { ...ALDEIA.estagio, proximo: null } }, 0);
});
tentar('linhaDoMembro', () => {
  for (const h of ALDEIA.habitantes) ctx.linhaDoMembro({ ...h, talentos: { minerador: 3 } }, ALDEIA);
});
tentar('memoriasDaAldeia', () => ctx.memoriasDaAldeia(ALDEIA));
tentar('listaDeMembros', () => {
  const eqs = [{ posto_id: 'p1', recurso: 'ferro' }];
  const habs = [{ ...ALDEIA.habitantes[0], funcao: 'coletor', equipe: 'p1' }, { ...ALDEIA.habitantes[1], funcao: 'guarda' }];
  if (ctx.membrosDoFiltro(habs, 'ferro', eqs).length !== 1) throw new Error('filtro de mineração errado');
  if (ctx.membrosDoFiltro(habs, 'guarda', eqs).length !== 1) throw new Error('filtro de guarda errado');
  if (ctx.membrosDoFiltro(habs, 'aldeia', eqs).length !== 0) throw new Error('filtro da aldeia errado');
  ctx.listaDeMembros({ aldeia_viva: { ...ALDEIA, habitantes: habs }, equipes: eqs });
});
tentar('painelDoCultivo', () => {
  ctx.painelDoCultivo({ andar_de_trabalho: 3, cultivo: [
    { slot: 0, nome: 'Kael', nivel: 20, ativo: true, existe: true, batalhando: true, morto: false,
      chance_morte: 5.9, risco_sessao: 21.6, resumo: 'Perde pro chefe.', xp_por_hora: 12,
      ultimo: { quando: 0, xp: 36, lutas: 3, morreu: false, travado: false } },
    { slot: 1, nome: 'Lira', nivel: 3, ativo: false, existe: true, batalhando: false, morto: true,
      chance_morte: 100, risco_sessao: 100, resumo: '', xp_por_hora: 12, ultimo: null },
    { slot: 2, nome: 'Novo', nivel: 1, ativo: false, existe: false, batalhando: false, morto: false,
      chance_morte: 0, risco_sessao: 0, resumo: '', xp_por_hora: 12, ultimo: null }] });
});
tentar('recursosDoCla', () => ctx.recursosDoCla({ comida: 5, teto_comida: 10, madeira: 1, couro: 2, gold: 3, materiais: [] }));
tentar('diarioDoAfk', () => ctx.diarioDoAfk({
  ticks: 24, comida: 20, mortos: [], famintos: [], eventos: [],
  aldeia: { producao: { comida: 20 }, frases: ['✨ Kael despertou', '📈 subiu'],
            ataque: null, despertaram: ['Kael'], chegou: null } }, 'Teste'));

// cartaoDoPonto saiu com a página do Território (25/09/2026).

tentar('desenharEquipe', () => {
  const div = ctx.document.createElement('div');
  const habs = [
    { id: 1, nome: 'A', nivel: 5, talentos: { agricultor: 1, guarda: 0 }, equipe: null },
    { id: 2, nome: 'B', nivel: 9, talentos: { agricultor: 4, guarda: 2 }, equipe: 'p1_bosque' },
    { id: 3, nome: 'C', nivel: 20, talentos: { lenhador: 2, guarda: 5 }, equipe: null }];
  const d = { aldeia_viva: { habitantes: habs }, defesa: 'lutar', de_guarda: false, guarda_pessoal: 0,
    equipes: [{ posto_id: 'p1_clareira', nome: 'Clareira', recurso: 'comida', coletores: [1], guardas: [3], poder: 90, ameaca: 18, producao: 12 },
              { posto_id: 'p1_bosque', nome: 'Bosque', recurso: 'madeira', coletores: [2], guardas: [], poder: 0, ameaca: 18, producao: 0 },
              { posto_id: 'ponto', nome: 'Equipe do ponto', recurso: null, coletores: [], guardas: [], poder: 0, ameaca: null, producao: 0 }] };
  ctx.desenharEquipe(div, d.equipes[0], d);
  ctx.desenharEquipe(div, d.equipes[2], d);
  // a lista de adicionar: mais talento primeiro, e o filtro esconde quem está em outra equipe
  const agri = (h) => (h.talentos.agricultor || 0);
  const vazia = { posto_id: 'x', coletores: [], guardas: [] };
  const ordem = ctx.candidatosParaAdicionar(habs, vazia, agri, false).map((h) => h.id);
  if (ordem[0] !== 2) throw new Error('não mostrou primeiro quem tem mais talento: ' + ordem);
  if (ctx.candidatosParaAdicionar(habs, vazia, agri, true).some((h) => h.id === 2))
    throw new Error('o filtro "só livres" mostrou quem está em outra equipe');
  if (ctx.candidatosParaAdicionar(habs, d.equipes[0], agri, false).some((h) => h.id === 1))
    throw new Error('a lista de adicionar mostrou quem já está na equipe');
  ctx.listaParaAdicionar(ctx.document.createElement('div'), d.equipes[0], d, 'guardas', habs, {}, (h) => h.talentos.guarda || 0);
});

tentar('linhaMaterialDaLoja', () => {
  if (!ctx.linhaMaterialDaLoja({ rank: 3, nome: 'Primordial', fonte: 'chefes', preco: 200, tem: 2 }))
    throw new Error('não montou a linha de material da loja');
});

tentar('cartaoDaReliquia', () => {
  if (!ctx.cartaoDaReliquia({ id: 'martelo_frio', icone: '🔨', nome: 'Martelo Frio',
    historia: 'um martelo', texto: 'O ferreiro cobra 20% menos.', ativa: false }, true))
    throw new Error('não montou o cartão da relíquia');
  ctx.cartaoDaReliquia({ id: 'x', icone: '🗺️', nome: 'Mapa', historia: 'h', texto: 't', ativa: true }, true);
});

tentar('painelDiarias', () => {
  const st = { dia: '2026-09-25', bonus: 600, bonus_pronto: false, bonus_resgatado: false, total: 4000,
    diarias: [{ id: 'd_torre', nome: 'Caçada', desc: 'Mate 30', meta: 30, ouro: 1200, progresso: 30, pronta: true, resgatada: false },
              { id: 'd_raid', nome: 'Raid', desc: 'Mate 10', meta: 10, ouro: 1200, progresso: 4, pronta: false, resgatada: false }] };
  if (!ctx.painelDiarias(st)) throw new Error('não montou o painel das diárias');
  if (ctx.contarMissoesProntas(st, { missoes: [{ concluida: true, resgatada: false }] }) !== 2)
    throw new Error('badge de missões contou errado');
  ctx.painelDiarias({ ...st, bonus_pronto: true, diarias: [] });
});

tentar('montarPodio', () => {
  const dados = { campo: 'floor', icone: '🗼', ranking: [
    { telegram_id: 1, username: 'A', floor: 30 }, { telegram_id: 2, username: 'B', floor: 20 }] };
  if (!ctx.montarPodio(dados)) throw new Error('não montou o pódio');
  if (!ctx.linhaDoRanking({ telegram_id: 9, username: 'Z', arena_points: 1200, wins: 3, losses: 1 }, 4,
    { campo: 'arena_points', icone: '⚔️' })) throw new Error('não montou a linha do ranking');
});

tentar('cartaoDoFerreiro', () => {
  ctx.cartaoDoFerreiro('lenhador', { nome: 'x', acao: 'evoluir', tier_lote: 1, alvo: 2, total: 25, quem: 25,
    custo: { 1: 75 }, tem: { 1: 40 }, bonus: 1, bonus_proximo: 1.15 });
  ctx.cartaoDoFerreiro('guarda', { nome: 'y', acao: 'nivelar', tier_lote: 3, alvo: 3, total: 4, quem: 1,
    custo: { 1: 9, 2: 6 }, tem: { 1: 99, 2: 99 }, bonus: 1.45, bonus_proximo: 1.45 });
  ctx.cartaoDoFerreiro('minerador', { nome: 'z', acao: 'maximo', tier_lote: 5, total: 4, quem: 0,
    custo: {}, tem: {}, bonus: 2.1 });
});

tentar('cabecalhoDoAndar', () => {
  if (!ctx.cabecalhoDoAndar({ andar_de_trabalho: 3, equipes: [{ especial: 'ponto', guardas: [], coletores: [] },
    { posto_id: 'p', guardas: [1], coletores: [] }] })) throw new Error('não montou o cabeçalho do andar');
});

tentar('caixaDeExploracao', () => {
  const eqs = [{ posto_id: 'p5_bosque', nome: 'Bosque', guardas: [1], coletores: [2] },
               { posto_id: 'ponto', nome: 'Equipe do ponto', guardas: [], coletores: [] }];
  const caixa = ctx.caixaDeExploracao({ comida: 50, custo_busca: 6, equipes: eqs, achados: { equipe: 'p5_bosque', lista: [
    { tipo: 'posto', titulo: '🌲 Bosque ★★', detalhe: 'rende 6 de madeira' },
    { tipo: 'ponto', titulo: 'Mina I · Andar 5', detalhe: '🤖 Presas' },
    { tipo: 'cidade', titulo: '🏰 Cidade de X', detalhe: 'outro clã' }] } });
  if (!caixa) throw new Error('não montou a caixa de exploração');
  if (!ctx.caixaDeExploracao({ comida: 0, custo_busca: 6, equipes: [eqs[1]], achados: {} })) throw new Error('sem equipe com guarda devia avisar');
});

tentar('desenharJornada', () => {
  const t = { origem: 9, destino: 10, tempo: 18, turno: 7, comida: 30, tatica: 'normal',
    turno_da_batalha: 2, limite: 6, batalhas_vencidas: 1, reforcos: 1, espolio_couro: 50,
    abatidos: 3, fim: null, espolio_material: { 1: 3 }, custo_comer: 8, log: ['a'],
    taticas: { normal: '⚖️', ofensiva: '⚔️', defensiva: '🛡️' },
    grupo: [{ nome: 'A', hp: 50, hp_max: 100 }, { nome: 'B', hp: 0, hp_max: 100 }],
    inimigos: [{ nome: 'Orc', tipo: 'elite', hp: 30, hp_max: 90 }] };
  ctx.desenharJornada({ jornada: t });
  ctx.desenharJornada({ jornada: null, andar_do_cla: 9, andar_max: 12, destino: 10, comida: 90,
    em_posto: 0, tempo: 18, limite: 6, chefe: true, comida_min: 25, comida_max: 50,
    nivel_referencia: 20, lutadores: [{ nome: 'A', hp_max: 100, atk: 10, def: 5 }] });
  ctx.desenharJornada({ jornada: null, andar_do_cla: 9, andar_max: 9, destino: null, lutadores: [] });
  ctx.desenharJornada({ jornada: t }, { fim: 'sucesso', destino: 10, batalhas: 3, abatidos: 5,
    reforcos: 1, material: { 1: 4 }, ouro: 90, comida_volta: 4, ferimentos: { 0: 2 }, gold: 999,
    posto_revelado: { nome: '🌲 Bosque ★★ · Andar 10' } });
});

tentar('ladoDoDuelo', () => {
  ctx.ladoDoDuelo(LADO_ARENA, 'Rival', false, true);
  ctx.ladoDoDuelo({ ...LADO_ARENA, img_key: null, escudo: 0, atordoado: false, dots: [] },
                  'Você', true, false);
});
tentar('desenharArenaCombate', () => {
  ctx.desenharArenaCombate({
    voce: { ...LADO_ARENA, nome: 'Você' }, oponente: LADO_ARENA,
    log: 'bateu', skills: [
      { skill_id: 'a_fire_1', nome: 'Faísca', cooldown_restante: 0, cooldown_max: 3 },
      { skill_id: 'a_ice_1', nome: 'Lasca', cooldown_restante: 2, cooldown_max: 4 }],
  });
  // e a tela de fim de luta, que é outro caminho inteiro
  ctx.desenharArenaCombate({ finalizado: true, venceu: true, ouro_ganho: 50,
                             pontos_delta: 0.2, gold: 100 });
  ctx.desenharArenaCombate({ finalizado: true, venceu: false, pontos_delta: -0.4 });
});

console.log(falhou ? '\n❌ ALGO FALHOU' : '\n🟢 APP.JS EXECUTA: TUDO PASSOU');
process.exit(falhou ? 1 : 0);
