#!/usr/bin/env python3
"""Fase 4 (20/09): a fundação monta o clã inicial, e os storylets da aldeia
falam das equipes, da aldeia e dos vizinhos — com efeito de verdade.

- as respostas da fundação decidem QUEM VEM e com que talento mínimo (e
  sempre vem um guarda: sem guarda nenhuma equipe sai);
- a fundação soma madeira/couro/ferro no clã;
- a relação com os vizinhos começa neutra (50) e mexe no PREÇO de comprar
  de outras aldeias;
- todo efeito dos storylets novos é algo que o jogo aplica (qualidade ou
  recurso real).
"""
import sys, os, json, random, tempfile, types

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

BANCO = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = BANCO
from game import clan_repo as CR
from game.clan_fundacao import aplicar_fundacao
from game.clan_equipes import preco_de_outra_aldeia, PRECO_OUTRAS_ALDEIAS
from game.storylets import _estado

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


CR.init_clan()
DONO = 12
CR.carregar_clan(DONO)
p = {"telegram_id": DONO}
res = aplicar_fundacao(p, {"origem": "montanha", "primeira_prova": "guerra", "acolhida": "negociou"})
chegaram = CR.fundar_aldeia(DONO, res["gente"], res["extras"], random.Random(3))
habs = CR.listar_habitantes(DONO)
guardas = [h for h in habs if h["talentos"].get("guarda", 0) >= 1]
exigir(len(habs) == 1 + 3 + 2 + 1, f"montanha+guerra+negociou deviam trazer 7 pessoas: {len(habs)}")
exigir(len([h for h in guardas if h["talentos"]["guarda"] >= 2]) >= 3,
       "a montanha e a guerra não trouxeram os guardas 2★ prometidos")
exigir(len([h for h in habs if h["talentos"].get("minerador", 0) >= 2]) >= 2, "faltaram os mineradores 2★ da montanha")
exigir(any(h["talentos"].get("lenhador", 0) >= 2 for h in habs), "faltou o lenhador 2★ de quem negociou")
clan = CR.carregar_clan(DONO)
exigir(clan["madeira"] == 40 and clan["couro"] == 10 and clan["materiais"].get(1) == 30,
       f"a fundação não somou madeira/couro/ferro certos: {clan['madeira']}, {clan['couro']}, {clan['materiais']}")
exigir(len(chegaram) == len(habs), "a tela não recebeu quem chegou")

# toda fundação traz ao menos um guarda
p2 = {"telegram_id": 13}
res2 = aplicar_fundacao(p2, {"origem": "planicie", "primeira_prova": "fome", "acolhida": "acolheu"})
exigir(any(g["funcao"] == "guarda" for g in res2["gente"]), "uma fundação sem guarda nenhum — nenhuma equipe sairia")

# vizinhos: começa neutro, e mexe no preço
exigir(_estado({"telegram_id": 1})["qualidades"]["vizinhos"] == 50, "a relação com os vizinhos não começa em 50")
for r, base in PRECO_OUTRAS_ALDEIAS.items():
    exigir(preco_de_outra_aldeia(r, 50) == base, f"{r}: com relação neutra o preço não é o de tabela")
exigir(preco_de_outra_aldeia("ferro", 100) < 5 < preco_de_outra_aldeia("ferro", 0),
       "a relação com os vizinhos não mexe no preço do ferro")

# (26/09/2026) a checagem dos storylets antigos da aldeia saiu com o sistema
# antigo de decisões — o conteúdo agora são as Crônicas (testar_cronicas.py).

if falhas:
    print("❌ FUNDAÇÃO / VIZINHOS COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print(f"✅ fundação monta o clã inicial ({len(habs)} pessoas na montanha+guerra+negociou), vizinhos "
      f"começam neutros e mexem no preço")
