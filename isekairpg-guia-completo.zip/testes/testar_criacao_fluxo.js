// 🎭 FLUXO DE CRIAÇÃO DE PONTA A PONTA (28/09) — roda o app.js INTEIRO num
// DOM simulado (classes de verdade, árvore de elementos, cliques), com um
// servidor de mentira que se comporta como o real pra um jogador novo:
// sexo → raça → profissão → habilidade → entrada no jogo.
// Confere, a cada passo: a barra de abas (menu de baixo) continua ESCONDIDA
// durante a criação; nenhum erro aparece; e no fim o jogo abre com a barra.
const fs = require('fs'), vm = require('vm'), path = require('path');
const arq = (process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : null) || path.join(path.dirname(__dirname), 'webapp/static/app.js');
const src = fs.readFileSync(arq, 'utf8');

const porId = {};
const CHAVE_TOKEN = (src.match(/const CHAVE_TOKEN\s*=\s*["']([^"']+)/) || [])[1];
function criar(tag) {
  const classes = new Set();
  const e = {
    tag, filhos: [], pai: null, _texto: '', dataset: {}, style: { setProperty() {}, removeProperty() {} },
    attrs: {}, disabled: false, value: '',
    classList: {
      add: (...c) => c.forEach((x) => classes.add(x)), remove: (...c) => c.forEach((x) => classes.delete(x)),
      toggle: (c, f) => { const v = f === undefined ? !classes.has(c) : !!f; v ? classes.add(c) : classes.delete(c); return v; },
      contains: (c) => classes.has(c),
    },
    get className() { return [...classes].join(' '); },
    set className(v) { classes.clear(); String(v || '').split(/\s+/).filter(Boolean).forEach((x) => classes.add(x)); },
    get textContent() { return this._texto + this.filhos.map((f) => f.textContent || '').join(''); },
    set textContent(v) { this._texto = String(v ?? ''); this.filhos = []; },
    get innerHTML() { return ''; }, set innerHTML(v) { this.filhos = []; this._texto = ''; },
    appendChild(x) { if (x && typeof x === 'object') { x.pai = this; this.filhos.push(x); } return x; },
    append(...xs) { xs.forEach((x) => typeof x === 'string' ? this.appendChild(Object.assign(criar('#t'), { _texto: x })) : this.appendChild(x)); },
    prepend(x) { if (x) { x.pai = this; this.filhos.unshift(x); } },
    remove() { if (this.pai) this.pai.filhos = this.pai.filhos.filter((f) => f !== this); },
    replaceWith(x) { if (this.pai) { const i = this.pai.filhos.indexOf(this); this.pai.filhos[i] = x; x.pai = this.pai; } },
    insertBefore(x) { this.appendChild(x); },
    setAttribute(k, v) { this.attrs[k] = v; if (k === 'id') porId[v] = this; }, getAttribute(k) { return this.attrs[k] ?? null; },
    removeAttribute(k) { delete this.attrs[k]; },
    addEventListener() {}, removeEventListener() {}, focus() {}, click() { this.onclick && this.onclick({ target: this, preventDefault() {}, stopPropagation() {} }); },
    scrollIntoView() {}, scrollTo() {}, getBoundingClientRect: () => ({ left: 0, top: 0, width: 100, height: 40 }),
    querySelector(s) { return todos(this).find((x) => casa(x, s)) || null; },
    querySelectorAll(s) { return todos(this).filter((x) => casa(x, s)); },
    contains(x) { return todos(this).includes(x); }, closest() { return null; },
    get parentNode() { return this.pai || corpo; },
    get children() { return this.filhos; }, get firstChild() { return this.filhos[0] || null; },
    get isConnected() { return true; }, scrollLeft: 0, clientWidth: 100,
  };
  return e;
}
function todos(n, acc = []) { for (const f of n.filhos || []) { acc.push(f); todos(f, acc); } return acc; }
function casa(x, s) { s = s.trim(); if (s.startsWith('.')) return x.classList.contains(s.slice(1).split(/[ .\[]/)[0]); if (s.startsWith('#')) return x.attrs.id === s.slice(1); return x.tag === s; }
function idEl(id, classes = '') { const e = criar('div'); e.attrs.id = id; e.className = classes; porId[id] = e; return e; }
const corpo = criar('body');
// todos os elementos com id do index.html DE VERDADE (com as classes iniciais)
const html = fs.readFileSync(path.join(path.dirname(arq), 'index.html'), 'utf8');
for (const m of html.matchAll(/<([a-z0-9]+)[^>]*\bid="([^"]+)"[^>]*>/gi)) {
  if (m[2] === 'barra-abas') continue;
  const cls = (m[0].match(/class="([^"]*)"/) || [])[1] || '';
  corpo.appendChild(idEl(m[2], cls));
}
const barra = idEl('barra-abas', 'barra-abas oculto');
for (const g of ['personagem', 'mundo', 'cidade', 'clan', 'mais']) { const b = criar('button'); b.className = 'aba-item'; b.dataset.grupo = g; barra.appendChild(b); }
corpo.appendChild(barra);

// --- servidor de mentira (as regras do real, pro jogador novo)
const NASCIDO = process.argv.includes('--nascido');
const estado = { sexo: null, raca: NASCIDO ? 'humano' : null, classe: NASCIDO ? 'mago' : null, skill: false, nome: NASCIDO ? 'Brisa' : '' };
const toasts = [], erros = [];
// --falha: o servidor falha UMA vez a pergunta "ainda falta criar?" (logo
// depois da habilidade, ou na abertura) — servidor ocupado, internet oscilando
// --falha=<onde>:<vezes>  (1 vez: a nova tentativa automática resolve sozinha;
// 2 vezes: as duas tentativas falham e a tela de "Tentar de novo" aparece)
const [FALHA, VEZES_TXT] = ((process.argv.find((a) => a.startsWith('--falha=')) || '').split('=')[1] || '').split(':');
const VEZES = Number(VEZES_TXT || 1);
let falhasPendentes = FALHA === 'abertura' ? VEZES : 0;
function resposta(url, opcoes) {
  const corpoReq = opcoes && opcoes.body ? JSON.parse(opcoes.body) : {};
  if (url.includes('/api/character/opcoes')) return {
    sexo_atual: estado.sexo, raca_atual: estado.raca, classe_atual: estado.classe,
    racas: [{ id: 'humano', nome: 'Humano', descricao: '', ganhos: [], perdas: [] }],
    classes: [{ id: 'mago', nome: 'Mago', descricao: '', ganhos: [], perdas: [] }],
    skill_pendente: !!estado.classe && !estado.skill,
    skills_iniciais: estado.classe ? [{ id: 'core_fire_1', skill_id: 'a_fire_1', nome: 'Faísca', efeitos: ['Dano de 130%'] }] : [],
    nascido_na_torre: NASCIDO };
  if (url.includes('/api/character/sexo')) { estado.sexo = corpoReq.sexo; return { ok: true }; }
  if (url.includes('/api/character/raca')) { estado.raca = corpoReq.id; return { ok: true, msg: '' }; }
  if (url.includes('/api/character/classe')) { estado.classe = corpoReq.id; return { ok: true, msg: '' }; }
  if (url.includes('/api/character/skill_inicial')) { estado.skill = true; if (FALHA === 'habilidade') falhasPendentes = VEZES; return { ok: true, msg: 'ok', nome: 'Faísca' }; }
  if (url.includes('/api/tower/status')) return { em_combate: false, andar: 1, hp: 100, hp_max: 100 };
  if (url.includes('/api/character')) return { level: 1, tower_floor: 1, username: estado.nome, stats: {}, equip: {}, atributos: {} };
  if (url.includes('/api/tutorial/')) return { visto: false };
  return {};
}
const janela = {
  document: null, location: { href: '', search: '', pathname: '/', reload() {} },
  // o token fica na MESMA chave que o jogo usa (CHAVE_TOKEN), lida do app.js
  localStorage: { getItem: (k) => (k === CHAVE_TOKEN ? 'tok' : null), setItem() {}, removeItem() {} },
  sessionStorage: { getItem: () => null, setItem() {}, removeItem() {} },
  addEventListener() {}, matchMedia: () => ({ matches: false, addEventListener() {} }),
  fetch: (url, op) => {
    if (String(url).includes('/api/character/opcoes') && falhasPendentes > 0) {
      falhasPendentes--;
      return Promise.resolve({ ok: false, status: 500, json: () => Promise.resolve({ detail: 'Erro no servidor (500).' }) });
    }
    return Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve(resposta(String(url), op)) });
  },
  navigator: { userAgent: 't', onLine: true, vibrate() {} }, innerHeight: 800, innerWidth: 400,
  setTimeout: (f, ms) => setTimeout(f, Math.min(ms || 0, 5)), clearTimeout, setInterval: () => 0, clearInterval() {},
  requestAnimationFrame: (f) => setTimeout(f, 0), confirm: () => true, alert() {}, scrollTo() {},
  AudioContext: undefined, Telegram: undefined,
};
const documento = {
  getElementById: (id) => porId[id] || null, createElement: (t) => criar(t), createTextNode: (t) => Object.assign(criar('#t'), { _texto: t }),
  querySelector: (s) => corpo.querySelector(s), querySelectorAll: (s) => corpo.querySelectorAll(s),
  addEventListener() {}, removeEventListener() {}, body: corpo, head: criar('head'), documentElement: criar('html'), hidden: false,
};
janela.document = documento; janela.window = janela;
const ctx = vm.createContext({ ...janela, window: janela, document: documento, console, Promise, JSON, Math, Date, URL,
  URLSearchParams, Error, TypeError, Set, Map, Array, Object, String, Number, Boolean, parseInt, parseFloat, isNaN,
  encodeURIComponent, decodeURIComponent, Intl, FormData: class FormData {} });
// o boot automático (iniciar) não roda aqui: o teste chama a entrada na mão
vm.runInContext(src.replace(/\(async function iniciar\(\) \{/, '(async function __naoIniciar() { return;'), ctx, { filename: 'app.js' });
vm.runInContext('toast = (m, e) => { __toasts.push([m, !!e]); };', Object.assign(ctx, { __toasts: toasts }));

const espera = (ms = 60) => new Promise((r) => setTimeout(r, ms));
const conteudo = porId['conteudo'];
const botao = (texto) => todos(conteudo).find((x) => x.tag === 'button' && (x.textContent || '').includes(texto));
let falhas = 0;
const linha = (rot, ok, extra = '') => { console.log(`${ok ? '✅' : '❌'} ${rot}${extra ? ' — ' + extra : ''}`); if (!ok) falhas++; };
const barraVisivel = () => !barra.classList.contains('oculto');

(async () => {
  process.on('unhandledRejection', (e) => erros.push(String(e && e.message || e)));
  await ctx.entrarNoJogo(); await espera(1700);
  const telaTentar = () => todos(porId['tela-carregando']).find((x) => x.tag === 'button' && (x.textContent || '').includes('Tentar'));
  if (FALHA === 'abertura') {
    linha(`falha na abertura (${VEZES}×): NÃO entra no jogo sem criar (menu escondido)`, !barraVisivel());
    if (VEZES >= 2) {
      linha('duas falhas seguidas: mostra "Tentar de novo"', !!telaTentar());
      porId['tela-carregando'].filhos = [];
      await ctx.entrarNoJogo(); await espera();
    } else {
      linha('uma falha: a nova tentativa resolve sozinha (sem tela de erro)', !telaTentar());
    }
  }
  linha('passo 1 (sexo): menu de baixo escondido', !barraVisivel());
  const passos = NASCIDO ? [['Feminino', 'sexo'], ['Escolher Faísca', 'habilidade']]
    : [['Feminino', 'sexo'], ['Escolher Humano', 'raça'], ['Escolher Mago', 'profissão'], ['Escolher Faísca', 'habilidade']];
  for (const [texto, nome] of passos) {
    const b = botao(texto);
    if (!b) { linha(`achar o botão "${texto}" (${nome})`, false); break; }
    b.onclick({ target: b, preventDefault() {}, stopPropagation() {} });
    await espera(1700);   // cobre a espera da nova tentativa automática
    if (process.env.DEPURAR) console.log('   toasts até aqui:', JSON.stringify(toasts));
    const ultimo = nome === 'habilidade';
    if (ultimo && FALHA === 'habilidade' && VEZES >= 2) {
      linha('duas falhas logo depois da habilidade: NÃO cai no jogo pela metade (menu escondido)', !barraVisivel());
      linha('duas falhas logo depois da habilidade: mostra "Tentar de novo"', !!telaTentar());
      porId['tela-carregando'].filhos = [];
      await ctx.entrarNoJogo(); await espera(120);
      linha('tentou de novo: agora entra no jogo, com o menu', barraVisivel());
      continue;
    }
    linha(`depois de escolher ${nome}: menu de baixo ${ultimo ? 'aparece (jogo começou)' : 'continua escondido'}`,
          ultimo ? barraVisivel() : !barraVisivel());
  }
  const ruins = toasts.filter((t) => t[1]);
  if (!FALHA) {
    linha('nenhum erro na tela durante a criação', !ruins.length && !erros.length, ruins.concat(erros).map(String).join(' | '));
  }
  console.log(falhas ? `❌ ${falhas} falha(s)` : '✅ criação de ponta a ponta ok');
  process.exit(falhas ? 1 : 0);
})();
