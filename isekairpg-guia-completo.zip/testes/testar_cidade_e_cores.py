#!/usr/bin/env python3
"""A cidade e o Veio de Cores (20/09, pedido do dev), no banco.

- 🔮 Veio de Cores: ponto que rende CORES pro inventário do personagem, do
  tier do andar; a equipe do ponto ali é SÓ de guardas.
- 🏰 Cidade: onde fica o que a aldeia tem. A guarnição (guardas que ficam em
  casa) é quem a defende — guarda que saiu com equipe não conta; se o
  ataque passar, levam 20% do estoque (comida, madeira, couro, ferro).
"""
import sys, os, json, random, tempfile, time, types

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
try:
    import aiosqlite  # noqa: F401
except ModuleNotFoundError:
    falso = types.ModuleType("aiosqlite")
    falso.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("só síncrono"))
    sys.modules["aiosqlite"] = falso

BANCO = os.path.join(tempfile.mkdtemp(), "t.db")
import game.sql_repo as SR
SR.DB_PATH = BANCO
from game import clan_repo as CR
from game import clan_habitantes as H

falhas = []


def exigir(cond, msg):
    if not cond:
        falhas.append(msg)


CR.init_clan()
DONO = 11
CR.carregar_clan(DONO)


def hab(nome, talentos, nivel=20):
    with CR._conn() as c:
        cur = c.execute("INSERT INTO clan_habitante(owner_id, nome, profissao, nivel, potencial, fadiga,"
                        " descansando, aura, vivo, talentos) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (DONO, nome, "agricultor", nivel, 1, 0, 0, 0, 1, json.dumps(talentos)))
        c.commit()
        return cur.lastrowid


guarda = hab("Muro", {"guarda": 3})
coletor = hab("Ana", {"agricultor": 2})
veio = next(p for p in CR.listar_mapa(5) if p["tipo"] == "cores")
with CR._conn() as c:
    c.execute("UPDATE clan SET andar = 5, ponto_id = ?, comida = 300, madeira = 50, couro = 50,"
              " materiais = '{\"1\": 50}' WHERE owner_id = ?", (veio["id"], DONO))
    c.execute("UPDATE territorio SET dono_tipo='jogador', dono_id=?, integridade=100 WHERE id=?",
              (str(DONO), veio["id"]))
    c.commit()

# ── 🔮 Veio de Cores: só guardas, e rende cores do tier do andar
exigir(not CR.montar_equipe(DONO, CR.EQUIPE_DO_PONTO, [coletor], [guarda], 30)["ok"],
       "o Veio de Cores aceitou coletor na equipe do ponto")
exigir(CR.montar_equipe(DONO, CR.EQUIPE_DO_PONTO, [], [guarda], 30)["ok"],
       "o Veio de Cores recusou uma equipe só de guardas")
cores = []
for s in range(6):
    with CR._conn() as c:
        c.execute("UPDATE clan SET ultimo_tick = ? WHERE owner_id = ?", (int(time.time()) - 6 * 3600, DONO))
        c.commit()
    cores += CR.rodar_afk(DONO, areas={}, modelos={}, rng=random.Random(30 + s)).get("cores") or []
exigir(cores and all(c.endswith("_t1") for c in cores),
       f"o Veio de Cores do Andar 5 não rendeu cores Tier 1: {cores}")

# ── 🏰 cidade: só guardas; quem defende é a guarnição
exigir(not CR.montar_equipe(DONO, CR.EQUIPE_DA_CIDADE, [coletor], [guarda], 30)["ok"],
       "a guarnição da cidade aceitou coletor")
fora = H.defesa_da_aldeia(CR.listar_habitantes(DONO), 0)       # guarda está no ponto
exigir(CR.montar_equipe(DONO, CR.EQUIPE_DA_CIDADE, [], [guarda], 30)["ok"], "não montou a guarnição")
dentro = H.defesa_da_aldeia(CR.listar_habitantes(DONO), 0)
exigir(dentro > fora, f"o guarda na guarnição não defende a cidade ({fora} → {dentro})")

# ── saque: ataque que passa leva 20% do estoque
CR.desfazer_equipe(DONO, CR.EQUIPE_DA_CIDADE)
chance, ameaca = H.CHANCE_ATAQUE_SESSAO, H.ameaca_do_ataque
H.CHANCE_ATAQUE_SESSAO, H.ameaca_do_ataque = 1.0, (lambda vivos, rng: 10 ** 6)
try:
    with CR._conn() as c:
        c.execute("UPDATE clan SET madeira = 100, couro = 100, ultimo_tick = ? WHERE owner_id = ?",
                  (int(time.time()) - 6 * 3600, DONO))
        c.commit()
    rel = CR.rodar_afk(DONO, areas={}, modelos={}, rng=random.Random(7))
finally:
    H.CHANCE_ATAQUE_SESSAO, H.ameaca_do_ataque = chance, ameaca
saque = (rel.get("equipes") or {}).get("saque") or {}
exigir(saque.get("madeira", 0) >= 15 and saque.get("couro", 0) >= 15,
       f"o ataque que passou não levou ~20% do estoque: {saque}")
exigir(any("Atacaram a cidade" in m["texto"] for m in CR.carregar_clan(DONO)["memorias"]),
       "o saque não foi pras Memórias")

if falhas:
    print("❌ CIDADE / CORES COM PROBLEMA")
    for f in falhas:
        print("  -", f)
    sys.exit(1)
print("✅ cidade e cores: Veio de Cores só de guardas rende cores do andar; a guarnição defende "
      "a cidade; ataque que passa leva 20% do estoque")
